# FareHarbor Internal Endpoint Scout Report

Below is a Cursor-ready knowledge-base report based on the Google Doc **“FareHarbor API Endpoints”**, which contains several Endpoint Scout runs from **2026-05-28 to 2026-06-08**. The document is a captured internal dashboard traffic report, not official public API documentation. The first captured report alone lists **44 endpoint groups**, **27 important groups**, and **24 groups with schema data**.

---

## Scope and caveats

These endpoints were discovered from live FareHarbor dashboard traffic captured by the extension’s Endpoint Scout. They should be treated as **internal dashboard API endpoints**, not stable public API contracts. Many require an authenticated FareHarbor dashboard session and company-level permissions.

The document repeatedly confirms that the scout captured both `fetch` and `XHR`, had schema mode enabled, and was injected into FareHarbor pages. Some endpoints only appeared from `performance` entries or refetches, which means they may need extra authentication headers, CSRF state, or route context. Several response bodies were redacted or too large to refetch.

Recommended usage in the Chrome extension:

Do **not** hard-code assumptions from one company. Always parse company shortname, item ID, reseller company ID, reseller item ID, option ID, availability ID, booking UUID, and calendar date from the current dashboard URL/DOM.

Prefer read-only `GET` endpoints for enrichment. Be much more careful with `POST` and `PUT` endpoints, because those directly mutate dashboard data.

---

# 1. Core / session / permissions endpoints

## `GET /api/v1/version/`

**Purpose:** FareHarbor backend version/deploy metadata.

**Observed response:** `version.version`, `tag`, `branch`, `commit`, `short_commit`, `deploy_time`.

**Extension relevance:** Mostly diagnostic. Useful to include in debug reports when endpoint behavior changes after FareHarbor deploys.

---

## `GET /api/authentication/v1/companies/{id}/permissions/`

**Purpose:** Returns permission flags for the current user in a company context.

**Observed fields:** `can_view_contacts`, `can_view_activities`, `can_view_resources`, `can_view_customer_types`, `can_view_items`, `can_view_availabilities`, `can_edit_activities`, `can_view_availability_capacities`, `can_edit_bookings`, and many more.

**Extension relevance:** Very useful as a gate before showing buttons or trying endpoints. For example, hide capacity/resource tools if `can_view_availabilities` or `can_view_availability_capacities` is false.

---

## `GET /api/v1/companies/{company}/`

**Purpose:** Returns company metadata.

**Observed fields:** `shortname`, `name`, `processor_currency`, `display_processor_currency`, admin/affiliate flags, fee settings, processor country, etc.

**Extension relevance:** Useful to confirm company context and currency before formatting copied mapping/pricing output.

---

## `GET /api/v1/companies/?jump=yes&q={query}`

**Purpose:** Company search/jump lookup.

**Observed in demo:** `/api/v1/companies/?jump=yes&q=sebastiaan`.

**Extension relevance:** Probably not needed for page-local automation, but useful if the extension ever adds company lookup/search tooling.

---

## `GET /api/v1/changelog-entries/visible/`

**Purpose:** Dashboard changelog entries visible to the current user/company.

**Observed response:** `changelog_entries[]` with `title`, `description`, `date`, link/button fields, image fields, and activity flags.

**Extension relevance:** Low. Mostly dashboard UI noise.

---

## `GET /api/v1/companies/{company}/accounts/`

**Purpose:** Financial/account metadata for a company.

**Observed response:** `accounts[]` with currency ledger objects.

**Extension relevance:** Low for current extension features.

---

# 2. Item endpoints

## `GET /api/v1/companies/{company}/items/?sort=sortable_index&page=0&page-size=100`

**Purpose:** Paginated item list.

**Observed response:** `items[]` with `pk`, `name`, `short_name`, `is_retail`, `is_archived`, `is_private`, `color`, `description`, booking limits, images, and `count`.

**Extension relevance:** Useful for item selectors, mapping tools, and “find item by ID/name” helpers.

---

## `GET /api/v1/companies/{company}/items/?pickable=yes`

**Purpose:** Lightweight item list suitable for dropdowns/pickers.

**Observed response:** `items[]` with basic item fields such as `pk`, `name`, `short_name`, archive/private flags, and `color`.

**Extension relevance:** Better than the full items endpoint for dropdowns because response is smaller.

---

## `GET /api/v1/companies/{company}/items/{item_id}/`

**Purpose:** Item detail.

**Observed response:** `item` with company, name, short name, retail/private/archive flags, booking rules, cutoff settings, min/max party sizes, capacity approximation, description fields, location, booking notes, cancellation notes, images, etc.

**Extension relevance:** Useful for item-level enrichment, validating copied item mappings, displaying item metadata, and comparing DOM values to API values.

---

## `GET /api/items/v1/{company}/{item_id}/structured-description/`

**Purpose:** Structured public/product description for an item.

**Observed response:** `short_description`, `duration`, `cancellation_summary`, `meeting_point`, `location_type`, `location_address`, `min_age`, `max_age`, `group_size`, `description`, included/not-included items, itinerary, highlights, check-in details, what-to-bring, restrictions, extras, disclaimers, FAQs, and guided languages.

**Extension relevance:** Useful for client-facing item copy, OTA mapping context, and comparison against channel product descriptions.

---

## `GET /api/v1/companies/{company}/items/{item_id}/flow-nodes/`

**Purpose:** Item flow/category/navigation tree data.

**Observed response:** `flow_nodes[]` with name, short name, parent, children count, external URL, properties, image URLs, frontend URL, item/combo refs.

**Extension relevance:** Useful if mapping/reporting needs product hierarchy context.

---

## `GET /api/v1/companies/{company}/items/{item_id}/insights/is-low-quality-image-present/`

**Purpose:** Item image quality insight.

**Observed response:** `status` plus `insights.is_low_quality_image_present`.

**Extension relevance:** Low for current mapping/capacity tools.

---

## `GET /api/v1/companies/{company}/items/{item_id}/availability-schedules/`

**Purpose:** Item availability schedules.

**Observed response:** `availability_schedules[]`. In some captures it was empty.

**Extension relevance:** Potentially useful for availability tooling, but the captured response does not provide enough examples to rely on it yet.

---

## `GET /api/v1/companies/{company}/items/{item_id}/custom-field-instance-groups/`

**Purpose:** Item-specific custom field instance groups.

**Observed response:** `custom_field_instance_groups[]`, including group name, item, company, archive flag, and nested `custom_field_instances[]`.

**Extension relevance:** Useful for booking form / manifest / custom-field aware automations.

---

## `GET /api/v1/companies/{company}/items/{item_id}/requirement-groups/`

**Purpose:** Item-level resource/capacity requirement groups.

**Observed response:** `requirement_groups[]` with `short_name`, `is_used_for_bookable_capacity`, `is_item_level`, `requirements[]`, settings, `availability_count`, and `item_count`.

**Extension relevance:** Very relevant for capacity/resource tooling. This may provide a cleaner API path than scraping resources from booking overlays.

---

# 3. Activity/history endpoints

These endpoints all return `activities[]`, usually with `company`, `user`, `object`, `context`, `type`, `created_at`, and `modified_at`.

## `GET /api/v1/companies/{company}/activities/Item/{item_id}/`

**Purpose:** Activity/history log for a dashboard item.

**Observed response:** activities list with next-page support.

**Extension relevance:** Useful for “last changed” columns, audit tools, and item-history related features.

---

## `GET /api/v1/companies/{company}/activities/ResellerItem/{reseller_item_id}/`

**Purpose:** Activity/history for a reseller/channel item.

**Observed on channel mapping pages.**

**Extension relevance:** Relevant to channel mapping UI and “Last changed” column for reseller items.

---

## `GET /api/v1/companies/{company}/activities/ResellerOption/{reseller_option_id}/`

**Purpose:** Activity/history for a reseller option.

**Observed response:** activities list.

**Extension relevance:** Relevant if we add option-level “last changed” or option mapping audits.

---

## `GET /api/v1/companies/{company}/activities/Booking/{booking_id}/`

**Purpose:** Activity/history for a booking.

**Observed response:** activities list for booking object.

**Extension relevance:** Useful for booking audit/debug tools.

---

## `GET /api/v1/companies/{company}/activities/Availability/{availability_id}/`

**Purpose:** Activity/history for an availability.

**Observed later in the doc.**

**Extension relevance:** Potentially very useful for capacity/audit features: when availability settings changed, who changed them, and what changed.

---

## `GET /api/v1/companies/{company}/activities/CancellationPolicy/{policy_id}/`

**Purpose:** Activity/history for a cancellation policy.

**Observed response includes change context for policy/rules.**

**Extension relevance:** Mostly outside current extension scope unless automating settings audits.

---

# 4. Customer type / customer prototype endpoints

FareHarbor appears to distinguish company-level **customer types** from item-level **customer prototypes**. The extension’s duplicate customer type feature currently works through DOM automation, but the captured endpoints show the underlying API calls.

## `GET /api/v1/companies/{company}/customer-types/?is-membership-item=no`

**Purpose:** Company-level customer type list.

**Observed response:** `customer_types[]` with `singular`, `plural`, `short_name`, `name`, hidden/archive flags, sortable index, settings, and tags.

**Extension relevance:** Useful source of base customer types for duplication/mapping tools.

---

## `GET /api/v1/companies/{company}/items/{item_id}/customer-prototypes/`

**Purpose:** Item-level customer prototypes.

**Observed response:** `customer_prototypes[]` with `customer_type`, `item`, `company`, `name`, `display_name`, exclusive/hidden/archive flags, settings, party size limits, age limits, custom field instances, and unicode.

**Extension relevance:** Core endpoint for the duplicate customer types feature. Could replace some DOM scraping.

---

## `GET /api/v1/companies/{company}/items/{item_id}/customer-prototypes/?include-is-inactive=yes`

**Purpose:** Same as above, but includes inactive customer prototypes.

**Observed response:** same shape plus `is_inactive`.

**Extension relevance:** Better default for audits because it avoids missing inactive prototypes.

---

## `GET /api/v1/companies/{company}/items/{item_id}/customer-prototypes/?include-archived=yes&include-is-inactive=yes`

**Purpose:** Expanded customer prototype list including archived and inactive entries.

**Observed response:** redacted in early report but endpoint was captured.

**Extension relevance:** Useful for debugging why a customer type appears missing in the UI.

---

## `GET /api/v1/companies/{company}/items/{item_id}/customer-prototypes/{customer_prototype_id}/`

**Purpose:** Single customer prototype detail.

**Observed response:** `customer_prototype` object.

**Extension relevance:** Useful after creating/duplicating/updating a prototype to confirm state.

---

## `POST /api/v1/companies/{company}/items/{item_id}/customer-prototypes/`

**Purpose:** Create a new customer prototype.

**Observed request:** `{ "name": "string", "customer_type": "number" }`.

**Observed response:** full `customer_prototype`, including `reseller_customer_type_mapping_count`.

**Extension relevance:** Could replace the current DOM duplicate/create flow, but should be used carefully because it mutates data.

---

## `POST /api/v1/companies/{company}/items/{item_id}/customer-prototypes/{customer_prototype_id}/duplicate/`

**Purpose:** Duplicate an existing customer prototype.

**Observed request:** `{ "item": "number", "customer_type": "number" }`.

**Observed response:** full duplicated `customer_prototype`.

**Extension relevance:** Direct API equivalent of the extension’s duplicate customer type workflow. This is probably the cleanest future replacement for clicking “Duplicate” in the UI.

---

## `PUT /api/v1/companies/{company}/items/{item_id}/customer-prototypes/{customer_prototype_id}/`

**Purpose:** Update a customer prototype.

**Observed request fields:** `name`, `note`, `display_name`, exclusive/hidden/archive flags, `capacity`, `minimum_party_size`, `maximum_party_size`, age/group size fields, `is_inactive`, and `settings-deposit_offset`.

**Extension relevance:** Direct API equivalent of renaming duplicated customer types and setting min/max party size.

---

# 5. Pricing / sheets endpoints

## `GET /api/v1/companies/{company}/total-sheets/`

**Purpose:** List total sheets.

**Observed response:** `total_sheets[]` with `name`, `display_name`, base flags, cascade/hidden/archive flags, online/taxable flags, `taxability`, `sheet_rate`, `sheet_percentage`, and `uuid`.

**Extension relevance:** Useful for price-sheet extraction and price editing context.

---

## `GET /api/v1/companies/{company}/total-sheets/?non_base=yes`

**Purpose:** List non-base total sheets.

**Observed response:** same `total_sheets[]` shape.

**Extension relevance:** Useful when distinguishing base/default pricing from extra sheets.

---

## `GET /api/v1/companies/{company}/total-sheets/{sheet_id}/pricing-for-editing/Item/{item_id}/`

**Purpose:** Pricing table for an item/sheet in editing context.

**Observed response:** `effective_pricings[]` with `visibility`, `price`, `sheet_rate`, `taxes`, `line`, `sheet`, and `for_object`.

**Extension relevance:** Very relevant to “grab values from price sheet and copy to clipboard.” This is likely the primary read endpoint for API-based price extraction.

---

## `GET /api/v1/companies/{company}/total-sheets/{sheet_id}/pricing/CustomerPrototype/{customer_prototype_id}/`

**Purpose:** Single pricing row for a customer prototype.

**Observed as performance-only in one run.**

**Extension relevance:** Useful if we need targeted pricing for one customer type rather than the full sheet.

---

## `PUT /api/v1/companies/{company}/total-sheets/{sheet_id}/pricing/CustomerPrototype/{customer_prototype_id}/`

**Purpose:** Update pricing for a customer prototype.

**Observed request fields:** `sheet_rate_type`, `sheet_rate`, `price_type`, `offset`, `tax_inclusion`, `custom_tax`, `modifier_type`, `modifier_kind`, `rate`, taxable flags, visibility flags, required/hidden flags, `tax_types`, `is_tax_pass_through`.

**Extension relevance:** High-risk mutation endpoint. Useful context, but I would avoid automating price writes until we have very strong safeguards.

---

## `GET /api/v1/companies/{company}/total-schedules/`

**Purpose:** List total schedules.

**Observed response:** `total_schedules[]` with name, display name, entries, default flags, archive flag, and UUID.

**Extension relevance:** Pricing context.

---

## `GET /api/v1/companies/{company}/invoice-sheets/`

**Purpose:** List invoice sheets.

**Observed response:** `invoice_sheets[]` with name, display name, taxability, invoice base flags, cascade/inheritance flags, relationship, sheet rate, and sheet percentage.

**Extension relevance:** Pricing/invoice context; useful if copied output needs invoice sheet info.

---

## `GET /api/v1/companies/{company}/invoice-sheets/?non_base=yes`

**Purpose:** List non-base invoice sheets.

**Observed response:** same `invoice_sheets[]` shape.

---

## `GET /api/v1/companies/{company}/invoice-schedules/`

**Purpose:** List invoice schedules.

**Observed response:** `invoice_schedules[]`. Captured example had zero length.

---

# 6. Availability / calendar endpoints

## `GET /api/v1/companies/{company}/Item/{item_id}/availabilities/future/count/`

**Purpose:** Future availability count for an item.

**Observed response:** `future_availability_count.count`.

**Extension relevance:** This is directly relevant to the Future Availabilities column. It is lightweight and probably the best API source for that value.

---

## `GET /api/v1/companies/{company}/reseller-companies/{reseller_company_id}/reseller-items/{reseller_item_id}/?availability_count=yes`

**Purpose:** Reseller/channel item detail with availability count.

**Observed response:** `reseller_item` includes name, external identifier, reseller company info, OTA settings, unmapped customer/option PKs, `changed_at`, and `availability_count`.

**Extension relevance:** This is the best endpoint for channel-item list columns: future availability count and last changed. It explains why a column could use `availability_count` and `changed_at`.

---

## `GET /api/v1/companies/{company}/items/{item_id}/item-calendar/{year}/{month}/?path={path}&week_number={n}`

**Purpose:** Month/week calendar data for an item.

**Observed response:** `calendar.year`, `calendar.month`, `calendar.weeks[]`, and `availability_count`.

**Extension relevance:** Useful for month calendar view parsing and availability counting. Could replace some DOM calendar scraping.

---

## `GET /api/v1/companies/{company}/items/{item_id}/item-calendar/{year}/{month}/?is_empty_calendar=yes`

**Purpose:** Calendar shell/empty calendar view.

**Observed response:** `calendar.year`, `month`, and `weeks[]`.

---

## `GET /api/v1/companies/{company}/search/items/{item_ids}/availabilities/date/{YYYY-MM-DD}/`

**Purpose:** Search/list availabilities for one date across multiple items.

**Observed response:** `availabilities[]` with `start_at`, `end_at`, `booking_count`, resources, requirement group, status, customer count, bookable capacity, reserved capacity, blocks-included capacity, overuse flags, bookable/waitlist flags, and resource availability flags.

**Extension relevance:** Very important for the “check resources/capacity at a specific date and time” idea. This is likely better than scraping visible booking grid data if the target date is known.

---

## `GET /api/v1/companies/{company}/items/{item_id}/availabilities/{availability_id}/`

**Purpose:** Availability detail.

**Observed as performance-only in later report.**

**Extension relevance:** Important for targeted capacity/resource audit, especially after selecting an availability from calendar/search.

---

## `GET /api/v1/companies/{company}/items/{item_id}/availabilities/{availability_id}/?include_custom_field_details=yes`

**Purpose:** Availability detail with custom field details.

**Observed later in the document.**

**Extension relevance:** Better version of availability detail when custom fields matter.

---

## `GET /api/v1/companies/{company}/items/{item_id}/availabilities/{availability_id}/live/?...`

**Purpose:** Live booking form / live availability state.

**Observed variants:**

`?is_flyout=yes&rebooking=`

A longer variant includes `asn`, `client_uuid`, `customer_type_rate_counts`, `include_custom_field_max_counts`, `is_book_form_holding`, `persistent_store`, `resource_custom_field_values`, and `total_sheet`.

**Extension relevance:** Potentially powerful but likely fragile. Could expose live bookability, customer type rates, capacity, custom field max counts, and resource constraints.

---

## `GET /api/v1/companies/{company}/items/{item_id}/availabilities/{availability_id}/book/`

**Purpose:** Booking-form/bootstrap endpoint for a selected availability.

**Observed as performance-only.**

**Extension relevance:** Potentially useful for understanding customer type availability and booking-form constraints.

---

## `GET /api/v1/companies/{company}/items/{item_id}/availabilities/{availability_id}/bookings/`

**Purpose:** Bookings on a specific availability.

**Observed as performance-only.**

**Extension relevance:** Very relevant to capacity audit. Could replace or supplement DOM scraping from the bookings grid.

---

## `GET /api/v1/companies/{company}/availabilities/{availability_id}/effective-sheets/`

**Purpose:** Effective sheets for an availability.

**Observed as performance-only.**

**Extension relevance:** Useful if pricing at the availability level differs from item defaults.

---

## `GET /api/v1/waiting_list/companies/{company}/availabilities/count_members/`

**Purpose:** Waiting list member counts for company availabilities.

**Observed as performance-only.**

**Extension relevance:** Low unless adding waitlist audit features.

---

# 7. Booking / contact / manifest endpoints

## `GET /api/v1/companies/{company}/search/bookings/new/admin/`

**Purpose:** New/admin booking search.

**Observed response:** `bookings[]` with UUID, item, availability, company, customer count, costs, receipt, paid status, invoice flags, created/modified timestamps, voucher number, user type, etc.

**Extension relevance:** Very relevant to booking search helpers. Could be more reliable than FareHarbor’s dashboard search in some cases.

---

## `GET /api/v1/companies/{company}/bookings/{booking_uuid}/`

**Purpose:** Booking detail.

**Observed response:** booking object with item, availability, company, customer counts, costs, receipts, paid status, invoiceable flags, created/modified/original created timestamps, voucher number, and `customers_with_seat_assignments`.

**Extension relevance:** Important for booking lookup, audit, capacity, and resource extraction.

---

## `GET /api/v1/companies/{company}/bookings/{booking_uuid}/customers-with-seats/`

**Purpose:** Customers with seat assignments for a booking.

**Observed response:** `customers`, redacted in scout output.

**Extension relevance:** Useful for seat-map/resource capacity tools.

---

## `GET /api/billing/v1/{company}/bookings/{booking_uuid}/invoice/status/`

**Purpose:** Invoice eligibility/submission status for a booking.

**Observed response:** `invoice.eligible`, `invoice.submitted`, `invoice.booking_id`.

**Extension relevance:** Low for current extension unless adding invoice-related tooling.

---

## `GET /api/v1/companies/{company}/contacts/{contact_id}/`

**Purpose:** Contact detail.

**Observed response:** `contact`, redacted.

**Extension relevance:** Useful for booking/contact lookup but privacy-sensitive.

---

## `GET /api/v1/companies/{company}/customer-profiles/suggestions/?search={query}`

**Purpose:** Customer/contact profile suggestions while searching.

**Observed as performance-only.**

**Extension relevance:** Potentially useful for contact search/autocomplete helpers.

---

## `GET /api/v1/companies/{company}/checkin-statuses/`

**Purpose:** Check-in status definitions.

**Observed response:** `checkin_statuses[]` with type, name, sortable index, hidden flag, and color.

**Extension relevance:** Useful for manifest/check-in tooling.

---

## `GET /api/v1/companies/{company}/custom-manifests/`

**Purpose:** Custom manifest definitions.

**Observed as performance-only.**

**Extension relevance:** Useful for future manifest automation.

---

## `GET /api/v1/companies/{company}/custom-fields/manifest/?include-archived=yes`

**Purpose:** Manifest custom fields, including archived.

**Observed as performance-only.**

**Extension relevance:** Useful for manifest/custom field aware tools.

---

# 8. Custom fields / settings endpoints

## `GET /api/v1/companies/{company}/custom-fields/`

**Purpose:** Company custom fields.

**Observed response:** `custom_fields[]` with name, type, short name, hint, title, description, pricing/private/display flags, linked booking input flag, scanning visibility, default values, etc.

**Extension relevance:** Useful for booking form automation, manifest tooling, and custom-field-aware copy helpers.

---

## `GET /api/v1/companies/{company}/custom-fields/?types=short&types=long&types=email`

**Purpose:** Filtered custom fields by type.

**Observed response:** same `custom_fields[]` shape, filtered to requested types.

---

## `GET /api/v1/companies/{company}/custom-field-instance-groups/`

**Purpose:** Company-level custom field instance groups.

**Observed response:** sometimes empty.

---

## `GET /api/v1/companies/{company}/tax-types/`

**Purpose:** Tax type definitions.

**Observed response:** `tax_types[]` with name, type, short name, rate, offset, percentage, hidden flag.

**Extension relevance:** Useful for pricing output and pricing mutation safety checks.

---

## `GET /api/v1/companies/{company}/in-store-payment-types/`

**Purpose:** In-store payment type definitions.

**Observed response:** redacted `in_store_payment_types`.

**Extension relevance:** Low for current tools.

---

# 9. Resource / capacity configuration endpoints

## `GET /api/v1/companies/{company}/resources/?include-archived=yes`

**Purpose:** Company resource list, including archived.

**Observed response:** `resources[]` with name, short name, archive/hidden flags, `maximum_use_count`, granularity, overuse settings, skip-use-creation settings, and sortable index.

**Extension relevance:** Very relevant to resource/capacity audit. This should be used to identify resource names and max counts rather than relying only on overlay text.

---

## `GET /api/v1/companies/{company}/requirement-groups/`

**Purpose:** Company-level requirement groups.

**Observed response:** `requirement_groups[]` with `short_name`, capacity flags, requirements, settings, availability count, and item count.

**Extension relevance:** Useful for capacity/resource logic across items.

---

## `GET /api/v1/companies/{company}/locations/`

**Purpose:** Company locations.

**Observed response:** `locations[]` with name, street/city/province/country/postal code, latitude/longitude, Google/Tripadvisor fields, and item count.

**Extension relevance:** Useful context for OTA mapping and item detail enrichment.

---

## `GET /api/v1/companies/{company}/routes/?pickable=yes`

**Purpose:** Pickable routes.

**Observed response:** `routes[]`; captured example was empty.

---

## `GET /api/v1/companies/{company}/memberships/?for-item={item_id}`

**Purpose:** Memberships applicable to an item.

**Observed response:** `memberships[]` with singular/plural names, short name, overlap flag, and unicode.

---

## `GET /api/v1/companies/{company}/stored-value-types/`

**Purpose:** Stored value / gift-card-like types.

**Observed response:** `stored_value_types[]` with name, short name, recipient notes, validity duration.

---

## `GET /api/v1/companies/{company}/waivers/`

**Purpose:** Waiver definitions.

**Observed response:** `waivers[]`; captured example empty.

---

# 10. Cancellation policy endpoints

## `GET /api/v1/companies/{company}/cancellation-policies/`

**Purpose:** List cancellation policies.

**Observed response:** `cancellation_policies[]` with name and description.

---

## `GET /api/v1/companies/{company}/cancellation-policies/{policy_id}/`

**Purpose:** Cancellation policy detail.

**Observed response:** `cancellation_policy` with name, description, item count, affiliation count.

---

## `GET /api/v1/companies/{company}/cancellation-policies/{policy_id}/cancellation-rules/`

**Purpose:** Cancellation rules for a policy.

**Observed response:** `cancellation_rules[]` with type, hours, charter/affiliate refund percentages, and cancellation allowed flag.

---

# 11. Channel / reseller / OTA mapping endpoints

These are the most relevant endpoints for Expedia/GetYourGuide/channel mapping features.

## `GET /api/v1/companies/{company}/reseller-companies/{reseller_company_id}/reseller-items/{reseller_item_id}/?availability_count=yes`

**Purpose:** Reseller item detail plus availability count.

**Important fields:** `name`, `short_name`, `external_identifier`, `reseller_company`, OTA settings, `modified_at`, `changed_at`, `availability_count`, unmapped customer/option PKs.

**Extension relevance:** Core endpoint for “Future Availabilities” and “Last changed” columns on channel item pages.

---

## `GET /api/v1/companies/{company}/reseller-companies/{reseller_company_id}/reseller-items/{reseller_item_id}/reseller-customer-types/`

**Purpose:** Customer types defined on a reseller/channel item.

**Observed response:** `reseller_customer_types[]` with name, short name, external identifier, reseller item ref, GetYourGuide/Viator/Booking.com/Airbnb ticket categories, min/max age, Booking.com product option, and mapped customer prototypes.

**Extension relevance:** Very useful for copy mapping features and customer type mapping audits.

---

## `GET /api/v1/companies/{company}/reseller-companies/{reseller_company_id}/reseller-items/{reseller_item_id}/reseller-item-mappings/`

**Purpose:** Dashboard item mappings for a reseller item.

**Observed response:** `reseller_item_mappings[]` with company, item, and reseller item.

**Extension relevance:** Core endpoint for “copy item mapping link/data” features.

---

## `GET /api/v1/companies/{company}/reseller-companies/{reseller_company_id}/reseller-items/{reseller_item_id}/reseller-options/`

**Purpose:** Reseller options/offers for a reseller item.

**Observed response:** `reseller_options[]` with name, short name, event notification flag, reseller item ref, and external identifier.

**Extension relevance:** Core endpoint for copied offer/option mapping data.

---

## `GET /api/v1/companies/{company}/reseller-companies/{reseller_company_id}/reseller-items/{reseller_item_id}/reseller-options/{reseller_option_id}/?availability_count=yes`

**Purpose:** Reseller option detail plus availability count.

**Observed as performance-only/refetch-failed.**

**Extension relevance:** Useful for option-level availability counts if we add that.

---

## `GET /api/v1/companies/{company}/reseller-companies/{reseller_company_id}/reseller-items/{reseller_item_id}/reseller-options/{reseller_option_id}/`

**Purpose:** Reseller option detail.

**Observed as performance-only/refetch-failed.**

---

## `GET /api/v1/companies/{company}/reseller-companies/{reseller_company_id}/reseller-items/{reseller_item_id}/reseller-options/{reseller_option_id}/reseller-option-mappings/`

**Purpose:** Dashboard option/time mappings for a reseller option.

**Observed as performance-only/refetch-failed.**

**Extension relevance:** Highly relevant for option-level copy mapping and audit features.

---

## `GET /api/v1/companies/{company}/reseller-companies/{reseller_company_id}/reseller-items/{reseller_item_id}/unmapped/items/`

**Purpose:** Items not yet mapped to the reseller item.

**Observed response:** `items[]` with basic item fields.

**Extension relevance:** Useful for mapping-assistant workflows and “find unmapped item” features.

---

## `GET /api/v1/companies/{company}/affiliates/{affiliate_id}/`

**Purpose:** Affiliate/reseller relationship detail.

**Observed response:** `affiliation` with company, affiliate company, affiliate group, voucher requirements, payment preference, default invoice sheet/schedule, cancellation policy, email settings, ASN fields, created/modified timestamps, and notes.

**Extension relevance:** Useful for channel context, especially if behavior differs by OTA/affiliate.

---

## `GET /api/v1/companies/{company}/affiliates/?pickable=yes`

**Purpose:** Pickable affiliate list.

**Observed later in the doc.**

---

## `GET /api/v1/companies/{company}/partners/`

**Purpose:** Partner/affiliate list.

**Observed response:** `affiliations[]`; captured example empty.

---

# 12. Other company configuration endpoints

## `GET /api/v1/companies/{company}/groups/`

**Purpose:** Permission/user groups.

**Observed response:** `groups[]` with name, type, permissions, in-use count, and conditions.

---

## `GET /api/v1/companies/{company}/users/`

**Purpose:** Company users.

**Observed as performance-only / body too large / timeout.**

---

## `GET /api/v1/companies/{company}/custom-calendars/`

**Purpose:** Custom calendar definitions.

**Observed response:** `custom_calendars[]` with name, company, user, and settings.

---

## `GET /api/v1/companies/{company}/availability-headlines/`

**Purpose:** Availability headline definitions.

**Observed response:** `availability_headlines[]`; captured example empty.

---

## `GET /api/v1/companies/{company}/booking-restrictions/`

**Purpose:** Booking restriction definitions.

**Observed response:** `booking_restrictions[]`; captured example empty.

---

# 13. Recommended endpoint priorities for the extension

## Highest value for current extension

1. **Future availability count for dashboard items**  
   `GET /api/v1/companies/{company}/Item/{item_id}/availabilities/future/count/`  
   Use `future_availability_count.count`.

2. **Future availability count + changed timestamp for channel items**  
   `GET /api/v1/companies/{company}/reseller-companies/{reseller_company_id}/reseller-items/{reseller_item_id}/?availability_count=yes`  
   Use `availability_count` and `changed_at`.

3. **Item-level customer prototypes**  
   `GET /api/v1/companies/{company}/items/{item_id}/customer-prototypes/?include-is-inactive=yes`  
   Use for duplicate customer types, customer type mapping, min/max, and display names.

4. **Pricing extraction**  
   `GET /api/v1/companies/{company}/total-sheets/{sheet_id}/pricing-for-editing/Item/{item_id}/`  
   Use for price-sheet copy features.

5. **Channel mapping copy features**  
   Use reseller item, reseller customer types, reseller options, reseller item mappings, and reseller option mappings endpoints.

6. **Capacity audit**  
   Prefer API paths in this order:  
   `GET /api/v1/companies/{company}/search/items/{item_ids}/availabilities/date/{YYYY-MM-DD}/`  
   then availability detail / live / bookings endpoints for a selected availability.

---

# 14. Cursor implementation notes

Use these route patterns in helper functions:

```js
const ENDPOINTS = {
  version: () =>
    `/api/v1/version/`,

  company: ({ company }) =>
    `/api/v1/companies/${company}/`,

  permissions: ({ companyPk }) =>
    `/api/authentication/v1/companies/${companyPk}/permissions/`,

  item: ({ company, itemId }) =>
    `/api/v1/companies/${company}/items/${itemId}/`,

  itemsList: ({ company, page = 0, pageSize = 100 }) =>
    `/api/v1/companies/${company}/items/?sort=sortable_index&page=${page}&page-size=${pageSize}`,

  pickableItems: ({ company }) =>
    `/api/v1/companies/${company}/items/?pickable=yes`,

  customerPrototypes: ({ company, itemId, includeInactive = true }) =>
    `/api/v1/companies/${company}/items/${itemId}/customer-prototypes/${includeInactive ? '?include-is-inactive=yes' : ''}`,

  futureAvailabilityCount: ({ company, itemId }) =>
    `/api/v1/companies/${company}/Item/${itemId}/availabilities/future/count/`,

  resellerItemWithAvailabilityCount: ({ company, resellerCompanyId, resellerItemId }) =>
    `/api/v1/companies/${company}/reseller-companies/${resellerCompanyId}/reseller-items/${resellerItemId}/?availability_count=yes`,

  resellerCustomerTypes: ({ company, resellerCompanyId, resellerItemId }) =>
    `/api/v1/companies/${company}/reseller-companies/${resellerCompanyId}/reseller-items/${resellerItemId}/reseller-customer-types/`,

  resellerOptions: ({ company, resellerCompanyId, resellerItemId }) =>
    `/api/v1/companies/${company}/reseller-companies/${resellerCompanyId}/reseller-items/${resellerItemId}/reseller-options/`,

  resellerItemMappings: ({ company, resellerCompanyId, resellerItemId }) =>
    `/api/v1/companies/${company}/reseller-companies/${resellerCompanyId}/reseller-items/${resellerItemId}/reseller-item-mappings/`,

  optionMappings: ({ company, resellerCompanyId, resellerItemId, resellerOptionId }) =>
    `/api/v1/companies/${company}/reseller-companies/${resellerCompanyId}/reseller-items/${resellerItemId}/reseller-options/${resellerOptionId}/reseller-option-mappings/`,

  pricingForEditing: ({ company, totalSheetId, itemId }) =>
    `/api/v1/companies/${company}/total-sheets/${totalSheetId}/pricing-for-editing/Item/${itemId}/`,

  availabilitySearchByDate: ({ company, itemIdsCsv, date }) =>
    `/api/v1/companies/${company}/search/items/${itemIdsCsv}/availabilities/date/${date}/`,

  booking: ({ company, bookingUuid }) =>
    `/api/v1/companies/${company}/bookings/${bookingUuid}/`
};
```

Implementation advice:

Use `fetch()` from the content script context so the request carries the user’s FareHarbor session. Keep API calls behind strict URL gates so the extension does not spam unrelated pages. Cache repeated endpoint calls per route/page for a short TTL. For table columns, store cells by column key rather than visual index to avoid swapped-column bugs after SPA navigation.

Most important caution: the mutation endpoints for customer prototypes and pricing are real write APIs. They should stay behind explicit user actions, confirmation, and strong preflight validation.
