const assert = require("assert");

const CHANNEL_COMPANY_NUMERIC_RE =
  /^\/[^/]+\/dashboard\/settings\/integrations\/channels\/(\d+)\/?$/;
const ITEM_HREF_RE = /\/dashboard\/items\/(\d+)/i;
const ITEM_MAPPINGS_HEADER_RE = /^item\s*mappings$/i;
const ITEM_STATUS_HEADER_RE = /^item\s*status$/i;
const ITEM_STATUS_COLUMN_ATTR = "data-fh-item-status-column";
const UNKNOWN_TEXT = "Unknown";

function parseNumericChannelCompanyPageContext(pathname) {
  const normalized = String(pathname || "").replace(/\/+$/, "");
  if (!normalized || /\/items\/\d+/.test(normalized)) {
    return null;
  }

  const numericMatch = normalized.match(CHANNEL_COMPANY_NUMERIC_RE);
  if (!numericMatch) {
    return null;
  }

  const parts = normalized.split("/").filter(Boolean);
  return {
    companyShortname: parts[0],
    channelId: numericMatch[1]
  };
}

function buildStatusCacheKey(companyShortname, itemId) {
  return `${companyShortname}|${itemId}`;
}

function formatTicketScanningValue(flag) {
  if (flag === true) return "Yes";
  if (flag === false) return "No";
  return UNKNOWN_TEXT;
}

function getTicketScanningLabel(item) {
  if (!item || typeof item !== "object") {
    return UNKNOWN_TEXT;
  }
  return formatTicketScanningValue(item.is_scanning_enabled);
}

function extractMappedItemIdsFromCell(cell) {
  if (!cell) {
    return [];
  }
  const ids = [];
  const links = cell.querySelectorAll('a[href*="/dashboard/items/"]');
  for (const link of links) {
    const href = link.getAttribute("href") || "";
    const match = href.match(ITEM_HREF_RE);
    if (match) {
      ids.push(match[1]);
    }
  }
  return ids;
}

function normalizeCellText(text) {
  return String(text || "").replace(/\s+/g, " ").trim();
}

function findItemMappingsIndex(cells) {
  return cells.findIndex((cell) =>
    ITEM_MAPPINGS_HEADER_RE.test(normalizeCellText(cell.textContent))
  );
}

function findItemStatusIndex(cells) {
  return cells.findIndex((cell) => {
    if (cell.getAttribute?.(ITEM_STATUS_COLUMN_ATTR) === "true") {
      return true;
    }
    return ITEM_STATUS_HEADER_RE.test(normalizeCellText(cell.textContent));
  });
}

function findInsertAnchorCell(cells) {
  const statusIdx = findItemStatusIndex(cells);
  if (statusIdx >= 0) {
    return cells[statusIdx];
  }
  const mappingsIdx = findItemMappingsIndex(cells);
  if (mappingsIdx >= 0) {
    return cells[mappingsIdx];
  }
  return null;
}

function makeMappingsCell(hrefs) {
  return {
    querySelectorAll(selector) {
      assert.strictEqual(selector, 'a[href*="/dashboard/items/"]');
      return hrefs.map((href) => ({
        getAttribute(name) {
          return name === "href" ? href : null;
        }
      }));
    }
  };
}

function makeHeaderCell(text, attrs = {}) {
  return {
    textContent: text,
    getAttribute(name) {
      return attrs[name] ?? null;
    }
  };
}

// --- formatTicketScanningValue / getTicketScanningLabel ---
assert.strictEqual(formatTicketScanningValue(true), "Yes");
assert.strictEqual(formatTicketScanningValue(false), "No");
assert.strictEqual(formatTicketScanningValue(undefined), "Unknown");
assert.strictEqual(formatTicketScanningValue(null), "Unknown");
assert.strictEqual(formatTicketScanningValue("yes"), "Unknown");
assert.strictEqual(
  getTicketScanningLabel({ is_scanning_enabled: true }),
  "Yes"
);
assert.strictEqual(
  getTicketScanningLabel({ is_scanning_enabled: false }),
  "No"
);
assert.strictEqual(getTicketScanningLabel({}), "Unknown");
assert.strictEqual(
  getTicketScanningLabel({ is_scanning_enabled: "yes" }),
  "Unknown"
);
assert.strictEqual(getTicketScanningLabel(null), "Unknown");

// Matching uses PK keys, not names
const lookup = new Map();
lookup.set("512290", true);
lookup.set("512291", false);
assert.strictEqual(formatTicketScanningValue(lookup.get("512290")), "Yes");
assert.strictEqual(formatTicketScanningValue(lookup.get("512291")), "No");
assert.strictEqual(formatTicketScanningValue(lookup.get("999999")), "Unknown");
assert.strictEqual(formatTicketScanningValue(lookup.get("Tour A")), "Unknown");

// Pagination stop: continue while page length === pageSize
function shouldFetchNextPage(itemsLength, pageSize) {
  return itemsLength >= pageSize;
}
assert.strictEqual(shouldFetchNextPage(1000, 1000), true);
assert.strictEqual(shouldFetchNextPage(999, 1000), false);

// --- page context ---
assert.deepStrictEqual(
  parseNumericChannelCompanyPageContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/35764/"
  ),
  { companyShortname: "eatingeurope-rome", channelId: "35764" }
);
assert.strictEqual(
  parseNumericChannelCompanyPageContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/35764/items/316479/"
  ),
  null
);
assert.strictEqual(
  parseNumericChannelCompanyPageContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/viator/"
  ),
  null
);

// --- cache key ---
assert.strictEqual(
  buildStatusCacheKey("babyloncitytours-amsterdam", "83686"),
  "babyloncitytours-amsterdam|83686"
);

// --- item ID extraction ---
assert.deepStrictEqual(
  extractMappedItemIdsFromCell(
    makeMappingsCell([
      "/babyloncitytours-amsterdam/dashboard/items/83686/",
      "/babyloncitytours-amsterdam/dashboard/items/143575/",
      "/dashboard/settings/integrations/channels/1/items/322229/"
    ])
  ),
  ["83686", "143575"]
);
assert.deepStrictEqual(extractMappedItemIdsFromCell(null), []);

// --- insert anchor: prefer Item Status, else Item Mappings ---
{
  const withStatus = [
    makeHeaderCell("Item Mappings"),
    makeHeaderCell("Item Status", { [ITEM_STATUS_COLUMN_ATTR]: "true" }),
    makeHeaderCell("Channel Customer Types")
  ];
  assert.strictEqual(findInsertAnchorCell(withStatus), withStatus[1]);

  const withoutStatus = [
    makeHeaderCell("Item Mappings"),
    makeHeaderCell("Channel Customer Types")
  ];
  assert.strictEqual(findInsertAnchorCell(withoutStatus), withoutStatus[0]);

  assert.strictEqual(findInsertAnchorCell([]), null);
}

console.log("test-ticket-scanning-channel-items: all tests passed");
