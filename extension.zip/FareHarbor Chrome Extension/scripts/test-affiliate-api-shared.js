#!/usr/bin/env node
"use strict";

const assert = require("assert");
const vm = require("vm");
const fs = require("fs");
const path = require("path");

const sharedPath = path.join(
  __dirname,
  "..",
  "content",
  "affiliate-api-shared.js"
);
const sharedSource = fs.readFileSync(sharedPath, "utf8");

const context = { window: {}, fetch: null };
vm.createContext(context);
vm.runInContext(sharedSource, context);

const api = context.window.FareHarborAffiliateApi;
assert.ok(api, "FareHarborAffiliateApi should be defined");

assert.strictEqual(
  api.parseAffiliateDetailFromResponse({ affiliation: { pk: 1 } })?.pk,
  1
);

assert.strictEqual(
  api.normalizeAffiliateCompanyName("Acme Tours - NYC - API"),
  "acme tours"
);

console.log("affiliate-api-shared: all assertions passed");
