#!/usr/bin/env node
"use strict";

const assert = require("assert");
const vm = require("vm");
const fs = require("fs");
const path = require("path");

const sharedPath = path.join(
  __dirname,
  "..",
  "content",
  "affiliate-api-shared.js"
);
const sharedSource = fs.readFileSync(sharedPath, "utf8");

const context = { window: {}, fetch: null };
vm.createContext(context);
vm.runInContext(sharedSource, context);

const api = context.window.FareHarborAffiliateApi;
assert.ok(api, "FareHarborAffiliateApi should be defined");

assert.strictEqual(
  api.parseAffiliateDetailFromResponse({ affiliation: { pk: 1 } })?.pk,
  1
);

const selection = api.extractAffiliateCancellationPolicySelection({
  cancellation_policy: { name: "Default - API" },
  cancellation_policy_id: 42
});
assert.strictEqual(selection.selectedId, "42");
assert.strictEqual(selection.selectedName, "Default - API");

const listMatch = api.findCancellationPolicyInList(
  [
    { pk: 42, name: "Default - API", uri: "/api/v1/companies/demo/cancellation-policies/42/" },
    { pk: 99, name: "Other", uri: "/api/v1/companies/demo/cancellation-policies/99/" }
  ],
  "42",
  null
);
assert.strictEqual(listMatch?.pk, 42);

assert.strictEqual(
  api.buildCancellationPolicyDashboardUrlFromApiUri(
    "/api/v1/companies/demo/cancellation-policies/42/",
    "demo"
  ),
  "/demo/dashboard/settings/cancellation-policies/42/"
);

assert.strictEqual(
  api.buildCancellationPolicyDashboardUrl(
    "demo",
    "42",
    "/api/v1/companies/demo/cancellation-policies/42/"
  ),
  "/demo/dashboard/settings/cancellation-policies/42/"
);

const withoutPolicy = api.normalizeAffiliationCancellationPolicy({});
assert.strictEqual(withoutPolicy.displayText, null);

console.log("affiliate-api-shared: all assertions passed");
