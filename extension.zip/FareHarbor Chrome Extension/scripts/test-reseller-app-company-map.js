#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const servicePath = path.join(
  __dirname,
  "..",
  "background",
  "reseller-app-company-map.js"
);
const bundledPath = path.join(
  __dirname,
  "..",
  "data",
  "reseller-app-company-map.json"
);
const sharedPath = path.join(
  __dirname,
  "..",
  "content",
  "affiliate-api-shared.js"
);

const serviceSource = fs.readFileSync(servicePath, "utf8");
const serviceContext = { self: {}, globalThis: {}, console, module: { exports: {} } };
vm.createContext(serviceContext);
vm.runInContext(serviceSource, serviceContext);
const { createService, validateResellerAppCompanyMapDocument } =
  serviceContext.module.exports;

const bundledRaw = JSON.parse(fs.readFileSync(bundledPath, "utf8"));

function createDeps(overrides = {}) {
  let now = overrides.now ?? 1_700_000_000_000;
  const storage = { ...(overrides.initialStorage || {}) };
  const fetchCalls = [];
  const storageWrites = [];

  const deps = {
    fetch: async (url, options = {}) => {
      fetchCalls.push({ url, options });
      if (typeof overrides.fetch === "function") {
        return overrides.fetch(url, options, { fetchCalls, storage, now });
      }
      throw new Error(`Unexpected fetch: ${url}`);
    },
    storageGet(keys) {
      if (Array.isArray(keys)) {
        const result = {};
        for (const key of keys) {
          if (Object.prototype.hasOwnProperty.call(storage, key)) {
            result[key] = storage[key];
          }
        }
        return Promise.resolve(result);
      }
      return Promise.resolve({ [keys]: storage[keys] });
    },
    storageSet(items) {
      storageWrites.push(items);
      Object.assign(storage, items);
      return Promise.resolve();
    },
    getBundledUrl(relativePath) {
      return `chrome-extension://test/${relativePath}`;
    },
    now() {
      return now;
    },
    _advance(ms) {
      now += ms;
    },
    _storage: storage,
    _fetchCalls: fetchCalls,
    _storageWrites: storageWrites
  };

  return Object.assign(deps, overrides.deps || {});
}

function validRemoteDocument(mapping = { hotelbedseuro: 49 }) {
  return {
    schemaVersion: 1,
    generatedAt: "2026-07-15T12:00:00.000Z",
    mapping
  };
}

function jsonResponse(payload, status = 200, contentType = "application/json") {
  return {
    ok: status >= 200 && status < 300,
    status,
    headers: {
      get(name) {
        if (name.toLowerCase() === "content-type") {
          return contentType;
        }
        return "";
      }
    },
    async json() {
      return payload;
    }
  };
}

assert.strictEqual(
  validateResellerAppCompanyMapDocument(validRemoteDocument()).mapping.hotelbedseuro,
  49
);

assert.strictEqual(
  validateResellerAppCompanyMapDocument({
    schemaVersion: 1,
    generatedAt: "2026-07-15T12:00:00.000Z",
    mapping: { HotelbedsEuro: 49 }
  }),
  null,
  "uppercase shortnames must be rejected"
);

assert.strictEqual(
  validateResellerAppCompanyMapDocument({
    schemaVersion: 1,
    generatedAt: "2026-07-15T12:00:00.000Z",
    mapping: { hotelbedseuro: "49" }
  }),
  null,
  "non-integer app PK must be rejected"
);

assert.strictEqual(
  validateResellerAppCompanyMapDocument({
    schemaVersion: 1,
    generatedAt: "2026-07-15T12:00:00.000Z",
    mapping: { __proto__: 49 }
  }),
  null,
  "dangerous keys must be rejected"
);

assert.strictEqual(
  validateResellerAppCompanyMapDocument({
    schemaVersion: 2,
    generatedAt: "2026-07-15T12:00:00.000Z",
    mapping: { hotelbedseuro: 49 }
  }),
  null,
  "invalid schema version must be rejected"
);

assert.strictEqual(
  validateResellerAppCompanyMapDocument({
    schemaVersion: 1,
    generatedAt: "2026-07-15T12:00:00.000Z",
    mapping: { "bad shortname": 49 }
  }),
  null,
  "malformed mapping entry must reject the full document"
);

(async () => {
  const remoteDocument = validRemoteDocument();
  const deps = createDeps({
    fetch(url) {
      if (url.includes("raw.githubusercontent.com")) {
        return jsonResponse(remoteDocument);
      }
      if (url.includes("data/reseller-app-company-map.json")) {
        return jsonResponse(bundledRaw);
      }
      throw new Error(`Unexpected fetch: ${url}`);
    }
  });
  const service = createService(deps);

  const first = await service.getResellerAppCompanyMap();
  assert.strictEqual(first.success, true);
  assert.strictEqual(first.metadata.source, "remote");
  assert.strictEqual(first.mapping.hotelbedseuro, 49);
  assert.strictEqual(deps._fetchCalls.length, 1);
  assert.ok(deps._storageWrites.length >= 1);
  assert.deepStrictEqual(
    Object.keys(deps._storageWrites[0].resellerAppCompanyMapCache.document.mapping),
    ["hotelbedseuro"]
  );
  assert.ok(
    !JSON.stringify(deps._storageWrites[0]).match(/"(key|calendar_token|cookie|token)"/),
    "cache must not store credentials"
  );

  const second = await service.getResellerAppCompanyMap();
  assert.strictEqual(second.success, true);
  assert.strictEqual(second.metadata.source, "cache");
  assert.strictEqual(deps._fetchCalls.length, 1, "fresh cache should avoid another fetch");

  deps._advance(25 * 60 * 60 * 1000);
  service.clearMemoryCache();

  const updatedRemote = validRemoteDocument({ hotelbedseuro: 50, tiqqets: 131 });
  deps.fetch = async (url) => {
    if (url.includes("raw.githubusercontent.com")) {
      return jsonResponse(updatedRemote);
    }
    if (url.includes("data/reseller-app-company-map.json")) {
      return jsonResponse(bundledRaw);
    }
    throw new Error(`Unexpected fetch: ${url}`);
  };

  const third = await service.getResellerAppCompanyMap();
  assert.strictEqual(third.success, true);
  assert.strictEqual(third.metadata.source, "remote");
  assert.strictEqual(third.mapping.hotelbedseuro, 50);
  assert.strictEqual(deps._fetchCalls.length, 2);

  service.clearMemoryCache();
  const forced = await service.getResellerAppCompanyMap({ forceRefresh: true });
  assert.strictEqual(forced.success, true);
  assert.strictEqual(forced.metadata.source, "remote");
  assert.strictEqual(deps._fetchCalls.length, 3);

  const offlineDeps = createDeps({
    initialStorage: {
      resellerAppCompanyMapCache: {
        fetchedAt: 1_700_000_000_000,
        sourceUrl: "https://raw.githubusercontent.com/example/map.json",
        document: validRemoteDocument({ hotelbedseuro: 49 })
      }
    },
    fetch(url) {
      if (url.includes("raw.githubusercontent.com")) {
        return Promise.reject(new Error("offline"));
      }
      if (url.includes("data/reseller-app-company-map.json")) {
        return jsonResponse(bundledRaw);
      }
      throw new Error(`Unexpected fetch: ${url}`);
    }
  });
  offlineDeps._advance(25 * 60 * 60 * 1000);
  const offlineService = createService(offlineDeps);
  const offline = await offlineService.getResellerAppCompanyMap();
  assert.strictEqual(offline.success, true);
  assert.strictEqual(offline.metadata.source, "expired_cache");
  assert.strictEqual(offline.mapping.hotelbedseuro, 49);

  const noCacheOfflineDeps = createDeps({
    fetch(url) {
      if (url.includes("raw.githubusercontent.com")) {
        return Promise.reject(new Error("offline"));
      }
      if (url.includes("data/reseller-app-company-map.json")) {
        return jsonResponse(bundledRaw);
      }
      throw new Error(`Unexpected fetch: ${url}`);
    }
  });
  const noCacheOfflineService = createService(noCacheOfflineDeps);
  const bundledOnly = await noCacheOfflineService.getResellerAppCompanyMap();
  assert.strictEqual(bundledOnly.success, true);
  assert.strictEqual(bundledOnly.metadata.source, "bundled");
  assert.strictEqual(bundledOnly.mapping.hotelbedseuro, 49);

  const invalidJsonDeps = createDeps({
    initialStorage: {
      resellerAppCompanyMapCache: {
        fetchedAt: 1_700_000_000_000,
        sourceUrl: "https://raw.githubusercontent.com/example/map.json",
        document: validRemoteDocument({ hotelbedseuro: 49 })
      }
    },
    fetch(url) {
      if (url.includes("raw.githubusercontent.com")) {
        return {
          ok: true,
          status: 200,
          headers: { get: () => "application/json" },
          async json() {
            throw new SyntaxError("Unexpected token");
          }
        };
      }
      if (url.includes("data/reseller-app-company-map.json")) {
        return jsonResponse(bundledRaw);
      }
      throw new Error(`Unexpected fetch: ${url}`);
    }
  });
  invalidJsonDeps._advance(25 * 60 * 60 * 1000);
  const invalidJsonService = createService(invalidJsonDeps);
  const invalidJson = await invalidJsonService.getResellerAppCompanyMap();
  assert.strictEqual(invalidJson.success, true);
  assert.strictEqual(invalidJson.metadata.source, "expired_cache");
  assert.strictEqual(invalidJson.mapping.hotelbedseuro, 49);

  const invalidSchemaDeps = createDeps({
    initialStorage: {
      resellerAppCompanyMapCache: {
        fetchedAt: 1_700_000_000_000,
        sourceUrl: "https://raw.githubusercontent.com/example/map.json",
        document: validRemoteDocument({ hotelbedseuro: 49 })
      }
    },
    fetch(url) {
      if (url.includes("raw.githubusercontent.com")) {
        return jsonResponse({
          schemaVersion: 2,
          generatedAt: "2026-07-15T12:00:00.000Z",
          mapping: { hotelbedseuro: 49 }
        });
      }
      if (url.includes("data/reseller-app-company-map.json")) {
        return jsonResponse(bundledRaw);
      }
      throw new Error(`Unexpected fetch: ${url}`);
    }
  });
  invalidSchemaDeps._advance(25 * 60 * 60 * 1000);
  const invalidSchemaService = createService(invalidSchemaDeps);
  const invalidSchema = await invalidSchemaService.getResellerAppCompanyMap();
  assert.strictEqual(invalidSchema.success, true);
  assert.strictEqual(invalidSchema.metadata.source, "expired_cache");
  assert.strictEqual(invalidSchema.mapping.hotelbedseuro, 49);

  const remoteFetchDeps = createDeps({
    fetch(url, options) {
      if (url.includes("raw.githubusercontent.com")) {
        assert.strictEqual(options.cache, "no-store");
        assert.strictEqual(options.credentials, "omit");
        return jsonResponse(remoteDocument);
      }
      if (url.includes("data/reseller-app-company-map.json")) {
        return jsonResponse(bundledRaw);
      }
      throw new Error(`Unexpected fetch: ${url}`);
    }
  });
  const remoteFetchService = createService(remoteFetchDeps);
  await remoteFetchService.getResellerAppCompanyMap();
  assert.strictEqual(remoteFetchDeps._fetchCalls[0].options.cache, "no-store");
  assert.strictEqual(remoteFetchDeps._fetchCalls[0].options.credentials, "omit");

  const sharedSource = fs.readFileSync(sharedPath, "utf8");
  const sharedContext = {
    window: {},
    chrome: {
      runtime: {
        sendMessage(message, callback) {
          callback({
            success: true,
            document: {
              schemaVersion: 1,
              generatedAt: "2026-07-15T12:00:00.000Z",
              mapping: { hotelbedseuro: 49 },
              duplicates: {},
              inactiveOnly: {},
              failedApps: [],
              stats: {}
            },
            metadata: { source: "remote", generatedAt: "2026-07-15T12:00:00.000Z" }
          });
        },
        lastError: null
      }
    },
    console
  };
  vm.createContext(sharedContext);
  vm.runInContext(sharedSource, sharedContext);
  const api = sharedContext.window.FareHarborAffiliateApi;

  const hotelbedsApps = [
    {
      pk: 49,
      name: "Redeam (Travel Curious)",
      short_name: "",
      key: "redeam-channel-key",
      is_inactive: false
    }
  ];

  const resolved = api.resolveChannelAppFromStaticMapping({
    affiliateShortname: "hotelbedseuro",
    resellerApps: hotelbedsApps,
    database: {
      schemaVersion: 1,
      generatedAt: "2026-07-15T12:00:00.000Z",
      mapping: { hotelbedseuro: 49 },
      duplicates: {},
      inactiveOnly: {},
      failedApps: [],
      stats: {}
    },
    affiliateCompanyName: "Hotelbeds - EUR - API"
  });
  assert.strictEqual(resolved.status, "resolved");
  assert.strictEqual(resolved.appPk, 49);
  assert.strictEqual(resolved.key, "redeam-channel-key");

  const mapLoad = await api.loadResellerAppCompanyMap();
  assert.strictEqual(mapLoad.ok, true);
  assert.strictEqual(mapLoad.database.mapping.hotelbedseuro, 49);

  console.log("reseller-app-company-map: all assertions passed");
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
