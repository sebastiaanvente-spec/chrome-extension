#!/usr/bin/env node
"use strict";

const assert = require("assert");

const CUSTOMER_TYPES_PATH_RE =
  /^\/[^/]+\/dashboard\/items\/[^/]+\/prices\/customer-types\/?$/;
const PROTOTYPE_URI_RE = /\/(?:customer-prototypes|CustomerPrototype)\/(\d+)\//i;

function parseCustomerPrototypePageContext(pathname, hostname) {
  if (!hostname.includes("fareharbor")) {
    return null;
  }
  const normalized = (pathname || "").replace(/\/+$/, "");
  if (!CUSTOMER_TYPES_PATH_RE.test(normalized)) {
    return null;
  }
  const parts = normalized.split("/").filter(Boolean);
  const dashIdx = parts.indexOf("dashboard");
  if (dashIdx < 1 || parts[dashIdx + 1] !== "items" || !parts[dashIdx + 2]) {
    return null;
  }
  return {
    shortname: parts[0],
    itemId: parts[dashIdx + 2]
  };
}

function extractIdsFromString(value, source, candidates) {
  if (!value || typeof value !== "string") return;
  let match;
  const re = new RegExp(PROTOTYPE_URI_RE.source, "gi");
  while ((match = re.exec(value)) !== null) {
    candidates.push({ id: match[1], source });
  }
}

function collectPrototypeIdsFromAttributes(values) {
  const candidates = [];
  for (const { value, source } of values) {
    extractIdsFromString(value, source, candidates);
  }
  const uniqueIds = [...new Set(candidates.map((c) => String(c.id)))];
  if (uniqueIds.length > 1) {
    return { ok: false, ambiguousIds: uniqueIds };
  }
  if (uniqueIds.length === 1) {
    const match = candidates.find((c) => String(c.id) === uniqueIds[0]);
    return { ok: true, prototypeId: uniqueIds[0], source: match.source };
  }
  return { ok: true, prototypeId: null, source: null };
}

function normalizeCustomerTypeName(name) {
  return (name || "").split("\n")[0].trim();
}

function findExactNameMatches(prototypes, displayName) {
  const target = normalizeCustomerTypeName(displayName);
  if (!target) return [];
  return prototypes.filter((prototype) => {
    const names = [prototype?.name, prototype?.display_name]
      .filter(Boolean)
      .map(normalizeCustomerTypeName);
    return names.some((name) => name === target);
  });
}

function classifyMapping(mapping, targetPrototypePk, targetTypePk) {
  const protoPk =
    mapping.customer_prototype?.pk != null
      ? String(mapping.customer_prototype.pk)
      : null;
  const typePk =
    mapping.customer_prototype?.customer_type?.pk != null
      ? String(mapping.customer_prototype.customer_type.pk)
      : null;
  if (protoPk === targetPrototypePk) return "exact";
  if (targetTypePk && typePk === targetTypePk) return "broader";
  return "none";
}

function formatChannelGroupLabelFromResellerCompany(resellerCompany) {
  if (!resellerCompany) return "Channel";

  const name = resellerCompany.name || resellerCompany.unicode || "";
  const channelLabel =
    resellerCompany.short_name ||
    resellerCompany.display_name ||
    resellerCompany.label ||
    "";

  const parts = [];
  if (name) parts.push(name);
  if (channelLabel && channelLabel !== name) parts.push(channelLabel);

  if (parts.length) return parts.join(" · ");

  const otaType = resellerCompany.ota_type || resellerCompany.otaType || "";
  if (otaType) {
    return otaType.charAt(0).toUpperCase() + otaType.slice(1);
  }

  return "Channel";
}

function formatChannelGroupLabel(result) {
  const rc =
    result.resellerCompany ||
    result.reseller_company ||
    result.resellerItem?.reseller_company ||
    null;
  return formatChannelGroupLabelFromResellerCompany(rc);
}

assert.strictEqual(
  formatChannelGroupLabelFromResellerCompany({
    name: "Viator Support Training",
    short_name: "Viator",
    ota_type: "viator"
  }),
  "Viator Support Training · Viator"
);
assert.strictEqual(
  formatChannelGroupLabelFromResellerCompany({
    name: "Viator Support Training",
    ota_type: "viator"
  }),
  "Viator Support Training"
);
assert.strictEqual(formatChannelGroupLabelFromResellerCompany({ ota_type: "viator" }), "Viator");
assert.strictEqual(formatChannelGroupLabelFromResellerCompany({}), "Channel");
assert.strictEqual(
  formatChannelGroupLabel({
    resellerCompany: {
      name: "Viator Support Training",
      short_name: "Viator",
      ota_type: "viator"
    }
  }),
  "Viator Support Training · Viator"
);
assert.strictEqual(
  formatChannelGroupLabel({
    resellerItem: {
      reseller_company: { name: "Viator Support Training", short_name: "Viator" }
    }
  }),
  "Viator Support Training · Viator"
);

// parseCustomerPrototypePageContext
assert.deepStrictEqual(
  parseCustomerPrototypePageContext(
    "/acme/dashboard/items/73204/prices/customer-types/",
    "demo.fareharbor.com"
  ),
  { shortname: "acme", itemId: "73204" }
);
assert.strictEqual(
  parseCustomerPrototypePageContext(
    "/acme/dashboard/items/73204/customer-prototypes/215882/",
    "demo.fareharbor.com"
  ),
  null
);

// ID extraction ambiguity
assert.deepStrictEqual(
  collectPrototypeIdsFromAttributes([
    { value: "/customer-prototypes/215882/", source: "dom-href" },
    { value: "/customer-prototypes/215883/", source: "dom-ng-init" }
  ]),
  { ok: false, ambiguousIds: ["215882", "215883"] }
);
assert.deepStrictEqual(
  collectPrototypeIdsFromAttributes([
    { value: "/CustomerPrototype/215882/", source: "dom-href" }
  ]),
  { ok: true, prototypeId: "215882", source: "dom-href" }
);

// exact name matching only
const prototypes = [
  { pk: 1, name: "Adult", display_name: "Adult 01-01" },
  { pk: 2, name: "Adult", display_name: "Adult 02-02" },
  { pk: 3, name: "Child", display_name: "Child" }
];
assert.strictEqual(findExactNameMatches(prototypes, "Adult").length, 2);
assert.strictEqual(findExactNameMatches(prototypes, "Adult 01-01").length, 1);
assert.strictEqual(findExactNameMatches(prototypes, "Adult\nextra").length, 2);
assert.strictEqual(findExactNameMatches(prototypes, "Senior").length, 0);
assert.strictEqual(findExactNameMatches(prototypes, "Child").length, 1);

// classification
assert.strictEqual(
  classifyMapping(
    { customer_prototype: { pk: 215882, customer_type: { pk: 10 } } },
    "215882",
    "10"
  ),
  "exact"
);
assert.strictEqual(
  classifyMapping(
    { customer_prototype: { pk: 215883, customer_type: { pk: 10 } } },
    "215882",
    "10"
  ),
  "broader"
);
assert.strictEqual(
  classifyMapping(
    { customer_prototype: { pk: 999, customer_type: { pk: 11 } } },
    "215882",
    "10"
  ),
  "none"
);

function formatResellerCustomerTypeName(result) {
  const rct = result.resellerCustomerType || result.reseller_customer_type;
  return rct?.name || rct?.unicode || rct?.short_name || "";
}

function formatResellerItemName(result) {
  const ri = result.resellerItem || result.reseller_item;
  return ri?.name || ri?.unicode || ri?.short_name || "";
}

assert.strictEqual(
  formatResellerCustomerTypeName({ resellerCustomerType: { pk: 3533, name: "Adult" } }),
  "Adult"
);
assert.strictEqual(
  formatResellerItemName({ resellerItem: { pk: 1965, name: "Private option" } }),
  "Private option"
);
assert.strictEqual(
  formatResellerItemName({
    reseller_item: { pk: 1965 },
    resellerItem: { pk: 1965, name: "Private option" }
  }),
  "Private option"
);
assert.strictEqual(formatResellerCustomerTypeName({ resellerCustomerType: { pk: 1 } }), "");
assert.strictEqual(formatResellerItemName({ resellerItem: { pk: 1 } }), "");

function parseCustomerTypeHeader(text) {
  const normalized = (text || "").replace(/\s+/g, " ");
  const pkMatch = normalized.match(/Customer type:\s*.+?\(#(\d+)\)/i);
  const nameMatch = normalized.match(/Customer type:\s*(.+?)\s*\(#\d+\)/i);
  return {
    customerTypeName: nameMatch ? nameMatch[1].trim() : "",
    customerTypePk: pkMatch ? String(pkMatch[1]) : null
  };
}

function getPrototypeCustomerTypePk(prototype) {
  const customerType = prototype?.customer_type ?? prototype?.customerType ?? {};
  return customerType?.pk != null ? String(customerType.pk) : null;
}

function matchByCustomerTypePkHeader(prototypes, customerTypePk) {
  const typeMatches = prototypes.filter(
    (prototype) => getPrototypeCustomerTypePk(prototype) === String(customerTypePk)
  );
  if (typeMatches.length === 1) return { ok: true, match: typeMatches[0] };
  const visible = typeMatches.filter((p) => p.is_archived !== true && p.is_hidden !== true);
  if (visible.length === 1) return { ok: true, match: visible[0] };
  if (typeMatches.length > 1) return { ok: false, ambiguous: true, matches: visible.length ? visible : typeMatches };
  return null;
}

assert.deepStrictEqual(
  parseCustomerTypeHeader("Customer type: Adult (#1194554)"),
  { customerTypeName: "Adult", customerTypePk: "1194554" }
);

const adultPrototypes = [
  { pk: 1, name: "A", customer_type: { pk: 1194554 }, is_archived: true, is_hidden: false },
  { pk: 2, name: "B", customer_type: { pk: 1194554 }, is_archived: false, is_hidden: false },
  { pk: 3, name: "C", customer_type: { pk: 999 }, is_archived: false, is_hidden: false }
];
assert.strictEqual(matchByCustomerTypePkHeader(adultPrototypes, "1194554").ok, true);
assert.strictEqual(matchByCustomerTypePkHeader(adultPrototypes, "1194554").match.pk, 2);

console.log("test-customer-type-mapping-finder: all tests passed");
