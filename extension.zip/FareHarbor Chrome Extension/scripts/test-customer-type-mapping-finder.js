#!/usr/bin/env node
"use strict";

const assert = require("assert");

const CUSTOMER_TYPES_PATH_RE =
  /^\/[^/]+\/dashboard\/items\/[^/]+\/prices\/customer-types\/?$/;
const PROTOTYPE_URI_RE = /\/(?:customer-prototypes|CustomerPrototype)\/(\d+)\//i;

function parseCustomerPrototypePageContext(pathname, hostname) {
  if (!hostname.includes("fareharbor")) {
    return null;
  }
  const normalized = (pathname || "").replace(/\/+$/, "");
  if (!CUSTOMER_TYPES_PATH_RE.test(normalized)) {
    return null;
  }
  const parts = normalized.split("/").filter(Boolean);
  const dashIdx = parts.indexOf("dashboard");
  if (dashIdx < 1 || parts[dashIdx + 1] !== "items" || !parts[dashIdx + 2]) {
    return null;
  }
  return {
    shortname: parts[0],
    itemId: parts[dashIdx + 2]
  };
}

function extractIdsFromString(value, source, candidates) {
  if (!value || typeof value !== "string") return;
  let match;
  const re = new RegExp(PROTOTYPE_URI_RE.source, "gi");
  while ((match = re.exec(value)) !== null) {
    candidates.push({ id: match[1], source });
  }
}

function collectPrototypeIdsFromAttributes(values) {
  const candidates = [];
  for (const { value, source } of values) {
    extractIdsFromString(value, source, candidates);
  }
  const uniqueIds = [...new Set(candidates.map((c) => String(c.id)))];
  if (uniqueIds.length > 1) {
    return { ok: false, ambiguousIds: uniqueIds };
  }
  if (uniqueIds.length === 1) {
    const match = candidates.find((c) => String(c.id) === uniqueIds[0]);
    return { ok: true, prototypeId: uniqueIds[0], source: match.source };
  }
  return { ok: true, prototypeId: null, source: null };
}

function normalizeCustomerTypeName(name) {
  return (name || "").split("\n")[0].trim();
}

function findExactNameMatches(prototypes, displayName) {
  const target = normalizeCustomerTypeName(displayName);
  if (!target) return [];
  return prototypes.filter((prototype) => {
    const names = [prototype?.name, prototype?.display_name]
      .filter(Boolean)
      .map(normalizeCustomerTypeName);
    return names.some((name) => name === target);
  });
}

function classifyMapping(mapping, targetPrototypePk, targetTypePk) {
  const protoPk =
    mapping.customer_prototype?.pk != null
      ? String(mapping.customer_prototype.pk)
      : null;
  const typePk =
    mapping.customer_prototype?.customer_type?.pk != null
      ? String(mapping.customer_prototype.customer_type.pk)
      : null;
  if (protoPk === targetPrototypePk) return "exact";
  if (targetTypePk && typePk === targetTypePk) return "broader";
  return "none";
}

function formatChannelGroupLabelFromResellerCompany(resellerCompany) {
  if (!resellerCompany) return "Channel";

  const name = resellerCompany.name || resellerCompany.unicode || "";
  const channelLabel =
    resellerCompany.short_name ||
    resellerCompany.display_name ||
    resellerCompany.label ||
    "";

  const parts = [];
  if (name) parts.push(name);
  if (channelLabel && channelLabel !== name) parts.push(channelLabel);

  if (parts.length) return parts.join(" · ");

  const otaType = resellerCompany.ota_type || resellerCompany.otaType || "";
  if (otaType) {
    return otaType.charAt(0).toUpperCase() + otaType.slice(1);
  }

  return "Channel";
}

function formatChannelGroupLabel(result) {
  const rc =
    result.resellerCompany ||
    result.reseller_company ||
    result.resellerItem?.reseller_company ||
    null;
  return formatChannelGroupLabelFromResellerCompany(rc);
}

assert.strictEqual(
  formatChannelGroupLabelFromResellerCompany({
    name: "Viator Support Training",
    short_name: "Viator",
    ota_type: "viator"
  }),
  "Viator Support Training · Viator"
);
assert.strictEqual(
  formatChannelGroupLabelFromResellerCompany({
    name: "Viator Support Training",
    ota_type: "viator"
  }),
  "Viator Support Training"
);
assert.strictEqual(formatChannelGroupLabelFromResellerCompany({ ota_type: "viator" }), "Viator");
assert.strictEqual(formatChannelGroupLabelFromResellerCompany({}), "Channel");
assert.strictEqual(
  formatChannelGroupLabel({
    resellerCompany: {
      name: "Viator Support Training",
      short_name: "Viator",
      ota_type: "viator"
    }
  }),
  "Viator Support Training · Viator"
);
assert.strictEqual(
  formatChannelGroupLabel({
    resellerItem: {
      reseller_company: { name: "Viator Support Training", short_name: "Viator" }
    }
  }),
  "Viator Support Training · Viator"
);

// parseCustomerPrototypePageContext
assert.deepStrictEqual(
  parseCustomerPrototypePageContext(
    "/acme/dashboard/items/73204/prices/customer-types/",
    "demo.fareharbor.com"
  ),
  { shortname: "acme", itemId: "73204" }
);
assert.strictEqual(
  parseCustomerPrototypePageContext(
    "/acme/dashboard/items/73204/customer-prototypes/215882/",
    "demo.fareharbor.com"
  ),
  null
);

// ID extraction ambiguity
assert.deepStrictEqual(
  collectPrototypeIdsFromAttributes([
    { value: "/customer-prototypes/215882/", source: "dom-href" },
    { value: "/customer-prototypes/215883/", source: "dom-ng-init" }
  ]),
  { ok: false, ambiguousIds: ["215882", "215883"] }
);
assert.deepStrictEqual(
  collectPrototypeIdsFromAttributes([
    { value: "/CustomerPrototype/215882/", source: "dom-href" }
  ]),
  { ok: true, prototypeId: "215882", source: "dom-href" }
);

// exact name matching only
const prototypes = [
  { pk: 1, name: "Adult", display_name: "Adult 01-01" },
  { pk: 2, name: "Adult", display_name: "Adult 02-02" },
  { pk: 3, name: "Child", display_name: "Child" }
];
assert.strictEqual(findExactNameMatches(prototypes, "Adult").length, 2);
assert.strictEqual(findExactNameMatches(prototypes, "Adult 01-01").length, 1);
assert.strictEqual(findExactNameMatches(prototypes, "Adult\nextra").length, 2);
assert.strictEqual(findExactNameMatches(prototypes, "Senior").length, 0);
assert.strictEqual(findExactNameMatches(prototypes, "Child").length, 1);

// classification
assert.strictEqual(
  classifyMapping(
    { customer_prototype: { pk: 215882, customer_type: { pk: 10 } } },
    "215882",
    "10"
  ),
  "exact"
);
assert.strictEqual(
  classifyMapping(
    { customer_prototype: { pk: 215883, customer_type: { pk: 10 } } },
    "215882",
    "10"
  ),
  "broader"
);
assert.strictEqual(
  classifyMapping(
    { customer_prototype: { pk: 999, customer_type: { pk: 11 } } },
    "215882",
    "10"
  ),
  "none"
);

function formatResellerCustomerTypeName(result) {
  const rct = result.resellerCustomerType || result.reseller_customer_type;
  return rct?.name || rct?.unicode || rct?.short_name || "";
}

function formatResellerItemName(result) {
  const ri = result.resellerItem || result.reseller_item;
  return ri?.name || ri?.unicode || ri?.short_name || "";
}

assert.strictEqual(
  formatResellerCustomerTypeName({ resellerCustomerType: { pk: 3533, name: "Adult" } }),
  "Adult"
);
assert.strictEqual(
  formatResellerItemName({ resellerItem: { pk: 1965, name: "Private option" } }),
  "Private option"
);
assert.strictEqual(
  formatResellerItemName({
    reseller_item: { pk: 1965 },
    resellerItem: { pk: 1965, name: "Private option" }
  }),
  "Private option"
);
assert.strictEqual(formatResellerCustomerTypeName({ resellerCustomerType: { pk: 1 } }), "");
assert.strictEqual(formatResellerItemName({ resellerItem: { pk: 1 } }), "");

function parseCustomerTypeHeader(text) {
  const normalized = (text || "").replace(/\s+/g, " ");
  const pkMatch = normalized.match(/Customer type:\s*.+?\(#(\d+)\)/i);
  const nameMatch = normalized.match(/Customer type:\s*(.+?)\s*\(#\d+\)/i);
  return {
    customerTypeName: nameMatch ? nameMatch[1].trim() : "",
    customerTypePk: pkMatch ? String(pkMatch[1]) : null
  };
}

function matchByCustomerTypePkHeader(prototypes, customerTypePk) {
  const typeMatches = prototypes.filter(
    (prototype) => getPrototypeCustomerTypePk(prototype) === String(customerTypePk)
  );
  if (typeMatches.length === 1) return { ok: true, match: typeMatches[0] };
  const visible = typeMatches.filter((p) => p.is_archived !== true && p.is_hidden !== true);
  if (visible.length === 1) return { ok: true, match: visible[0] };
  if (typeMatches.length > 1) return { ok: false, ambiguous: true, matches: visible.length ? visible : typeMatches };
  return null;
}

assert.deepStrictEqual(
  parseCustomerTypeHeader("Customer type: Adult (#1194554)"),
  { customerTypeName: "Adult", customerTypePk: "1194554" }
);

const adultPrototypes = [
  { pk: 1, name: "A", customer_type: { pk: 1194554 }, is_archived: true, is_hidden: false },
  { pk: 2, name: "B", customer_type: { pk: 1194554 }, is_archived: false, is_hidden: false },
  { pk: 3, name: "C", customer_type: { pk: 999 }, is_archived: false, is_hidden: false }
];
assert.strictEqual(matchByCustomerTypePkHeader(adultPrototypes, "1194554").ok, true);
assert.strictEqual(matchByCustomerTypePkHeader(adultPrototypes, "1194554").match.pk, 2);

const MASTER_CUSTOMER_TYPES_PATH_RE =
  /^\/[^/]+\/dashboard\/settings\/customer-types\/?$/;
const MASTER_CUSTOMER_TYPE_PK_RE =
  /\/dashboard\/settings\/customer-types\/(\d+)\/?/;

function parseMasterCustomerTypesPageContext(pathname, hostname) {
  if (!hostname.includes("fareharbor")) {
    return null;
  }
  const normalized = (pathname || "").replace(/\/+$/, "");
  if (!MASTER_CUSTOMER_TYPES_PATH_RE.test(normalized)) {
    return null;
  }
  const parts = normalized.split("/").filter(Boolean);
  if (!parts[0]) {
    return null;
  }
  return { shortname: parts[0] };
}

function extractCustomerTypePkFromHref(href) {
  if (!href || typeof href !== "string") {
    return null;
  }
  const match = href.match(MASTER_CUSTOMER_TYPE_PK_RE);
  return match ? String(match[1]) : null;
}

function extractCustomerTypePkFromTbodyLinks(hrefs) {
  const pks = [];
  for (const href of hrefs) {
    const pk = extractCustomerTypePkFromHref(href);
    if (pk) pks.push(pk);
  }
  const unique = [...new Set(pks)];
  return unique.length === 1 ? unique[0] : null;
}

function getPrototypeCustomerTypePk(prototype) {
  const customerType = prototype?.customer_type ?? prototype?.customerType ?? null;

  if (customerType != null && typeof customerType === "object") {
    if (customerType.pk != null) {
      return String(customerType.pk);
    }
    const uri = customerType.uri || customerType.url || "";
    const uriMatch = String(uri).match(/\/customer-types\/(\d+)\/?/i);
    if (uriMatch) {
      return String(uriMatch[1]);
    }
  }

  if (typeof customerType === "number" || typeof customerType === "string") {
    const asString = String(customerType);
    if (/^\d+$/.test(asString)) {
      return asString;
    }
    const uriMatch = asString.match(/\/customer-types\/(\d+)\/?/i);
    if (uriMatch) {
      return String(uriMatch[1]);
    }
  }

  const flatId =
    prototype?.customer_type_id ??
    prototype?.customerTypeId ??
    prototype?.customer_type_pk ??
    prototype?.customerTypePk ??
    null;
  return flatId != null ? String(flatId) : null;
}

function filterPrototypesByCustomerTypePk(prototypes, targetCustomerTypePk) {
  if (targetCustomerTypePk == null || targetCustomerTypePk === "") {
    return [];
  }
  const targetPk = String(targetCustomerTypePk);
  return (prototypes || []).filter(
    (prototype) => getPrototypeCustomerTypePk(prototype) === targetPk
  );
}

function classifyMappingAgainstPrototypeSet(mapping, targetPrototypePks) {
  const protoPk =
    mapping.customer_prototype?.pk != null
      ? String(mapping.customer_prototype.pk)
      : mapping.customerPrototypePk != null
        ? String(mapping.customerPrototypePk)
        : null;
  if (!protoPk) return "none";
  return targetPrototypePks.has(protoPk) ? "exact" : "none";
}

function dedupeMappingsByPk(mappings) {
  const seen = new Set();
  const result = [];
  for (const mapping of mappings || []) {
    const key =
      mapping?.mappingPk != null
        ? `pk:${mapping.mappingPk}`
        : [
            mapping?.resellerCompanyPk,
            mapping?.resellerItemPk,
            mapping?.resellerCustomerTypePk,
            mapping?.customerPrototypePk
          ].join(":");
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(mapping);
  }
  return result;
}

function aggregateDependencyTree({ items, prototypesByItemPk, mappings }) {
  const mappingsByPrototypePk = new Map();
  for (const mapping of mappings || []) {
    const protoPk = mapping?.customerPrototypePk;
    if (!protoPk) continue;
    if (!mappingsByPrototypePk.has(protoPk)) {
      mappingsByPrototypePk.set(protoPk, []);
    }
    mappingsByPrototypePk.get(protoPk).push(mapping);
  }

  const itemNodes = (items || []).map((item) => {
    const itemPk = item?.pk != null ? String(item.pk) : null;
    const prototypes = prototypesByItemPk?.[itemPk] || [];
    return {
      item,
      itemPk,
      itemName: item?.name || (itemPk ? `Item ${itemPk}` : "Item"),
      prototypes: prototypes.map((prototype) => {
        const prototypePk = prototype?.pk != null ? String(prototype.pk) : null;
        const localMappings = prototypePk
          ? mappingsByPrototypePk.get(prototypePk) || []
          : [];
        return {
          prototype,
          prototypePk,
          displayName:
            prototype?.display_name ||
            prototype?.name ||
            (prototypePk ? `Prototype ${prototypePk}` : "Prototype"),
          isInactive: prototype?.is_inactive === true,
          mappings: localMappings,
          localMappingCount: localMappings.length,
          reportedMappingCount: getReportedMappingCountFromPrototype(prototype)
        };
      })
    };
  });

  return {
    items: itemNodes,
    itemCount: itemNodes.length,
    prototypeCount: itemNodes.reduce((sum, node) => sum + node.prototypes.length, 0),
    mappingCount: (mappings || []).length
  };
}

function buildMasterScanSummary({ tree, incomplete, failures }) {
  return {
    usedByItemsLabel: `Used by ${tree.itemCount} item${tree.itemCount === 1 ? "" : "s"}`,
    prototypeLabel: `${tree.prototypeCount} Customer Type Duplicate${tree.prototypeCount === 1 ? "" : "s"} found`,
    mappingLabel:
      tree.mappingCount > 0
        ? `${tree.mappingCount} channel mapping${tree.mappingCount === 1 ? "" : "s"} found`
        : tree.prototypeCount > 0
          ? "No channel mappings found for these prototypes"
          : null,
    incomplete: !!incomplete || (failures && failures.length > 0),
    noneFoundIsValid: tree.itemCount === 0 && !(failures && failures.length)
  };
}

// master list route parsing
assert.deepStrictEqual(
  parseMasterCustomerTypesPageContext(
    "/sebastiaanconnectivitytests/dashboard/settings/customer-types/",
    "demo.fareharbor.com"
  ),
  { shortname: "sebastiaanconnectivitytests" }
);
assert.strictEqual(
  parseMasterCustomerTypesPageContext(
    "/sebastiaanconnectivitytests/dashboard/settings/customer-types/142514/",
    "demo.fareharbor.com"
  ),
  null
);
assert.strictEqual(
  parseCustomerPrototypePageContext(
    "/sebastiaanconnectivitytests/dashboard/settings/customer-types/",
    "demo.fareharbor.com"
  ),
  null
);

// CT PK extraction; same-name rows distinct by PK
assert.strictEqual(
  extractCustomerTypePkFromHref(
    "/sebastiaanconnectivitytests/dashboard/settings/customer-types/142514/"
  ),
  "142514"
);
assert.strictEqual(
  extractCustomerTypePkFromTbodyLinks([
    "/sebastiaanconnectivitytests/dashboard/settings/customer-types/124247/",
    "/sebastiaanconnectivitytests/dashboard/settings/customer-types/124247/"
  ]),
  "124247"
);
assert.notStrictEqual(
  extractCustomerTypePkFromHref(
    "/sebastiaanconnectivitytests/dashboard/settings/customer-types/124247/"
  ),
  extractCustomerTypePkFromHref(
    "/sebastiaanconnectivitytests/dashboard/settings/customer-types/142514/"
  )
);
assert.strictEqual(
  extractCustomerTypePkFromTbodyLinks([
    "/sebastiaanconnectivitytests/dashboard/settings/customer-types/124247/",
    "/sebastiaanconnectivitytests/dashboard/settings/customer-types/142514/"
  ]),
  null
);

// item_count === 0 / empty items tree
const emptyTree = aggregateDependencyTree({
  items: [],
  prototypesByItemPk: {},
  mappings: []
});
assert.strictEqual(emptyTree.itemCount, 0);
assert.strictEqual(emptyTree.prototypeCount, 0);
assert.strictEqual(emptyTree.mappingCount, 0);
assert.deepStrictEqual(
  buildMasterScanSummary({ tree: emptyTree, incomplete: false, failures: [] }),
  {
    usedByItemsLabel: "Used by 0 items",
    prototypeLabel: "0 Customer Type Duplicates found",
    mappingLabel: null,
    incomplete: false,
    noneFoundIsValid: true
  }
);

// prototype filter by customer_type.pk; inactive retained; multi-proto per item
const mixedPrototypes = [
  { pk: 1, name: "Adult API 01", customer_type: { pk: 142514 }, is_inactive: true },
  { pk: 2, name: "Adult API 02", customer_type: { pk: 142514 }, is_inactive: false },
  { pk: 3, name: "Other", customer_type: { pk: 999 }, is_inactive: false },
  { pk: 4, name: "Adult API 03", customer_type_id: 142514, is_inactive: false },
  {
    pk: 5,
    name: "Adult API 04",
    customer_type: { uri: "/customer-types/142514/" },
    is_inactive: true
  }
];
const filtered = filterPrototypesByCustomerTypePk(mixedPrototypes, "142514");
assert.strictEqual(filtered.length, 4);
assert.deepStrictEqual(
  filtered.map((p) => p.pk),
  [1, 2, 4, 5]
);
assert.strictEqual(filtered[0].is_inactive, true);
assert.strictEqual(filtered[1].pk, 2);

// related item with zero matching prototypes still present in tree
const treeWithEmptyItem = aggregateDependencyTree({
  items: [{ pk: 73204, name: "Flavors of Wine" }],
  prototypesByItemPk: { "73204": [] },
  mappings: []
});
assert.strictEqual(treeWithEmptyItem.itemCount, 1);
assert.strictEqual(treeWithEmptyItem.items[0].prototypes.length, 0);
assert.strictEqual(treeWithEmptyItem.prototypeCount, 0);

// set-based mapping classification
const targetPrototypePks = new Set(["215882", "215883", "215884"]);
assert.strictEqual(
  classifyMappingAgainstPrototypeSet(
    { customer_prototype: { pk: 215882 } },
    targetPrototypePks
  ),
  "exact"
);
assert.strictEqual(
  classifyMappingAgainstPrototypeSet(
    { customer_prototype: { pk: 215884 } },
    targetPrototypePks
  ),
  "exact"
);
assert.strictEqual(
  classifyMappingAgainstPrototypeSet(
    { customer_prototype: { pk: 999 } },
    targetPrototypePks
  ),
  "none"
);

// mapping dedupe by PK (not name)
const deduped = dedupeMappingsByPk([
  {
    mappingPk: 10,
    customerPrototypePk: "215882",
    resellerCustomerType: { name: "Adult" }
  },
  {
    mappingPk: 10,
    customerPrototypePk: "215882",
    resellerCustomerType: { name: "Adult" }
  },
  {
    mappingPk: 11,
    customerPrototypePk: "215883",
    resellerCustomerType: { name: "Adult" }
  },
  {
    mappingPk: 12,
    customerPrototypePk: "215884",
    resellerCustomerType: { name: "Adult" }
  }
]);
assert.strictEqual(deduped.length, 3);

// item with multiple matching prototypes must keep ALL of them in the hierarchy
const threeMatchingProtos = [
  { pk: 215882, name: "A", display_name: "Adult API 01", customer_type: { pk: 142514 }, is_inactive: true },
  { pk: 215883, name: "B", display_name: "Adult API 02", customer_type: { pk: 142514 }, is_inactive: false },
  { pk: 215884, name: "C", display_name: "Adult API 03", customer_type: { pk: 142514 }, is_inactive: false },
  { pk: 999001, name: "D", display_name: "Child", customer_type: { pk: 999 }, is_inactive: false }
];
const filteredThree = filterPrototypesByCustomerTypePk(threeMatchingProtos, "142514");
assert.strictEqual(filteredThree.length, 3);
assert.deepStrictEqual(
  filteredThree.map((p) => String(p.pk)),
  ["215882", "215883", "215884"]
);

const multiProtoTree = aggregateDependencyTree({
  items: [{ pk: 73204, name: "Flavors of Wine" }],
  prototypesByItemPk: {
    "73204": filteredThree
  },
  mappings: deduped.map((m) => ({
    ...m,
    customerPrototypePk: String(m.customerPrototypePk)
  }))
});
assert.strictEqual(multiProtoTree.prototypeCount, 3);
assert.strictEqual(multiProtoTree.items[0].prototypes.length, 3);
assert.deepStrictEqual(
  multiProtoTree.items[0].prototypes.map((node) => node.prototypePk),
  ["215882", "215883", "215884"]
);
assert.strictEqual(multiProtoTree.items[0].prototypes[0].isInactive, true);
assert.strictEqual(multiProtoTree.items[0].prototypes[0].mappings.length, 1);
assert.strictEqual(multiProtoTree.items[0].prototypes[1].mappings.length, 1);
assert.strictEqual(multiProtoTree.items[0].prototypes[2].mappings.length, 1);
assert.strictEqual(multiProtoTree.mappingCount, 3);

// every matching prototype pk must remain in the mapping target set
const builtTargetSet = new Set(
  filteredThree.map((prototype) => String(prototype.pk))
);
assert.strictEqual(builtTargetSet.size, 3);
assert.strictEqual(builtTargetSet.has("215882"), true);
assert.strictEqual(builtTargetSet.has("215883"), true);
assert.strictEqual(builtTargetSet.has("215884"), true);
assert.strictEqual(builtTargetSet.has("999001"), false);

// partial failure must not look like a clean "none found"
const incompleteSummary = buildMasterScanSummary({
  tree: emptyTree,
  incomplete: true,
  failures: [{ url: "/api/v1/companies/acme/customer-types/1/items/", error: "500" }]
});
assert.strictEqual(incompleteSummary.incomplete, true);
assert.strictEqual(incompleteSummary.noneFoundIsValid, false);

// existing item-level exact/broader classification unchanged
assert.strictEqual(
  classifyMapping(
    { customer_prototype: { pk: 215882, customer_type: { pk: 10 } } },
    "215882",
    "10"
  ),
  "exact"
);
assert.strictEqual(
  classifyMapping(
    { customer_prototype: { pk: 215883, customer_type: { pk: 10 } } },
    "215882",
    "10"
  ),
  "broader"
);
assert.strictEqual(
  classifyMapping(
    { customer_prototype: { pk: 999, customer_type: { pk: 11 } } },
    "215882",
    "10"
  ),
  "none"
);

function getReportedMappingCount(target) {
  const value =
    target?.customerPrototype?.reseller_customer_type_mapping_count ??
    target?.customerPrototype?.resellerCustomerTypeMappingCount ??
    target?.mappingCount;
  if (value == null || value === "") {
    return null;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function getReportedMappingCountFromPrototype(prototype) {
  const value =
    prototype?.reseller_customer_type_mapping_count ??
    prototype?.resellerCustomerTypeMappingCount ??
    prototype?.mappingCount ??
    null;
  if (value == null || value === "") {
    return null;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function buildMappingCountComparison(target, exactFound) {
  const reported = getReportedMappingCount(target);
  if (reported == null) {
    return null;
  }
  const found = exactFound ?? 0;
  const missing = Math.max(0, reported - found);
  return { reported, found, missing };
}

function buildMasterMappingCountComparison({ tree, incomplete } = {}) {
  const perPrototype = [];
  let totalMissing = 0;
  let reportedPrototypeCount = 0;

  for (const itemNode of tree?.items || []) {
    for (const prototypeNode of itemNode.prototypes || []) {
      const reported =
        prototypeNode.reportedMappingCount != null
          ? Number(prototypeNode.reportedMappingCount)
          : getReportedMappingCountFromPrototype(prototypeNode.prototype);
      const found =
        prototypeNode.localMappingCount != null
          ? Number(prototypeNode.localMappingCount)
          : Array.isArray(prototypeNode.mappings)
            ? prototypeNode.mappings.length
            : 0;
      const safeReported = Number.isFinite(reported) ? reported : null;
      const safeFound = Number.isFinite(found) ? found : 0;
      let missing = null;
      if (safeReported != null) {
        reportedPrototypeCount += 1;
        missing = Math.max(0, safeReported - safeFound);
        totalMissing += missing;
      }
      perPrototype.push({
        prototypePk: prototypeNode.prototypePk || null,
        reported: safeReported,
        found: safeFound,
        missing
      });
    }
  }

  const scanIncomplete = !!incomplete;
  return {
    perPrototype,
    totalMissing,
    reportedPrototypeCount,
    incomplete: scanIncomplete,
    authoritative: !scanIncomplete && totalMissing > 0,
    missing: !scanIncomplete && totalMissing > 0 ? totalMissing : 0
  };
}

function formatCrossDashboardMappingWarning(missing) {
  if (!missing || missing <= 0) {
    return "";
  }
  if (missing === 1) {
    return "⚠ 1 additional channel mapping exists in another dashboard and is not shown here.";
  }
  return `⚠ ${missing} additional channel mappings exist in another dashboard and are not shown here.`;
}

// item-level mapping-count comparison unchanged
assert.deepStrictEqual(
  buildMappingCountComparison(
    { customerPrototype: { reseller_customer_type_mapping_count: 3 } },
    3
  ),
  { reported: 3, found: 3, missing: 0 }
);
assert.deepStrictEqual(
  buildMappingCountComparison(
    { customerPrototype: { reseller_customer_type_mapping_count: 3 } },
    2
  ),
  { reported: 3, found: 2, missing: 1 }
);
assert.strictEqual(
  buildMappingCountComparison({ customerPrototype: {} }, 0),
  null
);
assert.strictEqual(formatCrossDashboardMappingWarning(1).includes("1 additional"), true);
assert.strictEqual(formatCrossDashboardMappingWarning(2).includes("2 additional"), true);
assert.strictEqual(formatCrossDashboardMappingWarning(0), "");

// master: one prototype reported 3 / local 3 → no warning
const matchTree = aggregateDependencyTree({
  items: [{ pk: 1, name: "Item" }],
  prototypesByItemPk: {
    "1": [{ pk: 101, reseller_customer_type_mapping_count: 3, customer_type: { pk: 10 } }]
  },
  mappings: [
    { mappingPk: 1, customerPrototypePk: "101" },
    { mappingPk: 2, customerPrototypePk: "101" },
    { mappingPk: 3, customerPrototypePk: "101" }
  ]
});
const matchComparison = buildMasterMappingCountComparison({
  tree: matchTree,
  incomplete: false
});
assert.strictEqual(matchComparison.totalMissing, 0);
assert.strictEqual(matchComparison.authoritative, false);
assert.strictEqual(matchComparison.missing, 0);

// master: one prototype reported 3 / local 2 → missing 1
const missingOneTree = aggregateDependencyTree({
  items: [{ pk: 1, name: "Item" }],
  prototypesByItemPk: {
    "1": [{ pk: 101, reseller_customer_type_mapping_count: 3, customer_type: { pk: 10 } }]
  },
  mappings: [
    { mappingPk: 1, customerPrototypePk: "101" },
    { mappingPk: 2, customerPrototypePk: "101" }
  ]
});
const missingOneComparison = buildMasterMappingCountComparison({
  tree: missingOneTree,
  incomplete: false
});
assert.strictEqual(missingOneComparison.totalMissing, 1);
assert.strictEqual(missingOneComparison.authoritative, true);
assert.strictEqual(missingOneComparison.missing, 1);
assert.strictEqual(missingOneComparison.perPrototype[0].found, 2);
assert.strictEqual(missingOneComparison.perPrototype[0].reported, 3);

// master: multiple prototypes aggregate missing correctly
const multiMissingTree = aggregateDependencyTree({
  items: [
    { pk: 1, name: "Item A" },
    { pk: 2, name: "Item B" }
  ],
  prototypesByItemPk: {
    "1": [
      { pk: 101, reseller_customer_type_mapping_count: 3, customer_type: { pk: 10 } },
      { pk: 102, reseller_customer_type_mapping_count: 0, customer_type: { pk: 10 } }
    ],
    "2": [{ pk: 201, reseller_customer_type_mapping_count: 4, customer_type: { pk: 10 } }]
  },
  mappings: [
    { mappingPk: 1, customerPrototypePk: "101" },
    { mappingPk: 2, customerPrototypePk: "101" },
    { mappingPk: 3, customerPrototypePk: "201" },
    { mappingPk: 4, customerPrototypePk: "201" },
    { mappingPk: 5, customerPrototypePk: "201" },
    { mappingPk: 6, customerPrototypePk: "201" }
  ]
});
const multiMissingComparison = buildMasterMappingCountComparison({
  tree: multiMissingTree,
  incomplete: false
});
// proto 101: 3-2=1, proto 102: 0-0=0, proto 201: 4-4=0 → totalMissing 1
assert.strictEqual(multiMissingComparison.totalMissing, 1);
assert.strictEqual(multiMissingComparison.authoritative, true);
assert.strictEqual(multiMissingComparison.perPrototype.length, 3);

// prototype with no reported mapping count → no false missing
const noReportedTree = aggregateDependencyTree({
  items: [{ pk: 1, name: "Item" }],
  prototypesByItemPk: {
    "1": [{ pk: 101, customer_type: { pk: 10 } }]
  },
  mappings: []
});
const noReportedComparison = buildMasterMappingCountComparison({
  tree: noReportedTree,
  incomplete: false
});
assert.strictEqual(noReportedComparison.totalMissing, 0);
assert.strictEqual(noReportedComparison.authoritative, false);
assert.strictEqual(noReportedComparison.perPrototype[0].reported, null);
assert.strictEqual(noReportedComparison.perPrototype[0].missing, null);

// incomplete scan → no authoritative missing count even when totals disagree
const incompleteComparison = buildMasterMappingCountComparison({
  tree: missingOneTree,
  incomplete: true
});
assert.strictEqual(incompleteComparison.totalMissing, 1);
assert.strictEqual(incompleteComparison.authoritative, false);
assert.strictEqual(incompleteComparison.missing, 0);

function getMappingDestinationKey(mapping) {
  const companyPk = mapping?.resellerCompanyPk;
  const itemPk = mapping?.resellerItemPk;
  const typePk = mapping?.resellerCustomerTypePk;
  if (companyPk == null || itemPk == null || typePk == null) {
    return null;
  }
  return `${String(companyPk)}|${String(itemPk)}|${String(typePk)}`;
}

function buildItemMappingDestinationGroups(itemNode) {
  const destinationMap = new Map();
  const unmappedPrototypes = [];

  for (const prototypeNode of itemNode?.prototypes || []) {
    const mappings = prototypeNode?.mappings || [];
    if (!mappings.length) {
      unmappedPrototypes.push(prototypeNode);
      continue;
    }

    const seenKeys = new Set();
    for (const mapping of mappings) {
      const key = getMappingDestinationKey(mapping);
      if (!key || seenKeys.has(key)) continue;
      seenKeys.add(key);
      if (!destinationMap.has(key)) {
        destinationMap.set(key, {
          key,
          representative: mapping,
          prototypesByPk: new Map()
        });
      }
      const group = destinationMap.get(key);
      const prototypePk = prototypeNode.prototypePk;
      if (prototypePk && !group.prototypesByPk.has(prototypePk)) {
        group.prototypesByPk.set(prototypePk, prototypeNode);
      }
    }
  }

  return {
    destinations: [...destinationMap.values()].map((group) => ({
      key: group.key,
      representative: group.representative,
      openMappingUrl: group.representative?.openMappingUrl || "",
      prototypes: [...group.prototypesByPk.values()]
    })),
    unmappedPrototypes
  };
}

function countDistinctMappingDestinations(tree) {
  const keys = new Set();
  for (const itemNode of tree?.items || []) {
    for (const prototypeNode of itemNode.prototypes || []) {
      for (const mapping of prototypeNode.mappings || []) {
        const key = getMappingDestinationKey(mapping);
        if (key) keys.add(key);
      }
    }
  }
  return keys.size;
}

function formatMappedDestinationSummary(destinationCount) {
  const n = Number(destinationCount) || 0;
  if (n <= 0) {
    return "No channel mappings found for these prototypes in the current dashboard.";
  }
  return n === 1
    ? "Mapped to 1 channel customer type"
    : `Mapped to ${n} channel customer types`;
}

function formatShowHidePrototypesLabel(count, expanded) {
  const n = Number(count) || 0;
  if (expanded) {
    return n === 1 ? "Hide duplicate" : `Hide ${n} duplicates`;
  }
  return n === 1 ? "Show duplicate" : `Show ${n} duplicates`;
}

function formatMasterCrossDashboardMappingWarning() {
  return "⚠ This Customer Type is also mapped on other dashboards. Those mappings cannot be shown here.";
}

// destination grouping by PKs, not names
assert.strictEqual(
  getMappingDestinationKey({
    resellerCompanyPk: "10",
    resellerItemPk: "20",
    resellerCustomerTypePk: "30"
  }),
  "10|20|30"
);
assert.strictEqual(
  getMappingDestinationKey({
    resellerCompanyPk: "10",
    resellerItemPk: "20"
  }),
  null
);

const groupedItem = {
  itemName: "Food Tour",
  prototypes: [
    {
      prototypePk: "101",
      displayName: "01-01 Adult",
      mappings: [
        {
          resellerCompanyPk: "10",
          resellerItemPk: "20",
          resellerCustomerTypePk: "30",
          openMappingUrl: "https://example/a"
        }
      ]
    },
    {
      prototypePk: "102",
      displayName: "02-02 Adult",
      mappings: [
        {
          resellerCompanyPk: "10",
          resellerItemPk: "20",
          resellerCustomerTypePk: "30",
          openMappingUrl: "https://example/a"
        }
      ]
    },
    {
      prototypePk: "103",
      displayName: "03-03 Adult",
      mappings: [
        {
          resellerCompanyPk: "10",
          resellerItemPk: "20",
          resellerCustomerTypePk: "99",
          openMappingUrl: "https://example/b"
        }
      ]
    },
    {
      prototypePk: "104",
      displayName: "Unmapped Adult",
      mappings: []
    }
  ]
};
const grouped = buildItemMappingDestinationGroups(groupedItem);
assert.strictEqual(grouped.destinations.length, 2);
assert.strictEqual(grouped.destinations[0].prototypes.length, 2);
assert.strictEqual(grouped.destinations[1].prototypes.length, 1);
assert.strictEqual(grouped.unmappedPrototypes.length, 1);
assert.strictEqual(grouped.unmappedPrototypes[0].prototypePk, "104");

const destinationTree = {
  items: [groupedItem]
};
assert.strictEqual(countDistinctMappingDestinations(destinationTree), 2);
assert.strictEqual(formatMappedDestinationSummary(1), "Mapped to 1 channel customer type");
assert.strictEqual(formatMappedDestinationSummary(3), "Mapped to 3 channel customer types");
assert.strictEqual(formatShowHidePrototypesLabel(1, false), "Show duplicate");
assert.strictEqual(formatShowHidePrototypesLabel(12, false), "Show 12 duplicates");
assert.strictEqual(formatShowHidePrototypesLabel(12, true), "Hide 12 duplicates");
assert.strictEqual(
  formatMasterCrossDashboardMappingWarning().includes("12 additional"),
  false
);
assert.strictEqual(
  formatMasterCrossDashboardMappingWarning().includes("other dashboards"),
  true
);
// item-level numeric warning wording remains unchanged
assert.strictEqual(
  formatCrossDashboardMappingWarning(12).includes("12 additional channel mappings"),
  true
);

console.log("test-customer-type-mapping-finder: all tests passed");
