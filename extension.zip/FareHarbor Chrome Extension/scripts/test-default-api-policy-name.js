#!/usr/bin/env node
'use strict';

const assert = require('assert');

const DEFAULT_API_POLICY_NAME_NORMALIZED = 'default api';

function normalizeCancellationPolicyNameForMatch(value) {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return normalized !== '' ? normalized : null;
}

function isDefaultApiCancellationPolicyName(name) {
  return normalizeCancellationPolicyNameForMatch(name) === DEFAULT_API_POLICY_NAME_NORMALIZED;
}

const shouldMatch = [
  'Default - API',
  'Default API',
  'Default/API',
  'Default_API',
  'Default  API',
  '  default   api  '
];

for (const name of shouldMatch) {
  assert.strictEqual(isDefaultApiCancellationPolicyName(name), true, `expected match: ${JSON.stringify(name)}`);
}

const shouldNotMatch = ['API', 'Default', 'Default Viator API', null, '', '   '];

for (const name of shouldNotMatch) {
  assert.strictEqual(isDefaultApiCancellationPolicyName(name), false, `expected no match: ${JSON.stringify(name)}`);
}

console.log('default api cancellation policy name matching: all assertions passed');
