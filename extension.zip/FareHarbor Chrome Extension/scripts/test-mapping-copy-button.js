const assert = require("assert");

const CHANNEL_COMPANY_LIST_RE =
  /^\/[^/]+\/dashboard\/settings\/integrations\/channels\/(\d+)\/?$/;
const CHANNEL_ITEM_PAGE_RE =
  /\/dashboard\/settings\/integrations\/channels\/(\d+)\/items\/(\d+)\/?$/;

const SHORT_NAME_ALIASES = {
  gyg: "getyourguide",
  getyourguide: "getyourguide",
  google: "google",
  viator: "viator",
  airbnb: "airbnb",
  bookingcom: "bookingcom",
  booking: "bookingcom",
  expedia: "expedia"
};

const MAPPING_COPY_STRATEGIES = {
  viator: { copyHandler: "viator-complete" },
  google: { copyHandler: "google-complete" },
  getyourguide: { copyHandler: "gyg-complete" },
  airbnb: { copyHandler: "airbnb-complete" },
  bookingcom: { copyHandler: "expedia-complete" },
  expedia: { copyHandler: "expedia-complete" }
};

function parseChannelCompanyListContext(pathname) {
  const normalized = (pathname || "").replace(/\/+$/, "");
  if (!normalized || /\/items\/\d+/.test(normalized)) {
    return null;
  }

  const numericMatch = normalized.match(CHANNEL_COMPANY_LIST_RE);
  if (numericMatch) {
    const parts = normalized.split("/").filter(Boolean);
    return {
      shortname: parts[0],
      companyPk: numericMatch[1]
    };
  }

  const parts = normalized.split("/").filter(Boolean);
  const dashIdx = parts.indexOf("dashboard");
  if (
    dashIdx >= 1 &&
    parts[dashIdx + 1] === "settings" &&
    parts[dashIdx + 2] === "integrations" &&
    parts[dashIdx + 3] === "channels"
  ) {
    const slug = parts[dashIdx + 4];
    const nextSegment = parts[dashIdx + 5];
    if (slug && !/^\d+$/.test(slug) && !nextSegment) {
      return {
        shortname: parts[0],
        channelSlug: slug.toLowerCase()
      };
    }
  }

  return null;
}

function parseChannelItemPageContext(pathname) {
  const normalized = (pathname || "").replace(/\/+$/, "");
  const match = normalized.match(CHANNEL_ITEM_PAGE_RE);
  if (!match) {
    return null;
  }
  const parts = normalized.split("/").filter(Boolean);
  return {
    shortname: parts[0],
    companyPk: match[1],
    resellerItemId: match[2]
  };
}

function normalizeAffiliateKey(company) {
  const otaType = String(company.ota_type || company.otaType || "")
    .trim()
    .toLowerCase();
  if (otaType && MAPPING_COPY_STRATEGIES[otaType]) {
    return otaType;
  }

  if (!otaType) {
    const shortName = String(company.short_name || company.shortName || "")
      .trim()
      .toLowerCase();
    const aliasKey = SHORT_NAME_ALIASES[shortName] || shortName;
    if (MAPPING_COPY_STRATEGIES[aliasKey]) {
      return aliasKey;
    }
  }

  return null;
}

assert.deepStrictEqual(
  parseChannelCompanyListContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/35764/"
  ),
  { shortname: "eatingeurope-rome", companyPk: "35764" }
);

assert.strictEqual(
  parseChannelCompanyListContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/35764/items/316479/"
  ),
  null
);

assert.deepStrictEqual(
  parseChannelCompanyListContext(
    "/demo/dashboard/settings/integrations/channels/getyourguide"
  ),
  { shortname: "demo", channelSlug: "getyourguide" }
);

assert.deepStrictEqual(
  parseChannelItemPageContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/35764/items/316479/"
  ),
  {
    shortname: "eatingeurope-rome",
    companyPk: "35764",
    resellerItemId: "316479"
  }
);

assert.strictEqual(normalizeAffiliateKey({ ota_type: "viator" }), "viator");
assert.strictEqual(normalizeAffiliateKey({ short_name: "gyg" }), "getyourguide");
assert.strictEqual(normalizeAffiliateKey({ name: "Unknown" }), null);

function normalizeVisibleText(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .trim();
}

function formatSingleItemButtonLabel(displayName) {
  return `Copy ${displayName} Item Data`;
}

const ITEM_INJECTED_ATTR = "data-fhx-copy-item-mapping-btn";
const ITEM_DATA_ATTR = "data-fh-copy-item-mapping-data";
const ACTIONS_BAR_ATTR = "data-fh-ext-item-mapping-actions";
const COPY_ITEM_BUTTON_ID = "fh-ext-copy-item-mapping-button";
const INJECTED_ATTR = "data-fhx-mapping-copy-btn";

function isItemMappingActionsBarPlaced(section, bar) {
  const blockList = section.querySelector?.("ul.block-list");
  if (blockList) {
    return blockList.nextElementSibling === bar;
  }
  return bar.parentElement === section;
}

const LINK_ACTION_LABEL_CLASS = "fh-ext-link-action-label";

function getItemMappingActionLabel(button) {
  const labelEl = button?.querySelector?.(`.${LINK_ACTION_LABEL_CLASS}`);
  if (labelEl) {
    return normalizeVisibleText(labelEl.textContent);
  }
  return normalizeVisibleText(button?.textContent || "");
}

function isSingleItemButtonCorrectlyPlaced(section, strategy) {
  if (!section || !strategy) {
    return null;
  }

  const bar = section.querySelector?.(`[${ACTIONS_BAR_ATTR}="true"]`);
  if (!bar || !isItemMappingActionsBarPlaced(section, bar)) {
    return null;
  }

  const button = bar.querySelector(`[${ITEM_DATA_ATTR}="true"]`);
  if (!button || !bar.contains(button)) {
    return null;
  }

  const expectedLabel = formatSingleItemButtonLabel(strategy.displayName);
  if (getItemMappingActionLabel(button) !== expectedLabel) {
    return null;
  }

  return bar;
}

function isWrapCorrectlyPlaced(wrap, placement) {
  if (!wrap || !placement?.ready) {
    return false;
  }
  if (placement.mode === "toolbar-before-flyout") {
    return (
      wrap.parentElement === placement.container &&
      wrap.nextElementSibling === placement.insertBefore
    );
  }
  if (placement.mode === "toolbar-append-group") {
    return wrap.parentElement === placement.container;
  }
  if (placement.mode === "header-fallback") {
    return placement.container?.contains(wrap);
  }
  return false;
}

function findExistingMappingCopyWrap(section, placement) {
  if (!section) {
    return null;
  }
  const wrap = section.querySelector(`[${INJECTED_ATTR}="1"]`);
  if (wrap && isWrapCorrectlyPlaced(wrap, placement)) {
    return wrap;
  }
  return null;
}

const strategy = { displayName: "GetYourGuide", affiliateKey: "getyourguide" };
const blockList = { nextElementSibling: null };
const dataButtonLabel = { textContent: formatSingleItemButtonLabel("GetYourGuide") };
const dataButton = {
  textContent: formatSingleItemButtonLabel("GetYourGuide"),
  querySelector(selector) {
    if (selector === `.${LINK_ACTION_LABEL_CLASS}`) {
      return dataButtonLabel;
    }
    return null;
  }
};
const actionsBar = {
  contains(node) {
    return node === dataButton;
  },
  querySelector(selector) {
    if (selector === `[${ITEM_DATA_ATTR}="true"]`) {
      return dataButton;
    }
    return null;
  }
};
blockList.nextElementSibling = actionsBar;
const section = {
  querySelector(selector) {
    if (selector === `[${ACTIONS_BAR_ATTR}="true"]`) {
      return actionsBar;
    }
    if (selector === "ul.block-list") {
      return blockList;
    }
    return null;
  }
};

assert.ok(isSingleItemButtonCorrectlyPlaced(section, strategy));

dataButtonLabel.textContent = "wrong label";
assert.strictEqual(isSingleItemButtonCorrectlyPlaced(section, strategy), null);

const channelSection = { container: {}, wrap: null };
const flyout = {};
channelSection.wrap = {
  parentElement: channelSection.container,
  nextElementSibling: flyout
};
channelSection.querySelector = function (selector) {
  return selector === `[${INJECTED_ATTR}="1"]` ? this.wrap : null;
};
const placement = {
  ready: true,
  mode: "toolbar-before-flyout",
  container: channelSection.container,
  insertBefore: flyout
};
assert.ok(findExistingMappingCopyWrap(channelSection, placement));
channelSection.wrap.nextElementSibling = {};
assert.strictEqual(findExistingMappingCopyWrap(channelSection, placement), null);

console.log("mapping-copy-button logic tests passed");
