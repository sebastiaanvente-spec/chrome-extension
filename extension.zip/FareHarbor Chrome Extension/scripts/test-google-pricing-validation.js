#!/usr/bin/env node
'use strict';

const assert = require('assert');

function formatSelectedPricingActual(selectedPricing) {
  if (!selectedPricing || selectedPricing.name === null || selectedPricing.name === undefined) {
    return String(selectedPricing?.name ?? 'null');
  }
  if (selectedPricing.type) {
    return `${selectedPricing.name} (${selectedPricing.type})`;
  }
  return String(selectedPricing.name);
}

function isAcceptedGooglePricingName(name) {
  if (typeof name !== 'string') {
    return false;
  }
  const selectedNameLower = name.trim().toLowerCase();
  if (!selectedNameLower) {
    return false;
  }
  return selectedNameLower.includes('online') || selectedNameLower.includes('google');
}

function validateGoogleAffiliatePricing(label, selectedPricing) {
  const selectedName = selectedPricing?.name ?? null;
  const accepted = isAcceptedGooglePricingName(selectedName);

  if (accepted) {
    return { ok: true };
  }

  return {
    ok: false,
    mismatch: `${label}: expected pricing containing Online or Google, got ${formatSelectedPricingActual(selectedPricing)}`
  };
}

const shouldMatch = [
  { name: 'Online', type: 'Total Sheet' },
  { name: 'Online - Dynamic Pricing API', type: 'Total Schedule' },
  { name: 'Online Weekend', type: 'Total Sheet' },
  { name: 'Online Summer', type: 'Total Schedule' },
  { name: 'Google', type: 'Total Sheet' },
  { name: 'Google Pricing', type: 'Total Sheet' },
  { name: 'Google Dynamic', type: 'Total Schedule' },
  { name: 'Google - EUR', type: 'Total Sheet' },
  { name: 'Online / Google', type: 'Total Schedule' },
  { name: '  online  ', type: null },
  { name: 'GOOGLE WEEKEND', type: 'Total Sheet' }
];

for (const selectedPricing of shouldMatch) {
  const result = validateGoogleAffiliatePricing('Pricing', selectedPricing);
  assert.strictEqual(result.ok, true, `expected pass for ${JSON.stringify(selectedPricing)}`);
}

const shouldFail = [
  { name: 'Direct', type: 'Total Sheet' },
  { name: 'Viator', type: 'Total Sheet' },
  { name: 'Expedia', type: 'Total Sheet' },
  { name: 'Airbnb', type: 'Total Sheet' },
  { name: 'GetYourGuide', type: 'Total Sheet' },
  { name: null, type: null },
  { name: '', type: null }
];

for (const selectedPricing of shouldFail) {
  const result = validateGoogleAffiliatePricing('Pricing', selectedPricing);
  assert.strictEqual(result.ok, false, `expected fail for ${JSON.stringify(selectedPricing)}`);
  assert.match(result.mismatch, /expected pricing containing Online or Google/);
}

const dynamicPricingResult = validateGoogleAffiliatePricing('Pricing', {
  name: 'Online - Dynamic Pricing API',
  type: 'Total Schedule'
});
assert.strictEqual(dynamicPricingResult.ok, true);
assert.strictEqual(dynamicPricingResult.mismatch, undefined);

console.log('test-google-pricing-validation: all assertions passed');
