const assert = require("assert");

const DEFAULT_RESELLER_ITEMS_COLUMN_INDEXES = {
  name: 0,
  sku: 1,
  externalIdentifier: 2,
  itemMappings: 3,
  channelCustomerTypes: 4,
  channelOptions: 5,
  lastChanged: 6
};

const RESELLER_ITEMS_COLUMN_HEADER_PATTERNS = {
  name: /^name$/i,
  sku: /^sku$/i,
  externalIdentifier: /^external identifier$/i,
  itemMappings: /^item mappings$/i,
  channelCustomerTypes: /^channel customer types$/i,
  channelOptions: /^channel options$/i,
  lastChanged: /^last changed$/i
};

function normalizeResellerHeaderText(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .trim();
}

function getResellerItemsColumnIndexesFromHeaders(headerTexts) {
  const indexes = { ...DEFAULT_RESELLER_ITEMS_COLUMN_INDEXES };
  const headers = (headerTexts || []).map((text) => ({
    textContent: text
  }));
  if (!headers.length) {
    return indexes;
  }

  for (const [key, pattern] of Object.entries(RESELLER_ITEMS_COLUMN_HEADER_PATTERNS)) {
    const idx = headers.findIndex((cell) =>
      pattern.test(normalizeResellerHeaderText(cell.textContent))
    );
    if (idx >= 0) {
      indexes[key] = idx;
    }
  }
  return indexes;
}

function getResellerItemCellFromRow(cells, columnIndexes, columnKey) {
  const idx = columnIndexes?.[columnKey];
  if (typeof idx !== "number" || idx < 0) {
    return null;
  }
  return cells[idx] || null;
}

const NATIVE_HEADERS = [
  "Name",
  "SKU",
  "External Identifier",
  "Item Mappings",
  "Channel Customer Types",
  "Channel Options",
  "Last changed"
];

const HEADERS_WITH_ITEM_STATUS = [
  "Name",
  "SKU",
  "External Identifier",
  "Item Mappings",
  "Item Status",
  "Channel Customer Types",
  "Channel Options",
  "Last changed"
];

const HEADERS_WITH_ITEM_STATUS_AND_TICKET_SCANNING = [
  "Name",
  "SKU",
  "External Identifier",
  "Item Mappings",
  "Item Status",
  "Ticket Scanning",
  "Channel Customer Types",
  "Channel Options",
  "Last changed"
];

// --- defaults when headers missing ---
assert.deepStrictEqual(
  getResellerItemsColumnIndexesFromHeaders([]),
  DEFAULT_RESELLER_ITEMS_COLUMN_INDEXES
);

// --- native table (no Item Status) ---
{
  const indexes = getResellerItemsColumnIndexesFromHeaders(NATIVE_HEADERS);
  assert.strictEqual(indexes.itemMappings, 3);
  assert.strictEqual(indexes.channelCustomerTypes, 4);
  assert.strictEqual(indexes.channelOptions, 5);
  assert.strictEqual(indexes.externalIdentifier, 2);
}

// --- with Item Status inserted after Item Mappings ---
{
  const indexes = getResellerItemsColumnIndexesFromHeaders(HEADERS_WITH_ITEM_STATUS);
  assert.strictEqual(indexes.itemMappings, 3);
  assert.strictEqual(indexes.channelCustomerTypes, 5);
  assert.strictEqual(indexes.channelOptions, 6);
  assert.strictEqual(indexes.externalIdentifier, 2);
  assert.strictEqual(indexes.lastChanged, 7);
}

// --- cell lookup uses resolved indexes (simulates the GYG bug) ---
{
  const indexes = getResellerItemsColumnIndexesFromHeaders(HEADERS_WITH_ITEM_STATUS);
  const cells = [
    "name",
    "sku",
    "ext",
    "mappings",
    "status",
    "Adult",
    "ro752107",
    "changed"
  ];

  // Hardcoded nth-child(6) / index 5 would incorrectly read customer types.
  assert.strictEqual(cells[5], "Adult");
  assert.strictEqual(
    getResellerItemCellFromRow(cells, indexes, "channelOptions"),
    "ro752107"
  );
  assert.strictEqual(
    getResellerItemCellFromRow(cells, indexes, "channelCustomerTypes"),
    "Adult"
  );
}

// --- without Item Status, indexes still match legacy positions ---
{
  const indexes = getResellerItemsColumnIndexesFromHeaders(NATIVE_HEADERS);
  const cells = [
    "name",
    "sku",
    "ext",
    "mappings",
    "Adult",
    "ro752107",
    "changed"
  ];
  assert.strictEqual(
    getResellerItemCellFromRow(cells, indexes, "channelOptions"),
    "ro752107"
  );
  assert.strictEqual(
    getResellerItemCellFromRow(cells, indexes, "channelCustomerTypes"),
    "Adult"
  );
}

// --- with Item Status + Ticket Scanning after Item Mappings ---
{
  const indexes = getResellerItemsColumnIndexesFromHeaders(
    HEADERS_WITH_ITEM_STATUS_AND_TICKET_SCANNING
  );
  assert.strictEqual(indexes.itemMappings, 3);
  assert.strictEqual(indexes.channelCustomerTypes, 6);
  assert.strictEqual(indexes.channelOptions, 7);
  assert.strictEqual(indexes.lastChanged, 8);
}

console.log("test-reseller-items-column-indexes: all tests passed");
