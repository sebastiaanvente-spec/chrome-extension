#!/usr/bin/env node
'use strict';

const assert = require('assert');

function normalizePricingNameForMatch(value) {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '');
  return normalized !== '' ? normalized : null;
}

function formatSelectedPricingActual(selectedPricing) {
  if (!selectedPricing || selectedPricing.name === null || selectedPricing.name === undefined) {
    return String(selectedPricing?.name ?? 'null');
  }
  if (selectedPricing.type) {
    return `${selectedPricing.name} (${selectedPricing.type})`;
  }
  return String(selectedPricing.name);
}

function validateAffiliatePricingContains(label, selectedPricing, allowedTokens) {
  const normalizedName = normalizePricingNameForMatch(selectedPricing?.name ?? null);
  const normalizedTokens = (allowedTokens || [])
    .map((token) => normalizePricingNameForMatch(token))
    .filter((token) => token !== null);

  if (!normalizedName) {
    return {
      ok: false,
      mismatch: `${label}: expected ${allowedTokens.join(' or ')}, got ${formatSelectedPricingActual(selectedPricing)}`
    };
  }
  if (normalizedTokens.some((token) => normalizedName.includes(token))) {
    return { ok: true };
  }
  return {
    ok: false,
    mismatch: `${label}: expected ${allowedTokens.join(' or ')}, got ${formatSelectedPricingActual(selectedPricing)}`
  };
}

const GYG_ALLOWED_TOKENS = ['Direct', 'GetYourGuide', 'GYG'];

function validateGetYourGuidePricing(selectedPricing) {
  return validateAffiliatePricingContains('Pricing', selectedPricing, GYG_ALLOWED_TOKENS);
}

const shouldMatch = [
  { name: 'Direct', type: 'Total Sheet' },
  { name: 'Direct Weekend', type: 'Total Sheet' },
  { name: 'Direct (Total Sheet)', type: 'Total Sheet' },
  { name: 'GetYourGuide', type: 'Total Sheet' },
  { name: 'GYG', type: 'Total Sheet' },
  { name: 'Get Your Guide', type: 'Total Sheet' },
  { name: 'Get Your Guide (Total Sheet)', type: 'Total Sheet' },
  { name: 'Get Your Guide Weekend', type: 'Total Sheet' },
  { name: 'Get-Your-Guide', type: 'Total Sheet' },
  { name: 'Get_Your_Guide', type: 'Total Schedule' },
  { name: '  Get Your Guide  ', type: null }
];

for (const selectedPricing of shouldMatch) {
  const result = validateGetYourGuidePricing(selectedPricing);
  assert.strictEqual(result.ok, true, `expected pass for ${JSON.stringify(selectedPricing)}`);
}

const shouldFail = [
  { name: 'Online', type: 'Total Sheet' },
  { name: 'Viator', type: 'Total Sheet' },
  { name: 'Expedia', type: 'Total Sheet' },
  { name: 'Airbnb', type: 'Total Sheet' },
  { name: null, type: null },
  { name: '', type: null }
];

for (const selectedPricing of shouldFail) {
  const result = validateGetYourGuidePricing(selectedPricing);
  assert.strictEqual(result.ok, false, `expected fail for ${JSON.stringify(selectedPricing)}`);
  assert.match(
    result.mismatch,
    /^Pricing: expected Direct or GetYourGuide or GYG, got/,
    `expected GetYourGuide pricing failure copy for ${JSON.stringify(selectedPricing)}`
  );
}

console.log('GetYourGuide pricing validation: all assertions passed');
