const assert = require("assert");

function normalizeVisibleText(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .trim();
}

function trimLinkText(rawText) {
  const str = normalizeVisibleText(rawText);
  const withIdLabel = str.match(/^(.+?\(ID:\s*\d+\))/);
  if (withIdLabel) return withIdLabel[1].trim();
  const withNumericId = str.match(/^(.+?\(\d+\))/);
  if (withNumericId) return withNumericId[1].trim();
  return str;
}

function getButtonLabel(linkCount) {
  return linkCount === 1 ? "Copy link" : "Copy links";
}

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function escapeHtmlAttr(text) {
  return escapeHtml(text).replace(/'/g, "&#39;");
}

function formatClipboardContent(links) {
  const html = links
    .map(
      (link) =>
        `<a href="${escapeHtmlAttr(link.href)}">${escapeHtml(link.text)}</a>`
    )
    .join("<br>");
  const plain = links.map((link) => link.text).join("\n");
  return { html, plain };
}

assert.strictEqual(
  trimLinkText("Private Bubbly Bike (ID: 354014) - funamsterdam"),
  "Private Bubbly Bike (ID: 354014)"
);

assert.strictEqual(
  trimLinkText("  Tour   (ID:  12)  - client  "),
  "Tour (ID: 12)"
);

assert.strictEqual(getButtonLabel(0), "Copy links");
assert.strictEqual(getButtonLabel(1), "Copy link");
assert.strictEqual(getButtonLabel(2), "Copy links");

const single = formatClipboardContent([
  {
    href: "https://fareharbor.com/demo/dashboard/items/354014/",
    text: "Private Bubbly Bike (ID: 354014)"
  }
]);
assert.strictEqual(
  single.html,
  '<a href="https://fareharbor.com/demo/dashboard/items/354014/">Private Bubbly Bike (ID: 354014)</a>'
);
assert.strictEqual(single.plain, "Private Bubbly Bike (ID: 354014)");

const multiple = formatClipboardContent([
  {
    href: "https://fareharbor.com/demo/dashboard/items/1/",
    text: "Tour A (ID: 1)"
  },
  {
    href: "https://fareharbor.com/demo/dashboard/items/2/",
    text: "Tour B (ID: 2)"
  }
]);
assert.strictEqual(
  multiple.html,
  '<a href="https://fareharbor.com/demo/dashboard/items/1/">Tour A (ID: 1)</a><br>' +
    '<a href="https://fareharbor.com/demo/dashboard/items/2/">Tour B (ID: 2)</a>'
);
assert.strictEqual(multiple.plain, "Tour A (ID: 1)\nTour B (ID: 2)");

console.log("item-mapping-link-copy logic tests passed");
