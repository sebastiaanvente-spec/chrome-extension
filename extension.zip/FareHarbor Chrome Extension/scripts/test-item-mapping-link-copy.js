const assert = require("assert");

function normalizeVisibleText(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .trim();
}

function trimLinkText(rawText) {
  const str = normalizeVisibleText(rawText);
  const withIdLabel = str.match(/^(.+?\(ID:\s*\d+\))/);
  if (withIdLabel) return withIdLabel[1].trim();
  const withNumericId = str.match(/^(.+?\(\d+\))/);
  if (withNumericId) return withNumericId[1].trim();
  return str;
}

function getButtonLabel(linkCount) {
  return linkCount === 1 ? "Copy Item Link" : "Copy Item Links";
}

function getItemNameButtonLabel(nameCount) {
  return nameCount === 1 ? "Copy Item Name" : "Copy Item Names";
}

function getChannelNameButtonLabel(linkCount) {
  return linkCount === 1 ? "Copy Channel Name" : "Copy Channel Names";
}

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function escapeHtmlAttr(text) {
  return escapeHtml(text).replace(/'/g, "&#39;");
}

function formatClipboardContent(links) {
  const html = links
    .map(
      (link) =>
        `<a href="${escapeHtmlAttr(link.href)}">${escapeHtml(link.text)}</a>`
    )
    .join("<br>");
  const plain = links.map((link) => link.text).join("\n");
  return { html, plain };
}

function normalizeItemMappingHref(href) {
  const raw = String(href || "").trim();
  if (!raw) {
    return raw;
  }
  try {
    const url = new URL(raw);
    url.pathname = url.pathname.replace(/\/calendar\/?$/i, "/");
    return url.toString();
  } catch (_err) {
    return raw.replace(/\/calendar\/?$/i, "/");
  }
}

assert.strictEqual(
  trimLinkText("Private Bubbly Bike (ID: 354014) - funamsterdam"),
  "Private Bubbly Bike (ID: 354014)"
);

assert.strictEqual(
  trimLinkText("  Tour   (ID:  12)  - client  "),
  "Tour (ID: 12)"
);

assert.strictEqual(getButtonLabel(0), "Copy Item Links");
assert.strictEqual(getButtonLabel(1), "Copy Item Link");
assert.strictEqual(getButtonLabel(2), "Copy Item Links");

assert.strictEqual(getItemNameButtonLabel(0), "Copy Item Names");
assert.strictEqual(getItemNameButtonLabel(1), "Copy Item Name");
assert.strictEqual(getItemNameButtonLabel(2), "Copy Item Names");

assert.strictEqual(getChannelNameButtonLabel(0), "Copy Channel Names");
assert.strictEqual(getChannelNameButtonLabel(1), "Copy Channel Name");
assert.strictEqual(getChannelNameButtonLabel(2), "Copy Channel Names");

assert.strictEqual(
  normalizeItemMappingHref(
    "https://fareharbor.com/eatingeurope-venice/dashboard/items/761826/calendar/"
  ),
  "https://fareharbor.com/eatingeurope-venice/dashboard/items/761826/"
);

assert.strictEqual(
  normalizeItemMappingHref(
    "https://fareharbor.com/eatingeurope-venice/dashboard/items/761826/calendar"
  ),
  "https://fareharbor.com/eatingeurope-venice/dashboard/items/761826/"
);

assert.strictEqual(
  normalizeItemMappingHref(
    "https://fareharbor.com/demo/dashboard/items/354014/"
  ),
  "https://fareharbor.com/demo/dashboard/items/354014/"
);

assert.strictEqual(
  normalizeItemMappingHref(
    "https://fareharbor.com/demo/dashboard/items/354014/settings/"
  ),
  "https://fareharbor.com/demo/dashboard/items/354014/settings/"
);

assert.strictEqual(
  normalizeItemMappingHref("/demo/dashboard/items/1/calendar/"),
  "/demo/dashboard/items/1/"
);

const single = formatClipboardContent([
  {
    href: "https://fareharbor.com/demo/dashboard/items/354014/",
    text: "Private Bubbly Bike (ID: 354014)"
  }
]);
assert.strictEqual(
  single.html,
  '<a href="https://fareharbor.com/demo/dashboard/items/354014/">Private Bubbly Bike (ID: 354014)</a>'
);
assert.strictEqual(single.plain, "Private Bubbly Bike (ID: 354014)");

const multiple = formatClipboardContent([
  {
    href: "https://fareharbor.com/demo/dashboard/items/1/",
    text: "Tour A (ID: 1)"
  },
  {
    href: "https://fareharbor.com/demo/dashboard/items/2/",
    text: "Tour B (ID: 2)"
  }
]);
assert.strictEqual(
  multiple.html,
  '<a href="https://fareharbor.com/demo/dashboard/items/1/">Tour A (ID: 1)</a><br>' +
    '<a href="https://fareharbor.com/demo/dashboard/items/2/">Tour B (ID: 2)</a>'
);
assert.strictEqual(multiple.plain, "Tour A (ID: 1)\nTour B (ID: 2)");

const channelSingle = formatClipboardContent([
  {
    href: normalizeItemMappingHref(
      "https://fareharbor.com/eatingeurope-venice/dashboard/items/761826/calendar/"
    ),
    text: "Venice Greatest Hits - Private"
  }
]);
assert.strictEqual(
  channelSingle.html,
  '<a href="https://fareharbor.com/eatingeurope-venice/dashboard/items/761826/">Venice Greatest Hits - Private</a>'
);
assert.strictEqual(channelSingle.plain, "Venice Greatest Hits - Private");

const plainNames = ["Tour A (ID: 1)", "Tour B (ID: 2)"].join("\n");
assert.strictEqual(plainNames, "Tour A (ID: 1)\nTour B (ID: 2)");

console.log("item-mapping-link-copy logic tests passed");
