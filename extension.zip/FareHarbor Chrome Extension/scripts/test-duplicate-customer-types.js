#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const read = (file) => fs.readFileSync(path.join(__dirname, "..", file), "utf8");
const quiet = { log() {}, warn() {}, error() {} };
const targetName = "Adult - EN / Tour & Tickets Included";
const adult = { pk: 185550, name: "Adult", customer_type: { pk: 10 } };
const target = { pk: 1316873, name: targetName, customer_type: { pk: 20 } };

function harness(initialPrototypes) {
  let prototypes = initialPrototypes;
  let failReads = false;
  let failWrites = false;
  const requests = [];
  const context = {
    console: quiet,
    document: { cookie: "csrftoken=test-token" },
    window: {
      FareHarborUtils: {}, // Any attempted DOM fallback fails this test.
      location: {
        pathname: "/walksineurope/dashboard/items/87603/prices/customer-types/",
        origin: "https://fareharbor.com",
        reload() {}
      },
      dispatchEvent() {}
    },
    CustomEvent: class {},
    setTimeout() {},
    async fetch(url, options) {
      requests.push({ url, ...options });
      if (options.method === "GET" && failReads) throw new Error("Read failed");
      if (options.method !== "GET" && failWrites) throw new Error("Write failed");
      const data = options.method === "GET"
        ? { customer_prototypes: prototypes }
        : { customer_prototype: { ...target, pk: 999999 } };
      return { ok: true, text: async () => JSON.stringify(data) };
    }
  };
  vm.runInNewContext(read("content/duplicate-customer-types.js"), context);
  return {
    module: context.window.DuplicateCustomerTypes,
    requests,
    setPrototypes(value) { prototypes = value; },
    failReads() { failReads = true; },
    failWrites() { failWrites = true; },
    message(req) {
      return new Promise((resolve) => {
        assert.equal(context.window.DuplicateCustomerTypes.handleMessage(req, null, resolve), true);
      });
    }
  };
}

function uiHarness() {
  const elements = new Map();
  const document = {
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, {
        value: "", options: [], disabled: false, textContent: "Start Duplication",
        appendChild(option) { this.options.push(option); },
        addEventListener(event, callback) { this[event] = callback; }
      });
      return elements.get(id);
    },
    createElement() {
      return { setAttribute(key, value) { this[key] = value; }, getAttribute(key) { return this[key]; } };
    },
    addEventListener(event, callback) { callback(); }
  };
  return { document, elements };
}

async function testUiSelection(list) {
  const popup = uiHarness();
  let sent;
  const popupContext = {
    document: popup.document, console: quiet, Blob,
    showStatus() {}, setDuplicateButtonState() {}, clearStatus() {}, updateBaseNameFromSelection() {},
    chrome: {
      runtime: {},
      tabs: {
        query(options, callback) { callback([{ id: 1 }]); },
        sendMessage(id, message, callback) {
          if (message.action === "getCustomerTypes") callback({ customerTypes: list });
          else { sent = message; callback({ status: "done" }); }
        }
      }
    }
  };
  const popupSource = read("popup.js");
  vm.createContext(popupContext);
  vm.runInContext(popupSource.slice(popupSource.indexOf("function loadCustomerTypes()"), popupSource.indexOf("// Expedia Mapping Handler")), popupContext);
  popupContext.loadCustomerTypes();
  const popupSelect = popup.document.getElementById("customerTypeSelect");
  assert.equal(popupSelect.options[1].value, target.pk);
  assert.equal(popupSelect.options[1].textContent, `${targetName} (#${target.pk})`);
  popupSelect.value = String(popupSelect.options[1].value);
  popup.document.getElementById("duplicateCount").value = "1";
  popup.document.getElementById("basename").value = "Copy";
  await popup.document.getElementById("multipleDuplicateBtn").click();
  assert.equal(sent.prototypeId, String(target.pk));
  assert.equal(sent.baseIndex, undefined);

  const overlay = uiHarness();
  let args;
  const overlayContext = {
    document: overlay.document, console: quiet,
    updateDuplicateBaseNameFromSelection() {}, setStatus() {}, runDuplicatePageCheck() {},
    window: { DuplicateCustomerTypes: { async runMultipleDuplicates(...values) { args = values; } } }
  };
  vm.createContext(overlayContext);
  const overlaySource = read("content/overlay.js");
  vm.runInContext(overlaySource.slice(overlaySource.indexOf("  function populateDuplicateSelect("), overlaySource.indexOf("  function runDuplicatePageCheck(")), overlayContext);
  vm.runInContext(overlaySource.slice(overlaySource.indexOf("  async function handleDuplicateRun("), overlaySource.indexOf("  function wireDuplicateSection(")), overlayContext);
  overlayContext.populateDuplicateSelect(list);
  const overlaySelect = overlay.document.getElementById("fh-automator-customer-type-select");
  assert.equal(overlaySelect.options[1].value, target.pk);
  overlaySelect.value = String(overlaySelect.options[1].value);
  overlay.document.getElementById("fh-automator-duplicate-count").value = "1";
  overlay.document.getElementById("fh-automator-basename").value = "Copy";
  await overlayContext.handleDuplicateRun();
  assert.equal(args[2], String(target.pk));
}

(async () => {
  const h = harness([adult, target]);
  const list = (await h.message({ action: "getCustomerTypes" })).customerTypes;
  assert.equal(list[1].prototypeId, target.pk);
  await testUiSelection(list);

  // Reported regression: the shorter prefix appears before the selected type.
  await h.module.runMultipleDuplicates(1, "Copy", String(list[1].prototypeId));
  // Identical labels must also preserve the selected identity.
  h.setPrototypes([{ ...adult, name: targetName }, target]);
  await h.module.runMultipleDuplicates(1, "Copy", String(list[1].prototypeId));
  // Reordering after selection must not change the source of either duplicate.
  h.setPrototypes([target, adult]);
  const response = await h.message({ action: "runMultipleDuplicates", count: 2, basename: "Copy", prototypeId: String(list[1].prototypeId) });
  assert.equal(response.status, "done");
  const duplicates = h.requests.filter((req) => req.method === "POST");
  assert.equal(duplicates.length, 4);
  for (const req of duplicates) {
    assert(req.url.endsWith(`/customer-prototypes/${target.pk}/duplicate/`));
    assert.equal(JSON.parse(req.body).customer_type, target.customer_type.pk);
  }

  const missing = harness([adult]);
  await assert.rejects(missing.module.runMultipleDuplicates(1, "Copy", target.pk), /no longer available/);
  assert(missing.requests.every((req) => req.method === "GET"));
  for (const id of [undefined, null, "", "0", "NaN", "1316873extra"]) {
    await assert.rejects(missing.module.runMultipleDuplicates(1, "Copy", id), /valid prototype ID/);
  }
  const legacy = await missing.message({ action: "runMultipleDuplicates", count: 1, basename: "Copy", baseIndex: 0 });
  assert.equal(legacy.status, "error");

  const unavailable = harness([adult, target]);
  unavailable.failReads();
  const failedList = await unavailable.message({ action: "getCustomerTypes" });
  assert.equal(failedList.customerTypes.length, 0);
  assert.equal(failedList.error, "Read failed");
  await assert.rejects(unavailable.module.runMultipleDuplicates(1, "Copy", target.pk), /Read failed/);

  const writeFailure = harness([adult, target]);
  writeFailure.failWrites();
  await assert.rejects(writeFailure.module.runMultipleDuplicates(1, "Copy", target.pk), /Write failed/);
  assert.equal(writeFailure.requests.filter((req) => req.method === "POST").length, 1);
  console.log("Duplicate customer types: all assertions passed");
})().catch((error) => { console.error(error); process.exitCode = 1; });
