const assert = require("assert");

const CHANNEL_ITEM_PAGE_RE =
  /\/dashboard\/settings\/integrations\/channels\/(\d+)\/items\/(\d+)\/?$/;

function parseChannelItemPageContext(pathname) {
  const normalized = (pathname || "").replace(/\/+$/, "");
  const match = normalized.match(CHANNEL_ITEM_PAGE_RE);
  if (!match) {
    return null;
  }
  const parts = normalized.split("/").filter(Boolean);
  return {
    shortname: parts[0],
    companyPk: match[1],
    resellerItemId: match[2]
  };
}

function isEligiblePath(pathname) {
  return !!parseChannelItemPageContext(pathname);
}

// Eligible: channel item mapping index
assert.deepStrictEqual(
  parseChannelItemPageContext(
    "/captainjackamsterdam/dashboard/settings/integrations/channels/43925/items/332081/"
  ),
  {
    shortname: "captainjackamsterdam",
    companyPk: "43925",
    resellerItemId: "332081"
  }
);

assert.strictEqual(
  isEligiblePath(
    "/demo/dashboard/settings/integrations/channels/123/items/456"
  ),
  true
);

// Ineligible paths
assert.strictEqual(
  isEligiblePath(
    "/demo/dashboard/settings/integrations/channels/43925/"
  ),
  false
);
assert.strictEqual(
  isEligiblePath(
    "/demo/dashboard/settings/integrations/channels/43925/items/332081/options/99/"
  ),
  false
);
assert.strictEqual(
  isEligiblePath(
    "/demo/dashboard/settings/integrations/channels/43925/items/332081/customer-types/12/"
  ),
  false
);
assert.strictEqual(
  isEligiblePath(
    "/demo/dashboard/settings/integrations/channels/43925/items/332081/settings/"
  ),
  false
);

const OTA_TOOL_REGISTRY = {
  getyourguide: { displayName: "GetYourGuide", hasCopyOneItem: true },
  expedia: { displayName: "Expedia", hasCopyOneItem: true },
  viator: {
    displayName: "Viator",
    hasCopyOneItem: false
  },
  airbnb: {
    displayName: "Airbnb",
    hasCopyOneItem: false
  }
};

assert.strictEqual(OTA_TOOL_REGISTRY.getyourguide.hasCopyOneItem, true);
assert.strictEqual(OTA_TOOL_REGISTRY.expedia.hasCopyOneItem, true);
assert.strictEqual(OTA_TOOL_REGISTRY.viator.hasCopyOneItem, false);
assert.strictEqual(OTA_TOOL_REGISTRY.viator.emptyMessage, undefined);
assert.strictEqual(OTA_TOOL_REGISTRY.airbnb.hasCopyOneItem, false);
assert.strictEqual(OTA_TOOL_REGISTRY.airbnb.emptyMessage, undefined);

// Ticket Scanning row in Mapping Tools is Viator-only (matches Channel Items column).
function shouldMountTicketScanningRow(affiliateKey) {
  return affiliateKey === "viator";
}
assert.strictEqual(shouldMountTicketScanningRow("viator"), true);
assert.strictEqual(shouldMountTicketScanningRow("getyourguide"), false);
assert.strictEqual(shouldMountTicketScanningRow("expedia"), false);
assert.strictEqual(shouldMountTicketScanningRow(null), false);

// Google Location / Place ID rows are Google-only (avoid extra location requests elsewhere).
function shouldMountGoogleLocationRows(affiliateKey) {
  return affiliateKey === "google";
}
assert.strictEqual(shouldMountGoogleLocationRows("google"), true);
assert.strictEqual(shouldMountGoogleLocationRows("viator"), false);
assert.strictEqual(shouldMountGoogleLocationRows("getyourguide"), false);
assert.strictEqual(shouldMountGoogleLocationRows(null), false);

function formatGoogleLocationDisplayName(locationName, isDashboardDefault) {
  if (!locationName) {
    return null;
  }
  return isDashboardDefault
    ? `${locationName} (Dashboard Default)`
    : locationName;
}

assert.strictEqual(
  formatGoogleLocationDisplayName("Google Things To Do", false),
  "Google Things To Do"
);
assert.strictEqual(
  formatGoogleLocationDisplayName("Pure Boats", true),
  "Pure Boats (Dashboard Default)"
);
assert.strictEqual(formatGoogleLocationDisplayName(null, true), null);

function pickCopyOutput({ useTSVFormat, htmlData, tsvData }) {
  return useTSVFormat ? tsvData : htmlData;
}

assert.strictEqual(
  pickCopyOutput({
    useTSVFormat: false,
    htmlData: "<table></table>",
    tsvData: "a\tb"
  }),
  "<table></table>"
);
assert.strictEqual(
  pickCopyOutput({
    useTSVFormat: true,
    htmlData: "<table></table>",
    tsvData: "a\tb"
  }),
  "a\tb"
);

const DASHBOARD_ITEM_PATH_RE = /\/([^/]+)\/dashboard\/items\/(\d+)/;

function parseConnectedItemFromHref(href) {
  try {
    const pathname = new URL(href, "https://fareharbor.com").pathname;
    const match = pathname.match(DASHBOARD_ITEM_PATH_RE);
    if (!match) return null;
    return { companyShortname: match[1], itemId: match[2] };
  } catch (_) {
    return null;
  }
}

assert.deepStrictEqual(
  parseConnectedItemFromHref(
    "/captainjackamsterdam/dashboard/items/764668/calendar/"
  ),
  { companyShortname: "captainjackamsterdam", itemId: "764668" }
);

// Channel item URL must not be treated as a FareHarbor dashboard item.
assert.strictEqual(
  parseConnectedItemFromHref(
    "/captainjackamsterdam/dashboard/settings/integrations/channels/43925/items/332081/"
  ),
  null
);

function parseAvailabilityCountText(text) {
  const trimmed = String(text || "")
    .replace(/\s+/g, " ")
    .trim();
  if (
    !trimmed ||
    trimmed === "Loading..." ||
    trimmed === "Error" ||
    trimmed === "—"
  ) {
    return null;
  }
  const numeric = Number(trimmed.replace(/,/g, ""));
  return Number.isFinite(numeric) ? numeric : null;
}

function evaluateAvailabilityMismatch(entries, stillLoading) {
  if (stillLoading) {
    return { status: "loading", entries };
  }
  if (entries.length < 2) {
    return { status: "ok", entries };
  }
  const baseline = entries[0].count;
  const mismatch = entries.some((entry) => entry.count !== baseline);
  return { status: mismatch ? "mismatch" : "ok", entries };
}

function buildFutureAvailabilityMismatchSignature(entries) {
  return entries.map((entry) => `${entry.name}:${entry.count}`).join("|");
}

function formatFutureAvailabilityMismatchLines(entries) {
  return [
    "Future availabilities do not match across customer types!",
    ...entries.map((entry) => `* ${entry.name}: ${entry.count}`)
  ];
}

assert.strictEqual(parseAvailabilityCountText("100"), 100);
assert.strictEqual(parseAvailabilityCountText("Loading..."), null);
assert.strictEqual(parseAvailabilityCountText("Error"), null);
assert.strictEqual(parseAvailabilityCountText("—"), null);

assert.strictEqual(
  evaluateAvailabilityMismatch(
    [
      { name: "Adult", count: 100 },
      { name: "Child", count: 100 }
    ],
    false
  ).status,
  "ok"
);
assert.strictEqual(
  evaluateAvailabilityMismatch(
    [
      { name: "Adult", count: 100 },
      { name: "Child", count: 95 }
    ],
    false
  ).status,
  "mismatch"
);
assert.strictEqual(
  evaluateAvailabilityMismatch(
    [
      { name: "Adult", count: 100 },
      { name: "Child", count: 95 }
    ],
    true
  ).status,
  "loading"
);
assert.strictEqual(
  evaluateAvailabilityMismatch([{ name: "Adult", count: 100 }], false).status,
  "ok"
);
assert.strictEqual(
  buildFutureAvailabilityMismatchSignature([
    { name: "Adult", count: 100 },
    { name: "Child", count: 95 }
  ]),
  "Adult:100|Child:95"
);
assert.deepStrictEqual(
  formatFutureAvailabilityMismatchLines([
    { name: "Adult", count: 990 },
    { name: "Child", count: 1098 },
    { name: "Infant", count: 1098 }
  ]),
  [
    "Future availabilities do not match across customer types!",
    "* Adult: 990",
    "* Child: 1098",
    "* Infant: 1098"
  ]
);

console.log("test-mapping-tools-panel: all assertions passed");
