const assert = require("assert");

const CHANNEL_ITEM_PAGE_RE =
  /\/dashboard\/settings\/integrations\/channels\/(\d+)\/items\/(\d+)\/?$/;

function parseChannelItemPageContext(pathname) {
  const normalized = (pathname || "").replace(/\/+$/, "");
  const match = normalized.match(CHANNEL_ITEM_PAGE_RE);
  if (!match) {
    return null;
  }
  const parts = normalized.split("/").filter(Boolean);
  return {
    shortname: parts[0],
    companyPk: match[1],
    resellerItemId: match[2]
  };
}

function isEligiblePath(pathname) {
  return !!parseChannelItemPageContext(pathname);
}

// Eligible: channel item mapping index
assert.deepStrictEqual(
  parseChannelItemPageContext(
    "/captainjackamsterdam/dashboard/settings/integrations/channels/43925/items/332081/"
  ),
  {
    shortname: "captainjackamsterdam",
    companyPk: "43925",
    resellerItemId: "332081"
  }
);

assert.strictEqual(
  isEligiblePath(
    "/demo/dashboard/settings/integrations/channels/123/items/456"
  ),
  true
);

// Ineligible paths
assert.strictEqual(
  isEligiblePath(
    "/demo/dashboard/settings/integrations/channels/43925/"
  ),
  false
);
assert.strictEqual(
  isEligiblePath(
    "/demo/dashboard/settings/integrations/channels/43925/items/332081/options/99/"
  ),
  false
);
assert.strictEqual(
  isEligiblePath(
    "/demo/dashboard/settings/integrations/channels/43925/items/332081/customer-types/12/"
  ),
  false
);
assert.strictEqual(
  isEligiblePath(
    "/demo/dashboard/settings/integrations/channels/43925/items/332081/settings/"
  ),
  false
);

const OTA_TOOL_REGISTRY = {
  getyourguide: { displayName: "GetYourGuide", hasCopyOneItem: true },
  expedia: { displayName: "Expedia", hasCopyOneItem: true },
  viator: {
    displayName: "Viator",
    hasCopyOneItem: false,
    emptyMessage:
      "Copy 1 Item is not available for Viator. Use the popup for the complete mapping file."
  }
};

assert.strictEqual(OTA_TOOL_REGISTRY.getyourguide.hasCopyOneItem, true);
assert.strictEqual(OTA_TOOL_REGISTRY.expedia.hasCopyOneItem, true);
assert.strictEqual(OTA_TOOL_REGISTRY.viator.hasCopyOneItem, false);
assert.ok(OTA_TOOL_REGISTRY.viator.emptyMessage);

function pickCopyOutput({ useTSVFormat, htmlData, tsvData }) {
  return useTSVFormat ? tsvData : htmlData;
}

assert.strictEqual(
  pickCopyOutput({
    useTSVFormat: false,
    htmlData: "<table></table>",
    tsvData: "a\tb"
  }),
  "<table></table>"
);
assert.strictEqual(
  pickCopyOutput({
    useTSVFormat: true,
    htmlData: "<table></table>",
    tsvData: "a\tb"
  }),
  "a\tb"
);

const DASHBOARD_ITEM_PATH_RE = /\/([^/]+)\/dashboard\/items\/(\d+)/;

function parseConnectedItemFromHref(href) {
  try {
    const pathname = new URL(href, "https://fareharbor.com").pathname;
    const match = pathname.match(DASHBOARD_ITEM_PATH_RE);
    if (!match) return null;
    return { companyShortname: match[1], itemId: match[2] };
  } catch (_) {
    return null;
  }
}

assert.deepStrictEqual(
  parseConnectedItemFromHref(
    "/captainjackamsterdam/dashboard/items/764668/calendar/"
  ),
  { companyShortname: "captainjackamsterdam", itemId: "764668" }
);

// Channel item URL must not be treated as a FareHarbor dashboard item.
assert.strictEqual(
  parseConnectedItemFromHref(
    "/captainjackamsterdam/dashboard/settings/integrations/channels/43925/items/332081/"
  ),
  null
);

console.log("test-mapping-tools-panel: all assertions passed");
