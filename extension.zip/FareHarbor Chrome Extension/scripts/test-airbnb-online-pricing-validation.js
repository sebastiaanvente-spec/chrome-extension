#!/usr/bin/env node
'use strict';

const assert = require('assert');

function normalizePricingNameForMatch(value) {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '');
  return normalized !== '' ? normalized : null;
}

function isAcceptedAirbnbPricingName(name) {
  const normalized = normalizePricingNameForMatch(name);
  return (
    normalized !== null &&
    (normalized.includes('online') || normalized.includes('airbnb'))
  );
}

function formatSelectedPricingActual(selectedPricing) {
  if (!selectedPricing || selectedPricing.name === null || selectedPricing.name === undefined) {
    return String(selectedPricing?.name ?? 'null');
  }
  if (selectedPricing.type) {
    return `${selectedPricing.name} (${selectedPricing.type})`;
  }
  return String(selectedPricing.name);
}

function validateAffiliatePricingOnline(label, selectedPricing, options = {}) {
  const affiliateLabel = options.affiliateLabel ?? null;
  const failurePrefix = affiliateLabel
    ? `${affiliateLabel}: expected Online or Airbnb pricing sheet, got`
    : `${label}: expected Online or Airbnb pricing sheet, got`;

  if (isAcceptedAirbnbPricingName(selectedPricing?.name)) {
    return { ok: true };
  }
  return {
    ok: false,
    mismatch: `${failurePrefix} ${formatSelectedPricingActual(selectedPricing)}`
  };
}

const shouldMatch = [
  { name: 'Online', type: 'Total Sheet' },
  { name: 'Online Total Sheet', type: 'Total Sheet' },
  { name: 'Online Total Schedule', type: 'Total Schedule' },
  { name: 'Online Weekend', type: 'Total Sheet' },
  { name: 'online', type: 'Total Sheet' },
  { name: 'Company Online Pricing', type: 'Total Schedule' },
  { name: '  Online  ', type: null },
  { name: 'Airbnb', type: 'Total Sheet' },
  { name: 'Airbnb Weekend', type: 'Total Sheet' },
  { name: 'Airbnb 20%', type: 'Total Sheet' },
  { name: 'airbnb', type: 'Total Sheet' }
];

for (const selectedPricing of shouldMatch) {
  const result = validateAffiliatePricingOnline('Pricing', selectedPricing, { affiliateLabel: 'Airbnb' });
  assert.strictEqual(result.ok, true, `expected pass for ${JSON.stringify(selectedPricing)}`);
}

const shouldFail = [
  { name: 'Direct', type: 'Total Sheet' },
  { name: 'Direct Total Sheet', type: 'Total Sheet' },
  { name: 'Viator', type: 'Total Sheet' },
  { name: 'GetYourGuide', type: 'Total Sheet' },
  { name: null, type: null },
  { name: '', type: null }
];

for (const selectedPricing of shouldFail) {
  const result = validateAffiliatePricingOnline('Pricing', selectedPricing, { affiliateLabel: 'Airbnb' });
  assert.strictEqual(result.ok, false, `expected fail for ${JSON.stringify(selectedPricing)}`);
  assert.match(
    result.mismatch,
    /^Airbnb: expected Online or Airbnb pricing sheet, got/,
    `expected Airbnb-specific failure copy for ${JSON.stringify(selectedPricing)}`
  );
}

console.log('Airbnb online pricing validation: all assertions passed');
