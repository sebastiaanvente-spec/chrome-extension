#!/usr/bin/env node
'use strict';

const assert = require('assert');

const GOOGLE_PLACE_ID_RE = /^ChIJ[A-Za-z0-9_-]{20,35}$/;

function isValidGooglePlaceId(value) {
  if (value == null) {
    return false;
  }
  const text = String(value).trim();
  if (!text) {
    return false;
  }
  return GOOGLE_PLACE_ID_RE.test(text);
}

const validExamples = [
  'ChIJ2WxmBjFgLxMRJybzeyo1Vrg',
  'ChIJfc8DqVVgLxMRxPIIp3z8CBg',
  'ChIJ81fvO6VhLxMREagEdBHlEIE'
];

for (const placeId of validExamples) {
  assert.strictEqual(isValidGooglePlaceId(placeId), true, `expected valid: ${placeId}`);
}

const invalidExamples = [
  null,
  undefined,
  '',
  '   ',
  'ChIJ',
  'ChIJshort',
  'NotAPlaceId',
  'ChIJ' + 'a'.repeat(50),
  'xxIJ2WxmBjFgLxMRJybzeyo1Vrg',
  'ChIJ invalid spaces here!!!!'
];

for (const placeId of invalidExamples) {
  assert.strictEqual(isValidGooglePlaceId(placeId), false, `expected invalid: ${String(placeId)}`);
}

console.log('test-google-place-id-validation: all assertions passed');
