const assert = require("assert");

const CHANNEL_ITEMS_LISTING_RE =
  /^\/[^/]+\/dashboard\/settings\/integrations\/channels\/(\d+)(?:\/items)?\/?$/;

function parseChannelItemsListingPageContext(pathname) {
  const normalized = String(pathname || "").replace(/\/+$/, "");
  if (!normalized || /\/items\/\d+/.test(normalized)) {
    return null;
  }

  const match = normalized.match(CHANNEL_ITEMS_LISTING_RE);
  if (!match) {
    return null;
  }

  const parts = normalized.split("/").filter(Boolean);
  return {
    companyShortname: parts[0],
    channelId: match[1]
  };
}

function resolveFutureAvailabilitiesAction(checkbox, pageKey, state) {
  const flyoutExpanded = !!state?.flyoutExpanded;
  const openedFlyout = state?.openedFlyoutPageKey === pageKey;
  const alreadyClicked = state?.clickedPageKey === pageKey;

  if (checkbox && checkbox.checked) {
    if (openedFlyout && flyoutExpanded) {
      return "close-flyout";
    }
    return "done";
  }

  if (!state?.displayOptionsButton) {
    return "wait";
  }

  if (!checkbox || !flyoutExpanded) {
    if (openedFlyout && flyoutExpanded && !checkbox) {
      return "wait";
    }
    if (openedFlyout && !flyoutExpanded && !checkbox) {
      return "open-flyout";
    }
    return "open-flyout";
  }

  if (alreadyClicked) {
    return "already-clicked";
  }
  return "click";
}

// --- page detection ---
assert.deepStrictEqual(
  parseChannelItemsListingPageContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/35764/"
  ),
  { companyShortname: "eatingeurope-rome", channelId: "35764" }
);
assert.deepStrictEqual(
  parseChannelItemsListingPageContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/35764/items/"
  ),
  { companyShortname: "eatingeurope-rome", channelId: "35764" }
);
assert.strictEqual(
  parseChannelItemsListingPageContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/35764/items/316479/"
  ),
  null
);

// --- open flyout before clicking hidden checkbox ---
const button = { tagName: "BUTTON" };
assert.strictEqual(
  resolveFutureAvailabilitiesAction(null, "a|1", {
    displayOptionsButton: null,
    flyoutExpanded: false,
    openedFlyoutPageKey: null,
    clickedPageKey: null
  }),
  "wait"
);
assert.strictEqual(
  resolveFutureAvailabilitiesAction(null, "a|1", {
    displayOptionsButton: button,
    flyoutExpanded: false,
    openedFlyoutPageKey: null,
    clickedPageKey: null
  }),
  "open-flyout"
);
assert.strictEqual(
  resolveFutureAvailabilitiesAction(null, "a|1", {
    displayOptionsButton: button,
    flyoutExpanded: true,
    openedFlyoutPageKey: "a|1",
    clickedPageKey: null
  }),
  "wait"
);
assert.strictEqual(
  resolveFutureAvailabilitiesAction(
    { checked: false },
    "a|1",
    {
      displayOptionsButton: button,
      flyoutExpanded: true,
      openedFlyoutPageKey: "a|1",
      clickedPageKey: null
    }
  ),
  "click"
);
assert.strictEqual(
  resolveFutureAvailabilitiesAction(
    { checked: false },
    "a|1",
    {
      displayOptionsButton: button,
      flyoutExpanded: true,
      openedFlyoutPageKey: "a|1",
      clickedPageKey: "a|1"
    }
  ),
  "already-clicked"
);
assert.strictEqual(
  resolveFutureAvailabilitiesAction(
    { checked: true },
    "a|1",
    {
      displayOptionsButton: button,
      flyoutExpanded: true,
      openedFlyoutPageKey: "a|1",
      clickedPageKey: "a|1"
    }
  ),
  "close-flyout"
);
assert.strictEqual(
  resolveFutureAvailabilitiesAction(
    { checked: true },
    "a|1",
    {
      displayOptionsButton: button,
      flyoutExpanded: false,
      openedFlyoutPageKey: "a|1",
      clickedPageKey: "a|1"
    }
  ),
  "done"
);
// Already enabled without us opening the flyout: do nothing
assert.strictEqual(
  resolveFutureAvailabilitiesAction(
    { checked: true },
    "a|1",
    {
      displayOptionsButton: button,
      flyoutExpanded: false,
      openedFlyoutPageKey: null,
      clickedPageKey: null
    }
  ),
  "done"
);
// Never click when checkbox is already checked and flyout closed
assert.strictEqual(
  resolveFutureAvailabilitiesAction(
    { checked: false },
    "a|1",
    {
      displayOptionsButton: button,
      flyoutExpanded: false,
      openedFlyoutPageKey: null,
      clickedPageKey: null
    }
  ),
  "open-flyout"
);

console.log("test-native-future-availabilities: all tests passed");
