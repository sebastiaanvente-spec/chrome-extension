#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const scriptPath = path.join(__dirname, "..", "content", "total-pricing-resolution.js");
const scriptSource = fs.readFileSync(scriptPath, "utf8");
const context = { window: {} };
vm.createContext(context);
vm.runInContext(scriptSource, context, { filename: scriptPath });
const resolver = context.window.FareHarborTotalPricingResolution;

assert(resolver, "FareHarborTotalPricingResolution should be defined");

const schedule = {
  pk: 4394,
  name: "GetYourGuide",
  entries: [
    { sheet: { pk: 101, name: "Weekday" } },
    { sheet: { pk: 102, name: "Weekend" } },
    { sheet: { pk: 101, name: "Weekday duplicate" } }
  ]
};

const sheets = resolver.extractTotalSheetsFromSchedule(schedule);
assert.strictEqual(sheets.length, 2);
assert.strictEqual(sheets[0].pk, 101);
assert.strictEqual(sheets[0].name, "Weekday");
assert.strictEqual(sheets[1].pk, 102);
assert.strictEqual(sheets[1].name, "Weekend");

assert.strictEqual(resolver.getPricingObjectPk({ pk: 55 }), 55);
assert.strictEqual(
  resolver.getPricingObjectPk({ uri: "/api/v1/companies/demo/total-schedules/12/" }),
  "12"
);
assert.strictEqual(resolver.getPricingObjectType({ cls: "TotalSchedule" }), "schedule");

const emptySchedule = { pk: 1, schedule_entries: [] };
assert.strictEqual(resolver.extractTotalSheetsFromSchedule(emptySchedule).length, 0);

console.log("Total pricing resolution: all assertions passed");
