#!/usr/bin/env node
'use strict';

const assert = require('assert');

function normalizeAirbnbInvoicePricingNameForMatch(value) {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9%]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return normalized !== '' ? normalized : null;
}

function isAcceptedAirbnbInvoicePricingName(displayName) {
  const normalized = normalizeAirbnbInvoicePricingNameForMatch(displayName);
  return normalized === 'billing 20%' || normalized === 'airbnb 20%';
}

function formatAffiliateSettingActual(actual) {
  if (actual === null || actual === undefined) {
    return String(actual);
  }
  return String(actual);
}

function validateAirbnbAffiliateInvoicePricing(detail) {
  const actual = detail?.default_invoice_sheet?.display_name ?? null;
  if (isAcceptedAirbnbInvoicePricingName(actual)) {
    return { ok: true };
  }
  return {
    ok: false,
    mismatch: `Invoice pricing should be Billing - 20% or an accepted Airbnb 20% variation; found: ${formatAffiliateSettingActual(actual)}`
  };
}

const shouldMatch = [
  'Billing - 20%',
  'Billing 20%',
  'Airbnb 20%',
  'Airbnb - 20%',
  'billing-20%',
  '  Billing   -   20%  ',
  'AIRBNB 20%'
];

for (const displayName of shouldMatch) {
  const result = validateAirbnbAffiliateInvoicePricing({
    default_invoice_sheet: { display_name: displayName }
  });
  assert.strictEqual(result.ok, true, `expected pass for ${JSON.stringify(displayName)}`);
}

const shouldFail = ['Billing - 15%', 'Viator 20%', 'Direct 20%', null, '', '   '];

for (const displayName of shouldFail) {
  const result = validateAirbnbAffiliateInvoicePricing({
    default_invoice_sheet: displayName === null ? null : { display_name: displayName }
  });
  assert.strictEqual(result.ok, false, `expected fail for ${JSON.stringify(displayName)}`);
  assert.match(
    result.mismatch,
    /^Invoice pricing should be Billing - 20% or an accepted Airbnb 20% variation; found:/,
    `expected Airbnb invoice failure copy for ${JSON.stringify(displayName)}`
  );
}

console.log('Airbnb invoice pricing validation: all assertions passed');
