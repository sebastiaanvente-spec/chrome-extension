#!/usr/bin/env node
"use strict";

/**
 * Unit tests for Expedia complete-mapping TSV formatting helpers.
 * Mirrors strip/escape/join logic in content/expedia-mapping.js formatCompleteDataAsTSV
 * (DOM strip approximated with tag removal for Node).
 */
const assert = require("assert");

function htmlToPlainText(value) {
  if (value == null) return "";
  return String(value)
    .replace(/<[^>]*>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .trim();
}

function escapeTsvField(field) {
  if (field == null || field === "") return "";
  return String(field).trim().replace(/[\t\n\r]/g, " ");
}

function formatCompleteDataAsTSV(data, channelInfo = "") {
  if (!data || data.length === 0) {
    return "";
  }

  const tsvLines = [];

  tsvLines.push(
    [escapeTsvField(channelInfo || "Channel Info Not Found"), "", "", ""].join(
      "\t"
    )
  );

  tsvLines.push(
    [
      "Name",
      "External Identifier",
      "Channel Options",
      "Channel Customer Types"
    ].join("\t")
  );

  data.forEach((row) => {
    const [name, externalId, options, customerTypes] = row;
    const nameText = htmlToPlainText(name);
    const optionsText = htmlToPlainText(options).replace(/\n/g, "; ");
    const customerTypesText = htmlToPlainText(customerTypes).replace(
      /\n/g,
      "; "
    );

    tsvLines.push(
      [
        escapeTsvField(nameText),
        escapeTsvField(externalId),
        escapeTsvField(optionsText),
        escapeTsvField(customerTypesText)
      ].join("\t")
    );
  });

  return tsvLines.join("\n");
}

assert.strictEqual(formatCompleteDataAsTSV([]), "");
assert.strictEqual(formatCompleteDataAsTSV(null), "");

const sample = [
  [
    '<a href="https://fareharbor.com/demo/dashboard/items/1/">Canal Cruise (123)</a>',
    "EXT-1",
    "<strong>ro100</strong> 10:00 AM\n<strong>ro200</strong> 2:00 PM",
    "<strong>rct1</strong> (Adult)\n<strong>rct2</strong> (Child)"
  ]
];

const tsv = formatCompleteDataAsTSV(sample, "Expedia Demo rc939");
const lines = tsv.split("\n");

assert.strictEqual(lines.length, 3);
assert.strictEqual(lines[0], "Expedia Demo rc939\t\t\t");
assert.strictEqual(
  lines[1],
  "Name\tExternal Identifier\tChannel Options\tChannel Customer Types"
);
assert.strictEqual(
  lines[2],
  "Canal Cruise (123)\tEXT-1\tro100 10:00 AM; ro200 2:00 PM\trct1 (Adult); rct2 (Child)"
);

assert.strictEqual(lines[2].split("\t").length, 4);
assert.ok(!lines[2].includes("<strong>"));
assert.ok(!lines[2].includes("<a "));

console.log("test-expedia-complete-tsv: all assertions passed");
