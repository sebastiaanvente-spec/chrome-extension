#!/usr/bin/env node
'use strict';

const assert = require('assert');
const {
  normalizeFareHarborId,
  buildDashboardUrl,
  JUMP_TO_VIEW_TYPE,
  resolveApiBookingHrefToDashboard,
  resolveBookingHrefToGridOverlay,
} = require('../fareharbor-view-resolver.js');

const TEST_GRID_DATE = '2026-07-06';
const bookingCtx = { gridDate: TEST_GRID_DATE };

function bookingGridOverlayUrl(shortname, overlayPath) {
  return `https://fareharbor.com/${shortname}/dashboard/bookings/grid/${TEST_GRID_DATE}/?overlay=${encodeURIComponent(overlayPath)}`;
}

// --- normalizeFareHarborId ---

assert.strictEqual(normalizeFareHarborId('896180'), '896180');
assert.strictEqual(normalizeFareHarborId('#896180'), '896180');
assert.strictEqual(normalizeFareHarborId('pk896180'), '896180');
assert.strictEqual(normalizeFareHarborId('item: 12345'), '12345');
assert.strictEqual(normalizeFareHarborId('booking-998877'), '998877');
assert.strictEqual(normalizeFareHarborId('rc35764'), '35764');
assert.strictEqual(normalizeFareHarborId('  channel item 316479 '), '316479');
assert.strictEqual(normalizeFareHarborId('id: #4422'), '4422');
assert.strictEqual(normalizeFareHarborId('no-id-here'), null);
assert.strictEqual(normalizeFareHarborId(''), null);
assert.strictEqual(normalizeFareHarborId(null), null);

// --- buildDashboardUrl: Item ---

assert.strictEqual(
  buildDashboardUrl('Item', {
    pk: 598844,
    company: { shortname: 'searocketftlauderdale' },
  }),
  'https://fareharbor.com/searocketftlauderdale/dashboard/items/598844/'
);

// --- buildDashboardUrl: ResellerCompany ---

assert.strictEqual(
  buildDashboardUrl('ResellerCompany', {
    pk: 35764,
    company: { shortname: 'eatingeurope-rome' },
  }),
  'https://fareharbor.com/eatingeurope-rome/dashboard/settings/integrations/channels/35764/'
);

// --- buildDashboardUrl: ResellerItem ---

assert.strictEqual(
  buildDashboardUrl('ResellerItem', {
    pk: 316479,
    company: { shortname: 'eatingeurope-rome' },
    reseller_company: { pk: 35764 },
  }),
  'https://fareharbor.com/eatingeurope-rome/dashboard/settings/integrations/channels/35764/items/316479/'
);

// --- buildDashboardUrl: ResellerOption (confirmed example) ---

assert.strictEqual(
  buildDashboardUrl('ResellerOption', {
    pk: 896180,
    company: { shortname: 'eatingeurope-rome' },
    reseller_item: {
      pk: 316479,
      reseller_company: { pk: 35764 },
    },
  }),
  'https://fareharbor.com/eatingeurope-rome/dashboard/settings/integrations/channels/35764/items/316479/options/896180/'
);

// --- buildDashboardUrl: Booking ---

const BOOKING_UUID = 'ef5a4c12-c5c3-44b0-b913-0c10f263e548';
const CONTACT_PK = '294171740';

assert.strictEqual(
  buildDashboardUrl(
    'Booking',
    { dashboard_url: '/foo/dashboard/bookings/abc/' },
    bookingCtx
  ),
  bookingGridOverlayUrl('foo', '/dashboard/bookings/abc/')
);

assert.strictEqual(
  buildDashboardUrl(
    'Booking',
    { url: 'https://fareharbor.com/mycompany/contacts/123/bookings/uuid-here/' },
    bookingCtx
  ),
  bookingGridOverlayUrl('mycompany', '/contacts/123/bookings/uuid-here/')
);

assert.strictEqual(
  buildDashboardUrl(
    'Booking',
    {
      company: { shortname: 'mycompany' },
      contact: { pk: CONTACT_PK },
      uuid: BOOKING_UUID,
    },
    bookingCtx
  ),
  bookingGridOverlayUrl(
    'mycompany',
    `/contacts/${CONTACT_PK}/bookings/${BOOKING_UUID}/`
  )
);

assert.strictEqual(
  buildDashboardUrl(
    'Booking',
    {
      company: { shortname: 'mycompany' },
      uuid: BOOKING_UUID,
    },
    bookingCtx
  ),
  bookingGridOverlayUrl('mycompany', `/dashboard/bookings/${BOOKING_UUID}/`)
);

assert.strictEqual(buildDashboardUrl('Booking', { pk: 123 }, bookingCtx), null);

assert.strictEqual(
  buildDashboardUrl(
    'Booking',
    {
      uri: `/api/v1/companies/mycompany/bookings/${BOOKING_UUID}/`,
      company: { shortname: 'mycompany' },
      contact: { pk: CONTACT_PK },
      uuid: BOOKING_UUID,
    },
    bookingCtx
  ),
  bookingGridOverlayUrl(
    'mycompany',
    `/contacts/${CONTACT_PK}/bookings/${BOOKING_UUID}/`
  )
);

assert.strictEqual(
  buildDashboardUrl(
    'Booking',
    {
      url: `https://fareharbor.com/api/v1/companies/mycompany/bookings/${BOOKING_UUID}/`,
      company: { shortname: 'mycompany' },
      uuid: BOOKING_UUID,
    },
    bookingCtx
  ),
  bookingGridOverlayUrl('mycompany', `/dashboard/bookings/${BOOKING_UUID}/`)
);

assert.strictEqual(
  resolveApiBookingHrefToDashboard(
    `/api/v1/companies/mycompany/bookings/${BOOKING_UUID}/`,
    bookingCtx
  ),
  bookingGridOverlayUrl('mycompany', `/dashboard/bookings/${BOOKING_UUID}/`)
);

assert.strictEqual(
  resolveBookingHrefToGridOverlay(
    `/contacts/${CONTACT_PK}/bookings/${BOOKING_UUID}/`,
    { ...bookingCtx, shortname: 'silentworld' }
  ),
  bookingGridOverlayUrl(
    'silentworld',
    `/contacts/${CONTACT_PK}/bookings/${BOOKING_UUID}/`
  )
);

assert.strictEqual(
  resolveBookingHrefToGridOverlay(
    `https://fareharbor.com/silentworld/contacts/${CONTACT_PK}/bookings/${BOOKING_UUID}/`,
    bookingCtx
  ),
  bookingGridOverlayUrl(
    'silentworld',
    `/contacts/${CONTACT_PK}/bookings/${BOOKING_UUID}/`
  )
);

assert.strictEqual(
  resolveBookingHrefToGridOverlay(
    'https://fareharbor.com/silentworld/dashboard/bookings/grid/2026-07-06/?overlay=/contacts/328584183/bookings/7470d107-a137-4b95-80b8-d7d20e20fd5f/',
    bookingCtx
  ),
  'https://fareharbor.com/silentworld/dashboard/bookings/grid/2026-07-06/?overlay=/contacts/328584183/bookings/7470d107-a137-4b95-80b8-d7d20e20fd5f/'
);

assert.strictEqual(
  buildDashboardUrl(
    'Booking',
    {
      company: { shortname: 'silentworld' },
      contact: { pk: 328584183 },
      uuid: '7470d107-a137-4b95-80b8-d7d20e20fd5f',
    },
    { gridDate: '2026-07-06' }
  ),
  'https://fareharbor.com/silentworld/dashboard/bookings/grid/2026-07-06/?overlay=%2Fcontacts%2F328584183%2Fbookings%2F7470d107-a137-4b95-80b8-d7d20e20fd5f%2F'
);

assert.strictEqual(
  resolveBookingHrefToGridOverlay(
    `/api/v1/companies/silentworld/bookings/${BOOKING_UUID}/`,
    {
      pathname: '/silentworld/dashboard/bookings/grid/2026-07-06/',
      shortname: 'silentworld',
    }
  ),
  bookingGridOverlayUrl('silentworld', `/dashboard/bookings/${BOOKING_UUID}/`)
);

// --- JUMP_TO_VIEW_TYPE mapping sanity ---

assert.strictEqual(JUMP_TO_VIEW_TYPE['channel-option'], 'ResellerOption');
assert.strictEqual(JUMP_TO_VIEW_TYPE.booking, 'Booking');

console.log('fareharbor-view-resolver: all assertions passed');

/*
 * MANUAL TEST CHECKLIST
 *
 * Prerequisite: logged into FareHarbor; extension loaded; DEV MODE optional for verbose logs.
 *
 * | Menu option      | Sample selection   | Expected resolver                         | Verify opens |
 * |------------------|--------------------|-------------------------------------------|--------------|
 * | Item             | numeric item pk    | GET .../view/Item/{id}/                   | /{shortname}/dashboard/items/{id}/ |
 * | Booking          | numeric booking id | GET .../view/Booking/{id}/                | booking dashboard (or DOM fallback) |
 * | Channel company  | rc35764 or 35764   | GET .../view/ResellerCompany/{id}/        | .../channels/{id}/ |
 * | Channel item     | 316479             | GET .../view/ResellerItem/{id}/           | .../channels/{co}/items/{id}/ |
 * | Channel option   | 896180             | GET .../view/ResellerOption/896180/       | .../options/896180/ (eatingeurope-rome) |
 *
 * Steps:
 * 1. Enable DEV MODE in popup (optional) → open service worker console.
 * 2. On any page, select an ID and use Jump to... → pick the matching type.
 * 3. Success: dashboard opens directly; no admin jump/search page flash.
 * 4. Service worker logs show raw text, normalized ID, resolver URL, hierarchy, final URL.
 * 5. Fallback: use invalid ID or log out → admin jump page opens and DOM flow runs.
 */
