#!/usr/bin/env node
"use strict";

const assert = require("assert");
const vm = require("vm");
const fs = require("fs");
const path = require("path");

function loadSharedModule() {
  const totalPricingPath = path.join(__dirname, "../content/total-pricing-resolution.js");
  const sharedPath = path.join(__dirname, "../content/affiliate-mapping-pricing-shared.js");
  const sandbox = { window: {}, console };
  vm.runInNewContext(fs.readFileSync(totalPricingPath, "utf8"), sandbox);
  vm.runInNewContext(fs.readFileSync(sharedPath, "utf8"), sandbox);
  return sandbox.window.FareHarborAffiliateMappingPricing.__test__;
}

const t = loadSharedModule();

const legacyTsvRow = [
  "ri176288",
  "277811",
  "Grutas",
  "Adult; Child; Infant"
].join("\t");
assert.strictEqual(legacyTsvRow, "ri176288\t277811\tGrutas\tAdult; Child; Infant");

assert.deepStrictEqual(t.reorderMappedCustomerTypes([
  { displayName: "Child" },
  { displayName: "Adult" },
  { displayName: "Infant" }
]).map((entry) => entry.displayName), ["Adult", "Child", "Infant"]);

assert.strictEqual(
  t.formatCustomerTypePricesCell(
    [{ name: "Adult", customerTypePk: 1 }, { name: "Child", customerTypePk: 2 }],
    { "type:1": [50], "type:2": [35] },
    "eur"
  ),
  "Adult: €50.00; Child: €35.00"
);

assert.strictEqual(
  t.formatCustomerTypePricesCell(
    [{ name: "Group", customerPrototypePk: 9 }],
    { "proto:9": [0] },
    "eur"
  ),
  "Group: €0.00"
);

assert.strictEqual(
  t.formatCustomerTypePricesCell(
    [{ name: "Adult", customerTypePk: 1 }],
    {},
    "eur"
  ),
  "Adult: unknown"
);

assert.deepStrictEqual(
  t.buildDisambiguatedSheetHeaders([
    { pk: "101", name: "Standard 2026" },
    { pk: "102", name: "Standard 2026" }
  ]),
  ["Standard 2026 [101]", "Standard 2026 [102]"]
);

assert.strictEqual(t.escapeTsvField("Name\twith\ttabs"), "Name with tabs");
assert.strictEqual(t.escapeTsvField("Line\nbreak"), "Line break");

const tsv = t.serializeTsvTable([
  ["A", "B"],
  ["1", "2"]
]);
assert.strictEqual(tsv, "A\tB\n1\t2");

assert.throws(() => {
  t.serializeTsvTable([
    ["A", "B"],
    ["1"]
  ]);
}, /row width mismatch/);

const prototype = { pk: 10, customer_type: { pk: 20, name: "Adult" } };
const pricingRows = [
  {
    customer_prototype: { pk: 10 },
    price_offset: 5000,
    price: { modifier_kind: "offset", tax_inclusion: "included" }
  }
];
const match = t.matchPricingRow(prototype, pricingRows);
assert.ok(match.row);
assert.strictEqual(t.calculateFinalPrice(match.row).finalPrice, "50.00");

assert.strictEqual(
  t.formatCurrencyAmount(12.5, "usd"),
  "$12.50"
);

assert.strictEqual(
  t.formatAggregatedPriceDisplay([10, 10, 12], "eur"),
  "€10.00 / €12.00"
);

const assignedSheet = t.resolveAssignedPricing(
  { totalPricingObject: { pk: 55, cls: "TotalSheet", display_name: "Direct" } },
  null
);
assert.strictEqual(assignedSheet.type, "sheet");
assert.strictEqual(String(assignedSheet.pk), "55");

console.log("All viator mapping pricing tests passed.");
