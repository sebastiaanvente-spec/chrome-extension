#!/usr/bin/env node
"use strict";

const assert = require("assert");
const vm = require("vm");
const fs = require("fs");
const path = require("path");

const sharedPath = path.join(
  __dirname,
  "..",
  "content",
  "affiliate-api-shared.js"
);
const generatorPath = path.join(
  __dirname,
  "..",
  "content",
  "reseller-app-map-generator.js"
);
const sharedSource = fs.readFileSync(sharedPath, "utf8");
const generatorSource = fs.readFileSync(generatorPath, "utf8");

const context = { window: {}, fetch: null, console };
vm.createContext(context);
vm.runInContext(sharedSource, context);
vm.runInContext(generatorSource, context);

const api = context.window.FareHarborAffiliateApi;
const generator = context.window.FareHarborResellerAppMapGenerator;
assert.ok(api, "FareHarborAffiliateApi should be defined");
assert.ok(generator, "FareHarborResellerAppMapGenerator should be defined");

const emptyStaticMap = {
  schemaVersion: 1,
  generatedAt: null,
  mapping: {},
  duplicates: {},
  inactiveOnly: {},
  failedApps: [],
  stats: {}
};

function resolveChannelWithStatic(
  affiliateCompanyName,
  resellerApps,
  affiliateShortname,
  staticMap
) {
  return api.resolveChannelApp(affiliateCompanyName, resellerApps, {
    affiliateShortname,
    staticMap
  });
}

function resolve(users, affiliateCompanyName) {
  return api.resolveAffiliateApiUserFromList(users, affiliateCompanyName);
}

// 1. Exact username `api` wins.
const exactApiWins = resolve(
  [
    { username: "api", name: "API", has_api_keys: true, is_inactive: false },
    {
      username: "barceloexperiencesapi",
      name: "Barcelo API",
      has_api_keys: true,
      is_inactive: false
    }
  ],
  "Barcelo Experiences - API"
);
assert.strictEqual(exactApiWins.status, "resolved");
assert.strictEqual(exactApiWins.user.username, "api");

// 2. One username containing `api` resolves.
const singleCandidate = resolve(
  [
    { username: "tiqetsapi", name: "Tiqets API", has_api_keys: true, is_inactive: false },
    { username: "support", name: "Support", has_api_keys: false, is_inactive: false }
  ],
  "Tiqets - GBP - API"
);
assert.strictEqual(singleCandidate.status, "resolved");
assert.strictEqual(singleCandidate.user.username, "tiqetsapi");

// 3. `Ctrip - EUR - API` resolves `ctripapi` over `tcapi`.
const ctripResolution = resolve(
  [
    { username: "ctripapi", name: "Ctrip API", has_api_keys: true, is_inactive: false },
    { username: "tcapi", name: "TourConnect API", has_api_keys: true, is_inactive: false }
  ],
  "Ctrip - EUR - API"
);
assert.strictEqual(ctripResolution.status, "resolved");
assert.strictEqual(ctripResolution.user.username, "ctripapi");

// 4. Candidate with `has_api_keys: false` is excluded.
const excludeFalseKeys = resolve(
  [
    { username: "ctripapi", name: "Ctrip API", has_api_keys: true, is_inactive: false },
    { username: "tcapi", name: "TourConnect API", has_api_keys: false, is_inactive: false },
    { username: "otherapi", name: "Other API", has_api_keys: true, is_inactive: false }
  ],
  "Ctrip - EUR - API"
);
assert.strictEqual(excludeFalseKeys.status, "resolved");
assert.strictEqual(excludeFalseKeys.user.username, "ctripapi");

const allWithoutKeys = resolve(
  [
    { username: "ctripapi", name: "Ctrip API", has_api_keys: false, is_inactive: false },
    { username: "tcapi", name: "TourConnect API", has_api_keys: false, is_inactive: false }
  ],
  "Ctrip - EUR - API"
);
assert.strictEqual(allWithoutKeys.status, "not_found");

// 5. Two brand-matching candidates return ambiguous.
const twoBrandMatches = resolve(
  [
    { username: "ctripapi", name: "Ctrip API", has_api_keys: true, is_inactive: false },
    { username: "ctripapi2", name: "Ctrip API 2", has_api_keys: true, is_inactive: false }
  ],
  "Ctrip - EUR - API"
);
assert.strictEqual(twoBrandMatches.status, "ambiguous");
assert.strictEqual(twoBrandMatches.errorMessage, "Multiple API users found");
assert.strictEqual(twoBrandMatches.user, null);

// 6. No brand match returns unresolved.
const noBrandMatch = resolve(
  [
    { username: "tcapi", name: "TourConnect API", has_api_keys: true, is_inactive: false },
    { username: "otherapi", name: "Other API", has_api_keys: true, is_inactive: false }
  ],
  "Ctrip - EUR - API"
);
assert.strictEqual(noBrandMatch.status, "ambiguous");
assert.strictEqual(
  noBrandMatch.errorMessage,
  "Could not reliably identify the affiliate API user"
);
assert.strictEqual(noBrandMatch.user, null);

// 7. Inactive users are excluded.
const inactiveExcluded = api.findApiUserCandidates([
  { username: "api", is_inactive: false, has_api_keys: true },
  { username: "barceloexperiencesapi", is_inactive: false, has_api_keys: true },
  { username: "inactiveapi", is_inactive: true, has_api_keys: true },
  { username: "support", is_inactive: false, has_api_keys: false }
]);
assert.deepStrictEqual(
  inactiveExcluded.map((user) => user.username),
  ["api", "barceloexperiencesapi"]
);

assert.strictEqual(api.findApiUserCandidates([]).length, 0);

assert.strictEqual(
  api.normalizeComparableName("Ctrip - EUR - API"),
  "ctrip"
);
assert.strictEqual(
  api.normalizeComparableName("Barcelo Experiences - API"),
  "barceloexperiences"
);

assert.strictEqual(
  api.parseCalendarTokenFromUserRecord({
    username: "api",
    calendar_token: "917e7737-017d-4367-9ca4-4eaae541f365"
  }),
  "917e7737-017d-4367-9ca4-4eaae541f365"
);

assert.strictEqual(
  api.parseAffiliateApiKeyFromUserResponse({
    user: {
      username: "barceloexperiencesapi",
      calendar_token: "abc-123"
    }
  }),
  "abc-123"
);

const channelResolved = api.resolveChannelApp("Tiqets - GBP - API", [
  { pk: 131, name: "Tiqets", key: "channel-key", is_inactive: false }
]);
assert.strictEqual(channelResolved.status, "resolved");
assert.strictEqual(channelResolved.matchType, "exact_name");
assert.strictEqual(channelResolved.key, "channel-key");

const ctripChannelResolved = api.resolveChannelApp("Ctrip - EUR - API", [
  {
    pk: 522,
    name: "Ctrip (Trip.com)",
    short_name: "",
    key: "ctrip-channel-key",
    is_inactive: false
  },
  {
    pk: 999,
    name: "Other App",
    short_name: "",
    key: "other-key",
    is_inactive: false
  }
]);
assert.strictEqual(ctripChannelResolved.status, "resolved");
assert.strictEqual(ctripChannelResolved.matchType, "leading_name");
assert.strictEqual(ctripChannelResolved.appPk, 522);
assert.strictEqual(ctripChannelResolved.appName, "Ctrip (Trip.com)");
assert.strictEqual(ctripChannelResolved.key, "ctrip-channel-key");

assert.strictEqual(api.normalizeAffiliateBrand("Ctrip - EUR - API"), "ctrip");
assert.strictEqual(
  api.normalizeAppComparable("Ctrip (Trip.com)"),
  "ctriptripcom"
);

const inactiveChannel = api.resolveChannelApp("Tiqets - GBP - API", [
  { pk: 131, name: "Tiqets", key: "channel-key", is_inactive: true }
]);
assert.strictEqual(inactiveChannel.status, "inactive");

const ambiguousChannel = api.resolveChannelApp("Ctrip - EUR - API", [
  { pk: 521, name: "Ctrip One", key: "key-one", is_inactive: false },
  { pk: 522, name: "Ctrip Two", key: "key-two", is_inactive: false }
]);
assert.strictEqual(ambiguousChannel.status, "ambiguous");

const safeMetadata = resolve(
  [
    { username: "ctripapi", name: "Ctrip API", has_api_keys: true, is_inactive: false },
    { username: "tcapi", name: "TourConnect API", has_api_keys: true, is_inactive: false }
  ],
  "Ctrip - EUR - API"
).candidates;
assert.deepStrictEqual(safeMetadata, [
  { username: "ctripapi", name: "Ctrip API", hasApiKeys: true },
  { username: "tcapi", name: "TourConnect API", hasApiKeys: true }
]);
assert.ok(
  !JSON.stringify(safeMetadata).includes("calendar_token"),
  "candidate metadata must not expose calendar_token"
);

assert.strictEqual(
  api.normalizeMappingShortname(" Hotelbeds-EUR "),
  "hotelbeds-eur"
);

const hotelbedsApps = [
  {
    pk: 49,
    name: "Redeam (Travel Curious)",
    short_name: "",
    key: "redeam-channel-key",
    is_inactive: false
  },
  {
    pk: 131,
    name: "Tiqets",
    key: "tiqets-key",
    is_inactive: false
  }
];
const hotelbedsStaticMap = {
  ...emptyStaticMap,
  mapping: { hotelbedseuro: 49 }
};

const hotelbedsResolved = resolveChannelWithStatic(
  "Hotelbeds - EUR - API",
  hotelbedsApps,
  "hotelbedseuro",
  hotelbedsStaticMap
);
assert.strictEqual(hotelbedsResolved.status, "resolved");
assert.strictEqual(hotelbedsResolved.matchType, "static_shortname_mapping");
assert.strictEqual(hotelbedsResolved.appPk, 49);
assert.strictEqual(hotelbedsResolved.appName, "Redeam (Travel Curious)");
assert.strictEqual(hotelbedsResolved.key, "redeam-channel-key");

const staticPriority = resolveChannelWithStatic(
  "Tiqets - GBP - API",
  hotelbedsApps,
  "hotelbedseuro",
  hotelbedsStaticMap
);
assert.strictEqual(staticPriority.status, "resolved");
assert.strictEqual(staticPriority.matchType, "static_shortname_mapping");
assert.strictEqual(staticPriority.appPk, 49);

const staticMappingApi = api.resolveChannelAppFromStaticMapping({
  affiliateShortname: "hotelbedseuro",
  resellerApps: hotelbedsApps,
  database: hotelbedsStaticMap,
  affiliateCompanyName: "Hotelbeds - EUR - API"
});
assert.strictEqual(staticMappingApi.status, "resolved");
assert.strictEqual(staticMappingApi.matchType, "static_shortname_mapping");
assert.strictEqual(staticMappingApi.appPk, 49);
assert.strictEqual(staticMappingApi.appName, "Redeam (Travel Curious)");

const duplicateStaticMap = {
  ...emptyStaticMap,
  duplicates: { examplecompany: [49, 122] }
};
const duplicateResolved = resolveChannelWithStatic(
  "Example Company - API",
  hotelbedsApps,
  "examplecompany",
  duplicateStaticMap
);
assert.strictEqual(duplicateResolved.status, "ambiguous");
assert.strictEqual(
  duplicateResolved.errorMessage,
  "Multiple Channel app relationships found"
);

const fallbackResolved = resolveChannelWithStatic(
  "Tiqets - GBP - API",
  hotelbedsApps,
  "tiqets",
  emptyStaticMap
);
assert.strictEqual(fallbackResolved.status, "resolved");
assert.strictEqual(fallbackResolved.matchType, "name_fallback");
assert.strictEqual(fallbackResolved.appPk, 131);

const outdatedResolved = resolveChannelWithStatic(
  "Hotelbeds - EUR - API",
  hotelbedsApps,
  "hotelbedseuro",
  {
    ...emptyStaticMap,
    mapping: { hotelbedseuro: 999 }
  }
);
assert.strictEqual(outdatedResolved.status, "unresolved");
assert.strictEqual(
  outdatedResolved.errorMessage,
  "Stored Channel app mapping is outdated"
);

const inactiveMappedResolved = resolveChannelWithStatic(
  "Hotelbeds - EUR - API",
  [
    {
      pk: 49,
      name: "Redeam (Travel Curious)",
      key: "redeam-channel-key",
      is_inactive: true
    }
  ],
  "hotelbedseuro",
  hotelbedsStaticMap
);
assert.strictEqual(inactiveMappedResolved.status, "inactive");
assert.strictEqual(
  inactiveMappedResolved.errorMessage,
  "Stored Channel app mapping points to an inactive app"
);

const missingKeyResolved = resolveChannelWithStatic(
  "Hotelbeds - EUR - API",
  [
    {
      pk: 49,
      name: "Redeam (Travel Curious)",
      key: "",
      is_inactive: false
    }
  ],
  "hotelbedseuro",
  hotelbedsStaticMap
);
assert.strictEqual(missingKeyResolved.status, "unresolved");
assert.strictEqual(
  missingKeyResolved.errorMessage,
  "Channel app key unavailable"
);

const mappingNotFound = resolveChannelWithStatic(
  "Unknown Affiliate - API",
  hotelbedsApps,
  "unknownaffiliate",
  emptyStaticMap
);
assert.strictEqual(mappingNotFound.status, "unresolved");
assert.strictEqual(
  mappingNotFound.errorMessage,
  "Channel app mapping not found"
);

const builtMap = generator.buildResellerAppCompanyMap({
  apps: [
    { pk: 49, is_inactive: false },
    { pk: 88, is_inactive: true },
    { pk: 122, is_inactive: false }
  ],
  relationshipsByPk: {
    49: [
      {
        company: { shortname: "hotelbedseuro", name: "Hotelbeds - EUR - API" },
        reseller_app: { pk: 49 }
      },
      {
        company: { shortname: "examplecompany", name: "Example Company" },
        reseller_app: { pk: 49 }
      }
    ],
    88: [
      {
        company: { shortname: "oldcompany", name: "Old Company" },
        reseller_app: { pk: 88 }
      }
    ],
    122: [
      {
        company: { shortname: "examplecompany", name: "Example Company" },
        reseller_app: { pk: 122 }
      }
    ]
  },
  failedApps: [{ pk: 123, status: 403 }]
});

assert.strictEqual(builtMap.mapping.hotelbedseuro, 49);
assert.deepStrictEqual(builtMap.duplicates.examplecompany.sort(), [49, 122]);
assert.deepStrictEqual(builtMap.inactiveOnly.oldcompany, [88]);
assert.strictEqual(builtMap.stats.relationshipsFound, 4);
assert.strictEqual(builtMap.stats.duplicatesFound, 1);

const sanitizedMap = generator.sanitizeGeneratedMapForDownload(builtMap);
const forbiddenPattern = /"(key|calendar_token|cookie|token)"/;
assert.ok(
  !forbiddenPattern.test(JSON.stringify(sanitizedMap)),
  "generated map must not contain sensitive fields"
);

assert.throws(() => {
  generator.sanitizeGeneratedMapForDownload({
    ...builtMap,
    stats: { token: "bad" }
  });
}, /forbidden fields/);

console.log("affiliate-api-credentials: all assertions passed");
