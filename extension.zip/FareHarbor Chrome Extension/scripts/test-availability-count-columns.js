const assert = require("assert");

const COLUMN_ATTR = "data-fh-availability-count-column";

function createNode(tagName, attrs = {}) {
  const node = {
    tagName: String(tagName).toUpperCase(),
    attrs: { ...attrs },
    children: [],
    parentElement: null,
    getAttribute(name) {
      return Object.prototype.hasOwnProperty.call(this.attrs, name)
        ? this.attrs[name]
        : null;
    },
    setAttribute(name, value) {
      this.attrs[name] = String(value);
    },
    matches(selector) {
      return selector
        .split(",")
        .map((part) => part.trim().toLowerCase())
        .includes(this.tagName.toLowerCase());
    },
    closest(selector) {
      const attrMatch = selector.match(/^\[([^=]+)="([^"]+)"\]$/);
      let current = this;
      while (current) {
        if (
          attrMatch &&
          current.getAttribute(attrMatch[1]) === attrMatch[2]
        ) {
          return current;
        }
        if (current.matches?.(selector)) {
          return current;
        }
        current = current.parentElement;
      }
      return null;
    },
    get lastElementChild() {
      return this.children.length
        ? this.children[this.children.length - 1]
        : null;
    },
    querySelector(selector) {
      if (selector === "thead tr") {
        const thead = this.children.find((child) => child.tagName === "THEAD");
        return (
          thead?.children.find((child) => child.tagName === "TR") || null
        );
      }
      const attrOnly = selector.match(/^\[([^=]+)="([^"]+)"\]$/);
      const stack = [...this.children];
      while (stack.length) {
        const child = stack.shift();
        if (
          attrOnly &&
          child.getAttribute(attrOnly[1]) === attrOnly[2]
        ) {
          return child;
        }
        if (child.matches?.(selector)) {
          return child;
        }
        stack.push(...child.children);
      }
      return null;
    },
    querySelectorAll(selector) {
      if (selector !== "tbody tr") {
        const one = this.querySelector(selector);
        return one ? [one] : [];
      }
      const rows = [];
      for (const child of this.children) {
        if (child.tagName === "TBODY") {
          rows.push(...child.children.filter((row) => row.tagName === "TR"));
        }
      }
      return rows;
    },
    appendChild(child) {
      child.parentElement = this;
      this.children.push(child);
      return child;
    }
  };
  // Match the content-script check: node instanceof Element
  Object.setPrototypeOf(node, Element.prototype);
  return node;
}

if (typeof Element === "undefined") {
  global.Element = class Element {};
}

function isExtensionNode(node, columnAttr = COLUMN_ATTR) {
  if (!(node instanceof Element)) {
    const parent = node?.parentElement;
    return parent ? isExtensionNode(parent, columnAttr) : false;
  }
  if (node.getAttribute(columnAttr) === "true") {
    return true;
  }
  return !!node.closest?.(`[${columnAttr}="true"]`);
}

function isStructuralTableNode(node) {
  if (!(node instanceof Element)) {
    return false;
  }
  return !!(
    node.matches?.("tr, table, tbody, thead, td, th") ||
    node.querySelector?.("tr, table, tbody, thead, td, th")
  );
}

function isExtensionMutation(mutation, options = {}) {
  const columnAttr = options.columnAttr || COLUMN_ATTR;
  const availabilitySortInProgress = !!options.availabilitySortInProgress;
  const extensionNode = (node) => isExtensionNode(node, columnAttr);

  if (availabilitySortInProgress) {
    return true;
  }

  for (const node of mutation.addedNodes) {
    if (!(node instanceof Element) || extensionNode(node)) {
      continue;
    }
    if (isStructuralTableNode(node)) {
      return false;
    }
  }

  for (const node of mutation.removedNodes) {
    if (!(node instanceof Element)) {
      continue;
    }
    if (extensionNode(node)) {
      if (
        mutation.target instanceof Element &&
        !extensionNode(mutation.target)
      ) {
        return false;
      }
      continue;
    }
    if (isStructuralTableNode(node)) {
      return false;
    }
  }

  if (extensionNode(mutation.target)) {
    return true;
  }
  for (const node of mutation.addedNodes) {
    if (extensionNode(node)) {
      return true;
    }
  }
  for (const node of mutation.removedNodes) {
    if (extensionNode(node)) {
      return true;
    }
  }
  return false;
}

function tableHasAvailabilityColumn(table, columnAttr = COLUMN_ATTR) {
  if (!table) {
    return true;
  }
  const headerRow = table.querySelector("thead tr");
  if (!headerRow?.querySelector(`[${columnAttr}="true"]`)) {
    return false;
  }
  for (const row of table.querySelectorAll("tbody tr")) {
    if (!row.lastElementChild) {
      continue;
    }
    if (!row.querySelector(`[${columnAttr}="true"]`)) {
      return false;
    }
  }
  return true;
}

function areAvailabilityColumnsReady(
  customerTypesTable,
  optionsTable,
  columnAttr = COLUMN_ATTR
) {
  if (!customerTypesTable && !optionsTable) {
    return false;
  }
  return (
    tableHasAvailabilityColumn(customerTypesTable, columnAttr) &&
    tableHasAvailabilityColumn(optionsTable, columnAttr)
  );
}

// --- isExtensionMutation ---
{
  const row = createNode("tr");
  const ourCell = createNode("td", { [COLUMN_ATTR]: "true" });
  row.appendChild(ourCell);

  assert.strictEqual(
    isExtensionMutation({
      target: row,
      addedNodes: [ourCell],
      removedNodes: []
    }),
    true,
    "injecting our column cell should be ignorable"
  );

  assert.strictEqual(
    isExtensionMutation({
      target: row,
      addedNodes: [],
      removedNodes: [ourCell]
    }),
    false,
    "Angular wiping our cell from a normal row must rescan"
  );

  const table = createNode("table");
  table.appendChild(createNode("tr"));
  assert.strictEqual(
    isExtensionMutation({
      target: createNode("div"),
      addedNodes: [table],
      removedNodes: []
    }),
    false,
    "new table structure must rescan"
  );

  assert.strictEqual(
    isExtensionMutation(
      {
        target: row,
        addedNodes: [],
        removedNodes: [ourCell]
      },
      { availabilitySortInProgress: true }
    ),
    true,
    "availability sort mutations stay ignorable"
  );
}

// --- column readiness ---
{
  assert.strictEqual(areAvailabilityColumnsReady(null, null), false);

  const readyTable = createNode("table");
  const thead = createNode("thead");
  const headerRow = createNode("tr");
  headerRow.appendChild(createNode("th", { [COLUMN_ATTR]: "true" }));
  headerRow.appendChild(createNode("th"));
  thead.appendChild(headerRow);
  readyTable.appendChild(thead);

  const tbody = createNode("tbody");
  const bodyRow = createNode("tr");
  bodyRow.appendChild(createNode("td", { [COLUMN_ATTR]: "true" }));
  bodyRow.appendChild(createNode("td"));
  tbody.appendChild(bodyRow);
  readyTable.appendChild(tbody);

  assert.strictEqual(tableHasAvailabilityColumn(readyTable), true);
  assert.strictEqual(areAvailabilityColumnsReady(readyTable, null), true);

  const missingBody = createNode("table");
  const missingHead = createNode("thead");
  const missingHeaderRow = createNode("tr");
  missingHeaderRow.appendChild(createNode("th", { [COLUMN_ATTR]: "true" }));
  missingHead.appendChild(missingHeaderRow);
  missingBody.appendChild(missingHead);
  const missingTbody = createNode("tbody");
  const plainRow = createNode("tr");
  plainRow.appendChild(createNode("td"));
  missingTbody.appendChild(plainRow);
  missingBody.appendChild(missingTbody);

  assert.strictEqual(tableHasAvailabilityColumn(missingBody), false);
  assert.strictEqual(areAvailabilityColumnsReady(missingBody, null), false);
}

console.log("test-availability-count-columns: all tests passed");
