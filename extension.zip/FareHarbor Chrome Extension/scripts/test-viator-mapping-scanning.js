#!/usr/bin/env node
"use strict";

/**
 * Shared FareHarborAffiliateMappingPricing scanning helpers.
 * Ticket Scanning UI column uses equivalent logic in ticket-scanning-channel-items.js;
 * these helpers remain available for reuse and are covered here.
 */

const assert = require("assert");
const vm = require("vm");
const fs = require("fs");
const path = require("path");

function loadSharedModule() {
  const totalPricingPath = path.join(__dirname, "../content/total-pricing-resolution.js");
  const sharedPath = path.join(__dirname, "../content/affiliate-mapping-pricing-shared.js");
  const sandbox = { window: {}, console };
  vm.runInNewContext(fs.readFileSync(totalPricingPath, "utf8"), sandbox);
  vm.runInNewContext(fs.readFileSync(sharedPath, "utf8"), sandbox);
  return {
    api: sandbox.window.FareHarborAffiliateMappingPricing,
    t: sandbox.window.FareHarborAffiliateMappingPricing.__test__
  };
}

const { api, t } = loadSharedModule();

assert.strictEqual(t.formatTicketScanningValue(true), "Yes");
assert.strictEqual(t.formatTicketScanningValue(false), "No");
assert.strictEqual(t.formatTicketScanningValue(undefined), "Unknown");
assert.strictEqual(t.formatTicketScanningValue(null), "Unknown");
assert.strictEqual(api.formatTicketScanningValue(true), "Yes");

const lookup = t.buildScanningLookupFromItems([
  { pk: 512290, name: "Tour A", is_scanning_enabled: true },
  { pk: 512291, name: "Tour B", is_scanning_enabled: false },
  { pk: 512292, name: "Tour C" },
  { pk: 512293, name: "Tour D", is_scanning_enabled: "yes" },
  { name: "No PK", is_scanning_enabled: true }
]);

assert.strictEqual(lookup.get("512290"), true);
assert.strictEqual(lookup.get("512291"), false);
assert.strictEqual(lookup.has("512292"), false);
assert.strictEqual(lookup.has("512293"), false);
assert.strictEqual(t.formatTicketScanningValue(lookup.get("999999")), "Unknown");
assert.strictEqual(t.ITEMS_SCANNING_PAGE_SIZE, 1000);

console.log("All shared ticket-scanning helper tests passed.");
