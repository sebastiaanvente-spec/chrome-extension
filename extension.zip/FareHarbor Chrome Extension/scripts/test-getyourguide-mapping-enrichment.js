#!/usr/bin/env node
"use strict";

const assert = require("assert");

function isBlankValue(value) {
  return value === null || value === undefined || value === "";
}

function toNumberOrNull(value) {
  if (isBlankValue(value)) return null;
  const num = Number(value);
  return Number.isNaN(num) ? null : num;
}

function pickHighest(...values) {
  const nums = values.map(toNumberOrNull).filter((n) => n !== null);
  return nums.length ? Math.max(...nums) : null;
}

function pickLowest(...values) {
  const nums = values.map(toNumberOrNull).filter((n) => n !== null);
  return nums.length ? Math.min(...nums) : null;
}

function calculateTotalAvailabilityCapacity(availability) {
  if (!availability) {
    return { total: null, customerCount: null, bookableCapacity: null, sampleWarning: null };
  }

  const rawCustomerCount = availability.customer_count ?? availability.customerCount;
  const bookableCapacity = toNumberOrNull(
    availability.bookable_capacity ?? availability.bookableCapacity
  );

  if (bookableCapacity === null) {
    return {
      total: null,
      customerCount: toNumberOrNull(rawCustomerCount),
      bookableCapacity: null,
      sampleWarning: "bookable_capacity missing; total capacity not calculated"
    };
  }

  let customerCount = toNumberOrNull(rawCustomerCount);
  let sampleWarning = null;
  if (customerCount === null) {
    customerCount = 0;
    sampleWarning = "customer_count missing; assumed 0 for total capacity calculation";
  }

  return {
    total: customerCount + bookableCapacity,
    customerCount,
    bookableCapacity,
    sampleWarning
  };
}

function calculateEffectiveMin(item, prototype) {
  return pickHighest(
    item?.minimum_initial_party_size,
    item?.minimum_subsequent_party_size,
    prototype?.minimum_party_size,
    prototype?.minimum_group_size
  );
}

function extractNestedArray(data, pluralKey) {
  if (!data) return [];
  const container = data[pluralKey];
  if (Array.isArray(container)) return container;
  if (container && Array.isArray(container.items)) return container.items;
  if (Array.isArray(data)) return data;
  return [];
}

function isActiveRecord(record) {
  if (!record || typeof record !== "object") return false;
  if (record.is_inactive === true || record.isInactive === true) return false;
  if (record.is_active === false || record.isActive === false) return false;
  return true;
}

function getRequirementGroupPk(group) {
  return group?.pk ?? group?.requirement_group?.pk ?? null;
}

function getRequirementsFromGroup(group) {
  const reqs = group?.requirements;
  if (Array.isArray(reqs)) return reqs;
  if (reqs && Array.isArray(reqs.items)) return reqs.items;
  return [];
}

function normalizeResourceRequirementsList(resourceReqs) {
  if (Array.isArray(resourceReqs)) return resourceReqs;
  if (resourceReqs && Array.isArray(resourceReqs.items)) return resourceReqs.items;
  return [];
}

function deriveResourceCapacity(requirementGroups, resourceRequirementsByKey, resources) {
  const resourceByPk = new Map();
  for (const resource of resources || []) {
    const pk = resource?.pk;
    if (pk !== null && pk !== undefined) {
      resourceByPk.set(String(pk), resource);
    }
  }

  const entries = [];
  const activeCapacities = [];
  const archivedCapacities = [];

  for (const group of requirementGroups || []) {
    if (!isActiveRecord(group)) continue;

    const groupPk = getRequirementGroupPk(group);
    const groupName = group?.name ?? group?.unicode ?? null;
    const usedForBookableCapacity =
      group?.is_used_for_bookable_capacity ?? group?.isUsedForBookableCapacity ?? null;

    for (const requirement of getRequirementsFromGroup(group)) {
      if (!isActiveRecord(requirement)) continue;

      const requirementPk = requirement?.pk;
      const requirementType = requirement?.type ?? "unknown";
      const mapKey = `${groupPk}:${requirementPk}`;

      let resourceReqs = normalizeResourceRequirementsList(requirement?.resource_requirements);
      if (resourceReqs.length === 0 && resourceRequirementsByKey) {
        resourceReqs = resourceRequirementsByKey.get(mapKey) || [];
      }

      for (const rawResourceReq of resourceReqs) {
        const resourceRequirement = rawResourceReq?.resource_requirement ?? rawResourceReq;
        const useCount = toNumberOrNull(
          resourceRequirement?.use_count ?? resourceRequirement?.useCount
        );
        const resourceRef = resourceRequirement?.resource ?? {};
        const resourcePk =
          resourceRef?.pk ??
          resourceRequirement?.resource_pk ??
          resourceRequirement?.resourcePk ??
          null;
        const matchedResource =
          resourcePk !== null && resourcePk !== undefined
            ? resourceByPk.get(String(resourcePk))
            : null;
        const resourceMaximumUseCount = toNumberOrNull(
          matchedResource?.maximum_use_count ??
            matchedResource?.maximumUseCount ??
            resourceRef?.maximum_use_count ??
            resourceRef?.maximumUseCount
        );
        const isArchived = Boolean(
          matchedResource?.is_archived ?? matchedResource?.isArchived ?? false
        );

        const entry = {
          requirementGroupPk: groupPk,
          requirementGroupName: groupName,
          usedForBookableCapacity,
          requirementPk,
          requirementType,
          resourcePk,
          resourceName: matchedResource?.name ?? resourceRef?.name ?? null,
          resourceMaximumUseCount,
          requirementUseCount: useCount,
          derivedResourceCapacity: null,
          isArchived
        };

        if (
          resourceMaximumUseCount !== null &&
          resourceMaximumUseCount > 0 &&
          useCount !== null &&
          useCount > 0
        ) {
          entry.derivedResourceCapacity = Math.floor(resourceMaximumUseCount / useCount);
          if (!isArchived) {
            activeCapacities.push(entry.derivedResourceCapacity);
          } else {
            archivedCapacities.push(entry.derivedResourceCapacity);
          }
        }

        entries.push(entry);
      }
    }
  }

  let selectedCapacity = null;
  if (activeCapacities.length > 0) {
    selectedCapacity = Math.min(...activeCapacities);
  } else if (archivedCapacities.length > 0) {
    selectedCapacity = Math.min(...archivedCapacities);
  }

  return { entries, selectedCapacity };
}

function normalizeAffiliateNameForMatch(name) {
  return String(name ?? "")
    .toLowerCase()
    .replace(/[\s\-_]/g, "");
}

function isGetYourGuideAffiliate(affiliate) {
  const ac = affiliate?.affiliate_company ?? affiliate?.affiliateCompany ?? {};
  const shortname = String(ac.shortname ?? "").toLowerCase();
  const name = String(ac.name ?? "");
  const normalizedName = normalizeAffiliateNameForMatch(name);
  const unicode = String(ac.unicode ?? "");
  return (
    shortname.includes("getyourguide") ||
    name === "GetYourGuide" ||
    name.includes("GetYourGuide") ||
    normalizedName.includes("getyourguide") ||
    unicode.includes("GetYourGuide")
  );
}

function getPricingObjectPk(pricingObject) {
  if (!pricingObject || typeof pricingObject !== "object") return null;
  if (pricingObject.pk !== null && pricingObject.pk !== undefined) {
    return pricingObject.pk;
  }
  const uri = String(pricingObject.uri ?? "");
  const sheetMatch = uri.match(/total-sheets\/(\d+)/i);
  if (sheetMatch) return sheetMatch[1];
  const scheduleMatch = uri.match(/total-schedules\/(\d+)/i);
  if (scheduleMatch) return scheduleMatch[1];
  return null;
}

function getPricingObjectType(pricingObject) {
  if (!pricingObject || typeof pricingObject !== "object") return null;
  const cls = String(pricingObject.cls ?? "").trim();
  if (cls === "TotalSheet" || cls === "total_sheet" || cls === "Total Sheet") {
    return "sheet";
  }
  if (cls === "TotalSchedule" || cls === "total_schedule" || cls === "Total Schedule") {
    return "schedule";
  }
  const uri = String(pricingObject.uri ?? "");
  if (uri.includes("/total-sheets/")) return "sheet";
  if (uri.includes("/total-schedules/")) return "schedule";
  return null;
}

function isAssignedPricingObject(pricingObject) {
  if (!pricingObject || typeof pricingObject !== "object") return false;
  return getPricingObjectPk(pricingObject) != null || Boolean(pricingObject.uri);
}

function resolveAssignedPricing(affiliateListRow, affiliationDetail) {
  const candidates = [
    {
      source: "totalPricingObject",
      obj: affiliateListRow?.totalPricingObject ?? affiliateListRow?.total_pricing_object ?? null
    },
    {
      source: "default_total_sheet",
      obj: affiliationDetail?.default_total_sheet ?? affiliationDetail?.defaultTotalSheet ?? null
    },
    {
      source: "default_total_schedule",
      obj: affiliationDetail?.default_total_schedule ?? affiliationDetail?.defaultTotalSchedule ?? null
    }
  ];

  for (const candidate of candidates) {
    if (!isAssignedPricingObject(candidate.obj)) continue;
    return {
      pricingObject: candidate.obj,
      type: getPricingObjectType(candidate.obj),
      pk: getPricingObjectPk(candidate.obj),
      source: candidate.source
    };
  }

  return null;
}

function analyzeCapacitySamples(samples) {
  const validSamples = (samples || []).filter(
    (sample) => sample.totalCapacity !== null && sample.totalCapacity !== undefined
  );

  if (validSamples.length === 0) {
    return {
      selectedFallbackCapacity: null,
      capacitySampleWarning: null,
      uniform: false
    };
  }

  const uniqueTotals = [...new Set(validSamples.map((sample) => sample.totalCapacity))];
  if (uniqueTotals.length === 1) {
    return {
      selectedFallbackCapacity: uniqueTotals[0],
      capacitySampleWarning: null,
      uniform: true
    };
  }

  const minCap = Math.min(...uniqueTotals);
  const maxCap = Math.max(...uniqueTotals);

  return {
    selectedFallbackCapacity: null,
    capacitySampleWarning: `Multiple capacities detected (${minCap}–${maxCap}). This item appears to use different capacities across availabilities.`,
    uniform: false
  };
}

function getPrototypeCustomerType(prototype) {
  return prototype?.customer_type ?? prototype?.customerType ?? {};
}

function getPricingRowPrototype(row) {
  return row?.customer_prototype ?? row?.customerPrototype ?? row?.for_object ?? row?.forObject ?? null;
}

function getPricingRowCustomerType(row) {
  return row?.customer_type ?? row?.customerType ?? getPrototypeCustomerType(getPricingRowPrototype(row) || {});
}

function identifiersMatch(a, b) {
  if (a === null || a === undefined || b === null || b === undefined) return false;
  return String(a) === String(b);
}

function isValidCapacityCandidate(value) {
  const num = toNumberOrNull(value);
  return num !== null && num > 0;
}

function getCustomerTypeRatesFromAvailability(availability) {
  const rates = availability?.customer_type_rates ?? availability?.customerTypeRates;
  if (Array.isArray(rates)) return rates;
  if (rates && Array.isArray(rates.items)) return rates.items;
  return [];
}

function extractAvailabilityCapacityDetails(availability) {
  const pk = availability?.pk ?? availability?.id ?? null;
  return {
    availabilityPk: pk,
    startAt: availability?.start_at ?? availability?.startAt ?? null,
    capacity: toNumberOrNull(availability?.capacity),
    nonResourceBookableCapacity: toNumberOrNull(
      availability?.non_resource_bookable_capacity ?? availability?.nonResourceBookableCapacity
    ),
    blocksIncludedNonResourceBookableCapacity: toNumberOrNull(
      availability?.blocks_included_non_resource_bookable_capacity ??
        availability?.blocksIncludedNonResourceBookableCapacity
    ),
    customerTypeRates: getCustomerTypeRatesFromAvailability(availability).map((rate) => {
      const prototype = rate?.customer_prototype ?? rate?.customerPrototype ?? {};
      return {
        prototypePk: prototype?.pk ?? null,
        prototypeName:
          prototype?.display_name ??
          prototype?.displayName ??
          prototype?.name ??
          rate?.unicode ??
          null,
        capacity: toNumberOrNull(rate?.capacity),
        minimumPartySize: toNumberOrNull(rate?.minimum_party_size ?? rate?.minimumPartySize),
        maximumPartySize: toNumberOrNull(rate?.maximum_party_size ?? rate?.maximumPartySize),
        capacityRemaining: toNumberOrNull(rate?.capacity_remaining ?? rate?.capacityRemaining)
      };
    })
  };
}

function matchCustomerTypeRateToMapping(rate, prototype) {
  if (!prototype || !rate) return false;
  const ratePrototype = rate?.customer_prototype ?? rate?.customerPrototype ?? rate;
  const ratePk = ratePrototype?.pk ?? rate?.prototypePk ?? null;
  return identifiersMatch(ratePk, prototype?.pk);
}

function isPresentNumericValue(value) {
  const num = toNumberOrNull(value);
  return num !== null;
}

function hasUsefulMatchedRateFields(matches) {
  for (const match of matches || []) {
    if (isPresentNumericValue(match.capacity)) return true;
    if (isPresentNumericValue(match.minimumPartySize)) return true;
    if (isPresentNumericValue(match.maximumPartySize)) return true;
    if (isPresentNumericValue(match.capacityRemaining)) return true;
  }
  return false;
}

function buildAvailabilityDetailFetchSummary(fetchedCount, totalSampled, noteKey) {
  const summary = {
    fetchedCount,
    totalSampled,
    noteKey,
    message: null
  };

  if (noteKey === "additional_fetched") {
    summary.message = `Fetched ${fetchedCount} of ${totalSampled} sampled availability details.\nAdditional details fetched because per-customer-type capacity/min/max values were found.`;
  } else if (noteKey === "skipped_no_useful_first") {
    summary.message = `Fetched ${fetchedCount} of ${totalSampled} sampled availability details.\nSkipped remaining details because the first matched availability detail had no per-customer-type capacity/min/max values.`;
  } else if (noteKey === "skipped_after_retry") {
    summary.message = `Fetched ${fetchedCount} of ${totalSampled} sampled availability details.\nSkipped remaining details because no useful matched customer type rate values were found after retrying a second sampled availability.`;
  } else if (fetchedCount > 0) {
    summary.message = `Fetched ${fetchedCount} of ${totalSampled} sampled availability details.`;
  }

  return summary;
}

function selectSmallestSampledValue(values) {
  const valid = (values || []).map(toNumberOrNull).filter((v) => isValidCapacityCandidate(v));
  if (valid.length === 0) {
    return { selected: null, sampled: [], uniform: false };
  }
  const unique = [...new Set(valid)];
  return {
    selected: Math.min(...valid),
    sampled: valid,
    uniform: unique.length === 1
  };
}

function selectLargestSampledValue(values) {
  const valid = (values || []).map(toNumberOrNull).filter((v) => isValidCapacityCandidate(v));
  if (valid.length === 0) {
    return { selected: null, sampled: [], uniform: false };
  }
  const unique = [...new Set(valid)];
  return {
    selected: Math.max(...valid),
    sampled: valid,
    uniform: unique.length === 1
  };
}

function calculateGroupedMappedCustomerTypeMin(item, prototypes) {
  const mins = (prototypes || [])
    .map((prototype) => calculateEffectiveMin(item, prototype))
    .map(toNumberOrNull)
    .filter((value) => value !== null);
  return mins.length ? Math.min(...mins) : null;
}

function calculateGroupedMappedCustomerTypeMax(prototypes) {
  const maxes = [];
  for (const prototype of prototypes || []) {
    for (const field of [
      prototype?.maximum_party_size,
      prototype?.maximum_group_size,
      prototype?.capacity
    ]) {
      if (isValidCapacityCandidate(field)) {
        maxes.push(toNumberOrNull(field));
      }
    }
  }
  return maxes.length ? Math.max(...maxes) : null;
}

function dedupePreservingOrder(values) {
  const seen = new Set();
  const result = [];
  for (const value of values || []) {
    if (value === null || value === undefined) continue;
    const key = String(value);
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(value);
  }
  return result;
}

function collectCapacityCandidates({
  item,
  prototype,
  prototypes,
  resourceDerivedCapacity,
  availabilityDetailMatches,
  pollingFallbackCapacity
}) {
  const prototypeList =
    prototypes?.length > 0 ? prototypes : prototype ? [prototype] : [];
  const isGroupedMappedCustomerTypes = prototypeList.length > 1;
  const candidates = [];

  function addCandidate(value, source) {
    if (!isValidCapacityCandidate(value)) return;
    candidates.push({ value: toNumberOrNull(value), source });
  }

  if (prototypeList.length > 1) {
    const groupedMappedMax = calculateGroupedMappedCustomerTypeMax(prototypeList);
    addCandidate(groupedMappedMax, "mapped customer type maximum");
  } else if (prototypeList.length === 1) {
    const singlePrototype = prototypeList[0];
    addCandidate(singlePrototype.maximum_party_size, "customer prototype maximum_party_size");
    addCandidate(singlePrototype.maximum_group_size, "customer prototype maximum_group_size");
    addCandidate(singlePrototype.capacity, "customer prototype capacity");
  }

  if (item) {
    addCandidate(item.maximum_initial_party_size, "item maximum_initial_party_size");
    addCandidate(item.maximum_subsequent_party_size, "item maximum_subsequent_party_size");
  }

  addCandidate(resourceDerivedCapacity, "resource requirement endpoint");

  const rateCapacitySelection = selectSmallestSampledValue(
    (availabilityDetailMatches || []).map((match) => match.capacity)
  );
  if (rateCapacitySelection.selected !== null) {
    candidates.push({
      value: rateCapacitySelection.selected,
      source: "availability customer_type_rates.capacity"
    });
  }

  const perBookingMinSelection = selectSmallestSampledValue(
    (availabilityDetailMatches || []).map((match) => match.minimumPartySize)
  );
  const perBookingMaxSelection = isGroupedMappedCustomerTypes
    ? selectLargestSampledValue(
        (availabilityDetailMatches || []).map((match) => match.maximumPartySize)
      )
    : selectSmallestSampledValue(
        (availabilityDetailMatches || []).map((match) => match.maximumPartySize)
      );
  if (perBookingMaxSelection.selected !== null) {
    candidates.push({
      value: perBookingMaxSelection.selected,
      source: "availability customer_type_rates.maximum_party_size"
    });
  }

  addCandidate(pollingFallbackCapacity, "availability endpoint");

  const availabilityPerBookingMinimum = perBookingMinSelection.selected;
  const availabilityPerBookingMaximum = perBookingMaxSelection.selected;

  const matchMethod =
    availabilityDetailMatches && availabilityDetailMatches.length > 0
      ? "customer_prototype.pk"
      : null;

  if (candidates.length === 0) {
    return {
      effectiveMax: null,
      capacitySource: null,
      candidates: [],
      availabilityCustomerTypeCapacity: rateCapacitySelection.selected,
      availabilityPerBookingMinimum,
      availabilityPerBookingMaximum,
      availabilitySampledCapacities: rateCapacitySelection.sampled,
      availabilitySampledPerBookingMinimums: perBookingMinSelection.sampled,
      availabilitySampledPerBookingMaximums: perBookingMaxSelection.sampled,
      availabilityCapacityDisagreement:
        !rateCapacitySelection.uniform && rateCapacitySelection.sampled.length > 1,
      availabilityPerBookingMinDisagreement:
        !perBookingMinSelection.uniform && perBookingMinSelection.sampled.length > 1,
      availabilityPerBookingMaxDisagreement:
        !perBookingMaxSelection.uniform && perBookingMaxSelection.sampled.length > 1,
      availabilityCapacityMatchMethod: matchMethod
    };
  }

  const effectiveMax = Math.min(...candidates.map((candidate) => candidate.value));
  const winner = candidates.find((candidate) => candidate.value === effectiveMax);

  return {
    effectiveMax,
    capacitySource: winner?.source ?? null,
    candidates,
    availabilityCustomerTypeCapacity: rateCapacitySelection.selected,
    availabilityPerBookingMinimum,
    availabilityPerBookingMaximum,
    availabilitySampledCapacities: rateCapacitySelection.sampled,
    availabilitySampledPerBookingMinimums: perBookingMinSelection.sampled,
    availabilitySampledPerBookingMaximums: perBookingMaxSelection.sampled,
    availabilityCapacityDisagreement:
      !rateCapacitySelection.uniform && rateCapacitySelection.sampled.length > 1,
    availabilityPerBookingMinDisagreement:
      !perBookingMinSelection.uniform && perBookingMinSelection.sampled.length > 1,
    availabilityPerBookingMaxDisagreement:
      !perBookingMaxSelection.uniform && perBookingMaxSelection.sampled.length > 1,
    availabilityCapacityMatchMethod: matchMethod
  };
}

function urisMatch(a, b) {
  if (!a || !b) return false;
  return String(a) === String(b);
}

function normalizeName(value) {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed !== "" ? trimmed : null;
}

function matchPricingRow(prototype, pricingRows) {
  if (!prototype) {
    return { row: null, method: null };
  }

  const protoPk = prototype?.pk;
  const protoUri = prototype?.uri;
  const customerType = getPrototypeCustomerType(prototype);
  const typePk = customerType?.pk;
  const typeUri = customerType?.uri;
  const displayName = normalizeName(prototype?.display_name ?? prototype?.displayName ?? prototype?.name);
  const name = normalizeName(prototype?.name);

  for (const row of pricingRows) {
    const rowProto = getPricingRowPrototype(row);
    if (rowProto && identifiersMatch(rowProto.pk, protoPk)) {
      return { row, method: "customer_prototype.pk" };
    }
  }

  for (const row of pricingRows) {
    const rowProto = getPricingRowPrototype(row);
    if (rowProto && urisMatch(rowProto.uri, protoUri)) {
      return { row, method: "customer_prototype.uri" };
    }
  }

  for (const row of pricingRows) {
    const rowType = getPricingRowCustomerType(row);
    if (identifiersMatch(rowType?.pk, typePk)) {
      return { row, method: "customer_type.pk" };
    }
  }

  for (const row of pricingRows) {
    const rowType = getPricingRowCustomerType(row);
    if (urisMatch(rowType?.uri, typeUri)) {
      return { row, method: "customer_type.uri" };
    }
  }

  for (const row of pricingRows) {
    const rowProto = getPricingRowPrototype(row);
    const rowType = getPricingRowCustomerType(row);
    const rowNames = [
      rowProto?.display_name,
      rowProto?.displayName,
      rowProto?.name,
      rowType?.singular,
      rowType?.plural
    ];
    for (const rowName of rowNames) {
      const normalized = normalizeName(rowName);
      if (normalized && (normalized === displayName || normalized === name)) {
        return { row, method: "display_name/name" };
      }
    }
  }

  return { row: null, method: null };
}

assert.strictEqual(
  calculateTotalAvailabilityCapacity({ customer_count: 3, bookable_capacity: 27 }).total,
  30,
  "total availability capacity should be customer_count + bookable_capacity"
);

assert.strictEqual(
  calculateTotalAvailabilityCapacity({ customer_count: 3 }).total,
  null,
  "missing bookable_capacity should not calculate total"
);

assert.strictEqual(
  calculateTotalAvailabilityCapacity({ bookable_capacity: 27 }).total,
  27,
  "missing customer_count should assume zero when bookable_capacity exists"
);

const item = {
  minimum_initial_party_size: 1,
  minimum_subsequent_party_size: 2,
  maximum_initial_party_size: 20,
  maximum_subsequent_party_size: 15
};
const prototype = {
  minimum_party_size: 4,
  minimum_group_size: 3,
  maximum_party_size: 10,
  maximum_group_size: 12,
  capacity: 8
};

assert.strictEqual(calculateEffectiveMin(item, prototype), 4, "effective_min should use highest min");

const configuredMaxResult = collectCapacityCandidates({
  item,
  prototype,
  resourceDerivedCapacity: null,
  availabilityDetailMatches: [],
  pollingFallbackCapacity: 30
});
assert.strictEqual(
  configuredMaxResult.effectiveMax,
  8,
  "effective_max should use smallest configured max candidate"
);
assert.strictEqual(configuredMaxResult.capacitySource, "customer prototype capacity");

const noConfiguredMaxPrototype = {
  minimum_party_size: 1,
  maximum_party_size: null,
  maximum_group_size: null,
  capacity: null
};
const noConfiguredMaxItem = {
  minimum_initial_party_size: 1,
  minimum_subsequent_party_size: 1,
  maximum_initial_party_size: null,
  maximum_subsequent_party_size: null
};
const noConfiguredMaxResult = collectCapacityCandidates({
  item: noConfiguredMaxItem,
  prototype: noConfiguredMaxPrototype,
  resourceDerivedCapacity: null,
  availabilityDetailMatches: [],
  pollingFallbackCapacity: 30
});
assert.strictEqual(
  noConfiguredMaxResult.effectiveMax,
  30,
  "effective_max should fall back to total availability capacity"
);
assert.strictEqual(noConfiguredMaxResult.capacitySource, "availability endpoint");

const resourceFallbackResult = collectCapacityCandidates({
  item: noConfiguredMaxItem,
  prototype: noConfiguredMaxPrototype,
  resourceDerivedCapacity: 10,
  availabilityDetailMatches: [],
  pollingFallbackCapacity: 30
});
assert.strictEqual(
  resourceFallbackResult.effectiveMax,
  10,
  "resource-derived capacity should be included in smallest-candidate selection"
);
assert.strictEqual(resourceFallbackResult.capacitySource, "resource requirement endpoint");

const itemMaxResult = collectCapacityCandidates({
  item,
  prototype: noConfiguredMaxPrototype,
  resourceDerivedCapacity: null,
  availabilityDetailMatches: [],
  pollingFallbackCapacity: null
});
assert.strictEqual(
  itemMaxResult.effectiveMax,
  15,
  "item subsequent max should still apply when prototype max is blank"
);

const adultPrototype = { pk: 101, maximum_party_size: 10, capacity: 8 };
const rateCapacityResult = collectCapacityCandidates({
  item: null,
  prototype: adultPrototype,
  resourceDerivedCapacity: 10,
  availabilityDetailMatches: [
    { capacity: 3, minimumPartySize: 1, maximumPartySize: 2 },
    { capacity: 4, minimumPartySize: 1, maximumPartySize: 2 }
  ],
  pollingFallbackCapacity: 30
});
assert.strictEqual(
  rateCapacityResult.effectiveMax,
  2,
  "availability customer_type_rates.maximum_party_size should limit effective max below capacity"
);
assert.strictEqual(
  rateCapacityResult.capacitySource,
  "availability customer_type_rates.maximum_party_size"
);
assert.strictEqual(rateCapacityResult.availabilityCustomerTypeCapacity, 3);
assert.strictEqual(rateCapacityResult.availabilityPerBookingMaximum, 2);
assert.strictEqual(rateCapacityResult.availabilityCapacityMatchMethod, "customer_prototype.pk");

const maxPartyOnlyResult = collectCapacityCandidates({
  item: null,
  prototype: { pk: 101 },
  resourceDerivedCapacity: null,
  availabilityDetailMatches: [{ capacity: null, minimumPartySize: 1, maximumPartySize: 2 }],
  pollingFallbackCapacity: 3
});
assert.strictEqual(maxPartyOnlyResult.effectiveMax, 2);
assert.strictEqual(
  maxPartyOnlyResult.capacitySource,
  "availability customer_type_rates.maximum_party_size"
);
assert.strictEqual(maxPartyOnlyResult.availabilityPerBookingMaximum, 2);

assert.strictEqual(isGetYourGuideAffiliate({ affiliate_company: { shortname: "demo-getyourguide" } }), true);
assert.strictEqual(isGetYourGuideAffiliate({ affiliate_company: { name: "GetYourGuide" } }), true);
assert.strictEqual(isGetYourGuideAffiliate({ affiliate_company: { name: "Get Your Guide Direct" } }), true);
assert.strictEqual(isGetYourGuideAffiliate({ affiliate_company: { unicode: "GetYourGuide Direct" } }), true);
assert.strictEqual(isGetYourGuideAffiliate({ affiliate_company: { name: "Viator" } }), false);

assert.deepStrictEqual(
  resolveAssignedPricing(
    { totalPricingObject: { cls: "TotalSheet", pk: 55, name: "Direct" } },
    { default_total_sheet: { cls: "TotalSheet", pk: 99, name: "Online" } }
  ),
  {
    pricingObject: { cls: "TotalSheet", pk: 55, name: "Direct" },
    type: "sheet",
    pk: 55,
    source: "totalPricingObject"
  }
);

assert.deepStrictEqual(
  resolveAssignedPricing(
    {},
    { default_total_sheet: { cls: "TotalSheet", uri: "/total-sheets/77/", name: "OTA Sheet" } }
  ),
  {
    pricingObject: { cls: "TotalSheet", uri: "/total-sheets/77/", name: "OTA Sheet" },
    type: "sheet",
    pk: "77",
    source: "default_total_sheet"
  }
);

assert.deepStrictEqual(
  resolveAssignedPricing(
    {},
    { default_total_schedule: { cls: "TotalSchedule", pk: 12, name: "Weekend Schedule" } }
  ),
  {
    pricingObject: { cls: "TotalSchedule", pk: 12, name: "Weekend Schedule" },
    type: "schedule",
    pk: 12,
    source: "default_total_schedule"
  }
);

assert.strictEqual(
  analyzeCapacitySamples([
    { totalCapacity: 30 },
    { totalCapacity: 30 },
    { totalCapacity: 30 }
  ]).selectedFallbackCapacity,
  30
);
assert.strictEqual(
  analyzeCapacitySamples([
    { totalCapacity: 30 },
    { totalCapacity: 30 },
    { totalCapacity: 30 }
  ]).capacitySampleWarning,
  null
);

const mixedCapacity = analyzeCapacitySamples([
  { availabilityId: "101", startAt: "2026-06-10T09:00:00", totalCapacity: 20 },
  { availabilityId: "102", startAt: "2026-06-11T09:00:00", totalCapacity: 30 }
]);
assert.strictEqual(mixedCapacity.selectedFallbackCapacity, null);
assert.strictEqual(
  mixedCapacity.capacitySampleWarning,
  "Multiple capacities detected (20–30). This item appears to use different capacities across availabilities."
);

const testPrototype = {
  pk: 101,
  uri: "/customer-prototypes/101/",
  display_name: "Adult",
  customer_type: { pk: 201, uri: "/customer-types/201/" }
};

const pricingRows = [
  { for_object: { pk: 999, cls: "CustomerPrototype" }, price_offset: 5000 },
  { for_object: { pk: 101, cls: "CustomerPrototype" }, price_offset: 2500 },
  { customer_type: { pk: 201 }, price_offset: 3000 }
];

assert.deepStrictEqual(matchPricingRow(testPrototype, pricingRows), {
  row: pricingRows[1],
  method: "customer_prototype.pk"
});

const uriOnlyPrototype = {
  pk: null,
  uri: "/customer-prototypes/102/",
  name: "Child",
  customer_type: { pk: 202, uri: "/customer-types/202/" }
};
const uriRows = [{ for_object: { uri: "/customer-prototypes/102/", pk: 102 } }];
assert.strictEqual(matchPricingRow(uriOnlyPrototype, uriRows).method, "customer_prototype.uri");

const typePkPrototype = {
  pk: 103,
  name: "Senior",
  customer_type: { pk: 303, uri: "/customer-types/303/" }
};
const typePkRows = [{ customer_type: { pk: 303 }, price_offset: 1000 }];
assert.strictEqual(matchPricingRow(typePkPrototype, typePkRows).method, "customer_type.pk");

const namePrototype = { pk: 104, display_name: "Student", name: "Student" };
const nameRows = [{ for_object: { pk: 104, name: "Student" } }];
assert.strictEqual(matchPricingRow(namePrototype, nameRows).method, "customer_prototype.pk");

function formatPriceAmount(value) {
  const num = toNumberOrNull(value);
  if (num === null) return null;
  return num.toFixed(2);
}

function extractBasePriceFromRow(row) {
  if (!row) return null;
  const price = row?.price ?? {};
  const modifierKind = price.modifier_kind ?? price.modifierKind ?? null;
  const offset = toNumberOrNull(row?.price_offset ?? row?.priceOffset ?? price?.offset);
  const rate = toNumberOrNull(row?.price_rate ?? row?.priceRate ?? price?.rate);

  if (modifierKind === "offset" && offset !== null) {
    return offset / 100;
  }
  if (offset !== null && offset !== 0) {
    return offset / 100;
  }
  if (rate !== null && rate !== 0) {
    return rate;
  }
  if (offset === 0) {
    return 0;
  }
  return null;
}

function getPriceTaxInclusion(row) {
  const price = row?.price ?? {};
  return price.tax_inclusion ?? price.taxInclusion ?? row?.tax_inclusion ?? row?.taxInclusion ?? null;
}

function taxesAreIncluded(taxInclusion) {
  if (!taxInclusion) return false;
  const normalized = String(taxInclusion).toLowerCase().trim();
  if (normalized === "not-included" || normalized === "not_included") return false;
  if (normalized === "included" || normalized.includes("included")) return true;
  return false;
}

function normalizePercentageTaxRate(rate) {
  const num = toNumberOrNull(rate);
  if (num === null) return null;
  if (num > 0 && num < 1) return num;
  if (num > 1) return num / 100;
  return null;
}

function sumTaxRatesFromRow(row) {
  const taxes = row?.taxes ?? {};
  const ratesByType = taxes.ratesByType ?? taxes.rates_by_type ?? {};
  let totalRate = 0;
  for (const rawRate of Object.values(ratesByType)) {
    const normalizedRate = normalizePercentageTaxRate(rawRate);
    if (normalizedRate !== null) {
      totalRate += normalizedRate;
    }
  }
  return totalRate;
}

function sumTaxOffsetsFromRow(row) {
  const taxes = row?.taxes ?? {};
  const offsetsByType = taxes.offsetsByType ?? taxes.offsets_by_type ?? {};
  let totalOffset = 0;
  for (const rawOffset of Object.values(offsetsByType)) {
    const num = toNumberOrNull(rawOffset);
    if (num !== null) {
      totalOffset += num / 100;
    }
  }
  return totalOffset;
}

function hasTaxData(row) {
  const taxes = row?.taxes ?? {};
  const ratesByType = taxes.ratesByType ?? taxes.rates_by_type ?? {};
  const offsetsByType = taxes.offsetsByType ?? taxes.offsets_by_type ?? {};
  return Object.keys(ratesByType).length > 0 || Object.keys(offsetsByType).length > 0;
}

function calculateGetYourGuideFinalPrice(row) {
  const base = extractBasePriceFromRow(row);
  if (base === null) {
    return {
      basePrice: null,
      finalPrice: null,
      taxRateUsed: null,
      taxOffsetUsed: null,
      calculationPath: "base price missing or invalid",
      calculationNote: null,
      warning: "Could not extract base price from effective_pricing row"
    };
  }

  const baseFormatted = formatPriceAmount(base);
  const taxInclusion = getPriceTaxInclusion(row);

  if (taxesAreIncluded(taxInclusion)) {
    return {
      basePrice: baseFormatted,
      finalPrice: baseFormatted,
      taxRateUsed: null,
      taxOffsetUsed: null,
      calculationPath: `base=${baseFormatted}`,
      calculationNote: `tax_inclusion=${taxInclusion}; taxes already included in base price`,
      warning: null
    };
  }

  const taxRateUsed = sumTaxRatesFromRow(row);
  const taxOffsetUsed = sumTaxOffsetsFromRow(row);

  if (taxRateUsed <= 0 && taxOffsetUsed <= 0) {
    return {
      basePrice: baseFormatted,
      finalPrice: baseFormatted,
      taxRateUsed: null,
      taxOffsetUsed: null,
      calculationPath: `base=${baseFormatted}`,
      calculationNote: null,
      warning: hasTaxData(row)
        ? "Tax data present but no usable rates/offsets found; using base price"
        : "Tax data missing; using base price"
    };
  }

  const pathParts = [`base=${baseFormatted}`];
  let amount = base;
  if (taxRateUsed > 0) {
    amount = base * (1 + taxRateUsed);
    pathParts.push(`* (1 + ${taxRateUsed})`);
  }
  if (taxOffsetUsed > 0) {
    amount += taxOffsetUsed;
    pathParts.push(`+ offset ${taxOffsetUsed}`);
  }

  return {
    basePrice: baseFormatted,
    finalPrice: formatPriceAmount(amount),
    taxRateUsed,
    taxOffsetUsed: taxOffsetUsed > 0 ? taxOffsetUsed : null,
    calculationPath: pathParts.join(" "),
    calculationNote:
      taxInclusion === null || taxInclusion === undefined ? null : `tax_inclusion=${taxInclusion}`,
    warning: null
  };
}

assert.strictEqual(normalizePercentageTaxRate(0.07), 0.07);
assert.strictEqual(normalizePercentageTaxRate(7), 0.07);

const adultPricingRow = {
  for_object: { pk: 762539, cls: "CustomerPrototype", display_name: "Adult" },
  price: {
    offset: 9066,
    rate: null,
    modifier_kind: "offset",
    tax_inclusion: "not-included"
  },
  taxes: {
    rates_by_type: { 21379: 0.07 },
    offsets_by_type: {}
  }
};

const adultFinalPrice = calculateGetYourGuideFinalPrice(adultPricingRow);
assert.strictEqual(adultFinalPrice.basePrice, "90.66");
assert.strictEqual(adultFinalPrice.finalPrice, "97.01");
assert.strictEqual(adultFinalPrice.taxRateUsed, 0.07);
assert.match(adultFinalPrice.calculationPath, /base=90\.66 \* \(1 \+ 0\.07\)/);

const adultPercentPricingRow = {
  price: { offset: 9066, modifier_kind: "offset", tax_inclusion: "not-included" },
  taxes: { rates_by_type: { 21379: 7 }, offsets_by_type: {} }
};
assert.strictEqual(calculateGetYourGuideFinalPrice(adultPercentPricingRow).finalPrice, "97.01");

const includedTaxRow = {
  price: { offset: 9701, modifier_kind: "offset", tax_inclusion: "included" },
  taxes: { rates_by_type: { 21379: 0.07 }, offsets_by_type: {} }
};
const includedTaxPrice = calculateGetYourGuideFinalPrice(includedTaxRow);
assert.strictEqual(includedTaxPrice.basePrice, "97.01");
assert.strictEqual(includedTaxPrice.finalPrice, "97.01");
assert.match(includedTaxPrice.calculationNote, /taxes already included/);

const missingTaxRow = {
  price: { offset: 9066, modifier_kind: "offset", tax_inclusion: "not-included" },
  taxes: {}
};
const missingTaxPrice = calculateGetYourGuideFinalPrice(missingTaxRow);
assert.strictEqual(missingTaxPrice.finalPrice, "90.66");
assert.match(missingTaxPrice.warning, /Tax data missing/);

assert.deepStrictEqual(extractNestedArray({ requirement_groups: { items: [{ pk: 1 }] } }, "requirement_groups"), [
  { pk: 1 }
]);
assert.deepStrictEqual(extractNestedArray({ resource_requirements: [{ pk: 2 }] }, "resource_requirements"), [
  { pk: 2 }
]);

const derivedCapacity = deriveResourceCapacity(
  [
    {
      pk: 59528,
      name: "Default group",
      is_used_for_bookable_capacity: true,
      is_active: true,
      requirements: [{ pk: 128894, type: "customers", is_active: true }]
    }
  ],
  new Map([
    [
      "59528:128894",
      [{ use_count: 1, resource: { pk: 55470, name: "GetYourGuide copy mapping data test" } }]
    ]
  ]),
  [{ pk: 55470, name: "GetYourGuide copy mapping data test", maximum_use_count: 10, is_archived: false }]
);
assert.strictEqual(derivedCapacity.selectedCapacity, 10);
assert.strictEqual(derivedCapacity.entries[0].derivedResourceCapacity, 10);

const limitingCapacity = deriveResourceCapacity(
  [
    {
      pk: 1,
      is_active: true,
      requirements: [
        { pk: 10, type: "customers", is_active: true, resource_requirements: [{ use_count: 1, resource: { pk: 100 } }] },
        { pk: 11, type: "customers", is_active: true, resource_requirements: [{ use_count: 2, resource: { pk: 101 } }] }
      ]
    }
  ],
  new Map(),
  [
    { pk: 100, maximum_use_count: 10, is_archived: false },
    { pk: 101, maximum_use_count: 12, is_archived: false }
  ]
);
assert.strictEqual(limitingCapacity.selectedCapacity, 6, "most limiting resource should control capacity");

const archivedFallbackCapacity = deriveResourceCapacity(
  [
    {
      pk: 2,
      is_active: true,
      requirements: [{ pk: 20, type: "customers", is_active: true, resource_requirements: [{ use_count: 1, resource: { pk: 200 } }] }]
    }
  ],
  new Map(),
  [{ pk: 200, maximum_use_count: 8, is_archived: true }]
);
assert.strictEqual(archivedFallbackCapacity.selectedCapacity, 8, "archived resource may be used when no active match exists");

assert.deepStrictEqual(
  extractAvailabilityCapacityDetails({
    pk: 9001,
    start_at: "2026-06-10T09:00:00",
    capacity: 4,
    non_resource_bookable_capacity: 4,
    customer_type_rates: {
      items: [
        {
          capacity: 3,
          minimum_party_size: 1,
          maximum_party_size: 2,
          customer_prototype: { pk: 101, display_name: "Adult" }
        }
      ]
    }
  }),
  {
    availabilityPk: 9001,
    startAt: "2026-06-10T09:00:00",
    capacity: 4,
    nonResourceBookableCapacity: 4,
    blocksIncludedNonResourceBookableCapacity: null,
    customerTypeRates: [
      {
        prototypePk: 101,
        prototypeName: "Adult",
        capacity: 3,
        minimumPartySize: 1,
        maximumPartySize: 2,
        capacityRemaining: null
      }
    ]
  }
);

assert.strictEqual(
  matchCustomerTypeRateToMapping(
    { customer_prototype: { pk: 101 } },
    { pk: 101 }
  ),
  true
);
assert.strictEqual(
  matchCustomerTypeRateToMapping(
    { customer_prototype: { pk: 101 } },
    { pk: 202 }
  ),
  false
);

assert.strictEqual(
  hasUsefulMatchedRateFields([{ capacity: 3, maximumPartySize: 2 }]),
  true
);
assert.strictEqual(hasUsefulMatchedRateFields([{ capacity: null, maximumPartySize: null }]), false);

assert.match(
  buildAvailabilityDetailFetchSummary(1, 5, "skipped_no_useful_first").message,
  /Skipped remaining details because the first matched availability detail had no per-customer-type capacity\/min\/max values/
);
assert.match(
  buildAvailabilityDetailFetchSummary(5, 5, "additional_fetched").message,
  /Additional details fetched because per-customer-type capacity\/min\/max values were found/
);

function formatCurrencyAmount(amount, processorCurrency) {
  if (amount === null || amount === undefined || amount === "") return "unknown";
  const num = Number(amount);
  if (Number.isNaN(num)) return "unknown";

  const formatted = num.toFixed(2);
  if (!processorCurrency) return formatted;

  const currency = String(processorCurrency).toLowerCase().trim();
  if (currency === "eur") return `€${formatted}`;
  if (currency === "usd") return `$${formatted}`;
  if (currency) return `${currency.toUpperCase()} ${formatted}`;
  return formatted;
}

function aggregateEnrichedMinMax(enrichedCustomerTypes) {
  let min = null;
  let max = null;
  for (const typeReport of enrichedCustomerTypes || []) {
    const typeMin = toNumberOrNull(typeReport?.effectiveMin);
    const typeMax = toNumberOrNull(typeReport?.effectiveMax);
    if (typeMin !== null) {
      min = min === null ? typeMin : Math.max(min, typeMin);
    }
    if (typeMax !== null) {
      max = max === null ? typeMax : Math.min(max, typeMax);
    }
  }
  return {
    min,
    max,
    minLabel: min !== null ? String(min) : "unknown",
    maxLabel: max !== null ? String(max) : "unknown"
  };
}

function formatMultipleEnrichmentPrices(prices, processorCurrency) {
  return formatAggregatedPriceDisplay(prices, processorCurrency);
}

function normalizeUniqueSortedPrices(values) {
  const numericValues = [];
  for (const value of values || []) {
    if (value === null || value === undefined || value === "") continue;
    const num = toNumberOrNull(value);
    if (num === null) continue;
    numericValues.push(num);
  }
  if (numericValues.length === 0) return [];

  const unique = [...new Set(numericValues)];
  unique.sort((a, b) => a - b);
  return unique;
}

function formatAggregatedPriceDisplay(prices, processorCurrency) {
  const uniqueSorted = normalizeUniqueSortedPrices(prices);
  if (uniqueSorted.length === 0) return "unknown";
  if (uniqueSorted.length === 1) {
    return formatCurrencyAmount(uniqueSorted[0], processorCurrency);
  }
  return uniqueSorted.map((price) => formatCurrencyAmount(price, processorCurrency)).join(" / ");
}

function collectEnrichmentPrices(typeReport, kind) {
  const listKey = kind === "final" ? "finalPrices" : "basePrices";
  const singleKey = kind === "final" ? "finalPrice" : "basePrice";
  const perSheetKey = kind === "final" ? "finalPricesPerSheet" : "basePricesPerSheet";

  if (Array.isArray(typeReport?.[listKey]) && typeReport[listKey].length > 0) {
    return typeReport[listKey];
  }
  if (Array.isArray(typeReport?.[perSheetKey]) && typeReport[perSheetKey].length > 0) {
    return typeReport[perSheetKey].flat();
  }
  if (typeReport?.[singleKey] != null && typeReport[singleKey] !== "") {
    return [typeReport[singleKey]];
  }
  return [];
}

function getEnrichmentPriceDisplay(typeReport, processorCurrency) {
  return formatAggregatedPriceDisplay(
    collectEnrichmentPrices(typeReport, "final"),
    processorCurrency
  );
}

function getEnrichmentBasePriceDisplay(typeReport, processorCurrency) {
  return formatAggregatedPriceDisplay(
    collectEnrichmentPrices(typeReport, "base"),
    processorCurrency
  );
}

function buildEnrichedCustomerTypeCell(enrichedCustomerTypes, processorCurrency) {
  const lines = [];
  for (const typeReport of enrichedCustomerTypes || []) {
    const name = String(typeReport?.displayName || "Unknown")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
    const price = getEnrichmentPriceDisplay(typeReport, processorCurrency);
    lines.push(price !== "unknown" ? `<strong>${name}:</strong> ${price}` : `<strong>${name}:</strong>`);
  }
  return lines.join("<br>");
}

const aggregatedMinMax = aggregateEnrichedMinMax([
  { displayName: "Adult", effectiveMin: 1, effectiveMax: 2, finalPrice: "45.00" },
  { displayName: "Child", effectiveMin: 1, effectiveMax: 3, finalPrice: "23.58" }
]);
assert.strictEqual(aggregatedMinMax.min, 1);
assert.strictEqual(aggregatedMinMax.max, 2);
assert.strictEqual(
  buildEnrichedCustomerTypeCell(
    [
      { displayName: "Adult", finalPrice: "45.00" },
      { displayName: "Child", finalPrice: "23.58" }
    ],
    "eur"
  ),
  "<strong>Adult:</strong> €45.00<br><strong>Child:</strong> €23.58"
);

assert.strictEqual(
  buildEnrichedCustomerTypeCell(
    [
      { displayName: "Adult", finalPrices: ["45.00", "10.00"] },
      { displayName: "Child", finalPrices: ["23.58", "5.00"] }
    ],
    "eur"
  ),
  "<strong>Adult:</strong> €10.00 / €45.00<br><strong>Child:</strong> €5.00 / €23.58"
);

assert.strictEqual(formatMultipleEnrichmentPrices(["45.00", "10.00"], "eur"), "€10.00 / €45.00");
assert.strictEqual(
  formatAggregatedPriceDisplay([25, 25, 27, 25, 29, 27], "eur"),
  "€25.00 / €27.00 / €29.00"
);
assert.strictEqual(
  formatAggregatedPriceDisplay([29, 25, 27], "eur"),
  "€25.00 / €27.00 / €29.00"
);
assert.strictEqual(formatAggregatedPriceDisplay([0, 0, 0], "eur"), "€0.00");
assert.strictEqual(
  formatAggregatedPriceDisplay([21, 23, 21, 25, 23], "eur"),
  "€21.00 / €23.00 / €25.00"
);
assert.strictEqual(
  formatAggregatedPriceDisplay([100, 25, 9], "eur"),
  "€9.00 / €25.00 / €100.00"
);
assert.strictEqual(formatAggregatedPriceDisplay([25, "25.0", "25.00"], "eur"), "€25.00");
assert.strictEqual(formatAggregatedPriceDisplay([45], "eur"), "€45.00");
assert.strictEqual(formatAggregatedPriceDisplay([], "eur"), "unknown");
assert.strictEqual(formatAggregatedPriceDisplay([null, "", undefined], "eur"), "unknown");

function extractRctExternalId(value) {
  if (value == null) return null;
  const text = String(value).trim();
  if (/^rct\S+/i.test(text)) return text;
  const match = text.match(/\brct\S+/i);
  return match ? match[0] : null;
}

function normalizeResellerExternalId(value) {
  const extracted = extractRctExternalId(value);
  return extracted ? extracted.toLowerCase() : null;
}

function findPrototypeByPk(prototypes, pk) {
  return (prototypes || []).find((prototype) => String(prototype.pk) === String(pk)) || null;
}

function buildResellerCustomerTypeLookup(entries) {
  const byExternalId = new Map();
  for (const entry of entries || []) {
    const prototype = entry.mapping?.customer_prototype ?? {};
    const customerType = prototype?.customer_type ?? {};
    const externalId = entry.resellerCustomerType?.external_identifier ?? null;
    if (externalId) {
      const key = normalizeResellerExternalId(externalId);
      if (!byExternalId.has(key)) {
        byExternalId.set(key, []);
      }
      byExternalId.get(key).push({
        customerPrototypePk: prototype.pk,
        customerTypePk: customerType.pk,
        fareHarborDisplayName: prototype.display_name
      });
    }
  }
  return { byExternalId };
}

function resolveMappingEntriesForChannelCustomerType(mapped, lookup) {
  const externalKey = normalizeResellerExternalId(mapped?.externalId);
  if (!externalKey || !lookup?.byExternalId?.has(externalKey)) return [];
  const value = lookup.byExternalId.get(externalKey);
  return Array.isArray(value) ? value : value ? [value] : [];
}

function buildMappedCustomerTypeFromEntry(entry, prototypes) {
  const prototype = findPrototypeByPk(prototypes, entry.customerPrototypePk);
  return {
    name: entry.fareHarborDisplayName,
    customerPrototypePk: entry.customerPrototypePk,
    customerTypePk: entry.customerTypePk,
    prototype,
    rawMin: prototype?.minimum_party_size ?? null,
    rawMax: prototype?.maximum_party_size ?? null,
    rawCapacity: prototype?.capacity ?? null
  };
}

function resolvePrototypeForChannelCustomerType(mapped, prototypes, lookup) {
  const mappingEntries = resolveMappingEntriesForChannelCustomerType(mapped, lookup);
  const mappedCustomerTypes = mappingEntries
    .map((entry) => buildMappedCustomerTypeFromEntry(entry, prototypes))
    .filter(Boolean);
  const resolvedPrototypes = mappedCustomerTypes
    .map((entry) => entry.prototype)
    .filter(Boolean);

  if (resolvedPrototypes.length > 0) {
    return {
      prototype: resolvedPrototypes[0],
      prototypes: resolvedPrototypes,
      mappedCustomerTypes,
      mappedFareHarborCustomerTypeName: mappedCustomerTypes[0]?.name ?? null,
      mappedFareHarborCustomerTypeNames: mappedCustomerTypes
        .map((entry) => entry.name)
        .filter(Boolean),
      resolutionMethod: "reseller customer type mapping"
    };
  }

  const fallback = (prototypes || []).find(
    (prototype) => prototype.display_name === mapped.displayName
  );
  return {
    prototype: fallback || null,
    prototypes: fallback ? [fallback] : [],
    mappedCustomerTypes: fallback
      ? [
          {
            name: fallback.display_name,
            customerPrototypePk: fallback.pk,
            customerTypePk: fallback.customer_type?.pk ?? null,
            prototype: fallback,
            rawMin: fallback.minimum_party_size ?? null,
            rawMax: fallback.maximum_party_size ?? null,
            rawCapacity: fallback.capacity ?? null
          }
        ]
      : [],
    mappedFareHarborCustomerTypeName: fallback?.display_name ?? null,
    mappedFareHarborCustomerTypeNames: fallback ? [fallback.display_name] : [],
    resolutionMethod: fallback ? "customer type display name" : null
  };
}

const lookup = buildResellerCustomerTypeLookup([
  {
    resellerCustomerType: { pk: 99, name: "Youth", external_identifier: "rct538891" },
    mapping: {
      customer_prototype: {
        pk: 225930,
        display_name: "Adolescent",
        customer_type: { pk: 124247 }
      }
    }
  }
]);

const prototypes = [
  { pk: 225930, display_name: "Adolescent", customer_type: { pk: 124247 } },
  { pk: 225931, display_name: "Adult", customer_type: { pk: 124248 } }
];

const youthResolved = resolvePrototypeForChannelCustomerType(
  { displayName: "Youth", externalId: "rct538891" },
  prototypes,
  lookup
);
assert.strictEqual(youthResolved.prototype?.pk, 225930);
assert.strictEqual(youthResolved.mappedFareHarborCustomerTypeName, "Adolescent");
assert.strictEqual(
  youthResolved.resolutionMethod,
  "reseller customer type mapping"
);

function parseResellerItemContextFromUrl(url) {
  const raw = String(url || "").trim();
  if (!raw) return null;
  let pathname = raw;
  try {
    if (/^https?:\/\//i.test(raw)) {
      pathname = new URL(raw).pathname;
    } else {
      pathname = raw.split("?")[0].split("#")[0];
    }
  } catch {
    pathname = raw.split("?")[0].split("#")[0];
  }
  const channelMatch = pathname.match(/\/integrations\/channels\/(\d+)\/items\/(\d+)/);
  if (!channelMatch) return null;
  const parts = pathname.split("/").filter(Boolean);
  return {
    company: parts[0] || null,
    resellerCompanyId: channelMatch[1],
    resellerItemId: channelMatch[2]
  };
}

const parsedContext = parseResellerItemContextFromUrl(
  "https://fareharbor.com/eatingeurope-venice/dashboard/settings/integrations/channels/40421/items/226006/"
);
assert.deepStrictEqual(parsedContext, {
  company: "eatingeurope-venice",
  resellerCompanyId: "40421",
  resellerItemId: "226006"
});

const demoContext = parseResellerItemContextFromUrl(
  "https://demo.fareharbor.com/demo/dashboard/settings/integrations/channels/12345/items/67890/"
);
assert.strictEqual(demoContext.company, "demo");
assert.strictEqual(demoContext.resellerCompanyId, "12345");
assert.strictEqual(demoContext.resellerItemId, "67890");

function extractResellerContextFromScrapedRows(scrapedRows) {
  const RESELLER_CHANNEL_ITEM_PATH_RE = /\/integrations\/channels\/(\d+)\/items\/(\d+)/;

  for (const row of scrapedRows || []) {
    if (row?.resellerCompanyId != null && row?.resellerItemId != null) {
      return {
        company: row.company || null,
        resellerCompanyId: String(row.resellerCompanyId),
        resellerItemId: String(row.resellerItemId),
        resellerItemUrl: row.resellerItemUrl || null,
        enrichmentPageUrl: row.enrichmentPageUrl || row.resellerItemUrl || null
      };
    }

    const candidates = [
      row?.enrichmentPageUrl,
      row?.resellerItemUrl,
      row?.itemLabelHTML,
      row?.itemHref,
      row?.href,
      row?.pageUrl
    ];
    for (const candidate of candidates) {
      if (!candidate) continue;
      const candidateText = String(candidate);
      const looksLikeUrl =
        /^https?:\/\//i.test(candidateText) || candidateText.startsWith("/");
      if (looksLikeUrl) {
        const parsed = parseResellerItemContextFromUrl(candidateText);
        if (parsed?.resellerCompanyId && parsed?.resellerItemId) {
          return {
            company: parsed.company,
            resellerCompanyId: parsed.resellerCompanyId,
            resellerItemId: parsed.resellerItemId,
            resellerItemUrl: candidateText,
            enrichmentPageUrl: candidateText
          };
        }
      }
      const match = candidateText.match(RESELLER_CHANNEL_ITEM_PATH_RE);
      if (match) {
        const parsedCompany = looksLikeUrl
          ? parseResellerItemContextFromUrl(candidateText)?.company
          : null;
        return {
          company: parsedCompany || null,
          resellerCompanyId: match[1],
          resellerItemId: match[2],
          resellerItemUrl: looksLikeUrl ? candidateText : null,
          enrichmentPageUrl: looksLikeUrl ? candidateText : null
        };
      }
    }
  }
  return null;
}

const rowLevelContext = extractResellerContextFromScrapedRows([
  {
    itemId: "86941",
    resellerCompanyId: "40421",
    resellerItemId: "226006",
    enrichmentPageUrl:
      "https://fareharbor.com/eatingeurope-venice/dashboard/settings/integrations/channels/40421/items/226006/"
  }
]);
assert.deepStrictEqual(rowLevelContext, {
  company: null,
  resellerCompanyId: "40421",
  resellerItemId: "226006",
  resellerItemUrl: null,
  enrichmentPageUrl:
    "https://fareharbor.com/eatingeurope-venice/dashboard/settings/integrations/channels/40421/items/226006/"
});

const linkContext = extractResellerContextFromScrapedRows([
  {
    itemLabelHTML:
      '<a href="https://fareharbor.com/eatingeurope-venice/dashboard/settings/integrations/channels/40421/items/226006/">Tour</a>'
  }
]);
assert.strictEqual(linkContext.resellerCompanyId, "40421");
assert.strictEqual(linkContext.resellerItemId, "226006");
assert.strictEqual(linkContext.company, null);

assert.strictEqual(
  extractResellerContextFromScrapedRows([
    { itemLabel: "Tour (ID: 86941)", itemId: "86941" }
  ]),
  null
);

const adultResolved = resolvePrototypeForChannelCustomerType(
  { displayName: "Adult", externalId: "rct3820" },
  prototypes,
  lookup
);
assert.strictEqual(adultResolved.prototype?.pk, 225931);
assert.strictEqual(adultResolved.resolutionMethod, "customer type display name");

const privateTourPrototypes = Array.from({ length: 12 }, (_, index) => {
  const size = index + 1;
  return {
    pk: 300000 + size,
    display_name: `Adult - OTA - Private Tour ${size}-${size}`,
    minimum_party_size: size,
    maximum_party_size: size,
    customer_type: { pk: 400000 + size }
  };
});

const multiAdultLookup = buildResellerCustomerTypeLookup(
  privateTourPrototypes.map((prototype) => ({
    resellerCustomerType: {
      pk: 99,
      name: "Adult",
      external_identifier: "rct595572"
    },
    mapping: {
      customer_prototype: {
        pk: prototype.pk,
        display_name: prototype.display_name,
        customer_type: prototype.customer_type
      }
    }
  }))
);

const multiAdultResolved = resolvePrototypeForChannelCustomerType(
  { displayName: "Adult", externalId: "rct595572" },
  privateTourPrototypes,
  multiAdultLookup
);
assert.strictEqual(multiAdultResolved.mappedCustomerTypes.length, 12);
assert.strictEqual(multiAdultResolved.prototypes.length, 12);
assert.strictEqual(
  calculateGroupedMappedCustomerTypeMin({ minimum_initial_party_size: 1 }, privateTourPrototypes),
  1
);
assert.strictEqual(calculateGroupedMappedCustomerTypeMax(privateTourPrototypes), 12);

const multiAdultMaxResult = collectCapacityCandidates({
  item: { maximum_initial_party_size: 20, maximum_subsequent_party_size: 20 },
  prototypes: privateTourPrototypes,
  resourceDerivedCapacity: null,
  availabilityDetailMatches: [],
  pollingFallbackCapacity: 30
});
assert.strictEqual(multiAdultMaxResult.effectiveMax, 12);
assert.strictEqual(multiAdultMaxResult.capacitySource, "mapped customer type maximum");

const multiAdultWithResourceLimit = collectCapacityCandidates({
  item: { maximum_initial_party_size: 20, maximum_subsequent_party_size: 20 },
  prototypes: privateTourPrototypes,
  resourceDerivedCapacity: 10,
  availabilityDetailMatches: [],
  pollingFallbackCapacity: 30
});
assert.strictEqual(multiAdultWithResourceLimit.effectiveMax, 10);
assert.strictEqual(multiAdultWithResourceLimit.capacitySource, "resource requirement endpoint");

const groupedAvailabilityMatches = Array.from({ length: 10 }, (_, index) => ({
  maximumPartySize: index + 1,
  minimumPartySize: index + 1
}));
const groupedAvailabilityMaxResult = collectCapacityCandidates({
  item: { maximum_initial_party_size: 20, maximum_subsequent_party_size: 20 },
  prototypes: privateTourPrototypes.slice(0, 10),
  resourceDerivedCapacity: null,
  availabilityDetailMatches: groupedAvailabilityMatches,
  pollingFallbackCapacity: 30
});
assert.strictEqual(groupedAvailabilityMaxResult.availabilityPerBookingMaximum, 10);
assert.strictEqual(groupedAvailabilityMaxResult.effectiveMax, 10);

function formatDiagnosticPriceList(prices, processorCurrency) {
  const formatted = (prices || [])
    .filter((price) => price !== null && price !== undefined && price !== "")
    .map((price) => formatCurrencyAmount(price, processorCurrency))
    .filter((price) => price !== "unknown");
  return formatted.length > 0 ? formatted.join(" / ") : "unknown";
}

function formatPriceRangeLabel(prices, processorCurrency) {
  const deduped = dedupePreservingOrder(
    (prices || []).filter((price) => price !== null && price !== undefined && price !== "")
  );
  if (deduped.length === 0) return "unknown";
  if (deduped.length === 1) {
    return formatCurrencyAmount(deduped[0], processorCurrency);
  }
  const numericPrices = deduped.map(toNumberOrNull).filter((value) => value !== null);
  if (numericPrices.length >= 2) {
    const min = Math.min(...numericPrices);
    const max = Math.max(...numericPrices);
    const minLabel = formatCurrencyAmount(min, processorCurrency);
    const maxLabel = formatCurrencyAmount(max, processorCurrency);
    if (minLabel !== maxLabel) {
      return `${minLabel}-${maxLabel}`;
    }
  }
  return formatDiagnosticPriceList(deduped, processorCurrency);
}

assert.strictEqual(
  formatPriceRangeLabel(["440.00", "220.00", "176.00", "177.22"], "eur"),
  "€176.00-€440.00"
);
assert.strictEqual(
  formatPriceRangeLabel(["440.00", "440.00"], "eur"),
  "€440.00"
);

function formatScheduleSheetPriceLabels(sheetPriceLabels) {
  const labels = (sheetPriceLabels || []).filter((label) => label && label !== "unknown");
  return labels.length > 0 ? labels.join(" / ") : "unknown";
}

assert.strictEqual(
  getEnrichmentPriceDisplay(
    {
      finalPricesPerSheet: [
        ["176.00", "440.00"],
        ["176.00", "440.00"]
      ]
    },
    "eur"
  ),
  "€176.00 / €440.00"
);
assert.strictEqual(
  getEnrichmentPriceDisplay(
    {
      finalPricesPerSheet: [["165.00"], ["165.00"]]
    },
    "eur"
  ),
  "€165.00"
);

assert.strictEqual(
  ["€177.22-€440.00", "€177.22-€440.00"].join(" / "),
  "€177.22-€440.00 / €177.22-€440.00"
);

assert.deepStrictEqual(dedupePreservingOrder(["440.00", "440.00", "500.00"]), ["440.00", "500.00"]);

assert.strictEqual(formatCurrencyAmount(45, "eur"), "€45.00");
assert.strictEqual(formatCurrencyAmount(23.58, "eur"), "€23.58");
assert.strictEqual(formatCurrencyAmount(45, "usd"), "$45.00");
assert.strictEqual(formatCurrencyAmount(45, "nok"), "NOK 45.00");
assert.strictEqual(formatCurrencyAmount(45, null), "45.00");
assert.strictEqual(formatCurrencyAmount(null, "eur"), "unknown");

console.log("GetYourGuide mapping enrichment: all assertions passed");
