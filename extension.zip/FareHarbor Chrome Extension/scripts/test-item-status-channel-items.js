const assert = require("assert");

const CHANNEL_COMPANY_NUMERIC_RE =
  /^\/[^/]+\/dashboard\/settings\/integrations\/channels\/(\d+)\/?$/;
const ITEM_HREF_RE = /\/dashboard\/items\/(\d+)/i;

function parseNumericChannelCompanyPageContext(pathname) {
  const normalized = String(pathname || "").replace(/\/+$/, "");
  if (!normalized || /\/items\/\d+/.test(normalized)) {
    return null;
  }

  const numericMatch = normalized.match(CHANNEL_COMPANY_NUMERIC_RE);
  if (!numericMatch) {
    return null;
  }

  const parts = normalized.split("/").filter(Boolean);
  return {
    companyShortname: parts[0],
    channelId: numericMatch[1]
  };
}

function buildStatusCacheKey(companyShortname, itemId) {
  return `${companyShortname}|${itemId}`;
}

function getItemStatus(item) {
  if (!item || typeof item !== "object") {
    return "Unknown";
  }
  if (item.is_archived === true) {
    return "Archived";
  }
  if (item.is_archived !== false) {
    return "Unknown";
  }
  if (item.is_private === true) {
    return "Off";
  }
  if (item.is_private === false) {
    return "On";
  }
  return "Unknown";
}

function extractMappedItemIdsFromCell(cell) {
  if (!cell) {
    return [];
  }
  const ids = [];
  const links = cell.querySelectorAll('a[href*="/dashboard/items/"]');
  for (const link of links) {
    const href = link.getAttribute("href") || "";
    const match = href.match(ITEM_HREF_RE);
    if (match) {
      ids.push(match[1]);
    }
  }
  return ids;
}

function makeMappingsCell(hrefs) {
  return {
    querySelectorAll(selector) {
      assert.strictEqual(selector, 'a[href*="/dashboard/items/"]');
      return hrefs.map((href) => ({
        getAttribute(name) {
          return name === "href" ? href : null;
        }
      }));
    }
  };
}

// --- getItemStatus ---
assert.strictEqual(
  getItemStatus({ is_archived: false, is_private: false }),
  "On"
);
assert.strictEqual(
  getItemStatus({ is_archived: false, is_private: true }),
  "Off"
);
assert.strictEqual(
  getItemStatus({ is_archived: true, is_private: false }),
  "Archived"
);
assert.strictEqual(
  getItemStatus({ is_archived: true, is_private: true }),
  "Archived"
);
assert.strictEqual(getItemStatus({ is_archived: true }), "Archived");
assert.strictEqual(getItemStatus({ is_private: false }), "Unknown");
assert.strictEqual(
  getItemStatus({ is_archived: false, is_private: "yes" }),
  "Unknown"
);
assert.strictEqual(
  getItemStatus({ is_archived: "true", is_private: false }),
  "Unknown"
);
assert.strictEqual(getItemStatus(null), "Unknown");
assert.strictEqual(getItemStatus({}), "Unknown");

// --- page context ---
assert.deepStrictEqual(
  parseNumericChannelCompanyPageContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/35764/"
  ),
  { companyShortname: "eatingeurope-rome", channelId: "35764" }
);
assert.strictEqual(
  parseNumericChannelCompanyPageContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/35764/items/316479/"
  ),
  null
);
assert.strictEqual(
  parseNumericChannelCompanyPageContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/getyourguide/"
  ),
  null
);

// --- cache key ---
assert.strictEqual(
  buildStatusCacheKey("babyloncitytours-amsterdam", "83686"),
  "babyloncitytours-amsterdam|83686"
);
assert.notStrictEqual(
  buildStatusCacheKey("company-a", "1"),
  buildStatusCacheKey("company-b", "1")
);

// --- item ID extraction (order preserved; ignore channel-item links) ---
assert.deepStrictEqual(
  extractMappedItemIdsFromCell(
    makeMappingsCell([
      "/babyloncitytours-amsterdam/dashboard/items/83686/",
      "/babyloncitytours-amsterdam/dashboard/items/143575/",
      "/dashboard/settings/integrations/channels/1/items/322229/"
    ])
  ),
  ["83686", "143575"]
);
assert.deepStrictEqual(extractMappedItemIdsFromCell(null), []);

console.log("test-item-status-channel-items: all tests passed");
