const assert = require("assert");

const CHANNEL_COMPANY_NUMERIC_RE =
  /^\/[^/]+\/dashboard\/settings\/integrations\/channels\/(\d+)\/?$/;
const RESELLER_ITEM_EXTERNAL_ID_RE = /\bri(\d+)\b/i;

function findAvailabilityCount(data) {
  if (!data || typeof data !== "object") {
    return null;
  }
  if (typeof data.availability_count === "number") {
    return data.availability_count;
  }
  if (typeof data.availabilityCount === "number") {
    return data.availabilityCount;
  }
  const stack = [data];
  const seen = new Set();
  while (stack.length) {
    const obj = stack.pop();
    if (!obj || typeof obj !== "object" || seen.has(obj)) {
      continue;
    }
    seen.add(obj);
    for (const [k, v] of Object.entries(obj)) {
      if (
        (k === "availability_count" ||
          k === "availabilityCount" ||
          k === "futureAvailabilitiesCount") &&
        typeof v === "number"
      ) {
        return v;
      }
      if (v && typeof v === "object") {
        stack.push(v);
      }
    }
  }
  return null;
}

function normalizeCount(value) {
  if (typeof value !== "number" || !Number.isFinite(value)) {
    return null;
  }
  return value;
}

function formatCount(count) {
  return String(count);
}

function parseNumericChannelCompanyPageContext(pathname) {
  const normalized = String(pathname || "").replace(/\/+$/, "");
  if (!normalized || /\/items\/\d+/.test(normalized)) {
    return null;
  }

  const numericMatch = normalized.match(CHANNEL_COMPANY_NUMERIC_RE);
  if (!numericMatch) {
    return null;
  }

  const parts = normalized.split("/").filter(Boolean);
  return {
    companyShortname: parts[0],
    channelId: numericMatch[1]
  };
}

function parseResellerItemIdFromExternalId(text) {
  const match = String(text || "").match(RESELLER_ITEM_EXTERNAL_ID_RE);
  return match ? match[1] : null;
}

assert.deepStrictEqual(
  parseNumericChannelCompanyPageContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/35764/"
  ),
  { companyShortname: "eatingeurope-rome", channelId: "35764" }
);

assert.strictEqual(
  parseNumericChannelCompanyPageContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/35764/items/316479/"
  ),
  null
);

assert.strictEqual(
  parseNumericChannelCompanyPageContext(
    "/eatingeurope-rome/dashboard/settings/integrations/channels/getyourguide/"
  ),
  null
);

assert.strictEqual(parseResellerItemIdFromExternalId("ri199720"), "199720");
assert.strictEqual(parseResellerItemIdFromExternalId("prefix ri199720 suffix"), "199720");
assert.strictEqual(parseResellerItemIdFromExternalId("rct538891"), null);
assert.strictEqual(parseResellerItemIdFromExternalId(""), null);

assert.strictEqual(normalizeCount(1402), 1402);
assert.strictEqual(normalizeCount(NaN), null);
assert.strictEqual(normalizeCount(Infinity), null);
assert.strictEqual(normalizeCount("1402"), null);

assert.strictEqual(formatCount(1402), "1402");
assert.notStrictEqual(formatCount(1402), "1,402");

assert.strictEqual(findAvailabilityCount({ availability_count: 42 }), 42);
assert.strictEqual(
  findAvailabilityCount({ nested: { availabilityCount: 7 } }),
  7
);
assert.strictEqual(findAvailabilityCount({}), null);

console.log("test-availability-count-shared: all tests passed");
