const assert = require("assert");

const CHANNEL_COMPANY_NUMERIC_RE =
  /^\/[^/]+\/dashboard\/settings\/integrations\/channels\/(\d+)\/?$/;
const RESELLER_CHANNEL_ITEM_PATH_RE =
  /\/integrations\/channels\/(\d+)\/items\/(\d+)/;
const ITEM_MAPPINGS_HEADER_RE = /^item\s*mappings$/i;
const ITEM_STATUS_HEADER_RE = /^item\s*status$/i;
const ITEM_STATUS_COLUMN_ATTR = "data-fh-item-status-column";

function parseNumericChannelCompanyPageContext(pathname) {
  const normalized = String(pathname || "").replace(/\/+$/, "");
  if (!normalized || /\/items\/\d+/.test(normalized)) {
    return null;
  }

  const numericMatch = normalized.match(CHANNEL_COMPANY_NUMERIC_RE);
  if (!numericMatch) {
    return null;
  }

  const parts = normalized.split("/").filter(Boolean);
  return {
    companyShortname: parts[0],
    channelId: numericMatch[1]
  };
}

function buildLocationCacheKey(companyShortname, channelId, resellerItemId) {
  return `${companyShortname}|${channelId}|${resellerItemId}`;
}

function getResellerItemPrimaryLocationObject(resellerItem) {
  const primary =
    resellerItem?.primary_location ?? resellerItem?.primaryLocation ?? null;
  if (!primary || typeof primary !== "object") {
    return null;
  }
  return primary;
}

function extractLocationDisplayName(location) {
  if (!location || typeof location !== "object") {
    return null;
  }
  const name = location.name;
  if (typeof name === "string" && name.trim() !== "") {
    return name.trim();
  }
  return null;
}

function formatGoogleLocationDisplayName(locationName, isDashboardDefault) {
  if (!locationName) {
    return null;
  }
  return isDashboardDefault
    ? `${locationName} (Dashboard Default)`
    : locationName;
}

function normalizeLocationUri(uri) {
  if (typeof uri !== "string" || !uri.trim()) {
    return null;
  }
  return uri.trim().replace(/\/+$/, "") || "/";
}

function shouldReuseCompanyPrimaryLocation(company) {
  const defaultRef = company?.default_item_primary_location ?? null;
  const companyPrimary = company?.primary_location ?? null;
  const defaultUri = normalizeLocationUri(defaultRef?.uri);
  const primaryUri = normalizeLocationUri(companyPrimary?.uri);
  return !!(defaultUri && primaryUri && defaultUri === primaryUri);
}

function extractResellerItemIdFromRow(row) {
  if (!row) {
    return null;
  }
  const links = row.querySelectorAll("a[href], a[ng-href]");
  for (const link of links) {
    const href = link.getAttribute("href") || link.getAttribute("ng-href") || "";
    const match = String(href).match(RESELLER_CHANNEL_ITEM_PATH_RE);
    if (match) {
      return match[2];
    }
  }
  return null;
}

function normalizeCellText(text) {
  return String(text || "").replace(/\s+/g, " ").trim();
}

function findItemMappingsIndex(cells) {
  return cells.findIndex((cell) =>
    ITEM_MAPPINGS_HEADER_RE.test(normalizeCellText(cell.textContent))
  );
}

function findItemStatusIndex(cells) {
  return cells.findIndex((cell) => {
    if (cell.getAttribute?.(ITEM_STATUS_COLUMN_ATTR) === "true") {
      return true;
    }
    return ITEM_STATUS_HEADER_RE.test(normalizeCellText(cell.textContent));
  });
}

function findInsertAnchorCell(cells) {
  const statusIdx = findItemStatusIndex(cells);
  if (statusIdx >= 0) {
    return cells[statusIdx];
  }
  const mappingsIdx = findItemMappingsIndex(cells);
  if (mappingsIdx >= 0) {
    return cells[mappingsIdx];
  }
  return null;
}

assert.deepStrictEqual(
  parseNumericChannelCompanyPageContext(
    "/demo/dashboard/settings/integrations/channels/81/"
  ),
  { companyShortname: "demo", channelId: "81" }
);
assert.strictEqual(
  parseNumericChannelCompanyPageContext(
    "/demo/dashboard/settings/integrations/channels/81/items/9/"
  ),
  null
);

assert.strictEqual(
  buildLocationCacheKey("demo", "81", "332081"),
  "demo|81|332081"
);

assert.strictEqual(
  extractLocationDisplayName(
    getResellerItemPrimaryLocationObject({
      primary_location: { name: "Google Things To Do", pk: 1 }
    })
  ),
  "Google Things To Do"
);
assert.strictEqual(
  getResellerItemPrimaryLocationObject({ primary_location: null }),
  null
);
assert.strictEqual(
  formatGoogleLocationDisplayName("Pure Boats", true),
  "Pure Boats (Dashboard Default)"
);
assert.strictEqual(
  formatGoogleLocationDisplayName("Pure Boats", false),
  "Pure Boats"
);
assert.strictEqual(
  formatGoogleLocationDisplayName("Pure Boats", true) === "Pure Boats",
  false
);
assert.strictEqual(
  shouldReuseCompanyPrimaryLocation({
    primary_location: {
      uri: "/api/v1/companies/pureboats/locations/57055/"
    },
    default_item_primary_location: {
      uri: "/api/v1/companies/pureboats/locations/57055/"
    }
  }),
  true
);
assert.strictEqual(
  shouldReuseCompanyPrimaryLocation({
    primary_location: {
      uri: "/api/v1/companies/pureboats/locations/57055/"
    },
    default_item_primary_location: {
      uri: "/api/v1/companies/pureboats/locations/999/"
    }
  }),
  false
);

function makeRow(hrefs) {
  return {
    querySelectorAll(selector) {
      assert.ok(
        selector === "a[href], a[ng-href]" ||
          selector === 'a[href], a[ng-href]'
      );
      return hrefs.map((href) => ({
        getAttribute(name) {
          if (name === "href" || name === "ng-href") {
            return href;
          }
          return null;
        }
      }));
    }
  };
}

assert.strictEqual(
  extractResellerItemIdFromRow(
    makeRow([
      "/demo/dashboard/items/1/",
      "/demo/dashboard/settings/integrations/channels/81/items/332081/"
    ])
  ),
  "332081"
);
assert.strictEqual(
  extractResellerItemIdFromRow(makeRow(["/demo/dashboard/items/1/"])),
  null
);

const mappings = { textContent: "Item Mappings", getAttribute: () => null };
const status = {
  textContent: "Item Status",
  getAttribute: (name) => (name === ITEM_STATUS_COLUMN_ATTR ? "true" : null)
};
assert.strictEqual(findInsertAnchorCell([mappings]), mappings);
assert.strictEqual(findInsertAnchorCell([mappings, status]), status);

// Google Location column is Google-only (mirrors Ticket Scanning Viator gate).
function shouldShowGoogleLocationColumn(affiliateKey) {
  return affiliateKey === "google";
}
assert.strictEqual(shouldShowGoogleLocationColumn("google"), true);
assert.strictEqual(shouldShowGoogleLocationColumn("viator"), false);

function isAnyExtensionColumnCell(el) {
  if (!el || typeof el.getAttributeNames !== "function") {
    return false;
  }
  for (const attr of el.getAttributeNames()) {
    if (
      attr.startsWith("data-fh-") &&
      attr.endsWith("-column") &&
      el.getAttribute(attr) === "true"
    ) {
      return true;
    }
  }
  return false;
}

function makeAttrEl(attrs) {
  return {
    getAttributeNames: () => Object.keys(attrs),
    getAttribute: (name) =>
      Object.prototype.hasOwnProperty.call(attrs, name) ? attrs[name] : null
  };
}

assert.strictEqual(
  isAnyExtensionColumnCell(
    makeAttrEl({ "data-fh-item-status-column": "true" })
  ),
  true
);
assert.strictEqual(
  isAnyExtensionColumnCell(
    makeAttrEl({ "data-fh-google-location-column": "true" })
  ),
  true
);
assert.strictEqual(
  isAnyExtensionColumnCell(makeAttrEl({ class: "prose" })),
  false
);

// Idempotent normalize: when placement is correct, report zero DOM mutations.
function summarizeNormalizePass({ needsRepair, rebuildCounts }) {
  if (!needsRepair) {
    return { headerInserted: 0, cellsInserted: 0, cellsRepositioned: 0 };
  }
  return rebuildCounts;
}

assert.deepStrictEqual(
  summarizeNormalizePass({
    needsRepair: false,
    rebuildCounts: {
      headerInserted: 1,
      cellsInserted: 10,
      cellsRepositioned: 11
    }
  }),
  { headerInserted: 0, cellsInserted: 0, cellsRepositioned: 0 }
);

console.log("test-google-location-channel-items: all assertions passed");
