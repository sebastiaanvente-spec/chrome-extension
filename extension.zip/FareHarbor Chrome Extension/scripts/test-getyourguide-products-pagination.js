#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const source = fs.readFileSync(
  path.join(__dirname, "..", "content", "getyourguide-products.js"),
  "utf8"
);

function loadModule(options) {
  const logs = [];
  const setTimeoutCalls = [];
  const context = {
    console: {
      log: function () {
        logs.push(["log"].concat(Array.prototype.slice.call(arguments)));
      },
      warn: function () {
        logs.push(["warn"].concat(Array.prototype.slice.call(arguments)));
      },
      error: function () {
        logs.push(["error"].concat(Array.prototype.slice.call(arguments)));
      }
    },
    document: { cookie: "" },
    localStorage: { length: 0, getItem: function () { return null; }, key: function () { return null; } },
    sessionStorage: { length: 0, getItem: function () { return null; }, key: function () { return null; } },
    chrome: {
      runtime: {
        sendMessage: function (_msg, cb) {
          if (typeof cb === "function") cb({});
        },
        lastError: null
      }
    },
    setTimeout: function (fn, ms) {
      setTimeoutCalls.push(ms);
      if (typeof fn === "function") fn();
      return 0;
    },
    clearTimeout: function () {},
    atob: function () {
      return "{}";
    },
    window: null,
    Math: Math,
    JSON: JSON,
    Array: Array,
    Map: Map,
    String: String,
    Number: Number,
    Boolean: Boolean,
    Object: Object,
    Error: Error,
    Promise: Promise,
    Date: Date
  };
  context.window = {
    location: {
      href: (options && options.href) || "https://supplier.getyourguide.com/dashboard",
      origin: "https://supplier.getyourguide.com"
    },
    addEventListener: function () {},
    GetYourGuideProducts: null
  };
  context.globalThis = context;
  vm.createContext(context);
  vm.runInContext(source, context, { filename: "getyourguide-products.js" });
  assert.ok(context.window.GetYourGuideProducts, "GetYourGuideProducts should be defined");
  return {
    api: context.window.GetYourGuideProducts,
    logs: logs,
    setTimeoutCalls: setTimeoutCalls
  };
}

function fromVm(value) {
  return JSON.parse(JSON.stringify(value));
}

function assertStep(actual, expected) {
  assert.deepStrictEqual(fromVm(actual), expected);
}

function bridgeOk(payload) {
  return {
    ok: true,
    status: 200,
    statusText: "OK",
    rawText: JSON.stringify(payload)
  };
}

function pagePayload(items, pagination) {
  const search = { items: items };
  if (pagination !== undefined) search.pagination = pagination;
  return { data: { activityOptionSearch: search } };
}

async function run() {
  const { api } = loadModule();
  const advance = api.advanceGYGOptionsPagination;

  // Empty results with zero limit and zero total — finish, do not throw
  assertStep(
    advance(0, [], { limit: 0, offset: 0, totalItems: 0 }, 50),
    { done: true, nextOffset: 0, totalItems: 0 }
  );

  // Completed nonempty result with zero response limit — finish before stall check
  assertStep(
    advance(
      0,
      [{ id: 1 }, { id: 2 }, { id: 3 }],
      { limit: 0, offset: 0, totalItems: 3 },
      50
    ),
    { done: true, nextOffset: 0, totalItems: 3 }
  );

  // Multi-page: first page not done, second page completes
  assertStep(
    advance(
      0,
      [{ id: 1 }, { id: 2 }],
      { limit: 2, offset: 0, totalItems: 3 },
      50
    ),
    { done: false, nextOffset: 2, totalItems: 3 }
  );
  assertStep(
    advance(2, [{ id: 3 }], { limit: 2, offset: 2, totalItems: 3 }, 50),
    { done: true, nextOffset: 2, totalItems: 3 }
  );

  // Missing pagination metadata — finish
  assertStep(
    advance(0, [{ id: 1 }], null, 50),
    { done: true, nextOffset: 0, totalItems: null }
  );
  assertStep(
    advance(0, [{ id: 1 }], undefined, 50),
    { done: true, nextOffset: 0, totalItems: null }
  );

  // Missing totalItems normalizes to null (keeps loop condition working)
  assertStep(
    advance(0, [{ id: 1 }], { limit: 50, offset: 0 }, 50),
    { done: false, nextOffset: 50, totalItems: null }
  );
  assertStep(
    advance(0, [{ id: 1 }], { limit: 50, offset: 0, totalItems: undefined }, 50),
    { done: false, nextOffset: 50, totalItems: null }
  );

  // Unknown total followed by an empty page — finish
  assertStep(
    advance(50, [], { limit: 50, offset: 50 }, 50),
    { done: true, nextOffset: 50, totalItems: null }
  );

  // Stalled pagination
  assert.throws(
    function () {
      advance(0, [{ id: 1 }], { limit: 0, offset: 0, totalItems: 10 }, 50);
    },
    /Pagination not advancing/
  );

  // Backward pagination
  assert.throws(
    function () {
      advance(20, [{ id: 1 }], { limit: 5, offset: 10, totalItems: 40 }, 50);
    },
    /Pagination not advancing/
  );

  // Non-finite next offset
  assert.throws(
    function () {
      advance(0, [{ id: 1 }], { limit: Number.NaN, offset: 0, totalItems: 10 }, 50);
    },
    /Pagination not advancing/
  );

  // Unexpected empty page before reported total
  assert.throws(
    function () {
      advance(0, [], { limit: 50, offset: 0, totalItems: 5 }, 50);
    },
    /Unexpected empty page before reported total/
  );

  // --- fetchAllGYGOptionsV2 integration ---

  // Empty search: items=[], pagination zeros — succeeds with []
  {
    const { api: api2, logs } = loadModule();
    const items = await api2.fetchAllGYGOptionsV2(
      "https://supplier.getyourguide.com/graphql",
      "query Q { __typename }",
      { filters: [], limit: 50 },
      {
        doOneGraphQLRequest: async function () {
          return bridgeOk(pagePayload([], { limit: 0, offset: 0, totalItems: 0 }));
        }
      }
    );
    assert.deepStrictEqual(fromVm(items), []);
    const pageLog = logs.find(function (entry) {
      return entry[0] === "log" && entry[1] === "[getyourguide-products] activityOptionSearch page";
    });
    assert.ok(pageLog, "expected page diagnostics log");
    assert.deepStrictEqual(fromVm(pageLog[2]), {
      requestedOffset: 0,
      itemCount: 0,
      pagination: { limit: 0, offset: 0, totalItems: 0 }
    });
    const joined = JSON.stringify(fromVm(logs));
    assert.ok(!/Bearer |eyJ|"token"|authorization/i.test(joined), "diagnostics must not log auth tokens");
  }

  // Completed nonempty with zero response limit
  {
    const { api: api2 } = loadModule();
    const items = fromVm(await api2.fetchAllGYGOptionsV2(
      "https://supplier.getyourguide.com/graphql",
      "query Q { __typename }",
      { filters: [], limit: 50 },
      {
        doOneGraphQLRequest: async function () {
          return bridgeOk(
            pagePayload([{ id: "a" }, { id: "b" }], { limit: 0, offset: 0, totalItems: 2 })
          );
        }
      }
    ));
    assert.strictEqual(items.length, 2);
    assert.strictEqual(items[0].id, "a");
  }

  // Successful retrieval across multiple pages
  {
    const { api: api2 } = loadModule();
    let calls = 0;
    const items = fromVm(await api2.fetchAllGYGOptionsV2(
      "https://supplier.getyourguide.com/graphql",
      "query Q { __typename }",
      { filters: [], limit: 2 },
      {
        doOneGraphQLRequest: async function (_e, _q, input) {
          calls += 1;
          if (input.offset === 0) {
            return bridgeOk(
              pagePayload([{ id: "1" }, { id: "2" }], { limit: 2, offset: 0, totalItems: 3 })
            );
          }
          if (input.offset === 2) {
            return bridgeOk(
              pagePayload([{ id: "3" }], { limit: 2, offset: 2, totalItems: 3 })
            );
          }
          throw new Error("Unexpected offset " + input.offset);
        }
      }
    ));
    assert.strictEqual(calls, 2);
    assert.deepStrictEqual(items.map(function (i) { return i.id; }), ["1", "2", "3"]);
  }

  // Missing pagination metadata — returns items from the single page
  {
    const { api: api2 } = loadModule();
    const items = fromVm(await api2.fetchAllGYGOptionsV2(
      "https://supplier.getyourguide.com/graphql",
      "query Q { __typename }",
      { filters: [] },
      {
        doOneGraphQLRequest: async function () {
          return bridgeOk(pagePayload([{ id: "only" }], null));
        }
      }
    ));
    assert.strictEqual(items.length, 1);
    assert.strictEqual(items[0].id, "only");
  }

  // Unknown total then empty page — finish with first page items
  {
    const { api: api2 } = loadModule();
    let calls = 0;
    const items = fromVm(await api2.fetchAllGYGOptionsV2(
      "https://supplier.getyourguide.com/graphql",
      "query Q { __typename }",
      { filters: [], limit: 50 },
      {
        doOneGraphQLRequest: async function (_e, _q, input) {
          calls += 1;
          if (input.offset === 0) {
            return bridgeOk(
              pagePayload([{ id: "1" }], { limit: 50, offset: 0 })
            );
          }
          return bridgeOk(pagePayload([], { limit: 50, offset: 50 }));
        }
      }
    ));
    assert.strictEqual(calls, 2);
    assert.strictEqual(items.length, 1);
  }

  // Stalled pagination aborts (does not return partial as success after throw)
  {
    const { api: api2 } = loadModule();
    await assert.rejects(
      function () {
        return api2.fetchAllGYGOptionsV2(
          "https://supplier.getyourguide.com/graphql",
          "query Q { __typename }",
          { filters: [] },
          {
            doOneGraphQLRequest: async function () {
              return bridgeOk(
                pagePayload([{ id: "1" }], { limit: 0, offset: 0, totalItems: 5 })
              );
            }
          }
        );
      },
      /Pagination not advancing/
    );
  }

  // Unexpected empty page before reported total
  {
    const { api: api2 } = loadModule();
    await assert.rejects(
      function () {
        return api2.fetchAllGYGOptionsV2(
          "https://supplier.getyourguide.com/graphql",
          "query Q { __typename }",
          { filters: [] },
          {
            doOneGraphQLRequest: async function () {
              return bridgeOk(pagePayload([], { limit: 50, offset: 0, totalItems: 4 }));
            }
          }
        );
      },
      /Unexpected empty page before reported total/
    );
  }

  // GraphQL errors remain visible (not swallowed as successful partial export)
  {
    const { api: api2 } = loadModule();
    await assert.rejects(
      function () {
        return api2.fetchAllGYGOptionsV2(
          "https://supplier.getyourguide.com/graphql",
          "query Q { __typename }",
          { filters: [] },
          {
            doOneGraphQLRequest: async function () {
              return bridgeOk({
                errors: [{ message: "Not authorized for supplier" }],
                data: null
              });
            }
          }
        );
      },
      /GetYourGuide GraphQL error: Not authorized for supplier/
    );
  }

  // HTTP failures remain visible
  {
    const { api: api2 } = loadModule();
    await assert.rejects(
      function () {
        return api2.fetchAllGYGOptionsV2(
          "https://supplier.getyourguide.com/graphql",
          "query Q { __typename }",
          { filters: [] },
          {
            doOneGraphQLRequest: async function () {
              return {
                ok: false,
                status: 500,
                statusText: "Internal Server Error",
                rawText: "boom"
              };
            }
          }
        );
      },
      /GetYourGuide GraphQL request failed with HTTP 500/
    );
  }

  console.log("getyourguide-products pagination: all assertions passed");
}

run().catch(function (err) {
  console.error(err);
  process.exit(1);
});
