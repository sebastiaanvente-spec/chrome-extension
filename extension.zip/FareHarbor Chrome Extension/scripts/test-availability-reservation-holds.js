const assert = require("assert");

// Mirror of reservation-hold helpers in content/availability-audit-api.js
const RESERVATION_HOLD_ACTIVITY_TYPES = {
  RESERVED: "reseller-reserved-booking",
  CANCELLED: "reseller-cancelled-reservation"
};

function toTimestampMs(value) {
  if (value == null || value === "") return null;
  if (value instanceof Date) {
    const ms = value.getTime();
    return Number.isNaN(ms) ? null : ms;
  }
  const parsed = new Date(value);
  const ms = parsed.getTime();
  return Number.isNaN(ms) ? null : ms;
}

function getActivityType(activity) {
  if (!activity || typeof activity !== "object") return null;
  if (activity.type != null && activity.type !== "") return String(activity.type);
  if (activity.activity_type != null && activity.activity_type !== "") {
    return String(activity.activity_type);
  }
  return null;
}

function getActivityBookingPk(activity) {
  const pk = activity?.context?.booking_pk;
  return pk != null && pk !== "" ? pk : null;
}

function parseHoldDurationMinutes(value) {
  if (value == null || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

function parseCustomerBreakdown(text) {
  if (text == null || text === "") return [];
  if (typeof text !== "string") return [];

  const normalized = text.replace(/\u00a0/g, " ").trim();
  if (!normalized) return [];

  const parts = normalized.split(",").map((part) => part.trim()).filter(Boolean);
  const results = [];
  const quantityPattern = /^(\d+)\s+(.+)$/;

  for (const part of parts) {
    const match = part.match(quantityPattern);
    if (!match) continue;
    const quantity = parseInt(match[1], 10);
    const name = match[2].trim();
    if (!name || !Number.isFinite(quantity) || quantity <= 0) continue;
    results.push({ name, quantity });
  }

  return results;
}

function sumCustomerTypes(customerTypes) {
  return customerTypes.reduce((sum, ct) => sum + (ct.quantity || 0), 0);
}

function sortActivitiesByCreatedAt(activities) {
  return [...(activities || [])].sort((a, b) => {
    const aMs = toTimestampMs(a?.created_at);
    const bMs = toTimestampMs(b?.created_at);
    if (aMs == null && bMs == null) return 0;
    if (aMs == null) return 1;
    if (bMs == null) return -1;
    return aMs - bMs;
  });
}

function extractReservationHoldActivities(activities) {
  const reservations = [];
  const cancellations = [];

  for (const activity of activities || []) {
    const type = getActivityType(activity);
    if (type === RESERVATION_HOLD_ACTIVITY_TYPES.RESERVED) {
      reservations.push(activity);
    } else if (type === RESERVATION_HOLD_ACTIVITY_TYPES.CANCELLED) {
      cancellations.push(activity);
    }
  }

  return { reservations, cancellations };
}

function parseReservationCustomerBreakdown(text) {
  const parsed = parseCustomerBreakdown(text);
  const customerTypes = parsed.map((entry) => ({
    name: entry.name,
    quantity: entry.quantity
  }));
  return {
    customerTypes,
    capacityUsed: sumCustomerTypes(customerTypes)
  };
}

function buildReservationHoldTimeline(reservations, cancellations, fulfilledBookingPks) {
  const fulfilled = new Set();
  for (const pk of fulfilledBookingPks || []) {
    if (pk == null || pk === "") continue;
    fulfilled.add(pk);
    fulfilled.add(String(pk));
    const numericPk = Number(pk);
    if (Number.isFinite(numericPk)) fulfilled.add(numericPk);
  }

  const reservationsByPk = {};
  const cancellationsByPk = {};

  for (const reservation of reservations || []) {
    const pk = getActivityBookingPk(reservation);
    if (pk == null) continue;
    if (fulfilled.has(pk) || fulfilled.has(String(pk))) continue;
    if (!reservationsByPk[pk]) reservationsByPk[pk] = [];
    reservationsByPk[pk].push(reservation);
  }

  for (const cancellation of cancellations || []) {
    const pk = getActivityBookingPk(cancellation);
    if (pk == null) continue;
    if (!cancellationsByPk[pk]) cancellationsByPk[pk] = [];
    cancellationsByPk[pk].push(cancellation);
  }

  const timeline = [];
  const bookingPks = new Set([
    ...Object.keys(reservationsByPk),
    ...Object.keys(cancellationsByPk)
  ]);

  for (const pkKey of bookingPks) {
    const reservationList = sortActivitiesByCreatedAt(reservationsByPk[pkKey] || []);
    const cancellationList = sortActivitiesByCreatedAt(cancellationsByPk[pkKey] || []);
    if (reservationList.length === 0) continue;

    for (let index = 0; index < reservationList.length; index += 1) {
      const reservation = reservationList[index];
      const cancellation = cancellationList[index] || null;
      const breakdown = reservation?.context?.customer_breakdown || null;
      const parsed = parseReservationCustomerBreakdown(breakdown);

      timeline.push({
        bookingPk: getActivityBookingPk(reservation) ?? pkKey,
        customerBreakdown: breakdown,
        reservedAt: reservation?.created_at || null,
        releasedAt: cancellation?.created_at || null,
        holdDurationMinutes: parseHoldDurationMinutes(reservation?.context?.hold_duration_minutes),
        customerTypes: parsed.customerTypes,
        capacityUsed: parsed.capacityUsed
      });
    }
  }

  return timeline;
}

function isReservationHoldActiveAtTimestamp(hold, targetMs) {
  const reservedMs = toTimestampMs(hold?.reservedAt);
  if (reservedMs == null || reservedMs > targetMs) return false;

  const releasedMs = toTimestampMs(hold?.releasedAt);
  if (releasedMs != null) return targetMs < releasedMs;

  const holdDurationMinutes = hold?.holdDurationMinutes;
  if (holdDurationMinutes != null) {
    return targetMs < reservedMs + holdDurationMinutes * 60 * 1000;
  }

  return false;
}

function getActiveReservationHoldsAtTimestamp(timeline, targetMs) {
  return (timeline || []).filter((hold) => isReservationHoldActiveAtTimestamp(hold, targetMs));
}

function buildScenarioActivities() {
  const expiredHoldReservation = {
    type: "reseller-reserved-booking",
    created_at: "2026-08-26T14:30:00+0000",
    context: {
      booking_pk: 375120421,
      customer_breakdown: "1\u00a0Adult",
      hold_duration_minutes: 15
    }
  };
  const expiredHoldCancellation = {
    type: "reseller-cancelled-reservation",
    created_at: "2026-08-26T14:45:04+0000",
    context: { booking_pk: 375120421 }
  };
  const successfulHoldReservation = {
    type: "reseller-reserved-booking",
    created_at: "2026-08-26T12:13:03+0000",
    context: {
      booking_pk: 375085511,
      customer_breakdown: "2\u00a0Adults",
      hold_duration_minutes: 15
    }
  };
  const fallbackHoldReservation = {
    type: "reseller-reserved-booking",
    created_at: "2026-08-26T14:30:00+0000",
    context: {
      booking_pk: 375999001,
      customer_breakdown: "1 Adult",
      hold_duration_minutes: 15
    }
  };

  return {
    expiredHoldReservation,
    expiredHoldCancellation,
    successfulHoldReservation,
    fallbackHoldReservation
  };
}

const scenarios = buildScenarioActivities();
const expiredOnlyReservations = [scenarios.expiredHoldReservation];
const expiredOnlyCancellations = [scenarios.expiredHoldCancellation];
const expiredTimeline = buildReservationHoldTimeline(
  expiredOnlyReservations,
  expiredOnlyCancellations,
  []
);

function assertActiveHoldCount(timeline, targetIso, expectedCount, label) {
  const targetMs = toTimestampMs(targetIso);
  const active = getActiveReservationHoldsAtTimestamp(timeline, targetMs);
  assert.strictEqual(
    active.length,
    expectedCount,
    `${label}: expected ${expectedCount} active holds at ${targetIso}, got ${active.length}`
  );
  return active;
}

// Test A — expired hold, target inside hold
const activeA = assertActiveHoldCount(
  expiredTimeline,
  "2026-08-26T14:40:00+0000",
  1,
  "Test A"
);
assert.strictEqual(activeA[0].capacityUsed, 1);
assert.strictEqual(activeA[0].customerTypes[0].name, "Adult");

// Test B — expired hold, target after expiry
assertActiveHoldCount(
  expiredTimeline,
  "2026-08-26T14:46:00+0000",
  0,
  "Test B"
);

// Test C — successful Viator hold excluded from timeline (no double-count path)
const { reservations: resC } = extractReservationHoldActivities([scenarios.successfulHoldReservation]);
const timelineC = buildReservationHoldTimeline(resC, [], [375085511]);
assert.strictEqual(timelineC.length, 0, "Test C: fulfilled hold must not appear in timeline");
assertActiveHoldCount(timelineC, "2026-08-26T14:40:00+0000", 0, "Test C active holds");

// Test D — target before hold
assertActiveHoldCount(
  expiredTimeline,
  "2026-08-26T14:20:00+0000",
  0,
  "Test D"
);

// Test E — no cancellation activity yet, fallback expiry
const fallbackTimeline = buildReservationHoldTimeline(
  [scenarios.fallbackHoldReservation],
  [],
  []
);
assertActiveHoldCount(fallbackTimeline, "2026-08-26T14:40:00+0000", 1, "Test E active");
assertActiveHoldCount(fallbackTimeline, "2026-08-26T14:46:00+0000", 0, "Test E inactive");

// Test F — resources unchanged (holds only affect capacity totals)
const bookingCapacity = 4;
const activeF = getActiveReservationHoldsAtTimestamp(
  expiredTimeline,
  toTimestampMs("2026-08-26T14:40:00+0000")
);
const holdCapacity = activeF.reduce((sum, hold) => sum + hold.capacityUsed, 0);
const resourcesUsed = {};
assert.strictEqual(bookingCapacity + holdCapacity, 5);
assert.deepStrictEqual(resourcesUsed, {});

console.log("All reservation hold scenarios passed (A-F).");
