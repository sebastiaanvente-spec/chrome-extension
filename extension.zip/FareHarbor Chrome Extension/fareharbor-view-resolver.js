/**
 * FareHarbor /api/v1/view/{Type}/{id}/ resolver for right-click jump navigation.
 * Dual-runtime: service worker (importScripts) + Node tests (require).
 */
(function (global) {
  'use strict';

  const LOG_PREFIX = '[fareharbor-view-resolver]';
  const BASE_ORIGIN = 'https://fareharbor.com';
  const DEV_MODE_STORAGE_KEY =
    global.FareHarborDeveloperAuth?.DEV_MODE_STORAGE_KEY || 'devModeEnabled';

  const JUMP_TO_VIEW_TYPE = {
    item: 'Item',
    booking: 'Booking',
    'channel-company': 'ResellerCompany',
    'channel-item': 'ResellerItem',
    'channel-option': 'ResellerOption',
  };

  const PREFIX_TOKEN = /^(?:pk|id|item|booking|channel)(?:[:\s#-]+|$)/i;

  let devModeEnabled = false;
  let devModeInitialized = false;

  function initDevModeListener() {
    if (devModeInitialized || typeof chrome === 'undefined' || !chrome.storage) return;
    devModeInitialized = true;
    const auth = global.FareHarborDeveloperAuth;
    if (!auth) {
      devModeEnabled = false;
      return;
    }
    auth.syncDevModeState().then((active) => {
      devModeEnabled = active;
    });
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== 'local' || !changes[DEV_MODE_STORAGE_KEY]) return;
      auth.syncDevModeState().then((active) => {
        devModeEnabled = active;
      });
    });
  }

  function resolverDebugLog(...args) {
    if (devModeEnabled) {
      console.log(LOG_PREFIX, ...args);
    }
  }

  function normalizeFareHarborId(rawText) {
    if (rawText == null) return null;
    let text = String(rawText).trim();
    if (!text) return null;

    text = text.replace(/^#+\s*/, '');

    let prev;
    do {
      prev = text;
      text = text.replace(PREFIX_TOKEN, '').trim();
    } while (text !== prev && text.length > 0);

    text = text.replace(/^[^0-9]+/, '');

    const match = text.match(/\d+/);
    return match ? match[0] : null;
  }

  function getShortname(object) {
    return object && object.company && object.company.shortname
      ? String(object.company.shortname)
      : null;
  }

  function buildFareHarborUrl(shortname, path) {
    const normalizedPath = path.startsWith('/') ? path : `/${path}`;
    return `${BASE_ORIGIN}/${encodeURIComponent(shortname)}${normalizedPath}`;
  }

  const API_BOOKING_PATH_RE =
    /^\/api\/v1\/companies\/([^/]+)\/bookings\/([^/]+)\/?$/i;
  const BOOKING_GRID_DATE_RE = /\/dashboard\/bookings\/grid\/([^/]+)\/?/i;
  const CONTACT_BOOKING_PATH_RE = /\/contacts\/([^/]+)\/bookings\/([^/]+)\/?/i;
  const DASHBOARD_BOOKING_DETAIL_RE =
    /\/dashboard\/bookings\/(?!grid\/)([^/]+)\/?/i;

  function getLocalIsoDate(date = new Date()) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function parseCompanyShortnameFromPathname(pathname) {
    const parts = String(pathname || '').split('/').filter(Boolean);
    return parts.length > 0 ? decodeURIComponent(parts[0]) : null;
  }

  function resolveBookingGridDate(context = {}) {
    if (context.gridDate) return context.gridDate;
    if (context.pathname) {
      const match = String(context.pathname).match(BOOKING_GRID_DATE_RE);
      if (match) {
        return match[1] === 'today' ? getLocalIsoDate() : match[1];
      }
    }
    return getLocalIsoDate();
  }

  function buildBookingOverlayPath(contactPk, uuid) {
    if (!uuid) return null;
    if (contactPk) {
      return `/contacts/${encodeURIComponent(contactPk)}/bookings/${encodeURIComponent(uuid)}/`;
    }
    return `/dashboard/bookings/${encodeURIComponent(uuid)}/`;
  }

  function buildBookingGridOverlayUrl(shortname, overlayPath, gridDate) {
    if (!shortname || !overlayPath || !gridDate) return null;
    const normalizedOverlay = overlayPath.startsWith('/')
      ? overlayPath
      : `/${overlayPath}`;
    const gridPath = `/dashboard/bookings/grid/${encodeURIComponent(gridDate)}/`;
    return `${BASE_ORIGIN}/${encodeURIComponent(shortname)}${gridPath}?overlay=${encodeURIComponent(normalizedOverlay)}`;
  }

  function isBookingGridOverlayUrl(url) {
    if (!url) return false;
    try {
      const parsed = new URL(url, BASE_ORIGIN);
      return (
        BOOKING_GRID_DATE_RE.test(parsed.pathname) &&
        parsed.searchParams.has('overlay')
      );
    } catch (_err) {
      return false;
    }
  }

  function parseShortnameFromFareHarborPath(pathname) {
    const parts = String(pathname || '').split('/').filter(Boolean);
    return parts.length > 0 ? decodeURIComponent(parts[0]) : null;
  }

  function parseContactBookingPath(urlOrPath) {
    if (urlOrPath == null) return null;
    try {
      const parsed = new URL(String(urlOrPath).trim(), BASE_ORIGIN);
      const match = parsed.pathname.match(CONTACT_BOOKING_PATH_RE);
      if (!match) return null;
      const contactPk = decodeURIComponent(match[1]);
      const uuid = decodeURIComponent(match[2]);
      return {
        shortname: parseShortnameFromFareHarborPath(parsed.pathname),
        contactPk,
        uuid,
        overlayPath: buildBookingOverlayPath(contactPk, uuid),
      };
    } catch (_err) {
      return null;
    }
  }

  function parseDashboardBookingDetailPath(urlOrPath) {
    if (urlOrPath == null) return null;
    try {
      const parsed = new URL(String(urlOrPath).trim(), BASE_ORIGIN);
      const match = parsed.pathname.match(DASHBOARD_BOOKING_DETAIL_RE);
      if (!match) return null;
      const uuid = decodeURIComponent(match[1]);
      return {
        shortname: parseShortnameFromFareHarborPath(parsed.pathname),
        uuid,
        overlayPath: buildBookingOverlayPath(null, uuid),
      };
    } catch (_err) {
      return null;
    }
  }

  function wrapBookingOverlayAsGridUrl(shortname, overlayPath, context = {}) {
    if (!shortname || !overlayPath) return null;
    const gridDate = resolveBookingGridDate(context);
    return buildBookingGridOverlayUrl(shortname, overlayPath, gridDate);
  }

  function isFareHarborApiUrl(url) {
    if (!url) return false;
    try {
      return new URL(url, BASE_ORIGIN).pathname.startsWith('/api/v1/');
    } catch (_err) {
      return false;
    }
  }

  function parseApiBookingUrl(urlOrPath) {
    if (urlOrPath == null) return null;
    try {
      const pathname = new URL(String(urlOrPath).trim(), BASE_ORIGIN).pathname;
      const match = pathname.match(API_BOOKING_PATH_RE);
      if (!match) return null;
      return {
        shortname: decodeURIComponent(match[1]),
        uuid: decodeURIComponent(match[2]),
      };
    } catch (_err) {
      return null;
    }
  }

  function normalizeUrlField(value) {
    if (value == null) return null;
    const text = String(value).trim();
    if (!text) return null;
    if (/^https?:\/\//i.test(text)) return text;
    if (text.startsWith('/')) return `${BASE_ORIGIN}${text}`;
    return null;
  }

  function pickExplicitDashboardUrl(object) {
    const fields = ['dashboard_url', 'url', 'uri', 'admin_url'];
    for (let i = 0; i < fields.length; i++) {
      const normalized = normalizeUrlField(object[fields[i]]);
      if (normalized && !isFareHarborApiUrl(normalized)) return normalized;
    }
    return null;
  }

  function buildBookingDashboardUrl(object, context = {}) {
    const explicit = pickExplicitDashboardUrl(object);
    if (explicit && isBookingGridOverlayUrl(explicit)) return explicit;

    const shortname = getShortname(object);
    const uuid = object.uuid != null ? String(object.uuid) : null;
    const contactPk =
      object.contact && object.contact.pk != null ? String(object.contact.pk) : null;
    const resolvedShortname =
      shortname ||
      (explicit ? parseShortnameFromFareHarborPath(new URL(explicit, BASE_ORIGIN).pathname) : null) ||
      context.shortname ||
      null;

    if (explicit) {
      const contactParsed = parseContactBookingPath(explicit);
      if (contactParsed) {
        return wrapBookingOverlayAsGridUrl(
          resolvedShortname || contactParsed.shortname,
          contactParsed.overlayPath,
          context
        );
      }

      const dashboardParsed = parseDashboardBookingDetailPath(explicit);
      if (dashboardParsed) {
        return wrapBookingOverlayAsGridUrl(
          resolvedShortname || dashboardParsed.shortname,
          dashboardParsed.overlayPath,
          context
        );
      }
    }

    if (resolvedShortname && uuid) {
      const overlayPath = buildBookingOverlayPath(contactPk, uuid);
      const gridUrl = wrapBookingOverlayAsGridUrl(resolvedShortname, overlayPath, context);
      if (gridUrl) return gridUrl;
    }

    const apiFields = ['dashboard_url', 'url', 'uri', 'admin_url'];
    for (let i = 0; i < apiFields.length; i++) {
      const normalized = normalizeUrlField(object[apiFields[i]]);
      if (!normalized || !isFareHarborApiUrl(normalized)) continue;
      const parsed = parseApiBookingUrl(normalized);
      if (!parsed) continue;
      const overlayPath = buildBookingOverlayPath(
        contactPk,
        uuid || parsed.uuid
      );
      const gridUrl = wrapBookingOverlayAsGridUrl(
        resolvedShortname || parsed.shortname,
        overlayPath,
        context
      );
      if (gridUrl) return gridUrl;
    }

    return null;
  }

  function resolveBookingHrefToGridOverlay(href, context = {}) {
    if (href == null) return null;
    const hrefText = String(href).trim();
    if (!hrefText) return null;

    if (isBookingGridOverlayUrl(hrefText)) {
      return normalizeUrlField(hrefText);
    }

    const apiParsed = parseApiBookingUrl(hrefText);
    if (apiParsed) {
      const overlayPath = buildBookingOverlayPath(null, apiParsed.uuid);
      return wrapBookingOverlayAsGridUrl(
        context.shortname || apiParsed.shortname,
        overlayPath,
        context
      );
    }

    const contactParsed = parseContactBookingPath(hrefText);
    if (contactParsed) {
      return wrapBookingOverlayAsGridUrl(
        context.shortname || contactParsed.shortname,
        contactParsed.overlayPath,
        context
      );
    }

    const dashboardParsed = parseDashboardBookingDetailPath(hrefText);
    if (dashboardParsed) {
      return wrapBookingOverlayAsGridUrl(
        context.shortname || dashboardParsed.shortname,
        dashboardParsed.overlayPath,
        context
      );
    }

    return null;
  }

  function resolveApiBookingHrefToDashboard(href, context = {}) {
    return resolveBookingHrefToGridOverlay(href, context);
  }

  function buildDashboardUrl(viewType, object, context = {}) {
    if (!object || typeof object !== 'object') return null;

    const shortname = getShortname(object);
    const pk = object.pk != null ? String(object.pk) : null;

    switch (viewType) {
      case 'Item':
        if (!shortname || !pk) return null;
        return buildFareHarborUrl(shortname, `/dashboard/items/${encodeURIComponent(pk)}/`);

      case 'Booking':
        return buildBookingDashboardUrl(object, context);

      case 'ResellerCompany':
        if (!shortname || !pk) return null;
        return buildFareHarborUrl(
          shortname,
          `/dashboard/settings/integrations/channels/${encodeURIComponent(pk)}/`
        );

      case 'ResellerItem': {
        const resellerCompanyPk =
          object.reseller_company && object.reseller_company.pk != null
            ? String(object.reseller_company.pk)
            : null;
        if (!shortname || !pk || !resellerCompanyPk) return null;
        return buildFareHarborUrl(
          shortname,
          `/dashboard/settings/integrations/channels/${encodeURIComponent(resellerCompanyPk)}/items/${encodeURIComponent(pk)}/`
        );
      }

      case 'ResellerOption': {
        const resellerItem = object.reseller_item;
        const resellerItemPk =
          resellerItem && resellerItem.pk != null ? String(resellerItem.pk) : null;
        const resellerCompanyPk =
          resellerItem &&
          resellerItem.reseller_company &&
          resellerItem.reseller_company.pk != null
            ? String(resellerItem.reseller_company.pk)
            : null;
        if (!shortname || !pk || !resellerItemPk || !resellerCompanyPk) return null;
        return buildFareHarborUrl(
          shortname,
          `/dashboard/settings/integrations/channels/${encodeURIComponent(resellerCompanyPk)}/items/${encodeURIComponent(resellerItemPk)}/options/${encodeURIComponent(pk)}/`
        );
      }

      default:
        return null;
    }
  }

  function summarizeObjectHierarchy(viewType, object) {
    if (!object) return null;
    const summary = {
      viewType,
      shortname: getShortname(object),
      pk: object.pk != null ? object.pk : null,
    };

    if (viewType === 'ResellerItem' && object.reseller_company) {
      summary.resellerCompanyPk = object.reseller_company.pk;
    }
    if (viewType === 'ResellerOption' && object.reseller_item) {
      summary.resellerItemPk = object.reseller_item.pk;
      if (object.reseller_item.reseller_company) {
        summary.resellerCompanyPk = object.reseller_item.reseller_company.pk;
      }
    }
    if (viewType === 'Booking') {
      summary.uuid = object.uuid || null;
      summary.contactPk =
        object.contact && object.contact.pk != null ? object.contact.pk : null;
    }

    return summary;
  }

  async function fetchViewObject(viewType, id) {
    const resolverUrl = `${BASE_ORIGIN}/api/v1/view/${viewType}/${encodeURIComponent(id)}/`;

    try {
      const response = await fetch(resolverUrl, {
        method: 'GET',
        credentials: 'include',
        headers: { Accept: 'application/json' },
      });

      const text = await response.text();
      let data = null;
      if (text) {
        try {
          data = JSON.parse(text);
        } catch (parseErr) {
          return {
            ok: false,
            resolverUrl,
            error: 'invalid-json',
            status: response.status,
            bodySnippet: text.slice(0, 200),
          };
        }
      }

      if (!response.ok) {
        return {
          ok: false,
          resolverUrl,
          error: 'http-error',
          status: response.status,
          bodySnippet: text ? text.slice(0, 200) : '',
        };
      }

      const object = data && data.view && data.view.object;
      if (!object) {
        return {
          ok: false,
          resolverUrl,
          error: 'missing-view-object',
          status: response.status,
        };
      }

      return {
        ok: true,
        resolverUrl,
        object,
        status: response.status,
      };
    } catch (err) {
      return {
        ok: false,
        resolverUrl,
        error: 'fetch-failed',
        message: err && err.message ? err.message : String(err),
      };
    }
  }

  async function resolveFareHarborJump(jumpType, rawText) {
    initDevModeListener();

    const meta = {
      rawText,
      jumpType,
      normalizedId: null,
      viewType: null,
      resolverUrl: null,
      hierarchy: null,
      url: null,
    };

    resolverDebugLog('resolve start', { rawText, jumpType });

    const viewType = JUMP_TO_VIEW_TYPE[jumpType];
    if (!viewType) {
      const fallbackReason = 'unknown-jump-type';
      console.warn(LOG_PREFIX, fallbackReason, meta);
      return { ok: false, fallbackReason, meta };
    }
    meta.viewType = viewType;

    const normalizedId = normalizeFareHarborId(rawText);
    meta.normalizedId = normalizedId;
    resolverDebugLog('normalized ID', normalizedId);

    if (!normalizedId) {
      const fallbackReason = 'no-numeric-id';
      console.warn(LOG_PREFIX, fallbackReason, meta);
      return { ok: false, fallbackReason, meta };
    }

    const fetchResult = await fetchViewObject(viewType, normalizedId);
    meta.resolverUrl = fetchResult.resolverUrl;
    resolverDebugLog('resolver URL', fetchResult.resolverUrl);

    if (!fetchResult.ok) {
      const fallbackReason = fetchResult.error || 'resolver-failed';
      console.warn(LOG_PREFIX, 'resolver failed', fallbackReason, fetchResult, meta);
      return { ok: false, fallbackReason, meta };
    }

    meta.hierarchy = summarizeObjectHierarchy(viewType, fetchResult.object);
    resolverDebugLog('resolved hierarchy', meta.hierarchy);

    const url = buildDashboardUrl(viewType, fetchResult.object);
    meta.url = url;
    resolverDebugLog('final dashboard URL', url);

    if (!url) {
      const fallbackReason = 'url-build-failed';
      console.warn(LOG_PREFIX, fallbackReason, meta);
      return { ok: false, fallbackReason, meta };
    }

    resolverDebugLog('resolve success', meta);
    return { ok: true, url, meta };
  }

  const api = {
    JUMP_TO_VIEW_TYPE,
    normalizeFareHarborId,
    buildDashboardUrl,
    fetchViewObject,
    resolveFareHarborJump,
    summarizeObjectHierarchy,
    isFareHarborApiUrl,
    parseApiBookingUrl,
    resolveApiBookingHrefToDashboard,
    resolveBookingHrefToGridOverlay,
    parseCompanyShortnameFromPathname,
  };

  if (typeof globalThis !== 'undefined') {
    Object.assign(globalThis, api);
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
