/**
 * Developer authorization and DEV mode gating for FareHarbor Automator.
 * Dual-runtime: content/popup (global) + service worker (importScripts) + Node tests (require).
 */
(function (global) {
  'use strict';

  const LOG_PREFIX = '[developer-auth]';
  const DEV_MODE_STORAGE_KEY = 'devModeEnabled';
  const USER_NAME_SELECTOR = '.db-header-btn--user-name';
  const AUTHORIZED_DEVELOPER_NAMES = new Set([
    'Sebastiaan Vente',
  ]);
  const FAREHARBOR_TAB_URL_PATTERNS = [
    'https://fareharbor.com/*',
    'https://*.fareharbor.com/*',
  ];

  function logUnavailable(reason, details) {
    if (details !== undefined) {
      console.log(LOG_PREFIX, 'DEV mode unavailable:', reason, details);
      return;
    }
    console.log(LOG_PREFIX, 'DEV mode unavailable:', reason);
  }

  function isAuthorizedDeveloperUser() {
    try {
      if (typeof document === 'undefined') {
        return false;
      }
      const el = document.querySelector(USER_NAME_SELECTOR);
      if (!el) {
        return false;
      }
      const name = el.textContent.trim();
      return AUTHORIZED_DEVELOPER_NAMES.has(name);
    } catch {
      return false;
    }
  }

  function readDevModeFlagFromStorage(callback) {
    try {
      if (typeof chrome === 'undefined' || !chrome.storage?.local) {
        callback(false);
        return;
      }
      chrome.storage.local.get({ [DEV_MODE_STORAGE_KEY]: false }, (result) => {
        callback(!!result[DEV_MODE_STORAGE_KEY]);
      });
    } catch {
      callback(false);
    }
  }

  function readDevModeFlagFromStorageAsync() {
    return new Promise((resolve) => {
      readDevModeFlagFromStorage(resolve);
    });
  }

  function writeDevModeFlagToStorage(enabled, callback) {
    try {
      if (typeof chrome === 'undefined' || !chrome.storage?.local) {
        if (callback) callback(false);
        return;
      }
      chrome.storage.local.set({ [DEV_MODE_STORAGE_KEY]: !!enabled }, () => {
        if (callback) callback(true);
      });
    } catch {
      if (callback) callback(false);
    }
  }

  function writeDevModeFlagToStorageAsync(enabled) {
    return new Promise((resolve) => {
      writeDevModeFlagToStorage(enabled, resolve);
    });
  }

  function isDevModeActiveSync(authorized, flagEnabled) {
    return !!authorized && !!flagEnabled;
  }

  async function syncDevModeState() {
    const authorized = isAuthorizedDeveloperUser();
    const flagEnabled = await readDevModeFlagFromStorageAsync();

    if (!authorized) {
      if (flagEnabled) {
        logUnavailable('clearing stored devModeEnabled because user is not an authorized developer');
        await writeDevModeFlagToStorageAsync(false);
      }
      return false;
    }

    return !!flagEnabled;
  }

  async function isDevModeActiveAsync() {
    return syncDevModeState();
  }

  function requestDevModeChange(enabled, callback) {
    if (!isAuthorizedDeveloperUser()) {
      logUnavailable('cannot change DEV mode because user is not an authorized developer');
      if (callback) callback(false);
      return;
    }

    writeDevModeFlagToStorage(enabled, (ok) => {
      if (!ok) {
        logUnavailable('cannot change DEV mode because chrome.storage is unavailable');
      }
      if (callback) callback(ok);
    });
  }

  function sendTabMessageAsync(tabId, message) {
    return new Promise((resolve) => {
      try {
        chrome.tabs.sendMessage(tabId, message, (response) => {
          if (chrome.runtime.lastError) {
            resolve(null);
            return;
          }
          resolve(response || null);
        });
      } catch {
        resolve(null);
      }
    });
  }

  function queryTabsAsync(queryInfo) {
    return new Promise((resolve) => {
      try {
        chrome.tabs.query(queryInfo, (tabs) => resolve(Array.isArray(tabs) ? tabs : []));
      } catch {
        resolve([]);
      }
    });
  }

  async function queryDeveloperAuthorizationFromTabs() {
    if (typeof chrome === 'undefined' || !chrome.tabs?.query) {
      logUnavailable('authorization cannot be determined: chrome.tabs unavailable');
      return { authorized: false, devModeActive: false, reason: 'chrome.tabs unavailable' };
    }

    const tabs = await queryTabsAsync({ url: FAREHARBOR_TAB_URL_PATTERNS });
    for (const tab of tabs) {
      if (!tab?.id) continue;
      const response = await sendTabMessageAsync(tab.id, { action: 'checkDeveloperAuthorization' });
      if (response?.authorized) {
        return {
          authorized: true,
          devModeActive: !!response.devModeActive,
          developerName: response.developerName || null,
        };
      }
    }

    logUnavailable('authorization cannot be determined: no authorized developer session found on FareHarbor tabs');
    return {
      authorized: false,
      devModeActive: false,
      reason: 'no authorized developer session found',
    };
  }

  async function requireAuthorizedDeveloperAsync(actionLabel) {
    const authorized = isAuthorizedDeveloperUser();
    if (authorized) {
      return true;
    }

    if (typeof document !== 'undefined') {
      logUnavailable(
        actionLabel
          ? `${actionLabel} blocked: user is not an authorized developer`
          : 'user is not an authorized developer'
      );
      return false;
    }

    const auth = await queryDeveloperAuthorizationFromTabs();
    if (!auth.authorized) {
      logUnavailable(
        actionLabel
          ? `${actionLabel} blocked: ${auth.reason || 'user is not an authorized developer'}`
          : auth.reason || 'user is not an authorized developer'
      );
      return false;
    }

    return true;
  }

  async function requireActiveDevModeAsync(actionLabel) {
    if (typeof document !== 'undefined') {
      const active = await isDevModeActiveAsync();
      if (!active) {
        if (!isAuthorizedDeveloperUser()) {
          logUnavailable(
            actionLabel
              ? `${actionLabel} blocked: user is not an authorized developer`
              : 'user is not an authorized developer'
          );
        } else {
          logUnavailable(
            actionLabel
              ? `${actionLabel} blocked: DEV mode is not enabled`
              : 'DEV mode is not enabled'
          );
        }
      }
      return active;
    }

    const auth = await queryDeveloperAuthorizationFromTabs();
    if (!auth.authorized) {
      logUnavailable(
        actionLabel
          ? `${actionLabel} blocked: ${auth.reason || 'user is not an authorized developer'}`
          : auth.reason || 'user is not an authorized developer'
      );
      return false;
    }

    if (!auth.devModeActive) {
      logUnavailable(
        actionLabel
          ? `${actionLabel} blocked: DEV mode is not enabled`
          : 'DEV mode is not enabled'
      );
      return false;
    }

    return true;
  }

  function getDeveloperAuthorizationStatus() {
    const authorized = isAuthorizedDeveloperUser();
    let developerName = null;
    if (authorized) {
      try {
        const el = document.querySelector(USER_NAME_SELECTOR);
        developerName = el ? el.textContent.trim() : null;
      } catch {
        developerName = null;
      }
    }

    return {
      authorized,
      developerName,
      reason: authorized ? null : 'user is not an authorized developer',
    };
  }

  const api = {
    LOG_PREFIX,
    DEV_MODE_STORAGE_KEY,
    USER_NAME_SELECTOR,
    AUTHORIZED_DEVELOPER_NAMES,
    FAREHARBOR_TAB_URL_PATTERNS,
    logUnavailable,
    isAuthorizedDeveloperUser,
    readDevModeFlagFromStorage,
    readDevModeFlagFromStorageAsync,
    writeDevModeFlagToStorage,
    writeDevModeFlagToStorageAsync,
    isDevModeActiveSync,
    syncDevModeState,
    isDevModeActiveAsync,
    requestDevModeChange,
    queryDeveloperAuthorizationFromTabs,
    requireAuthorizedDeveloperAsync,
    requireActiveDevModeAsync,
    getDeveloperAuthorizationStatus,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    global.FareHarborDeveloperAuth = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : typeof self !== 'undefined' ? self : this);
