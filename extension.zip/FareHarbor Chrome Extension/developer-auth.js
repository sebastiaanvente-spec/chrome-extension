/**
 * DEV mode storage and passcode gate for FareHarbor Automator.
 * Dual-runtime: content/popup (global) + service worker (importScripts) + Node tests (require).
 */
(function (global) {
  'use strict';

  const LOG_PREFIX = '[dev-mode]';
  const DEV_MODE_STORAGE_KEY = 'devModeEnabled';
  const DEV_MODE_PASSCODE = 'CHANGE_ME';

  function logUnavailable(reason, details) {
    if (details !== undefined) {
      console.log(LOG_PREFIX, 'DEV mode unavailable:', reason, details);
      return;
    }
    console.log(LOG_PREFIX, 'DEV mode unavailable:', reason);
  }

  function validatePasscode(passcode) {
    return String(passcode) === DEV_MODE_PASSCODE;
  }

  function readDevModeFlagFromStorage(callback) {
    try {
      if (typeof chrome === 'undefined' || !chrome.storage?.local) {
        callback(false);
        return;
      }
      chrome.storage.local.get({ [DEV_MODE_STORAGE_KEY]: false }, (result) => {
        callback(!!result[DEV_MODE_STORAGE_KEY]);
      });
    } catch {
      callback(false);
    }
  }

  function readDevModeFlagFromStorageAsync() {
    return new Promise((resolve) => {
      readDevModeFlagFromStorage(resolve);
    });
  }

  function writeDevModeFlagToStorage(enabled, callback) {
    try {
      if (typeof chrome === 'undefined' || !chrome.storage?.local) {
        if (callback) callback(false);
        return;
      }
      chrome.storage.local.set({ [DEV_MODE_STORAGE_KEY]: !!enabled }, () => {
        if (callback) callback(true);
      });
    } catch {
      if (callback) callback(false);
    }
  }

  function writeDevModeFlagToStorageAsync(enabled) {
    return new Promise((resolve) => {
      writeDevModeFlagToStorage(enabled, resolve);
    });
  }

  async function isDevModeActiveAsync() {
    return readDevModeFlagFromStorageAsync();
  }

  async function syncDevModeState() {
    return readDevModeFlagFromStorageAsync();
  }

  function requestDevModeChange(enabled, callback) {
    writeDevModeFlagToStorage(enabled, (ok) => {
      if (!ok) {
        logUnavailable('cannot change DEV mode because chrome.storage is unavailable');
      }
      if (callback) callback(ok);
    });
  }

  async function requireActiveDevModeAsync(actionLabel) {
    const active = await isDevModeActiveAsync();
    if (!active) {
      logUnavailable(
        actionLabel
          ? `${actionLabel} blocked: DEV mode is not enabled`
          : 'DEV mode is not enabled'
      );
    }
    return active;
  }

  const api = {
    LOG_PREFIX,
    DEV_MODE_STORAGE_KEY,
    DEV_MODE_PASSCODE,
    logUnavailable,
    validatePasscode,
    readDevModeFlagFromStorage,
    readDevModeFlagFromStorageAsync,
    writeDevModeFlagToStorage,
    writeDevModeFlagToStorageAsync,
    isDevModeActiveAsync,
    syncDevModeState,
    requestDevModeChange,
    requireActiveDevModeAsync,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    global.FareHarborDeveloperAuth = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : typeof self !== 'undefined' ? self : this);
