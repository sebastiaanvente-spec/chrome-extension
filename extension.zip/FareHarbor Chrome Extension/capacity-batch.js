/**
 * Single active capacity-check batch in chrome.storage.local.
 * Popup loads this before popup.js; exposes window.CapacityBatch.
 */
(function (global) {
  'use strict';

  const STORAGE_KEY = 'fh_capacity_batch_v1';

  const STATUS_PRIORITY = {
    active_at_snapshot: 0,
    created_after_snapshot: 1,
    cancelled_before_snapshot: 2
  };

  function newBatchId() {
    if (global.crypto && typeof global.crypto.randomUUID === 'function') {
      return global.crypto.randomUUID();
    }
    return `${Date.now()}-${Math.random().toString(36).slice(2, 11)}`;
  }

  function toISOStringSafe(value) {
    if (value == null || value === '') return null;
    const d = value instanceof Date ? value : new Date(value);
    return isNaN(d.getTime()) ? null : d.toISOString();
  }

  function normalizeBookingStatus(booking, isFiltered) {
    if (isFiltered) return 'active_at_snapshot';
    if (booking.isCancelled) {
      if (booking.reason === 'cancelled_created_after_target') {
        return 'created_after_snapshot';
      }
      return 'cancelled_before_snapshot';
    }
    return 'created_after_snapshot';
  }

  function serializeBookingForTsvSource(b) {
    if (!b) return null;
    let dt = null;
    if (b.datetime != null) {
      const d =
        b.datetime instanceof Date ? b.datetime : new Date(b.datetime);
      dt = isNaN(d.getTime()) ? null : d.toISOString();
    }
    let ba;
    if (b.bookedAt != null) {
      const d =
        b.bookedAt instanceof Date ? b.bookedAt : new Date(b.bookedAt);
      ba = isNaN(d.getTime()) ? undefined : d.toISOString();
    }
    return {
      bookingNumber: b.bookingNumber,
      partySize: b.partySize,
      customerTypes: Array.isArray(b.customerTypes) ? b.customerTypes : [],
      resourceUses: extractResourceUsesForTsv(b),
      isCancelled: !!b.isCancelled,
      datetime: dt,
      bookedAt: ba,
      reason: b.reason,
      bookingHref: b.bookingHref,
      hasHref: b.hasHref,
      index: b.index
    };
  }

  function normalizeResourceNameKey(name) {
    return String(name || '')
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function isValidResourceNameForTsv(name) {
    const trimmed = String(name || '').trim();
    return trimmed.length > 0 && trimmed !== 'Unknown';
  }

  function extractResourceUsesForTsv(booking) {
    if (!booking || typeof booking !== 'object') return [];

    if (Array.isArray(booking.resourceUses) && booking.resourceUses.length > 0) {
      return booking.resourceUses
        .map((use) => ({
          resourceId: use.resourceId ?? null,
          resourceName: use.resourceName,
          quantity: use.quantity || 0
        }))
        .filter(
          (use) => isValidResourceNameForTsv(use.resourceName) && use.quantity > 0
        );
    }

    if (
      Array.isArray(booking.resourceUsesAtTimestamp) &&
      booking.resourceUsesAtTimestamp.length > 0
    ) {
      return booking.resourceUsesAtTimestamp
        .map((use) => ({
          resourceId: use.resourceId ?? null,
          resourceName: use.resourceName,
          quantity: use.quantity || 0
        }))
        .filter(
          (use) => isValidResourceNameForTsv(use.resourceName) && use.quantity > 0
        );
    }

    const detailed = booking.detailedInfo?.resources?.detailed;
    if (Array.isArray(detailed) && detailed.length > 0) {
      return detailed
        .map((resource) => ({
          resourceId: resource.resourceId ?? resource.id ?? resource.pk ?? null,
          resourceName: resource.name,
          quantity: resource.quantity || 0
        }))
        .filter(
          (use) => isValidResourceNameForTsv(use.resourceName) && use.quantity > 0
        );
    }

    return [];
  }

  function buildResourceAggregateKey(use) {
    if (use.resourceId != null && use.resourceId !== '') {
      return String(use.resourceId);
    }
    return `name:${normalizeResourceNameKey(use.resourceName)}`;
  }

  function buildResourceColumns(bookings, resourcesUsed) {
    const columns = [];
    const seenLabels = new Set();

    if (resourcesUsed && typeof resourcesUsed === 'object') {
      for (const [resourceName, value] of Object.entries(resourcesUsed)) {
        if (resourceName === '_total') continue;
        if (typeof value !== 'number' || !Number.isFinite(value)) continue;
        if (!isValidResourceNameForTsv(resourceName)) continue;
        columns.push({
          aggregateKey: `name:${normalizeResourceNameKey(resourceName)}`,
          label: resourceName
        });
        seenLabels.add(resourceName);
      }
    }

    const extras = [];
    for (const booking of bookings || []) {
      for (const use of extractResourceUsesForTsv(booking)) {
        if (seenLabels.has(use.resourceName)) continue;
        seenLabels.add(use.resourceName);
        extras.push({
          aggregateKey: buildResourceAggregateKey(use),
          label: use.resourceName
        });
      }
    }

    extras.sort((a, b) =>
      a.label.localeCompare(b.label, undefined, { sensitivity: 'base' })
    );
    return [...columns, ...extras];
  }

  function groupBookingResourcesByKey(booking, resourceColumns) {
    const labelToAggregateKey = new Map(
      (resourceColumns || []).map((col) => [col.label, col.aggregateKey])
    );
    const grouped = {};
    for (const use of extractResourceUsesForTsv(booking)) {
      const aggregateKey =
        labelToAggregateKey.get(use.resourceName) || buildResourceAggregateKey(use);
      grouped[aggregateKey] = (grouped[aggregateKey] || 0) + (use.quantity || 0);
    }
    return grouped;
  }

  function toSafeNumber(value) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function buildResourceTotalRowValues(
    resourceColumns,
    resourcesUsed,
    filteredBookings
  ) {
    const totals = {};
    for (const booking of filteredBookings || []) {
      const grouped = groupBookingResourcesByKey(booking, resourceColumns);
      for (const [aggregateKey, quantity] of Object.entries(grouped)) {
        totals[aggregateKey] =
          (totals[aggregateKey] || 0) + toSafeNumber(quantity);
      }
    }
    const fromRows = resourceColumns.map((col) => totals[col.aggregateKey] || 0);

    if (resourcesUsed && typeof resourcesUsed === 'object') {
      const hasSummary = Object.keys(resourcesUsed).some(
        (key) => key !== '_total' && typeof resourcesUsed[key] === 'number'
      );
      if (hasSummary) {
        const storedTotals = resourceColumns.map((col) => {
          const value = resourcesUsed[col.label];
          return typeof value === 'number' && Number.isFinite(value) ? value : 0;
        });
        const mismatch = storedTotals.some(
          (value, i) => toSafeNumber(value) !== fromRows[i]
        );
        if (mismatch) {
          console.warn('[capacity-check] Stored resource totals did not match row totals', {
            storedTotals,
            recalculatedTotals: fromRows
          });
        }
      }
    }

    return fromRows;
  }

  function normalizeCustomerTypeLookupKey(value) {
    return String(value || '')
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function buildCustomerTypeResolver(lookupEntries) {
    const lookup = new Map(Array.isArray(lookupEntries) ? lookupEntries : []);
    return function resolveCustomerType(typeName) {
      const raw = String(typeName || '').trim();
      if (!raw) return null;
      const key = normalizeCustomerTypeLookupKey(raw);
      const resolved = lookup.get(key);
      if (resolved) {
        const label = resolved.canonicalLabel || raw;
        const aggregateKey = String(
          resolved.customerTypePk ??
            resolved.customerPrototypePk ??
            label
        );
        return { aggregateKey, label };
      }
      console.warn(
        '[capacity-batch] No customer type PK mapping for raw label:',
        raw
      );
      return {
        aggregateKey: `unmapped:${key}`,
        label: raw
      };
    };
  }

  function buildCustomerTypeColumns(
    bookings,
    resolveCustomerType,
    customerTypesUsedDetailed,
    customerTypesUsed
  ) {
    const labelToAggregateKey = new Map();

    if (customerTypesUsedDetailed && typeof customerTypesUsedDetailed === 'object') {
      for (const [aggregateKey, entry] of Object.entries(customerTypesUsedDetailed)) {
        if (entry && entry.label) {
          labelToAggregateKey.set(entry.label, String(aggregateKey));
        }
      }
    }

    for (const booking of bookings || []) {
      if (!booking.customerTypes || !Array.isArray(booking.customerTypes)) continue;
      for (const ct of booking.customerTypes) {
        const resolved = resolveCustomerType(ct.name);
        if (!resolved) continue;
        if (!labelToAggregateKey.has(resolved.label)) {
          labelToAggregateKey.set(resolved.label, resolved.aggregateKey);
        }
      }
    }

    if (customerTypesUsed && typeof customerTypesUsed === 'object') {
      for (const label of Object.keys(customerTypesUsed)) {
        if (!label || labelToAggregateKey.has(label)) continue;
        labelToAggregateKey.set(
          label,
          `summary:${normalizeCustomerTypeLookupKey(label)}`
        );
      }
    }

    return [...labelToAggregateKey.entries()]
      .map(([label, aggregateKey]) => ({ aggregateKey, label }))
      .sort((a, b) =>
        a.label.localeCompare(b.label, undefined, { sensitivity: 'base' })
      );
  }

  function groupBookingCustomerTypesByPk(booking, resolveCustomerType, columns) {
    const labelToAggregateKey = new Map(
      (columns || []).map((col) => [col.label, col.aggregateKey])
    );
    const grouped = {};
    if (!booking.customerTypes || !Array.isArray(booking.customerTypes)) {
      return grouped;
    }
    for (const ct of booking.customerTypes) {
      const resolved = resolveCustomerType(ct.name);
      if (!resolved) continue;
      const aggregateKey =
        labelToAggregateKey.get(resolved.label) || resolved.aggregateKey;
      grouped[aggregateKey] =
        (grouped[aggregateKey] || 0) + toSafeNumber(ct.quantity);
    }
    return grouped;
  }

  function buildTotalRowValues(
    columns,
    customerTypesUsed,
    filteredBookings,
    resolveCustomerType,
    bookingEntries
  ) {
    const totalsFromRows = {};
    const entries =
      Array.isArray(bookingEntries) && bookingEntries.length
        ? bookingEntries
        : (filteredBookings || []).map((booking) => ({
            booking,
            resolveCustomerType
          }));

    for (const entry of entries) {
      const resolver = entry.resolveCustomerType || resolveCustomerType;
      const grouped = groupBookingCustomerTypesByPk(
        entry.booking,
        resolver,
        columns
      );
      for (const [aggregateKey, quantity] of Object.entries(grouped)) {
        totalsFromRows[aggregateKey] =
          (totalsFromRows[aggregateKey] || 0) + toSafeNumber(quantity);
      }
    }
    const fromRows = columns.map((col) => totalsFromRows[col.aggregateKey] || 0);

    if (customerTypesUsed && typeof customerTypesUsed === 'object') {
      const hasSummary = Object.keys(customerTypesUsed).length > 0;
      if (hasSummary) {
        const storedTotals = columns.map((col) => customerTypesUsed[col.label] ?? 0);
        const mismatch = columns.some(
          (col, i) => toSafeNumber(storedTotals[i]) !== fromRows[i]
        );
        if (mismatch) {
          console.warn('[capacity-check] Stored totals did not match row totals', {
            storedTotals,
            recalculatedTotals: fromRows
          });
        }
      }
    }

    return fromRows;
  }

  function getBookedAtDateForTsv(booking) {
    if (booking.isCancelled) {
      if (booking.bookedAt) {
        return booking.bookedAt instanceof Date
          ? booking.bookedAt
          : new Date(booking.bookedAt);
      }
      return new Date('9999-12-31');
    }
    return booking.datetime
      ? booking.datetime instanceof Date
        ? booking.datetime
        : new Date(booking.datetime)
      : new Date('9999-12-31');
  }

  function escapeTsvCell(str) {
    if (!str) return '';
    return str
      .toString()
      .replace(/\t/g, ' ')
      .replace(/\n/g, ' ')
      .replace(/\r/g, '');
  }

  const TSV_SECTION_HEADER_CUSTOMER_TYPES = 'Customer Types';
  const TSV_SECTION_HEADER_RESOURCES = 'Resources';

  function countCapacityCheckTsvColumns(customerTypeColumns, resourceColumns) {
    return (
      4 +
      1 +
      (customerTypeColumns || []).length +
      1 +
      (resourceColumns || []).length
    );
  }

  function buildCapacityCheckTsvHeader(customerTypeColumns, resourceColumns) {
    return [
      'Booking Number',
      'Booked at',
      'Status',
      'Cancelled at',
      TSV_SECTION_HEADER_CUSTOMER_TYPES,
      ...(customerTypeColumns || []).map((col) => col.label),
      TSV_SECTION_HEADER_RESOURCES,
      ...(resourceColumns || []).map((col) => col.label)
    ].join('\t');
  }

  function buildCapacityCheckTsvTotalRow(
    customerTypeTotals,
    resourceTotals
  ) {
    return [
      'TOTAL',
      '',
      '',
      '',
      '',
      ...customerTypeTotals,
      '',
      ...resourceTotals
    ].join('\t');
  }

  function buildCapacityCheckTimestampRow(timestampStr, colCount) {
    return [
      'Timestamp:',
      escapeTsvCell(timestampStr),
      ...Array(Math.max(0, colCount - 2)).fill('')
    ].join('\t');
  }

  function buildBookingStatusForTsv(booking, isFiltered) {
    let status = 'Active';
    if (booking.isCancelled) {
      if (booking.reason === 'cancelled_created_after_target') {
        status = 'Cancelled (created after timestamp)';
      } else if (isFiltered) {
        status = 'Cancelled (was active at timestamp)';
      } else {
        status = 'Cancelled before timestamp';
      }
    } else if (!isFiltered) {
      status = 'Active (created after timestamp)';
    }
    return status;
  }

  function buildBookingDateCellsForTsv(booking, formatDateTime) {
    const dateTime = booking.datetime
      ? formatDateTime(
          booking.datetime instanceof Date
            ? booking.datetime
            : new Date(booking.datetime)
        )
      : '';

    let bookedAt = '';
    let cancelledAt = '';
    if (booking.isCancelled) {
      cancelledAt = dateTime;
      if (booking.bookedAt) {
        bookedAt = formatDateTime(
          booking.bookedAt instanceof Date
            ? booking.bookedAt
            : new Date(booking.bookedAt)
        );
      }
    } else {
      bookedAt = dateTime;
    }

    return { bookedAt, cancelledAt };
  }

  function buildBookingTsvRow(
    booking,
    customerTypeColumns,
    resourceColumns,
    resolveCustomerType,
    formatDateTime,
    isFiltered
  ) {
    const { bookedAt, cancelledAt } = buildBookingDateCellsForTsv(booking, formatDateTime);
    const groupedCustomerTypes = groupBookingCustomerTypesByPk(
      booking,
      resolveCustomerType,
      customerTypeColumns
    );
    const groupedResources = groupBookingResourcesByKey(booking, resourceColumns);
    return [
      escapeTsvCell(booking.bookingNumber || ''),
      escapeTsvCell(bookedAt),
      escapeTsvCell(buildBookingStatusForTsv(booking, isFiltered)),
      escapeTsvCell(cancelledAt),
      '',
      ...customerTypeColumns.map((col) => groupedCustomerTypes[col.aggregateKey] || ''),
      '',
      ...resourceColumns.map((col) => groupedResources[col.aggregateKey] || '')
    ].join('\t');
  }

  function sortBookingsByBookedAt(bookings) {
    return [...(bookings || [])].sort((a, b) => {
      const dateA = getBookedAtDateForTsv(a);
      const dateB = getBookedAtDateForTsv(b);
      if (isNaN(dateA.getTime()) && isNaN(dateB.getTime())) return 0;
      if (isNaN(dateA.getTime())) return 1;
      if (isNaN(dateB.getTime())) return -1;
      return dateA.getTime() - dateB.getTime();
    });
  }

  /**
   * Same TSV as single “Copy All Bookings to Clipboard (TSV)”.
   * @param {object} auditData - filteredBookings, skippedBookings, targetDateTime, originalBookingsCount
   * @param {{ formatDateTime: function }} deps
   * @param {{ availabilityName?: string }} [options]
   * @returns {string|null}
   */
  function buildCapacityCheckTsvFromAudit(auditData, deps, options) {
    const { formatDateTime } = deps;
    if (
      !auditData ||
      !auditData.filteredBookings ||
      !auditData.filteredBookings.length
    ) {
      return null;
    }

    const resolveCustomerType = buildCustomerTypeResolver(
      auditData.customerTypeLookupEntries
    );
    const sortedBookings = sortBookingsByBookedAt(auditData.filteredBookings);
    const sortedSkippedBookings = sortBookingsByBookedAt(
      auditData.skippedBookings || []
    );
    const sortedAllBookings = sortBookingsByBookedAt([
      ...sortedBookings,
      ...sortedSkippedBookings
    ]);

    const filteredBookingsSet = new Set(
      auditData.filteredBookings.map((b) => b.bookingHref || b.bookingNumber)
    );

    const customerTypeColumns = buildCustomerTypeColumns(
      sortedAllBookings,
      resolveCustomerType,
      auditData.customerTypesUsedDetailed,
      auditData.customerTypesUsed
    );
    const resourceColumns = buildResourceColumns(
      sortedAllBookings,
      auditData.resourcesUsed
    );
    const colCount = countCapacityCheckTsvColumns(
      customerTypeColumns,
      resourceColumns
    );

    const prefixLines = [];
    if (options && options.availabilityName) {
      const availRow = [
        'Availability name',
        escapeTsvCell(options.availabilityName)
      ];
      while (availRow.length < colCount) availRow.push('');
      prefixLines.push(availRow.join('\t'));
    }

    const header = buildCapacityCheckTsvHeader(customerTypeColumns, resourceColumns);

    const filteredRows = [];
    const skippedRows = [];

    sortedAllBookings.forEach((booking) => {
      const isFiltered = filteredBookingsSet.has(
        booking.bookingHref || booking.bookingNumber
      );
      const row = buildBookingTsvRow(
        booking,
        customerTypeColumns,
        resourceColumns,
        resolveCustomerType,
        formatDateTime,
        isFiltered
      );
      if (isFiltered) filteredRows.push(row);
      else skippedRows.push(row);
    });

    const totalRow = buildCapacityCheckTsvTotalRow(
      buildTotalRowValues(
        customerTypeColumns,
        auditData.customerTypesUsed,
        auditData.filteredBookings,
        resolveCustomerType
      ),
      buildResourceTotalRowValues(
        resourceColumns,
        auditData.resourcesUsed,
        auditData.filteredBookings
      )
    );

    const emptyRow = Array(colCount).fill('').join('\t');

    const targetDateTime =
      auditData.targetDateTime instanceof Date
        ? auditData.targetDateTime
        : new Date(auditData.targetDateTime);
    const timestampStr = formatDateTime(targetDateTime);

    const timestampRow = buildCapacityCheckTimestampRow(timestampStr, colCount);

    const totalScanned =
      auditData.originalBookingsCount != null
        ? auditData.originalBookingsCount
        : sortedAllBookings.length;

    const summaryStats = [`Total bookings scanned: ${totalScanned}`];

    return [
      ...prefixLines,
      header,
      ...filteredRows,
      emptyRow,
      totalRow,
      emptyRow,
      timestampRow,
      emptyRow,
      ...skippedRows,
      ...summaryStats
    ].join('\n');
  }

  function countBatchTsvBookings(batch) {
    let n = 0;
    for (const snap of batch.snapshots || []) {
      const src = snap.tsvSource;
      if (!src) continue;
      n += (src.filteredBookings || []).length + (src.skippedBookings || []).length;
    }
    return n;
  }

  /**
   * One accumulated TSV matching single “Copy All Bookings” layout:
   * header → filtered rows (all snapshots, sorted by booked-at) → TOTAL → blank → Timestamp → blank → skipped → summary.
   */
  function exportBatchToCapacityCheckTsv(batch, deps) {
    const { formatDateTime } = deps;

    const snaps = [...(batch.snapshots || [])].filter((s) => s.tsvSource);
    if (!snaps.length) return null;

    const enriched = [];
    let totalScannedSum = 0;
    const targetIsoSet = new Set();
    const mergedCustomerTypesUsed = {};
    const mergedCustomerTypesUsedDetailed = {};
    const mergedResourcesUsed = {};
    const customerTypeLabelToAggregateKey = new Map();

    function mergeSnapshotSummaries(src) {
      const customerTypesUsed = src.customerTypesUsed;
      const customerTypesUsedDetailed = src.customerTypesUsedDetailed;
      const resourcesUsed = src.resourcesUsed;

      if (customerTypesUsed && typeof customerTypesUsed === 'object') {
        for (const [label, qty] of Object.entries(customerTypesUsed)) {
          if (typeof qty === 'number' && Number.isFinite(qty)) {
            mergedCustomerTypesUsed[label] =
              (mergedCustomerTypesUsed[label] || 0) + qty;
          }
        }
        for (const label of Object.keys(customerTypesUsed)) {
          if (!label || customerTypeLabelToAggregateKey.has(label)) continue;
          customerTypeLabelToAggregateKey.set(
            label,
            `summary:${normalizeCustomerTypeLookupKey(label)}`
          );
        }
      }
      if (customerTypesUsedDetailed && typeof customerTypesUsedDetailed === 'object') {
        for (const [aggregateKey, detail] of Object.entries(customerTypesUsedDetailed)) {
          if (!detail || !detail.label) continue;
          const key = String(aggregateKey);
          if (!mergedCustomerTypesUsedDetailed[key]) {
            mergedCustomerTypesUsedDetailed[key] = {
              label: detail.label,
              quantity: 0,
              customerTypePk: detail.customerTypePk ?? null,
              customerPrototypePk: detail.customerPrototypePk ?? null
            };
          }
          mergedCustomerTypesUsedDetailed[key].quantity += toSafeNumber(detail.quantity);
          if (!customerTypeLabelToAggregateKey.has(detail.label)) {
            customerTypeLabelToAggregateKey.set(detail.label, key);
          }
        }
      }
      if (resourcesUsed && typeof resourcesUsed === 'object') {
        for (const [resourceName, qty] of Object.entries(resourcesUsed)) {
          if (resourceName === '_total') continue;
          if (typeof qty === 'number' && Number.isFinite(qty)) {
            mergedResourcesUsed[resourceName] =
              (mergedResourcesUsed[resourceName] || 0) + qty;
          }
        }
      }
    }

    for (const snap of snaps) {
      const src = snap.tsvSource;
      mergeSnapshotSummaries(src);
      const resolveCustomerType = buildCustomerTypeResolver(
        src.customerTypeLookupEntries
      );
      const filteredSet = new Set(
        (src.filteredBookings || []).map((b) => b.bookingHref || b.bookingNumber)
      );
      const allInSnap = [
        ...(src.filteredBookings || []),
        ...(src.skippedBookings || [])
      ];
      const seen = new Set();
      const targetForFormat =
        src.targetDateTime instanceof Date
          ? src.targetDateTime
          : new Date(src.targetDateTime);
      const targetIso = isNaN(targetForFormat.getTime())
        ? ''
        : targetForFormat.toISOString();
      if (targetIso) targetIsoSet.add(targetIso);

      for (const booking of allInSnap) {
        const key =
          booking.bookingHref || booking.bookingNumber || String(booking.index);
        if (seen.has(key)) continue;
        seen.add(key);

        const isFiltered = filteredSet.has(
          booking.bookingHref || booking.bookingNumber
        );
        enriched.push({
          booking,
          availabilityName: snap.availabilityName || '',
          targetDateTime: targetForFormat,
          isFiltered,
          resolveCustomerType
        });
        for (const ct of booking.customerTypes || []) {
          const resolved = resolveCustomerType(ct.name);
          if (!resolved) continue;
          if (!customerTypeLabelToAggregateKey.has(resolved.label)) {
            customerTypeLabelToAggregateKey.set(resolved.label, resolved.aggregateKey);
          }
        }
      }

      if (src.originalBookingsCount != null) {
        totalScannedSum += src.originalBookingsCount;
      } else {
        totalScannedSum +=
          (src.filteredBookings || []).length +
          (src.skippedBookings || []).length;
      }
    }

    if (!enriched.length) return null;

    const allBookings = enriched.map((entry) => entry.booking);

    const customerTypeColumns = [...customerTypeLabelToAggregateKey.entries()]
      .map(([label, aggregateKey]) => ({ aggregateKey, label }))
      .sort((a, b) =>
        a.label.localeCompare(b.label, undefined, { sensitivity: 'base' })
      );
    const resourceColumns = buildResourceColumns(allBookings, mergedResourcesUsed);

    const sortByBookedAt = (a, b) => {
      const dateA = getBookedAtDateForTsv(a.booking);
      const dateB = getBookedAtDateForTsv(b.booking);
      if (isNaN(dateA.getTime()) && isNaN(dateB.getTime())) return 0;
      if (isNaN(dateA.getTime())) return 1;
      if (isNaN(dateB.getTime())) return -1;
      return dateA.getTime() - dateB.getTime();
    };

    const filteredList = enriched.filter((e) => e.isFiltered).sort(sortByBookedAt);
    const skippedList = enriched.filter((e) => !e.isFiltered).sort(sortByBookedAt);
    const colCount = countCapacityCheckTsvColumns(
      customerTypeColumns,
      resourceColumns
    );

    const filteredRows = filteredList.map((entry) =>
      buildBookingTsvRow(
        entry.booking,
        customerTypeColumns,
        resourceColumns,
        entry.resolveCustomerType,
        formatDateTime,
        entry.isFiltered
      )
    );
    const skippedRows = skippedList.map((entry) =>
      buildBookingTsvRow(
        entry.booking,
        customerTypeColumns,
        resourceColumns,
        entry.resolveCustomerType,
        formatDateTime,
        entry.isFiltered
      )
    );

    const header = buildCapacityCheckTsvHeader(customerTypeColumns, resourceColumns);

    const filteredBookingsForTotals = filteredList.map((entry) => entry.booking);

    const totalRow = buildCapacityCheckTsvTotalRow(
      buildTotalRowValues(
        customerTypeColumns,
        Object.keys(mergedCustomerTypesUsed).length ? mergedCustomerTypesUsed : null,
        filteredBookingsForTotals,
        null,
        filteredList
      ),
      buildResourceTotalRowValues(
        resourceColumns,
        Object.keys(mergedResourcesUsed).length ? mergedResourcesUsed : null,
        filteredBookingsForTotals
      )
    );

    const emptyRow = Array(colCount).fill('').join('\t');

    let timestampDisplay = '';
    if (targetIsoSet.size === 1) {
      const d = new Date([...targetIsoSet][0]);
      timestampDisplay = formatDateTime(d);
    } else if (targetIsoSet.size > 1) {
      const sortedTs = [...targetIsoSet].sort();
      timestampDisplay = sortedTs
        .map((iso) => formatDateTime(new Date(iso)))
        .join('; ');
    }

    const timestampRow = buildCapacityCheckTimestampRow(timestampDisplay, colCount);

    const summaryStats = [`Total bookings scanned: ${totalScannedSum}`];

    return [
      header,
      ...filteredRows,
      emptyRow,
      totalRow,
      emptyRow,
      timestampRow,
      emptyRow,
      ...skippedRows,
      ...summaryStats
    ].join('\n');
  }

  /**
   * Maps audit API response + pageContext to a persisted snapshot (normalized rows only).
   */
  function auditResponseToSnapshot(auditData, pageContext) {
    const availabilityId =
      (pageContext && pageContext.availabilityId) || 'unknown';
    const availabilityName =
      (pageContext && pageContext.availabilityName) || 'Unknown';

    const snapshotTimestamp =
      toISOStringSafe(auditData.targetDateTime) || new Date().toISOString();

    const filtered = auditData.filteredBookings || [];
    const skipped = auditData.skippedBookings || [];
    const filteredSet = new Set(
      filtered.map((b) => b.bookingHref || b.bookingNumber)
    );

    const tsvTargetIso =
      toISOStringSafe(auditData.targetDateTime) || snapshotTimestamp;
    const tsvSource = {
      filteredBookings: filtered.map(serializeBookingForTsvSource).filter(Boolean),
      skippedBookings: skipped.map(serializeBookingForTsvSource).filter(Boolean),
      targetDateTime: tsvTargetIso,
      originalBookingsCount:
        auditData.originalBookingsCount != null
          ? auditData.originalBookingsCount
          : filtered.length + skipped.length,
      customerTypesUsed: auditData.customerTypesUsed || {},
      customerTypesUsedDetailed: auditData.customerTypesUsedDetailed || null,
      customerTypeLookupEntries: auditData.customerTypeLookupEntries || [],
      resourcesUsed: auditData.resourcesUsed || {}
    };

    const rows = [];
    const seen = new Set();

    for (const booking of [...filtered, ...skipped]) {
      const dedupeKey = booking.bookingHref || booking.bookingNumber || JSON.stringify(booking.index);
      if (seen.has(dedupeKey)) continue;
      seen.add(dedupeKey);

      const isFiltered = filteredSet.has(booking.bookingHref || booking.bookingNumber);
      const status = normalizeBookingStatus(booking, isFiltered);

      const datetime =
        booking.datetime != null
          ? booking.datetime instanceof Date
            ? booking.datetime
            : new Date(booking.datetime)
          : null;

      let bookedAtIso = null;
      let cancelledAtIso = null;
      if (booking.isCancelled) {
        cancelledAtIso = toISOStringSafe(datetime);
        bookedAtIso = toISOStringSafe(booking.bookedAt);
      } else {
        bookedAtIso = toISOStringSafe(datetime);
      }

      rows.push({
        bookingNumber: booking.bookingNumber != null ? String(booking.bookingNumber) : '',
        bookedAt: bookedAtIso,
        status,
        cancelledAt: cancelledAtIso,
        adults:
          booking.partySize != null && !isNaN(Number(booking.partySize))
            ? Number(booking.partySize)
            : 0
      });
    }

    return {
      availabilityId,
      availabilityName,
      snapshotTimestamp,
      rows,
      tsvSource
    };
  }

  function flattenBatchToRows(batch) {
    const flat = [];
    for (const snap of batch.snapshots || []) {
      for (const row of snap.rows || []) {
        flat.push({
          availabilityName: snap.availabilityName || '',
          availabilityId: snap.availabilityId || '',
          snapshotTimestamp: snap.snapshotTimestamp || '',
          bookingNumber: row.bookingNumber,
          bookedAt: row.bookedAt,
          status: row.status,
          cancelledAt: row.cancelledAt,
          adults: row.adults
        });
      }
    }
    return flat;
  }

  function sortBatchRows(rows) {
    return [...rows].sort((a, b) => {
      const nameCmp = (a.availabilityName || '').localeCompare(
        b.availabilityName || '',
        undefined,
        { sensitivity: 'base' }
      );
      if (nameCmp !== 0) return nameCmp;

      const tsCmp = (a.snapshotTimestamp || '').localeCompare(
        b.snapshotTimestamp || ''
      );
      if (tsCmp !== 0) return tsCmp;

      const pa = STATUS_PRIORITY[a.status] ?? 99;
      const pb = STATUS_PRIORITY[b.status] ?? 99;
      if (pa !== pb) return pa - pb;

      const ba = a.bookedAt || '';
      const bb = b.bookedAt || '';
      if (!ba && bb) return 1;
      if (ba && !bb) return -1;
      const bookedCmp = ba.localeCompare(bb);
      if (bookedCmp !== 0) return bookedCmp;

      return (a.bookingNumber || '').localeCompare(b.bookingNumber || '', undefined, {
        numeric: true
      });
    });
  }

  function escapeCsvField(val) {
    if (val == null || val === '') return '';
    const s = String(val);
    if (/[",\n\r]/.test(s)) {
      return '"' + s.replace(/"/g, '""') + '"';
    }
    return s;
  }

  const EXPORT_HEADERS = [
    'availabilityName',
    'availabilityId',
    'snapshotTimestamp',
    'bookingNumber',
    'bookedAt',
    'status',
    'cancelledAt',
    'adults'
  ];

  function exportBatchToCsv(batch) {
    const flat = sortBatchRows(flattenBatchToRows(batch));
    const lines = [EXPORT_HEADERS.join(',')];
    for (const r of flat) {
      lines.push(
        EXPORT_HEADERS.map((h) => escapeCsvField(r[h])).join(',')
      );
    }
    return lines.join('\n');
  }

  function exportBatchToTableText(batch) {
    const flat = sortBatchRows(flattenBatchToRows(batch));
    const escapeCell = (v) =>
      String(v ?? '')
        .replace(/\t/g, ' ')
        .replace(/\n/g, ' ')
        .replace(/\r/g, '');
    const lines = [EXPORT_HEADERS.join('\t')];
    for (const r of flat) {
      lines.push(EXPORT_HEADERS.map((h) => escapeCell(r[h])).join('\t'));
    }
    return lines.join('\n');
  }

  function createNewBatch() {
    return new Promise((resolve, reject) => {
      const batch = {
        id: newBatchId(),
        createdAt: new Date().toISOString(),
        label: 'Batch',
        snapshots: []
      };
      chrome.storage.local.remove(STORAGE_KEY, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        chrome.storage.local.set({ [STORAGE_KEY]: batch }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
            return;
          }
          resolve(batch);
        });
      });
    });
  }

  function getActiveBatch() {
    return new Promise((resolve) => {
      chrome.storage.local.get([STORAGE_KEY], (r) => {
        if (chrome.runtime.lastError) {
          resolve(null);
          return;
        }
        const batch = r[STORAGE_KEY];
        if (
          !batch ||
          typeof batch !== 'object' ||
          !Array.isArray(batch.snapshots)
        ) {
          resolve(null);
          return;
        }
        resolve(batch);
      });
    });
  }

  function saveSnapshotToBatch(snapshot) {
    return new Promise((resolve, reject) => {
      getActiveBatch()
        .then((batch) => {
          if (!batch) {
            reject(new Error('No active batch'));
            return;
          }
          const idx = batch.snapshots.findIndex(
            (s) =>
              s.availabilityId === snapshot.availabilityId &&
              s.snapshotTimestamp === snapshot.snapshotTimestamp
          );
          if (idx >= 0) {
            batch.snapshots[idx] = snapshot;
          } else {
            batch.snapshots.push(snapshot);
          }
          chrome.storage.local.set({ [STORAGE_KEY]: batch }, () => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
              return;
            }
            resolve(batch);
          });
        })
        .catch(reject);
    });
  }

  function formatBatchStatusLine(batch) {
    if (!batch) {
      return 'No active batch. Click “New batch” to start.';
    }
    const started = new Date(batch.createdAt).toLocaleString();
    const n = batch.snapshots.length;
    return `Active batch: started ${started}, ${n} snapshot${n === 1 ? '' : 's'}`;
  }

  /** Same as content script: overlay holds real availability when pathname is resource/date only. */
  function parseItemAvailabilityFromOverlayUrl(url) {
    try {
      const u = new URL(url);
      const overlay = u.searchParams.get('overlay');
      if (!overlay) return null;
      const decoded = decodeURIComponent(overlay);
      const m = decoded.match(/\/items\/(\d+)\/availabilities\/(\d+)/i);
      if (!m) return null;
      return { itemId: m[1], availabilityNumericId: m[2] };
    } catch (e) {
      return null;
    }
  }

  /** Fallback when pageContext is missing (e.g. older content script). */
  function inferPageContextFromUrl(url) {
    try {
      const u = new URL(url);
      const pathname = u.pathname || '';
      let availabilityId = '';
      const overlayIds = parseItemAvailabilityFromOverlayUrl(url);
      if (overlayIds) {
        availabilityId = `${overlayIds.itemId}-${overlayIds.availabilityNumericId}`;
      } else {
        const itemMatch = pathname.match(/\/items\/(\d+)/);
        const itemId = itemMatch ? itemMatch[1] : null;
        const calMatch = pathname.match(
          /\/calendar\/(\d{4})\/(\d{1,2})(?:\/(\d{1,2}))?/
        );
        if (itemId && calMatch) {
          const y = calMatch[1];
          const m = String(calMatch[2]).padStart(2, '0');
          const d = calMatch[3] ? String(calMatch[3]).padStart(2, '0') : '';
          availabilityId = d ? `${itemId}-${y}-${m}-${d}` : `${itemId}-${y}-${m}`;
        } else if (itemId) {
          availabilityId = itemId;
        } else {
          const trimmed = pathname.replace(/^\/+|\/+$/g, '').replace(/\//g, '_');
          availabilityId = trimmed || 'unknown';
        }
      }
      let availabilityName = 'Unknown';
      const itemMatch = pathname.match(/\/items\/(\d+)/);
      const itemId = itemMatch ? itemMatch[1] : null;
      const calMatch = pathname.match(
        /\/calendar\/(\d{4})\/(\d{1,2})(?:\/(\d{1,2}))?/
      );
      if (overlayIds) {
        availabilityName = `Item ${overlayIds.itemId} · availability ${overlayIds.availabilityNumericId}`;
      } else if (itemId) {
        if (calMatch) {
          const y = calMatch[1];
          const mo = String(calMatch[2]).padStart(2, '0');
          const day = calMatch[3]
            ? `-${String(calMatch[3]).padStart(2, '0')}`
            : '';
          availabilityName = `Item ${itemId} (${y}-${mo}${day})`;
        } else {
          availabilityName = `Item ${itemId}`;
        }
      } else {
        availabilityName = pathname || u.hostname || 'Unknown';
      }
      return { availabilityId, availabilityName };
    } catch (e) {
      return { availabilityId: 'unknown', availabilityName: 'Unknown' };
    }
  }

  global.CapacityBatch = {
    STORAGE_KEY,
    STATUS_PRIORITY,
    createNewBatch,
    getActiveBatch,
    saveSnapshotToBatch,
    auditResponseToSnapshot,
    sortBatchRows,
    exportBatchToCsv,
    exportBatchToTableText,
    formatBatchStatusLine,
    flattenBatchToRows,
    inferPageContextFromUrl,
    buildCapacityCheckTsvFromAudit,
    exportBatchToCapacityCheckTsv,
    countBatchTsvBookings,
    serializeBookingForTsvSource,
    extractResourceUsesForTsv
  };
})(typeof window !== 'undefined' ? window : self);
