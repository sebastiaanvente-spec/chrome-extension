// Background service worker for MV3
console.log('[background] Service worker started');

importScripts('gyg-client.js');
importScripts('update-check.js');
importScripts('developer-auth.js');
importScripts('fareharbor-view-resolver.js');
importScripts('background/reseller-app-company-map.js');

// GYG token capture (webRequest) + storage keys
const GYG_GRAPHQL_URL_PATTERN = '*://supplier.getyourguide.com/graphql';
const GYG_TOKEN_KEY = 'gygAuthToken';
const GYG_SUPPLIER_KEY = 'gygSupplierId';
const GYG_TOKEN_TS_KEY = 'gygTokenCapturedAt';

function gygSaveToken(token, supplierId) {
  const payload = {};
  if (token !== undefined) payload[GYG_TOKEN_KEY] = token;
  if (supplierId !== undefined) payload[GYG_SUPPLIER_KEY] = supplierId;
  payload[GYG_TOKEN_TS_KEY] = Date.now();
  chrome.storage.local.set(payload, () => {
    console.log('[background] GYG saved token/supplierId:', !!token, supplierId);
  });
}

chrome.webRequest.onBeforeSendHeaders.addListener(
  function (details) {
    try {
      const headers = details.requestHeaders || [];
      const auth = headers.find(h => h.name.toLowerCase() === 'authorization');
      const supplierHeader = headers.find(h => h.name.toLowerCase() === 'x-gyg-supplier-id');
      if (auth || supplierHeader) {
        gygSaveToken(auth ? auth.value : undefined, supplierHeader ? supplierHeader.value : undefined);
      }
    } catch (err) {
      console.error('[background] GYG onBeforeSendHeaders error', err);
    }
    return {};
  },
  { urls: [GYG_GRAPHQL_URL_PATTERN] },
  ['requestHeaders', 'extraHeaders']
);

const GYG_PRODUCTS_LOG = '[background][getyourguide-products]';
const GYG_GRAPHQL_TIMEOUT_MS = 50000;

function gygNormalizeBearerToken(token) {
  if (!token || typeof token !== 'string') return '';
  const trimmed = token.trim();
  if (!trimmed) return '';
  return trimmed.indexOf('Bearer ') === 0 ? trimmed.slice(7) : trimmed;
}

function gygGetStoredAuth() {
  return new Promise((resolve) => {
    chrome.storage.local.get([GYG_TOKEN_KEY, GYG_SUPPLIER_KEY], resolve);
  });
}

function gygExecuteScriptWithTimeout(tabId, options, timeoutMs) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      reject(new Error('GraphQL request timed out'));
    }, timeoutMs);

    chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      ...options
    }, (results) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (chrome.runtime.lastError) {
        reject(new Error('MAIN-world execution failure: ' + chrome.runtime.lastError.message));
        return;
      }
      resolve(results);
    });
  });
}

function gygInstallTokenCaptureInMainWorld() {
  if (window.__gygTokenCaptureInstalled) return true;
  const pageUrl = window.location.href;
  if (pageUrl.indexOf('supplier.getyourguide.com') === -1) return false;

  function capture(token) {
    if (!token || !token.length) return;
    window.__gygBearerToken = token;
    try {
      window.postMessage({ type: 'GYG_TOKEN', token }, window.location.origin);
    } catch (_) {}
  }

  function getAuth(opts) {
    if (!opts || !opts.headers) return null;
    const h = opts.headers;
    if (h.get && typeof h.get === 'function') return h.get('authorization') || h.get('Authorization');
    return h.authorization || h.Authorization || null;
  }

  const origFetch = window.fetch;
  window.fetch = function (url, options) {
    const urlStr = typeof url === 'string' ? url : (url && url.url) ? url.url : '';
    if (urlStr.indexOf('/graphql') !== -1) {
      const auth = getAuth(options || {});
      if (auth && auth.indexOf('Bearer ') === 0) capture(auth.slice(7));
    }
    return origFetch.apply(this, arguments);
  };

  const OrigXHR = window.XMLHttpRequest;
  function XHRPatch() {
    const xhr = new OrigXHR();
    const origOpen = xhr.open;
    xhr.open = function (method, url) {
      xhr._gygUrl = url;
      return origOpen.apply(this, arguments);
    };
    const origSetHeader = xhr.setRequestHeader;
    xhr.setRequestHeader = function (name, value) {
      if ((name === 'Authorization' || name === 'authorization') && value && value.indexOf('Bearer ') === 0) {
        xhr._gygAuth = value.slice(7);
      }
      return origSetHeader.apply(this, arguments);
    };
    const origSend = xhr.send;
    xhr.send = function () {
      if (xhr._gygUrl && xhr._gygUrl.indexOf('/graphql') !== -1 && xhr._gygAuth) capture(xhr._gygAuth);
      return origSend.apply(this, arguments);
    };
    return xhr;
  }
  window.XMLHttpRequest = XHRPatch;
  window.__gygTokenCaptureInstalled = true;
  return true;
}

function gygTriggerGraphQLForTokenInMainWorld() {
  const url = window.location.origin + '/graphql';
  const body = JSON.stringify({ operationName: null, query: '{ __typename }', variables: {} });
  try {
    window.fetch(url, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body
    });
  } catch (_) {}
  return true;
}

function gygReadBearerTokenInMainWorld() {
  return window.__gygBearerToken || '';
}

async function gygExecuteGraphQLInMainWorld(args) {
  const GYG_MAIN_LOG = '[background][getyourguide-products]';
  const endpoint = args && args.endpoint ? String(args.endpoint) : '';
  const body = args && args.body ? String(args.body) : '';
  const supplierIdArg = args && args.supplierId ? String(args.supplierId) : '';
  const storedToken = args && args.storedToken ? String(args.storedToken) : '';
  const pageTokenArg = args && args.pageToken ? String(args.pageToken) : '';

  let authValue = pageTokenArg || window.__gygBearerToken || storedToken || '';
  if (authValue && authValue.indexOf('Bearer ') !== 0) {
    authValue = 'Bearer ' + authValue;
  }

  let supplierId = supplierIdArg;
  if (!supplierId) {
    const match = document.cookie.match(/supplier_id=([^;]+)/);
    if (match) supplierId = match[1].trim();
  }

  if (!authValue) {
    return {
      ok: false,
      status: 401,
      statusText: 'Unauthorized',
      rawText: '',
      error: 'No auth token available'
    };
  }
  if (!endpoint || !body) {
    return {
      ok: false,
      status: 0,
      statusText: '',
      rawText: '',
      error: 'Empty or malformed GraphQL response'
    };
  }

  let payload;
  try {
    payload = JSON.parse(body);
  } catch (err) {
    return {
      ok: false,
      status: 0,
      statusText: '',
      rawText: '',
      error: 'GetYourGuide GraphQL request body is not valid JSON: ' + String(err && err.message ? err.message : err)
    };
  }

  if (typeof payload.query !== 'string') {
    return {
      ok: false,
      status: 0,
      statusText: '',
      rawText: '',
      error: 'GetYourGuide GraphQL query is missing or is not a string'
    };
  }
  if (payload.query.trim() === '') {
    return {
      ok: false,
      status: 0,
      statusText: '',
      rawText: '',
      error: 'GetYourGuide GraphQL query is missing or is not a string'
    };
  }
  if (payload.query.includes('[object Object]')) {
    return {
      ok: false,
      status: 0,
      statusText: '',
      rawText: '',
      error: 'GetYourGuide GraphQL query appears corrupted: contains [object Object]'
    };
  }
  if (payload.query.includes('undefined')) {
    return {
      ok: false,
      status: 0,
      statusText: '',
      rawText: '',
      error: 'GetYourGuide GraphQL query appears corrupted: contains undefined'
    };
  }

  console.log(GYG_MAIN_LOG, 'GraphQL payload diagnostics', {
    operationName: payload && payload.operationName != null ? payload.operationName : null,
    queryType: typeof payload.query,
    queryLength: typeof payload.query === 'string' ? payload.query.length : null,
    queryStart: typeof payload.query === 'string' ? payload.query.slice(0, 500) : payload.query,
    queryEnd: typeof payload.query === 'string' ? payload.query.slice(-500) : null,
    variables: payload && payload.variables ? payload.variables : null,
    bodyPreview: JSON.stringify(payload).slice(0, 3000)
  });

  console.log(GYG_MAIN_LOG, 'GraphQL query validation', {
    isString: typeof payload.query === 'string',
    isEmpty: typeof payload.query !== 'string' || payload.query.trim().length === 0,
    startsWithFragment: typeof payload.query === 'string' && payload.query.trimStart().startsWith('fragment'),
    hasOperationDefinition: typeof payload.query === 'string' && payload.query.includes('query CatalogActivityOption_ActivityOptionDetailsSearch'),
    containsUndefined: typeof payload.query === 'string' && payload.query.includes('undefined'),
    containsObjectObject: typeof payload.query === 'string' && payload.query.includes('[object Object]'),
    containsLiteralBackslashN: typeof payload.query === 'string' && payload.query.includes('\\n'),
    containsRealNewline: typeof payload.query === 'string' && payload.query.includes('\n')
  });

  const requestBody = {
    operationName: payload.operationName || 'CatalogActivityOption_ActivityOptionDetailsSearch',
    query: payload.query,
    variables: payload.variables || {}
  };

  const fetchBody = JSON.stringify(requestBody);

  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'multipart/mixed;subscriptionSpec=1.0, application/json',
    'Authorization': authValue,
    'apollographql-client-name': 'supplier-portal',
    'apollographql-client-version': 'v47840'
  };
  if (supplierId) headers['x-gyg-supplier-id'] = String(supplierId);

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      mode: 'cors',
      credentials: 'include',
      headers,
      body: fetchBody
    });
    const rawText = await res.text();

    return {
      ok: res.ok,
      status: res.status,
      statusText: res.statusText || '',
      rawText: rawText || '',
      error: ''
    };
  } catch (err) {
    return {
      ok: false,
      status: 0,
      statusText: '',
      rawText: '',
      error: 'MAIN-world execution failure: ' + String(err && err.message ? err.message : err)
    };
  }
}

async function gygHandleGraphQLRequest(message, sender) {
  const requestId = message.requestId || '';
  const tabId = sender.tab && sender.tab.id;
  if (!tabId) {
    return { ok: false, requestId, error: 'Missing sender tab ID' };
  }

  const endpoint = message.endpoint || '';
  const body = message.body || '';
  const supplierId = message.supplierId != null ? String(message.supplierId) : '';
  const pageToken = message.pageToken != null ? String(message.pageToken) : '';

  const auth = await gygGetStoredAuth();
  const storedToken = auth[GYG_TOKEN_KEY] || '';
  const storedSupplierId = auth[GYG_SUPPLIER_KEY] != null ? String(auth[GYG_SUPPLIER_KEY]) : '';

  let operationName = '';
  let variableKeys = [];
  let parsedPayload = null;
  try {
    parsedPayload = JSON.parse(body);
    operationName = parsedPayload && parsedPayload.operationName ? String(parsedPayload.operationName) : '';
    const variables = parsedPayload && parsedPayload.variables ? parsedPayload.variables : {};
    variableKeys = Object.keys(variables || {});
  } catch (_) {}

  console.log(GYG_PRODUCTS_LOG, 'GraphQL request summary', {
    requestId: requestId || '(no-id)',
    endpoint,
    operationName,
    variableKeys,
    queryType: parsedPayload ? typeof parsedPayload.query : 'unknown',
    queryLength: parsedPayload && typeof parsedPayload.query === 'string' ? parsedPayload.query.length : null,
    bodyLength: body.length,
    bodyMatchesParsed: parsedPayload ? body === JSON.stringify({
      query: parsedPayload.query,
      variables: parsedPayload.variables || {},
      ...(parsedPayload.operationName ? { operationName: parsedPayload.operationName } : {})
    }) : false,
    hasAuthorization: Boolean(pageToken || storedToken),
    credentials: 'include'
  });

  const results = await gygExecuteScriptWithTimeout(tabId, {
    func: gygExecuteGraphQLInMainWorld,
    args: [{
      endpoint,
      body,
      supplierId: supplierId || storedSupplierId,
      storedToken,
      pageToken
    }]
  }, GYG_GRAPHQL_TIMEOUT_MS);

  const result = results && results[0] && results[0].result;
  if (!result || typeof result !== 'object') {
    return { ok: false, requestId, error: 'Empty or malformed GraphQL response' };
  }

  const bridgeResponse = {
    ok: Boolean(result.ok),
    status: typeof result.status === 'number' ? result.status : 0,
    statusText: result.statusText || '',
    rawText: result.rawText || ''
  };

  if (result.error) {
    return {
      ok: false,
      requestId,
      status: bridgeResponse.status,
      statusText: bridgeResponse.statusText,
      rawText: bridgeResponse.rawText,
      error: result.error
    };
  }

  if (!bridgeResponse.ok) {
    console.error(GYG_PRODUCTS_LOG, 'GraphQL HTTP error', {
      requestId: requestId || '(no-id)',
      status: bridgeResponse.status,
      statusText: bridgeResponse.statusText,
      responseBody: bridgeResponse.rawText.slice(0, 2000)
    });
    return {
      ok: false,
      requestId,
      status: bridgeResponse.status,
      statusText: bridgeResponse.statusText,
      rawText: bridgeResponse.rawText,
      error: 'GetYourGuide GraphQL request failed with HTTP ' + bridgeResponse.status + ': ' +
        (bridgeResponse.rawText || bridgeResponse.statusText || 'Unknown error')
    };
  }

  if (!bridgeResponse.rawText) {
    return {
      ok: false,
      requestId,
      status: bridgeResponse.status,
      statusText: bridgeResponse.statusText,
      rawText: '',
      error: 'Empty or malformed GraphQL response'
    };
  }

  let payload;
  try {
    payload = JSON.parse(bridgeResponse.rawText);
  } catch (_) {
    return {
      ok: false,
      requestId,
      status: bridgeResponse.status,
      statusText: bridgeResponse.statusText,
      rawText: bridgeResponse.rawText,
      error: 'GetYourGuide returned invalid JSON: ' + bridgeResponse.rawText.slice(0, 500)
    };
  }

  if (Array.isArray(payload.errors) && payload.errors.length > 0) {
    const message = payload.errors.map((error) => error && error.message ? error.message : String(error)).join('; ');
    return {
      ok: false,
      requestId,
      status: bridgeResponse.status,
      statusText: bridgeResponse.statusText,
      rawText: bridgeResponse.rawText,
      error: 'GetYourGuide GraphQL error: ' + message
    };
  }

  if (!payload.data) {
    return {
      ok: false,
      requestId,
      status: bridgeResponse.status,
      statusText: bridgeResponse.statusText,
      rawText: bridgeResponse.rawText,
      error: 'Empty or malformed GraphQL response'
    };
  }

  return {
    ok: true,
    requestId,
    status: bridgeResponse.status,
    statusText: bridgeResponse.statusText,
    rawText: bridgeResponse.rawText
  };
}

// Tab management for background scraping
class BackgroundTabManager {
  constructor() {
    this.activeTabs = new Map(); // tabId -> { url, resolve, reject, timeout }
    this.maxConcurrentTabs = 4;
    this.requestQueue = [];
    this.tabTimeoutMs = 30000; // 30 seconds timeout per tab
  }

  async scrapeUrl(url, targetDateTime = null, extractResources = true) {
    console.log(`[background] scrapeUrl called for: ${url}`);
    console.log(`[background] Target date/time: ${targetDateTime ? new Date(targetDateTime).toISOString() : 'null'}`);
    console.log(`[background] Extract resources: ${extractResources}`);
    return new Promise((resolve, reject) => {
      const request = { url, targetDateTime, extractResources, resolve, reject, retryCount: 0 };
      this.requestQueue.push(request);
      console.log(`[background] Added request to queue. Queue length: ${this.requestQueue.length}, Active tabs: ${this.activeTabs.size}`);
      this.processQueue();
    });
  }

  async processQueue() {
    if (this.activeTabs.size >= this.maxConcurrentTabs || this.requestQueue.length === 0) {
      return;
    }

    const request = this.requestQueue.shift();
    await this.processRequest(request);
  }

  async processRequest(request) {
    const { url, targetDateTime, extractResources, resolve, reject, retryCount } = request;

    try {
      console.log(`[background] ===== processRequest CALLED =====`);
      console.log(`[background] URL: ${url}`);
      console.log(`[background] Target date/time: ${targetDateTime ? new Date(targetDateTime).toISOString() : 'null'}`);
      console.log(`[background] Extract resources from request: ${extractResources} (type: ${typeof extractResources})`);
      console.log(`[background] Retry count: ${retryCount}`);
      console.log(`[background] Creating background tab for: ${url}`);
      
      const tab = await chrome.tabs.create({
        url: url,
        active: false // Create in background
      });

      console.log(`[background] Tab created successfully! Tab ID: ${tab.id}, URL: ${tab.url}`);

      const tabData = {
        url,
        targetDateTime,
        extractResources: extractResources, // Store the extractResources flag
        resolve,
        reject,
        timeout: setTimeout(() => {
          console.warn(`[background] Tab ${tab.id} timed out after ${this.tabTimeoutMs}ms`);
          this.handleTabTimeout(tab.id);
        }, this.tabTimeoutMs)
      };
      
      console.log(`[background] Stored tabData for tab ${tab.id}:`, {
        url: tabData.url,
        hasTargetDateTime: !!tabData.targetDateTime,
        extractResources: tabData.extractResources,
        extractResourcesType: typeof tabData.extractResources
      });

      this.activeTabs.set(tab.id, tabData);
      console.log(`[background] Tab ${tab.id} added to activeTabs. Total active tabs: ${this.activeTabs.size}`);

      // Wait for tab to finish loading, then inject script
      console.log(`[background] Waiting for tab ${tab.id} to load...`);
      this.waitForTabLoad(tab.id);

    } catch (error) {
      console.error(`[background] Failed to create tab for ${url}:`, error);
      
      // Retry with exponential backoff
      if (retryCount < 3) {
        const delay = Math.pow(2, retryCount) * 1000; // 1s, 2s, 4s
        setTimeout(() => {
          request.retryCount = retryCount + 1;
          this.requestQueue.unshift(request); // Add back to front of queue
          this.processQueue();
        }, delay);
      } else {
        reject(new Error(`Failed to create tab after ${retryCount} retries: ${error.message}`));
      }
    }
  }

  waitForTabLoad(tabId) {
    console.log(`[background] Setting up tab load listener for tab ${tabId}`);
    const onTabUpdated = (updatedTabId, changeInfo, tab) => {
      if (updatedTabId === tabId) {
        console.log(`[background] Tab ${tabId} updated:`, {
          status: changeInfo.status,
          url: tab.url
        });
        if (changeInfo.status === 'complete') {
          console.log(`[background] Tab ${tabId} finished loading! Removing listener and injecting script...`);
          chrome.tabs.onUpdated.removeListener(onTabUpdated);
          this.injectScrapeScript(tabId);
        }
      }
    };

    chrome.tabs.onUpdated.addListener(onTabUpdated);
  }

  async injectScrapeScript(tabId) {
    try {
      console.log(`[background] Injecting scrape script into tab ${tabId}`);
      
      const tabData = this.activeTabs.get(tabId);
      const targetDateTime = tabData?.targetDateTime;
      const extractResourcesRaw = tabData?.extractResources;
      // Default to true if not specified, but respect explicit false
      const extractResources = extractResourcesRaw === undefined ? true : extractResourcesRaw;
      
      console.log(`[background] Tab data for ${tabId}:`, {
        hasTargetDateTime: !!targetDateTime,
        extractResourcesRaw: extractResourcesRaw,
        extractResources: extractResources
      });
      
      if (targetDateTime) {
        console.log(`[background] Setting targetDateTime for tab ${tabId}:`, targetDateTime);
        // First inject the targetDateTime as a global variable
        await chrome.scripting.executeScript({
          target: { tabId: tabId },
          func: (targetDateTime) => {
            window.FAREHARBOR_TARGET_DATETIME = targetDateTime;
            console.log('[background injection] Set targetDateTime:', targetDateTime);
          },
          args: [targetDateTime]
        });
      }
      
      // Set extractResources flag
      console.log(`[background] Setting extractResources for tab ${tabId}:`, extractResources, '(raw value:', extractResourcesRaw, ')');
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: (extractResources) => {
          window.FAREHARBOR_EXTRACT_RESOURCES = extractResources;
          console.log('[background injection] Set extractResources:', extractResources, '(type:', typeof extractResources, ')');
        },
        args: [extractResources]
      });
      
      // Then inject the main scrape script
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['scrape.js']
      });

      console.log(`[background] Script injected successfully into tab ${tabId}`);
    } catch (error) {
      console.error(`[background] Failed to inject script into tab ${tabId}:`, error);
      this.handleTabError(tabId, error);
    }
  }

  handleTabTimeout(tabId) {
    console.warn(`[background] Tab ${tabId} timed out`);
    this.handleTabError(tabId, new Error('Tab loading timeout'));
  }

  handleTabError(tabId, error) {
    const tabData = this.activeTabs.get(tabId);
    if (tabData) {
      clearTimeout(tabData.timeout);
      tabData.reject(error);
      this.cleanupTab(tabId);
    }
  }

  handleTabSuccess(tabId, result) {
    const tabData = this.activeTabs.get(tabId);
    if (tabData) {
      clearTimeout(tabData.timeout);
      tabData.resolve(result);
      this.cleanupTab(tabId);
    }
  }

  async cleanupTab(tabId) {
    this.activeTabs.delete(tabId);

    try {
      await chrome.tabs.remove(tabId);
    } catch (error) {
      // Ignore if tab was already closed by user
      if (error?.message && !error.message.includes('No tab with id')) {
        console.warn(`[background] Failed to close tab ${tabId}:`, error);
      }
    }

    // Process next item in queue
    this.processQueue();
  }
}

// Create global tab manager instance
const tabManager = new BackgroundTabManager();

// Function to set up context menus based on use case
async function setupContextMenus() {
  // Remove all existing context menus first
  await chrome.contextMenus.removeAll();
  
  // Get the current use case preference
  const result = await chrome.storage.sync.get(['selectedUsecase']);
  const usecase = result.selectedUsecase || 'all';
  
  console.log(`[background] Setting up context menus for use case: ${usecase}`);
  
  // Create main context menu (works on any website)
  chrome.contextMenus.create({
    id: "jump-to",
    title: "Jump to...",
    contexts: ["selection"]
  });

  if (usecase === 'support') {
    // For Support use case: Put FareHarbor items directly under "Jump to" (no submenu)
    
    // Create shortname submenu directly under "Jump to"
    chrome.contextMenus.create({
      id: "shortname-jump",
      parentId: "jump-to",
      title: "shortname",
      contexts: ["selection"]
    });

    // Create shortname submenu items
    const shortnameOptions = [
      { id: "shortname-calendar", title: "Calendar", url: "https://fareharbor.com/SHORTNAME/dashboard/" },
      { id: "shortname-items", title: "Items", url: "https://fareharbor.com/SHORTNAME/dashboard/items/list/" },
      { id: "shortname-affiliates", title: "Affiliates", url: "https://fareharbor.com/SHORTNAME/dashboard/settings/network/affiliates/" },
      { id: "shortname-reports", title: "Reports", url: "https://fareharbor.com/SHORTNAME/dashboard/reports/" },
      { id: "shortname-settings", title: "Settings", url: "https://fareharbor.com/SHORTNAME/dashboard/settings/" },
      { id: "shortname-users", title: "Users", url: "https://fareharbor.com/SHORTNAME/dashboard/settings/permissions/users/" },
      { id: "shortname-integrations", title: "Integrations", url: "https://fareharbor.com/SHORTNAME/dashboard/settings/integrations/channels/" }
    ];

    shortnameOptions.forEach(option => {
      chrome.contextMenus.create({
        id: option.id,
        parentId: "shortname-jump",
        title: option.title,
        contexts: ["selection"]
      });
    });

    // Create FareHarbor jump options directly under "Jump to" (excluding channel options for Support)
    const jumpOptions = [
      { id: "jump-item", title: "Item", type: "Item" },
      { id: "jump-booking", title: "Booking", type: "Booking" }
    ];

    jumpOptions.forEach(option => {
      chrome.contextMenus.create({
        id: option.id,
        parentId: "jump-to",
        title: option.title,
        contexts: ["selection"]
      });
    });
  } else {
    // For other use cases: Normal structure with submenus
    
    // Create FareHarbor submenu
    chrome.contextMenus.create({
      id: "fareharbor-jump",
      parentId: "jump-to",
      title: "FareHarbor",
      contexts: ["selection"]
    });

    // Create Airbnb submenu
    chrome.contextMenus.create({
      id: "airbnb-jump",
      parentId: "jump-to",
      title: "Airbnb",
      contexts: ["selection"]
    });

    // Create Airbnb submenu items
    const airbnbOptions = [
      { id: "airbnb-host-listings", title: "Host ID Listings" },
      { id: "airbnb-activity-id", title: "Activity ID" },
      { id: "airbnb-offering-id", title: "Offering ID" }
    ];

    airbnbOptions.forEach(option => {
      chrome.contextMenus.create({
        id: option.id,
        parentId: "airbnb-jump",
        title: option.title,
        contexts: ["selection"]
      });
    });

    // Create GetYourGuide submenu
    chrome.contextMenus.create({
      id: "getyourguide-jump",
      parentId: "jump-to",
      title: "GetYourGuide",
      contexts: ["selection"]
    });

    // Create GetYourGuide Supplier ID context menu item under GetYourGuide submenu
    chrome.contextMenus.create({
      id: "getyourguide-supplier",
      parentId: "getyourguide-jump",
      title: "Supplier ID",
      contexts: ["selection"]
    });

    // Create GetYourGuide context menu item under GetYourGuide submenu
    chrome.contextMenus.create({
      id: "getyourguide-product",
      parentId: "getyourguide-jump",
      title: "Product ID",
      contexts: ["selection"]
    });

    // Create Expedia context menu item under main menu
    chrome.contextMenus.create({
      id: "expedia-product",
      parentId: "jump-to",
      title: "Expedia product",
      contexts: ["selection"]
    });

    // Create shortname submenu under FareHarbor (at the top)
    chrome.contextMenus.create({
      id: "shortname-jump",
      parentId: "fareharbor-jump",
      title: "shortname",
      contexts: ["selection"]
    });

    // Create shortname submenu items
    const shortnameOptions = [
      { id: "shortname-calendar", title: "Calendar", url: "https://fareharbor.com/SHORTNAME/dashboard/" },
      { id: "shortname-items", title: "Items", url: "https://fareharbor.com/SHORTNAME/dashboard/items/list/" },
      { id: "shortname-affiliates", title: "Affiliates", url: "https://fareharbor.com/SHORTNAME/dashboard/settings/network/affiliates/" },
      { id: "shortname-reports", title: "Reports", url: "https://fareharbor.com/SHORTNAME/dashboard/reports/" },
      { id: "shortname-settings", title: "Settings", url: "https://fareharbor.com/SHORTNAME/dashboard/settings/" },
      { id: "shortname-users", title: "Users", url: "https://fareharbor.com/SHORTNAME/dashboard/settings/permissions/users/" },
      { id: "shortname-integrations", title: "Integrations", url: "https://fareharbor.com/SHORTNAME/dashboard/settings/integrations/channels/" }
    ];

    shortnameOptions.forEach(option => {
      chrome.contextMenus.create({
        id: option.id,
        parentId: "shortname-jump",
        title: option.title,
        contexts: ["selection"]
      });
    });

    // Create submenu items for different FareHarbor search types
    const jumpOptions = [
      { id: "jump-item", title: "Item", type: "Item" },
      { id: "jump-booking", title: "Booking", type: "Booking" },
      { id: "jump-channel-company", title: "Channel company", type: "Channel company" },
      { id: "jump-channel-item", title: "Channel item", type: "Channel item" },
      { id: "jump-channel-option", title: "Channel option", type: "Channel option" }
    ];

    jumpOptions.forEach(option => {
      chrome.contextMenus.create({
        id: option.id,
        parentId: "fareharbor-jump",
        title: option.title,
        contexts: ["selection"]
      });
    });

    // Create TripAdvisor listing option at the bottom (for other use cases)
    chrome.contextMenus.create({
      id: "tripadvisor-listing",
      parentId: "jump-to",
      title: "TripAdvisor listing",
      contexts: ["selection"]
    });
  }
}

// Context menu setup for FareHarbor Jump functionality
chrome.runtime.onInstalled.addListener(() => {
  setupContextMenus();
});

// Listen for use case changes and update context menus
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'sync' && changes.selectedUsecase) {
    console.log('[background] Use case changed, updating context menus');
    setupContextMenus();
  }
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  // Handle TripAdvisor listing menu
  if (info.menuItemId === "tripadvisor-listing" && info.selectionText) {
    const searchText = info.selectionText.trim();
    // Format: site:tripadvisor.com+"Product Code: TEXTHERE"
    // Encode the search text and build the query with proper encoding
    const encodedText = encodeURIComponent(searchText);
    const query = `site:tripadvisor.com+%22Product%20Code%3A%20${encodedText}%22`;
    const googleSearchUrl = `https://www.google.com/search?q=${query}`;
    
    console.log(`[background] Opening TripAdvisor Google search URL: ${googleSearchUrl}`);
    chrome.tabs.create({ url: googleSearchUrl }, (newTab) => {
      // Wait for the tab to load, then click the first result
      chrome.tabs.onUpdated.addListener(function tabUpdateListener(tabId, changeInfo, tab) {
        if (tabId === newTab.id && changeInfo.status === 'complete' && tab.url && tab.url.includes('google.com/search')) {
          console.log(`[background] Google search page loaded, attempting to click first result`);
          // Remove the listener to avoid multiple triggers
          chrome.tabs.onUpdated.removeListener(tabUpdateListener);
          
          // Poll for search results and navigate to first result
          let attemptCount = 0;
          const maxAttempts = 50; // Try for up to 5 seconds (50 * 100ms)
          
          function tryFindAndNavigate() {
            attemptCount++;
            if (attemptCount % 10 === 0) { // Only log every 10th attempt to reduce noise
              console.log(`[background] Attempting to find first result (attempt ${attemptCount}/${maxAttempts})`);
            }
            
            chrome.scripting.executeScript({
              target: { tabId: newTab.id },
              func: () => {
                console.log('[tripadvisor-jump] Script injected, starting search for link');
                console.log('[tripadvisor-jump] Current URL:', window.location.href);
                console.log('[tripadvisor-jump] Document ready state:', document.readyState);
                
                // Try multiple selectors to find the first Google search result link
                // Based on Google's current HTML structure
                const selectors = [
                  'a.zReHs[href*="tripadvisor.com"]', // Specific class with tripadvisor link
                  'a[jsname="UWckNb"][href*="tripadvisor.com"]', // jsname attribute with tripadvisor link
                  'div.yuRUbf a[href*="tripadvisor.com"]', // Container div with tripadvisor link
                  'div.N54PNb a[href*="tripadvisor.com"]', // Outer container with tripadvisor link
                  'a.zReHs', // Any link with zReHs class (first result)
                  'a[jsname="UWckNb"]', // Any link with UWckNb jsname
                  'div.yuRUbf a', // Any link in yuRUbf container
                  'div.g a[href*="tripadvisor.com"]', // Fallback: old structure with tripadvisor link
                  'div[data-ved] a[href*="tripadvisor.com"]', // Fallback: data-ved with tripadvisor link
                  'h3 a[href*="tripadvisor.com"]', // Fallback: title link with tripadvisor
                  'div.g a', // Fallback: any first result link
                  'div[data-ved] a', // Fallback: any result with data-ved
                  'h3 a' // Fallback: any title link
                ];
                
                console.log('[tripadvisor-jump] Trying selectors...');
                
                // Try to find TripAdvisor link first
                for (let i = 0; i < selectors.length; i++) {
                  const selector = selectors[i];
                  console.log(`[tripadvisor-jump] Trying selector ${i + 1}/${selectors.length}: ${selector}`);
                  const firstLink = document.querySelector(selector);
                  
                  if (firstLink) {
                    console.log(`[tripadvisor-jump] Found element with selector: ${selector}`);
                    console.log(`[tripadvisor-jump] Element href: ${firstLink.href}`);
                    console.log(`[tripadvisor-jump] Element class: ${firstLink.className}`);
                    console.log(`[tripadvisor-jump] Element tag: ${firstLink.tagName}`);
                    
                    if (firstLink.href && firstLink.href.includes('tripadvisor.com')) {
                      console.log(`[tripadvisor-jump] Found TripAdvisor link: ${firstLink.href}`);
                      return { url: firstLink.href, found: true, selector: selector };
                    } else if (firstLink.href) {
                      console.log(`[tripadvisor-jump] Found link (not TripAdvisor): ${firstLink.href}`);
                      // Continue searching for TripAdvisor link
                    } else {
                      console.log(`[tripadvisor-jump] Found element but no href`);
                    }
                  } else {
                    console.log(`[tripadvisor-jump] No element found with selector: ${selector}`);
                  }
                }
                
                // If no tripadvisor link found, try any first result link
                console.log('[tripadvisor-jump] No TripAdvisor link found, trying any first result...');
                for (let i = 0; i < selectors.length; i++) {
                  const selector = selectors[i];
                  const firstLink = document.querySelector(selector);
                  if (firstLink && firstLink.href) {
                    console.log(`[tripadvisor-jump] Found any link: ${firstLink.href} with selector: ${selector}`);
                    return { url: firstLink.href, found: true, selector: selector };
                  }
                }
                
                // Log page structure for debugging
                console.log('[tripadvisor-jump] Page structure check:');
                console.log('[tripadvisor-jump] - Total links on page:', document.querySelectorAll('a').length);
                console.log('[tripadvisor-jump] - Links with tripadvisor.com:', document.querySelectorAll('a[href*="tripadvisor.com"]').length);
                console.log('[tripadvisor-jump] - Elements with class zReHs:', document.querySelectorAll('.zReHs').length);
                console.log('[tripadvisor-jump] - Elements with jsname UWckNb:', document.querySelectorAll('[jsname="UWckNb"]').length);
                console.log('[tripadvisor-jump] - Divs with class yuRUbf:', document.querySelectorAll('.yuRUbf').length);
                
                console.log('[tripadvisor-jump] No link found, returning null');
                return { url: null, found: false, selector: null };
              }
            }, (results) => {
              console.log(`[background] Script execution result:`, results);
              console.log(`[background] Results type:`, typeof results);
              console.log(`[background] Results is array:`, Array.isArray(results));
              
              if (chrome.runtime.lastError) {
                console.error(`[background] Error executing script:`, chrome.runtime.lastError.message);
                if (attemptCount < maxAttempts) {
                  setTimeout(tryFindAndNavigate, 100); // Retry quickly
                } else {
                  console.error(`[background] Max attempts reached, giving up`);
                }
                return;
              }
              
              // Extract the actual result from the executeScript response
              let actualResult = null;
              if (results && Array.isArray(results) && results.length > 0) {
                // executeScript returns array of results, each with {result: ...}
                actualResult = results[0].result || results[0];
              } else if (results && results.result) {
                actualResult = results.result;
              } else {
                actualResult = results;
              }
              
              if (actualResult && actualResult.found && actualResult.url) {
                const targetUrl = actualResult.url;
                console.log(`[background] ✓ Found first result link on attempt ${attemptCount}: ${targetUrl}`);
                console.log(`[background] Found with selector: ${actualResult.selector}`);
                console.log(`[background] Navigating to: ${targetUrl}`);
                
                // Navigate to the URL from background script (more reliable)
                chrome.tabs.update(newTab.id, { url: targetUrl }, (updatedTab) => {
                  if (chrome.runtime.lastError) {
                    console.error(`[background] Error navigating to URL:`, chrome.runtime.lastError.message);
                  } else {
                    console.log(`[background] ✓ Successfully navigated to TripAdvisor page`);
                  }
                });
                return; // Stop polling once we found and navigated
              }
              
              // Continue polling if not found yet
              if (attemptCount < maxAttempts) {
                setTimeout(tryFindAndNavigate, 100); // Check every 100ms for faster response
              } else {
                console.warn('[background] Could not find first search result link after max attempts');
              }
            });
          }
          
          // Start trying immediately (page is already loaded)
          console.log(`[background] Starting search for first result...`);
          tryFindAndNavigate();
        }
      });
    });
    return;
  }
  
  // Handle GetYourGuide product menu
  if (info.menuItemId === "getyourguide-product" && info.selectionText) {
    const searchText = info.selectionText.trim();
    const getyourguideUrl = `https://www.getyourguide.com/venice-l35/getyourguide-t${encodeURIComponent(searchText)}`;
    
    console.log(`[background] Opening GetYourGuide URL: ${getyourguideUrl}`);
    chrome.tabs.create({ url: getyourguideUrl });
    return;
  }
  
  // Handle GetYourGuide supplier menu
  if (info.menuItemId === "getyourguide-supplier" && info.selectionText) {
    const supplierId = info.selectionText.trim();
    const getyourguideUrl = `https://www.getyourguide.com/partner-s${encodeURIComponent(supplierId)}/`;
    
    console.log(`[background] Opening GetYourGuide Supplier URL: ${getyourguideUrl}`);
    chrome.tabs.create({ url: getyourguideUrl });
    return;
  }
  
  // Handle Expedia product menu
  if (info.menuItemId === "expedia-product" && info.selectionText) {
    const searchText = info.selectionText.trim();
    const expediadUrl = `https://www.expedia.com/things-to-do/amsterdam.a${encodeURIComponent(searchText)}.activity-details`;
    
    console.log(`[background] Opening Expedia URL: ${expediadUrl}`);
    chrome.tabs.create({ url: expediadUrl });
    return;
  }
  
  // Handle Airbnb menu options
  if (info.menuItemId.startsWith("airbnb-") && info.selectionText) {
    const searchText = info.selectionText.trim();
    
    const airbnbUrls = {
      "airbnb-host-listings": `https://www.airbnb.com/api-partner-portal/activities/client/2724/diagnostics/activity-listings?hostUserID=${encodeURIComponent(searchText)}`,
      "airbnb-activity-id": `https://www.airbnb.com/api-partner-portal/activities/client/2724/diagnostics/activity-listings/${encodeURIComponent(searchText)}/overview`,
      "airbnb-offering-id": `https://www.airbnb.com/api-partner-portal/activities/client/2724/diagnostics/activity-offerings/${encodeURIComponent(searchText)}/overview`
    };
    
    const targetUrl = airbnbUrls[info.menuItemId];
    if (targetUrl) {
      console.log(`[background] Opening Airbnb URL: ${targetUrl}`);
      chrome.tabs.create({ url: targetUrl });
      return;
    }
  }
  
  // Handle shortname menu options
  if (info.menuItemId.startsWith("shortname-") && info.selectionText) {
    const shortname = info.selectionText.trim();
    
    const shortnameUrls = {
      "shortname-calendar": `https://fareharbor.com/${encodeURIComponent(shortname)}/dashboard/`,
      "shortname-items": `https://fareharbor.com/${encodeURIComponent(shortname)}/dashboard/items/list/`,
      "shortname-affiliates": `https://fareharbor.com/${encodeURIComponent(shortname)}/dashboard/settings/network/affiliates/`,
      "shortname-reports": `https://fareharbor.com/${encodeURIComponent(shortname)}/dashboard/reports/`,
      "shortname-settings": `https://fareharbor.com/${encodeURIComponent(shortname)}/dashboard/settings/`,
      "shortname-users": `https://fareharbor.com/${encodeURIComponent(shortname)}/dashboard/settings/permissions/users/`,
      "shortname-integrations": `https://fareharbor.com/${encodeURIComponent(shortname)}/dashboard/settings/integrations/channels/`
    };
    
    const targetUrl = shortnameUrls[info.menuItemId];
    if (targetUrl) {
      console.log(`[background] Opening shortname URL: ${targetUrl}`);
      chrome.tabs.create({ url: targetUrl });
      return;
    }
  }
  
  // Handle FareHarbor jump menu
  if (info.menuItemId.startsWith("jump-") && info.selectionText) {
    const jumpType = info.menuItemId.replace("jump-", "");
    const searchText = info.selectionText.trim();
    resolveAndOpenFareHarborJump(jumpType, searchText);
    return;
  }
});

function performDomJumpFallback(jumpType, searchText) {
  console.log(`[background] Opening admin dashboard for DOM jump fallback: ${jumpType}: "${searchText}"`);
  chrome.tabs.create({ url: 'https://fareharbor.com/admin/dashboard/admin/' }, (newTab) => {
    chrome.tabs.onUpdated.addListener(function tabUpdateListener(tabId, changeInfo, tab) {
      if (tabId === newTab.id && changeInfo.status === 'complete' && tab.url.includes('fareharbor.com/admin')) {
        console.log(`[background] Tab loaded completely. Final URL: ${tab.url}`);
        chrome.tabs.onUpdated.removeListener(tabUpdateListener);
        attemptJumpMessage();

        function attemptJumpMessage() {
          let retryCount = 0;
          const maxRetries = 30;

          function checkAndSend() {
            console.log(`[background] Checking for content scripts availability, attempt ${retryCount + 1}/${maxRetries}`);

            chrome.tabs.sendMessage(newTab.id, {
              action: "performFareHarborJump",
              jumpType: jumpType,
              searchText: searchText
            }, (response) => {
              if (chrome.runtime.lastError) {
                console.log(`[background] Content scripts not ready yet:`, chrome.runtime.lastError.message);

                if (retryCount === 0) {
                  console.log(`[background] Attempting manual content script injection...`);
                  chrome.scripting.executeScript({
                    target: { tabId: newTab.id },
                    files: [
                      'content/content-main.js',
                      'content/fareharbor-jump.js'
                    ]
                  }, () => {
                    if (chrome.runtime.lastError) {
                      console.error(`[background] Failed to inject content scripts:`, chrome.runtime.lastError.message);
                    } else {
                      console.log(`[background] Content scripts injected successfully`);
                    }
                  });
                }

                if (retryCount < maxRetries) {
                  retryCount++;
                  setTimeout(checkAndSend, 500);
                } else {
                  console.error(`[background] Failed to send jump message after ${maxRetries} attempts`);
                }
              } else {
                console.log(`[background] Jump message sent successfully on attempt ${retryCount + 1}:`, response);
              }
            });
          }

          checkAndSend();
        }
      }
    });
  });
}

async function resolveAndOpenFareHarborJump(jumpType, searchText) {
  try {
    const result = await resolveFareHarborJump(jumpType, searchText);
    if (result.ok && result.url) {
      console.log(`[background] Opening resolved FareHarbor URL: ${result.url}`);
      chrome.tabs.create({ url: result.url });
      return;
    }
    console.warn('[background] FareHarbor jump resolver fallback:', result.fallbackReason, result.meta);
    performDomJumpFallback(jumpType, searchText);
  } catch (err) {
    console.error('[background] FareHarbor jump resolver error:', err);
    performDomJumpFallback(jumpType, searchText);
  }
}


// Message listener
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // GYG token / fetch API (getyourguide_capture_and_fetch)
  if (message.type === 'getToken') {
    (async () => {
      const allowed = await FareHarborDeveloperAuth.requireActiveDevModeAsync('getToken');
      if (!allowed) {
        sendResponse({ error: 'GYG token access requires DEV mode' });
        return;
      }
      chrome.storage.local.get([GYG_TOKEN_KEY, GYG_SUPPLIER_KEY, GYG_TOKEN_TS_KEY], sendResponse);
    })();
    return true;
  }
  if (message.type === 'clearToken') {
    (async () => {
      const allowed = await FareHarborDeveloperAuth.requireActiveDevModeAsync('clearToken');
      if (!allowed) {
        sendResponse({ ok: false, error: 'GYG token clear requires DEV mode' });
        return;
      }
      chrome.storage.local.remove([GYG_TOKEN_KEY, GYG_SUPPLIER_KEY, GYG_TOKEN_TS_KEY], () => sendResponse({ ok: true }));
    })();
    return true;
  }
  if (message.type === 'startFetchAllOptions') {
    (async () => {
      try {
        const results = await self.runFetchAllOptions(message.payload || {});
        sendResponse({ ok: true, results });
      } catch (err) {
        sendResponse({
          ok: false,
          error: String(err),
          partial: { count: 0, ids: [] }
        });
      }
    })();
    return true;
  }

  if (message.type === 'gygInstallTokenCapture') {
    (async () => {
      const tabId = sender.tab && sender.tab.id;
      if (!tabId) {
        sendResponse({ ok: false, error: 'Missing sender tab ID' });
        return;
      }
      try {
        await gygExecuteScriptWithTimeout(tabId, {
          func: gygInstallTokenCaptureInMainWorld,
          args: []
        }, 10000);
        sendResponse({ ok: true });
      } catch (err) {
        console.error(GYG_PRODUCTS_LOG, 'Token capture install failed:', err && err.message ? err.message : err);
        sendResponse({ ok: false, error: String(err && err.message ? err.message : err) });
      }
    })();
    return true;
  }

  if (message.type === 'gygTriggerGraphQLForToken') {
    (async () => {
      const tabId = sender.tab && sender.tab.id;
      if (!tabId) {
        sendResponse({ ok: false, error: 'Missing sender tab ID' });
        return;
      }
      try {
        await gygExecuteScriptWithTimeout(tabId, {
          func: gygTriggerGraphQLForTokenInMainWorld,
          args: []
        }, 10000);
        sendResponse({ ok: true });
      } catch (err) {
        sendResponse({ ok: false, error: String(err && err.message ? err.message : err) });
      }
    })();
    return true;
  }

  if (message.type === 'gygReadBearerToken') {
    (async () => {
      const tabId = sender.tab && sender.tab.id;
      if (!tabId) {
        sendResponse({ ok: false, error: 'Missing sender tab ID' });
        return;
      }
      try {
        const results = await gygExecuteScriptWithTimeout(tabId, {
          func: gygReadBearerTokenInMainWorld,
          args: []
        }, 10000);
        const token = results && results[0] && results[0].result ? String(results[0].result) : '';
        if (token) gygSaveToken('Bearer ' + gygNormalizeBearerToken(token), undefined);
        sendResponse({ ok: true, token: gygNormalizeBearerToken(token) });
      } catch (err) {
        sendResponse({ ok: false, error: String(err && err.message ? err.message : err) });
      }
    })();
    return true;
  }

  if (message.type === 'gygGraphQLRequest') {
    (async () => {
      try {
        const response = await gygHandleGraphQLRequest(message, sender);
        sendResponse(response);
      } catch (err) {
        console.error(GYG_PRODUCTS_LOG, 'GraphQL request failed:', err && err.message ? err.message : err);
        sendResponse({
          ok: false,
          requestId: message.requestId || '',
          error: String(err && err.message ? err.message : err)
        });
      }
    })();
    return true;
  }

  // Handle Angular extraction (existing functionality)
  if (message?.type === 'FH_INJECT_ANGULAR_EXTRACTOR' && sender.tab?.id) {
    const { tabId, elementRefId } = message;
    const targetTabId = tabId || sender.tab.id;
    chrome.scripting.executeScript({
      target: { tabId: targetTabId },
      world: 'MAIN',
      func: (id) => {
        try {
          const responseEventName = 'fh-ext-angular-response';
          const el = document.querySelector(`[data-fh-ext-id="${id}"]`);
          let payload = null;
          if (el && window.angular && typeof window.angular.element === 'function') {
            try {
              const ngEl = window.angular.element(el);
              const scope = (ngEl && (ngEl.scope && ngEl.scope())) || (ngEl && ngEl.inheritedData && ngEl.inheritedData('$scope')) || null;
              const booking = (scope && (scope.booking || (scope.$ctrl && scope.$ctrl.booking))) || scope || null;
              if (booking) {
                try { payload = JSON.stringify(booking); } catch (e) { payload = booking; }
              }
            } catch (_) {}
          }
          const evt = new CustomEvent(responseEventName, { detail: { id, payload } });
          document.dispatchEvent(evt);
        } catch (_) {
          const evt = new CustomEvent('fh-ext-angular-response', { detail: { id, payload: null } });
          document.dispatchEvent(evt);
        }
      },
      args: [elementRefId]
    }, () => {
      sendResponse({ ok: true });
    });
    return true;
  }

  // Handle background scraping requests
  if (message.action === 'backgroundScrapeUrls') {
    const { urls, targetDateTime, extractResources = true } = message;
    console.log(`[background] ===== RECEIVED backgroundScrapeUrls REQUEST =====`);
    console.log(`[background] Number of URLs: ${urls.length}`);
    console.log(`[background] URLs:`, urls);
    console.log(`[background] Target date/time: ${targetDateTime ? new Date(targetDateTime).toISOString() : 'null'}`);
    console.log(`[background] Extract resources: ${extractResources}`);

    (async () => {
      try {
        console.log(`[background] Starting to process ${urls.length} URLs...`);
        const results = await Promise.allSettled(
          urls.map((url, index) => {
            console.log(`[background] Processing URL ${index + 1}/${urls.length}: ${url}`);
            return tabManager.scrapeUrl(url, targetDateTime, extractResources);
          })
        );
        
        console.log(`[background] All URLs processed. Results:`, results.map((r, i) => ({
          url: urls[i],
          status: r.status,
          hasValue: r.status === 'fulfilled' && !!r.value,
          error: r.status === 'rejected' ? r.reason.message : null
        })));
        
        const processedResults = results.map((result, index) => ({
          url: urls[index],
          success: result.status === 'fulfilled',
          data: result.status === 'fulfilled' ? result.value : null,
          error: result.status === 'rejected' ? result.reason.message : null
        }));

        console.log(`[background] Sending response with ${processedResults.length} results`);
        sendResponse({ success: true, results: processedResults });
      } catch (error) {
        console.error('[background] ===== ERROR IN backgroundScrapeUrls =====');
        console.error('[background] Batch scraping failed:', error);
        console.error('[background] Error stack:', error.stack);
        sendResponse({ success: false, error: error.message });
      }
    })();

    return true; // Keep message channel open for async response
  }

  // Handle results from injected scrape scripts
  if (message.action === 'backgroundScrapeResult') {
    const { data } = message;
    const tabId = sender.tab?.id;
    
    console.log(`[background] Received scrape result from tab ${tabId}:`, data);
    
    if (tabId && tabManager.activeTabs.has(tabId)) {
      tabManager.handleTabSuccess(tabId, data);
    }
    
    return true;
  }

  // Handle scraping all GetYourGuide products
  if (message.action === 'scrapeAllGetYourGuideProducts') {
    const { tourIds, includeHeaderRow } = message;
    console.log(`[background] Received request to scrape ${tourIds.length} GetYourGuide products`);
    
    (async () => {
      try {
        const allResults = [];
        const seenOptionIds = new Set();
        
        // Scrape each product sequentially
        for (let i = 0; i < tourIds.length; i++) {
          const tourId = tourIds[i];
          const url = `https://supplier.getyourguide.com/products/details?tour_id=${tourId}`;
          
          console.log(`[background] Scraping product ${i + 1}/${tourIds.length} (tour_id: ${tourId})...`);
          
          try {
            // Create tab and wait for it to load
            const tab = await chrome.tabs.create({ url: url, active: false });
            
            // Wait for tab to complete loading
            await new Promise((resolve) => {
              const listener = (tabId, changeInfo) => {
                if (tabId === tab.id && changeInfo.status === 'complete') {
                  chrome.tabs.onUpdated.removeListener(listener);
                  // Wait a bit more for content to fully load
                  setTimeout(resolve, 2000);
                }
              };
              chrome.tabs.onUpdated.addListener(listener);
            });
            
            // Send message to scrape the product
            const response = await new Promise((resolve, reject) => {
              chrome.tabs.sendMessage(tab.id, {
                action: "runGetYourGuideProductsExtract",
                includeHeaderRow: false
              }, (response) => {
                if (chrome.runtime.lastError) {
                  reject(new Error(chrome.runtime.lastError.message));
                } else {
                  resolve(response);
                }
              });
            });
            
            // Close the tab
            chrome.tabs.remove(tab.id);
            
            // Process results
            if (response && response.success && response.data) {
              response.data.forEach(item => {
                if (!seenOptionIds.has(item.optionId)) {
                  seenOptionIds.add(item.optionId);
                  allResults.push(item);
                }
              });
            }
            
            console.log(`[background] Product ${i + 1} complete: ${allResults.length} total unique options so far`);
            
            // Small delay between products
            await new Promise(resolve => setTimeout(resolve, 1000));
          } catch (error) {
            console.error(`[background] Error scraping product ${tourId}:`, error);
            // Continue with next product
          }
        }
        
        console.log(`[background] Successfully extracted ${allResults.length} total unique options from ${tourIds.length} products`);
        
        // Format as TSV
        const formatAsTSV = (data, includeHeaderRow) => {
          if (!data || data.length === 0) return '';
          
          const tsvLines = [];
          if (includeHeaderRow) {
            const headers = ['Product ID', 'Option ID', 'Option name', 'External Product ID', 'Status'];
            tsvLines.push(headers.join('\t'));
          }
          
          data.forEach(item => {
            const row = [
              item.productId || '',
              item.optionId || '',
              item.optionName || '',
              item.externalProductId || '',
              item.status || ''
            ].map(field => {
              const str = String(field).trim();
              return str.replace(/[\t\n\r]/g, ' ');
            });
            tsvLines.push(row.join('\t'));
          });
          
          return tsvLines.join('\n');
        };
        
        const tsvData = formatAsTSV(allResults, includeHeaderRow);
        
        sendResponse({
          success: true,
          data: allResults,
          tsvData: tsvData,
          count: allResults.length,
          productCount: tourIds.length
        });
      } catch (error) {
        console.error('[background] Error scraping all GetYourGuide products:', error);
        sendResponse({
          success: false,
          error: error.message
        });
      }
    })();
    
    return true; // Keep message channel open for async response
  }

  // Handle extraction of airbnbActivityId from Settings page
  if (message.action === 'extractAirbnbActivityId') {
    const { url } = message;
    console.log(`[background] Received request to extract airbnbActivityId from edit URL: ${url}`);
    
    (async () => {
      try {
        // Create background tab with the edit link URL
        const tab = await chrome.tabs.create({ url: url, active: false });
        console.log(`[background] Created tab ${tab.id} for edit page: ${url}`);
        
        // Wait for edit page to complete loading with longer timeout
        console.log(`[background] Waiting for edit page to load...`);
        await new Promise((resolve) => {
          const listener = (tabId, changeInfo) => {
            if (tabId === tab.id && changeInfo.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              // Wait longer for content to fully load (Angular apps need more time)
              setTimeout(resolve, 4000);
            }
          };
          chrome.tabs.onUpdated.addListener(listener);
          // Fallback timeout after 15 seconds
          setTimeout(() => {
            chrome.tabs.onUpdated.removeListener(listener);
            resolve();
          }, 15000);
        });
        
        // Wait for Angular to be ready and page to be interactive
        console.log(`[background] Waiting for page to be fully interactive...`);
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            return new Promise((resolve) => {
              // Wait for document to be ready
              if (document.readyState === 'complete') {
                // Wait for Angular to be available and initialized
                const checkAngular = () => {
                  if (window.angular && document.querySelector('body')) {
                    // Wait a bit more for Angular to finish rendering
                    setTimeout(resolve, 2000);
                  } else {
                    setTimeout(checkAngular, 500);
                  }
                };
                checkAngular();
              } else {
                window.addEventListener('load', () => {
                  setTimeout(resolve, 2000);
                });
              }
            });
          }
        });
        
        // Inject CSS to hide overlay elements (same approach as Capacity Check)
        console.log(`[background] Injecting CSS to hide overlays...`);
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            // Add CSS to hide overlay UI if it appears
            let hideStyle = document.getElementById('fh-ext-hide-overlay-style');
            if (!hideStyle) {
              hideStyle = document.createElement('style');
              hideStyle.id = 'fh-ext-hide-overlay-style';
              hideStyle.textContent = `
                [class*="overlay"], [id*="overlay"], .modal, .dialog, [role="dialog"], .ngdialog, .ng-modal {
                  display: none !important; visibility: hidden !important; opacity: 0 !important;
                }
                body.body-print-overlay { overflow: hidden !important; }
              `;
              document.documentElement.appendChild(hideStyle);
              console.log('[airbnb-extract] Injected CSS to hide overlays');
            }
          }
        });
        
        console.log(`[background] Edit page loaded, waiting for Settings link to be available...`);
        
        // Wait for Settings link to be available with retries
        let clickResult = null;
        let retryCount = 0;
        const maxRetries = 10;
        
        while (retryCount < maxRetries && !clickResult) {
          await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second between retries
          
          clickResult = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              // Find the Settings link
              const settingsLink = document.querySelector('a.test-settings-reseller-item-action[ng-href*="/settings/"], a.test-settings-reseller-item-action[href*="/settings/"]');
              if (settingsLink) {
                console.log('[airbnb-extract] Found Settings link, clicking...');
                const href = settingsLink.getAttribute('ng-href') || settingsLink.getAttribute('href') || settingsLink.href;
                console.log('[airbnb-extract] Settings link href:', href);
                
                // Check if link is visible and clickable
                const style = window.getComputedStyle(settingsLink);
                if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
                  console.warn('[airbnb-extract] Settings link is not visible');
                  return { found: false, reason: 'not_visible' };
                }
                
                settingsLink.click();
                return { found: true, clicked: true };
              } else {
                console.warn('[airbnb-extract] Settings link not found (attempt ' + (window.retryAttempt || 0) + ')');
                // Log available links for debugging
                const allLinks = document.querySelectorAll('a[href*="/settings/"]');
                console.log('[airbnb-extract] Found links with /settings/:', allLinks.length);
                return { found: false, reason: 'not_found' };
              }
            }
          });
          
          if (clickResult && clickResult[0] && clickResult[0].result && clickResult[0].result.found) {
            console.log(`[background] Settings link found and clicked on attempt ${retryCount + 1}`);
            break;
          }
          
          retryCount++;
          console.log(`[background] Settings link not found, retrying... (${retryCount}/${maxRetries})`);
        }
        
        if (!clickResult || !clickResult[0] || !clickResult[0].result || !clickResult[0].result.found) {
          console.warn(`[background] Failed to click Settings link after ${maxRetries} attempts`);
          chrome.tabs.remove(tab.id);
          sendResponse({
            success: false,
            error: 'Settings link not found after multiple attempts',
            airbnbActivityId: ''
          });
          return;
        }
        
        console.log(`[background] Settings link clicked, waiting for Settings page to load...`);
        
        // Wait for navigation to Settings page with longer timeout
        await new Promise((resolve) => {
          let resolved = false;
          const listener = (tabId, changeInfo, updatedTab) => {
            if (tabId === tab.id && changeInfo.status === 'complete') {
              const currentUrl = updatedTab.url || '';
              if (currentUrl.endsWith('/settings/')) {
                console.log(`[background] Settings page loaded: ${currentUrl}`);
                chrome.tabs.onUpdated.removeListener(listener);
                if (!resolved) {
                  resolved = true;
                  // Wait longer for Settings page to fully load
                  setTimeout(resolve, 4000);
                }
              }
            }
          };
          chrome.tabs.onUpdated.addListener(listener);
          
          // Timeout after 20 seconds (increased from 15)
          setTimeout(() => {
            if (!resolved) {
              resolved = true;
              chrome.tabs.onUpdated.removeListener(listener);
              resolve();
            }
          }, 20000);
        });
        
        // Wait for Angular to be ready on Settings page
        console.log(`[background] Waiting for Settings page to be fully interactive...`);
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            return new Promise((resolve) => {
              // Wait for Angular to be available and initialized
              const checkAngular = () => {
                if (window.angular && document.querySelector('body')) {
                  // Wait a bit more for Angular to finish rendering
                  setTimeout(resolve, 2000);
                } else {
                  setTimeout(checkAngular, 500);
                }
              };
              checkAngular();
            });
          }
        });
        
        // Re-inject CSS to hide overlays on Settings page (in case they appear)
        console.log(`[background] Re-injecting CSS to hide overlays on Settings page...`);
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            // Add CSS to hide overlay UI if it appears
            let hideStyle = document.getElementById('fh-ext-hide-overlay-style');
            if (!hideStyle) {
              hideStyle = document.createElement('style');
              hideStyle.id = 'fh-ext-hide-overlay-style';
              hideStyle.textContent = `
                [class*="overlay"], [id*="overlay"], .modal, .dialog, [role="dialog"], .ngdialog, .ng-modal {
                  display: none !important; visibility: hidden !important; opacity: 0 !important;
                }
                body.body-print-overlay { overflow: hidden !important; }
              `;
              document.documentElement.appendChild(hideStyle);
              console.log('[airbnb-extract] Injected CSS to hide overlays on Settings page');
            }
          }
        });
        
        console.log(`[background] Extracting airbnbActivityId from Settings page...`);
        
        // Extract airbnbActivityId with retries
        let extractResult = null;
        let extractRetryCount = 0;
        const maxExtractRetries = 10;
        
        while (extractRetryCount < maxExtractRetries) {
          await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second between retries
          
          extractResult = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              const input = document.querySelector('input[name="airbnbActivityId"]');
              if (input) {
                const value = input.value ? input.value.trim() : '';
                console.log('[airbnb-extract] Found airbnbActivityId input, value:', value);
                return { found: true, value: value };
              } else {
                console.warn('[airbnb-extract] airbnbActivityId input not found (attempt ' + (window.extractRetryAttempt || 0) + ')');
                // Log available inputs for debugging
                const allInputs = document.querySelectorAll('input[type="text"]');
                console.log('[airbnb-extract] Found text inputs:', allInputs.length);
                allInputs.forEach((inp, i) => {
                  const name = inp.getAttribute('name') || 'no-name';
                  console.log('[airbnb-extract] Input ' + i + ': name="' + name + '"');
                });
                return { found: false, value: '' };
              }
            }
          });
          
          if (extractResult && extractResult[0] && extractResult[0].result && extractResult[0].result.found) {
            console.log(`[background] airbnbActivityId found on attempt ${extractRetryCount + 1}`);
            break;
          }
          
          extractRetryCount++;
          console.log(`[background] airbnbActivityId input not found, retrying... (${extractRetryCount}/${maxExtractRetries})`);
        }
        
        const airbnbActivityId = extractResult && extractResult[0] && extractResult[0].result && extractResult[0].result.found 
          ? extractResult[0].result.value 
          : '';
        console.log(`[background] Extracted airbnbActivityId: "${airbnbActivityId}"`);
        
        // Close the tab
        chrome.tabs.remove(tab.id);
        
        sendResponse({
          success: true,
          airbnbActivityId: airbnbActivityId
        });
      } catch (error) {
        console.error('[background] Error extracting airbnbActivityId:', error);
        sendResponse({
          success: false,
          error: error.message,
          airbnbActivityId: ''
        });
      }
    })();
    
    return true; // Keep message channel open for async response
  }

  // Handle scraping all Viator products
  if (message.action === 'scrapeAllViatorProducts') {
    const { productCodes, includeHeaderRow } = message;
    console.log(`[background] Received request to scrape ${productCodes.length} Viator products`);
    
    (async () => {
      try {
        const allResults = [];
        const seenTabSections = new Set();
        
        // Scrape each product sequentially
        for (let i = 0; i < productCodes.length; i++) {
          const productCode = productCodes[i];
          const url = `https://supplier.viator.com/product/${productCode}/productConnection`;
          
          console.log(`[background] Scraping product ${i + 1}/${productCodes.length} (product code: ${productCode})...`);
          
          try {
            // Create tab and wait for it to load
            const tab = await chrome.tabs.create({ url: url, active: false });
            
            // Wait for tab to complete loading
            await new Promise((resolve) => {
              const listener = (tabId, changeInfo) => {
                if (tabId === tab.id && changeInfo.status === 'complete') {
                  chrome.tabs.onUpdated.removeListener(listener);
                  // Wait a bit more for content to fully load
                  setTimeout(resolve, 2000);
                }
              };
              chrome.tabs.onUpdated.addListener(listener);
            });
            
            // Send message to scrape the product
            const response = await new Promise((resolve, reject) => {
              chrome.tabs.sendMessage(tab.id, {
                action: "runViatorProductsExtract",
                includeHeaderRow: false
              }, (response) => {
                if (chrome.runtime.lastError) {
                  reject(new Error(chrome.runtime.lastError.message));
                } else {
                  resolve(response);
                }
              });
            });
            
            // Close the tab
            chrome.tabs.remove(tab.id);
            
            // Process results
            if (response && response.success && response.data) {
              response.data.forEach(item => {
                // Use a combination of productCode and supplierProductCode as unique identifier
                const uniqueId = `${item.productCode}-${item.supplierProductCode || 'no-code'}`;
                if (!seenTabSections.has(uniqueId)) {
                  seenTabSections.add(uniqueId);
                  allResults.push(item);
                }
              });
            }
            
            console.log(`[background] Product ${i + 1} complete: ${allResults.length} total unique options so far`);
            
            // Small delay between products
            await new Promise(resolve => setTimeout(resolve, 1000));
          } catch (error) {
            console.error(`[background] Error scraping product ${productCode}:`, error);
            // Continue with next product
          }
        }
        
        console.log(`[background] Successfully extracted ${allResults.length} total unique options from ${productCodes.length} products`);
        
        // Format as TSV
        const formatAsTSV = (data, includeHeaderRow) => {
          if (!data || data.length === 0) return '';
          
          const tsvLines = [];
          if (includeHeaderRow) {
            const headers = ['Product Code', 'Product name', 'Supplier product code', 'Status', 'Supplier option code'];
            tsvLines.push(headers.join('\t'));
          }
          
          data.forEach(item => {
            const row = [
              item.productCode || '',
              item.productName || '',
              item.supplierProductCode || '',
              item.status || '',
              item.supplierOptionCode || ''
            ].map(field => {
              const str = String(field).trim();
              return str.replace(/[\t\n\r]/g, ' ');
            });
            tsvLines.push(row.join('\t'));
          });
          
          return tsvLines.join('\n');
        };
        
        const tsvData = formatAsTSV(allResults, includeHeaderRow);
        
        sendResponse({
          success: true,
          data: allResults,
          tsvData: tsvData,
          count: allResults.length,
          productCount: productCodes.length
        });
      } catch (error) {
        console.error('[background] Error scraping all Viator products:', error);
        sendResponse({
          success: false,
          error: error.message
        });
      }
    })();
    
    return true; // Keep message channel open for async response
  }

  // Open each Viator product in a background tab (no scraping, no closing)
  if (message.action === 'openViatorProductTabs') {
    const { productCodes } = message;
    if (!productCodes || !Array.isArray(productCodes) || productCodes.length === 0) {
      sendResponse({ success: false, error: 'No product codes to open.' });
      return true;
    }
    try {
      for (const code of productCodes) {
        const url = `https://supplier.viator.com/product/${code}/productConnection`;
        chrome.tabs.create({ url, active: false });
      }
      sendResponse({ success: true, tabsOpened: productCodes.length });
    } catch (error) {
      console.error('[background] Error opening Viator product tabs:', error);
      sendResponse({ success: false, error: error.message });
    }
    return true;
  }

  if (message.action === 'getResellerAppCompanyMap') {
    (async () => {
      try {
        const result = await ResellerAppCompanyMapService.getResellerAppCompanyMap({
          forceRefresh: message.forceRefresh === true
        });
        sendResponse(result);
      } catch (error) {
        sendResponse({
          success: false,
          error: error?.message || String(error)
        });
      }
    })();
    return true;
  }

  if (message.action === 'refreshResellerAppCompanyMap') {
    (async () => {
      try {
        const allowed = await FareHarborDeveloperAuth.requireActiveDevModeAsync(
          'refreshResellerAppCompanyMap'
        );
        if (!allowed) {
          sendResponse({
            success: false,
            error: 'Remote mapping refresh requires DEV mode'
          });
          return;
        }

        ResellerAppCompanyMapService.clearMemoryCache();
        const result = await ResellerAppCompanyMapService.getResellerAppCompanyMap({
          forceRefresh: true
        });
        sendResponse(result);
      } catch (error) {
        sendResponse({
          success: false,
          error: error?.message || String(error)
        });
      }
    })();
    return true;
  }
});




