console.log("[google-location-channel-items] script loaded");

(function googleLocationChannelItemsModule() {
  "use strict";

  const LOG_PREFIX = "[google-location-channel-items]";
  const COLUMN_ATTR = "data-fh-google-location-column";
  const ITEM_STATUS_COLUMN_ATTR = "data-fh-item-status-column";
  const RESELLER_ITEM_ID_ATTR = "data-fh-google-location-reseller-item-id";
  const HEADER_TEXT = "Location";
  const SETTING_KEY = "showGoogleMappingLocationColumn";
  const STYLE_ID = "fh-google-location-column-style";
  const SCAN_DEBOUNCE_MS = 150;
  const ROUTE_REEVAL_DELAY_MS = 150;
  const ROUTE_POLL_MS = 500;
  const RETRY_INTERVAL_MS = 500;
  const RETRY_MAX_MS = 10000;
  const MAX_CONCURRENCY = 5;
  const MISSING_TEXT = "No location available";
  const LOADING_TEXT = "Loading...";

  const CHANNEL_COMPANY_NUMERIC_RE =
    /^\/[^/]+\/dashboard\/settings\/integrations\/channels\/(\d+)\/?$/;
  const RESELLER_CHANNEL_ITEM_PATH_RE =
    /\/integrations\/channels\/(\d+)\/items\/(\d+)/;
  const ITEM_MAPPINGS_HEADER_RE = /^item\s*mappings$/i;
  const ITEM_STATUS_HEADER_RE = /^item\s*status$/i;

  const REQUIRED_HEADERS = [
    "Name",
    "SKU",
    "External Identifier",
    "Item Mappings",
    "Channel Customer Types",
    "Channel Options",
    "Last changed"
  ];

  const STYLE_TEXT = `
.fh-google-location {
  margin: 0;
  line-height: 1.4;
  font-size: inherit;
}
.fh-google-location--muted {
  color: #8c959f;
}
`.trim();

  let observer = null;
  let debounceTimer = null;
  let hrefPollTimer = null;
  let lifecycleEvalTimer = null;
  let retryTimer = null;
  let retryStartedAt = 0;
  let lastTrackedHref = location.href;
  let watchersActive = false;
  let routeWatchersStarted = false;
  let scanInProgress = false;
  let fetchGeneration = 0;
  let featureEnabled = true;

  /** @type {Map<string, string|null>} */
  const locationCache = new Map();
  /** @type {Map<string, Promise<string|null>>} */
  const inflightItemFetches = new Map();
  let lastAppliedState = {
    pageKey: null,
    itemIdSetKey: null,
    populated: false
  };
  /** @type {{ pageKey: string|null, isGoogle: boolean|null, inflight: Promise<boolean>|null }} */
  let googleEligibility = {
    pageKey: null,
    isGoogle: null,
    inflight: null
  };

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function warn(...args) {
    console.warn(LOG_PREFIX, ...args);
  }

  function parseNumericChannelCompanyPageContext(pathname) {
    const normalized = String(pathname || "").replace(/\/+$/, "");
    if (!normalized || /\/items\/\d+/.test(normalized)) {
      return null;
    }

    const numericMatch = normalized.match(CHANNEL_COMPANY_NUMERIC_RE);
    if (!numericMatch) {
      return null;
    }

    const parts = normalized.split("/").filter(Boolean);
    return {
      companyShortname: parts[0],
      channelId: numericMatch[1]
    };
  }

  function buildLocationCacheKey(companyShortname, channelId, resellerItemId) {
    return `${companyShortname}|${channelId}|${resellerItemId}`;
  }

  function extractResellerItemIdFromRow(row) {
    if (!row) {
      return null;
    }
    const links = row.querySelectorAll("a[href], a[ng-href]");
    for (const link of links) {
      const href = link.getAttribute("href") || link.getAttribute("ng-href") || "";
      const match = String(href).match(RESELLER_CHANNEL_ITEM_PATH_RE);
      if (match) {
        return match[2];
      }
    }
    return null;
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function parsePageContext() {
    return parseNumericChannelCompanyPageContext(location.pathname || "");
  }

  function isUrlEligible() {
    return isFareHarborHost() && !!parsePageContext();
  }

  function buildPageKey(ctx) {
    if (!ctx) {
      return null;
    }
    return `${ctx.companyShortname}|${ctx.channelId}`;
  }

  function buildItemIdSetKey(itemIds) {
    return [...new Set(itemIds)].sort().join("|");
  }

  function clearPageCaches() {
    locationCache.clear();
    inflightItemFetches.clear();
    googleEligibility = {
      pageKey: null,
      isGoogle: null,
      inflight: null
    };
    lastAppliedState = {
      pageKey: null,
      itemIdSetKey: null,
      populated: false
    };
  }

  /**
   * Google-only: reuse MappingCopyButton's reseller-company ota_type detection
   * (same path as Mapping Tools / Ticket Scanning Viator gate).
   */
  async function resolveIsGoogleChannelPage() {
    const ctx = parsePageContext();
    if (!ctx) {
      return false;
    }

    const pageKey = buildPageKey(ctx);
    if (
      googleEligibility.pageKey === pageKey &&
      typeof googleEligibility.isGoogle === "boolean"
    ) {
      return googleEligibility.isGoogle;
    }
    if (googleEligibility.pageKey === pageKey && googleEligibility.inflight) {
      return googleEligibility.inflight;
    }

    const promise = (async () => {
      const mapping = window.MappingCopyButton;
      if (
        !mapping?.fetchResellerCompany ||
        !mapping?.parseChannelCompanyListContext
      ) {
        warn("MappingCopyButton not available; Google Location column skipped");
        return false;
      }

      const listContext = mapping.parseChannelCompanyListContext();
      if (!listContext) {
        return false;
      }

      try {
        const result = await mapping.fetchResellerCompany(listContext);
        return Boolean(
          result?.ok && result.strategy?.affiliateKey === "google"
        );
      } catch (err) {
        warn("Google channel detection failed", String(err?.message || err));
        return false;
      }
    })();

    googleEligibility = { pageKey, isGoogle: null, inflight: promise };
    try {
      const isGoogle = await promise;
      if (googleEligibility.pageKey === pageKey) {
        googleEligibility = { pageKey, isGoogle, inflight: null };
      }
      return isGoogle;
    } catch (_err) {
      if (googleEligibility.pageKey === pageKey) {
        googleEligibility = { pageKey, isGoogle: false, inflight: null };
      }
      return false;
    }
  }

  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = STYLE_TEXT;
    (document.head || document.documentElement).appendChild(style);
  }

  function getRowCells(row) {
    return [...row.children].filter(
      (el) => el.tagName === "TD" || el.tagName === "TH"
    );
  }

  function normalizeCellText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function isChannelItemsTable(table) {
    const headerText = table.querySelector("thead")?.innerText || "";
    return REQUIRED_HEADERS.every((header) => headerText.includes(header));
  }

  function findChannelItemsTable(root) {
    const scope = root || document;
    const selectors = [
      'table[ng-if="resellerItems.length"]',
      'table[ng-table="resellerItems"]',
      'table[ng-controller*="ResellerItemsController"]',
      "table.reseller-items-table",
      'table.spreadsheet[ng-if="resellerItems.length"]',
      'table[ng-table*="resellerItems"]'
    ];

    for (const selector of selectors) {
      const table = scope.querySelector(selector);
      if (table && isChannelItemsTable(table)) {
        return table;
      }
    }

    const tables = scope.querySelectorAll("table");
    for (const table of tables) {
      if (!isChannelItemsTable(table)) {
        continue;
      }
      if (table.querySelector('tbody[ng-repeat*="resellerItem"]')) {
        return table;
      }
    }

    return null;
  }

  // Keep sibling extension columns (Item Status) for anchor placement; omit own.
  function getNativeRowCells(row) {
    return getRowCells(row).filter(
      (cell) => cell.getAttribute(COLUMN_ATTR) !== "true"
    );
  }

  function findItemMappingsIndex(cells) {
    return cells.findIndex((cell) =>
      ITEM_MAPPINGS_HEADER_RE.test(normalizeCellText(cell.textContent))
    );
  }

  function findItemStatusIndex(cells) {
    return cells.findIndex((cell) => {
      if (cell.getAttribute(ITEM_STATUS_COLUMN_ATTR) === "true") {
        return true;
      }
      return ITEM_STATUS_HEADER_RE.test(normalizeCellText(cell.textContent));
    });
  }

  function findInsertAnchorCell(cells) {
    const statusIdx = findItemStatusIndex(cells);
    if (statusIdx >= 0) {
      return cells[statusIdx];
    }
    const mappingsIdx = findItemMappingsIndex(cells);
    if (mappingsIdx >= 0) {
      return cells[mappingsIdx];
    }
    return null;
  }

  function isAnyExtensionColumnCell(el) {
    if (!(el instanceof Element)) {
      return false;
    }
    for (const attr of el.getAttributeNames()) {
      if (
        attr.startsWith("data-fh-") &&
        attr.endsWith("-column") &&
        el.getAttribute(attr) === "true"
      ) {
        return true;
      }
    }
    return false;
  }

  function isExtensionNode(node) {
    if (!(node instanceof Element)) {
      const parent = node?.parentElement;
      return parent ? isExtensionNode(parent) : false;
    }
    if (isAnyExtensionColumnCell(node)) {
      return true;
    }
    let parent = node.parentElement;
    while (parent) {
      if (isAnyExtensionColumnCell(parent)) {
        return true;
      }
      parent = parent.parentElement;
    }
    return false;
  }

  async function isDevModeActive() {
    try {
      if (typeof window.FareHarborDeveloperAuth?.isDevModeActiveAsync === "function") {
        return !!(await window.FareHarborDeveloperAuth.isDevModeActiveAsync());
      }
    } catch (_err) {
      // fall through
    }
    return false;
  }

  function devLog(...args) {
    console.log(LOG_PREFIX, "[dev]", ...args);
  }

  function isExtensionMutation(mutation) {
    if (isExtensionNode(mutation.target)) {
      return true;
    }
    for (const node of mutation.addedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    for (const node of mutation.removedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    return false;
  }

  function removeInjectedColumns() {
    document.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
      cell.remove();
    });
  }

  function applyFeatureSetting(enabled, reason) {
    featureEnabled = enabled !== false;
    if (!featureEnabled) {
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }
    evaluateLifecycle(reason || "setting-enabled");
  }

  function initSettingsBinding() {
    const settings = window.FHSettings;
    if (!settings) {
      return;
    }
    settings.get(SETTING_KEY, (value) => {
      applyFeatureSetting(value, "settings-init");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SETTING_KEY]) {
        applyFeatureSetting(changes[SETTING_KEY].newValue, "setting-change");
      }
    });
  }

  function createHeaderCell(referenceCell) {
    const tagName =
      referenceCell?.tagName === "TD" || referenceCell?.tagName === "td"
        ? "td"
        : "th";
    const cell = document.createElement(tagName);
    cell.setAttribute(COLUMN_ATTR, "true");
    cell.textContent = HEADER_TEXT;
    if (referenceCell?.className) {
      cell.className = referenceCell.className;
    }
    return cell;
  }

  function createLocationLine(label, muted) {
    const p = document.createElement("p");
    p.className = "fh-google-location";
    if (muted) {
      p.classList.add("fh-google-location--muted");
    }
    p.textContent = label;
    return p;
  }

  function renderLocationCell(cell, resellerItemId, ctx) {
    cell.replaceChildren();

    if (!resellerItemId || !ctx?.companyShortname || !ctx?.channelId) {
      cell.appendChild(createLocationLine(MISSING_TEXT, true));
      return;
    }

    const cacheKey = buildLocationCacheKey(
      ctx.companyShortname,
      ctx.channelId,
      resellerItemId
    );
    if (!locationCache.has(cacheKey)) {
      cell.appendChild(createLocationLine(LOADING_TEXT, true));
      return;
    }

    const displayName = locationCache.get(cacheKey);
    if (displayName) {
      cell.appendChild(createLocationLine(displayName, false));
      return;
    }
    cell.appendChild(createLocationLine(MISSING_TEXT, true));
  }

  function createBodyCell(resellerItemId, ctx) {
    const cell = document.createElement("td");
    cell.setAttribute(COLUMN_ATTR, "true");
    cell.className = "prose prose--compact";
    if (resellerItemId) {
      cell.setAttribute(RESELLER_ITEM_ID_ATTR, resellerItemId);
    }
    renderLocationCell(cell, resellerItemId, ctx);
    return cell;
  }

  function cellHasFinalValue(cell) {
    if (!cell) {
      return false;
    }
    const line = cell.querySelector(".fh-google-location");
    if (!line) {
      const text = (cell.textContent || "").trim();
      return text !== LOADING_TEXT && text !== "";
    }
    const text = (line.textContent || "").trim();
    return text !== LOADING_TEXT && text !== "";
  }

  function collectExistingDescriptors(table, ctx) {
    ensureStyles();
    const descriptors = [];
    const unmatchedIds = [];

    table.querySelectorAll("tbody tr").forEach((row) => {
      const cell = row.querySelector(`[${COLUMN_ATTR}="true"]`);
      if (!cell) {
        return;
      }
      const resellerItemId = extractResellerItemIdFromRow(row);
      if (resellerItemId) {
        cell.setAttribute(RESELLER_ITEM_ID_ATTR, resellerItemId);
        descriptors.push({ resellerItemId, cell });
      } else {
        cell.removeAttribute(RESELLER_ITEM_ID_ATTR);
        unmatchedIds.push("(no reseller-item link in row)");
      }
      renderLocationCell(cell, resellerItemId, ctx);
    });

    return { descriptors, unmatchedIds };
  }

  function normalizeColumn(table, ctx) {
    ensureStyles();
    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return {
        descriptors: [],
        unmatchedIds: [],
        headerInserted: 0,
        cellsInserted: 0,
        cellsRepositioned: 0
      };
    }

    let headerInserted = 0;
    let cellsInserted = 0;
    let cellsRepositioned = 0;
    const descriptors = [];
    const unmatchedIds = [];

    headerRow.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
      cell.remove();
      cellsRepositioned += 1;
    });

    const headerCells = getNativeRowCells(headerRow);
    const anchorHeader = findInsertAnchorCell(headerCells);
    if (!anchorHeader) {
      return {
        descriptors,
        unmatchedIds,
        headerInserted,
        cellsInserted,
        cellsRepositioned
      };
    }

    const headerCell = createHeaderCell(anchorHeader);
    headerRow.insertBefore(headerCell, anchorHeader.nextElementSibling);
    headerInserted = 1;

    const rows = table.querySelectorAll("tbody tr");
    rows.forEach((row) => {
      row.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
        cell.remove();
        cellsRepositioned += 1;
      });

      const rowCells = getNativeRowCells(row);
      const anchorCell = findInsertAnchorCell(rowCells);
      if (!anchorCell) {
        return;
      }

      const resellerItemId = extractResellerItemIdFromRow(row);
      const cell = createBodyCell(resellerItemId, ctx);
      row.insertBefore(cell, anchorCell.nextElementSibling);
      cellsInserted += 1;

      if (!resellerItemId) {
        unmatchedIds.push("(no reseller-item link in row)");
        return;
      }

      descriptors.push({ resellerItemId, cell });
    });

    return {
      descriptors,
      unmatchedIds,
      headerInserted,
      cellsInserted,
      cellsRepositioned
    };
  }

  function rowColumnCorrectlyPlaced(row) {
    const rowCells = getNativeRowCells(row);
    const anchorCell = findInsertAnchorCell(rowCells);
    if (!anchorCell) {
      return false;
    }

    const extensionCell = row.querySelector(`[${COLUMN_ATTR}="true"]`);
    if (!extensionCell) {
      return false;
    }

    return extensionCell.previousElementSibling === anchorCell;
  }

  function tableNeedsRepair(table) {
    if (!table) {
      return false;
    }

    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return true;
    }

    const headerCells = getNativeRowCells(headerRow);
    const anchorHeader = findInsertAnchorCell(headerCells);
    if (!anchorHeader) {
      return true;
    }

    const extensionHeaders = headerRow.querySelectorAll(
      `[${COLUMN_ATTR}="true"]`
    );
    if (extensionHeaders.length !== 1) {
      return true;
    }

    if (extensionHeaders[0].previousElementSibling !== anchorHeader) {
      return true;
    }

    for (const row of table.querySelectorAll("tbody tr")) {
      const extensionCells = row.querySelectorAll(`[${COLUMN_ATTR}="true"]`);
      if (extensionCells.length !== 1) {
        return true;
      }
      if (!rowColumnCorrectlyPlaced(row)) {
        return true;
      }
    }

    return false;
  }

  function collectUniqueResellerItemIds(descriptors) {
    const ids = [];
    const seen = new Set();
    for (const descriptor of descriptors) {
      const id = descriptor.resellerItemId;
      if (!id || seen.has(id)) {
        continue;
      }
      seen.add(id);
      ids.push(id);
    }
    return ids;
  }

  function allLocationCellsFinal(table) {
    const cells = [
      ...table.querySelectorAll(
        `tbody [${COLUMN_ATTR}="true"][${RESELLER_ITEM_ID_ATTR}]`
      )
    ];
    if (!cells.length) {
      return false;
    }
    return cells.every(cellHasFinalValue);
  }

  function populateCells(table, ctx) {
    table
      .querySelectorAll(
        `tbody [${COLUMN_ATTR}="true"][${RESELLER_ITEM_ID_ATTR}]`
      )
      .forEach((cell) => {
        if (cellHasFinalValue(cell)) {
          return;
        }
        const resellerItemId = cell.getAttribute(RESELLER_ITEM_ID_ATTR) || "";
        renderLocationCell(cell, resellerItemId, ctx);
      });
  }

  /**
   * Resolve display location via shared QCChecks helper (explicit primary_location
   * or company.default_item_primary_location → "Name (Dashboard Default)").
   */
  async function fetchResellerItemLocationDetail(ctx, resellerItemId) {
    const cacheKey = buildLocationCacheKey(
      ctx.companyShortname,
      ctx.channelId,
      resellerItemId
    );
    if (locationCache.has(cacheKey)) {
      return locationCache.get(cacheKey);
    }

    const inflight = inflightItemFetches.get(cacheKey);
    if (inflight) {
      return inflight;
    }

    const promise = (async () => {
      const resolve = window.QCChecks?.resolveGoogleResellerItemLocationInfo;
      if (typeof resolve !== "function") {
        log("QCChecks.resolveGoogleResellerItemLocationInfo unavailable");
        return null;
      }
      try {
        const result = await resolve(
          {
            shortname: ctx.companyShortname,
            resellerCompanyId: ctx.channelId,
            resellerItemId,
            itemId: null
          },
          { needPlaceId: false }
        );
        if (result?.displayName) {
          return result.displayName;
        }
        // Resolved successfully but no location — cache empty string sentinel as null.
        return null;
      } catch (err) {
        log("reseller item location resolve error", {
          resellerItemId,
          error: String(err?.message || err)
        });
        return null;
      }
    })();

    inflightItemFetches.set(cacheKey, promise);
    try {
      const displayName = await promise;
      locationCache.set(cacheKey, displayName);
      return displayName;
    } finally {
      if (inflightItemFetches.get(cacheKey) === promise) {
        inflightItemFetches.delete(cacheKey);
      }
    }
  }

  async function mapWithConcurrency(items, concurrency, fn) {
    if (!items.length) {
      return [];
    }
    const results = new Array(items.length);
    let nextIndex = 0;

    async function worker() {
      while (nextIndex < items.length) {
        const index = nextIndex;
        nextIndex += 1;
        results[index] = await fn(items[index], index);
      }
    }

    const workers = Array.from(
      { length: Math.min(concurrency, items.length) },
      () => worker()
    );
    await Promise.all(workers);
    return results;
  }

  /**
   * Resolve locations via shared helper (detail + company default fallback).
   * Company detail / default location are cached once per shortname inside QCChecks.
   */
  async function resolveLocations(ctx, resellerItemIds, onResolved, options = {}) {
    const dev = !!options.dev;
    const missing = resellerItemIds.filter((id) => {
      const cacheKey = buildLocationCacheKey(
        ctx.companyShortname,
        ctx.channelId,
        id
      );
      return !locationCache.has(cacheKey);
    });

    if (dev) {
      devLog("resolveLocations", {
        visibleResellerItemIds: resellerItemIds.length,
        alreadyCached: resellerItemIds.length - missing.length,
        detailFetchesNeeded: missing.length
      });
    }

    if (missing.length) {
      log("fetching reseller item locations", {
        company: ctx.companyShortname,
        channelId: ctx.channelId,
        itemCount: missing.length
      });
      await mapWithConcurrency(missing, MAX_CONCURRENCY, async (id) => {
        await fetchResellerItemLocationDetail(ctx, id);
        if (typeof onResolved === "function") {
          onResolved(id);
        }
      });
    }

    let withLocation = 0;
    let withDashboardDefault = 0;
    for (const id of resellerItemIds) {
      const cacheKey = buildLocationCacheKey(
        ctx.companyShortname,
        ctx.channelId,
        id
      );
      if (!locationCache.has(cacheKey)) {
        locationCache.set(cacheKey, null);
      }
      const displayName = locationCache.get(cacheKey);
      if (displayName) {
        withLocation += 1;
        if (String(displayName).includes("(Dashboard Default)")) {
          withDashboardDefault += 1;
        }
      }
    }

    if (dev) {
      const unmatched = resellerItemIds.filter((id) => {
        const cacheKey = buildLocationCacheKey(
          ctx.companyShortname,
          ctx.channelId,
          id
        );
        return !locationCache.get(cacheKey);
      });
      devLog("resolveLocations complete", {
        withLocationDisplay: withLocation,
        withDashboardDefaultSuffix: withDashboardDefault,
        withoutLocation: unmatched.length,
        withoutLocationIds: unmatched
      });
    }

    if (typeof onResolved === "function") {
      onResolved();
    }
  }

  function shouldFullySkipScan(ctx, descriptors, table) {
    if (!ctx || !descriptors.length || !table) {
      return false;
    }

    if (tableNeedsRepair(table)) {
      return false;
    }

    if (!allLocationCellsFinal(table)) {
      return false;
    }

    const pageKey = buildPageKey(ctx);
    const itemIdSetKey = buildItemIdSetKey(
      collectUniqueResellerItemIds(descriptors)
    );

    if (
      lastAppliedState.pageKey === pageKey &&
      lastAppliedState.itemIdSetKey === itemIdSetKey &&
      lastAppliedState.populated
    ) {
      return true;
    }

    return collectUniqueResellerItemIds(descriptors).every((id) =>
      locationCache.has(
        buildLocationCacheKey(ctx.companyShortname, ctx.channelId, id)
      )
    );
  }

  function descriptorsNeedFetch(ctx, descriptors) {
    if (!ctx || !descriptors.length) {
      return false;
    }
    return collectUniqueResellerItemIds(descriptors).some(
      (id) =>
        !locationCache.has(
          buildLocationCacheKey(ctx.companyShortname, ctx.channelId, id)
        )
    );
  }

  async function scanTable(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return false;
    }

    const isGoogle = await resolveIsGoogleChannelPage();
    if (!isGoogle) {
      removeInjectedColumns();
      return false;
    }

    const table = findChannelItemsTable(document);
    if (!table) {
      return false;
    }

    if (scanInProgress) {
      return false;
    }

    scanInProgress = true;
    const generation = ++fetchGeneration;
    let didWork = false;
    const dev = await isDevModeActive();

    try {
      const ctx = parsePageContext();
      const needsRepair = tableNeedsRepair(table);
      const normalizeResult = needsRepair
        ? normalizeColumn(table, ctx)
        : (() => {
            const existing = collectExistingDescriptors(table, ctx);
            return {
              descriptors: existing.descriptors,
              unmatchedIds: existing.unmatchedIds,
              headerInserted: 0,
              cellsInserted: 0,
              cellsRepositioned: 0
            };
          })();
      const {
        descriptors,
        unmatchedIds = [],
        headerInserted,
        cellsInserted,
        cellsRepositioned
      } = normalizeResult;

      const domChanged =
        headerInserted > 0 || cellsInserted > 0 || cellsRepositioned > 0;
      if (domChanged) {
        log("Google Location column normalized", {
          reason,
          rowCount: descriptors.length,
          headerInserted,
          cellsInserted,
          cellsRepositioned
        });
      }

      didWork = domChanged;

      // DEV logs only when DOM changed or on non-mutation triggers (avoid flood).
      if (
        dev &&
        (domChanged ||
          (reason !== "mutation-observer" && reason !== "debounced-scan"))
      ) {
        devLog("scan summary", {
          reason,
          domChanged,
          visibleTableRows: table.querySelectorAll("tbody tr").length,
          matchedResellerItemRows: descriptors.length,
          unmatchedRowCount: unmatchedIds.length,
          unmatched: unmatchedIds
        });
      }

      if (!ctx) {
        return didWork;
      }

      if (!descriptors.length) {
        lastAppliedState = {
          pageKey: buildPageKey(ctx),
          itemIdSetKey: "",
          populated: true
        };
        stopRetryLoop();
        return didWork;
      }

      const uniqueItemIds = collectUniqueResellerItemIds(descriptors);

      if (shouldFullySkipScan(ctx, descriptors, table)) {
        populateCells(table, ctx);
        return didWork;
      }

      populateCells(table, ctx);

      if (!descriptorsNeedFetch(ctx, descriptors)) {
        lastAppliedState = {
          pageKey: buildPageKey(ctx),
          itemIdSetKey: buildItemIdSetKey(uniqueItemIds),
          populated: allLocationCellsFinal(table)
        };
        if (lastAppliedState.populated) {
          stopRetryLoop();
        }
        return didWork;
      }

      await resolveLocations(
        ctx,
        uniqueItemIds,
        () => {
          if (generation !== fetchGeneration) {
            return;
          }
          populateCells(table, ctx);
        },
        { dev }
      );
      if (generation !== fetchGeneration) {
        return didWork;
      }

      populateCells(table, ctx);
      lastAppliedState = {
        pageKey: buildPageKey(ctx),
        itemIdSetKey: buildItemIdSetKey(uniqueItemIds),
        populated: allLocationCellsFinal(table)
      };

      if (lastAppliedState.populated) {
        stopRetryLoop();
      }

      return didWork;
    } finally {
      scanInProgress = false;
    }
  }

  function scheduleScan(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }
    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      scanTable(reason || "debounced-scan");
    }, SCAN_DEBOUNCE_MS);
  }

  function stopRetryLoop() {
    if (retryTimer) {
      clearInterval(retryTimer);
      retryTimer = null;
    }
    retryStartedAt = 0;
  }

  function startRetryLoop(reason) {
    if (!isUrlEligible()) {
      stopRetryLoop();
      return;
    }

    if (!retryTimer) {
      retryStartedAt = Date.now();
      retryTimer = setInterval(async () => {
        const elapsed = Date.now() - retryStartedAt;
        const found = await scanTable("retry-loop");
        if (found) {
          stopRetryLoop();
          return;
        }
        if (elapsed >= RETRY_MAX_MS) {
          stopRetryLoop();
        }
      }, RETRY_INTERVAL_MS);
    }

    scheduleScan(reason || "retry-schedule");
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    stopRetryLoop();
    clearPageCaches();
    fetchGeneration += 1;
    scanInProgress = false;
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  async function evaluateLifecycle(reason) {
    if (!featureEnabled) {
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }

    if (!isUrlEligible()) {
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }

    const isGoogle = await resolveIsGoogleChannelPage();
    if (!isGoogle) {
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }

    if (!watchersActive) {
      log("eligible Google page detected", { reason, href: location.href });
      startObserver();
      watchersActive = true;
    }

    startRetryLoop(reason || "lifecycle");
  }

  function onRouteChange(reason) {
    const nextHref = location.href;
    if (nextHref !== lastTrackedHref) {
      clearPageCaches();
      fetchGeneration += 1;
    }
    lastTrackedHref = nextHref;
    scheduleLifecycleEval(reason || "route-change");
  }

  function startRouteWatchers() {
    if (routeWatchersStarted) {
      return;
    }
    routeWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", () => onRouteChange("popstate"));
    window.addEventListener("hashchange", () => onRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        onRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        onRouteChange("replaceState");
        return result;
      };
    } catch (err) {
      log("history hook unavailable:", err);
    }

    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        onRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  function startObserver() {
    if (observer) {
      return;
    }

    observer = new MutationObserver((mutations) => {
      if (!isUrlEligible()) {
        return;
      }
      if (mutations.length > 0 && mutations.every(isExtensionMutation)) {
        return;
      }
      scheduleScan("mutation-observer");
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }

  function init() {
    if (!isFareHarborHost()) {
      return;
    }

    initSettingsBinding();
    startRouteWatchers();
    evaluateLifecycle("init");

    if (document.readyState === "loading") {
      document.addEventListener(
        "DOMContentLoaded",
        () => evaluateLifecycle("dom-content-loaded"),
        { once: true }
      );
    }
  }

  window.FareHarborGoogleLocationColumn = {
    extractResellerItemIdFromRow,
    buildLocationCacheKey,
    parseNumericChannelCompanyPageContext,
    findInsertAnchorCell,
    resolveIsGoogleChannelPage,
    MISSING_TEXT,
    LOADING_TEXT
  };

  init();
})();
