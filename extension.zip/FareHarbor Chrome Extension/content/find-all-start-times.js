console.log("[find-all-start-times] script loaded");

(function findAllStartTimesModule() {
  "use strict";

  const LOG_PREFIX = "[find-all-start-times]";
  const MAX_CONCURRENCY = 3;
  const TRANSIENT_RETRY_DELAY_MS = 400;
  const START_AT_RE = /^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})(?::\d{2})?/;
  const MONTH_NAMES = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];

  /** @type {ScanState} */
  let state = createIdleState();
  /** @type {Set<(snapshot: object) => void>} */
  const listeners = new Set();
  /** @type {AbortController[]} */
  let inflightControllers = [];
  let scanGeneration = 0;

  /**
   * @typedef {{ year: number, month: number, key: string, label: string }} MonthRef
   * @typedef {{
   *   status: 'idle'|'running'|'complete'|'partial'|'cancelled',
   *   companyShortname: string|null,
   *   itemId: string|null,
   *   startDate: string|null,
   *   endDate: string|null,
   *   months: MonthRef[],
   *   completedMonthKeys: string[],
   *   failedMonths: Array<{ key: string, year: number, month: number, label: string, error: string }>,
   *   availabilityCounts: Record<string, number>,
   *   seenAvailabilityKeys: Set<string>,
   *   authFailed: boolean,
   *   cancelRequested: boolean,
   *   isComplete: boolean,
   *   uniqueStartTimes: string[],
   *   monthsTotal: number,
   *   monthsCompleted: number
   * }} ScanState
   */

  function createIdleState() {
    return {
      status: "idle",
      companyShortname: null,
      itemId: null,
      startDate: null,
      endDate: null,
      months: [],
      completedMonthKeys: [],
      failedMonths: [],
      availabilityCounts: {},
      seenAvailabilityKeys: new Set(),
      authFailed: false,
      cancelRequested: false,
      isComplete: false,
      uniqueStartTimes: [],
      monthsTotal: 0,
      monthsCompleted: 0
    };
  }

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function warn(...args) {
    console.warn(LOG_PREFIX, ...args);
  }

  function pad2(n) {
    return String(n).padStart(2, "0");
  }

  function formatYmd(date) {
    return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
  }

  function parseYmd(ymd) {
    const m = String(ymd || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!m) return null;
    const year = Number(m[1]);
    const month = Number(m[2]);
    const day = Number(m[3]);
    if (month < 1 || month > 12 || day < 1 || day > 31) return null;
    return { year, month, day, ymd: `${m[1]}-${m[2]}-${m[3]}` };
  }

  function compareYmd(a, b) {
    if (a < b) return -1;
    if (a > b) return 1;
    return 0;
  }

  function defaultDateRange() {
    const today = new Date();
    const startDate = formatYmd(today);
    const endDate = `${today.getFullYear() + 1}-12-31`;
    return { startDate, endDate };
  }

  function monthLabel(year, month) {
    return `${MONTH_NAMES[month - 1]} ${year}`;
  }

  function monthKey(year, month) {
    return `${year}-${pad2(month)}`;
  }

  function buildMonthList(startDate, endDate) {
    const start = parseYmd(startDate);
    const end = parseYmd(endDate);
    if (!start || !end || compareYmd(start.ymd, end.ymd) > 0) {
      return [];
    }

    const months = [];
    let year = start.year;
    let month = start.month;
    const endYear = end.year;
    const endMonth = end.month;

    while (year < endYear || (year === endYear && month <= endMonth)) {
      months.push({
        year,
        month,
        key: monthKey(year, month),
        label: monthLabel(year, month)
      });
      month += 1;
      if (month > 12) {
        month = 1;
        year += 1;
      }
    }
    return months;
  }

  function buildCalendarUrl(companyShortname, itemId, year, month) {
    return (
      `/api/v1/companies/${encodeURIComponent(companyShortname)}/items/${encodeURIComponent(itemId)}` +
      `/item-calendar/${year}/${pad2(month)}/?path=2`
    );
  }

  function sleep(ms, signal) {
    return new Promise((resolve, reject) => {
      if (signal?.aborted) {
        reject(Object.assign(new Error("Aborted"), { name: "AbortError" }));
        return;
      }
      const timer = setTimeout(() => {
        if (signal) signal.removeEventListener("abort", onAbort);
        resolve();
      }, ms);
      function onAbort() {
        clearTimeout(timer);
        reject(Object.assign(new Error("Aborted"), { name: "AbortError" }));
      }
      if (signal) signal.addEventListener("abort", onAbort, { once: true });
    });
  }

  async function fhFetchJson(path, signal) {
    try {
      const response = await fetch(path, {
        method: "GET",
        credentials: "include",
        headers: { Accept: "application/json" },
        signal
      });

      if (!response.ok) {
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `API request failed with status ${response.status}`,
          isAuthFailure: response.status === 401 || response.status === 403
        };
      }

      try {
        const data = await response.json();
        return { ok: true, status: response.status, data, error: null, isAuthFailure: false };
      } catch (err) {
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `Response is not valid JSON: ${err.message}`,
          isAuthFailure: false
        };
      }
    } catch (err) {
      if (err?.name === "AbortError") {
        return {
          ok: false,
          status: null,
          data: null,
          error: "Aborted",
          isAuthFailure: false,
          aborted: true
        };
      }
      return {
        ok: false,
        status: null,
        data: null,
        error: `Fetch failed: ${err.message || String(err)}`,
        isAuthFailure: false
      };
    }
  }

  function extractStartTimeParts(startAt) {
    if (typeof startAt !== "string") return null;
    const match = startAt.match(START_AT_RE);
    if (!match) return null;
    return { date: match[1], time: match[2] };
  }

  function rebuildUniqueStartTimes() {
    state.uniqueStartTimes = Object.keys(state.availabilityCounts).sort((a, b) =>
      a < b ? -1 : a > b ? 1 : 0
    );
  }

  function recomputeDerivedFlags() {
    const completedSet = new Set(state.completedMonthKeys);
    const failedSet = new Set(state.failedMonths.map((m) => m.key));
    state.monthsCompleted = completedSet.size;
    state.monthsTotal = state.months.length;
    rebuildUniqueStartTimes();

    const allResolved = state.months.every(
      (m) => completedSet.has(m.key) || failedSet.has(m.key)
    );

    if (state.status === "running") {
      state.isComplete = false;
      return;
    }

    if (state.cancelRequested && state.status === "cancelled") {
      state.isComplete = false;
      return;
    }

    if (allResolved && failedSet.size === 0) {
      state.status = "complete";
      state.isComplete = true;
    } else if (allResolved && failedSet.size > 0) {
      state.status = "partial";
      state.isComplete = false;
    }
  }

  function getPublicSnapshot() {
    recomputeDerivedFlags();
    return {
      status: state.status,
      companyShortname: state.companyShortname,
      itemId: state.itemId,
      startDate: state.startDate,
      endDate: state.endDate,
      uniqueStartTimes: state.uniqueStartTimes.slice(),
      availabilityCounts: { ...state.availabilityCounts },
      completedMonths: state.completedMonthKeys.slice(),
      failedMonths: state.failedMonths.map((m) => ({ ...m })),
      isComplete: state.isComplete,
      monthsTotal: state.monthsTotal,
      monthsCompleted: state.monthsCompleted,
      authFailed: state.authFailed,
      cancelRequested: state.cancelRequested
    };
  }

  function notifyListeners() {
    const snapshot = getPublicSnapshot();
    listeners.forEach((listener) => {
      try {
        listener(snapshot);
      } catch (err) {
        warn("listener error", err);
      }
    });
  }

  function trackController(controller) {
    inflightControllers.push(controller);
  }

  function untrackController(controller) {
    inflightControllers = inflightControllers.filter((c) => c !== controller);
  }

  function abortInflight() {
    inflightControllers.forEach((controller) => {
      try {
        controller.abort();
      } catch (_) {
        /* ignore */
      }
    });
    inflightControllers = [];
  }

  function processCalendarPayload(data, companyShortname, itemId, startDate, endDate) {
    const weeks = data?.calendar?.weeks;
    if (!Array.isArray(weeks)) {
      return { ok: false, error: "Unexpected response structure: missing calendar.weeks" };
    }

    for (const week of weeks) {
      const days = week?.days;
      if (!Array.isArray(days)) continue;
      for (const day of days) {
        const availabilities = day?.availabilities;
        if (!Array.isArray(availabilities)) continue;
        for (const availability of availabilities) {
          const parts = extractStartTimeParts(availability?.start_at);
          if (!parts) continue;
          if (compareYmd(parts.date, startDate) < 0 || compareYmd(parts.date, endDate) > 0) {
            continue;
          }

          const time = parts.time;
          if (!(time in state.availabilityCounts)) {
            state.availabilityCounts[time] = 0;
          }

          const pk = availability?.pk;
          if (pk !== undefined && pk !== null && pk !== "") {
            const dedupeKey = `${companyShortname}|${itemId}|${pk}`;
            if (!state.seenAvailabilityKeys.has(dedupeKey)) {
              state.seenAvailabilityKeys.add(dedupeKey);
              state.availabilityCounts[time] += 1;
            }
          }
          // No usable ID: start time remains in availabilityCounts (possibly 0)
          // without incrementing occurrence counts.
        }
      }
    }

    return { ok: true };
  }

  async function fetchMonthOnce(monthRef, companyShortname, itemId, signal) {
    const path = buildCalendarUrl(companyShortname, itemId, monthRef.year, monthRef.month);
    return fhFetchJson(path, signal);
  }

  async function fetchMonthWithRetry(monthRef, companyShortname, itemId, generation) {
    const controller = new AbortController();
    trackController(controller);

    try {
      let result = await fetchMonthOnce(
        monthRef,
        companyShortname,
        itemId,
        controller.signal
      );

      if (generation !== scanGeneration || state.cancelRequested) {
        return { aborted: true };
      }

      if (result.aborted) {
        return { aborted: true };
      }

      if (result.isAuthFailure) {
        return {
          ok: false,
          error: result.error || "Authentication failed",
          isAuthFailure: true
        };
      }

      if (!result.ok) {
        // One automatic retry for transient failures only.
        try {
          await sleep(TRANSIENT_RETRY_DELAY_MS, controller.signal);
        } catch (_) {
          return { aborted: true };
        }
        if (generation !== scanGeneration || state.cancelRequested) {
          return { aborted: true };
        }

        result = await fetchMonthOnce(
          monthRef,
          companyShortname,
          itemId,
          controller.signal
        );

        if (result.aborted || generation !== scanGeneration || state.cancelRequested) {
          return { aborted: true };
        }
        if (result.isAuthFailure) {
          return {
            ok: false,
            error: result.error || "Authentication failed",
            isAuthFailure: true
          };
        }
        if (!result.ok) {
          return { ok: false, error: result.error || "Request failed", isAuthFailure: false };
        }
      }

      const processed = processCalendarPayload(
        result.data,
        companyShortname,
        itemId,
        state.startDate,
        state.endDate
      );
      if (!processed.ok) {
        return { ok: false, error: processed.error, isAuthFailure: false };
      }
      return { ok: true };
    } finally {
      untrackController(controller);
    }
  }

  async function runMonths(monthsToScan, generation) {
    const companyShortname = state.companyShortname;
    const itemId = state.itemId;
    let nextIndex = 0;
    let authStop = false;

    async function worker() {
      while (nextIndex < monthsToScan.length) {
        if (generation !== scanGeneration || state.cancelRequested || authStop) {
          return;
        }

        const index = nextIndex;
        nextIndex += 1;
        const monthRef = monthsToScan[index];

        // Skip months already completed in this scan session.
        if (state.completedMonthKeys.includes(monthRef.key)) {
          continue;
        }

        const result = await fetchMonthWithRetry(
          monthRef,
          companyShortname,
          itemId,
          generation
        );

        if (generation !== scanGeneration) {
          return;
        }

        if (result.aborted || state.cancelRequested) {
          return;
        }

        if (result.isAuthFailure) {
          state.authFailed = true;
          authStop = true;
          markMonthFailed(monthRef, result.error || "Authentication failed");
          // Mark remaining not-yet-started months as failed due to auth.
          for (let i = nextIndex; i < monthsToScan.length; i += 1) {
            const pending = monthsToScan[i];
            if (
              !state.completedMonthKeys.includes(pending.key) &&
              !state.failedMonths.some((f) => f.key === pending.key)
            ) {
              markMonthFailed(pending, "Skipped after authentication failure");
            }
          }
          notifyListeners();
          return;
        }

        if (result.ok) {
          if (!state.completedMonthKeys.includes(monthRef.key)) {
            state.completedMonthKeys.push(monthRef.key);
          }
          state.failedMonths = state.failedMonths.filter((f) => f.key !== monthRef.key);
        } else {
          markMonthFailed(monthRef, result.error || "Request failed");
        }

        notifyListeners();
      }
    }

    const workerCount = Math.min(MAX_CONCURRENCY, Math.max(monthsToScan.length, 1));
    await Promise.all(Array.from({ length: workerCount }, () => worker()));
  }

  function markMonthFailed(monthRef, error) {
    const existing = state.failedMonths.find((f) => f.key === monthRef.key);
    if (existing) {
      existing.error = error;
      return;
    }
    state.failedMonths.push({
      key: monthRef.key,
      year: monthRef.year,
      month: monthRef.month,
      label: monthRef.label,
      error: error
    });
  }

  function finalizeScan(generation) {
    if (generation !== scanGeneration) {
      return;
    }

    if (state.cancelRequested) {
      state.status = "cancelled";
      state.isComplete = false;
      // Months that were never completed and not already failed stay unlisted;
      // UI shows cancelled + partial retrieved results.
      notifyListeners();
      return;
    }

    const completedSet = new Set(state.completedMonthKeys);
    const failedSet = new Set(state.failedMonths.map((m) => m.key));
    const allResolved = state.months.every(
      (m) => completedSet.has(m.key) || failedSet.has(m.key)
    );

    if (allResolved && failedSet.size === 0) {
      state.status = "complete";
      state.isComplete = true;
    } else {
      state.status = "partial";
      state.isComplete = false;
    }
    notifyListeners();
  }

  function validateInputs(companyShortname, itemId) {
    const shortname = String(companyShortname || "").trim();
    const id = String(itemId || "").trim();
    if (!shortname) {
      return { ok: false, error: "Company shortname is required." };
    }
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(shortname)) {
      return { ok: false, error: "Company shortname format looks invalid." };
    }
    if (!/^\d+$/.test(id)) {
      return { ok: false, error: "Item ID must be a numeric FareHarbor item ID." };
    }
    return { ok: true, companyShortname: shortname, itemId: id };
  }

  async function startScan(options = {}) {
    const validated = validateInputs(options.companyShortname, options.itemId);
    if (!validated.ok) {
      return { ok: false, error: validated.error };
    }

    if (state.status === "running") {
      return { ok: false, error: "A scan is already running." };
    }

    const range =
      options.startDate && options.endDate
        ? { startDate: options.startDate, endDate: options.endDate }
        : defaultDateRange();

    if (!parseYmd(range.startDate) || !parseYmd(range.endDate)) {
      return { ok: false, error: "Invalid start or end date." };
    }
    if (compareYmd(range.startDate, range.endDate) > 0) {
      return { ok: false, error: "Start date must be on or before end date." };
    }

    const months = buildMonthList(range.startDate, range.endDate);
    if (!months.length) {
      return { ok: false, error: "No months to scan for the selected date range." };
    }

    abortInflight();
    scanGeneration += 1;
    const generation = scanGeneration;

    state = {
      status: "running",
      companyShortname: validated.companyShortname,
      itemId: validated.itemId,
      startDate: range.startDate,
      endDate: range.endDate,
      months,
      completedMonthKeys: [],
      failedMonths: [],
      availabilityCounts: {},
      seenAvailabilityKeys: new Set(),
      authFailed: false,
      cancelRequested: false,
      isComplete: false,
      uniqueStartTimes: [],
      monthsTotal: months.length,
      monthsCompleted: 0
    };

    notifyListeners();
    log("starting scan", {
      company: validated.companyShortname,
      itemId: validated.itemId,
      startDate: range.startDate,
      endDate: range.endDate,
      months: months.length
    });

    // Run asynchronously so callers get an immediate ack.
    Promise.resolve()
      .then(() => runMonths(months, generation))
      .then(() => finalizeScan(generation))
      .catch((err) => {
        warn("scan failed unexpectedly", err);
        if (generation === scanGeneration) {
          state.status = "partial";
          state.isComplete = false;
          notifyListeners();
        }
      });

    return { ok: true, state: getPublicSnapshot() };
  }

  function cancelScan() {
    if (state.status !== "running") {
      return { ok: false, error: "No scan is currently running.", state: getPublicSnapshot() };
    }
    state.cancelRequested = true;
    abortInflight();
    // finalizeScan will run when workers exit; also set cancelled promptly for UI.
    state.status = "cancelled";
    state.isComplete = false;
    notifyListeners();
    return { ok: true, state: getPublicSnapshot() };
  }

  async function retryFailedMonths() {
    if (state.status === "running") {
      return { ok: false, error: "A scan is already running." };
    }
    if (!state.companyShortname || !state.itemId) {
      return { ok: false, error: "No previous scan to retry." };
    }
    if (!state.failedMonths.length) {
      return { ok: false, error: "There are no failed months to retry." };
    }

    const monthsToRetry = state.failedMonths.map((f) => ({
      year: f.year,
      month: f.month,
      key: f.key,
      label: f.label
    }));

    const retryKeys = new Set(monthsToRetry.map((m) => m.key));
    state.failedMonths = state.failedMonths.filter((f) => !retryKeys.has(f.key));
    state.cancelRequested = false;
    state.authFailed = false;
    state.status = "running";
    state.isComplete = false;

    scanGeneration += 1;
    const generation = scanGeneration;
    notifyListeners();

    Promise.resolve()
      .then(() => runMonths(monthsToRetry, generation))
      .then(() => finalizeScan(generation))
      .catch((err) => {
        warn("retry failed unexpectedly", err);
        if (generation === scanGeneration) {
          state.status = "partial";
          state.isComplete = false;
          notifyListeners();
        }
      });

    return { ok: true, state: getPublicSnapshot() };
  }

  function getState() {
    return getPublicSnapshot();
  }

  function subscribe(listener) {
    if (typeof listener !== "function") {
      return () => {};
    }
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }

  function detectFromUrl(url) {
    try {
      const href = url || window.location.href;
      const u = new URL(href, window.location.origin);
      const parts = u.pathname.split("/").filter(Boolean);
      const companyShortname = parts[0] || null;

      let itemId = null;
      const overlay = u.searchParams.get("overlay");
      if (overlay) {
        const decoded = decodeURIComponent(overlay);
        const overlayItem = decoded.match(/\/items\/(\d+)/i);
        if (overlayItem) itemId = overlayItem[1];
      }
      if (!itemId) {
        const pathItem = u.pathname.match(/\/items\/(\d+)/);
        if (pathItem) itemId = pathItem[1];
      }

      return { companyShortname, itemId };
    } catch (_) {
      return { companyShortname: null, itemId: null };
    }
  }

  function formatDateDisplay(ymd) {
    const parsed = parseYmd(ymd);
    if (!parsed) return ymd || "—";
    return `${pad2(parsed.day)}/${pad2(parsed.month)}/${parsed.year}`;
  }

  function buildCopyStartTimesText(snapshot) {
    const snap = snapshot || getPublicSnapshot();
    return (snap.uniqueStartTimes || []).join("\n");
  }

  function buildCopyDetailedTsv(snapshot) {
    const snap = snapshot || getPublicSnapshot();
    const lines = ["Start Time\tAvailabilities"];
    for (const time of snap.uniqueStartTimes || []) {
      const count = snap.availabilityCounts?.[time] ?? 0;
      lines.push(`${time}\t${count}`);
    }
    return lines.join("\n");
  }

  window.FindAllStartTimes = {
    startScan,
    cancelScan,
    retryFailedMonths,
    getState,
    subscribe,
    detectFromUrl,
    formatDateDisplay,
    buildCopyStartTimesText,
    buildCopyDetailedTsv,
    defaultDateRange,
    buildMonthList,
    buildCalendarUrl,
    MAX_CONCURRENCY
  };
})();
