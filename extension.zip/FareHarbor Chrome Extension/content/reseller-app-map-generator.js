(function () {
  "use strict";

  const RESELLER_APP_MAP_LOG = "[reseller-app-map-generator]";
  const RESELLER_APPS_URL = "/api/v1/companies/admin/reseller-apps/";
  const MAX_CONCURRENCY = 4;
  const FORBIDDEN_OUTPUT_KEYS = new Set([
    "key",
    "calendar_token",
    "cookie",
    "token"
  ]);

  function normalizeMappingShortname(shortname) {
    return String(shortname || "").trim().toLowerCase();
  }

  function isNumericPk(value) {
    return typeof value === "number" && Number.isFinite(value);
  }

  function buildAppInactiveLookup(apps) {
    const lookup = new Map();
    for (const app of Array.isArray(apps) ? apps : []) {
      if (!isNumericPk(app?.pk)) {
        continue;
      }
      lookup.set(app.pk, app.is_inactive === true);
    }
    return lookup;
  }

  function buildResellerAppCompanyMap({ apps, relationshipsByPk, failedApps }) {
    const appInactiveLookup = buildAppInactiveLookup(apps);
    const shortnameToPks = new Map();
    let relationshipsFound = 0;

    for (const [parentPk, relationships] of Object.entries(
      relationshipsByPk || {}
    )) {
      const parentPkNumber = Number(parentPk);
      if (!Number.isFinite(parentPkNumber)) {
        continue;
      }

      for (const relationship of Array.isArray(relationships) ? relationships : []) {
        const shortname = normalizeMappingShortname(
          relationship?.company?.shortname
        );
        if (!shortname) {
          continue;
        }

        const relationshipPk = relationship?.reseller_app?.pk;
        const pk = isNumericPk(relationshipPk) ? relationshipPk : parentPkNumber;
        if (!isNumericPk(pk)) {
          continue;
        }

        if (!shortnameToPks.has(shortname)) {
          shortnameToPks.set(shortname, new Set());
        }
        shortnameToPks.get(shortname).add(pk);
        relationshipsFound += 1;
      }
    }

    const mapping = {};
    const duplicates = {};
    const inactiveOnly = {};

    for (const [shortname, pkSet] of shortnameToPks.entries()) {
      const pks = Array.from(pkSet).sort((a, b) => a - b);
      if (pks.length > 1) {
        duplicates[shortname] = pks;
        continue;
      }

      const pk = pks[0];
      const isInactive = appInactiveLookup.get(pk) === true;
      if (isInactive) {
        inactiveOnly[shortname] = [pk];
      } else {
        mapping[shortname] = pk;
      }
    }

    const appList = Array.isArray(apps) ? apps : [];
    const activeAppsScanned = appList.filter(
      (app) => isNumericPk(app?.pk) && app.is_inactive !== true
    ).length;
    const inactiveAppsScanned = appList.filter(
      (app) => isNumericPk(app?.pk) && app.is_inactive === true
    ).length;
    const failedAppList = Array.isArray(failedApps) ? failedApps : [];

    return {
      schemaVersion: 1,
      generatedAt: new Date().toISOString(),
      mapping,
      duplicates,
      inactiveOnly,
      failedApps: failedAppList,
      stats: {
        appsScanned: appList.filter((app) => isNumericPk(app?.pk)).length,
        activeAppsScanned,
        inactiveAppsScanned,
        relationshipsFound,
        uniqueCompanies: shortnameToPks.size,
        duplicatesFound: Object.keys(duplicates).length,
        failedApps: failedAppList.length
      }
    };
  }

  function collectForbiddenKeys(value, path, found) {
    if (!value || typeof value !== "object") {
      return;
    }

    if (Array.isArray(value)) {
      value.forEach((item, index) => {
        collectForbiddenKeys(item, `${path}[${index}]`, found);
      });
      return;
    }

    for (const [key, nestedValue] of Object.entries(value)) {
      if (FORBIDDEN_OUTPUT_KEYS.has(key)) {
        found.push(path ? `${path}.${key}` : key);
      }
      collectForbiddenKeys(nestedValue, path ? `${path}.${key}` : key, found);
    }
  }

  function sanitizeGeneratedMapForDownload(map) {
    const source = map && typeof map === "object" ? map : {};
    const sanitized = {
      schemaVersion: 1,
      generatedAt:
        typeof source.generatedAt === "string" ? source.generatedAt : null,
      mapping:
        source.mapping && typeof source.mapping === "object"
          ? { ...source.mapping }
          : {},
      duplicates:
        source.duplicates && typeof source.duplicates === "object"
          ? { ...source.duplicates }
          : {},
      inactiveOnly:
        source.inactiveOnly && typeof source.inactiveOnly === "object"
          ? { ...source.inactiveOnly }
          : {},
      failedApps: Array.isArray(source.failedApps)
        ? source.failedApps.map((entry) => ({
            pk: entry?.pk ?? null,
            status: entry?.status ?? null
          }))
        : [],
      stats:
        source.stats && typeof source.stats === "object"
          ? { ...source.stats }
          : {}
    };

    const forbidden = [];
    collectForbiddenKeys(sanitized, "", forbidden);
    if (forbidden.length > 0) {
      throw new Error(
        `Generated map contains forbidden fields: ${forbidden.join(", ")}`
      );
    }

    return sanitized;
  }

  function formatCount(value) {
    return Number(value || 0).toLocaleString("en-US");
  }

  async function runWorkerPool(items, worker, concurrency, isCancelled) {
    const results = new Array(items.length);
    let nextIndex = 0;

    async function runWorkerSlot() {
      while (true) {
        if (typeof isCancelled === "function" && isCancelled()) {
          return;
        }

        const currentIndex = nextIndex;
        nextIndex += 1;
        if (currentIndex >= items.length) {
          return;
        }

        results[currentIndex] = await worker(items[currentIndex], currentIndex);
      }
    }

    const workerCount = Math.min(
      Math.max(1, concurrency),
      Math.max(1, items.length)
    );
    await Promise.all(
      Array.from({ length: workerCount }, () => runWorkerSlot())
    );
    return results;
  }

  function reportProgress(onProgress, message) {
    if (typeof onProgress === "function") {
      onProgress(message);
    }
  }

  async function fetchResellerAppCompanies(apiGetJson, appPk) {
    const url = `/api/v1/companies/admin/reseller-apps/${encodeURIComponent(
      String(appPk)
    )}/reseller-app-companies/`;
    const result = await apiGetJson(url);
    if (!result.ok) {
      return {
        ok: false,
        status: result.status ?? null,
        relationships: null
      };
    }

    const relationships = result.data?.reseller_app_companies;
    if (!Array.isArray(relationships)) {
      return {
        ok: false,
        status: result.status ?? null,
        relationships: null
      };
    }

    return {
      ok: true,
      status: result.status ?? null,
      relationships
    };
  }

  async function generateResellerAppCompanyMap({
    apiGetJson,
    onProgress,
    isCancelled
  } = {}) {
    if (typeof apiGetJson !== "function") {
      throw new Error("apiGetJson is required");
    }

    reportProgress(onProgress, "Loading reseller apps…");
    console.log(RESELLER_APP_MAP_LOG, "loading reseller apps");

    const appsResult = await apiGetJson(RESELLER_APPS_URL);
    if (!appsResult.ok) {
      const status = appsResult.status ?? null;
      console.log(RESELLER_APP_MAP_LOG, "reseller apps failed", { status });
      if (status === 401 || status === 403) {
        throw new Error(
          "Permission denied loading reseller apps. Ensure you are logged in with admin access."
        );
      }
      throw new Error(
        appsResult.error || "Unable to load reseller apps catalog"
      );
    }

    const apps = (Array.isArray(appsResult.data?.reseller_apps)
      ? appsResult.data.reseller_apps
      : []
    ).filter((app) => isNumericPk(app?.pk));

    const inactiveCount = apps.filter((app) => app.is_inactive === true).length;
    console.log(RESELLER_APP_MAP_LOG, "reseller apps loaded", {
      appsScanned: apps.length,
      inactiveAppsScanned: inactiveCount
    });

    const relationshipsByPk = {};
    const failedApps = [];
    let relationshipsFound = 0;
    const totalApps = apps.length;

    await runWorkerPool(
      apps,
      async (app, index) => {
        if (typeof isCancelled === "function" && isCancelled()) {
          return;
        }

        reportProgress(
          onProgress,
          `Scanning app ${index + 1} of ${totalApps}…`
        );

        const result = await fetchResellerAppCompanies(apiGetJson, app.pk);
        if (!result.ok) {
          failedApps.push({
            pk: app.pk,
            status: result.status
          });
          console.log(RESELLER_APP_MAP_LOG, "relationship request failed", {
            pk: app.pk,
            status: result.status
          });
          return;
        }

        relationshipsByPk[app.pk] = result.relationships;
        relationshipsFound += result.relationships.length;
        reportProgress(
          onProgress,
          `Found ${formatCount(relationshipsFound)} relationships…`
        );
        console.log(RESELLER_APP_MAP_LOG, "relationships loaded", {
          pk: app.pk,
          relationshipCount: result.relationships.length,
          relationshipsFound
        });
      },
      MAX_CONCURRENCY,
      isCancelled
    );

    const built = buildResellerAppCompanyMap({
      apps,
      relationshipsByPk,
      failedApps
    });
    const map = sanitizeGeneratedMapForDownload(built);

    reportProgress(onProgress, "Complete");
    console.log(RESELLER_APP_MAP_LOG, "generation complete", map.stats);

    return map;
  }

  window.FareHarborResellerAppMapGenerator = {
    RESELLER_APP_MAP_LOG,
    normalizeMappingShortname,
    buildResellerAppCompanyMap,
    sanitizeGeneratedMapForDownload,
    generateResellerAppCompanyMap
  };
})();
