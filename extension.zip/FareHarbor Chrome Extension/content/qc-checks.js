console.log("[qc-checks] qc-checks.js loaded");

(function initializeQCChecks() {
  if (!window.FareHarborUtils) {
    setTimeout(initializeQCChecks, 10);
    return;
  }

  const CHECK_DEFAULT_API = {
    key: "default_api_cancellation_policy",
    label: "Default - API Cancellation Policy"
  };

  const CHECK_DEFAULT_API_RULES = {
    key: "default_api_cancellation_policy_rules",
    label: "Default - API Cancellation Policy Rules",
    category: "Policies",
    severity: "critical"
  };

  const CHECK_ENABLE_API_BOOKING_CREATION = {
    key: "enable_api_booking_creation",
    label: "Enable API Booking Creation",
    category: "API",
    severity: "critical"
  };

  const CHECK_ALLOW_API_BOOKINGS_API_FEE = {
    key: "allow_api_bookings_to_be_charged_api_fee",
    label: "Allow API Bookings to be charged an API fee",
    category: "API",
    severity: "critical"
  };

  const CHECK_API_FEE_RATE = {
    key: "api_fee_rate",
    label: "API Fee",
    category: "API",
    severity: "critical"
  };

  const CHECK_BILLING_METHOD_ADDED = {
    key: "billing_method_added",
    label: "Billing Method Added",
    category: "Payments",
    severity: "critical"
  };

  const CHECK_AFFILIATE_API_PERMISSION_GROUP = {
    key: "affiliate_api_permission_group_exists",
    label: "Affiliate - API Permission Group Exists",
    category: "Permissions",
    severity: "critical"
  };

  const CHECK_AFFILIATE_API_PERMISSION_GROUP_PERMISSIONS = {
    key: "affiliate_api_permission_group_permissions",
    label: "Affiliate - API Permission Group Permissions",
    category: "Permissions",
    severity: "critical"
  };

  const CHECK_VIATOR_INVOICE_PRICING_ZERO_COMMISSION_WARNING = {
    key: "viator_invoice_pricing_zero_commission_warning",
    label: "Viator Invoice Pricing 0% Warning",
    category: "Affiliates",
    severity: "warning"
  };

  const CHECK_VIATOR_PRICING_SHEET_ASSIGNMENT_WARNING = {
    key: "viator_pricing_sheet_assignment_warning",
    label: "Viator Pricing Sheet Assignment Warning",
    category: "Affiliates",
    severity: "warning"
  };

  const CHECK_GYG_GROUP_TICKET_CATEGORY = {
    key: "gyg_group_ticket_category_mapping",
    label: "GetYourGuide Group Ticket Category Mapping",
    category: "Integrations",
    severity: "warning"
  };

  const CHECK_TRANSPORTATION_MAPPING = {
    key: "transportation_mapping",
    label: "Transportation Mapping",
    category: "Bookings",
    severity: "warning"
  };

  const CHECK_GOOGLE_LOCATIONS = {
    key: "google_locations",
    label: "Google Locations",
    category: "Affiliates",
    severity: "critical"
  };

  const TRANSPORTATION_SETTING_LABEL = "transportation";
  const MAP_TRANSPORTATION_CUSTOM_FIELDS_LABEL = "map to transportation custom fields";

  const GYG_CHANNEL_PATH_RE = /\/integrations\/channels\/(?:getyourguide|gyg)(?:\/|$)/i;
  const GYG_RESELLER_ITEM_IDS_RE = /\/reseller-companies\/(\d+)\/reseller-items\/(\d+)/;
  const GYG_GROUP_CONCURRENCY_LIMIT = 5;
  const GOOGLE_CHANNEL_PATH_RE = /\/integrations\/channels\/google(?:\/|$)/i;
  const GOOGLE_CHANNEL_NUMERIC_PATH_RE = /\/integrations\/channels\/(\d+)\/items\/(\d+)/;
  const GOOGLE_PLACE_ID_RE = /^ChIJ[A-Za-z0-9_-]{20,35}$/;
  const GOOGLE_LOCATIONS_CONCURRENCY_LIMIT = 5;
  const DEV_MODE_STORAGE_KEY = FareHarborDeveloperAuth.DEV_MODE_STORAGE_KEY;

  let gygDevModeEnabled = false;

  function gygDevLog(...args) {
    if (gygDevModeEnabled) {
      console.log(...args);
    }
  }

  function gygDevWarn(...args) {
    if (gygDevModeEnabled) {
      console.warn(...args);
    }
  }

  function isDevModeEnabledAsync() {
    return FareHarborDeveloperAuth.isDevModeActiveAsync();
  }

  async function mapWithConcurrency(items, concurrency, fn) {
    const results = new Array(items.length);
    let nextIndex = 0;

    async function worker() {
      while (nextIndex < items.length) {
        const index = nextIndex;
        nextIndex += 1;
        results[index] = await fn(items[index], index);
      }
    }

    const workers = Array.from({ length: Math.min(concurrency, items.length) }, () => worker());
    await Promise.all(workers);
    return results;
  }

  function initGygGroupPerf() {
    qcRunCache.gygGroupPerfTracking = true;
    qcRunCache.gygGroupPerf = {
      groupMappingsFound: 0,
      itemIdsSeen: new Set(),
      prototypePksSeen: new Set(),
      customFieldPksSeen: new Set(),
      baseSheetFieldPricingRequestKeys: new Set(),
      sheetFieldPricingCacheHits: 0,
      sheetFieldPricingInFlightHits: 0,
      baseSheetPk: null,
      baseSheetIdentificationSource: null,
      usingBaseSheetOnly: false,
      skippedNonBaseSheetsCount: 0,
      networkRequests: 0
    };
  }

  function trackGygPrototypeChecked(prototypePk) {
    if (qcRunCache.gygGroupPerf?.prototypePksSeen && prototypePk != null) {
      qcRunCache.gygGroupPerf.prototypePksSeen.add(String(prototypePk));
    }
  }

  function trackGygCustomFieldsFound(customFields) {
    if (!qcRunCache.gygGroupPerf?.customFieldPksSeen) {
      return;
    }
    for (const field of customFields) {
      if (field?.pk != null) {
        qcRunCache.gygGroupPerf.customFieldPksSeen.add(String(field.pk));
      }
    }
  }

  function trackGygNetworkRequest() {
    if (qcRunCache.gygGroupPerfTracking && qcRunCache.gygGroupPerf) {
      qcRunCache.gygGroupPerf.networkRequests += 1;
    }
  }

  async function gygApiGetJson(url) {
    trackGygNetworkRequest();
    return apiGetJson(url);
  }

  function logGygGroupPerfSummary(startedAt) {
    if (!gygDevModeEnabled || !qcRunCache.gygGroupPerf) {
      return;
    }
    const perf = qcRunCache.gygGroupPerf;
    gygDevLog("[qc-checks] GYG Group mapping perf:", {
      groupMappingsFound: perf.groupMappingsFound ?? 0,
      uniqueItemsChecked: perf.itemIdsSeen?.size ?? 0,
      uniquePrototypesChecked: perf.prototypePksSeen?.size ?? 0,
      uniqueCustomFieldsFound: perf.customFieldPksSeen?.size ?? 0,
      baseSheetPk: perf.baseSheetPk ?? null,
      baseSheetIdentificationSource: perf.baseSheetIdentificationSource ?? null,
      usingBaseSheetOnly: perf.usingBaseSheetOnly === true,
      baseSheetFieldPricingRequests: perf.baseSheetFieldPricingRequestKeys?.size ?? 0,
      sheetFieldPricingCacheHits: perf.sheetFieldPricingCacheHits ?? 0,
      sheetFieldPricingInFlightHits: perf.sheetFieldPricingInFlightHits ?? 0,
      skippedNonBaseSheetsCount: perf.skippedNonBaseSheetsCount ?? 0,
      networkRequests: perf.networkRequests ?? 0,
      durationMs: Date.now() - startedAt
    });
  }

  function trackGygGroupMappingFound(itemId) {
    if (!qcRunCache.gygGroupPerf) {
      return;
    }
    qcRunCache.gygGroupPerf.groupMappingsFound += 1;
    if (itemId != null && qcRunCache.gygGroupPerf.itemIdsSeen) {
      qcRunCache.gygGroupPerf.itemIdsSeen.add(String(itemId));
    }
  }

  function getGygResellerItemCacheKey(ctx) {
    return `${ctx.shortname}:${ctx.resellerCompanyId}:${ctx.resellerItemId}`;
  }

  function getCustomerPrototypesCacheKey(shortname, itemId) {
    return `${shortname}:${itemId}`;
  }

  const API_BOOKING_CHECKBOX_SELECTOR = "#id_company_features-is_opted_in_for_api_booking_fees";
  const API_FEE_CHARGEABLE_SELECTOR = "#id_company_features-is_api_fee_chargeable_for_bookings";
  const API_INVOICE_FEE_RATE_SELECTOR = "#id_features-api_invoice_fee_rate";
  const API_FEE_RATE_TOLERANCE = 0.000001;

  const EXPECTED_CANCELLATION_RULES = [
    { hours: 48, charter_refund_percentage: 1.0, affiliate_refund_percentage: 1.0 },
    { hours: 0, charter_refund_percentage: 0.0, affiliate_refund_percentage: 0.0 }
  ];

  const DEFAULT_API_POLICY_NAME = "Default - API";
  const DEFAULT_API_POLICY_NAME_NORMALIZED = "default api";
  const AFFILIATE_API_GROUP_NAME = "Affiliate - API";

  function normalizeCancellationPolicyNameForMatch(value) {
    if (typeof value !== "string") {
      return null;
    }
    const normalized = value
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    return normalized !== "" ? normalized : null;
  }

  function isDefaultApiCancellationPolicyName(name) {
    return normalizeCancellationPolicyNameForMatch(name) === DEFAULT_API_POLICY_NAME_NORMALIZED;
  }

  function findDefaultApiCancellationPolicy(policies) {
    if (!Array.isArray(policies)) {
      return null;
    }
    return policies.find((p) => isDefaultApiCancellationPolicyName(p?.name)) || null;
  }

  let qcRunCache = {};

  function formatAffiliateSettingActual(value) {
    if (value === null || value === undefined) {
      return "null";
    }
    if (value === "") {
      return "empty";
    }
    return String(value);
  }

  function getSheetDisplayName(sheet) {
    if (!sheet || typeof sheet !== "object") {
      return null;
    }
    const name = sheet.display_name ?? sheet.displayName ?? sheet.name ?? null;
    if (typeof name !== "string") {
      return null;
    }
    const trimmed = name.trim();
    return trimmed !== "" ? trimmed : null;
  }

  function getPricingObjectDisplayName(pricingObject) {
    if (!pricingObject || typeof pricingObject !== "object") {
      return null;
    }
    const name =
      pricingObject.display_name ??
      pricingObject.displayName ??
      pricingObject.name ??
      pricingObject.unicode ??
      null;
    if (typeof name !== "string") {
      return null;
    }
    const trimmed = name.trim();
    return trimmed !== "" ? trimmed : null;
  }

  function getPricingObjectDisplayNameForWarning(pricingObject) {
    if (!pricingObject || typeof pricingObject !== "object") {
      return null;
    }
    const name = pricingObject.display_name ?? pricingObject.displayName ?? pricingObject.name ?? null;
    if (typeof name !== "string") {
      return null;
    }
    const trimmed = name.trim();
    return trimmed !== "" ? trimmed : null;
  }

  function formatPricingLine(name, typeLabel) {
    return `${name} (${typeLabel})`;
  }

  function collectSelectedPricingLines({
    selectedTotalSheet,
    selectedTotalSchedule,
    selectedInvoiceSheet,
    resolutionSources
  }) {
    const lines = [];

    if (selectedTotalSheet) {
      const totalSheetName = resolvePricingObjectDisplayName(selectedTotalSheet, resolutionSources);
      if (totalSheetName) {
        lines.push(formatPricingLine(totalSheetName, "Total Sheet"));
      }
    }

    if (selectedTotalSchedule) {
      const totalScheduleName = resolvePricingObjectDisplayName(selectedTotalSchedule, resolutionSources);
      if (totalScheduleName) {
        lines.push(formatPricingLine(totalScheduleName, "Total Schedule"));
      }
    }

    if (selectedInvoiceSheet) {
      const invoiceSheetName = resolvePricingObjectDisplayName(selectedInvoiceSheet, resolutionSources);
      if (invoiceSheetName) {
        lines.push(formatPricingLine(invoiceSheetName, "Invoice Sheet"));
      }
    }

    return lines;
  }

  function buildOtaPricingAssignmentWarningDetails({ otaLabel, selectedLines, availableLines }) {
    const label = typeof otaLabel === "string" && otaLabel.trim() !== "" ? otaLabel.trim() : "OTA";
    const normalizedSelectedLines = Array.isArray(selectedLines) ? selectedLines : [];
    const normalizedAvailableLines = Array.isArray(availableLines) ? availableLines : [];

    const sections = [
      `A ${label}-specific pricing configuration exists but is not assigned to the ${label} affiliate.`,
      `Selected pricing:\n${normalizedSelectedLines.length > 0 ? normalizedSelectedLines.join("\n") : "None assigned"}`
    ];

    if (normalizedAvailableLines.length > 0) {
      sections.push(`Available pricing:\n${normalizedAvailableLines.join("\n")}`);
    }

    return sections.join("\n\n");
  }

  function sheetsMatch(referenceSheet, candidateSheet) {
    if (
      !referenceSheet ||
      !candidateSheet ||
      typeof referenceSheet !== "object" ||
      typeof candidateSheet !== "object"
    ) {
      return false;
    }

    const referenceUri = referenceSheet.uri ?? null;
    const candidateUri = candidateSheet.uri ?? null;
    if (referenceUri && candidateUri && referenceUri === candidateUri) {
      return true;
    }

    const referencePk = referenceSheet.pk ?? null;
    const candidatePk = candidateSheet.pk ?? null;
    if (referencePk != null && candidatePk != null && referencePk === candidatePk) {
      return true;
    }

    return false;
  }

  function pricingObjectsMatch(referenceObject, candidateObject) {
    if (
      !referenceObject ||
      !candidateObject ||
      typeof referenceObject !== "object" ||
      typeof candidateObject !== "object"
    ) {
      return false;
    }

    const referencePk = referenceObject.pk ?? null;
    const candidatePk = candidateObject.pk ?? null;
    if (referencePk != null && candidatePk != null) {
      return referencePk === candidatePk;
    }

    const referenceUri = referenceObject.uri ?? null;
    const candidateUri = candidateObject.uri ?? null;
    if (referenceUri && candidateUri) {
      return referenceUri === candidateUri;
    }

    return false;
  }

  function stringifyPricingObject(pricingObject) {
    if (!pricingObject || typeof pricingObject !== "object") {
      return null;
    }
    return {
      pk: pricingObject.pk ?? null,
      uri: pricingObject.uri ?? null,
      name: getPricingObjectDisplayName(pricingObject)
    };
  }

  function normalizePricingNameForMatch(value) {
    if (typeof value !== "string") {
      return null;
    }
    const normalized = value
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "");
    return normalized !== "" ? normalized : null;
  }

  function isAcceptedAirbnbPricingName(name) {
    const normalized = normalizePricingNameForMatch(name);
    return (
      normalized !== null &&
      (normalized.includes("online") || normalized.includes("airbnb"))
    );
  }

  const OTA_PRICING_ASSIGNMENT_CONFIG = {
    viator: { keywords: ["viator", "tripadvisor"], excludeFromAvailable: ["direct"] },
    airbnb: { keywords: ["online"], excludeFromAvailable: ["direct"] },
    expedia: { keywords: ["expedia"], excludeFromAvailable: ["direct"] },
    getyourguide: { keywords: ["getyourguide", "gyg"], excludeFromAvailable: ["direct"] },
    google: { keywords: ["google"], excludeFromAvailable: ["online"] }
  };

  function getOtaPricingAssignmentConfig(integrationKey) {
    return OTA_PRICING_ASSIGNMENT_CONFIG[integrationKey] ?? null;
  }

  function nameMatchesOtaKeywords(name, keywords) {
    const normalized = normalizePricingNameForMatch(name);
    if (!normalized || !Array.isArray(keywords)) {
      return false;
    }
    return keywords.some((keyword) => normalized.includes(keyword));
  }

  function isExcludedGenericPricingName(name, integrationKey) {
    const config = getOtaPricingAssignmentConfig(integrationKey);
    if (!config || !Array.isArray(config.excludeFromAvailable)) {
      return false;
    }
    const normalized = normalizePricingNameForMatch(name);
    if (!normalized) {
      return false;
    }
    return config.excludeFromAvailable.some((excluded) => normalized === excluded);
  }

  function isOtaSpecificPricingName(name, integrationKey) {
    const config = getOtaPricingAssignmentConfig(integrationKey);
    if (!config) {
      return false;
    }
    if (isExcludedGenericPricingName(name, integrationKey)) {
      return false;
    }
    return nameMatchesOtaKeywords(name, config.keywords);
  }

  function buildPricingResolutionSources({ affiliation, affiliateListRow, totalSheets, totalSchedules }) {
    const company = affiliation?.company ?? null;
    const affiliateListPricing =
      affiliateListRow?.totalPricingObject ?? affiliateListRow?.total_pricing_object ?? null;

    const lookupObjects = [];
    if (affiliateListPricing) {
      lookupObjects.push(affiliateListPricing);
    }
    if (company?.default_direct_total_sheet) {
      lookupObjects.push(company.default_direct_total_sheet);
    }
    if (company?.default_online_total_sheet) {
      lookupObjects.push(company.default_online_total_sheet);
    }
    if (company?.default_direct_total_schedule) {
      lookupObjects.push(company.default_direct_total_schedule);
    }
    if (company?.default_online_total_schedule) {
      lookupObjects.push(company.default_online_total_schedule);
    }
    for (const sheet of totalSheets || []) {
      lookupObjects.push(sheet);
    }
    for (const schedule of totalSchedules || []) {
      lookupObjects.push(schedule);
    }

    return { lookupObjects };
  }

  function resolvePricingObjectDisplayName(pricingObject, resolutionSources) {
    if (!pricingObject || typeof pricingObject !== "object") {
      return null;
    }

    const inlineName = getPricingObjectDisplayNameForWarning(pricingObject);
    if (inlineName) {
      return inlineName;
    }

    const lookupObjects = resolutionSources?.lookupObjects || [];
    for (const candidate of lookupObjects) {
      if (!pricingObjectsMatch(pricingObject, candidate)) {
        continue;
      }
      const resolvedName = getSheetDisplayName(candidate) ?? getPricingObjectDisplayNameForWarning(candidate);
      if (resolvedName) {
        return resolvedName;
      }
    }

    return null;
  }

  function pricingClsToTypeLabel(cls) {
    if (typeof cls !== "string") {
      return null;
    }
    const normalized = cls.trim();
    if (normalized === "TotalSheet" || normalized === "total_sheet" || normalized === "Total Sheet") {
      return "Total Sheet";
    }
    if (
      normalized === "TotalSchedule" ||
      normalized === "total_schedule" ||
      normalized === "Total Schedule"
    ) {
      return "Total Schedule";
    }
    return null;
  }

  function formatSelectedPricingActual(selectedPricing) {
    if (!selectedPricing || selectedPricing.name === null || selectedPricing.name === undefined) {
      return formatAffiliateSettingActual(selectedPricing?.name ?? null);
    }
    if (selectedPricing.type) {
      return `${selectedPricing.name} (${selectedPricing.type})`;
    }
    return String(selectedPricing.name);
  }

  function buildSelectedPricingFromObject(pricingObject, typeLabel, resolutionSources) {
    if (!pricingObject || typeof pricingObject !== "object") {
      return { name: null, type: null, uri: null, pk: null };
    }

    const type = typeLabel ?? pricingClsToTypeLabel(pricingObject.cls) ?? null;
    const inlineName = getPricingObjectDisplayNameForWarning(pricingObject);
    const name = inlineName ?? resolvePricingObjectDisplayName(pricingObject, resolutionSources);

    return {
      name,
      type,
      uri: pricingObject.uri ?? null,
      pk: pricingObject.pk ?? null
    };
  }

  function getSelectedPricingDisplay(affiliation, affiliateListItem, resolutionSources) {
    const affiliateListPricing =
      affiliateListItem?.totalPricingObject ?? affiliateListItem?.total_pricing_object ?? null;
    const defaultSheet = affiliation?.default_total_sheet ?? null;
    const defaultSchedule = affiliation?.default_total_schedule ?? null;

    console.log("[qc-checks] raw totalPricingObject from list item:", affiliateListPricing);
    console.log("[qc-checks] raw default_total_sheet:", defaultSheet);
    console.log("[qc-checks] raw default_total_schedule:", defaultSchedule);

    let result;
    if (affiliateListPricing) {
      result = buildSelectedPricingFromObject(
        affiliateListPricing,
        pricingClsToTypeLabel(affiliateListPricing.cls),
        resolutionSources
      );
    } else if (defaultSheet) {
      result = buildSelectedPricingFromObject(defaultSheet, "Total Sheet", resolutionSources);
    } else if (defaultSchedule) {
      result = buildSelectedPricingFromObject(defaultSchedule, "Total Schedule", resolutionSources);
    } else {
      result = { name: null, type: null, uri: null, pk: null };
    }

    console.log("[qc-checks] resolved selected pricing name/type:", {
      name: result.name,
      type: result.type
    });

    return result;
  }

  function logPricingValidation(label, selectedPricing, allowedTokens, result) {
    console.log("[qc-checks] pricing validation expected tokens:", allowedTokens);
    console.log("[qc-checks] pricing validation result:", {
      label,
      ok: result.ok === true,
      mismatch: result.mismatch ?? null,
      selectedName: selectedPricing?.name ?? null,
      selectedType: selectedPricing?.type ?? null
    });
  }

  function getPricingObjectNameFields(pricingObject) {
    if (!pricingObject || typeof pricingObject !== "object") {
      return [];
    }
    return [
      pricingObject.display_name ?? null,
      pricingObject.displayName ?? null,
      pricingObject.name ?? null,
      pricingObject.unicode ?? null
    ]
      .filter((value) => typeof value === "string")
      .map((value) => value.trim())
      .filter((value) => value !== "");
  }

  function isOtaSpecificTotalSheet(sheet, integrationKey) {
    const nameFields = getPricingObjectNameFields(sheet);
    return nameFields.some((value) => isOtaSpecificPricingName(value, integrationKey));
  }

  function getTotalScheduleEntries(schedule) {
    if (window.FareHarborTotalPricingResolution?.getTotalScheduleEntries) {
      return window.FareHarborTotalPricingResolution.getTotalScheduleEntries(schedule);
    }

    if (!schedule || typeof schedule !== "object") {
      return [];
    }

    const candidateCollections = [
      schedule.entries,
      schedule.schedule_entries,
      schedule.total_schedule_entries
    ];

    for (const collection of candidateCollections) {
      if (Array.isArray(collection)) {
        return collection;
      }
    }

    return [];
  }

  function isOtaSpecificTotalScheduleByName(schedule, integrationKey) {
    const scheduleNameFields = getPricingObjectNameFields(schedule);
    return scheduleNameFields.some((value) => isOtaSpecificPricingName(value, integrationKey));
  }

  function hasOtaSpecificPricingAvailable(sheets, schedules, integrationKey) {
    if ((sheets || []).some((sheet) => isOtaSpecificTotalSheet(sheet, integrationKey))) {
      return true;
    }

    for (const schedule of schedules || []) {
      if (isOtaSpecificTotalScheduleByName(schedule, integrationKey)) {
        return true;
      }
      const entries = getTotalScheduleEntries(schedule);
      if (entries.some((entry) => isOtaSpecificTotalSheet(entry?.sheet ?? null, integrationKey))) {
        return true;
      }
    }

    return false;
  }

  function collectOtaSpecificAvailablePricingLines(sheets, schedules, integrationKey) {
    const lines = [];
    const seen = new Set();

    const addUniqueLine = (line) => {
      if (!seen.has(line)) {
        seen.add(line);
        lines.push(line);
      }
    };

    for (const sheet of sheets || []) {
      const name = getPricingObjectDisplayNameForWarning(sheet);
      if (name && isOtaSpecificPricingName(name, integrationKey)) {
        addUniqueLine(formatPricingLine(name, "Total Sheet"));
      }
    }

    for (const schedule of schedules || []) {
      const scheduleName = getPricingObjectDisplayNameForWarning(schedule);
      if (scheduleName && isOtaSpecificPricingName(scheduleName, integrationKey)) {
        addUniqueLine(formatPricingLine(scheduleName, "Total Schedule"));
        continue;
      }

      const entries = getTotalScheduleEntries(schedule);
      for (const entry of entries) {
        const entrySheet = entry?.sheet ?? null;
        const entrySheetName = getPricingObjectDisplayNameForWarning(entrySheet);
        if (entrySheetName && isOtaSpecificPricingName(entrySheetName, integrationKey)) {
          addUniqueLine(formatPricingLine(entrySheetName, "Total Sheet"));
        }
      }
    }

    return lines;
  }

  function getOtaSpecificTotalSheetsForMatching(sheets, integrationKey) {
    return (sheets || []).filter((sheet) => isOtaSpecificTotalSheet(sheet, integrationKey));
  }

  function getOtaSpecificTotalSchedulesForMatching(schedules, integrationKey) {
    return (schedules || []).filter((schedule) => isOtaSpecificTotalScheduleByName(schedule, integrationKey));
  }

  async function fetchTotalSheetsUncached(shortname) {
    const url = `/api/v1/companies/${encodeURIComponent(shortname)}/total-sheets/`;
    console.log("[qc-checks] total sheets URL:", url);

    const result = await apiGetJson(url);
    console.log("[qc-checks] total sheets response status:", result.status);

    if (!result.ok) {
      return { ok: false, sheets: null, error: result.error };
    }

    const sheets = result.data?.total_sheets;
    if (!Array.isArray(sheets)) {
      return { ok: false, sheets: null, error: "Response missing total_sheets array" };
    }

    console.log("[qc-checks] total sheets count:", sheets.length);
    return { ok: true, sheets, error: null };
  }

  async function fetchTotalSheets(shortname) {
    if (qcRunCache.totalSheetsResult !== undefined) {
      return qcRunCache.totalSheetsResult;
    }

    if (!qcRunCache.totalSheetsPromise) {
      qcRunCache.totalSheetsPromise = fetchTotalSheetsUncached(shortname);
    }

    const result = await qcRunCache.totalSheetsPromise;
    qcRunCache.totalSheetsResult = result;
    return result;
  }

  async function fetchTotalSchedulesUncached(shortname) {
    const url = `/api/v1/companies/${encodeURIComponent(shortname)}/total-schedules/`;
    console.log("[qc-checks] total schedules URL:", url);

    const result = await apiGetJson(url);
    console.log("[qc-checks] total schedules response status:", result.status);

    if (!result.ok) {
      return { ok: false, schedules: null, error: result.error };
    }

    const schedules = result.data?.total_schedules;
    if (!Array.isArray(schedules)) {
      return { ok: false, schedules: null, error: "Response missing total_schedules array" };
    }

    console.log("[qc-checks] total schedules count:", schedules.length);
    return { ok: true, schedules, error: null };
  }

  async function fetchTotalSchedules(shortname) {
    if (qcRunCache.totalSchedulesResult !== undefined) {
      return qcRunCache.totalSchedulesResult;
    }

    if (!qcRunCache.totalSchedulesPromise) {
      qcRunCache.totalSchedulesPromise = fetchTotalSchedulesUncached(shortname);
    }

    const result = await qcRunCache.totalSchedulesPromise;
    qcRunCache.totalSchedulesResult = result;
    return result;
  }

  function normalizePercentageValue(value) {
    if (value === null || value === undefined) {
      return null;
    }
    const parsed = Number(String(value).trim());
    if (Number.isNaN(parsed)) {
      return null;
    }
    return parsed;
  }

  function extractPricingPercentage(pricingObject) {
    if (!pricingObject || typeof pricingObject !== "object") {
      return null;
    }

    const candidateFields = [
      "sheet_percentage",
      "schedule_percentage",
      "invoice_percentage",
      "percentage",
      "rate",
      "commission_percentage",
      "commission_rate"
    ];

    for (const field of candidateFields) {
      const parsed = normalizePercentageValue(pricingObject[field]);
      if (parsed !== null) {
        return { value: parsed, field };
      }
    }

    return null;
  }

  function getViatorInvoicePricingSignals(detail) {
    const invoiceSheet = detail?.default_invoice_sheet ?? null;
    const invoiceSchedule = detail?.default_invoice_schedule ?? null;
    const sheetSignal = extractPricingPercentage(invoiceSheet);
    const scheduleSignal = extractPricingPercentage(invoiceSchedule);

    console.log("[qc-checks] Viator invoice sheet percentage signal:", {
      object: stringifyPricingObject(invoiceSheet),
      signal: sheetSignal
    });
    console.log("[qc-checks] Viator invoice schedule percentage signal:", {
      object: stringifyPricingObject(invoiceSchedule),
      signal: scheduleSignal
    });

    return { sheetSignal, scheduleSignal };
  }

  async function fetchAvailableTotalPricingObjects(shortname) {
    const totalSheetsResult = await fetchTotalSheets(shortname);
    if (!totalSheetsResult.ok) {
      return {
        ok: false,
        endpointMapped: true,
        sheets: [],
        schedules: [],
        error: totalSheetsResult.error
      };
    }

    const totalSchedulesResult = await fetchTotalSchedules(shortname);
    if (!totalSchedulesResult.ok) {
      return {
        ok: false,
        endpointMapped: true,
        sheets: totalSheetsResult.sheets ?? [],
        schedules: [],
        error: totalSchedulesResult.error
      };
    }

    return {
      ok: true,
      endpointMapped: true,
      sheets: totalSheetsResult.sheets ?? [],
      schedules: totalSchedulesResult.schedules ?? [],
      error: null
    };
  }

  function isCustomInvoiceFeeEnabled(detail) {
    return (
      detail?.invoice_fee_rate != null ||
      detail?.invoice_fee_percentage != null ||
      detail?.invoice_flat_fee != null
    );
  }

  function validateAffiliateBooleanField(label, actual, expected) {
    if (actual === expected) {
      return { ok: true };
    }
    return {
      ok: false,
      mismatch: `${label}: expected ${expected}, got ${formatAffiliateSettingActual(actual)}`
    };
  }

  function validateAffiliateStringField(label, actual, expected) {
    if (actual === expected) {
      return { ok: true };
    }
    return {
      ok: false,
      mismatch: `${label}: expected ${expected}, got ${formatAffiliateSettingActual(actual)}`
    };
  }

  function validateAffiliateDefaultApiCancellationPolicy(detail) {
    const actual = detail?.cancellation_policy?.name ?? null;
    if (isDefaultApiCancellationPolicyName(actual)) {
      return { ok: true };
    }
    return {
      ok: false,
      mismatch: `Cancellation policy: expected ${DEFAULT_API_POLICY_NAME}, got ${formatAffiliateSettingActual(actual)}`
    };
  }

  function validateAffiliateOneOfDisplayName(label, actual, allowed) {
    if (allowed.includes(actual)) {
      return { ok: true };
    }
    return {
      ok: false,
      mismatch: `${label}: expected ${allowed.join(" or ")}, got ${formatAffiliateSettingActual(actual)}`
    };
  }

  function validateAffiliateExactDisplayName(label, actual, expected) {
    if (actual === expected) {
      return { ok: true };
    }
    return {
      ok: false,
      mismatch: `${label}: expected ${expected}, got ${formatAffiliateSettingActual(actual)}`
    };
  }

  function normalizeAirbnbInvoicePricingNameForMatch(value) {
    if (typeof value !== "string") {
      return null;
    }
    const normalized = value
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9%]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    return normalized !== "" ? normalized : null;
  }

  function isAcceptedAirbnbInvoicePricingName(displayName) {
    const normalized = normalizeAirbnbInvoicePricingNameForMatch(displayName);
    return normalized === "billing 20%" || normalized === "airbnb 20%";
  }

  function validateAirbnbAffiliateInvoicePricing(detail) {
    const actual = detail?.default_invoice_sheet?.display_name ?? null;
    if (isAcceptedAirbnbInvoicePricingName(actual)) {
      return { ok: true };
    }
    return {
      ok: false,
      mismatch: `Invoice pricing should be Billing - 20% or an accepted Airbnb 20% variation; found: ${formatAffiliateSettingActual(actual)}`
    };
  }

  function validateAffiliatePricingContains(label, selectedPricing, allowedTokens) {
    const normalizedName = normalizePricingNameForMatch(selectedPricing?.name ?? null);
    const normalizedTokens = (allowedTokens || [])
      .map((token) => normalizePricingNameForMatch(token))
      .filter((token) => token !== null);

    let result;
    if (!normalizedName) {
      result = {
        ok: false,
        mismatch: `${label}: expected ${allowedTokens.join(" or ")}, got ${formatSelectedPricingActual(selectedPricing)}`
      };
    } else if (normalizedTokens.some((token) => normalizedName.includes(token))) {
      result = { ok: true };
    } else {
      result = {
        ok: false,
        mismatch: `${label}: expected ${allowedTokens.join(" or ")}, got ${formatSelectedPricingActual(selectedPricing)}`
      };
    }

    logPricingValidation(label, selectedPricing, allowedTokens, result);
    return result;
  }

  function validateAffiliatePricingExact(label, selectedPricing, expected) {
    const actual = selectedPricing?.name ?? null;
    let result;
    if (actual === expected) {
      result = { ok: true };
    } else {
      result = {
        ok: false,
        mismatch: `${label}: expected ${expected}, got ${formatSelectedPricingActual(selectedPricing)}`
      };
    }

    logPricingValidation(label, selectedPricing, [expected], result);
    return result;
  }

  function validateAffiliatePricingOnline(label, selectedPricing, options = {}) {
    const affiliateLabel = options.affiliateLabel ?? null;
    const failurePrefix = affiliateLabel
      ? `${affiliateLabel}: expected Online or Airbnb pricing sheet, got`
      : `${label}: expected Online or Airbnb pricing sheet, got`;

    let result;
    if (isAcceptedAirbnbPricingName(selectedPricing?.name)) {
      result = { ok: true };
    } else {
      result = {
        ok: false,
        mismatch: `${failurePrefix} ${formatSelectedPricingActual(selectedPricing)}`
      };
    }

    logPricingValidation(label, selectedPricing, ["Online", "Airbnb"], result);
    return result;
  }

  function isAcceptedGooglePricingName(name) {
    if (typeof name !== "string") {
      return false;
    }
    const selectedNameLower = name.trim().toLowerCase();
    if (!selectedNameLower) {
      return false;
    }
    return selectedNameLower.includes("online") || selectedNameLower.includes("google");
  }

  function validateGoogleAffiliatePricing(label, selectedPricing) {
    const selectedName = selectedPricing?.name ?? null;
    const selectedNameLower =
      typeof selectedName === "string" ? selectedName.trim().toLowerCase() : "";
    const containsOnline = selectedNameLower.includes("online");
    const containsGoogle = selectedNameLower.includes("google");
    const accepted = isAcceptedGooglePricingName(selectedName);

    console.log("[qc-checks] Google pricing validation");
    console.log("[qc-checks] selected pricing:", formatSelectedPricingActual(selectedPricing));
    console.log("[qc-checks] contains online:", containsOnline);
    console.log("[qc-checks] contains google:", containsGoogle);
    console.log("[qc-checks] final result:", accepted ? "pass" : "fail");

    if (accepted) {
      return { ok: true };
    }

    return {
      ok: false,
      mismatch: `${label}: expected pricing containing Online or Google, got ${formatSelectedPricingActual(selectedPricing)}`
    };
  }

  function validateAffiliateNonEmptyInvoice(label, sheet) {
    const displayName = sheet?.display_name ?? null;
    if (sheet != null && typeof displayName === "string" && displayName.trim() !== "") {
      return { ok: true };
    }
    return {
      ok: false,
      mismatch: `${label}: expected non-empty, got ${formatAffiliateSettingActual(displayName)}`
    };
  }

  function validateAffiliateNonEmptyNote(detail, context = {}) {
    const integrationKey = context.integrationKey ?? null;
    const note = detail?.note ?? null;
    const noteLengthAfterTrim = typeof note === "string" ? note.trim().length : 0;
    const noteExists = typeof note === "string" && noteLengthAfterTrim > 0;

    console.log("[qc-checks] affiliate note validation integration key:", integrationKey);
    console.log("[qc-checks] affiliate note validation note exists:", noteExists);
    console.log("[qc-checks] affiliate note validation note length after trim:", noteLengthAfterTrim);

    if (noteExists) {
      return { ok: true };
    }
    return {
      ok: false,
      mismatch: "Affiliate note: expected a non-empty note, got empty"
    };
  }

  function validateAffiliateCustomInvoiceFeeDisabled(detail) {
    if (!isCustomInvoiceFeeEnabled(detail)) {
      return { ok: true };
    }
    return {
      ok: false,
      mismatch: "Use custom invoice fee for this affiliation: expected disabled, got enabled"
    };
  }

  function buildSharedOtaAffiliateValidators({ standardApiEmailFlags }) {
    const pricedConfirmationsExpected = standardApiEmailFlags ? false : true;
    const reminderEmailsExpected = standardApiEmailFlags ? true : false;
    const confirmationEmailsExpected = standardApiEmailFlags ? true : false;

    return [
      {
        label: "Cancellation policy",
        validate: (detail) => validateAffiliateDefaultApiCancellationPolicy(detail)
      },
      {
        label: "Permissions",
        validate: (detail) =>
          validateAffiliateStringField(
            "Permissions",
            detail?.affiliate_group?.name ?? null,
            AFFILIATE_API_GROUP_NAME
          )
      },
      {
        label: "Payment default",
        validate: (detail) =>
          validateAffiliateStringField("Payment default", detail?.payment_preference ?? null, "affiliate-take")
      },
      {
        label: "Require voucher number",
        validate: (detail) =>
          validateAffiliateBooleanField(
            "Require voucher number",
            detail?.is_voucher_number_required ?? null,
            true
          )
      },
      {
        label: "Show prices in confirmations",
        validate: (detail) =>
          validateAffiliateBooleanField(
            "Show prices in confirmations",
            detail?.is_priced_confirmations_enabled ?? null,
            pricedConfirmationsExpected
          )
      },
      {
        label: "Send receipt emails",
        validate: (detail) =>
          validateAffiliateBooleanField("Send receipt emails", detail?.is_receipt_emails_enabled ?? null, true)
      },
      {
        label: "Send reminder emails for bookings over APIs",
        validate: (detail) =>
          validateAffiliateBooleanField(
            "Send reminder emails for bookings over APIs",
            detail?.is_reminder_emails_enabled_for_api ?? null,
            reminderEmailsExpected
          )
      },
      {
        label: "Send confirmation emails for bookings over APIs",
        validate: (detail) =>
          validateAffiliateBooleanField(
            "Send confirmation emails for bookings over APIs",
            detail?.is_confirmation_emails_enabled_for_api ?? null,
            confirmationEmailsExpected
          )
      },
      {
        label: "Include affiliate name and voucher in emails",
        validate: (detail) =>
          validateAffiliateBooleanField(
            "Include affiliate name and voucher in emails",
            detail?.is_affiliate_information_in_emails_enabled ?? null,
            false
          )
      },
      {
        label: "Use custom invoice fee for this affiliation",
        validate: validateAffiliateCustomInvoiceFeeDisabled
      }
    ];
  }

  const OTA_MATCH_TOKENS = {
    airbnb: ["airbnb"],
    expedia: ["expediaonline"],
    getyourguide: ["getyourguide"],
    google: ["google"],
    viator: ["viator"]
  };

  const OTA_AFFILIATE_CONFIG = {
    airbnb: {
      label: "Airbnb",
      validators: [
        {
          label: "Pricing",
          validate: (detail, ctx) =>
            validateAffiliatePricingOnline("Pricing", ctx.selectedPricing, { affiliateLabel: "Airbnb" })
        },
        {
          label: "Invoice pricing",
          validate: validateAirbnbAffiliateInvoicePricing
        },
        ...buildSharedOtaAffiliateValidators({ standardApiEmailFlags: true })
      ]
    },
    viator: {
      label: "Viator",
      validators: [
        {
          label: "Pricing",
          validate: (detail, ctx) =>
            validateAffiliatePricingContains("Pricing", ctx.selectedPricing, ["Direct", "Viator"])
        },
        {
          label: "Invoice pricing",
          validate: (detail) =>
            validateAffiliateNonEmptyInvoice("Invoice pricing", detail?.default_invoice_sheet ?? null)
        },
        ...buildSharedOtaAffiliateValidators({ standardApiEmailFlags: true })
      ]
    },
    getyourguide: {
      label: "GetYourGuide",
      validators: [
        {
          label: "Pricing",
          validate: (detail, ctx) =>
            validateAffiliatePricingContains("Pricing", ctx.selectedPricing, [
              "Direct",
              "GetYourGuide",
              "GYG"
            ])
        },
        {
          label: "Invoice pricing",
          validate: (detail) =>
            validateAffiliateNonEmptyInvoice("Invoice pricing", detail?.default_invoice_sheet ?? null)
        },
        {
          label: "Affiliate note",
          validate: validateAffiliateNonEmptyNote
        },
        ...buildSharedOtaAffiliateValidators({ standardApiEmailFlags: true })
      ]
    },
    expedia: {
      label: "Expedia",
      validators: [
        {
          label: "Pricing",
          validate: (detail, ctx) =>
            validateAffiliatePricingContains("Pricing", ctx.selectedPricing, ["Direct", "Expedia"])
        },
        ...buildSharedOtaAffiliateValidators({ standardApiEmailFlags: true })
      ]
    },
    google: {
      label: "Google",
      validators: [
        {
          label: "Pricing",
          validate: (detail, ctx) => validateGoogleAffiliatePricing("Pricing", ctx.selectedPricing)
        },
        {
          label: "Invoice pricing",
          validate: (detail) => {
            const sheet = detail?.default_invoice_sheet ?? null;
            if (sheet === null) {
              return { ok: true };
            }
            return {
              ok: false,
              mismatch: `Invoice pricing: expected null, got ${formatAffiliateSettingActual(sheet?.display_name ?? sheet)}`
            };
          }
        },
        ...buildSharedOtaAffiliateValidators({ standardApiEmailFlags: false }).map((validator) =>
          validator.label === "Payment default"
            ? {
                label: "Payment default",
                validate: (detail) =>
                  validateAffiliateStringField("Payment default", detail?.payment_preference ?? null, "take")
              }
            : validator
        )
      ]
    }
  };

  const EXPECTED_AFFILIATE_API_ENABLED_PERMISSIONS = [
    "can_view_contacts",
    "can_view_activities",
    "can_view_resources",
    "can_view_custom_fields",
    "can_view_checkin_statuses",
    "can_view_custom_field_values",
    "can_view_payments",
    "can_edit_payments",
    "can_view_waivers",
    "can_view_customers",
    "can_edit_activities",
    "can_view_invoice_amounts",
    "can_edit_booking_explicit_invoice_prices",
    "can_view_availability_capacities",
    "can_create_credit_card_payments",
    "can_create_affiliate_payments",
    "can_create_deferred_payments",
    "can_edit_booking_affiliation_info",
    "can_view_line_items",
    "can_create_bookings",
    "can_view_booking_notes",
    "can_edit_booking_notes",
    "can_edit_notifications",
    "can_change_price_sheets",
    "can_view_notifications",
    "can_view_sms_notifications",
    "can_view_waiver_instances",
    "can_create_invoice_uploads",
    "can_cancel_eligible_bookings",
    "can_view_cards",
    "can_view_activities_self",
    "can_view_activities_feed",
    "can_skip_contact_email",
    "can_skip_contact_phone"
  ];

  const OPTIONAL_PERMISSIONS = ["can_view_other_users"];

  function parseCompanyShortname() {
    const parts = (window.location.pathname || "").split("/").filter(Boolean);
    return parts[0] || null;
  }

  function normalizeName(value) {
    return String(value || "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, " ")
      .trim()
      .replace(/\s+/g, " ");
  }

  function isValidGooglePlaceId(value) {
    if (value == null) {
      return false;
    }
    const text = String(value).trim();
    if (!text) {
      return false;
    }
    return GOOGLE_PLACE_ID_RE.test(text);
  }

  function getGygTicketCategory(resellerCustomerType) {
    return (
      resellerCustomerType?.getyourguide_ticket_category ??
      resellerCustomerType?.getyourguideTicketCategory ??
      null
    );
  }

  function isGroupTicketCategory(resellerCustomerType) {
    return normalizeName(getGygTicketCategory(resellerCustomerType)) === "group";
  }

  function getResellerCustomerTypeDisplayName(resellerCustomerType) {
    const name =
      resellerCustomerType?.name ??
      resellerCustomerType?.display_name ??
      resellerCustomerType?.displayName ??
      resellerCustomerType?.unicode ??
      resellerCustomerType?.short_name ??
      resellerCustomerType?.shortName ??
      resellerCustomerType?.external_identifier ??
      resellerCustomerType?.externalIdentifier ??
      null;
    if (typeof name === "string" && name.trim() !== "") {
      return name.trim();
    }
    const pk = resellerCustomerType?.pk;
    return pk !== null && pk !== undefined ? String(pk) : "Unknown";
  }

  function formatGygGroupCategoryConfiguredOn(resellerCustomerTypeName) {
    return `GetYourGuide Group ticket category is configured on reseller customer type "${resellerCustomerTypeName}"`;
  }

  const GYG_GROUP_REASON_SECTIONS = {
    no_priced_custom_fields: "No priced custom fields found:",
    priced_custom_field: "Priced custom field found - manual check needed:",
    no_item_mapping: "No FareHarbor item mapping found:",
    no_customer_type_mapping: "Not mapped to a FareHarbor customer type:",
    missing_prototype_pk: "Mapping is missing a customer prototype pk:",
    prototype_not_found: "Mapped customer prototype was not found on the item:"
  };

  const GYG_GROUP_REASON_ORDER = [
    "no_priced_custom_fields",
    "priced_custom_field",
    "no_item_mapping",
    "no_customer_type_mapping",
    "missing_prototype_pk",
    "prototype_not_found"
  ];

  function buildGygGroupItemResult(fields) {
    return {
      status: fields.status,
      itemLabel: fields.itemLabel,
      resellerItemPk: String(fields.resellerItemPk),
      mappedTo: fields.mappedTo ?? null,
      reason: fields.reason ?? null,
      resellerCustomerTypeName: fields.resellerCustomerTypeName ?? null,
      line: fields.line ?? null
    };
  }

  function formatGygGroupMappedItemLine(item) {
    const nameWithPk = `${item.itemLabel} (pk ${item.resellerItemPk})`;
    if (item.mappedTo) {
      return `- ${nameWithPk}\n  Mapped to: ${item.mappedTo}`;
    }
    return `- ${nameWithPk}`;
  }

  const GYG_GROUP_EXPANDED_REASON_ORDER = [
    "priced_custom_field",
    "no_item_mapping",
    "no_customer_type_mapping",
    "missing_prototype_pk",
    "prototype_not_found"
  ];

  function escapeGygGroupHtml(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function collectGygGroupMappingDisplayData(itemResults) {
    const items = Array.isArray(itemResults) ? itemResults : [];
    const warningItems = items.filter((result) => result.status === "warning");
    const passItems = items.filter((result) => result.status === "pass");
    const errorItems = items.filter((result) => result.status === "error" && result.line);
    const resellerTypeName = items.find((result) => result.resellerCustomerTypeName)
      ?.resellerCustomerTypeName;

    const displayItems = warningItems.length > 0 ? [...warningItems, ...passItems] : passItems;
    const grouped = new Map();
    for (const item of displayItems) {
      if (!item.reason) {
        continue;
      }
      if (!grouped.has(item.reason)) {
        grouped.set(item.reason, []);
      }
      grouped.get(item.reason).push(item);
    }

    const totalItemsFound = displayItems.filter((item) => item.reason).length;
    const manualReviewCount = warningItems.length;
    const noPricedCustomFieldsItems = grouped.get("no_priced_custom_fields") || [];

    return {
      warningItems,
      passItems,
      errorItems,
      resellerTypeName,
      grouped,
      totalItemsFound,
      manualReviewCount,
      noPricedCustomFieldsItems
    };
  }

  function formatGygGroupMappingSummaryLine(totalItemsFound, manualReviewCount) {
    if (totalItemsFound <= 0) {
      return null;
    }
    if (manualReviewCount > 0) {
      const reviewLabel = manualReviewCount === 1 ? "needs manual review" : "need manual review";
      return `${totalItemsFound} items found, ${manualReviewCount} ${reviewLabel}`;
    }
    const itemLabel = totalItemsFound === 1 ? "item" : "items";
    return `${totalItemsFound} ${itemLabel} found`;
  }

  function formatGetYourGuideGroupTicketCategoryMappingWarning(itemResults) {
    const {
      errorItems,
      resellerTypeName,
      grouped,
      totalItemsFound,
      manualReviewCount
    } = collectGygGroupMappingDisplayData(itemResults);

    const introLines = [];
    if (resellerTypeName) {
      introLines.push(formatGygGroupCategoryConfiguredOn(resellerTypeName) + ".");
    }
    const summaryLine = formatGygGroupMappingSummaryLine(totalItemsFound, manualReviewCount);
    if (summaryLine) {
      introLines.push(summaryLine);
    }

    const bodySections = [];
    for (const reason of GYG_GROUP_REASON_ORDER) {
      const groupItems = grouped.get(reason);
      if (!groupItems || groupItems.length === 0) {
        continue;
      }
      const title = GYG_GROUP_REASON_SECTIONS[reason];
      const lines = groupItems.map(formatGygGroupMappedItemLine);
      bodySections.push(`${title}\n${lines.join("\n")}`);
    }

    if (errorItems.length > 0) {
      bodySections.push(errorItems.map((result) => result.line).join("\n"));
    }

    const parts = [];
    if (introLines.length > 0) {
      parts.push(introLines.join("\n"));
    }
    if (bodySections.length > 0) {
      parts.push(bodySections.join("\n\n"));
    }

    return parts.join("\n\n");
  }

  function formatGygGroupMappedItemHtml(item) {
    const nameWithPk = escapeGygGroupHtml(`${item.itemLabel} (pk ${item.resellerItemPk})`);
    let html = `<div class="qc-gyg-group-item">- ${nameWithPk}`;
    if (item.mappedTo) {
      html += `<div class="qc-gyg-group-item-mapped">  Mapped to: ${escapeGygGroupHtml(item.mappedTo)}</div>`;
    }
    html += "</div>";
    return html;
  }

  function formatGygGroupReasonSectionHtml(reason, groupItems) {
    if (!groupItems || groupItems.length === 0) {
      return "";
    }
    const title = GYG_GROUP_REASON_SECTIONS[reason];
    return (
      `<div class="qc-gyg-group-section">` +
      `<div class="qc-gyg-group-section-title">${escapeGygGroupHtml(title)}</div>` +
      groupItems.map(formatGygGroupMappedItemHtml).join("") +
      `</div>`
    );
  }

  function formatGetYourGuideGroupTicketCategoryMappingDetailsHtml(itemResults) {
    const {
      errorItems,
      resellerTypeName,
      grouped,
      totalItemsFound,
      manualReviewCount,
      noPricedCustomFieldsItems
    } = collectGygGroupMappingDisplayData(itemResults);

    const htmlParts = ['<div class="qc-gyg-group-mapping-details">'];

    if (resellerTypeName) {
      htmlParts.push(
        `<div class="qc-gyg-group-intro">${escapeGygGroupHtml(formatGygGroupCategoryConfiguredOn(resellerTypeName) + ".")}</div>`
      );
    }

    const summaryLine = formatGygGroupMappingSummaryLine(totalItemsFound, manualReviewCount);
    if (summaryLine) {
      htmlParts.push(`<div class="qc-gyg-group-summary">${escapeGygGroupHtml(summaryLine)}</div>`);
    }

    for (const reason of GYG_GROUP_EXPANDED_REASON_ORDER) {
      const sectionHtml = formatGygGroupReasonSectionHtml(reason, grouped.get(reason));
      if (sectionHtml) {
        htmlParts.push(sectionHtml);
      }
    }

    if (noPricedCustomFieldsItems.length > 0) {
      const count = noPricedCustomFieldsItems.length;
      const itemLabel = count === 1 ? "item" : "items";
      const summaryText = `No priced custom fields found (${count} ${itemLabel})`;
      htmlParts.push(
        `<details class="qc-gyg-group-collapsible">` +
        `<summary class="qc-gyg-group-collapsible-summary">${escapeGygGroupHtml(summaryText)}</summary>` +
        `<div class="qc-gyg-group-collapsible-body">` +
        noPricedCustomFieldsItems.map(formatGygGroupMappedItemHtml).join("") +
        `</div></details>`
      );
    }

    if (errorItems.length > 0) {
      htmlParts.push(
        `<div class="qc-gyg-group-errors">${errorItems
          .map((result) => `<div class="qc-gyg-group-error-line">${escapeGygGroupHtml(result.line)}</div>`)
          .join("")}</div>`
      );
    }

    htmlParts.push("</div>");
    return htmlParts.join("");
  }

  function rowHasActualPrice(row) {
    const price = row?.price || {};
    const line = row?.line || {};

    const hasEffectivePrice =
      Number(price.offset || 0) !== 0 || Number(price.rate || 0) !== 0;

    const hasExplicitLinePrice =
      line.price_type === "change" &&
      (Number(line.offset || 0) !== 0 ||
        Number(line.rate || 0) !== 0 ||
        Number(line.percentage || 0) !== 0);

    return hasEffectivePrice || hasExplicitLinePrice;
  }

  function evaluateCustomFieldPricing(pricingData, customFieldMeta) {
    const effectivePricings = pricingData?.effective_pricings ?? pricingData?.effectivePricings;
    const rows = Array.isArray(effectivePricings) ? effectivePricings : [];
    const pricedRows = rows.filter((row) => rowHasActualPrice(row));

    gygDevLog("[qc-checks] GYG custom field pricing audit:", {
      customFieldPk: customFieldMeta.pk,
      customFieldName: customFieldMeta.name,
      sheetId: customFieldMeta.sheetId ?? null,
      effectivePricingsLength: rows.length,
      pricedRowsCount: pricedRows.length
    });

    for (const row of pricedRows) {
      const price = row?.price || {};
      const line = row?.line || {};
      gygDevLog("[qc-checks] GYG custom field priced row:", {
        customFieldPk: customFieldMeta.pk,
        customFieldName: customFieldMeta.name,
        sheetId: customFieldMeta.sheetId ?? null,
        forObjectCls: row?.for_object?.cls ?? null,
        forObjectPk: row?.for_object?.pk ?? null,
        priceOffset: price.offset ?? null,
        priceRate: price.rate ?? null,
        priceModifierType: price.modifier_type ?? null,
        priceModifierKind: price.modifier_kind ?? null,
        lineOffset: line.offset ?? null,
        lineRate: line.rate ?? null,
        linePercentage: line.percentage ?? null,
        linePriceType: line.price_type ?? null,
        lineModifierType: line.modifier_type ?? null,
        lineModifierKind: line.modifier_kind ?? null
      });
    }

    const isPriced = pricedRows.length > 0;

    gygDevLog("[qc-checks] GYG custom field pricing result:", {
      customFieldPk: customFieldMeta.pk,
      customFieldName: customFieldMeta.name,
      sheetId: customFieldMeta.sheetId ?? null,
      isPriced
    });

    return isPriced;
  }

  function getActiveTotalSheetsForGygPricingCheck(sheets) {
    return (sheets || []).filter(
      (sheet) => sheet?.is_archived !== true && sheet?.is_hidden !== true && sheet?.pk != null
    );
  }

  function getSheetInheritsFromPk(sheet) {
    const parent =
      sheet?.inherits_from ??
      sheet?.inheritsFrom ??
      sheet?.parent_sheet ??
      sheet?.parentSheet ??
      sheet?.parent ??
      null;
    if (!parent) {
      return null;
    }
    if (typeof parent === "object") {
      const pk = parent.pk ?? parent.id;
      return pk !== null && pk !== undefined ? String(pk) : null;
    }
    return String(parent);
  }

  function sheetHasExplicitGygBaseMarker(sheet) {
    return (
      sheet?.is_base === true ||
      sheet?.isBase === true ||
      sheet?.is_base_total_sheet === true ||
      sheet?.isBaseTotalSheet === true
    );
  }

  function sheetHasExplicitGygDefaultMarker(sheet) {
    return sheet?.is_default === true || sheet?.isDefault === true;
  }

  function isNormalizedBaseTotalSheetName(sheet) {
    return normalizeName(getSheetDisplayName(sheet)) === "base";
  }

  function getGygGroupPricingCandidateSheets(totalSheets) {
    const activeSheets = getActiveTotalSheetsForGygPricingCheck(totalSheets);
    if (activeSheets.length > 0) {
      return activeSheets;
    }
    return (totalSheets || []).filter((sheet) => sheet?.pk !== null && sheet?.pk !== undefined);
  }

  function identifyGygGroupBaseTotalSheet(totalSheets) {
    const sheets = getGygGroupPricingCandidateSheets(totalSheets);
    if (sheets.length === 0) {
      return { confident: false, reason: "no_sheets" };
    }
    if (sheets.length === 1) {
      return {
        confident: true,
        baseSheet: sheets[0],
        source: "only_active_sheet",
        skippedCount: 0
      };
    }

    const baseMarked = sheets.filter(sheetHasExplicitGygBaseMarker);
    if (baseMarked.length === 1) {
      return {
        confident: true,
        baseSheet: baseMarked[0],
        source: "is_base_marker",
        skippedCount: sheets.length - 1
      };
    }
    if (baseMarked.length > 1) {
      return { confident: false, reason: "multiple_is_base_markers" };
    }

    const defaultMarked = sheets.filter(sheetHasExplicitGygDefaultMarker);
    if (defaultMarked.length === 1) {
      return {
        confident: true,
        baseSheet: defaultMarked[0],
        source: "is_default_marker",
        skippedCount: sheets.length - 1
      };
    }
    if (defaultMarked.length > 1) {
      return { confident: false, reason: "multiple_is_default_markers" };
    }

    const sheetsWithoutParent = sheets.filter((sheet) => getSheetInheritsFromPk(sheet) === null);
    if (sheetsWithoutParent.length === 1) {
      const basePk = String(sheetsWithoutParent[0].pk);
      const othersInheritFromBase = sheets.every((sheet) => {
        if (String(sheet.pk) === basePk) {
          return true;
        }
        return getSheetInheritsFromPk(sheet) === basePk;
      });
      if (othersInheritFromBase) {
        return {
          confident: true,
          baseSheet: sheetsWithoutParent[0],
          source: "inherits_from_graph",
          skippedCount: sheets.length - 1
        };
      }
    }

    const parentPkCounts = new Map();
    for (const sheet of sheets) {
      const parentPk = getSheetInheritsFromPk(sheet);
      if (parentPk) {
        parentPkCounts.set(parentPk, (parentPkCounts.get(parentPk) || 0) + 1);
      }
    }
    for (const [parentPk, count] of parentPkCounts) {
      if (count !== sheets.length - 1) {
        continue;
      }
      const baseSheet = sheets.find((sheet) => String(sheet.pk) === parentPk);
      if (baseSheet) {
        return {
          confident: true,
          baseSheet,
          source: "common_parent_pk",
          skippedCount: sheets.length - 1
        };
      }
    }

    const baseNamed = sheets.filter(isNormalizedBaseTotalSheetName);
    if (baseNamed.length === 1) {
      return {
        confident: true,
        baseSheet: baseNamed[0],
        source: "display_name_base",
        skippedCount: sheets.length - 1
      };
    }

    return { confident: false, reason: "no_confident_base_sheet" };
  }

  function resolveGygGroupCustomFieldPricingSheets(totalSheets) {
    const baseResolution = identifyGygGroupBaseTotalSheet(totalSheets);
    if (baseResolution.confident) {
      return {
        sheetsToCheck: [baseResolution.baseSheet],
        usingBaseSheetOnly: true,
        baseSheetPk: baseResolution.baseSheet?.pk ?? null,
        baseSheetIdentificationSource: baseResolution.source,
        skippedNonBaseSheetsCount: baseResolution.skippedCount ?? 0
      };
    }

    gygDevWarn(
      "[qc-checks] GYG Group mapping: could not identify Base/default total sheet confidently;",
      baseResolution.reason,
      "- falling back to all active total sheets for custom field pricing checks."
    );

    const fallbackSheets = getGygGroupPricingCandidateSheets(totalSheets);
    return {
      sheetsToCheck: fallbackSheets,
      usingBaseSheetOnly: false,
      baseSheetPk: null,
      baseSheetIdentificationSource: null,
      skippedNonBaseSheetsCount: 0
    };
  }

  function getSheetFieldPricingCacheKey(sheetId, customFieldPk) {
    return `${sheetId}:CustomField:${customFieldPk}`;
  }

  async function fetchCustomFieldPricingForEditing(shortname, sheetId, customFieldPk) {
    const cacheKey = getSheetFieldPricingCacheKey(sheetId, customFieldPk);
    if (!qcRunCache.customFieldPricingByKey) {
      qcRunCache.customFieldPricingByKey = {};
    }
    if (!qcRunCache.customFieldPricingPromisesByKey) {
      qcRunCache.customFieldPricingPromisesByKey = {};
    }

    if (qcRunCache.customFieldPricingByKey[cacheKey] !== undefined) {
      if (qcRunCache.gygGroupPerf) {
        qcRunCache.gygGroupPerf.sheetFieldPricingCacheHits += 1;
      }
      return qcRunCache.customFieldPricingByKey[cacheKey];
    }

    if (qcRunCache.customFieldPricingPromisesByKey[cacheKey]) {
      if (qcRunCache.gygGroupPerf) {
        qcRunCache.gygGroupPerf.sheetFieldPricingInFlightHits += 1;
      }
      return qcRunCache.customFieldPricingPromisesByKey[cacheKey];
    }

    if (qcRunCache.gygGroupPerf?.baseSheetFieldPricingRequestKeys) {
      qcRunCache.gygGroupPerf.baseSheetFieldPricingRequestKeys.add(cacheKey);
    }

    const url =
      `/api/v1/companies/${encodeURIComponent(shortname)}/total-sheets/${encodeURIComponent(sheetId)}` +
      `/pricing-for-editing/CustomField/${encodeURIComponent(customFieldPk)}/`;
    gygDevLog("[qc-checks] Fetch URL:", url);

    const fetchPromise = (async () => {
      const result = await gygApiGetJson(url);
      const cached = result.ok
        ? { ok: true, data: result.data, error: null }
        : { ok: false, data: null, error: result.error };
      qcRunCache.customFieldPricingByKey[cacheKey] = cached;
      return cached;
    })();

    qcRunCache.customFieldPricingPromisesByKey[cacheKey] = fetchPromise;

    try {
      return await fetchPromise;
    } finally {
      delete qcRunCache.customFieldPricingPromisesByKey[cacheKey];
    }
  }

  function getCustomFieldsFromPrototype(customerPrototype) {
    const instances = Array.isArray(customerPrototype?.custom_field_instances)
      ? customerPrototype.custom_field_instances
      : [];

    const fields = [];
    for (const instance of instances) {
      const field = instance?.custom_field;
      if (!field || field.is_archived === true) {
        continue;
      }
      const pk = field?.pk;
      if (pk === null || pk === undefined) {
        continue;
      }
      const name =
        field?.display_name ??
        field?.displayName ??
        field?.name ??
        field?.unicode ??
        String(pk);
      fields.push({ pk, name });
    }
    return fields;
  }

  async function prototypeHasPricedCustomFieldViaPricingApi(shortname, customerPrototype, sheetsToCheck) {
    const customFields = getCustomFieldsFromPrototype(customerPrototype);
    trackGygCustomFieldsFound(customFields);
    if (customFields.length === 0) {
      return { priced: false, error: null };
    }

    if (!Array.isArray(sheetsToCheck) || sheetsToCheck.length === 0) {
      return { priced: false, error: null };
    }

    const tasks = [];
    for (const customField of customFields) {
      for (const sheet of sheetsToCheck) {
        const sheetId = sheet?.pk;
        if (sheetId === null || sheetId === undefined) {
          continue;
        }
        tasks.push({ customField, sheetId });
      }
    }

    if (tasks.length === 0) {
      return { priced: false, error: null };
    }

    let stopChecking = false;

    const taskResults = await mapWithConcurrency(
      tasks,
      GYG_GROUP_CONCURRENCY_LIMIT,
      async ({ customField, sheetId }) => {
        if (stopChecking) {
          return { attempted: false, succeeded: false, priced: false };
        }

        const pricingResult = await fetchCustomFieldPricingForEditing(shortname, sheetId, customField.pk);
        if (stopChecking) {
          return { attempted: true, succeeded: pricingResult.ok, priced: false };
        }

        if (!pricingResult.ok) {
          return { attempted: true, succeeded: false, priced: false };
        }

        const priced = evaluateCustomFieldPricing(pricingResult.data, {
          pk: customField.pk,
          name: customField.name,
          sheetId
        });
        if (priced) {
          stopChecking = true;
        }
        return { attempted: true, succeeded: true, priced };
      }
    );

    const fetchAttempts = taskResults.filter((entry) => entry.attempted).length;
    const fetchSuccesses = taskResults.filter((entry) => entry.succeeded).length;
    const foundPriced = taskResults.some((entry) => entry.priced);

    if (foundPriced) {
      return { priced: true, error: null };
    }
    if (fetchAttempts > 0 && fetchSuccesses === 0) {
      return { priced: false, error: "Could not verify custom field pricing." };
    }
    return { priced: false, error: null };
  }

  function getCustomerPrototypeDisplayName(prototype) {
    const name =
      prototype?.display_name ?? prototype?.displayName ?? prototype?.name ?? prototype?.unicode ?? null;
    if (typeof name === "string" && name.trim() !== "") {
      return name.trim();
    }
    return "Unknown";
  }

  function isGygResellerCompanyValue(value) {
    const normalized = normalizeName(value);
    if (!normalized) {
      return false;
    }
    if (normalized === "getyourguide" || normalized === "gyg") {
      return true;
    }
    return normalized.includes("getyourguide");
  }

  function isGygResellerCompany(resellerCompany) {
    const candidates = [
      resellerCompany?.ota_type,
      resellerCompany?.otaType,
      resellerCompany?.name,
      resellerCompany?.short_name,
      resellerCompany?.shortName,
      resellerCompany?.external_identifier,
      resellerCompany?.externalIdentifier
    ];
    return candidates.some((value) => isGygResellerCompanyValue(value));
  }

  function filterGygResellerCompanies(companies) {
    if (!Array.isArray(companies)) {
      return [];
    }
    return companies.filter((company) => isGygResellerCompany(company));
  }

  function isGoogleResellerCompanyValue(value) {
    const normalized = normalizeName(value);
    if (!normalized) {
      return false;
    }
    if (normalized === "google") {
      return true;
    }
    return normalized.includes("google");
  }

  function isGoogleResellerCompany(resellerCompany) {
    const candidates = [
      resellerCompany?.ota_type,
      resellerCompany?.otaType,
      resellerCompany?.name,
      resellerCompany?.short_name,
      resellerCompany?.shortName,
      resellerCompany?.external_identifier,
      resellerCompany?.externalIdentifier
    ];
    return candidates.some((value) => isGoogleResellerCompanyValue(value));
  }

  function filterGoogleResellerCompanies(companies) {
    if (!Array.isArray(companies)) {
      return [];
    }
    return companies.filter((company) => isGoogleResellerCompany(company));
  }

  function getResellerItemLabel(resellerItem) {
    const name =
      resellerItem?.display_name ??
      resellerItem?.displayName ??
      resellerItem?.name ??
      resellerItem?.external_identifier ??
      resellerItem?.externalIdentifier ??
      null;
    if (typeof name === "string" && name.trim() !== "") {
      return name.trim();
    }
    const pk = resellerItem?.pk;
    return pk !== null && pk !== undefined ? String(pk) : "Unknown";
  }

  function formatGygResellerItemResultPrefix(itemLabel, resellerItemPk) {
    return `Item "${itemLabel}" (pk ${resellerItemPk}): `;
  }

  function isGygChannelPath(pathname) {
    return GYG_CHANNEL_PATH_RE.test(pathname || "");
  }

  function parseGygResellerItemIdsFromPath(pathname) {
    const match = (pathname || "").match(GYG_RESELLER_ITEM_IDS_RE);
    if (!match) {
      return null;
    }
    return {
      resellerCompanyId: match[1],
      resellerItemId: match[2]
    };
  }

  function parseItemIdFromResellerItemDom() {
    let link = document.querySelector(".block-list-content.ng-binding");
    if (!link) {
      link = document.querySelector(".block-list-content");
    }
    if (!link) {
      return null;
    }
    const href = link.getAttribute("href") || "";
    const match = href.match(/\/items\/(\d+)/);
    return match ? match[1] : null;
  }

  function buildGygResellerItemApiBase(ctx) {
    return (
      `/api/v1/companies/${encodeURIComponent(ctx.shortname)}` +
      `/reseller-companies/${encodeURIComponent(ctx.resellerCompanyId)}` +
      `/reseller-items/${encodeURIComponent(ctx.resellerItemId)}`
    );
  }

  async function fetchResellerCompanies(shortname) {
    const url = `/api/v1/companies/${encodeURIComponent(shortname)}/reseller-companies/`;
    gygDevLog("[qc-checks] Fetch URL:", url);

    const result = await gygApiGetJson(url);
    if (!result.ok) {
      return { ok: false, companies: null, error: result.error };
    }

    const companies = result.data?.reseller_companies ?? result.data?.resellerCompanies;
    if (!Array.isArray(companies)) {
      return { ok: false, companies: null, error: "Response missing reseller_companies array" };
    }

    return { ok: true, companies, error: null };
  }

  async function fetchResellerItems(shortname, resellerCompanyId) {
    const url =
      `/api/v1/companies/${encodeURIComponent(shortname)}` +
      `/reseller-companies/${encodeURIComponent(resellerCompanyId)}/reseller-items/`;
    gygDevLog("[qc-checks] Fetch URL:", url);

    const result = await gygApiGetJson(url);
    if (!result.ok) {
      return { ok: false, items: null, error: result.error };
    }

    const items = result.data?.reseller_items ?? result.data?.resellerItems;
    if (!Array.isArray(items)) {
      return { ok: false, items: null, error: "Response missing reseller_items array" };
    }

    return { ok: true, items, error: null };
  }

  async function fetchResellerItemMappingsUncached(ctx) {
    const url = `${buildGygResellerItemApiBase(ctx)}/reseller-item-mappings/`;
    gygDevLog("[qc-checks] Fetch URL:", url);

    const result = await gygApiGetJson(url);
    if (!result.ok) {
      return { ok: false, mappings: null, error: result.error };
    }

    const mappings = result.data?.reseller_item_mappings ?? result.data?.resellerItemMappings;
    if (!Array.isArray(mappings)) {
      return { ok: false, mappings: null, error: "Response missing reseller_item_mappings array" };
    }

    return { ok: true, mappings, error: null };
  }

  async function fetchResellerItemMappings(ctx) {
    const cacheKey = getGygResellerItemCacheKey(ctx);
    if (!qcRunCache.resellerItemMappingsByKey) {
      qcRunCache.resellerItemMappingsByKey = {};
    }
    if (qcRunCache.resellerItemMappingsByKey[cacheKey] !== undefined) {
      return qcRunCache.resellerItemMappingsByKey[cacheKey];
    }

    const result = await fetchResellerItemMappingsUncached(ctx);
    qcRunCache.resellerItemMappingsByKey[cacheKey] = result;
    return result;
  }

  async function fetchResellerItemDetail(ctx) {
    const url = `${buildGygResellerItemApiBase(ctx)}/`;
    gygDevLog("[qc-checks] Fetch URL:", url);

    const result = await gygApiGetJson(url);
    if (!result.ok) {
      return { ok: false, resellerItem: null, error: result.error };
    }

    const resellerItem = result.data?.reseller_item ?? result.data?.resellerItem ?? null;
    if (!resellerItem || typeof resellerItem !== "object") {
      return { ok: false, resellerItem: null, error: "Response missing reseller_item object" };
    }

    return { ok: true, resellerItem, error: null };
  }

  async function fetchResellerCustomerTypesUncached(ctx) {
    const url = `${buildGygResellerItemApiBase(ctx)}/reseller-customer-types/`;
    gygDevLog("[qc-checks] Fetch URL:", url);

    const result = await gygApiGetJson(url);
    if (!result.ok) {
      return { ok: false, types: null, error: result.error };
    }

    const types = result.data?.reseller_customer_types ?? result.data?.resellerCustomerTypes;
    if (!Array.isArray(types)) {
      return { ok: false, types: null, error: "Response missing reseller_customer_types array" };
    }

    return { ok: true, types, error: null };
  }

  async function fetchResellerCustomerTypes(ctx) {
    const cacheKey = getGygResellerItemCacheKey(ctx);
    if (!qcRunCache.resellerCustomerTypesByKey) {
      qcRunCache.resellerCustomerTypesByKey = {};
    }
    if (qcRunCache.resellerCustomerTypesByKey[cacheKey] !== undefined) {
      return qcRunCache.resellerCustomerTypesByKey[cacheKey];
    }

    const result = await fetchResellerCustomerTypesUncached(ctx);
    qcRunCache.resellerCustomerTypesByKey[cacheKey] = result;
    return result;
  }

  async function fetchResellerCustomerTypeMappingsUncached(ctx, resellerCustomerTypeId) {
    const url =
      `${buildGygResellerItemApiBase(ctx)}` +
      `/reseller-customer-types/${encodeURIComponent(resellerCustomerTypeId)}` +
      `/reseller-customer-type-mappings/`;
    gygDevLog("[qc-checks] Fetch URL:", url);

    const result = await gygApiGetJson(url);
    if (!result.ok) {
      return { ok: false, mappings: null, error: result.error };
    }

    const mappings =
      result.data?.reseller_customer_type_mappings ?? result.data?.resellerCustomerTypeMappings;
    if (!Array.isArray(mappings)) {
      return { ok: false, mappings: null, error: "Response missing reseller_customer_type_mappings array" };
    }

    return { ok: true, mappings, error: null };
  }

  async function fetchResellerCustomerTypeMappings(ctx, resellerCustomerTypeId) {
    const cacheKey = `${getGygResellerItemCacheKey(ctx)}:${resellerCustomerTypeId}`;
    if (!qcRunCache.resellerCustomerTypeMappingsByKey) {
      qcRunCache.resellerCustomerTypeMappingsByKey = {};
    }
    if (qcRunCache.resellerCustomerTypeMappingsByKey[cacheKey] !== undefined) {
      return qcRunCache.resellerCustomerTypeMappingsByKey[cacheKey];
    }

    const result = await fetchResellerCustomerTypeMappingsUncached(ctx, resellerCustomerTypeId);
    qcRunCache.resellerCustomerTypeMappingsByKey[cacheKey] = result;
    return result;
  }

  async function fetchCustomerPrototypesUncached(shortname, itemId) {
    const url =
      `/api/v1/companies/${encodeURIComponent(shortname)}/items/${encodeURIComponent(itemId)}` +
      `/customer-prototypes/?include-is-inactive=yes`;
    gygDevLog("[qc-checks] Fetch URL:", url);

    const result = await gygApiGetJson(url);
    if (!result.ok) {
      return { ok: false, prototypes: null, error: result.error };
    }

    const prototypes = result.data?.customer_prototypes ?? result.data?.customerPrototypes;
    if (!Array.isArray(prototypes)) {
      return { ok: false, prototypes: null, error: "Response missing customer_prototypes array" };
    }

    return { ok: true, prototypes, error: null };
  }

  async function fetchCustomerPrototypes(shortname, itemId) {
    const cacheKey = getCustomerPrototypesCacheKey(shortname, itemId);
    if (!qcRunCache.customerPrototypesByItemKey) {
      qcRunCache.customerPrototypesByItemKey = {};
    }
    if (qcRunCache.customerPrototypesByItemKey[cacheKey] !== undefined) {
      return qcRunCache.customerPrototypesByItemKey[cacheKey];
    }

    if (!qcRunCache.customerPrototypesPromisesByKey) {
      qcRunCache.customerPrototypesPromisesByKey = {};
    }
    if (!qcRunCache.customerPrototypesPromisesByKey[cacheKey]) {
      qcRunCache.customerPrototypesPromisesByKey[cacheKey] = fetchCustomerPrototypesUncached(shortname, itemId);
    }

    const result = await qcRunCache.customerPrototypesPromisesByKey[cacheKey];
    qcRunCache.customerPrototypesByItemKey[cacheKey] = result;
    return result;
  }

  function getEmbeddedPrototypeFromMapping(mapping) {
    const embedded = mapping?.customer_prototype ?? mapping?.customerPrototype ?? null;
    if (!embedded || typeof embedded !== "object") {
      return null;
    }
    if (!Array.isArray(embedded.custom_field_instances)) {
      return null;
    }
    return embedded;
  }

  async function resolveGygResellerItemContext() {
    const pathname = window.location.pathname || "";
    const shortname = parseCompanyShortname();
    if (!shortname || !isGygChannelPath(pathname)) {
      return null;
    }

    const ids = parseGygResellerItemIdsFromPath(pathname);
    if (!ids) {
      return null;
    }

    const ctx = {
      shortname,
      resellerCompanyId: ids.resellerCompanyId,
      resellerItemId: ids.resellerItemId,
      itemId: null
    };

    const detailResult = await fetchResellerItemDetail(ctx);
    if (detailResult.ok) {
      const item = detailResult.resellerItem?.item ?? null;
      const pk = item?.pk;
      if (pk !== null && pk !== undefined) {
        ctx.itemId = String(pk);
        return ctx;
      }
    }

    const domItemId = parseItemIdFromResellerItemDom();
    if (domItemId) {
      ctx.itemId = domItemId;
      return ctx;
    }

    return null;
  }

  function buildCheckResult({
    key,
    label,
    status,
    value,
    details,
    detailsHtml,
    category,
    severity,
    suppressDisplay
  }) {
    const result = { key, label, status, value, details };
    if (detailsHtml) {
      result.detailsHtml = detailsHtml;
    }
    if (category) result.category = category;
    if (severity) result.severity = severity;
    if (suppressDisplay) result.suppressDisplay = true;
    return result;
  }

  // Keep in sync with popup.js and overlay.js advanced settings path helper
  function isAdvancedSettingsPage() {
    const shortname = parseCompanyShortname();
    if (!shortname) {
      return false;
    }
    const normalized = (window.location.pathname || "/").replace(/\/+$/, "") || "/";
    const expected = `/${shortname}/dashboard/settings/advanced`;
    return normalized === expected;
  }

  function getCheckboxLabelText(checkbox) {
    if (!(checkbox instanceof HTMLInputElement)) {
      return "";
    }

    const id = checkbox.id;
    if (id) {
      const label = document.querySelector(`label[for="${CSS.escape(id)}"]`);
      if (label) {
        return label.textContent || "";
      }
    }

    const parentLabel = checkbox.closest("label");
    if (parentLabel) {
      return parentLabel.textContent || "";
    }

    return "";
  }

  function findCheckboxByNormalizedLabel(expectedNormalizedLabel) {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    for (const checkbox of checkboxes) {
      if (!(checkbox instanceof HTMLInputElement)) {
        continue;
      }
      const labelText = getCheckboxLabelText(checkbox);
      if (normalizeName(labelText) === expectedNormalizedLabel) {
        return checkbox;
      }
    }
    return null;
  }

  function checkTransportationMapping() {
    const base = { ...CHECK_TRANSPORTATION_MAPPING };

    if (!isAdvancedSettingsPage()) {
      console.log("[qc-checks] Transportation mapping check: advanced settings page not loaded");
      return buildCheckResult({
        ...base,
        status: "skip",
        value: null,
        details: "Advanced settings page not loaded; skipping transportation mapping check."
      });
    }

    const transportationCheckbox = findCheckboxByNormalizedLabel(TRANSPORTATION_SETTING_LABEL);
    const mapCustomFieldsCheckbox = findCheckboxByNormalizedLabel(MAP_TRANSPORTATION_CUSTOM_FIELDS_LABEL);

    const transportationFound = transportationCheckbox instanceof HTMLInputElement;
    const mapCustomFieldsFound = mapCustomFieldsCheckbox instanceof HTMLInputElement;
    const transportationChecked = transportationFound && transportationCheckbox.checked === true;
    const mapCustomFieldsChecked = mapCustomFieldsFound && mapCustomFieldsCheckbox.checked === true;

    console.log("[qc-checks] Transportation checkbox found:", transportationFound);
    console.log("[qc-checks] Transportation checkbox checked:", transportationFound ? transportationChecked : null);
    console.log(
      "[qc-checks] Map to transportation custom fields checkbox found:",
      mapCustomFieldsFound
    );
    console.log(
      "[qc-checks] Map to transportation custom fields checkbox checked:",
      mapCustomFieldsFound ? mapCustomFieldsChecked : null
    );

    if (!transportationFound || !mapCustomFieldsFound) {
      return buildCheckResult({
        ...base,
        status: "warning",
        value: null,
        details:
          "Could not find transportation settings on the advanced settings page. Manual confirmation needed."
      });
    }

    if (!transportationChecked && !mapCustomFieldsChecked) {
      return buildCheckResult({
        ...base,
        status: "skip",
        value: null,
        details: "Transportation settings are not enabled; skipping transportation mapping check.",
        suppressDisplay: true
      });
    }

    if (transportationChecked && mapCustomFieldsChecked) {
      return buildCheckResult({
        ...base,
        status: "pass",
        value: true,
        details: "Transportation is enabled and mapped to transportation custom fields."
      });
    }

    if (transportationChecked && !mapCustomFieldsChecked) {
      return buildCheckResult({
        ...base,
        status: "warning",
        value: null,
        details:
          "Transportation is enabled, but transportation custom field mapping is not enabled. Manual confirmation needed."
      });
    }

    return buildCheckResult({
      ...base,
      status: "warning",
      value: null,
      details:
        "Transportation custom field mapping is enabled, but the Transportation module is not enabled. Manual confirmation needed."
    });
  }

  async function apiGetJson(url) {
    try {
      const response = await fetch(url, {
        method: "GET",
        credentials: "include",
        headers: { Accept: "application/json" }
      });

      if (!response.ok) {
        return { ok: false, status: response.status, data: null, error: `API request failed with status ${response.status}` };
      }

      try {
        const data = await response.json();
        return { ok: true, status: response.status, data, error: null };
      } catch (err) {
        return { ok: false, status: response.status, data: null, error: `Response is not valid JSON: ${err.message}` };
      }
    } catch (err) {
      return { ok: false, status: null, data: null, error: `Fetch failed: ${err.message}` };
    }
  }

  async function fetchCancellationPolicies(shortname) {
    const url = `/api/v1/companies/${encodeURIComponent(shortname)}/cancellation-policies/`;
    console.log("[qc-checks] Fetch URL:", url);

    const result = await apiGetJson(url);
    console.log("[qc-checks] Response status:", result.status);

    if (!result.ok) {
      return { ok: false, policies: null, error: result.error };
    }

    console.log("[qc-checks] Object.keys(data):", Object.keys(result.data));
    console.log("[qc-checks] Array.isArray(data.cancellation_policies):", Array.isArray(result.data.cancellation_policies));

    const policies = result.data.cancellation_policies;
    if (!Array.isArray(policies)) {
      console.log("[qc-checks] cancellation_policies missing or not an array");
      return { ok: false, policies: null, error: "Response missing cancellation_policies array" };
    }

    return { ok: true, policies, error: null };
  }

  async function fetchB2bPaymentMethods(shortname) {
    const url = `/api/v1/companies/${encodeURIComponent(shortname)}/payments/b2b-payment-methods/`;
    console.log("[qc-checks] Fetch URL:", url);

    const result = await apiGetJson(url);
    console.log("[qc-checks] Response status:", result.status);

    if (!result.ok) {
      return { ok: false, methods: null, error: result.error };
    }

    const methods = result.data.b2b_payment_methods;
    if (!Array.isArray(methods)) {
      console.log("[qc-checks] b2b_payment_methods missing or not an array");
      return { ok: false, methods: null, error: "Response missing b2b_payment_methods array" };
    }

    console.log("[qc-checks] Number of payment methods found:", methods.length);
    const first = methods[0] || null;
    console.log("[qc-checks] First payment method type:", first?.stripe_payment_method_type ?? null);
    console.log("[qc-checks] First payment method last4:", first?.stripe_payment_method_last4 ?? null);

    return { ok: true, methods, error: null };
  }

  async function fetchPermissionGroups(shortname) {
    const url = `/api/v1/companies/${encodeURIComponent(shortname)}/groups/`;
    console.log("[qc-checks] Groups URL:", url);

    const result = await apiGetJson(url);
    console.log("[qc-checks] Response status:", result.status);

    if (!result.ok) {
      return { ok: false, groups: null, error: result.error };
    }

    const groups = result.data.groups;
    if (!Array.isArray(groups)) {
      console.log("[qc-checks] groups missing or not an array");
      return { ok: false, groups: null, error: "Response missing groups array" };
    }

    console.log("[qc-checks] Number of groups returned:", groups.length);
    return { ok: true, groups, error: null };
  }

  async function fetchCompanyDetail(shortname) {
    const url = `/api/v1/companies/${encodeURIComponent(shortname)}/`;
    console.log("[qc-checks] Company detail URL:", url);

    const result = await apiGetJson(url);
    console.log("[qc-checks] Company detail response status:", result.status);

    if (!result.ok) {
      return { ok: false, company: null, error: result.error };
    }

    const company = result.data?.company ?? null;
    if (!company || typeof company !== "object") {
      console.log("[qc-checks] Company detail missing company object");
      return { ok: false, company: null, error: "Response missing company object" };
    }

    return { ok: true, company, error: null };
  }

  async function fetchLocationsUncached(shortname) {
    const url = `/api/v1/companies/${encodeURIComponent(shortname)}/locations/`;
    console.log("[qc-checks] Google locations fetch URL:", url);

    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, locations: null, error: result.error };
    }

    const locations = result.data?.locations ?? result.data?.Locations;
    if (!Array.isArray(locations)) {
      return { ok: false, locations: null, error: "Response missing locations array" };
    }

    return { ok: true, locations, error: null };
  }

  async function fetchLocations(shortname) {
    if (qcRunCache.locationsByShortname?.[shortname] !== undefined) {
      return qcRunCache.locationsByShortname[shortname];
    }

    if (!qcRunCache.locationsByShortname) {
      qcRunCache.locationsByShortname = {};
    }

    const result = await fetchLocationsUncached(shortname);
    qcRunCache.locationsByShortname[shortname] = result;
    return result;
  }

  async function fetchFareHarborItemDetailUncached(shortname, itemPk) {
    const url = `/api/v1/companies/${encodeURIComponent(shortname)}/items/${encodeURIComponent(itemPk)}/`;
    console.log("[qc-checks] Google item detail fetch URL:", url);

    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, item: null, error: result.error };
    }

    const item = result.data?.item ?? result.data ?? null;
    if (!item || typeof item !== "object") {
      return { ok: false, item: null, error: "Response missing item object" };
    }

    return { ok: true, item, error: null };
  }

  async function fetchFareHarborItemDetail(shortname, itemPk) {
    const cacheKey = `${shortname}:${itemPk}`;
    if (!qcRunCache.itemDetailByKey) {
      qcRunCache.itemDetailByKey = {};
    }
    if (qcRunCache.itemDetailByKey[cacheKey] !== undefined) {
      return qcRunCache.itemDetailByKey[cacheKey];
    }

    const result = await fetchFareHarborItemDetailUncached(shortname, itemPk);
    qcRunCache.itemDetailByKey[cacheKey] = result;
    return result;
  }

  async function fetchGoogleResellerItemDetailUncached(ctx) {
    const url = `${buildGygResellerItemApiBase(ctx)}/?availability_count=yes`;
    console.log("[qc-checks] Google reseller item detail fetch URL:", url);

    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, resellerItem: null, error: result.error };
    }

    const resellerItem = result.data?.reseller_item ?? result.data?.resellerItem ?? null;
    if (!resellerItem || typeof resellerItem !== "object") {
      return { ok: false, resellerItem: null, error: "Response missing reseller_item object" };
    }

    return { ok: true, resellerItem, error: null };
  }

  async function fetchGoogleResellerItemDetail(ctx) {
    const cacheKey = `google-detail:${getGygResellerItemCacheKey(ctx)}`;
    if (!qcRunCache.googleResellerItemDetailByKey) {
      qcRunCache.googleResellerItemDetailByKey = {};
    }
    if (qcRunCache.googleResellerItemDetailByKey[cacheKey] !== undefined) {
      return qcRunCache.googleResellerItemDetailByKey[cacheKey];
    }

    const result = await fetchGoogleResellerItemDetailUncached(ctx);
    qcRunCache.googleResellerItemDetailByKey[cacheKey] = result;
    return result;
  }

  function formatBillingMethodDetails(method) {
    const type = method?.stripe_payment_method_type;
    const last4 = method?.stripe_payment_method_last4;
    if (type && last4) {
      return `Billing method found: ${type} ending in ${last4}`;
    }
    if (type) {
      return `Billing method found: ${type}`;
    }
    if (last4) {
      return `Billing method found: ending in ${last4}`;
    }
    return "Billing method found";
  }

  function findGroupByName(groups, name) {
    return groups.find((g) => g?.name === name) || null;
  }

  function normalizeAffiliateShortname(shortname) {
    if (typeof shortname !== "string") {
      return null;
    }
    const trimmed = shortname.trim().toLowerCase();
    return trimmed !== "" ? trimmed : null;
  }

  function normalizeAffiliateShortnameForMatch(shortname) {
    if (typeof shortname !== "string") {
      return null;
    }
    const normalized = shortname.trim().toLowerCase().replace(/[\s\-_]/g, "");
    return normalized !== "" ? normalized : null;
  }

  function getAffiliateCompanyShortnameRaw(affiliate) {
    const shortname =
      affiliate?.affiliate_company?.shortname ?? affiliate?.affiliateCompany?.shortname ?? null;
    return typeof shortname === "string" ? shortname.trim() : null;
  }

  function getAffiliateCompanyShortname(affiliate) {
    return normalizeAffiliateShortname(getAffiliateCompanyShortnameRaw(affiliate));
  }

  function getAffiliateCompanyShortnameForMatch(affiliate) {
    return normalizeAffiliateShortnameForMatch(getAffiliateCompanyShortnameRaw(affiliate));
  }

  function getAffiliateCompanyName(affiliate) {
    const name = affiliate?.affiliate_company?.name ?? affiliate?.affiliateCompany?.name ?? null;
    return typeof name === "string" ? name.trim() : null;
  }

  function affiliateMatchesIntegrationTokens(affiliate, normalizedTokens) {
    const normalizedShortname = getAffiliateCompanyShortnameForMatch(affiliate);
    if (!normalizedShortname) {
      return false;
    }
    return normalizedTokens.some((token) => normalizedShortname.includes(token));
  }

  function isExactAffiliateTokenMatch(affiliate, normalizedTokens) {
    const normalizedShortname = getAffiliateCompanyShortnameForMatch(affiliate);
    if (!normalizedShortname) {
      return false;
    }
    return normalizedTokens.some((token) => normalizedShortname === token);
  }

  function findAffiliateByIntegration(affiliates, integrationKey) {
    console.log("[qc-checks] affiliate match selected integration:", integrationKey);

    const tokens = OTA_MATCH_TOKENS[integrationKey];
    if (!Array.isArray(tokens) || tokens.length === 0) {
      console.log("[qc-checks] No affiliate match tokens for integration:", integrationKey);
      return null;
    }

    console.log("[qc-checks] affiliate match token(s) used:", tokens);

    const normalizedTokens = tokens
      .map((token) => normalizeAffiliateShortnameForMatch(token))
      .filter((token) => token !== null);

    const matches = (affiliates || []).filter((affiliate) =>
      affiliateMatchesIntegrationTokens(affiliate, normalizedTokens)
    );

    console.log(
      "[qc-checks] affiliate match all matching shortnames:",
      matches.map((affiliate) => getAffiliateCompanyShortnameRaw(affiliate)).filter((shortname) => shortname !== null)
    );

    if (matches.length === 0) {
      return null;
    }

    const exactMatches = matches.filter((affiliate) => isExactAffiliateTokenMatch(affiliate, normalizedTokens));
    const matchType = exactMatches.length > 0 ? "exact" : "substring";
    const selectedPool = exactMatches.length > 0 ? exactMatches : matches;
    const selected = selectedPool[0] || null;

    if (matches.length > 1) {
      console.log(
        "[qc-checks] affiliate match candidates:",
        matches.map((affiliate) => ({
          pk: affiliate?.pk ?? null,
          shortname: getAffiliateCompanyShortnameRaw(affiliate),
          name: getAffiliateCompanyName(affiliate)
        }))
      );
    }

    if (selected) {
      console.log("[qc-checks] affiliate match selected:", {
        pk: selected?.pk ?? null,
        shortname: getAffiliateCompanyShortnameRaw(selected),
        name: getAffiliateCompanyName(selected),
        matchType
      });
    }

    return selected;
  }

  function getAffiliationPk(affiliate) {
    const pk = affiliate?.pk ?? null;
    if (pk === null || pk === undefined) {
      return null;
    }
    return pk;
  }

  function parseAffiliateDetailFromResponse(data) {
    return window.FareHarborAffiliateApi?.parseAffiliateDetailFromResponse(data) ?? null;
  }

  async function fetchAffiliateDetail(shortname, affiliationPk) {
    const api = window.FareHarborAffiliateApi;
    if (!api) {
      return { ok: false, detail: null, error: "FareHarborAffiliateApi not loaded" };
    }
    return api.fetchAffiliateDetail(shortname, affiliationPk);
  }

  function runAffiliateValidators(detail, config, context = {}) {
    const mismatches = [];

    for (const validator of config.validators) {
      const result = validator.validate(detail, context);
      const ok = result.ok === true;
      console.log(`[qc-checks] affiliate settings field: ${validator.label} ok=${ok}`);
      if (!ok && result.mismatch) {
        console.log(`[qc-checks] affiliate settings field mismatch: ${validator.label}`, result.mismatch);
        mismatches.push(result.mismatch);
      }
    }

    console.log("[qc-checks] affiliate settings mismatches:", mismatches);
    return mismatches;
  }

  async function fetchAllNetworkAffiliatesUncached(shortname) {
    try {
      const allResults = [];
      let page = 1;
      let totalPages = 1;

      while (page <= totalPages) {
        const url = `/api-affiliations-v2/companies/${encodeURIComponent(shortname)}/affiliates/?page=${page}&page_size=50`;
        console.log("[qc-checks] Affiliates full URL:", url);

        const result = await apiGetJson(url);
        console.log("[qc-checks] Affiliates response status:", result.status);

        if (!result.ok) {
          throw new Error(result.error || `Affiliates API request failed with status ${result.status}`);
        }

        const data = result.data;
        if (!data || typeof data !== "object") {
          throw new Error("Affiliates API response is not a valid object");
        }

        console.log("[qc-checks] Affiliates response keys:", Object.keys(data));

        if (page === 1) {
          const reportedTotalPages = Number(data.total_pages);
          totalPages =
            Number.isFinite(reportedTotalPages) && reportedTotalPages >= 1 ? reportedTotalPages : 1;
          console.log("[qc-checks] Affiliates total_pages:", totalPages);
        }

        const pageResults = data.results;
        if (!Array.isArray(pageResults)) {
          throw new Error("Affiliates API response missing results array");
        }

        allResults.push(...pageResults);
        page += 1;
      }

      console.log("[qc-checks] Total affiliates fetched:", allResults.length);
      return { ok: true, affiliates: allResults, error: null };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      console.error("[qc-checks] Affiliates fetch failed:", message);
      return { ok: false, affiliates: null, error: message };
    }
  }

  async function fetchAllNetworkAffiliates(shortname) {
    if (qcRunCache.affiliatesResult !== undefined) {
      return qcRunCache.affiliatesResult;
    }

    if (!qcRunCache.affiliatesPromise) {
      qcRunCache.affiliatesPromise = fetchAllNetworkAffiliatesUncached(shortname);
    }

    const result = await qcRunCache.affiliatesPromise;
    qcRunCache.affiliatesResult = result;
    return result;
  }

  async function getCompanyDetail(shortname) {
    if (qcRunCache.companyDetailResult !== undefined) {
      return qcRunCache.companyDetailResult;
    }

    if (!qcRunCache.companyDetailPromise) {
      qcRunCache.companyDetailPromise = fetchCompanyDetail(shortname);
    }

    const result = await qcRunCache.companyDetailPromise;
    qcRunCache.companyDetailResult = result;
    return result;
  }

  async function getDefaultApiCancellationPolicyPk(shortname) {
    if (qcRunCache.defaultApiPolicyPkResolved) {
      return { pk: qcRunCache.defaultApiPolicyPk, error: qcRunCache.defaultApiPolicyPkError };
    }

    if (!qcRunCache.defaultApiPolicyPkPromise) {
      qcRunCache.defaultApiPolicyPkPromise = (async () => {
        const { ok, policies, error } = await fetchCancellationPolicies(shortname);
        if (!ok) {
          qcRunCache.defaultApiPolicyPkError = error;
          qcRunCache.defaultApiPolicyPk = null;
          console.error("[qc-checks] Default - API policy pk lookup failed:", error);
        } else {
          const policy = findDefaultApiCancellationPolicy(policies);
          qcRunCache.defaultApiPolicyPk = policy?.pk ?? null;
          qcRunCache.defaultApiPolicyPkError = null;
          console.log("[qc-checks] Default - API policy pk:", qcRunCache.defaultApiPolicyPk);
        }
        qcRunCache.defaultApiPolicyPkResolved = true;
      })();
    }

    await qcRunCache.defaultApiPolicyPkPromise;
    return { pk: qcRunCache.defaultApiPolicyPk, error: qcRunCache.defaultApiPolicyPkError };
  }

  function formatExpectedAffiliateShortnames(integrationKey) {
    const tokens = OTA_MATCH_TOKENS[integrationKey];
    if (!Array.isArray(tokens) || tokens.length === 0) {
      return "unknown";
    }
    return `shortname includes "${tokens.join('" or "')}"`;
  }

  async function checkAffiliateExists(integrationKey, checkMeta) {
    const base = { ...checkMeta, category: "Affiliates", severity: "critical" };
    const shortname = parseCompanyShortname();

    if (!shortname) {
      console.log("[qc-checks] Could not parse company shortname from:", window.location.pathname);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `Could not parse company shortname from URL: ${window.location.pathname}`
      });
    }

    const { ok, affiliates, error } = await fetchAllNetworkAffiliates(shortname);
    if (!ok) {
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: error
      });
    }

    const affiliate = findAffiliateByIntegration(affiliates, integrationKey);
    if (affiliate) {
      const affiliateShortname = getAffiliateCompanyShortnameRaw(affiliate);
      return buildCheckResult({
        ...base,
        status: "pass",
        value: true,
        details: `Found affiliate "${affiliateShortname}".`
      });
    }

    return buildCheckResult({
      ...base,
      status: "fail",
      value: false,
      details: `No affiliate found (expected shortnames: ${formatExpectedAffiliateShortnames(integrationKey)}).`
    });
  }

  async function checkAffiliateSettings(integrationKey, checkMeta) {
    const base = { ...checkMeta, category: "Affiliates", severity: "critical" };
    const config = OTA_AFFILIATE_CONFIG[integrationKey];

    console.log("[qc-checks] selected integration:", integrationKey);

    if (!config) {
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `No affiliate settings configuration for integration "${integrationKey}".`
      });
    }

    const shortname = parseCompanyShortname();

    if (!shortname) {
      console.log("[qc-checks] Could not parse company shortname from:", window.location.pathname);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `Could not parse company shortname from URL: ${window.location.pathname}`
      });
    }

    const { ok, affiliates, error } = await fetchAllNetworkAffiliates(shortname);
    if (!ok) {
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: error
      });
    }

    const affiliate = findAffiliateByIntegration(affiliates, integrationKey);
    if (!affiliate) {
      return buildCheckResult({
        ...base,
        status: "fail",
        value: false,
        details: `Affiliate not found (expected shortnames: ${formatExpectedAffiliateShortnames(integrationKey)}).`
      });
    }

    const affiliationPk = getAffiliationPk(affiliate);
    console.log("[qc-checks] matched affiliate pk:", affiliationPk);

    if (affiliationPk === null) {
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: "Affiliate list entry is missing affiliation pk."
      });
    }

    const { ok: detailOk, detail, error: detailError } = await fetchAffiliateDetail(shortname, affiliationPk);
    if (!detailOk) {
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: detailError
      });
    }

    const [totalSheetsResult, totalSchedulesResult] = await Promise.all([
      fetchTotalSheets(shortname),
      fetchTotalSchedules(shortname)
    ]);
    const resolutionSources = buildPricingResolutionSources({
      affiliation: detail,
      affiliateListRow: affiliate,
      totalSheets: totalSheetsResult.ok ? totalSheetsResult.sheets : [],
      totalSchedules: totalSchedulesResult.ok ? totalSchedulesResult.schedules : []
    });
    const selectedPricing = getSelectedPricingDisplay(detail, affiliate, resolutionSources);
    const validatorContext = {
      selectedPricing,
      resolutionSources,
      affiliateListRow: affiliate,
      integrationKey
    };

    const mismatches = runAffiliateValidators(detail, config, validatorContext);

    if (mismatches.length === 0) {
      return buildCheckResult({
        ...base,
        status: "pass",
        value: true,
        details: "All affiliate settings match expected configuration."
      });
    }

    return buildCheckResult({
      ...base,
      status: "fail",
      value: false,
      details: mismatches.join("; ")
    });
  }

  async function resolveAffiliateDetailForIntegration(integrationKey) {
    const shortname = parseCompanyShortname();
    if (!shortname) {
      return {
        ok: false,
        detail: null,
        affiliate: null,
        shortname: null,
        error: `Could not parse company shortname from URL: ${window.location.pathname}`
      };
    }

    const { ok, affiliates, error } = await fetchAllNetworkAffiliates(shortname);
    if (!ok) {
      return { ok: false, detail: null, affiliate: null, shortname, error };
    }

    const affiliate = findAffiliateByIntegration(affiliates, integrationKey);
    if (!affiliate) {
      return {
        ok: false,
        detail: null,
        affiliate: null,
        shortname,
        error: `Affiliate not found (expected shortnames: ${formatExpectedAffiliateShortnames(integrationKey)}).`
      };
    }

    const affiliationPk = getAffiliationPk(affiliate);
    if (affiliationPk === null) {
      return {
        ok: false,
        detail: null,
        affiliate: null,
        shortname,
        error: "Affiliate list entry is missing affiliation pk."
      };
    }

    const detailResult = await fetchAffiliateDetail(shortname, affiliationPk);
    if (!detailResult.ok) {
      return {
        ok: false,
        detail: null,
        affiliate: null,
        shortname,
        error: detailResult.error
      };
    }

    return {
      ok: true,
      detail: detailResult.detail,
      affiliate,
      shortname,
      error: null
    };
  }

  async function checkViatorInvoicePricingZeroCommissionWarning() {
    const base = { ...CHECK_VIATOR_INVOICE_PRICING_ZERO_COMMISSION_WARNING };
    const detailResult = await resolveAffiliateDetailForIntegration("viator");
    if (!detailResult.ok) {
      return buildCheckResult({
        ...base,
        status: "warning",
        value: null,
        details: `Could not verify Viator invoice pricing percentage. ${detailResult.error}`
      });
    }

    const { sheetSignal, scheduleSignal } = getViatorInvoicePricingSignals(detailResult.detail);
    const hasZeroCommissionSignal = sheetSignal?.value === 100 || scheduleSignal?.value === 100;

    if (hasZeroCommissionSignal) {
      return buildCheckResult({
        ...base,
        status: "warning",
        value: 100,
        details:
          "Viator invoice pricing appears to be 0% commission. Double-check whether commission is added at item level."
      });
    }

    return buildCheckResult({
      ...base,
      status: "pass",
      value: null,
      details: "Viator invoice pricing does not indicate 0% commission from sheet/schedule percentage fields."
    });
  }

  async function checkViatorPricingSheetAssignmentWarning() {
    const base = { ...CHECK_VIATOR_PRICING_SHEET_ASSIGNMENT_WARNING };
    const detailResult = await resolveAffiliateDetailForIntegration("viator");
    if (!detailResult.ok) {
      return buildCheckResult({
        ...base,
        status: "warning",
        value: null,
        details: `Could not verify Viator pricing assignment. ${detailResult.error}`
      });
    }

    const availablePricingResult = await fetchAvailableTotalPricingObjects(detailResult.shortname);
    if (!availablePricingResult.ok) {
      console.log("[qc-checks] Viator pricing availability check not verifiable:", {
        endpointMapped: availablePricingResult.endpointMapped,
        error: availablePricingResult.error
      });
      return buildCheckResult({
        ...base,
        status: "warning",
        value: null,
        details: `Could not verify Viator pricing assignment. ${availablePricingResult.error}`
      });
    }

    const integrationKey = "viator";
    const resolutionSources = buildPricingResolutionSources({
      affiliation: detailResult.detail,
      affiliateListRow: detailResult.affiliate,
      totalSheets: availablePricingResult.sheets,
      totalSchedules: availablePricingResult.schedules
    });
    const selectedPricing = getSelectedPricingDisplay(
      detailResult.detail,
      detailResult.affiliate,
      resolutionSources
    );

    const otaSpecificSheetsForMatching = getOtaSpecificTotalSheetsForMatching(
      availablePricingResult.sheets,
      integrationKey
    );
    const otaSpecificSchedulesForMatching = getOtaSpecificTotalSchedulesForMatching(
      availablePricingResult.schedules,
      integrationKey
    );
    const availablePricingLines = collectOtaSpecificAvailablePricingLines(
      availablePricingResult.sheets,
      availablePricingResult.schedules,
      integrationKey
    );

    const selectedPricingLines = [];
    if (selectedPricing.name) {
      selectedPricingLines.push(
        formatPricingLine(selectedPricing.name, selectedPricing.type || "Total Sheet")
      );
    }
    const selectedInvoiceSheet = detailResult.detail?.default_invoice_sheet ?? null;
    if (selectedInvoiceSheet) {
      const invoiceSheetName = resolvePricingObjectDisplayName(selectedInvoiceSheet, resolutionSources);
      if (invoiceSheetName) {
        selectedPricingLines.push(formatPricingLine(invoiceSheetName, "Invoice Sheet"));
      }
    }

    console.log("[qc-checks] Viator selected pricing (resolved):", selectedPricing);
    console.log("[qc-checks] Viator selected pricing lines:", selectedPricingLines);
    console.log("[qc-checks] Viator available OTA-specific pricing lines:", availablePricingLines);

    const otaSpecificExists = hasOtaSpecificPricingAvailable(
      availablePricingResult.sheets,
      availablePricingResult.schedules,
      integrationKey
    );
    if (!otaSpecificExists) {
      return buildCheckResult({
        ...base,
        status: "pass",
        value: true,
        details: "No Viator-specific total price sheet or schedule found; nothing to compare."
      });
    }

    const selectedPricingRef = { uri: selectedPricing.uri, pk: selectedPricing.pk };
    const hasSelectedPricingRef = selectedPricing.uri != null || selectedPricing.pk != null;
    const selectedMatchesAny =
      hasSelectedPricingRef &&
      (otaSpecificSheetsForMatching.some((sheet) => pricingObjectsMatch(selectedPricingRef, sheet)) ||
        otaSpecificSchedulesForMatching.some((schedule) =>
          pricingObjectsMatch(selectedPricingRef, schedule)
        ));

    if (!selectedMatchesAny) {
      return buildCheckResult({
        ...base,
        status: "warning",
        value: null,
        details: buildOtaPricingAssignmentWarningDetails({
          otaLabel: "Viator",
          selectedLines: selectedPricingLines,
          availableLines: availablePricingLines
        })
      });
    }

    return buildCheckResult({
      ...base,
      status: "pass",
      value: true,
      details: "Viator-specific pricing is assigned."
    });
  }

  async function evaluateGygGroupMappingPhase1(ctx, itemLabel, resellerItemPk) {
    const prefix = formatGygResellerItemResultPrefix(itemLabel, resellerItemPk);
    const baseItem = { itemLabel, resellerItemPk: String(resellerItemPk) };

    const itemMappingsResult = await fetchResellerItemMappings(ctx);
    if (!itemMappingsResult.ok) {
      return {
        kind: "final",
        result: {
          ...baseItem,
          status: "error",
          line: `${prefix}Could not verify item mapping. ${itemMappingsResult.error}`
        }
      };
    }

    const mappedItemPk = itemMappingsResult.mappings[0]?.item?.pk ?? null;
    if (!itemMappingsResult.mappings.length || mappedItemPk === null || mappedItemPk === undefined) {
      return {
        kind: "final",
        result: buildGygGroupItemResult({
          ...baseItem,
          status: "warning",
          reason: "no_item_mapping",
          line: `${prefix}No FareHarbor item mapping found.`
        })
      };
    }

    const itemCtx = {
      ...ctx,
      itemId: String(mappedItemPk)
    };

    const typesResult = await fetchResellerCustomerTypes(itemCtx);
    if (!typesResult.ok) {
      return {
        kind: "final",
        result: {
          ...baseItem,
          status: "error",
          line: `${prefix}Could not verify GetYourGuide Group ticket category. ${typesResult.error}`
        }
      };
    }

    const groupType = typesResult.types.find((type) => isGroupTicketCategory(type));
    if (!groupType) {
      return {
        kind: "final",
        result: {
          status: "no_group",
          line: null
        }
      };
    }

    const resellerTypeName = getResellerCustomerTypeDisplayName(groupType);
    const groupCategoryContext = formatGygGroupCategoryConfiguredOn(resellerTypeName);
    const commonItem = { ...baseItem, resellerCustomerTypeName: resellerTypeName };

    const groupTypePk = groupType?.pk;
    if (groupTypePk === null || groupTypePk === undefined) {
      return {
        kind: "final",
        result: {
          ...commonItem,
          status: "error",
          line: `${prefix}GetYourGuide Group ticket category is missing a pk.`
        }
      };
    }

    const mappingsResult = await fetchResellerCustomerTypeMappings(itemCtx, groupTypePk);
    if (!mappingsResult.ok) {
      return {
        kind: "final",
        result: {
          ...commonItem,
          status: "error",
          line: `${prefix}Could not verify GetYourGuide Group ticket category mapping. ${mappingsResult.error}`
        }
      };
    }

    if (mappingsResult.mappings.length === 0) {
      return {
        kind: "final",
        result: buildGygGroupItemResult({
          ...commonItem,
          status: "warning",
          reason: "no_customer_type_mapping",
          line: `${prefix}${groupCategoryContext}, but is not mapped to a FareHarbor customer type. Please check this setup manually.`
        })
      };
    }

    const mapping = mappingsResult.mappings[0];
    const mappedPrototypePk =
      mapping?.customer_prototype?.pk ?? mapping?.customerPrototype?.pk ?? null;
    if (mappedPrototypePk === null || mappedPrototypePk === undefined) {
      return {
        kind: "final",
        result: buildGygGroupItemResult({
          ...commonItem,
          status: "warning",
          reason: "missing_prototype_pk",
          line: `${prefix}${groupCategoryContext}, but the mapping is missing a customer prototype pk. Please check this setup manually.`
        })
      };
    }

    return {
      kind: "needsPricingCheck",
      prefix,
      commonItem,
      itemCtx,
      mappedPrototypePk: String(mappedPrototypePk),
      groupCategoryContext,
      embeddedPrototype: getEmbeddedPrototypeFromMapping(mapping)
    };
  }

  function buildGygGroupPricingItemResult({
    prefix,
    commonItem,
    groupCategoryContext,
    prototypeName,
    pricedFieldResult
  }) {
    if (pricedFieldResult.error) {
      return {
        ...commonItem,
        status: "error",
        line: `${prefix}${pricedFieldResult.error}`
      };
    }

    if (pricedFieldResult.priced) {
      return buildGygGroupItemResult({
        ...commonItem,
        status: "warning",
        reason: "priced_custom_field",
        mappedTo: prototypeName,
        line: `${prefix}${groupCategoryContext}, mapped to ${prototypeName}, and that customer type has a priced custom field. Please check this setup manually.`
      });
    }

    return buildGygGroupItemResult({
      ...commonItem,
      status: "pass",
      reason: "no_priced_custom_fields",
      mappedTo: prototypeName,
      line: `${prefix}${groupCategoryContext}, mapped to ${prototypeName}, and no priced custom fields were found.`
    });
  }

  async function resolvePrototypePricingCheck({
    shortname,
    itemId,
    mappedPrototypePk,
    embeddedPrototype,
    sheetsToCheck
  }) {
    trackGygPrototypeChecked(mappedPrototypePk);

    let mappedPrototype = embeddedPrototype;

    if (!mappedPrototype || String(mappedPrototype.pk) !== String(mappedPrototypePk)) {
      const prototypesResult = await fetchCustomerPrototypes(shortname, itemId);
      if (!prototypesResult.ok) {
        return {
          status: "prototype_fetch_error",
          error: prototypesResult.error
        };
      }

      mappedPrototype = prototypesResult.prototypes.find(
        (prototype) => String(prototype?.pk) === String(mappedPrototypePk)
      );
      if (!mappedPrototype) {
        return {
          status: "prototype_not_found",
          mappedPrototypePk
        };
      }
    }

    const pricedFieldResult = await prototypeHasPricedCustomFieldViaPricingApi(
      shortname,
      mappedPrototype,
      sheetsToCheck
    );

    return {
      status: "ok",
      mappedPrototype,
      prototypeName: getCustomerPrototypeDisplayName(mappedPrototype),
      pricedFieldResult
    };
  }

  function aggregateGygGroupCheckResults(itemResults) {
    const details = formatGetYourGuideGroupTicketCategoryMappingWarning(itemResults);
    const detailsHtml = formatGetYourGuideGroupTicketCategoryMappingDetailsHtml(itemResults);

    const hasError = itemResults.some((result) => result.status === "error");
    const hasWarning = itemResults.some((result) => result.status === "warning");

    if (hasError) {
      return { status: "error", value: null, details, detailsHtml };
    }
    if (hasWarning) {
      return { status: "warning", value: null, details, detailsHtml };
    }
    if (itemResults.some((result) => result.status === "pass")) {
      return { status: "pass", value: true, details, detailsHtml };
    }
    return { status: "warning", value: null, details, detailsHtml };
  }

  async function discoverGygResellerItems(shortname, urlContextFilter) {
    const companiesResult = await fetchResellerCompanies(shortname);
    if (!companiesResult.ok) {
      return { ok: false, gygCompanies: [], items: [], error: companiesResult.error };
    }

    const gygCompanies = filterGygResellerCompanies(companiesResult.companies);
    if (gygCompanies.length === 0) {
      return { ok: true, gygCompanies: [], items: [], error: null };
    }

    const items = [];
    for (const company of gygCompanies) {
      const companyPk = company?.pk;
      if (companyPk === null || companyPk === undefined) {
        continue;
      }

      const itemsResult = await fetchResellerItems(shortname, companyPk);
      if (!itemsResult.ok) {
        return { ok: false, gygCompanies, items: [], error: itemsResult.error };
      }

      for (const resellerItem of itemsResult.items) {
        const resellerItemPk = resellerItem?.pk;
        if (resellerItemPk === null || resellerItemPk === undefined) {
          continue;
        }
        if (
          urlContextFilter &&
          String(resellerItemPk) !== String(urlContextFilter.resellerItemId)
        ) {
          continue;
        }

        items.push({
          shortname,
          resellerCompanyId: String(companyPk),
          resellerItemId: String(resellerItemPk),
          itemId: null,
          resellerItem
        });
      }
    }

    return { ok: true, gygCompanies, items, error: null };
  }

  function isGoogleChannelPath(pathname) {
    return GOOGLE_CHANNEL_PATH_RE.test(pathname || "");
  }

  function parseGoogleResellerItemIdsFromPath(pathname) {
    const legacyMatch = (pathname || "").match(GYG_RESELLER_ITEM_IDS_RE);
    if (legacyMatch) {
      return {
        resellerCompanyId: legacyMatch[1],
        resellerItemId: legacyMatch[2]
      };
    }

    const numericMatch = (pathname || "").match(GOOGLE_CHANNEL_NUMERIC_PATH_RE);
    if (numericMatch) {
      return {
        resellerCompanyId: numericMatch[1],
        resellerItemId: numericMatch[2]
      };
    }

    return null;
  }

  async function resolveGoogleResellerItemContext() {
    const pathname = window.location.pathname || "";
    const shortname = parseCompanyShortname();
    if (!shortname) {
      return null;
    }

    const isLegacyGooglePath = isGoogleChannelPath(pathname);
    const isNumericChannelPath = GOOGLE_CHANNEL_NUMERIC_PATH_RE.test(pathname);
    if (!isLegacyGooglePath && !isNumericChannelPath) {
      return null;
    }

    const ids = parseGoogleResellerItemIdsFromPath(pathname);
    if (!ids) {
      return null;
    }

    if (isNumericChannelPath && !isLegacyGooglePath) {
      const companiesResult = await fetchResellerCompanies(shortname);
      if (!companiesResult.ok) {
        return null;
      }
      const googleCompanies = filterGoogleResellerCompanies(companiesResult.companies);
      const matchingCompany = googleCompanies.find(
        (company) => String(company?.pk) === String(ids.resellerCompanyId)
      );
      if (!matchingCompany) {
        return null;
      }
    }

    return {
      shortname,
      resellerCompanyId: ids.resellerCompanyId,
      resellerItemId: ids.resellerItemId,
      itemId: null
    };
  }

  async function discoverGoogleResellerItems(shortname, urlContextFilter) {
    const companiesResult = await fetchResellerCompanies(shortname);
    if (!companiesResult.ok) {
      return { ok: false, googleCompanies: [], items: [], error: companiesResult.error };
    }

    const googleCompanies = filterGoogleResellerCompanies(companiesResult.companies);
    if (googleCompanies.length === 0) {
      return { ok: true, googleCompanies: [], items: [], error: null };
    }

    const items = [];
    for (const company of googleCompanies) {
      const companyPk = company?.pk;
      if (companyPk === null || companyPk === undefined) {
        continue;
      }

      const itemsResult = await fetchResellerItems(shortname, companyPk);
      if (!itemsResult.ok) {
        return { ok: false, googleCompanies, items: [], error: itemsResult.error };
      }

      for (const resellerItem of itemsResult.items) {
        const resellerItemPk = resellerItem?.pk;
        if (resellerItemPk === null || resellerItemPk === undefined) {
          continue;
        }
        if (
          urlContextFilter &&
          String(resellerItemPk) !== String(urlContextFilter.resellerItemId)
        ) {
          continue;
        }

        items.push({
          shortname,
          resellerCompanyId: String(companyPk),
          resellerItemId: String(resellerItemPk),
          itemId: null,
          resellerItem
        });
      }
    }

    return { ok: true, googleCompanies, items, error: null };
  }

  function buildLocationsByPk(locations) {
    const map = new Map();
    for (const location of locations || []) {
      const pk = location?.pk ?? location?.id;
      if (pk !== null && pk !== undefined) {
        map.set(String(pk), location);
      }
    }
    return map;
  }

  function getLocationDisplayName(location) {
    const name =
      location?.name ??
      location?.display_name ??
      location?.displayName ??
      location?.unicode ??
      null;
    if (typeof name === "string" && name.trim() !== "") {
      return name.trim();
    }
    const pk = location?.pk ?? location?.id;
    return pk !== null && pk !== undefined ? `Location pk ${pk}` : "Unknown location";
  }

  function getLocationGooglePlaceId(location) {
    return location?.google_place_id ?? location?.googlePlaceId ?? null;
  }

  function extractLocationPkFromObject(obj) {
    if (!obj || typeof obj !== "object") {
      return null;
    }

    const location = obj.location ?? obj.Location ?? null;
    const primaryLocation = obj.primary_location ?? obj.primaryLocation ?? null;
    const defaultLocation = obj.default_location ?? obj.defaultLocation ?? null;

    if (obj.location_pk !== null && obj.location_pk !== undefined) {
      return String(obj.location_pk);
    }
    if (obj.locationPk !== null && obj.locationPk !== undefined) {
      return String(obj.locationPk);
    }

    for (const candidate of [location, primaryLocation, defaultLocation]) {
      if (candidate && typeof candidate === "object") {
        const pk = candidate.pk ?? candidate.id;
        if (pk !== null && pk !== undefined) {
          return String(pk);
        }
      }
    }

    const locations = obj.locations ?? obj.Locations ?? null;
    if (Array.isArray(locations)) {
      for (const entry of locations) {
        if (entry && typeof entry === "object") {
          const pk = entry.pk ?? entry.id;
          if (pk !== null && pk !== undefined) {
            return String(pk);
          }
        }
      }
    }

    if (typeof location === "number") {
      return String(location);
    }
    if (typeof location === "string" && /^\d+$/.test(location.trim())) {
      return String(location.trim());
    }

    return null;
  }

  function getEmbeddedLocationObject(obj) {
    if (!obj || typeof obj !== "object") {
      return null;
    }
    const location = obj.location ?? obj.Location ?? null;
    const primaryLocation = obj.primary_location ?? obj.primaryLocation ?? null;
    const defaultLocation = obj.default_location ?? obj.defaultLocation ?? null;
    for (const candidate of [location, primaryLocation, defaultLocation]) {
      if (candidate && typeof candidate === "object") {
        return candidate;
      }
    }
    const locations = obj.locations ?? obj.Locations ?? null;
    if (Array.isArray(locations)) {
      for (const entry of locations) {
        if (entry && typeof entry === "object") {
          return entry;
        }
      }
    }
    return null;
  }

  function identifyDashboardPrimaryLocation(company, locations) {
    const locationsList = Array.isArray(locations) ? locations : [];

    const companyLocation =
      company?.primary_location ??
      company?.primaryLocation ??
      company?.default_location ??
      company?.defaultLocation ??
      null;

    if (companyLocation && typeof companyLocation === "object") {
      const pk = companyLocation.pk ?? companyLocation.id;
      if (pk !== null && pk !== undefined) {
        return { confident: true, locationPk: String(pk), embeddedLocation: companyLocation };
      }
    }
    if (
      companyLocation !== null &&
      companyLocation !== undefined &&
      (typeof companyLocation === "number" || /^\d+$/.test(String(companyLocation).trim()))
    ) {
      return { confident: true, locationPk: String(companyLocation), embeddedLocation: null };
    }

    const primaryFlagged = locationsList.filter(
      (location) =>
        location?.is_primary === true ||
        location?.primary === true ||
        location?.isPrimary === true
    );
    if (primaryFlagged.length === 1) {
      const pk = primaryFlagged[0]?.pk ?? primaryFlagged[0]?.id;
      if (pk !== null && pk !== undefined) {
        return { confident: true, locationPk: String(pk), embeddedLocation: primaryFlagged[0] };
      }
    }
    if (primaryFlagged.length > 1) {
      return { confident: false, locationPk: null, embeddedLocation: null };
    }

    if (locationsList.length === 1) {
      const pk = locationsList[0]?.pk ?? locationsList[0]?.id;
      if (pk !== null && pk !== undefined) {
        return { confident: true, locationPk: String(pk), embeddedLocation: locationsList[0] };
      }
    }

    return { confident: false, locationPk: null, embeddedLocation: null };
  }

  function resolveLocationRecord(locationPk, locationsByPk, embeddedLocation) {
    if (locationPk) {
      const fromMap = locationsByPk.get(String(locationPk));
      if (fromMap) {
        return fromMap;
      }
    }
    if (embeddedLocation && typeof embeddedLocation === "object") {
      return embeddedLocation;
    }
    return null;
  }

  function getFareHarborItemDisplayName(item) {
    const name = item?.name ?? item?.unicode ?? item?.display_name ?? item?.displayName ?? null;
    if (typeof name === "string" && name.trim() !== "") {
      return name.trim();
    }
    const pk = item?.pk ?? item?.id;
    return pk !== null && pk !== undefined ? `Item pk ${pk}` : "Unknown item";
  }

  function extractLocationPkFromMappingRowOnly(mappingRow) {
    if (!mappingRow || typeof mappingRow !== "object") {
      return null;
    }

    const location = mappingRow.location ?? mappingRow.Location ?? null;
    const primaryLocation = mappingRow.primary_location ?? mappingRow.primaryLocation ?? null;
    const defaultLocation = mappingRow.default_location ?? mappingRow.defaultLocation ?? null;

    if (mappingRow.location_pk !== null && mappingRow.location_pk !== undefined) {
      return String(mappingRow.location_pk);
    }
    if (mappingRow.locationPk !== null && mappingRow.locationPk !== undefined) {
      return String(mappingRow.locationPk);
    }

    for (const candidate of [location, primaryLocation, defaultLocation]) {
      if (candidate && typeof candidate === "object") {
        const pk = candidate.pk ?? candidate.id;
        if (pk !== null && pk !== undefined) {
          return String(pk);
        }
      }
    }

    if (typeof location === "number") {
      return String(location);
    }
    if (typeof location === "string" && /^\d+$/.test(location.trim())) {
      return String(location.trim());
    }

    return null;
  }

  function getEmbeddedLocationObjectFromMappingRow(mappingRow) {
    if (!mappingRow || typeof mappingRow !== "object") {
      return null;
    }
    const location = mappingRow.location ?? mappingRow.Location ?? null;
    const primaryLocation = mappingRow.primary_location ?? mappingRow.primaryLocation ?? null;
    const defaultLocation = mappingRow.default_location ?? mappingRow.defaultLocation ?? null;
    for (const candidate of [location, primaryLocation, defaultLocation]) {
      if (candidate && typeof candidate === "object") {
        return candidate;
      }
    }
    return null;
  }

  function extractGoogleResellerItemMappingLocationPk(resellerItem) {
    if (!resellerItem || typeof resellerItem !== "object") {
      return null;
    }
    return extractLocationPkFromObject({
      location: resellerItem.location ?? resellerItem.Location ?? null,
      primary_location: resellerItem.primary_location ?? resellerItem.primaryLocation ?? null,
      default_location: resellerItem.default_location ?? resellerItem.defaultLocation ?? null,
      location_pk: resellerItem.location_pk ?? resellerItem.locationPk ?? null
    });
  }

  function getEmbeddedGoogleResellerItemMappingLocation(resellerItem) {
    if (!resellerItem || typeof resellerItem !== "object") {
      return null;
    }
    return getEmbeddedLocationObject({
      location: resellerItem.location ?? resellerItem.Location ?? null,
      primary_location: resellerItem.primary_location ?? resellerItem.primaryLocation ?? null,
      default_location: resellerItem.default_location ?? resellerItem.defaultLocation ?? null
    });
  }

  function logIgnoredMappedFareHarborItemLocation(itemName, mappedItem) {
    const ignoredPk = extractLocationPkFromObject(mappedItem);
    if (!ignoredPk) {
      return;
    }
    console.log(
      "[qc-checks] Ignoring mapped FareHarbor item dashboard location:",
      itemName,
      `(pk ${ignoredPk})`
    );
  }

  function resolveGoogleMappedItemLocation({
    mappingRow,
    resellerItem,
    dashboardPrimaryLocation,
    locationsByPk,
    itemName,
    mappedItem
  }) {
    logIgnoredMappedFareHarborItemLocation(itemName, mappedItem);

    const mappingRowPk = extractLocationPkFromMappingRowOnly(mappingRow);
    const mappingRowEmbedded = getEmbeddedLocationObjectFromMappingRow(mappingRow);
    if (mappingRowPk) {
      console.log("[qc-checks] Google mapping location found:", itemName);
      console.log("[qc-checks] Google mapping location pk:", mappingRowPk);
      const resolvedLocation = resolveLocationRecord(mappingRowPk, locationsByPk, mappingRowEmbedded);
      const googlePlaceId = resolvedLocation ? getLocationGooglePlaceId(resolvedLocation) : null;
      return {
        resolvedLocationSource: "google_mapping_location",
        resolvedLocationPk: mappingRowPk,
        resolvedLocationName: resolvedLocation
          ? getLocationDisplayName(resolvedLocation)
          : `Location pk ${mappingRowPk}`,
        resolvedLocation,
        googlePlaceId,
        placeIdValid: isValidGooglePlaceId(googlePlaceId)
      };
    }

    const resellerItemPk = extractGoogleResellerItemMappingLocationPk(resellerItem);
    const resellerItemEmbedded = getEmbeddedGoogleResellerItemMappingLocation(resellerItem);
    if (resellerItemPk) {
      console.log("[qc-checks] Google mapping location found:", itemName);
      console.log("[qc-checks] Google mapping location pk:", resellerItemPk);
      const resolvedLocation = resolveLocationRecord(
        resellerItemPk,
        locationsByPk,
        resellerItemEmbedded
      );
      const googlePlaceId = resolvedLocation ? getLocationGooglePlaceId(resolvedLocation) : null;
      return {
        resolvedLocationSource: "google_mapping_location",
        resolvedLocationPk: resellerItemPk,
        resolvedLocationName: resolvedLocation
          ? getLocationDisplayName(resolvedLocation)
          : `Location pk ${resellerItemPk}`,
        resolvedLocation,
        googlePlaceId,
        placeIdValid: isValidGooglePlaceId(googlePlaceId)
      };
    }

    if (dashboardPrimaryLocation.confident && dashboardPrimaryLocation.locationPk) {
      console.log("[qc-checks] Falling back to dashboard primary location:", itemName);
      console.log(
        "[qc-checks] Dashboard primary location pk:",
        dashboardPrimaryLocation.locationPk
      );
      const resolvedLocation = resolveLocationRecord(
        dashboardPrimaryLocation.locationPk,
        locationsByPk,
        dashboardPrimaryLocation.embeddedLocation
      );
      const googlePlaceId = resolvedLocation ? getLocationGooglePlaceId(resolvedLocation) : null;
      return {
        resolvedLocationSource: "dashboard_primary_location",
        resolvedLocationPk: dashboardPrimaryLocation.locationPk,
        resolvedLocationName: resolvedLocation
          ? getLocationDisplayName(resolvedLocation)
          : `Location pk ${dashboardPrimaryLocation.locationPk}`,
        resolvedLocation,
        googlePlaceId,
        placeIdValid: isValidGooglePlaceId(googlePlaceId)
      };
    }

    return {
      resolvedLocationSource: "unknown",
      resolvedLocationPk: null,
      resolvedLocationName: null,
      resolvedLocation: null,
      googlePlaceId: null,
      placeIdValid: false
    };
  }

  function buildGoogleLocationItemResult({
    status,
    itemName,
    itemPk,
    resolvedLocation,
    resolvedLocationPk,
    resolvedLocationName,
    resolvedLocationSource,
    googlePlaceId,
    placeIdValid,
    resellerItemLabel,
    resellerItemPk
  }) {
    return {
      status,
      itemName,
      itemPk,
      resolvedLocation,
      resolvedLocationPk,
      resolvedLocationName,
      resolvedLocationSource,
      googlePlaceId,
      placeIdValid,
      resellerItemLabel,
      resellerItemPk
    };
  }

  function logGoogleLocationResolution(result) {
    console.log("[qc-checks] Resolved location source:", result.resolvedLocationSource);
    console.log("[qc-checks] Resolved Place ID:", result.googlePlaceId);
    console.log(
      "[qc-checks] Place ID valid:",
      result.placeIdValid ? "yes" : "no"
    );
  }

  async function evaluateGoogleLocationsForResellerItem(
    entry,
    locationsByPk,
    dashboardPrimaryLocation
  ) {
    const ctx = {
      shortname: entry.shortname,
      resellerCompanyId: entry.resellerCompanyId,
      resellerItemId: entry.resellerItemId,
      itemId: null
    };
    const resellerItemLabel = getResellerItemLabel(entry.resellerItem);
    const resellerItemPk = entry.resellerItemId;

    const detailResult = await fetchGoogleResellerItemDetail(ctx);
    if (!detailResult.ok) {
      console.log(
        "[qc-checks] Google locations: could not fetch reseller item detail:",
        detailResult.error
      );
      return [
        buildGoogleLocationItemResult({
          status: "uncertain",
          itemName: "Unknown item",
          itemPk: null,
          resolvedLocation: null,
          resolvedLocationPk: null,
          resolvedLocationName: null,
          resolvedLocationSource: "unknown",
          googlePlaceId: null,
          placeIdValid: false,
          resellerItemLabel,
          resellerItemPk
        })
      ];
    }

    const resellerItem = detailResult.resellerItem;

    const mappingsResult = await fetchResellerItemMappings(ctx);
    if (!mappingsResult.ok) {
      console.log(
        "[qc-checks] Google locations: could not fetch reseller item mappings:",
        mappingsResult.error
      );
      return [
        buildGoogleLocationItemResult({
          status: "uncertain",
          itemName: "Unknown item",
          itemPk: null,
          resolvedLocation: null,
          resolvedLocationPk: null,
          resolvedLocationName: null,
          resolvedLocationSource: "unknown",
          googlePlaceId: null,
          placeIdValid: false,
          resellerItemLabel,
          resellerItemPk
        })
      ];
    }

    const mappings = mappingsResult.mappings;
    console.log(
      "[qc-checks] Google locations: mapped items found for reseller item",
      resellerItemLabel,
      `(pk ${resellerItemPk}):`,
      mappings.length
    );

    if (mappings.length === 0) {
      return [];
    }

    const results = [];
    for (const mapping of mappings) {
      const mappedItem = mapping?.item ?? null;
      const mappedItemPk = mappedItem?.pk ?? mappedItem?.id ?? null;
      if (mappedItemPk === null || mappedItemPk === undefined) {
        console.log("[qc-checks] Google locations: mapping missing item pk, marking uncertain");
        const uncertainResult = buildGoogleLocationItemResult({
          status: "uncertain",
          itemName: "Unknown item",
          itemPk: null,
          resolvedLocation: null,
          resolvedLocationPk: null,
          resolvedLocationName: null,
          resolvedLocationSource: "unknown",
          googlePlaceId: null,
          placeIdValid: false,
          resellerItemLabel,
          resellerItemPk
        });
        logGoogleLocationResolution(uncertainResult);
        results.push(uncertainResult);
        continue;
      }

      const itemName = getFareHarborItemDisplayName(mappedItem);
      console.log(
        "[qc-checks] Google locations: evaluating mapped item",
        itemName,
        `(pk ${mappedItemPk})`
      );

      const locationResolution = resolveGoogleMappedItemLocation({
        mappingRow: mapping,
        resellerItem,
        dashboardPrimaryLocation,
        locationsByPk,
        itemName,
        mappedItem
      });

      if (locationResolution.resolvedLocationSource === "unknown") {
        const uncertainResult = buildGoogleLocationItemResult({
          status: "uncertain",
          itemName,
          itemPk: String(mappedItemPk),
          resolvedLocation: null,
          resolvedLocationPk: null,
          resolvedLocationName: null,
          resolvedLocationSource: "unknown",
          googlePlaceId: null,
          placeIdValid: false,
          resellerItemLabel,
          resellerItemPk
        });
        logGoogleLocationResolution(uncertainResult);
        results.push(uncertainResult);
        continue;
      }

      let status = "pass";
      if (!locationResolution.placeIdValid) {
        status = "fail";
      }

      const itemResult = buildGoogleLocationItemResult({
        status,
        itemName,
        itemPk: String(mappedItemPk),
        resolvedLocation: locationResolution.resolvedLocation,
        resolvedLocationPk: locationResolution.resolvedLocationPk,
        resolvedLocationName: locationResolution.resolvedLocationName,
        resolvedLocationSource: locationResolution.resolvedLocationSource,
        googlePlaceId: locationResolution.googlePlaceId,
        placeIdValid: locationResolution.placeIdValid,
        resellerItemLabel,
        resellerItemPk
      });
      logGoogleLocationResolution(itemResult);
      results.push(itemResult);
    }

    return results;
  }

  function formatGoogleLocationsFailureLine(result) {
    if (result.resolvedLocationName) {
      return `${result.itemName} — ${result.resolvedLocationName}`;
    }
    return result.itemName;
  }

  function aggregateGoogleLocationsResults(itemResults) {
    if (itemResults.length === 0) {
      return {
        status: "skip",
        value: null,
        details: "No mapped Google items found."
      };
    }

    const uncertainResults = itemResults.filter(
      (result) => result.status === "uncertain" || result.resolvedLocationSource === "unknown"
    );
    if (uncertainResults.length > 0) {
      return {
        status: "warning",
        value: null,
        details: "Google location data could not be fully confirmed. Manual confirmation needed."
      };
    }

    const failGoogleMappingLocationResults = itemResults.filter(
      (result) => result.status === "fail" && result.resolvedLocationSource === "google_mapping_location"
    );
    const failDashboardPrimaryResults = itemResults.filter(
      (result) =>
        result.status === "fail" && result.resolvedLocationSource === "dashboard_primary_location"
    );

    if (failGoogleMappingLocationResults.length > 0) {
      const lines = failGoogleMappingLocationResults.map(formatGoogleLocationsFailureLine);
      return {
        status: "fail",
        value: false,
        details:
          "Some mapped Google items use mapping-specific locations without valid Google Place IDs.\n" +
          lines.join("\n")
      };
    }

    if (failDashboardPrimaryResults.length > 0) {
      const lines = failDashboardPrimaryResults.map(formatGoogleLocationsFailureLine);
      return {
        status: "fail",
        value: false,
        details:
          "Some mapped Google items fall back to the dashboard primary location, but that location does not have a valid Google Place ID.\n" +
          lines.join("\n")
      };
    }

    const allPass = itemResults.every((result) => result.status === "pass" && result.placeIdValid);
    if (allPass) {
      return {
        status: "pass",
        value: true,
        details: "All mapped Google items resolve to locations with valid Google Place IDs."
      };
    }

    return {
      status: "warning",
      value: null,
      details: "Google location data could not be fully confirmed. Manual confirmation needed."
    };
  }

  function escapeGoogleMappingHtml(text) {
    return String(text ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function buildGoogleMapsPlaceIdUrl(googlePlaceId) {
    return `https://www.google.com/maps/place/?q=place_id:${encodeURIComponent(googlePlaceId)}`;
  }

  function buildFareHarborDashboardItemUrl(origin, shortname, itemPk) {
    return (
      `${origin}/${encodeURIComponent(shortname)}/dashboard/items/${encodeURIComponent(itemPk)}/`
    );
  }

  function getGoogleResellerCompanyTitle(resellerCompany) {
    const name =
      resellerCompany?.name ??
      resellerCompany?.display_name ??
      resellerCompany?.displayName ??
      resellerCompany?.unicode ??
      resellerCompany?.short_name ??
      resellerCompany?.shortName ??
      null;
    if (typeof name === "string" && name.trim() !== "") {
      return name.trim();
    }
    const pk = resellerCompany?.pk;
    return pk !== null && pk !== undefined ? `Google mapping file pk ${pk}` : "Unknown Google mapping file";
  }

  function resolveGoogleMappingFilePlaceId({
    googleCompany,
    resellerItems,
    dashboardPrimaryLocation,
    locationsByPk
  }) {
    const mappingFileTitle = getGoogleResellerCompanyTitle(googleCompany);
    const companyLocationPk = extractLocationPkFromObject(googleCompany);
    if (companyLocationPk) {
      console.log("[qc-checks] Google mapping location found:", mappingFileTitle);
      console.log("[qc-checks] Google mapping location pk:", companyLocationPk);
      const resolvedLocation = resolveLocationRecord(
        companyLocationPk,
        locationsByPk,
        getEmbeddedLocationObject(googleCompany)
      );
      const googlePlaceId = resolvedLocation ? getLocationGooglePlaceId(resolvedLocation) : null;
      return {
        googlePlaceId,
        placeIdValid: isValidGooglePlaceId(googlePlaceId),
        resolvedLocationSource: "google_mapping_location"
      };
    }

    for (const resellerItem of resellerItems || []) {
      const resellerItemPk = extractGoogleResellerItemMappingLocationPk(resellerItem);
      if (!resellerItemPk) {
        continue;
      }
      console.log("[qc-checks] Google mapping location found:", mappingFileTitle);
      console.log("[qc-checks] Google mapping location pk:", resellerItemPk);
      const resolvedLocation = resolveLocationRecord(
        resellerItemPk,
        locationsByPk,
        getEmbeddedGoogleResellerItemMappingLocation(resellerItem)
      );
      const googlePlaceId = resolvedLocation ? getLocationGooglePlaceId(resolvedLocation) : null;
      return {
        googlePlaceId,
        placeIdValid: isValidGooglePlaceId(googlePlaceId),
        resolvedLocationSource: "google_mapping_location"
      };
    }

    if (dashboardPrimaryLocation.confident && dashboardPrimaryLocation.locationPk) {
      console.log("[qc-checks] Falling back to dashboard primary location:", mappingFileTitle);
      console.log(
        "[qc-checks] Dashboard primary location pk:",
        dashboardPrimaryLocation.locationPk
      );
      const resolvedLocation = resolveLocationRecord(
        dashboardPrimaryLocation.locationPk,
        locationsByPk,
        dashboardPrimaryLocation.embeddedLocation
      );
      const googlePlaceId = resolvedLocation ? getLocationGooglePlaceId(resolvedLocation) : null;
      return {
        googlePlaceId,
        placeIdValid: isValidGooglePlaceId(googlePlaceId),
        resolvedLocationSource: "dashboard_primary_location"
      };
    }

    return {
      googlePlaceId: null,
      placeIdValid: false,
      resolvedLocationSource: "unknown"
    };
  }

  async function collectGoogleMappingCopyEntries(shortname) {
    const discovery = await discoverGoogleResellerItems(shortname, null);
    if (!discovery.ok) {
      return { ok: false, entries: [], error: discovery.error };
    }

    if (discovery.googleCompanies.length === 0) {
      return { ok: false, entries: [], error: "No Google mappings found." };
    }

    const [locationsResult, companyDetailResult] = await Promise.all([
      fetchLocations(shortname),
      getCompanyDetail(shortname)
    ]);

    if (!locationsResult.ok) {
      return {
        ok: false,
        entries: [],
        error: "Could not fetch company locations for Google mapping copy."
      };
    }

    const locationsByPk = buildLocationsByPk(locationsResult.locations);
    const company = companyDetailResult.ok ? companyDetailResult.company : null;
    const dashboardPrimaryLocation = identifyDashboardPrimaryLocation(
      company,
      locationsResult.locations
    );

    const entries = [];
    for (const googleCompany of discovery.googleCompanies) {
      const resellerCompanyPk = googleCompany?.pk;
      if (resellerCompanyPk === null || resellerCompanyPk === undefined) {
        continue;
      }

      const companyItems = discovery.items.filter(
        (entry) => String(entry.resellerCompanyId) === String(resellerCompanyPk)
      );
      if (companyItems.length === 0) {
        continue;
      }

      const mappedItems = [];
      const seenItemPks = new Set();
      const resellerItemsForLocation = [];

      for (const entry of companyItems) {
        const ctx = {
          shortname: entry.shortname,
          resellerCompanyId: entry.resellerCompanyId,
          resellerItemId: entry.resellerItemId,
          itemId: null
        };

        const detailResult = await fetchGoogleResellerItemDetail(ctx);
        if (detailResult.ok && detailResult.resellerItem) {
          resellerItemsForLocation.push(detailResult.resellerItem);
        }

        const mappingsResult = await fetchResellerItemMappings(ctx);
        if (!mappingsResult.ok) {
          console.log(
            "[qc-checks] Google mapping copy: could not fetch mappings for reseller item",
            entry.resellerItemId,
            mappingsResult.error
          );
          continue;
        }

        for (const mapping of mappingsResult.mappings) {
          const mappedItem = mapping?.item ?? null;
          const mappedItemPk = mappedItem?.pk ?? mappedItem?.id ?? null;
          if (mappedItemPk === null || mappedItemPk === undefined) {
            continue;
          }
          const itemName = getFareHarborItemDisplayName(mappedItem);
          logIgnoredMappedFareHarborItemLocation(itemName, mappedItem);
          const pk = String(mappedItemPk);
          if (seenItemPks.has(pk)) {
            continue;
          }
          seenItemPks.add(pk);
          mappedItems.push({
            name: itemName,
            pk
          });
        }
      }

      if (mappedItems.length === 0) {
        continue;
      }

      const title = getGoogleResellerCompanyTitle(googleCompany);
      const placeResolution = resolveGoogleMappingFilePlaceId({
        googleCompany,
        resellerItems: resellerItemsForLocation,
        dashboardPrimaryLocation,
        locationsByPk
      });

      const googlePlaceId = placeResolution.googlePlaceId;
      const placeIdValid = placeResolution.placeIdValid;
      const placeIdUrl = placeIdValid && googlePlaceId ? buildGoogleMapsPlaceIdUrl(googlePlaceId) : null;

      console.log("[qc-checks] Google mappings found:", title);
      console.log("[qc-checks] Mapping title:", title);
      console.log("[qc-checks] Place ID:", googlePlaceId);
      console.log("[qc-checks] Place ID URL:", placeIdUrl);
      console.log("[qc-checks] Mapped item count:", mappedItems.length);
      console.log("[qc-checks] Resolved location source:", placeResolution.resolvedLocationSource);
      console.log("[qc-checks] Resolved Place ID:", googlePlaceId);
      console.log("[qc-checks] Place ID valid:", placeIdValid ? "yes" : "no");

      entries.push({
        title,
        resellerCompanyPk: String(resellerCompanyPk),
        googlePlaceId,
        placeIdValid,
        placeIdUrl,
        resolvedLocationSource: placeResolution.resolvedLocationSource,
        mappedItems
      });
    }

    if (entries.length === 0) {
      return { ok: false, entries: [], error: "No Google mappings found." };
    }

    return { ok: true, entries, error: null };
  }

  function formatGoogleMappingZendeskHtml(entries, origin, shortname) {
    const blocks = entries.map((entry) => {
      const titleHtml = escapeGoogleMappingHtml(entry.title);
      const titleBlock = entry.placeIdValid && entry.placeIdUrl
        ? `<p><strong><a href="${escapeGoogleMappingHtml(entry.placeIdUrl)}">${titleHtml}</a></strong></p>`
        : `<p><strong>${titleHtml}</strong></p>`;

      const warningBlock = entry.placeIdValid
        ? ""
        : `<p><em>Place ID missing or invalid for this mapping.</em></p>`;

      const itemLines = entry.mappedItems
        .map((item) => {
          const itemUrl = buildFareHarborDashboardItemUrl(origin, shortname, item.pk);
          const label = escapeGoogleMappingHtml(`${item.name} (${item.pk})`);
          return `<li><a href="${escapeGoogleMappingHtml(itemUrl)}">${label}</a></li>`;
        })
        .join("\n");

      return `${titleBlock}${warningBlock}<ul>\n${itemLines}\n</ul>`;
    });

    return `${blocks.join("\n")}\n`;
  }

  function formatGoogleMappingSheetsTsv(entries) {
    const blocks = entries.map((entry) => {
      const lines = [entry.title];
      if (entry.placeIdValid && entry.placeIdUrl) {
        lines.push(entry.placeIdUrl);
      } else {
        lines.push("Place ID missing or invalid");
      }
      for (const item of entry.mappedItems) {
        lines.push(`${item.name} (${item.pk})`);
      }
      return lines.join("\n");
    });

    return `${blocks.join("\n\n")}\n`;
  }

  async function checkGoogleLocations() {
    const base = { ...CHECK_GOOGLE_LOCATIONS };
    const shortname = parseCompanyShortname();

    if (!shortname) {
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `Could not parse company shortname from URL: ${window.location.pathname}`
      });
    }

    const urlContext = await resolveGoogleResellerItemContext();
    const urlContextFilter = urlContext ? { resellerItemId: urlContext.resellerItemId } : null;

    const discovery = await discoverGoogleResellerItems(shortname, urlContextFilter);
    if (!discovery.ok) {
      return buildCheckResult({
        ...base,
        status: "warning",
        value: null,
        details: "Google location data could not be fully confirmed. Manual confirmation needed."
      });
    }

    if (discovery.googleCompanies.length === 0) {
      return buildCheckResult({
        ...base,
        status: "skip",
        value: null,
        details: "Google reseller company was not found."
      });
    }

    if (discovery.items.length === 0) {
      return buildCheckResult({
        ...base,
        status: "warning",
        value: null,
        details: "Google reseller company exists but has no reseller items."
      });
    }

    const [locationsResult, companyDetailResult] = await Promise.all([
      fetchLocations(shortname),
      getCompanyDetail(shortname)
    ]);

    if (!locationsResult.ok) {
      console.log("[qc-checks] Google locations: locations fetch failed:", locationsResult.error);
      return buildCheckResult({
        ...base,
        status: "warning",
        value: null,
        details: "Google location data could not be fully confirmed. Manual confirmation needed."
      });
    }

    const locationsByPk = buildLocationsByPk(locationsResult.locations);
    const company = companyDetailResult.ok ? companyDetailResult.company : null;
    const dashboardPrimaryLocation = identifyDashboardPrimaryLocation(
      company,
      locationsResult.locations
    );

    console.log(
      "[qc-checks] Google locations: dashboard primary location:",
      dashboardPrimaryLocation.confident
        ? `pk ${dashboardPrimaryLocation.locationPk}`
        : "not confidently identified"
    );

    const perItemResults = await mapWithConcurrency(
      discovery.items,
      GOOGLE_LOCATIONS_CONCURRENCY_LIMIT,
      async (entry) =>
        evaluateGoogleLocationsForResellerItem(entry, locationsByPk, dashboardPrimaryLocation)
    );

    const itemResults = perItemResults.flat();
    const aggregated = aggregateGoogleLocationsResults(itemResults);

    return buildCheckResult({
      ...base,
      status: aggregated.status,
      value: aggregated.value,
      details: aggregated.details
    });
  }

  async function checkGygGroupTicketCategoryMapping() {
    const base = { ...CHECK_GYG_GROUP_TICKET_CATEGORY };
    const startedAt = Date.now();
    gygDevModeEnabled = await isDevModeEnabledAsync();
    initGygGroupPerf();

    const shortname = parseCompanyShortname();

    if (!shortname) {
      logGygGroupPerfSummary(startedAt);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `Could not parse company shortname from URL: ${window.location.pathname}`
      });
    }

    const urlContext = await resolveGygResellerItemContext();
    const urlContextFilter = urlContext ? { resellerItemId: urlContext.resellerItemId } : null;

    const discovery = await discoverGygResellerItems(shortname, urlContextFilter);
    if (!discovery.ok) {
      logGygGroupPerfSummary(startedAt);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `Could not verify GetYourGuide reseller configuration. ${discovery.error}`
      });
    }

    if (discovery.gygCompanies.length === 0) {
      logGygGroupPerfSummary(startedAt);
      return buildCheckResult({
        ...base,
        status: "skip",
        value: null,
        details: "GetYourGuide reseller company was not found."
      });
    }

    if (discovery.items.length === 0) {
      logGygGroupPerfSummary(startedAt);
      return buildCheckResult({
        ...base,
        status: "warning",
        value: null,
        details: "GetYourGuide reseller company exists but has no reseller items."
      });
    }

    const sheetsResult = await fetchTotalSheets(shortname);
    const totalSheets = sheetsResult.ok ? sheetsResult.sheets : null;

    const phase1Results = await mapWithConcurrency(
      discovery.items,
      GYG_GROUP_CONCURRENCY_LIMIT,
      async (entry) => {
        const itemLabel = getResellerItemLabel(entry.resellerItem);
        return evaluateGygGroupMappingPhase1(
          {
            shortname: entry.shortname,
            resellerCompanyId: entry.resellerCompanyId,
            resellerItemId: entry.resellerItemId,
            itemId: null
          },
          itemLabel,
          entry.resellerItemId
        );
      }
    );

    const itemResults = [];
    const pricingChecks = [];

    for (const phase1 of phase1Results) {
      if (phase1.kind === "final") {
        itemResults.push(phase1.result);
        continue;
      }

      trackGygGroupMappingFound(phase1.itemCtx.itemId);
      pricingChecks.push(phase1);
    }

    if (pricingChecks.length > 0) {
      if (!totalSheets) {
        for (const queued of pricingChecks) {
          itemResults.push({
            ...queued.commonItem,
            status: "error",
            line: `${queued.prefix}Could not verify custom field pricing. ${sheetsResult.error}`
          });
        }
      } else {
        const pricingSheetContext = resolveGygGroupCustomFieldPricingSheets(totalSheets);
        if (qcRunCache.gygGroupPerf) {
          qcRunCache.gygGroupPerf.usingBaseSheetOnly = pricingSheetContext.usingBaseSheetOnly;
          qcRunCache.gygGroupPerf.baseSheetPk = pricingSheetContext.baseSheetPk;
          qcRunCache.gygGroupPerf.baseSheetIdentificationSource =
            pricingSheetContext.baseSheetIdentificationSource;
          qcRunCache.gygGroupPerf.skippedNonBaseSheetsCount =
            pricingSheetContext.skippedNonBaseSheetsCount;
        }

        const pricingOutcomes = await mapWithConcurrency(
          pricingChecks,
          GYG_GROUP_CONCURRENCY_LIMIT,
          async (queued) => ({
            queued,
            outcome: await resolvePrototypePricingCheck({
              shortname: queued.itemCtx.shortname,
              itemId: queued.itemCtx.itemId,
              mappedPrototypePk: queued.mappedPrototypePk,
              embeddedPrototype: queued.embeddedPrototype,
              sheetsToCheck: pricingSheetContext.sheetsToCheck
            })
          })
        );

        for (const { queued, outcome } of pricingOutcomes) {
          if (outcome.status === "prototype_fetch_error") {
            itemResults.push({
              ...queued.commonItem,
              status: "error",
              line: `${queued.prefix}Could not verify mapped customer prototype. ${outcome.error}`
            });
            continue;
          }

          if (outcome.status === "prototype_not_found") {
            itemResults.push(
              buildGygGroupItemResult({
                ...queued.commonItem,
                status: "warning",
                reason: "prototype_not_found",
                mappedTo: `customer prototype pk ${outcome.mappedPrototypePk}`,
                line: `${queued.prefix}${queued.groupCategoryContext}, mapped to customer prototype pk ${outcome.mappedPrototypePk}, but that prototype was not found on the item. Please check this setup manually.`
              })
            );
            continue;
          }

          itemResults.push(
            buildGygGroupPricingItemResult({
              prefix: queued.prefix,
              commonItem: queued.commonItem,
              groupCategoryContext: queued.groupCategoryContext,
              prototypeName: outcome.prototypeName,
              pricedFieldResult: outcome.pricedFieldResult
            })
          );
        }
      }
    }

    itemResults.sort((left, right) => {
      const leftPk = left.resellerItemPk ?? "";
      const rightPk = right.resellerItemPk ?? "";
      return String(leftPk).localeCompare(String(rightPk), undefined, { numeric: true });
    });

    const groupResults = itemResults.filter((result) => result.status !== "no_group");
    if (groupResults.length === 0) {
      const errorResults = itemResults.filter((result) => result.status === "error" && result.line);
      logGygGroupPerfSummary(startedAt);
      if (errorResults.length > 0) {
        return buildCheckResult({
          ...base,
          status: "error",
          value: null,
          details: errorResults.map((result) => result.line).join("\n")
        });
      }

      return buildCheckResult({
        ...base,
        status: "skip",
        value: null,
        details: "No GetYourGuide Group ticket categories were found."
      });
    }

    const aggregated = aggregateGygGroupCheckResults(groupResults);
    logGygGroupPerfSummary(startedAt);
    return buildCheckResult({
      ...base,
      status: aggregated.status,
      value: aggregated.value,
      details: aggregated.details,
      detailsHtml: aggregated.detailsHtml
    });
  }

  function ruleMatchesExpected(rule, expected) {
    return (
      rule?.type === "hours-before-start" &&
      Number(rule.hours) === expected.hours &&
      Number(rule.charter_refund_percentage) === expected.charter_refund_percentage &&
      Number(rule.affiliate_refund_percentage) === expected.affiliate_refund_percentage &&
      rule.is_cancellation_allowed === true
    );
  }

  function describeRuleFieldMismatches(rule, expected) {
    const mismatches = [];
    if (rule?.type !== "hours-before-start") {
      mismatches.push(`expected type "hours-before-start", got ${JSON.stringify(rule?.type)}`);
    }
    if (Number(rule?.hours) !== expected.hours) {
      mismatches.push(`expected hours ${expected.hours}, got ${rule?.hours}`);
    }
    if (Number(rule?.charter_refund_percentage) !== expected.charter_refund_percentage) {
      mismatches.push(
        `expected charter_refund_percentage ${expected.charter_refund_percentage}, got ${rule?.charter_refund_percentage}`
      );
    }
    if (Number(rule?.affiliate_refund_percentage) !== expected.affiliate_refund_percentage) {
      mismatches.push(
        `expected affiliate_refund_percentage ${expected.affiliate_refund_percentage}, got ${rule?.affiliate_refund_percentage}`
      );
    }
    if (rule?.is_cancellation_allowed !== true) {
      mismatches.push(`expected is_cancellation_allowed true, got ${rule?.is_cancellation_allowed}`);
    }
    return mismatches;
  }

  function validateCancellationRules(rules) {
    const issues = [];

    if (rules.length !== 2) {
      const hoursFound = rules.map((r) => r?.hours).join(", ");
      return {
        valid: false,
        summary: `Expected 2 cancellation rules, found ${rules.length}.${hoursFound ? ` Hours found: ${hoursFound}.` : ""}`
      };
    }

    const usedIndices = new Set();

    for (const expected of EXPECTED_CANCELLATION_RULES) {
      const matches = rules
        .map((rule, index) => ({ rule, index }))
        .filter(({ rule }) => Number(rule?.hours) === expected.hours);

      if (matches.length === 0) {
        issues.push(`Missing rule with hours ${expected.hours}.`);
        continue;
      }

      if (matches.length > 1) {
        issues.push(`Multiple rules found with hours ${expected.hours}.`);
        continue;
      }

      const { rule, index } = matches[0];
      if (usedIndices.has(index)) {
        issues.push(`Duplicate match for hours ${expected.hours}.`);
        continue;
      }
      usedIndices.add(index);

      if (!ruleMatchesExpected(rule, expected)) {
        const fieldIssues = describeRuleFieldMismatches(rule, expected);
        issues.push(`${expected.hours}h rule: ${fieldIssues.join("; ")}.`);
      }
    }

    const extraRules = rules.filter((_, index) => !usedIndices.has(index));
    if (extraRules.length > 0) {
      const extraHours = extraRules.map((r) => r?.hours).join(", ");
      issues.push(`Unexpected extra rule(s) with hours: ${extraHours}.`);
    }

    if (issues.length > 0) {
      return { valid: false, summary: issues.join(" ") };
    }

    return { valid: true, summary: "Both cancellation rules match expected configuration." };
  }

  async function checkDefaultApiCancellationPolicy() {
    const base = { ...CHECK_DEFAULT_API };
    const shortname = parseCompanyShortname();

    if (!shortname) {
      console.log("[qc-checks] Could not parse company shortname from:", window.location.pathname);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `Could not parse company shortname from URL: ${window.location.pathname}`
      });
    }

    console.log("[qc-checks] Parsed shortname:", shortname);

    const { ok, policies, error } = await fetchCancellationPolicies(shortname);
    if (!ok) {
      console.error("[qc-checks] Fetch failed:", error);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: error
      });
    }

    const policy = findDefaultApiCancellationPolicy(policies);
    const found = policy !== null;
    console.log("[qc-checks] Default - API policy found:", found);

    if (found) {
      return buildCheckResult({
        ...base,
        status: "pass",
        value: true,
        details: `Found policy "${policy.name}"`
      });
    }

    const names = policies.map((p) => p?.name).filter(Boolean);
    const namesHint = names.length > 0 ? ` Found policies: ${names.join(", ")}` : "";
    return buildCheckResult({
      ...base,
      status: "fail",
      value: false,
      details: `Policy "${DEFAULT_API_POLICY_NAME}" not found.${namesHint}`
    });
  }

  async function checkDefaultApiCancellationPolicyRules() {
    const base = { ...CHECK_DEFAULT_API_RULES };
    const shortname = parseCompanyShortname();

    if (!shortname) {
      console.log("[qc-checks] Could not parse company shortname from:", window.location.pathname);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `Could not parse company shortname from URL: ${window.location.pathname}`
      });
    }

    const { ok, policies, error } = await fetchCancellationPolicies(shortname);
    if (!ok) {
      console.error("[qc-checks] Fetch failed:", error);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: error
      });
    }

    const policy = findDefaultApiCancellationPolicy(policies);
    if (!policy) {
      console.log("[qc-checks] Default - API policy not found; cannot validate rules");
      return buildCheckResult({
        ...base,
        status: "fail",
        value: false,
        details: `Policy "${DEFAULT_API_POLICY_NAME}" not found; cannot validate cancellation rules.`
      });
    }

    if (!policy.uri) {
      console.log("[qc-checks] Default - API policy missing uri");
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `Policy "${DEFAULT_API_POLICY_NAME}" is missing uri.`
      });
    }

    console.log("[qc-checks] Policy URI:", policy.uri);

    const rulesUrl = `${policy.uri.replace(/\/?$/, "/")}cancellation-rules/`;
    console.log("[qc-checks] Rules URL:", rulesUrl);

    const rulesResult = await apiGetJson(rulesUrl);
    console.log("[qc-checks] Rules response status:", rulesResult.status);

    if (!rulesResult.ok) {
      console.error("[qc-checks] Rules fetch failed:", rulesResult.error);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: rulesResult.error
      });
    }

    const rules = rulesResult.data.cancellation_rules;
    if (!Array.isArray(rules)) {
      console.log("[qc-checks] cancellation_rules missing or not an array");
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: "Response missing cancellation_rules array"
      });
    }

    console.log("[qc-checks] Number of rules found:", rules.length);

    const validation = validateCancellationRules(rules);
    console.log("[qc-checks] Validation result:", validation.valid ? "pass" : "fail", validation.summary);

    if (validation.valid) {
      return buildCheckResult({
        ...base,
        status: "pass",
        value: true,
        details: validation.summary
      });
    }

    return buildCheckResult({
      ...base,
      status: "fail",
      value: false,
      details: validation.summary
    });
  }

  async function checkBillingMethodAdded() {
    const base = { ...CHECK_BILLING_METHOD_ADDED };
    const shortname = parseCompanyShortname();

    if (!shortname) {
      console.log("[qc-checks] Could not parse company shortname from:", window.location.pathname);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `Could not parse company shortname from URL: ${window.location.pathname}`
      });
    }

    console.log("[qc-checks] Parsed shortname:", shortname);

    const { ok, methods, error } = await fetchB2bPaymentMethods(shortname);
    if (!ok) {
      console.error("[qc-checks] B2B payment methods fetch failed:", error);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: error
      });
    }

    if (methods.length > 0) {
      return buildCheckResult({
        ...base,
        status: "pass",
        value: true,
        details: formatBillingMethodDetails(methods[0])
      });
    }

    return buildCheckResult({
      ...base,
      status: "fail",
      value: false,
      details: "No billing method found"
    });
  }

  async function checkAffiliateApiPermissionGroupExists() {
    const base = { ...CHECK_AFFILIATE_API_PERMISSION_GROUP };
    const shortname = parseCompanyShortname();

    if (!shortname) {
      console.log("[qc-checks] Could not parse company shortname from:", window.location.pathname);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `Could not parse company shortname from URL: ${window.location.pathname}`
      });
    }

    const { ok, groups, error } = await fetchPermissionGroups(shortname);
    if (!ok) {
      console.error("[qc-checks] Permission groups fetch failed:", error);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: error
      });
    }

    const group = findGroupByName(groups, AFFILIATE_API_GROUP_NAME);
    const found = group !== null;
    console.log("[qc-checks] Affiliate - API found:", found);

    if (found) {
      console.log("[qc-checks] Affiliate - API group pk:", group?.pk ?? null);
      return buildCheckResult({
        ...base,
        status: "pass",
        value: true,
        details: `Found permission group "${AFFILIATE_API_GROUP_NAME}" (pk: ${group?.pk ?? "unknown"})`
      });
    }

    const names = groups.map((g) => g?.name).filter(Boolean);
    const namesHint = names.length > 0 ? ` Found groups: ${names.join(", ")}` : "";
    return buildCheckResult({
      ...base,
      status: "fail",
      value: false,
      details: `Permission group "${AFFILIATE_API_GROUP_NAME}" not found.${namesHint}`
    });
  }

  async function checkAffiliateApiPermissionGroupPermissions() {
    const base = { ...CHECK_AFFILIATE_API_PERMISSION_GROUP_PERMISSIONS };
    const shortname = parseCompanyShortname();

    if (!shortname) {
      console.log("[qc-checks] Could not parse company shortname from:", window.location.pathname);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `Could not parse company shortname from URL: ${window.location.pathname}`
      });
    }

    const { ok, groups, error } = await fetchPermissionGroups(shortname);
    if (!ok) {
      console.error("[qc-checks] Permission groups fetch failed:", error);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: error
      });
    }

    const group = findGroupByName(groups, AFFILIATE_API_GROUP_NAME);
    if (!group) {
      return buildCheckResult({
        ...base,
        status: "fail",
        value: false,
        details: "Affiliate - API group not found."
      });
    }

    const groupPermissions = group.group_permissions;
    if (!groupPermissions || typeof groupPermissions !== "object" || Array.isArray(groupPermissions)) {
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: "Affiliate - API group_permissions is missing or invalid."
      });
    }

    const optionalSet = new Set(OPTIONAL_PERMISSIONS);
    const actualEnabledPermissions = Object.entries(groupPermissions)
      .filter(([, value]) => value === true)
      .map(([permission]) => permission);

    const ignoredOptionalPresent = OPTIONAL_PERMISSIONS.filter(
      (permission) =>
        EXPECTED_AFFILIATE_API_ENABLED_PERMISSIONS.includes(permission) ||
        actualEnabledPermissions.includes(permission)
    );
    if (ignoredOptionalPresent.length > 0) {
      console.log("[qc-checks] Ignored optional permissions:", ignoredOptionalPresent);
    }

    const expectedForComparison = EXPECTED_AFFILIATE_API_ENABLED_PERMISSIONS.filter(
      (permission) => !optionalSet.has(permission)
    );
    const actualForComparison = actualEnabledPermissions.filter((permission) => !optionalSet.has(permission));
    const expectedSet = new Set(expectedForComparison);
    const actualSet = new Set(actualForComparison);

    const missingPermissions = expectedForComparison.filter((permission) => !actualSet.has(permission));
    const extraPermissions = actualForComparison.filter((permission) => !expectedSet.has(permission));

    console.log("[qc-checks] Expected permission count:", EXPECTED_AFFILIATE_API_ENABLED_PERMISSIONS.length);
    console.log("[qc-checks] Actual enabled permission count:", actualEnabledPermissions.length);
    console.log("[qc-checks] Missing permissions:", missingPermissions);
    console.log("[qc-checks] Extra permissions:", extraPermissions);

    if (missingPermissions.length === 0 && extraPermissions.length === 0) {
      return buildCheckResult({
        ...base,
        status: "pass",
        value: true,
        details: "Affiliate - API permissions match expected configuration."
      });
    }

    return buildCheckResult({
      ...base,
      status: "fail",
      value: false,
      details: `Missing: ${missingPermissions.length > 0 ? missingPermissions.join(", ") : "none"}. Extra: ${extraPermissions.length > 0 ? extraPermissions.join(", ") : "none"}.`
    });
  }

  function isApiBookingCreationFieldMissing(company) {
    const companyFeatures = company?.company_features;
    if (companyFeatures == null || typeof companyFeatures !== "object") {
      return true;
    }
    return companyFeatures.is_opted_in_for_api_booking_fees === undefined;
  }

  function isApiInvoiceFeeRateFieldMissing(company) {
    const features = company?.features;
    if (features == null || typeof features !== "object") {
      return true;
    }
    return features.api_invoice_fee_rate === undefined;
  }

  function evaluateApiFeeRate(rawValue) {
    if (rawValue === null || rawValue === undefined) {
      return {
        status: "fail",
        value: null,
        parsedValue: null,
        details: "API fee is empty."
      };
    }

    const trimmedValue = typeof rawValue === "string" ? rawValue.trim() : String(rawValue).trim();
    if (!trimmedValue) {
      return {
        status: "fail",
        value: null,
        parsedValue: null,
        details: "API fee is empty."
      };
    }

    const parsedValue = Number(trimmedValue);
    if (Number.isNaN(parsedValue)) {
      return {
        status: "fail",
        value: trimmedValue,
        parsedValue: null,
        details: "API fee is not a valid number."
      };
    }

    const isTwoPercentAsPercent = Math.abs(parsedValue - 2) <= API_FEE_RATE_TOLERANCE;
    const isTwoPercentAsDecimal = Math.abs(parsedValue - 0.02) <= API_FEE_RATE_TOLERANCE;
    const status = isTwoPercentAsPercent || isTwoPercentAsDecimal ? "pass" : "warning";
    const details = status === "pass"
      ? "API fee is set to 2%."
      : `API fee is set to ${parsedValue}. Double-check whether this is intentional.`;

    return { status, value: parsedValue, parsedValue, details };
  }

  function buildApiFeeRateCheckResult(base, rawValue) {
    console.log("[qc-checks] API fee raw field value:", rawValue);

    const evaluation = evaluateApiFeeRate(rawValue);
    console.log("[qc-checks] API fee parsed numeric value:", evaluation.parsedValue);
    console.log("[qc-checks] API fee final status:", evaluation.status);

    return buildCheckResult({
      ...base,
      status: evaluation.status,
      value: evaluation.value,
      details: evaluation.details
    });
  }

  function checkEnableApiBookingCreationFromDom(base) {
    const checkbox = document.querySelector(API_BOOKING_CHECKBOX_SELECTOR);

    if (!(checkbox instanceof HTMLInputElement) || checkbox.type !== "checkbox") {
      console.log("[qc-checks] Enable API Booking Creation checkbox found:", false);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: "Enable API Booking Creation checkbox not found on this page."
      });
    }

    console.log("[qc-checks] Enable API Booking Creation checkbox found:", true);
    console.log("[qc-checks] Enable API Booking Creation checkbox checked:", checkbox.checked);

    if (checkbox.checked === true) {
      return buildCheckResult({
        ...base,
        status: "pass",
        value: true,
        details: "Enable API Booking Creation is enabled."
      });
    }

    return buildCheckResult({
      ...base,
      status: "fail",
      value: false,
      details: "Enable API Booking Creation is not enabled."
    });
  }

  function checkApiFeeRateFromDom(base) {
    const input = document.querySelector(API_INVOICE_FEE_RATE_SELECTOR);
    const fieldFound = input instanceof HTMLInputElement;

    console.log("[qc-checks] API fee field found:", fieldFound);

    if (!fieldFound) {
      console.log("[qc-checks] API fee raw field value:", null);
      console.log("[qc-checks] API fee parsed numeric value:", null);
      console.log("[qc-checks] API fee final status:", "error");
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: "API fee field not found. This check must be run from Settings > Advanced."
      });
    }

    return buildApiFeeRateCheckResult(base, input.value);
  }

  async function checkEnableApiBookingCreation() {
    const base = { ...CHECK_ENABLE_API_BOOKING_CREATION };
    const shortname = parseCompanyShortname();

    if (!shortname) {
      console.log("[qc-checks] Could not parse company shortname from:", window.location.pathname);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `Could not parse company shortname from URL: ${window.location.pathname}`
      });
    }

    const { ok, company, error } = await getCompanyDetail(shortname);
    if (!ok) {
      console.error("[qc-checks] Company detail fetch failed:", error);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: error
      });
    }

    if (isApiBookingCreationFieldMissing(company)) {
      console.log("[qc-checks] Enable API Booking Creation source: dom");
      return checkEnableApiBookingCreationFromDom(base);
    }

    const isEnabled = company.company_features.is_opted_in_for_api_booking_fees === true;
    console.log("[qc-checks] Enable API Booking Creation source: api");
    console.log("[qc-checks] Enable API Booking Creation API value:", isEnabled);

    if (isEnabled) {
      return buildCheckResult({
        ...base,
        status: "pass",
        value: true,
        details: "Enable API Booking Creation is enabled (company API)."
      });
    }

    return buildCheckResult({
      ...base,
      status: "fail",
      value: false,
      details: "Enable API Booking Creation is not enabled (company API)."
    });
  }

  function checkAllowApiBookingsToBeChargedApiFee() {
    const base = { ...CHECK_ALLOW_API_BOOKINGS_API_FEE };
    const checkbox = document.querySelector(API_FEE_CHARGEABLE_SELECTOR);

    if (!(checkbox instanceof HTMLInputElement) || checkbox.type !== "checkbox") {
      console.log("[qc-checks] Allow API Bookings API fee checkbox found:", false);
      return buildCheckResult({
        ...base,
        status: "skip",
        value: null,
        details: "Setting is not available on this dashboard; skipping."
      });
    }

    console.log("[qc-checks] Allow API Bookings API fee checkbox found:", true);
    console.log("[qc-checks] Allow API Bookings API fee checkbox checked:", checkbox.checked);

    if (checkbox.checked === true) {
      return buildCheckResult({
        ...base,
        status: "pass",
        value: true,
        details: "Setting is available and enabled."
      });
    }

    return buildCheckResult({
      ...base,
      status: "fail",
      value: false,
      details: "Setting is available but not enabled."
    });
  }

  async function checkApiFeeRate() {
    const base = { ...CHECK_API_FEE_RATE };
    const shortname = parseCompanyShortname();

    if (!shortname) {
      console.log("[qc-checks] Could not parse company shortname from:", window.location.pathname);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: `Could not parse company shortname from URL: ${window.location.pathname}`
      });
    }

    const { ok, company, error } = await getCompanyDetail(shortname);
    if (!ok) {
      console.error("[qc-checks] Company detail fetch failed:", error);
      return buildCheckResult({
        ...base,
        status: "error",
        value: null,
        details: error
      });
    }

    if (isApiInvoiceFeeRateFieldMissing(company)) {
      console.log("[qc-checks] API Fee source: dom");
      return checkApiFeeRateFromDom(base);
    }

    const rawValue = company.features.api_invoice_fee_rate;
    console.log("[qc-checks] API Fee source: api");
    return buildApiFeeRateCheckResult(base, rawValue);
  }

  function checkAppliesToCheck(selectedIntegrations, appliesTo) {
    if (!Array.isArray(appliesTo) || appliesTo.length === 0) {
      return false;
    }
    if (appliesTo.includes("all")) {
      return true;
    }
    if (!Array.isArray(selectedIntegrations) || selectedIntegrations.length === 0) {
      return false;
    }
    return appliesTo.some((integrationId) => selectedIntegrations.includes(integrationId));
  }

  function getChecksToRun(selectedIntegrations) {
    return QC_CHECK_REGISTRY.filter((entry) => checkAppliesToCheck(selectedIntegrations, entry.appliesTo));
  }

  const QC_CHECK_REGISTRY = [
    {
      ...CHECK_DEFAULT_API,
      category: "Policies",
      severity: "critical",
      appliesTo: ["all"],
      run: checkDefaultApiCancellationPolicy
    },
    {
      ...CHECK_DEFAULT_API_RULES,
      appliesTo: ["all"],
      run: checkDefaultApiCancellationPolicyRules
    },
    {
      ...CHECK_BILLING_METHOD_ADDED,
      appliesTo: ["all"],
      run: checkBillingMethodAdded
    },
    {
      ...CHECK_AFFILIATE_API_PERMISSION_GROUP,
      appliesTo: ["all"],
      run: checkAffiliateApiPermissionGroupExists
    },
    {
      ...CHECK_AFFILIATE_API_PERMISSION_GROUP_PERMISSIONS,
      appliesTo: ["all"],
      run: checkAffiliateApiPermissionGroupPermissions
    },
    {
      ...CHECK_ENABLE_API_BOOKING_CREATION,
      appliesTo: ["all"],
      run: checkEnableApiBookingCreation
    },
    {
      ...CHECK_ALLOW_API_BOOKINGS_API_FEE,
      appliesTo: ["all"],
      run: checkAllowApiBookingsToBeChargedApiFee
    },
    {
      ...CHECK_API_FEE_RATE,
      appliesTo: ["all"],
      run: checkApiFeeRate
    },
    {
      ...CHECK_TRANSPORTATION_MAPPING,
      appliesTo: ["all"],
      run: checkTransportationMapping
    },
    {
      key: "airbnb_affiliate_exists",
      label: "Airbnb Affiliate Exists",
      category: "Affiliates",
      severity: "critical",
      appliesTo: ["airbnb"],
      run: () => checkAffiliateExists("airbnb", { key: "airbnb_affiliate_exists", label: "Airbnb Affiliate Exists" })
    },
    {
      key: "airbnb_affiliate_settings",
      label: "Airbnb Affiliate Settings",
      category: "Affiliates",
      severity: "critical",
      appliesTo: ["airbnb"],
      run: () => checkAffiliateSettings("airbnb", { key: "airbnb_affiliate_settings", label: "Airbnb Affiliate Settings" })
    },
    {
      key: "expedia_affiliate_exists",
      label: "Expedia Affiliate Exists",
      category: "Affiliates",
      severity: "critical",
      appliesTo: ["expedia"],
      run: () => checkAffiliateExists("expedia", { key: "expedia_affiliate_exists", label: "Expedia Affiliate Exists" })
    },
    {
      key: "expedia_affiliate_settings",
      label: "Expedia Affiliate Settings",
      category: "Affiliates",
      severity: "critical",
      appliesTo: ["expedia"],
      run: () => checkAffiliateSettings("expedia", { key: "expedia_affiliate_settings", label: "Expedia Affiliate Settings" })
    },
    {
      key: "getyourguide_affiliate_exists",
      label: "GetYourGuide Affiliate Exists",
      category: "Affiliates",
      severity: "critical",
      appliesTo: ["getyourguide"],
      run: () =>
        checkAffiliateExists("getyourguide", {
          key: "getyourguide_affiliate_exists",
          label: "GetYourGuide Affiliate Exists"
        })
    },
    {
      key: "getyourguide_affiliate_settings",
      label: "GetYourGuide Affiliate Settings",
      category: "Affiliates",
      severity: "critical",
      appliesTo: ["getyourguide"],
      run: () =>
        checkAffiliateSettings("getyourguide", {
          key: "getyourguide_affiliate_settings",
          label: "GetYourGuide Affiliate Settings"
        })
    },
    {
      ...CHECK_GYG_GROUP_TICKET_CATEGORY,
      appliesTo: ["getyourguide"],
      run: checkGygGroupTicketCategoryMapping
    },
    {
      key: "google_affiliate_exists",
      label: "Google Affiliate Exists",
      category: "Affiliates",
      severity: "critical",
      appliesTo: ["google"],
      run: () => checkAffiliateExists("google", { key: "google_affiliate_exists", label: "Google Affiliate Exists" })
    },
    {
      key: "google_affiliate_settings",
      label: "Google Affiliate Settings",
      category: "Affiliates",
      severity: "critical",
      appliesTo: ["google"],
      run: () => checkAffiliateSettings("google", { key: "google_affiliate_settings", label: "Google Affiliate Settings" })
    },
    {
      ...CHECK_GOOGLE_LOCATIONS,
      appliesTo: ["google"],
      run: checkGoogleLocations
    },
    {
      key: "viator_affiliate_exists",
      label: "Viator Affiliate Exists",
      category: "Affiliates",
      severity: "critical",
      appliesTo: ["viator"],
      run: () => checkAffiliateExists("viator", { key: "viator_affiliate_exists", label: "Viator Affiliate Exists" })
    },
    {
      key: "viator_affiliate_settings",
      label: "Viator Affiliate Settings",
      category: "Affiliates",
      severity: "critical",
      appliesTo: ["viator"],
      run: () => checkAffiliateSettings("viator", { key: "viator_affiliate_settings", label: "Viator Affiliate Settings" })
    },
    {
      ...CHECK_VIATOR_INVOICE_PRICING_ZERO_COMMISSION_WARNING,
      appliesTo: ["viator"],
      run: checkViatorInvoicePricingZeroCommissionWarning
    },
    {
      ...CHECK_VIATOR_PRICING_SHEET_ASSIGNMENT_WARNING,
      appliesTo: ["viator"],
      run: checkViatorPricingSheetAssignmentWarning
    }
  ];

  async function runQCChecks(selectedIntegrations = []) {
    qcRunCache = {};
    const integrations = Array.isArray(selectedIntegrations) ? selectedIntegrations : [];
    console.log("[qc-checks] Running QC checks", { selectedIntegrations: integrations });
    const entries = getChecksToRun(integrations);
    const checks = (await Promise.all(entries.map((entry) => Promise.resolve(entry.run())))).filter(
      (check) => !check.suppressDisplay
    );
    return {
      success: true,
      checks
    };
  }

  function handleMessage(req, sender, sendResponse) {
    console.log("[qc-checks] Message received:", req);

    if (req.action === "runQCChecks") {
      const selectedIntegrations = Array.isArray(req.selectedIntegrations) ? req.selectedIntegrations : [];
      runQCChecks(selectedIntegrations)
        .then((result) => {
          console.log("[qc-checks] Sending result:", result);
          sendResponse(result);
        })
        .catch((err) => {
          console.error("[qc-checks] runQCChecks failed:", err);
          sendResponse({ success: false, error: err.message, checks: [] });
        });
      return true;
    }

    return false;
  }

  window.QCChecks = {
    handleMessage,
    runQCChecks,
    formatGetYourGuideGroupTicketCategoryMappingWarning,
    formatGetYourGuideGroupTicketCategoryMappingDetailsHtml,
    collectGoogleMappingCopyEntries,
    formatGoogleMappingZendeskHtml,
    formatGoogleMappingSheetsTsv
  };

  console.log("[qc-checks] Module initialized");
})();
