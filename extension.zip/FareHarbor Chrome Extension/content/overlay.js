console.log("[overlay] overlay.js loaded");

(function initializeFareHarborOverlay() {
  const DEV_MODE_STORAGE_KEY = FareHarborDeveloperAuth.DEV_MODE_STORAGE_KEY;
  const GYG_MAPPING_API_ENRICHMENT_STORAGE_KEY = "gygMappingIncludeApiEnrichment";
  const VIATOR_MAPPING_INCLUDE_PRICE_SHEETS_STORAGE_KEY = "viatorMappingIncludePriceSheets";
  let devModeEnabled = false;
  let gygIncludeApiEnrichment = false;
  let viatorIncludePriceSheets = false;
  const STORAGE_KEY = "overlayOpen";
  const POSITION_STORAGE_KEY = "overlayPosition";
  const SIZE_STORAGE_KEY = "overlaySize";
  const POSITION_MARGIN = 8;
  const OVERLAY_MIN_WIDTH = 320;
  const OVERLAY_MIN_HEIGHT = 240;
  const OVERLAY_ID = "fh-automator-overlay";
  const STYLES_ID = "fh-automator-styles";
  const AUDIT_POLL_MS = 100;
  const AUDIT_POLL_MAX = 50;
  const SPA_URL_POLL_MS = 500;
  const MAPPING_CHECK_POLL_MS = 400;
  const MAPPING_CHECK_TIMEOUT_MS = 6000;

  let activeView = "home";
  let copyMappingCheckToken = 0;
  let lastTrackedHref = location.href;
  let spaUrlWatcherStarted = false;
  let currentPageCanAudit = false;
  let currentPageStatusMessage = "";
  let lastCapacityResults = null;
  let currentPageHasCustomerTypes = false;
  let duplicateCompatMessage = "";
  let currentPageQcReady = false;
  let qcCompatMessage = "";
  let lastQcResults = null;
  let lastMappingCopyStatus = null;
  let overlayDragActive = false;
  let overlayResizeActive = false;
  let overlayResizeDirection = "";
  let overlayResizeStartX = 0;
  let overlayResizeStartY = 0;
  let overlayResizeStartWidth = 0;
  let overlayResizeStartHeight = 0;
  let overlayResizeActiveHandle = null;

  const MAPPING_VIEW_IDS = [
    "mapping",
    "mapping-expedia",
    "mapping-gyg",
    "mapping-items",
    "mapping-viator",
    "mapping-airbnb",
    "mapping-google"
  ];
  let overlayDragOffsetX = 0;
  let overlayDragOffsetY = 0;
  let overlayResizeWatcherStarted = false;

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function getOverlayEl() {
    return document.getElementById(OVERLAY_ID);
  }

  function isOverlayVisible() {
    const el = getOverlayEl();
    return el && !el.classList.contains("fh-automator-overlay--hidden");
  }

  function persistOverlayOpen(open) {
    chrome.storage.local.set({ [STORAGE_KEY]: open });
  }

  function persistOverlayPosition(left, top) {
    chrome.storage.local.set({ [POSITION_STORAGE_KEY]: { left, top } });
  }

  function clearOverlayPositionStorage() {
    chrome.storage.local.remove(POSITION_STORAGE_KEY);
  }

  function persistOverlaySize(width, height) {
    chrome.storage.local.set({ [SIZE_STORAGE_KEY]: { width, height } });
  }

  function clearOverlaySizeStorage() {
    chrome.storage.local.remove(SIZE_STORAGE_KEY);
  }

  function getMaxOverlayDimensions(overlay) {
    const rect = overlay.getBoundingClientRect();
    const isPositioned = overlay.classList.contains("fh-automator-overlay--positioned");
    const anchorRight = 16;
    const anchorTop = 16;

    const maxWidth = isPositioned
      ? window.innerWidth - rect.left - POSITION_MARGIN
      : window.innerWidth - anchorRight - POSITION_MARGIN;
    const maxHeight = window.innerHeight - (isPositioned ? rect.top : anchorTop) - POSITION_MARGIN;

    return {
      maxWidth: Math.max(OVERLAY_MIN_WIDTH, maxWidth),
      maxHeight: Math.max(OVERLAY_MIN_HEIGHT, maxHeight),
    };
  }

  function clampOverlayDimensions(width, height, overlay) {
    const { maxWidth, maxHeight } = getMaxOverlayDimensions(overlay);
    return {
      width: Math.min(Math.max(width, OVERLAY_MIN_WIDTH), maxWidth),
      height: Math.min(Math.max(height, OVERLAY_MIN_HEIGHT), maxHeight),
    };
  }

  function applyDefaultOverlaySize(overlay) {
    overlay.classList.remove("fh-automator-overlay--sized");
    overlay.style.width = "";
    overlay.style.height = "";
  }

  function applyOverlaySize(overlay, width, height) {
    const clamped = clampOverlayDimensions(width, height, overlay);
    overlay.classList.add("fh-automator-overlay--sized");
    overlay.style.width = `${clamped.width}px`;
    overlay.style.height = `${clamped.height}px`;
    return clamped;
  }

  function clampOverlayPosition(left, top, overlay) {
    const width = overlay.offsetWidth;
    const height = overlay.offsetHeight;
    const maxLeft = window.innerWidth - width - POSITION_MARGIN;
    const maxTop = window.innerHeight - height - POSITION_MARGIN;
    return {
      left: Math.min(Math.max(left, POSITION_MARGIN), Math.max(maxLeft, POSITION_MARGIN)),
      top: Math.min(Math.max(top, POSITION_MARGIN), Math.max(maxTop, POSITION_MARGIN)),
    };
  }

  function applyDefaultOverlayPosition(overlay) {
    overlay.classList.remove("fh-automator-overlay--positioned");
    overlay.style.left = "";
    overlay.style.top = "";
    overlay.style.right = "";
  }

  function applyCustomOverlayPosition(overlay, left, top) {
    const clamped = clampOverlayPosition(left, top, overlay);
    overlay.classList.add("fh-automator-overlay--positioned");
    overlay.style.right = "auto";
    overlay.style.left = `${clamped.left}px`;
    overlay.style.top = `${clamped.top}px`;
    return clamped;
  }

  function restoreOverlayLayout(overlay) {
    chrome.storage.local.get([POSITION_STORAGE_KEY, SIZE_STORAGE_KEY], (result) => {
      if (!overlay) return;

      const size = result[SIZE_STORAGE_KEY];
      if (size && typeof size.width === "number" && typeof size.height === "number") {
        applyOverlaySize(overlay, size.width, size.height);
      }

      const pos = result[POSITION_STORAGE_KEY];
      if (pos && typeof pos.left === "number" && typeof pos.top === "number") {
        applyCustomOverlayPosition(overlay, pos.left, pos.top);
      }
    });
  }

  function isOverlayDragBlockedTarget(target) {
    if (!target || !(target instanceof Element)) {
      return true;
    }
    return Boolean(target.closest("button, input, select, textarea, a"));
  }

  function onOverlayDragPointerMove(e) {
    if (!overlayDragActive) return;
    const overlay = getOverlayEl();
    if (!overlay) return;

    const left = e.clientX - overlayDragOffsetX;
    const top = e.clientY - overlayDragOffsetY;
    applyCustomOverlayPosition(overlay, left, top);
  }

  function stopOverlayDrag(e) {
    if (!overlayDragActive) return;

    overlayDragActive = false;
    const overlay = getOverlayEl();
    const header = overlay?.querySelector(".fh-automator-header");
    if (header) {
      header.classList.remove("fh-automator-header--dragging");
      if (e && header.hasPointerCapture?.(e.pointerId)) {
        header.releasePointerCapture(e.pointerId);
      }
    }

    document.removeEventListener("pointermove", onOverlayDragPointerMove);
    document.removeEventListener("pointerup", stopOverlayDrag);
    document.removeEventListener("pointercancel", stopOverlayDrag);

    if (overlay && overlay.classList.contains("fh-automator-overlay--positioned")) {
      const left = parseFloat(overlay.style.left);
      const top = parseFloat(overlay.style.top);
      if (Number.isFinite(left) && Number.isFinite(top)) {
        persistOverlayPosition(left, top);
      }
    }
  }

  function startOverlayDrag(e, overlay, header) {
    if (e.button !== 0 || overlayResizeActive) return;

    const rect = overlay.getBoundingClientRect();
    overlayDragOffsetX = e.clientX - rect.left;
    overlayDragOffsetY = e.clientY - rect.top;

    if (!overlay.classList.contains("fh-automator-overlay--positioned")) {
      applyCustomOverlayPosition(overlay, rect.left, rect.top);
    }

    overlayDragActive = true;
    header.classList.add("fh-automator-header--dragging");
    header.setPointerCapture(e.pointerId);

    document.addEventListener("pointermove", onOverlayDragPointerMove);
    document.addEventListener("pointerup", stopOverlayDrag);
    document.addEventListener("pointercancel", stopOverlayDrag);
  }

  function resetOverlayPosition() {
    const overlay = getOverlayEl();
    if (!overlay) return;
    applyDefaultOverlayPosition(overlay);
    applyDefaultOverlaySize(overlay);
    clearOverlayPositionStorage();
    clearOverlaySizeStorage();
  }

  function onOverlayResizePointerMove(e) {
    if (!overlayResizeActive) return;
    const overlay = getOverlayEl();
    if (!overlay) return;

    const dx = e.clientX - overlayResizeStartX;
    const dy = e.clientY - overlayResizeStartY;
    let newWidth = overlayResizeStartWidth;
    let newHeight = overlayResizeStartHeight;

    if (overlayResizeDirection.includes("e")) {
      newWidth = overlayResizeStartWidth + dx;
    }
    if (overlayResizeDirection.includes("s")) {
      newHeight = overlayResizeStartHeight + dy;
    }

    applyOverlaySize(overlay, newWidth, newHeight);

    if (overlay.classList.contains("fh-automator-overlay--positioned")) {
      const left = parseFloat(overlay.style.left);
      const top = parseFloat(overlay.style.top);
      if (Number.isFinite(left) && Number.isFinite(top)) {
        applyCustomOverlayPosition(overlay, left, top);
      }
    }
  }

  function stopOverlayResize(e) {
    if (!overlayResizeActive) return;

    overlayResizeActive = false;
    const overlay = getOverlayEl();
    if (overlay) {
      overlay.classList.remove("fh-automator-overlay--resizing");
    }
    if (overlayResizeActiveHandle) {
      if (e && overlayResizeActiveHandle.hasPointerCapture?.(e.pointerId)) {
        overlayResizeActiveHandle.releasePointerCapture(e.pointerId);
      }
      overlayResizeActiveHandle = null;
    }

    document.removeEventListener("pointermove", onOverlayResizePointerMove);
    document.removeEventListener("pointerup", stopOverlayResize);
    document.removeEventListener("pointercancel", stopOverlayResize);

    if (overlay && overlay.classList.contains("fh-automator-overlay--sized")) {
      const width = overlay.offsetWidth;
      const height = overlay.offsetHeight;
      persistOverlaySize(width, height);
    }
  }

  function startOverlayResize(e, overlay, handle) {
    if (e.button !== 0 || overlayDragActive) return;

    e.preventDefault();
    e.stopPropagation();

    overlayResizeDirection = handle.dataset.resize || "";
    overlayResizeStartX = e.clientX;
    overlayResizeStartY = e.clientY;
    overlayResizeStartWidth = overlay.offsetWidth;
    overlayResizeStartHeight = overlay.offsetHeight;

    overlayResizeActive = true;
    overlayResizeActiveHandle = handle;
    overlay.classList.add("fh-automator-overlay--resizing");
    handle.setPointerCapture(e.pointerId);

    document.addEventListener("pointermove", onOverlayResizePointerMove);
    document.addEventListener("pointerup", stopOverlayResize);
    document.addEventListener("pointercancel", stopOverlayResize);
  }

  function wireOverlayResize(overlay) {
    overlay.querySelectorAll(".fh-automator-resize-handle").forEach((handle) => {
      handle.addEventListener("pointerdown", (e) => {
        startOverlayResize(e, overlay, handle);
      });
    });
  }

  function startOverlayResizeWatcher() {
    if (overlayResizeWatcherStarted) return;
    overlayResizeWatcherStarted = true;

    window.addEventListener("resize", () => {
      const overlay = getOverlayEl();
      if (!overlay) return;

      if (overlay.classList.contains("fh-automator-overlay--sized")) {
        const width = parseFloat(overlay.style.width) || overlay.offsetWidth;
        const height = parseFloat(overlay.style.height) || overlay.offsetHeight;
        const clamped = applyOverlaySize(overlay, width, height);
        persistOverlaySize(clamped.width, clamped.height);
      }

      if (!overlay.classList.contains("fh-automator-overlay--positioned")) {
        return;
      }

      const left = parseFloat(overlay.style.left);
      const top = parseFloat(overlay.style.top);
      if (!Number.isFinite(left) || !Number.isFinite(top)) {
        return;
      }

      const clamped = applyCustomOverlayPosition(overlay, left, top);
      persistOverlayPosition(clamped.left, clamped.top);
    });
  }

  function wireOverlayDrag(overlay) {
    const header = overlay.querySelector(".fh-automator-header");
    const resetBtn = overlay.querySelector("#fh-automator-reset-position");
    if (!header) return;

    header.addEventListener("pointerdown", (e) => {
      if (isOverlayDragBlockedTarget(e.target)) {
        return;
      }
      e.preventDefault();
      startOverlayDrag(e, overlay, header);
    });

    if (resetBtn) {
      resetBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        resetOverlayPosition();
      });
    }

    startOverlayResizeWatcher();
  }

  function injectStyles() {
    if (document.getElementById(STYLES_ID)) return;
    const style = document.createElement("style");
    style.id = STYLES_ID;
    style.textContent = `
      .fh-automator-overlay {
        --fh-primary: #0a5dbc;
        --fh-primary-hover: #1d4ed8;
        --fh-primary-gradient: linear-gradient(145deg, #0757ac 0%, #0a5dbc 40%, #1b81e7 100%);
        --fh-surface: #ffffff;
        --fh-canvas: #eef2f7;
        --fh-text: #0f172a;
        --fh-muted: #64748b;
        --fh-shadow-card: 0 1px 2px rgba(15, 23, 42, 0.035), 0 1px 3px rgba(15, 23, 42, 0.022);
        --fh-shadow-card-hover: 0 2px 6px rgba(15, 23, 42, 0.045), 0 1px 2px rgba(15, 23, 42, 0.03);
        --fh-radius-card: 10px;
        --fh-gap-tight: 5px;
        --fh-gap-section: 6px;
        --fh-subordinate-indent: 2px;
        --fh-status-ok: #15803d;
        position: fixed;
        top: 16px;
        right: 16px;
        z-index: 2147483646;
        width: 340px;
        max-width: calc(100vw - 32px);
        max-height: calc(100vh - 32px);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        font-size: 12px;
        line-height: 1.35;
        color: var(--fh-text);
        background: var(--fh-surface);
        border: 1px solid rgba(15, 23, 42, 0.08);
        border-radius: var(--fh-radius-card);
        box-shadow: 0 12px 40px rgba(15, 23, 42, 0.16);
        box-sizing: border-box;
      }
      .fh-automator-overlay button {
        appearance: none;
        font-family: inherit;
        transition: background-color 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease, color 0.2s ease, transform 0.15s ease;
      }
      .fh-automator-overlay button:focus-visible {
        outline: 2px solid rgba(10, 91, 188, 0.45);
        outline-offset: 2px;
      }
      .fh-automator-overlay--hidden {
        display: none !important;
      }
      .fh-automator-overlay--positioned {
        right: auto;
      }
      .fh-automator-overlay--resizing {
        user-select: none;
      }
      .fh-automator-resize-handle {
        position: absolute;
        z-index: 2;
        touch-action: none;
        user-select: none;
      }
      .fh-automator-resize-handle--right {
        top: 0;
        right: 0;
        width: 8px;
        height: 100%;
        cursor: ew-resize;
      }
      .fh-automator-resize-handle--bottom {
        left: 0;
        bottom: 0;
        width: 100%;
        height: 8px;
        cursor: ns-resize;
      }
      .fh-automator-resize-handle--corner {
        right: 0;
        bottom: 0;
        width: 16px;
        height: 16px;
        cursor: nwse-resize;
      }
      .fh-automator-resize-handle--corner::after {
        content: "";
        position: absolute;
        right: 4px;
        bottom: 4px;
        width: 7px;
        height: 7px;
        border-right: 2px solid rgba(15, 23, 42, 0.18);
        border-bottom: 2px solid rgba(15, 23, 42, 0.18);
        border-radius: 0 0 2px 0;
        pointer-events: none;
      }
      .fh-automator-resize-handle:hover::after,
      .fh-automator-overlay--resizing .fh-automator-resize-handle--corner::after {
        border-color: rgba(10, 91, 188, 0.35);
      }
      .fh-automator-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        flex-shrink: 0;
        padding: 7px 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.12);
        background: var(--fh-primary-gradient);
        border-radius: var(--fh-radius-card) var(--fh-radius-card) 0 0;
        cursor: grab;
        user-select: none;
        touch-action: none;
      }
      .fh-automator-header--dragging {
        cursor: grabbing;
      }
      .fh-automator-header-text {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 0;
      }
      .fh-automator-title {
        display: block;
        font-weight: 700;
        font-size: 13px;
        line-height: 1.15;
        color: #ffffff;
        letter-spacing: 0.01em;
      }
      .fh-automator-subtitle {
        display: block;
        margin: 0;
        padding-left: var(--fh-subordinate-indent);
        font-size: 9px;
        font-weight: 400;
        line-height: 1.15;
        color: rgba(255, 255, 255, 0.52);
        letter-spacing: 0.02em;
      }
      .fh-automator-dev-badge {
        display: inline-block;
        margin-left: 6px;
        padding: 1px 5px;
        font-size: 8px;
        font-weight: 600;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        color: #fef3c7;
        background: rgba(180, 83, 9, 0.35);
        border: 1px solid rgba(252, 211, 77, 0.45);
        border-radius: 3px;
        vertical-align: middle;
      }
      .fh-automator-endpoint-scout {
        margin-top: 4px;
        width: 100%;
        padding: 6px 8px;
        border: 1px dashed rgba(180, 83, 9, 0.45);
        border-radius: 6px;
        background: #fffbeb;
        color: #92400e;
        font-size: 11px;
        font-weight: 500;
        cursor: pointer;
      }
      .fh-automator-endpoint-scout:hover:not(:disabled) {
        background: #fef3c7;
        border-color: #f59e0b;
      }
      .fh-automator-api-capacity-summary {
        margin-top: 6px;
        padding: 8px 10px;
        font-size: 11px;
        line-height: 1.45;
        color: #78350f;
        background: #fffbeb;
        border: 1px solid rgba(180, 83, 9, 0.25);
        border-radius: 6px;
        white-space: pre-line;
      }
      .fh-automator-api-capacity-summary--error {
        color: #991b1b;
        background: #fef2f2;
        border-color: rgba(239, 68, 68, 0.25);
      }
      .fh-automator-api-capacity-summary--warn {
        border-color: rgba(245, 158, 11, 0.45);
      }
      .fh-automator-api-capacity-summary--inspect {
        max-height: 420px;
        overflow: auto;
        white-space: pre-wrap;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 10px;
      }
      .fh-automator-capacity-engine-row {
        display: flex;
        align-items: center;
        gap: 6px;
        margin-top: 6px;
      }
      .fh-automator-capacity-engine-label {
        font-size: 11px;
        font-weight: 500;
        color: #92400e;
        flex-shrink: 0;
      }
      .fh-automator-capacity-engine-select {
        flex: 1;
        font-size: 11px;
        padding: 4px 6px;
        border: 1px solid rgba(180, 83, 9, 0.35);
        border-radius: 4px;
        background: #fff;
        color: #78350f;
      }
      .fh-automator-header-actions {
        display: flex;
        align-items: center;
        gap: 4px;
        flex-shrink: 0;
      }
      .fh-automator-reset-position {
        flex-shrink: 0;
        min-height: 24px;
        padding: 3px 7px;
        border: 1px solid rgba(255, 255, 255, 0.28);
        border-radius: 6px;
        background: rgba(255, 255, 255, 0.08);
        color: rgba(255, 255, 255, 0.92);
        font-size: 10px;
        font-weight: 500;
        line-height: 1.2;
        cursor: pointer;
        white-space: nowrap;
      }
      .fh-automator-reset-position:hover {
        background: rgba(255, 255, 255, 0.18);
        border-color: rgba(255, 255, 255, 0.4);
        color: #ffffff;
      }
      .fh-automator-close {
        flex-shrink: 0;
        width: 24px;
        min-height: 24px;
        padding: 0;
        border: none;
        border-radius: 6px;
        background: transparent;
        color: rgba(255, 255, 255, 0.85);
        font-size: 20px;
        line-height: 1;
        cursor: pointer;
      }
      .fh-automator-close:hover {
        background: rgba(255, 255, 255, 0.15);
        color: #ffffff;
      }
      .fh-automator-body {
        flex: 1;
        min-height: 0;
        overflow-y: auto;
        overscroll-behavior: contain;
        padding: 8px 10px 10px;
        background: var(--fh-canvas);
        display: flex;
        flex-direction: column;
        gap: var(--fh-gap-tight);
      }
      .fh-automator-action-list {
        display: flex;
        flex-direction: column;
        gap: var(--fh-gap-tight);
      }
      .fh-automator-action {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 0;
        width: 100%;
        padding: 7px 10px;
        border: 1px solid rgba(15, 23, 42, 0.06);
        border-radius: var(--fh-radius-card);
        background: var(--fh-surface);
        color: var(--fh-text);
        text-align: left;
        cursor: pointer;
        box-sizing: border-box;
        box-shadow: var(--fh-shadow-card);
      }
      .fh-automator-action:hover:not(:disabled) {
        border-color: rgba(15, 23, 42, 0.1);
        box-shadow: var(--fh-shadow-card-hover);
      }
      .fh-automator-action:active:not(:disabled) {
        background: #fafbfc;
      }
      .fh-automator-action--muted .fh-automator-action-label {
        color: #64748b;
      }
      .fh-automator-action:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }
      .fh-automator-action-label {
        font-size: 12px;
        font-weight: 600;
        color: var(--fh-text);
        line-height: 1.2;
      }
      .fh-automator-action-status {
        display: block;
        position: relative;
        padding-left: 10px;
        margin-top: 2px;
        margin-left: var(--fh-subordinate-indent);
        font-size: 10px;
        font-weight: 500;
        line-height: 1.3;
        letter-spacing: 0.01em;
        min-height: 0;
      }
      .fh-automator-action-status:empty {
        display: none;
        margin-top: 0;
      }
      .fh-automator-action-status--supported {
        color: var(--fh-status-ok);
      }
      .fh-automator-action-status--supported::before {
        content: "";
        position: absolute;
        left: 0;
        top: 50%;
        margin-top: -3px;
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background-color: var(--fh-status-ok);
      }
      .fh-automator-action-status--unsupported {
        color: var(--fh-muted);
      }
      .fh-automator-action-status--unsupported::before {
        content: "";
        position: absolute;
        left: 0;
        top: 50%;
        margin-top: -3px;
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background-color: #94a3b8;
      }
      .fh-automator-action-status--checking {
        padding-left: 0;
        color: var(--fh-muted);
      }
      .fh-automator-action-status--checking::before {
        content: none;
      }
      .fh-automator-view--hidden {
        display: none !important;
      }
      .fh-automator-back {
        align-self: flex-start;
        padding: 2px 0;
        margin-bottom: -2px;
        border: none;
        background: transparent;
        color: var(--fh-primary);
        font-size: 11px;
        font-weight: 500;
        cursor: pointer;
      }
      .fh-automator-back:hover {
        color: var(--fh-primary-hover);
        text-decoration: underline;
      }
      .fh-automator-capacity-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
      }
      .fh-automator-refresh {
        flex-shrink: 0;
        padding: 4px 8px;
        border: 1px solid rgba(15, 23, 42, 0.1);
        border-radius: 6px;
        background: var(--fh-surface);
        color: var(--fh-muted);
        font-size: 10px;
        font-weight: 500;
        cursor: pointer;
        white-space: nowrap;
        box-shadow: var(--fh-shadow-card);
      }
      .fh-automator-refresh:hover {
        background: var(--fh-surface);
        border-color: rgba(10, 91, 188, 0.35);
        color: var(--fh-primary);
      }
      .fh-automator-capacity {
        display: flex;
        flex-direction: column;
        gap: var(--fh-gap-section);
      }
      .fh-automator-capacity-title {
        font-weight: 600;
        font-size: 12px;
        color: #0f172a;
        margin: 0;
      }
      .fh-automator-capacity-compat {
        margin: 0;
        font-size: 10.5px;
        line-height: 1.3;
        padding: 5px 8px;
        border-radius: 8px;
        background: var(--fh-surface);
        color: var(--fh-muted);
        border: 1px solid rgba(15, 23, 42, 0.08);
        box-shadow: var(--fh-shadow-card);
      }
      .fh-automator-capacity-compat--ready {
        background: rgba(236, 253, 245, 0.7);
        color: #047857;
        border-color: rgba(167, 243, 208, 0.6);
      }
      .fh-automator-capacity-compat--blocked {
        background: rgba(248, 250, 252, 0.9);
        color: var(--fh-muted);
        border-color: rgba(15, 23, 42, 0.08);
      }
      .fh-automator-field {
        display: flex;
        flex-direction: column;
        gap: 3px;
      }
      .fh-automator-field--hidden {
        display: none;
      }
      .fh-automator-label {
        font-size: 11px;
        font-weight: 500;
        color: #475569;
      }
      .fh-automator-input {
        width: 100%;
        padding: 5px 8px;
        border: 1px solid rgba(15, 23, 42, 0.1);
        border-radius: 6px;
        font-size: 12px;
        box-sizing: border-box;
        background: var(--fh-surface);
        color: var(--fh-text);
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
      }
      .fh-automator-input:focus {
        outline: none;
        border-color: rgba(10, 91, 188, 0.45);
        box-shadow: 0 0 0 2px rgba(10, 91, 188, 0.12);
      }
      .fh-automator-select {
        width: 100%;
        padding: 5px 8px;
        border: 1px solid rgba(15, 23, 42, 0.1);
        border-radius: 6px;
        font-size: 12px;
        box-sizing: border-box;
        background: var(--fh-surface);
        color: var(--fh-text);
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
      }
      .fh-automator-select:focus {
        outline: none;
        border-color: rgba(10, 91, 188, 0.45);
        box-shadow: 0 0 0 2px rgba(10, 91, 188, 0.12);
      }
      .fh-automator-hint {
        margin: 0;
        font-size: 10px;
        color: #64748b;
        text-align: center;
        line-height: 1.3;
      }
      .fh-automator-checkbox-row {
        display: flex;
        align-items: flex-start;
        gap: 6px;
        font-size: 11px;
        color: #475569;
        cursor: pointer;
      }
      .fh-automator-checkbox-row input {
        margin-top: 2px;
        flex-shrink: 0;
      }
      .fh-automator-gyg-api-enrichment-group {
        margin: 0 0 8px;
        padding-left: var(--fh-subordinate-indent);
      }
      .fh-automator-gyg-api-enrichment-beta {
        margin: 4px 0 0 20px;
        font-size: 9px;
        color: #78716c;
        line-height: 1.35;
        text-align: left;
      }
      .fh-automator-run {
        width: 100%;
        padding: 7px 10px;
        border: none;
        border-radius: 6px;
        background: var(--fh-primary);
        color: #fff;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        box-shadow: 0 1px 2px rgba(10, 91, 188, 0.2);
      }
      .fh-automator-run:hover:not(:disabled) {
        background: var(--fh-primary-hover);
      }
      .fh-automator-run:disabled {
        opacity: 0.5;
        cursor: not-allowed;
        box-shadow: none;
      }
      .fh-automator-audit-results {
        display: none;
        padding: 6px;
        border-radius: 6px;
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        font-size: 11px;
      }
      .fh-automator-audit-results--visible {
        display: block;
      }
      .fh-automator-results-stale-warning {
        margin: 0;
        font-size: 10.5px;
        line-height: 1.3;
        padding: 5px 7px;
        border-radius: 6px;
        background: #fffbeb;
        color: #92400e;
        border: 1px solid #fde68a;
      }
      .fh-automator-results-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
        margin-bottom: 4px;
      }
      .fh-automator-audit-results-title {
        font-weight: 600;
        font-size: 11px;
        margin: 0;
        color: #0f172a;
      }
      .fh-automator-clear-results {
        flex-shrink: 0;
        padding: 3px 8px;
        border: 1px solid rgba(15, 23, 42, 0.1);
        border-radius: 6px;
        background: var(--fh-surface);
        color: var(--fh-muted);
        font-size: 10px;
        font-weight: 500;
        cursor: pointer;
        white-space: nowrap;
        box-shadow: var(--fh-shadow-card);
      }
      .fh-automator-clear-results:hover {
        background: var(--fh-surface);
        border-color: rgba(10, 91, 188, 0.35);
        color: var(--fh-primary);
      }
      .fh-automator-audit-meta {
        color: #64748b;
        font-size: 10px;
        margin-bottom: 4px;
        word-break: break-all;
      }
      .fh-automator-audit-at {
        color: #495057;
        margin-bottom: 4px;
      }
      .fh-automator-audit-hint {
        color: #6c757d;
        font-size: 10px;
        margin-bottom: 4px;
      }
      .fh-automator-audit-grid {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 4px 8px;
      }
      .fh-automator-audit-grid strong {
        font-weight: 600;
      }
      .fh-automator-audit-capacity {
        font-weight: 700;
        color: var(--fh-primary);
      }
      .fh-automator-audit-section-title {
        font-weight: 600;
        margin: 5px 0 3px;
      }
      .fh-automator-audit-note {
        margin-top: 5px;
        color: #6c757d;
        font-size: 10px;
      }
      .fh-automator-status {
        margin: 0;
        padding: 6px 8px;
        border-radius: 6px;
        font-size: 11px;
        line-height: 1.4;
        display: none;
      }
      .fh-automator-status--visible {
        display: block;
      }
      .fh-automator-status--success {
        background: #ecfdf5;
        color: #047857;
        border: 1px solid #a7f3d0;
      }
      .fh-automator-status--error {
        background: #fef2f2;
        color: #b91c1c;
        border: 1px solid #fecaca;
      }
      .fh-automator-status--info {
        background: #f8fafc;
        color: #475569;
        border: 1px solid #e2e8f0;
      }
      .fh-automator-secondary {
        width: 100%;
        padding: 6px 10px;
        border: 1px solid rgba(15, 23, 42, 0.1);
        border-radius: 6px;
        background: var(--fh-surface);
        color: var(--fh-muted);
        font-size: 11px;
        font-weight: 500;
        cursor: pointer;
        box-sizing: border-box;
        box-shadow: var(--fh-shadow-card);
      }
      .fh-automator-secondary:hover {
        background: var(--fh-surface);
        border-color: rgba(10, 91, 188, 0.35);
        color: var(--fh-primary);
      }
      .fh-automator-secondary--hidden {
        display: none !important;
      }
      .fh-automator-qc-integrations {
        display: flex;
        flex-direction: column;
        gap: var(--fh-gap-tight);
      }
      .fh-automator-qc-integrations-heading {
        font-size: 11px;
        font-weight: 600;
        color: #0f172a;
        margin: 0;
      }
      .fh-automator-qc-result-row {
        margin-bottom: 6px;
      }
      .fh-automator-qc-result-label {
        color: #0f172a;
        font-weight: 500;
      }
      .fh-automator-qc-result-details {
        margin-top: 2px;
        padding-left: var(--fh-subordinate-indent);
        font-size: 10px;
        color: #475569;
        line-height: 1.3;
        white-space: pre-wrap;
      }
      .fh-automator-qc-result-details--html {
        white-space: normal;
      }
      .qc-gyg-group-mapping-details {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }
      .qc-gyg-group-intro,
      .qc-gyg-group-summary {
        color: #475569;
      }
      .qc-gyg-group-summary {
        font-weight: 500;
      }
      .qc-gyg-group-section-title {
        font-weight: 600;
        color: #334155;
        margin-bottom: 4px;
      }
      .qc-gyg-group-item {
        margin-top: 2px;
      }
      .qc-gyg-group-item-mapped {
        padding-left: 10px;
        color: #64748b;
      }
      .qc-gyg-group-collapsible {
        margin-top: 4px;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        background: #f8fafc;
        overflow: hidden;
      }
      .qc-gyg-group-collapsible-summary {
        cursor: pointer;
        padding: 6px 8px;
        font-weight: 500;
        color: #475569;
        list-style: none;
      }
      .qc-gyg-group-collapsible-summary::-webkit-details-marker {
        display: none;
      }
      .qc-gyg-group-collapsible-body {
        padding: 0 8px 8px;
        border-top: 1px solid #e2e8f0;
      }
      .qc-gyg-group-errors {
        color: #b45309;
      }
      .fh-automator-mapping-toolbar {
        margin-bottom: var(--fh-gap-section);
        padding-bottom: var(--fh-gap-tight);
        border-bottom: 1px solid #e2e8f0;
      }
      .fh-automator-mapping-toolbar-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
        margin-bottom: 4px;
      }
      .fh-automator-mapping-toolbar-title {
        margin: 0;
        font-size: 11px;
        font-weight: 600;
        color: #334155;
      }
      .fh-automator-mapping-status-snapshot {
        margin: 0 0 4px;
        padding: 5px 7px;
        border-radius: 4px;
        font-size: 10px;
        line-height: 1.35;
        color: #475569;
        background: #f8fafc;
        border: 1px solid #e2e8f0;
      }
      .fh-automator-mapping-status-snapshot--success {
        color: #166534;
        background: #f0fdf4;
        border-color: #bbf7d0;
      }
      .fh-automator-mapping-status-snapshot--error {
        color: #991b1b;
        background: #fef2f2;
        border-color: #fecaca;
      }
      .fh-automator-mapping-status-snapshot--empty {
        display: none;
      }
      .fh-automator-mapping-toolbar-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 4px;
      }
      .fh-automator-mapping-clear-status {
        padding: 4px 8px;
        font-size: 10px;
        border: 1px solid rgba(15, 23, 42, 0.1);
        border-radius: 6px;
        background: var(--fh-surface);
        color: var(--fh-muted);
        cursor: pointer;
        box-shadow: var(--fh-shadow-card);
      }
      .fh-automator-mapping-clear-status:hover {
        background: var(--fh-surface);
        border-color: rgba(10, 91, 188, 0.35);
        color: var(--fh-primary);
      }
      .fh-automator-mapping-panel {
        display: flex;
        flex-direction: column;
        gap: var(--fh-gap-section);
      }
      .fh-automator-mapping-title {
        margin: 0;
        font-size: 12px;
        font-weight: 600;
        line-height: 1.2;
        color: #0f172a;
      }
      .fh-automator-mapping-subtitle,
      .fh-automator-mapping-hint,
      .fh-automator-mapping-hub-compat {
        margin: 0;
        padding-left: var(--fh-subordinate-indent);
        font-size: 9.5px;
        color: #64748b;
        line-height: 1.25;
      }
      .fh-automator-mapping-subtitle {
        margin-top: 1px;
      }
      .fh-automator-mapping-hint {
        text-align: left;
      }
      .fh-automator-mapping-menu-option {
        display: block;
        width: 100%;
        padding: 7px 10px;
        text-align: left;
        border: 1px solid rgba(15, 23, 42, 0.06);
        border-radius: var(--fh-radius-card);
        background: var(--fh-surface);
        cursor: pointer;
        box-shadow: var(--fh-shadow-card);
      }
      .fh-automator-mapping-menu-option:hover {
        border-color: rgba(15, 23, 42, 0.1);
        box-shadow: var(--fh-shadow-card-hover);
      }
      .fh-automator-mapping-menu-option:active {
        background: #fafbfc;
      }
      .fh-automator-mapping-menu-option-title {
        font-size: 12px;
        font-weight: 600;
        color: #0f172a;
        margin: 0;
        line-height: 1.2;
      }
      .fh-automator-mapping-menu-option-desc {
        margin-top: 1px;
        padding-left: var(--fh-subordinate-indent);
        font-size: 9.5px;
        color: #64748b;
        line-height: 1.25;
      }
      .fh-automator-mapping-run {
        display: block;
        width: 100%;
        padding: 7px 10px;
        font-size: 11px;
        font-weight: 600;
        color: #fff;
        background: var(--fh-primary);
        border: none;
        border-radius: 6px;
        cursor: pointer;
        box-shadow: 0 1px 2px rgba(10, 91, 188, 0.2);
      }
      .fh-automator-mapping-run:hover:not(:disabled) {
        background: var(--fh-primary-hover);
      }
      .fh-automator-mapping-run:disabled {
        opacity: 0.5;
        cursor: not-allowed;
        box-shadow: none;
      }
      .fh-automator-mapping-button-compat {
        margin: -1px 0 2px;
        padding-left: var(--fh-subordinate-indent);
        font-size: 9.5px;
        line-height: 1.25;
        color: var(--fh-muted);
      }
      .fh-automator-mapping-button-compat--ready {
        color: var(--fh-status-ok);
      }
      .fh-automator-mapping-toggles {
        display: flex;
        flex-direction: column;
        gap: var(--fh-gap-section);
        margin: 2px 0;
      }
      .fh-automator-toggle-row {
        display: grid;
        grid-template-columns: 1fr auto 1fr;
        align-items: center;
        gap: 6px;
        width: 100%;
      }
      .fh-automator-toggle-label {
        font-size: 10px;
        color: #697886;
        font-weight: 400;
      }
      .fh-automator-toggle-label:first-child {
        justify-self: end;
        text-align: right;
      }
      .fh-automator-toggle-label:last-child {
        justify-self: start;
        text-align: left;
      }
      .fh-automator-toggle-label--active {
        color: #1f2428;
        font-weight: 500;
      }
      .fh-automator-toggle-switch {
        position: relative;
        width: 44px;
        height: 24px;
        background-color: #e2e8f0;
        border-radius: 12px;
        cursor: pointer;
        border: 1px solid rgba(15, 23, 42, 0.12);
        flex-shrink: 0;
      }
      .fh-automator-toggle-switch--active {
        background-color: rgba(10, 91, 188, 0.15);
        border-color: rgba(10, 91, 188, 0.35);
      }
      .fh-automator-toggle-switch--active .fh-automator-toggle-slider {
        transform: translateX(18px);
      }
      .fh-automator-toggle-slider {
        position: absolute;
        top: 2px;
        left: 2px;
        width: 18px;
        height: 18px;
        background-color: var(--fh-primary);
        border-radius: 50%;
        transition: transform 0.2s ease;
        box-shadow: 0 1px 2px rgba(15, 23, 42, 0.15);
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function setStatus(message, type) {
    const el = document.getElementById("fh-automator-status");
    if (!el) return;
    el.textContent = message;
    el.className = "fh-automator-status fh-automator-status--visible";
    if (type === "error") {
      el.classList.add("fh-automator-status--error");
    } else if (type === "success") {
      el.classList.add("fh-automator-status--success");
    } else {
      el.classList.add("fh-automator-status--info");
    }
  }

  function clearStatus() {
    const el = document.getElementById("fh-automator-status");
    if (!el) return;
    el.textContent = "";
    el.className = "fh-automator-status";
  }

  // Keep in sync with popup.js QC Checks page URL helpers
  function parseCompanyShortnameFromPath(pathname) {
    const parts = (pathname || "").split("/").filter(Boolean);
    return parts[0] || null;
  }

  function isAdvancedSettingsPath(pathname, shortname) {
    const normalized = (pathname || "/").replace(/\/+$/, "") || "/";
    const expected = `/${shortname}/dashboard/settings/advanced`;
    return normalized === expected;
  }

  function isGygResellerItemSettingsPath(pathname, shortname) {
    if (!shortname || !pathname) {
      return false;
    }
    const normalized = pathname || "/";
    if (!normalized.startsWith(`/${shortname}/`)) {
      return false;
    }
    if (!/\/integrations\/channels\/(?:getyourguide|gyg)(?:\/|$)/i.test(normalized)) {
      return false;
    }
    return /\/reseller-companies\/\d+\/reseller-items\/\d+/.test(normalized);
  }

  function isGoogleResellerItemSettingsPath(pathname, shortname) {
    if (!shortname || !pathname) {
      return false;
    }
    const normalized = pathname || "/";
    if (!normalized.startsWith(`/${shortname}/`)) {
      return false;
    }
    if (/\/integrations\/channels\/google(?:\/|$)/i.test(normalized)) {
      return (
        /\/reseller-companies\/\d+\/reseller-items\/\d+/.test(normalized) ||
        /\/integrations\/channels\/\d+\/items\/\d+/.test(normalized)
      );
    }
    return /\/integrations\/channels\/\d+\/items\/\d+/.test(normalized);
  }

  function isQcCompatiblePath(pathname, shortname) {
    return (
      isAdvancedSettingsPath(pathname, shortname) ||
      isGygResellerItemSettingsPath(pathname, shortname) ||
      isGoogleResellerItemSettingsPath(pathname, shortname)
    );
  }

  // Keep in sync with popup.js Duplicate Customer Types page URL helper
  function isDuplicateCustomerTypesPath(pathname) {
    const normalized = (pathname || "/").replace(/\/+$/, "") || "/";
    return /^\/[^/]+\/dashboard\/items\/[^/]+\/prices\/customer-types$/.test(normalized);
  }

  function buildAdvancedSettingsUrl(origin, shortname) {
    return `${origin}/${encodeURIComponent(shortname)}/dashboard/settings/advanced/`;
  }

  function isMappingView(viewName) {
    const view = viewName || activeView;
    return view === "mapping" || (typeof view === "string" && view.startsWith("mapping-"));
  }

  function isKnownView(name) {
    return (
      name === "home" ||
      name === "capacity" ||
      name === "duplicate" ||
      name === "qc" ||
      MAPPING_VIEW_IDS.includes(name)
    );
  }

  function updateMappingToolbarVisibility() {
    const toolbar = document.getElementById("fh-automator-mapping-toolbar");
    if (!toolbar) return;
    if (isMappingView()) {
      toolbar.classList.remove("fh-automator-view--hidden");
      updateMappingStatusSnapshotPanel();
    } else {
      toolbar.classList.add("fh-automator-view--hidden");
    }
  }

  function setHomeActionStatus(key, text, state) {
    const statusEl = document.querySelector(`[data-home-status="${key}"]`);
    const btn = document.querySelector(`[data-home-action="${key}"]`);
    if (!statusEl || !btn) return;

    statusEl.textContent = text || "";
    statusEl.className = "fh-automator-action-status";
    btn.classList.remove("fh-automator-action--muted");

    if (!text) return;

    if (state === "supported") {
      statusEl.classList.add("fh-automator-action-status--supported");
    } else if (state === "unsupported") {
      statusEl.classList.add("fh-automator-action-status--unsupported");
      if (key !== "mapping") {
        btn.classList.add("fh-automator-action--muted");
      }
    } else if (state === "checking") {
      statusEl.classList.add("fh-automator-action-status--checking");
    }
  }

  function updateOverlayHomeStatus() {
    if (activeView !== "home" || !isOverlayVisible()) return;

    setHomeActionStatus("capacity", "Checking…", "checking");
    setHomeActionStatus("duplicate", "Checking…", "checking");
    setHomeActionStatus("qc", "Checking…", "checking");
    setHomeActionStatus("mapping", "Select an integration", "checking");

    if (window.AvailabilityAudit && window.AvailabilityAudit.detectPageType) {
      const pageType = window.AvailabilityAudit.detectPageType();
      if (pageType === "booking-grid") {
        setHomeActionStatus("capacity", "Available on this page", "supported");
      } else {
        setHomeActionStatus("capacity", "Open a FareHarbor availability page", "unsupported");
      }
    } else {
      setHomeActionStatus("capacity", "Open a FareHarbor availability page", "unsupported");
    }

    const shortname = parseCompanyShortnameFromPath(location.pathname);
    if (shortname && isQcCompatiblePath(location.pathname, shortname)) {
      setHomeActionStatus("qc", "Available on this page", "supported");
    } else {
      setHomeActionStatus("qc", "Open Settings → Advanced or a GetYourGuide item settings page", "unsupported");
    }

    if (isDuplicateCustomerTypesPath(location.pathname)) {
      setHomeActionStatus("duplicate", "Available on this page", "supported");
    } else {
      setHomeActionStatus("duplicate", "Open an item customer types page", "unsupported");
    }
  }

  function wireOverlayHomeStatusRefresh() {
    document.addEventListener("visibilitychange", () => {
      if (
        document.visibilityState === "visible" &&
        isOverlayVisible() &&
        activeView === "home"
      ) {
        updateOverlayHomeStatus();
      }
    });
  }

  function showView(name) {
    const targetView = isKnownView(name) ? name : "home";
    activeView = targetView;

    const viewIds = [
      "fh-automator-view-home",
      "fh-automator-view-capacity",
      "fh-automator-view-duplicate",
      "fh-automator-view-qc",
      "fh-automator-view-mapping",
      "fh-automator-view-mapping-expedia",
      "fh-automator-view-mapping-gyg",
      "fh-automator-view-mapping-items",
      "fh-automator-view-mapping-viator",
      "fh-automator-view-mapping-airbnb",
      "fh-automator-view-mapping-google"
    ];

    viewIds.forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.classList.add("fh-automator-view--hidden");
    });

    const targetId =
      targetView === "home"
        ? "fh-automator-view-home"
        : targetView === "capacity"
          ? "fh-automator-view-capacity"
          : targetView === "duplicate"
            ? "fh-automator-view-duplicate"
            : targetView === "qc"
              ? "fh-automator-view-qc"
              : `fh-automator-view-${targetView}`;

    const targetEl = document.getElementById(targetId);
    if (targetEl) targetEl.classList.remove("fh-automator-view--hidden");

    updateMappingToolbarVisibility();

    if (activeView === "capacity") {
      runCapacityCompatibilityCheck();
    } else if (activeView === "duplicate") {
      clearStatus();
      runDuplicatePageCheck();
    } else if (activeView === "qc") {
      clearStatus();
      runQcPageCheck();
    } else if (isMappingView()) {
      refreshCopyMappingPageCheck({ retry: true });
    } else if (activeView === "home") {
      if (isOverlayVisible()) {
        updateOverlayHomeStatus();
      }
    }
  }

  function onSpaUrlChange() {
    if (!isOverlayVisible()) return;
    if (isMappingView()) {
      refreshCopyMappingPageCheck({ retry: true });
      return;
    }
    if (activeView === "home") {
      updateOverlayHomeStatus();
      return;
    }
    clearStatus();
    if (activeView === "capacity") {
      runCapacityCompatibilityCheck();
    } else if (activeView === "duplicate") {
      runDuplicatePageCheck();
    } else if (activeView === "qc") {
      runQcPageCheck();
    }
  }

  function startSpaUrlWatcher() {
    if (spaUrlWatcherStarted) return;
    spaUrlWatcherStarted = true;
    lastTrackedHref = location.href;

    setInterval(() => {
      if (location.href !== lastTrackedHref) {
        lastTrackedHref = location.href;
        onSpaUrlChange();
      }
    }, SPA_URL_POLL_MS);
  }

  // Keep in sync with popup.js validate* functions
  function validateDateFormat(dateStr) {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(dateStr)) {
      return { valid: false, error: "Date must be in YYYY-MM-DD format (e.g., 2025-08-22)" };
    }

    const date = new Date(dateStr);
    if (isNaN(date.getTime())) {
      return { valid: false, error: "Invalid date" };
    }

    return { valid: true, date: dateStr };
  }

  function validateTimeFormat(timeStr) {
    const timeRegex12 = /^(\d{1,2}):(\d{2})\s*(AM|PM)$/i;
    const timeRegex24 = /^(\d{1,2}):(\d{2})$/;

    let match = timeStr.match(timeRegex12);
    if (match) {
      const hours = parseInt(match[1], 10);
      const minutes = parseInt(match[2], 10);
      const ampm = match[3].toUpperCase();

      if (hours < 1 || hours > 12 || minutes < 0 || minutes > 59) {
        return { valid: false, error: "Invalid time format" };
      }

      let hours24 = hours;
      if (ampm === "PM" && hours !== 12) hours24 += 12;
      if (ampm === "AM" && hours === 12) hours24 = 0;

      return {
        valid: true,
        time: `${hours24.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`,
      };
    }

    match = timeStr.match(timeRegex24);
    if (match) {
      const hours = parseInt(match[1], 10);
      const minutes = parseInt(match[2], 10);

      if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
        return { valid: false, error: "Invalid time format" };
      }

      return {
        valid: true,
        time: `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`,
      };
    }

    return { valid: false, error: "Time must be in HH:MM AM/PM format (e.g., 5:30 PM)" };
  }

  function validateISODateTimeFormat(isoStr) {
    const isoRegex = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/;

    const match = isoStr.match(isoRegex);
    if (!match) {
      return {
        valid: false,
        error: "DateTime must be in YYYY-MM-DDTHH:MM:SS format (e.g., 2025-08-24T09:51:51)",
      };
    }

    const [, year, month, day, hours, minutes, seconds] = match;
    const date = new Date(`${year}-${month}-${day}T${hours}:${minutes}:${seconds || "00"}`);

    if (isNaN(date.getTime())) {
      return { valid: false, error: "Invalid date/time values" };
    }

    return {
      valid: true,
      date: `${year}-${month}-${day}`,
      time: `${hours}:${minutes}`,
    };
  }

  // Keep in sync with popup.js validatePriceFormat
  function validatePriceFormat(priceText) {
    const cleanPrice = priceText.trim();

    if (!cleanPrice) {
      return { valid: false, error: "Price cannot be empty" };
    }

    const priceRegex = /^\d+(\.\d{1,2})?$/;
    if (!priceRegex.test(cleanPrice)) {
      return {
        valid: false,
        error: "Price must be a positive number with max 2 decimal places (e.g., 76.45)",
      };
    }

    const price = parseFloat(cleanPrice);

    if (isNaN(price) || price <= 0) {
      return { valid: false, error: "Price must be a positive number greater than 0" };
    }

    if (price > 999999.99) {
      return { valid: false, error: "Price seems too large (max 999,999.99)" };
    }

    return { valid: true, price };
  }

  function formatLocalISODateTime(now) {
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, "0");
    const d = String(now.getDate()).padStart(2, "0");
    const h = String(now.getHours()).padStart(2, "0");
    const min = String(now.getMinutes()).padStart(2, "0");
    const s = String(now.getSeconds()).padStart(2, "0");
    return `${y}-${m}-${d}T${h}:${min}:${s}`;
  }

  function formatLocalManualTime(now) {
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const ampm = hours >= 12 ? "PM" : "AM";
    const displayHours = hours % 12 || 12;
    const displayMinutes = minutes.toString().padStart(2, "0");
    return `${displayHours}:${displayMinutes} ${ampm}`;
  }

  function prefillCapacityInputs() {
    const isoInput = document.getElementById("fh-automator-iso-datetime");
    const dateInput = document.getElementById("fh-automator-audit-date");
    const timeInput = document.getElementById("fh-automator-audit-time");
    if (!isoInput || !dateInput || !timeInput) return;

    const now = new Date();
    if (!isoInput.value.trim()) {
      isoInput.value = formatLocalISODateTime(now);
    }
    if (!dateInput.value.trim()) {
      dateInput.value = now.toISOString().split("T")[0];
    }
    if (!timeInput.value.trim()) {
      timeInput.value = formatLocalManualTime(now);
    }
  }

  function setCapacityFieldMode(separateFields) {
    const isoGroup = document.getElementById("fh-automator-iso-group");
    const dateGroup = document.getElementById("fh-automator-date-group");
    const timeGroup = document.getElementById("fh-automator-time-group");
    if (!isoGroup || !dateGroup || !timeGroup) return;

    if (separateFields) {
      isoGroup.classList.add("fh-automator-field--hidden");
      dateGroup.classList.remove("fh-automator-field--hidden");
      timeGroup.classList.remove("fh-automator-field--hidden");
    } else {
      isoGroup.classList.remove("fh-automator-field--hidden");
      dateGroup.classList.add("fh-automator-field--hidden");
      timeGroup.classList.add("fh-automator-field--hidden");
    }
  }

  function setCapacityCompatMessage(message, state) {
    const el = document.getElementById("fh-automator-capacity-compat");
    if (!el) return;
    el.textContent = message;
    el.className = "fh-automator-capacity-compat";
    if (state === "ready") {
      el.classList.add("fh-automator-capacity-compat--ready");
    } else if (state === "blocked") {
      el.classList.add("fh-automator-capacity-compat--blocked");
    }
  }

  function getCompatMessageState() {
    if (currentPageCanAudit) return "ready";
    if (lastCapacityResults) return null;
    return "blocked";
  }

  function applyCapacityCompatUI() {
    const runBtn = document.getElementById("fh-automator-run-audit");
    setCapacityCompatMessage(currentPageStatusMessage, getCompatMessageState());
    if (runBtn && runBtn.textContent === "Run") {
      runBtn.disabled = !currentPageCanAudit;
    }
  }

  function truncateUrl(url, maxLen) {
    if (!url || url.length <= maxLen) return url || "";
    return url.slice(0, maxLen - 1) + "…";
  }

  function waitForAvailabilityAudit(onReady, onTimeout) {
    let attempts = 0;

    function poll() {
      if (window.AvailabilityAudit && window.AvailabilityAudit.detectPageType) {
        onReady();
        return;
      }
      attempts += 1;
      if (attempts >= AUDIT_POLL_MAX) {
        onTimeout();
        return;
      }
      setTimeout(poll, AUDIT_POLL_MS);
    }

    poll();
  }

  function runCapacityCompatibilityCheck() {
    if (activeView !== "capacity") return;

    const runBtn = document.getElementById("fh-automator-run-audit");
    if (!runBtn) return;

    currentPageCanAudit = false;
    currentPageStatusMessage = "Checking page compatibility...";
    applyCapacityCompatUI();
    if (runBtn.textContent === "Run") {
      runBtn.disabled = true;
    }

    if (!window.AvailabilityAudit || !window.AvailabilityAudit.detectPageType) {
      currentPageCanAudit = false;
      currentPageStatusMessage = "Capacity Check is still loading, try again in a moment.";
      applyCapacityCompatUI();
      updateResultsPanel();
      waitForAvailabilityAudit(
        () => {
          if (activeView === "capacity") runCapacityCompatibilityCheck();
        },
        () => {
          currentPageCanAudit = false;
          currentPageStatusMessage = "Capacity Check is still loading, try again in a moment.";
          applyCapacityCompatUI();
          updateResultsPanel();
        }
      );
      return;
    }

    const pageType = window.AvailabilityAudit.detectPageType();
    currentPageCanAudit = pageType === "booking-grid";

    if (currentPageCanAudit) {
      currentPageStatusMessage = "Compatible page — ready for check";
      prefillCapacityInputs();
    } else if (lastCapacityResults) {
      currentPageStatusMessage = "Current page is not compatible for a new check.";
    } else {
      currentPageStatusMessage =
        "Open an availability with bookings on this page to run Capacity Check.";
    }

    applyCapacityCompatUI();
    updateResultsPanel();
  }

  function resolveResourceDisplayCount(value) {
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (value && typeof value === "object") {
      if (typeof value._total === "number") return value._total;
      if (typeof value.quantity === "number") return value.quantity;
    }
    return null;
  }

  function formatResourcesUsedHtml(resourcesUsed) {
    if (!resourcesUsed || Object.keys(resourcesUsed).length === 0) {
      return "";
    }

    let html =
      '<div class="fh-automator-audit-section-title">Resources Used:</div><div class="fh-automator-audit-grid">';
    for (const [resourceName, value] of Object.entries(resourcesUsed)) {
      if (resourceName === "_total") continue;
      if (typeof value !== "number" || !Number.isFinite(value)) {
        console.warn("[capacity-api] renderer skipped non-numeric resourcesUsed entry", {
          resourceName,
          value
        });
        continue;
      }
      html += `<span><strong>${resourceName}:</strong></span><span>${value}</span>`;
    }
    html += "</div>";
    return html;
  }

  function formatCustomerTypesUsedHtml(customerTypesUsed) {
    if (!customerTypesUsed || Object.keys(customerTypesUsed).length === 0) {
      return "";
    }

    let html =
      '<div class="fh-automator-audit-section-title">Customer Types Used:</div><div class="fh-automator-audit-grid">';
    for (const [typeName, count] of Object.entries(customerTypesUsed)) {
      html += `<span><strong>${typeName}:</strong></span><span>${count}</span>`;
    }
    html += "</div>";
    return html;
  }

  function clearLastCapacityResults() {
    lastCapacityResults = null;
    updateResultsPanel();
  }

  function buildAuditResultsBodyHtml(auditData) {
    const targetDate = new Date(auditData.targetDateTime);
    const targetDateStr = targetDate.toLocaleDateString();
    const targetTimeStr = targetDate.toLocaleTimeString();
    let detailHint = "";
    if (auditData.fallbackWarning) {
      detailHint = `<div class="fh-automator-audit-hint fh-automator-audit-hint--warn">${auditData.fallbackWarning}</div>`;
    } else if (auditData.apiSource) {
      detailHint = '<div class="fh-automator-audit-hint">Capacity from FareHarbor API</div>';
    } else if (!auditData.detailedInfoFetched) {
      detailHint = '<div class="fh-automator-audit-hint">Basic capacity info (from page display)</div>';
    }

    return `
      <div class="fh-automator-audit-at">Capacity at: ${targetDateStr} at ${targetTimeStr}</div>
      ${detailHint}
      <div class="fh-automator-audit-grid">
        <span><strong>Total Bookings:</strong></span>
        <span>${auditData.originalBookingsCount}</span>
        <span><strong>Active Bookings:</strong></span>
        <span>${auditData.filteredBookingsCount}</span>
        <span><strong>Total Customer Types:</strong></span>
        <span class="fh-automator-audit-capacity">${auditData.totalCapacityUsed}</span>
      </div>
      ${formatResourcesUsedHtml(auditData.resourcesUsed)}
      ${formatCustomerTypesUsedHtml(auditData.customerTypesUsed)}
      <div class="fh-automator-audit-note">
        Note: Includes cancelled bookings that were cancelled after target time
      </div>
    `;
  }

  function updateResultsPanel() {
    const resultsEl = document.getElementById("fh-automator-audit-results");
    const staleEl = document.getElementById("fh-automator-results-stale-warning");
    if (!resultsEl) return;

    if (!lastCapacityResults) {
      resultsEl.classList.remove("fh-automator-audit-results--visible");
      resultsEl.innerHTML = "";
      if (staleEl) {
        staleEl.textContent = "";
        staleEl.classList.add("fh-automator-view--hidden");
      }
      return;
    }

    const { auditData, pageUrl, targetDate, targetTime, auditedAt } = lastCapacityResults;
    console.log("[capacity-api] result.resourcesUsed before render", auditData.resourcesUsed);
    const auditedAtStr = new Date(auditedAt).toLocaleString();
    const pageDisplay = truncateUrl(pageUrl, 56);

    resultsEl.innerHTML = `
      <div class="fh-automator-results-header">
        <span class="fh-automator-audit-results-title">Results</span>
        <button type="button" id="fh-automator-clear-results" class="fh-automator-clear-results">Clear results</button>
      </div>
      <div class="fh-automator-audit-meta">Checked at: ${auditedAtStr}</div>
      <div class="fh-automator-audit-meta">Page: ${pageDisplay}</div>
      <div class="fh-automator-audit-meta">Target: ${targetDate} ${targetTime}</div>
      ${buildAuditResultsBodyHtml(auditData)}
    `;
    resultsEl.classList.add("fh-automator-audit-results--visible");

    if (staleEl) {
      if (!currentPageCanAudit) {
        staleEl.textContent =
          "These results are from the last completed check. Open an availability with bookings to run a new check.";
        staleEl.classList.remove("fh-automator-view--hidden");
      } else {
        staleEl.textContent = "";
        staleEl.classList.add("fh-automator-view--hidden");
      }
    }
  }

  async function handleCapacityRun() {
    if (
      !window.AvailabilityAudit ||
      (!window.AvailabilityAudit.runAvailabilityAuditApiFirst &&
        !window.AvailabilityAudit.runAvailabilityAudit)
    ) {
      setStatus("Capacity Check is still loading, try again in a moment.", "error");
      return;
    }

    const runBtn = document.getElementById("fh-automator-run-audit");
    if (!runBtn || runBtn.disabled) {
      return;
    }

    const separateFields = document.getElementById("fh-automator-separate-fields").checked;
    const fetchDetailedInfo = document.getElementById("fh-automator-fetch-detailed").checked;

    let validatedDate;
    let validatedTime;

    if (separateFields) {
      const dateInput = document.getElementById("fh-automator-audit-date");
      const timeInput = document.getElementById("fh-automator-audit-time");
      const targetDate = dateInput.value.trim();
      const targetTime = timeInput.value.trim();

      if (!targetDate) {
        setStatus("Please enter a target date.", "error");
        return;
      }
      if (!targetTime) {
        setStatus("Please enter a target time.", "error");
        return;
      }

      const dateValidation = validateDateFormat(targetDate);
      if (!dateValidation.valid) {
        setStatus(`Invalid date: ${dateValidation.error}`, "error");
        dateInput.focus();
        return;
      }

      const timeValidation = validateTimeFormat(targetTime);
      if (!timeValidation.valid) {
        setStatus(`Invalid time: ${timeValidation.error}`, "error");
        timeInput.focus();
        return;
      }

      validatedDate = dateValidation.date;
      validatedTime = timeValidation.time;
    } else {
      const isoInput = document.getElementById("fh-automator-iso-datetime");
      const isoValue = isoInput.value.trim();

      if (!isoValue) {
        setStatus("Please enter a target date and time.", "error");
        return;
      }

      const isoValidation = validateISODateTimeFormat(isoValue);
      if (!isoValidation.valid) {
        setStatus(`Invalid date/time: ${isoValidation.error}`, "error");
        isoInput.focus();
        return;
      }

      validatedDate = isoValidation.date;
      validatedTime = isoValidation.time;
    }

    clearLastCapacityResults();
    const statusMessage = fetchDetailedInfo
      ? "Running capacity check (API first)..."
      : "Running capacity check (API first)...";
    setStatus(statusMessage, "info");

    const originalText = runBtn.textContent;
    runBtn.disabled = true;
    runBtn.textContent = fetchDetailedInfo ? "Fetching details..." : "Running...";

    try {
      const runAudit =
        window.AvailabilityAudit.runAvailabilityAuditApiFirst ||
        window.AvailabilityAudit.runAvailabilityAudit;
      const result = await runAudit(validatedDate, validatedTime, fetchDetailedInfo);

      if (result && result.success) {
        lastCapacityResults = {
          auditData: result,
          pageUrl: location.href,
          targetDate: validatedDate,
          targetTime: validatedTime,
          auditedAt: new Date().toISOString(),
        };
        updateResultsPanel();
        if (result.fallbackWarning) {
          setStatus(result.fallbackWarning, "error");
        } else {
          const successMessage = result.apiSource
            ? "Capacity check completed (API)."
            : fetchDetailedInfo
              ? "Detailed audit completed successfully!"
              : "Audit completed successfully!";
          setStatus(successMessage, "success");
        }
      } else {
        setStatus("Error: " + (result?.error || "Unknown error occurred"), "error");
      }
    } catch (err) {
      console.error("[overlay] Capacity check failed", err);
      setStatus("Error: " + (err.message || "Audit failed"), "error");
    } finally {
      runBtn.textContent = originalText;
      runCapacityCompatibilityCheck();
    }
  }

  function wireCapacitySection(root) {
    const separateCheckbox = root.querySelector("#fh-automator-separate-fields");
    const runBtn = root.querySelector("#fh-automator-run-audit");
    const refreshBtn = root.querySelector("#fh-automator-refresh-compat");

    setCapacityFieldMode(separateCheckbox.checked);
    separateCheckbox.addEventListener("change", () => {
      setCapacityFieldMode(separateCheckbox.checked);
    });

    runBtn.addEventListener("click", () => {
      handleCapacityRun();
    });

    root.addEventListener("click", (e) => {
      if (e.target && e.target.id === "fh-automator-clear-results") {
        clearLastCapacityResults();
        clearStatus();
        runCapacityCompatibilityCheck();
      }
    });

    if (refreshBtn) {
      refreshBtn.addEventListener("click", () => {
        runCapacityCompatibilityCheck();
      });
    }

    document.addEventListener("visibilitychange", () => {
      if (
        document.visibilityState === "visible" &&
        isOverlayVisible() &&
        activeView === "capacity"
      ) {
        runCapacityCompatibilityCheck();
      }
    });
  }

  function setDuplicateCompatMessage(message, state) {
    const el = document.getElementById("fh-automator-duplicate-compat");
    if (!el) return;
    el.textContent = message;
    el.className = "fh-automator-capacity-compat";
    if (state === "ready") {
      el.classList.add("fh-automator-capacity-compat--ready");
    } else if (state === "blocked") {
      el.classList.add("fh-automator-capacity-compat--blocked");
    }
  }

  function getDuplicateCompatState() {
    if (currentPageHasCustomerTypes) return "ready";
    return "blocked";
  }

  function applyDuplicateCompatUI() {
    const startBtn = document.getElementById("fh-automator-start-duplicate");
    setDuplicateCompatMessage(duplicateCompatMessage, getDuplicateCompatState());
    if (startBtn && startBtn.textContent === "Start Duplication") {
      startBtn.disabled = !currentPageHasCustomerTypes;
    }
  }

  function waitForDuplicateCustomerTypes(onReady, onTimeout) {
    let attempts = 0;

    function poll() {
      if (window.DuplicateCustomerTypes && window.DuplicateCustomerTypes.handleMessage) {
        onReady();
        return;
      }
      attempts += 1;
      if (attempts >= AUDIT_POLL_MAX) {
        onTimeout();
        return;
      }
      setTimeout(poll, AUDIT_POLL_MS);
    }

    poll();
  }

  function updateDuplicateBaseNameFromSelection() {
    const select = document.getElementById("fh-automator-customer-type-select");
    const baseNameInput = document.getElementById("fh-automator-basename");
    if (!select || !baseNameInput || select.selectedIndex < 0) return;

    const selectedOption = select.options[select.selectedIndex];
    const customerTypeName =
      selectedOption.getAttribute("data-name") || selectedOption.textContent;
    const currentBaseName = baseNameInput.value.trim();
    const allOptions = Array.from(select.options);
    const isLikelyDefault =
      currentBaseName === "Adult" ||
      allOptions.some((option) => option.getAttribute("data-name") === currentBaseName);

    if (isLikelyDefault || currentBaseName === "") {
      baseNameInput.value = customerTypeName;
    }
  }

  function populateDuplicateSelect(customerTypes) {
    const select = document.getElementById("fh-automator-customer-type-select");
    if (!select) return;

    select.innerHTML = "";
    customerTypes.forEach((type) => {
      const option = document.createElement("option");
      option.value = type.domIndex;
      option.textContent = type.name;
      option.setAttribute("data-name", type.name);
      select.appendChild(option);
    });

    if (customerTypes.length > 0) {
      select.selectedIndex = 0;
      updateDuplicateBaseNameFromSelection();
    }
  }

  function runDuplicatePageCheck() {
    if (activeView !== "duplicate") return;

    const startBtn = document.getElementById("fh-automator-start-duplicate");
    if (!startBtn) return;

    currentPageHasCustomerTypes = false;

    if (!isDuplicateCustomerTypesPath(location.pathname)) {
      duplicateCompatMessage =
        "Open an item customer types page to use Duplicate Customer Types.";
      applyDuplicateCompatUI();
      if (startBtn.textContent === "Start Duplication") {
        startBtn.disabled = true;
      }
      return;
    }

    duplicateCompatMessage = "Checking for customer types...";
    applyDuplicateCompatUI();
    if (startBtn.textContent === "Start Duplication") {
      startBtn.disabled = true;
    }

    if (!window.DuplicateCustomerTypes || !window.DuplicateCustomerTypes.handleMessage) {
      duplicateCompatMessage = "Duplicate Customer Types is still loading, try again in a moment.";
      applyDuplicateCompatUI();
      waitForDuplicateCustomerTypes(
        () => {
          if (activeView === "duplicate") runDuplicatePageCheck();
        },
        () => {
          duplicateCompatMessage =
            "Duplicate Customer Types is still loading, try again in a moment.";
          applyDuplicateCompatUI();
        }
      );
      return;
    }

    window.DuplicateCustomerTypes.handleMessage({ action: "getCustomerTypes" }, null, (res) => {
      if (activeView !== "duplicate") return;

      const customerTypes = res && res.customerTypes ? res.customerTypes : [];

      populateDuplicateSelect(customerTypes);

      if (customerTypes.length === 0) {
        currentPageHasCustomerTypes = false;
        duplicateCompatMessage = "No customer types found on this page.";
      } else {
        currentPageHasCustomerTypes = true;
        duplicateCompatMessage = `Found ${customerTypes.length} customer type(s) — ready to duplicate`;
      }

      applyDuplicateCompatUI();
    });
  }

  async function handleDuplicateRun() {
    if (!window.DuplicateCustomerTypes || !window.DuplicateCustomerTypes.runMultipleDuplicates) {
      setStatus("Duplicate Customer Types is still loading, try again in a moment.", "error");
      return;
    }

    const startBtn = document.getElementById("fh-automator-start-duplicate");
    if (!startBtn || startBtn.disabled) return;

    const countInput = document.getElementById("fh-automator-duplicate-count");
    const baseInput = document.getElementById("fh-automator-basename");
    const typeSelect = document.getElementById("fh-automator-customer-type-select");
    const priceInput = document.getElementById("fh-automator-price-input");

    const count = parseInt(countInput.value, 10);
    const basename = baseInput.value.trim();
    const baseIndex = parseInt(typeSelect.value, 10);
    const priceText = priceInput.value.trim();

    if (isNaN(count) || count < 1 || count > 15) {
      setStatus("Please enter a number between 1 and 15.", "error");
      return;
    }

    if (!basename) {
      setStatus("Please enter a base name.", "error");
      return;
    }

    if (typeSelect.options.length === 0) {
      setStatus(
        "No customer types available. Please make sure you're on the correct page.",
        "error"
      );
      return;
    }

    let price = null;
    if (priceText) {
      const priceValidation = validatePriceFormat(priceText);
      if (!priceValidation.valid) {
        setStatus(`Invalid price: ${priceValidation.error}`, "error");
        priceInput.focus();
        return;
      }
      price = priceValidation.price;
    }

    setStatus(`Starting duplication of ${count} customer types...`, "info");

    const originalText = startBtn.textContent;
    startBtn.disabled = true;
    startBtn.textContent = "Processing...";

    try {
      await window.DuplicateCustomerTypes.runMultipleDuplicates(
        count,
        basename,
        baseIndex,
        price
      );
      setStatus(`Successfully created ${count} duplicate customer types.`, "success");
    } catch (err) {
      console.error("[overlay] Duplicate customer types failed", err);
      setStatus("Error: " + (err.message || "Duplication failed"), "error");
    } finally {
      startBtn.textContent = originalText;
      runDuplicatePageCheck();
    }
  }

  function wireDuplicateSection(root) {
    const refreshBtn = root.querySelector("#fh-automator-refresh-duplicate-types");
    const startBtn = root.querySelector("#fh-automator-start-duplicate");
    const typeSelect = root.querySelector("#fh-automator-customer-type-select");

    if (refreshBtn) {
      refreshBtn.addEventListener("click", () => {
        runDuplicatePageCheck();
      });
    }

    if (typeSelect) {
      typeSelect.addEventListener("change", () => {
        updateDuplicateBaseNameFromSelection();
      });
    }

    if (startBtn) {
      startBtn.addEventListener("click", () => {
        handleDuplicateRun();
      });
    }

    document.addEventListener("visibilitychange", () => {
      if (
        document.visibilityState === "visible" &&
        isOverlayVisible() &&
        activeView === "duplicate"
      ) {
        runDuplicatePageCheck();
      }
    });
  }

  function setQcCompatMessage(message, state) {
    const el = document.getElementById("fh-automator-qc-compat");
    if (!el) return;
    el.textContent = message;
    el.className = "fh-automator-capacity-compat";
    if (state === "ready") {
      el.classList.add("fh-automator-capacity-compat--ready");
    } else if (state === "blocked") {
      el.classList.add("fh-automator-capacity-compat--blocked");
    }
  }

  function getQcCompatState() {
    if (currentPageQcReady) return "ready";
    if (lastQcResults) return null;
    return "blocked";
  }

  function applyQcCompatUI() {
    const runBtn = document.getElementById("fh-automator-run-qc");
    const goBtn = document.getElementById("fh-automator-go-advanced");
    setQcCompatMessage(qcCompatMessage, getQcCompatState());
    if (goBtn) {
      if (currentPageQcReady) {
        goBtn.classList.add("fh-automator-secondary--hidden");
      } else {
        goBtn.classList.remove("fh-automator-secondary--hidden");
      }
    }
    if (runBtn && runBtn.textContent === "Run QC Checks") {
      runBtn.disabled = !currentPageQcReady;
    }
  }

  function waitForQCChecks(onReady, onTimeout) {
    let attempts = 0;

    function poll() {
      if (window.QCChecks && window.QCChecks.runQCChecks) {
        onReady();
        return;
      }
      attempts += 1;
      if (attempts >= AUDIT_POLL_MAX) {
        onTimeout();
        return;
      }
      setTimeout(poll, AUDIT_POLL_MS);
    }

    poll();
  }

  function getSelectedQcIntegrations() {
    return Array.from(
      document.querySelectorAll(".fh-automator-qc-integration-checkbox:checked")
    )
      .map((checkbox) => checkbox.value)
      .filter(Boolean);
  }

  function escapeQcResultDetailsText(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function buildQcResultsBodyHtml(checks) {
    const icons = {
      pass: "\u2705",
      fail: "\u274C",
      warning: "\u26A0\uFE0F",
      error: "\u26A0\uFE0F",
      skip: "\u23ED"
    };
    if (!checks || checks.length === 0) {
      return "";
    }

    return checks
      .map((check) => {
        const icon = icons[check.status] || icons.error;
        const label = check.label || check.key || "Check";
        let detailsHtml = "";
        if (check.detailsHtml) {
          detailsHtml = `<div class="fh-automator-qc-result-details fh-automator-qc-result-details--html">${check.detailsHtml}</div>`;
        } else if (check.details) {
          detailsHtml = `<div class="fh-automator-qc-result-details">${escapeQcResultDetailsText(check.details)}</div>`;
        }
        return `<div class="fh-automator-qc-result-row"><div class="fh-automator-qc-result-label">${icon} ${label}</div>${detailsHtml}</div>`;
      })
      .join("");
  }

  function clearLastQcResults() {
    lastQcResults = null;
    updateQcResultsPanel();
  }

  function updateQcResultsPanel() {
    const resultsEl = document.getElementById("fh-automator-qc-results");
    const staleEl = document.getElementById("fh-automator-qc-results-stale-warning");
    if (!resultsEl) return;

    if (!lastQcResults) {
      resultsEl.classList.remove("fh-automator-audit-results--visible");
      resultsEl.innerHTML = "";
      if (staleEl) {
        staleEl.textContent = "";
        staleEl.classList.add("fh-automator-view--hidden");
      }
      return;
    }

    const { checks, pageUrl, completedAt } = lastQcResults;
    const completedAtStr = new Date(completedAt).toLocaleString();
    const pageDisplay = truncateUrl(pageUrl, 56);

    resultsEl.innerHTML = `
      <div class="fh-automator-results-header">
        <span class="fh-automator-audit-results-title">Results</span>
        <button type="button" id="fh-automator-clear-qc-results" class="fh-automator-clear-results">Clear results</button>
      </div>
      <div class="fh-automator-audit-meta">Checked at: ${completedAtStr}</div>
      <div class="fh-automator-audit-meta">Page: ${pageDisplay}</div>
      ${buildQcResultsBodyHtml(checks)}
    `;
    resultsEl.classList.add("fh-automator-audit-results--visible");

    if (staleEl) {
      if (!currentPageQcReady) {
        staleEl.textContent =
          "These results are from the last completed check. Open Settings > Advanced or a GetYourGuide item settings page to run a new check.";
        staleEl.classList.remove("fh-automator-view--hidden");
      } else {
        staleEl.textContent = "";
        staleEl.classList.add("fh-automator-view--hidden");
      }
    }
  }

  function runQcPageCheck() {
    if (activeView !== "qc") return;

    const runBtn = document.getElementById("fh-automator-run-qc");
    if (!runBtn) return;

    currentPageQcReady = false;
    qcCompatMessage = "Checking page compatibility...";
    applyQcCompatUI();
    if (runBtn.textContent === "Run QC Checks") {
      runBtn.disabled = true;
    }

    if (!window.QCChecks || !window.QCChecks.runQCChecks) {
      qcCompatMessage = "QC Check is still loading, try again in a moment.";
      applyQcCompatUI();
      updateQcResultsPanel();
      waitForQCChecks(
        () => {
          if (activeView === "qc") runQcPageCheck();
        },
        () => {
          qcCompatMessage = "QC Check is still loading, try again in a moment.";
          applyQcCompatUI();
          updateQcResultsPanel();
        }
      );
      return;
    }

    const shortname = parseCompanyShortnameFromPath(location.pathname);
    if (!shortname) {
      qcCompatMessage = "Could not determine company shortname from the current URL.";
      applyQcCompatUI();
      updateQcResultsPanel();
      return;
    }

    const isOnCompatiblePage = isQcCompatiblePath(location.pathname, shortname);
    const isOnAdvancedSettings = isAdvancedSettingsPath(location.pathname, shortname);
    const isOnGygItemSettings = isGygResellerItemSettingsPath(location.pathname, shortname);
    currentPageQcReady = isOnCompatiblePage;

    if (isOnAdvancedSettings) {
      qcCompatMessage = "Ready to run QC checks.";
    } else if (isOnGygItemSettings) {
      qcCompatMessage =
        "Ready to run QC checks. GetYourGuide Group ticket category mapping will be checked on this page.";
    } else if (lastQcResults) {
      qcCompatMessage = "Current page is not compatible for a new check.";
    } else {
      qcCompatMessage =
        "QC Checks must be run from Settings > Advanced, or a GetYourGuide or Google reseller item settings page.";
    }

    applyQcCompatUI();
    updateQcResultsPanel();
  }

  async function handleQcRun() {
    if (!window.QCChecks || !window.QCChecks.runQCChecks) {
      setStatus("QC Check is still loading, try again in a moment.", "error");
      return;
    }

    const runBtn = document.getElementById("fh-automator-run-qc");
    if (!runBtn || runBtn.disabled) return;

    const shortname = parseCompanyShortnameFromPath(location.pathname);
    if (!shortname || !isQcCompatiblePath(location.pathname, shortname)) {
      setStatus(
        "QC Checks must be run from Settings > Advanced, or a GetYourGuide or Google reseller item settings page.",
        "error"
      );
      return;
    }

    clearLastQcResults();
    const selectedIntegrations = getSelectedQcIntegrations();

    const originalText = runBtn.textContent;
    runBtn.disabled = true;
    runBtn.textContent = "Running...";
    setStatus("Running QC checks...", "info");

    try {
      const response = await window.QCChecks.runQCChecks(selectedIntegrations);

      if (!response || response.success === false) {
        setStatus(response?.error || "QC checks failed.", "error");
        if (response?.checks?.length) {
          lastQcResults = {
            checks: response.checks,
            pageUrl: location.href,
            selectedIntegrations,
            completedAt: new Date().toISOString(),
          };
          updateQcResultsPanel();
        }
        return;
      }

      lastQcResults = {
        checks: response.checks,
        pageUrl: location.href,
        selectedIntegrations,
        completedAt: new Date().toISOString(),
      };
      updateQcResultsPanel();

      const failed = (response.checks || []).some(
        (c) => c.status === "fail" || c.status === "error"
      );
      if (failed) {
        setStatus("QC checks completed with issues.", "error");
      } else {
        setStatus("All QC checks passed.", "success");
      }
    } catch (err) {
      console.error("[overlay] QC check failed", err);
      setStatus("Error: " + (err.message || "QC checks failed"), "error");
    } finally {
      runBtn.textContent = originalText;
      runQcPageCheck();
    }
  }

  function handleGoToAdvancedSettings() {
    const shortname = parseCompanyShortnameFromPath(location.pathname);
    if (!shortname) {
      setStatus("Could not determine company shortname from the current URL.", "error");
      return;
    }
    location.assign(buildAdvancedSettingsUrl(location.origin, shortname));
  }

  function wireQcSection(root) {
    const refreshBtn = root.querySelector("#fh-automator-refresh-qc-compat");
    const goBtn = root.querySelector("#fh-automator-go-advanced");
    const runBtn = root.querySelector("#fh-automator-run-qc");

    if (refreshBtn) {
      refreshBtn.addEventListener("click", () => {
        runQcPageCheck();
      });
    }

    if (goBtn) {
      goBtn.addEventListener("click", () => {
        handleGoToAdvancedSettings();
      });
    }

    if (runBtn) {
      runBtn.addEventListener("click", () => {
        handleQcRun();
      });
    }

    root.addEventListener("click", (e) => {
      if (e.target && e.target.id === "fh-automator-clear-qc-results") {
        clearLastQcResults();
        clearStatus();
        runQcPageCheck();
      }
    });

    document.addEventListener("visibilitychange", () => {
      if (
        document.visibilityState === "visible" &&
        isOverlayVisible() &&
        activeView === "qc"
      ) {
        runQcPageCheck();
      }
    });
  }

  function formatExpediaDataForClipboard(data) {
    if (window.ExpediaMapping?.formatExpediaDataForClipboard) {
      return window.ExpediaMapping.formatExpediaDataForClipboard(data);
    }

    let formattedText = "";
    data.forEach((row) => {
      const [type, detail, code] = row;
      if (type === "Activity") {
        formattedText += `Activity: ${detail}\n`;
        formattedText += `Code: ${code}\n\n`;
      } else if (type === "Offer") {
        if (formattedText && !formattedText.includes("Available Times:")) {
          formattedText += "Available Times:\n";
        }
        formattedText += `- ${detail} (${code})\n`;
      } else if (type === "TicketType") {
        if (formattedText && !formattedText.includes("Ticket Types:")) {
          formattedText += "\nTicket Types:\n";
        }
        formattedText += `- ${detail} (${code})\n`;
      }
    });
    return formattedText;
  }

  function dispatchToModule(module, req, onResult) {
    if (!module || !module.handleMessage) {
      onResult({ status: "error", error: "Module not loaded" });
      return;
    }
    module.handleMessage(req, null, onResult);
  }

  const MAPPING_COMPLETE_ON_SINGLE_PAGE_REASON =
    "Complete mapping file is only available from the full mapping/list page.";

  const MAPPING_COMPAT_HINTS = {
    "expedia-single":
      "Open an Expedia single item configuration page.",
    "expedia-ro":
      "Open an Expedia single item configuration page.",
    "expedia-complete":
      "Open the Expedia reseller items page.",
    "gyg-single":
      "Open a GetYourGuide single item configuration page.",
    "gyg-complete":
      "Open the FareHarbor reseller items page for GetYourGuide.",
    "gyg-explanation":
      "Open a GetYourGuide mapping page with Price and min/max settings enabled.",
    "items-copy":
      "Open the Items list page with the ID column visible.",
    "viator-complete":
      "Open the Viator reseller items page.",
    "airbnb-complete":
      "Open the Airbnb reseller items page.",
    "google-zendesk":
      "Open any FareHarbor dashboard page for the company.",
    "google-sheets":
      "Open any FareHarbor dashboard page for the company."
  };

  function setMappingButtonCompat(buttonKey, ready, hint) {
    const btn = document.querySelector(`[data-mapping-button="${buttonKey}"]`);
    const compatEl = document.querySelector(`[data-mapping-compat="${buttonKey}"]`);
    if (btn) btn.disabled = !ready;
    if (!compatEl) return;
    if (ready) {
      compatEl.textContent = hint || "Ready on this page.";
      compatEl.className =
        "fh-automator-mapping-button-compat fh-automator-mapping-button-compat--ready";
    } else {
      compatEl.textContent =
        hint || MAPPING_COMPAT_HINTS[buttonKey] || "Not available on this page.";
      compatEl.className = "fh-automator-mapping-button-compat";
    }
  }

  function updateMappingStatusSnapshotPanel() {
    const el = document.getElementById("fh-automator-mapping-status-snapshot");
    if (!el) return;
    if (!lastMappingCopyStatus) {
      el.textContent = "";
      el.className = "fh-automator-mapping-status-snapshot fh-automator-mapping-status-snapshot--empty";
      return;
    }
    const { label, message, type, completedAt, pageUrl } = lastMappingCopyStatus;
    const when = completedAt ? new Date(completedAt).toLocaleString() : "";
    const page = pageUrl ? truncateUrl(pageUrl, 48) : "";
    el.textContent = `${label}: ${message}${when ? ` (${when})` : ""}${page ? ` — ${page}` : ""}`;
    el.className = "fh-automator-mapping-status-snapshot";
    if (type === "success") {
      el.classList.add("fh-automator-mapping-status-snapshot--success");
    } else if (type === "error") {
      el.classList.add("fh-automator-mapping-status-snapshot--error");
    }
  }

  function setMappingStatusSnapshot(snapshot) {
    lastMappingCopyStatus = snapshot;
    updateMappingStatusSnapshotPanel();
  }

  function clearMappingStatusSnapshot() {
    lastMappingCopyStatus = null;
    updateMappingStatusSnapshotPanel();
    clearStatus();
  }

  function copyTextToClipboard(text, onSuccess, onError) {
    navigator.clipboard
      .writeText(text)
      .then(onSuccess)
      .catch((err) => {
        console.error("[overlay] Clipboard copy failed", err);
        if (onError) onError(err);
      });
  }

  function getMappingButtonKeysForView(viewName) {
    const buttonKeysByView = {
      "mapping-expedia": ["expedia-single", "expedia-ro", "expedia-complete"],
      "mapping-gyg": ["gyg-single", "gyg-complete", "gyg-explanation"],
      "mapping-items": ["items-copy"],
      "mapping-viator": ["viator-complete"],
      "mapping-airbnb": ["airbnb-complete"],
      "mapping-google": ["google-zendesk", "google-sheets"]
    };
    return buttonKeysByView[viewName] || [];
  }

  function areMappingModulesReady() {
    return !!(
      window.ExpediaMapping &&
      window.FareHarborResellerItems &&
      window.FareHarborItems &&
      window.ViatorMappingFile &&
      window.AirbnbMappingFile
    );
  }

  function probeGoogleMappingCopyAvailability() {
    const fallbackReason = MAPPING_COMPAT_HINTS["google-zendesk"];
    if (!window.GoogleMappingData || !window.QCChecks?.collectGoogleMappingCopyEntries) {
      return { enabled: false, reason: "Google mapping module not loaded. Reload the page." };
    }
    if (!isFareHarborHost()) {
      return { enabled: false, reason: fallbackReason };
    }
    const parts = (location.pathname || "").split("/").filter(Boolean);
    if (!parts[0]) {
      return {
        enabled: false,
        reason: "Could not determine company shortname from the current URL."
      };
    }
    return { enabled: true, reason: "" };
  }

  function probeExpediaSingleItem() {
    return !!(window.ExpediaMapping && window.ExpediaMapping.getItemCode());
  }

  function probeGygSingleItem() {
    if (!window.FareHarborResellerItems) return false;
    const data = window.FareHarborResellerItems.scrapeSingleResellerItem(false);
    return !!(data && data.length > 0);
  }

  function isGygResellerListPage() {
    return !!(
      document.querySelector('table[ng-if="resellerItems.length"]') ||
      document.querySelector('table[ng-table="resellerItems"]')
    );
  }

  function probeExpediaCompleteAvailability() {
    const fallbackReason = MAPPING_COMPAT_HINTS["expedia-complete"];
    if (!window.ExpediaMapping) {
      return { enabled: false, reason: fallbackReason };
    }
    if (probeExpediaSingleItem()) {
      return { enabled: false, reason: MAPPING_COMPLETE_ON_SINGLE_PAGE_REASON };
    }
    const result = window.ExpediaMapping.scrapeCompleteResellerItems();
    const enabled = !!(result && result.success && result.data && result.data.length > 0);
    return {
      enabled,
      reason: enabled ? "" : fallbackReason
    };
  }

  function probeGygCompleteAvailability() {
    const fallbackReason = MAPPING_COMPAT_HINTS["gyg-complete"];
    if (!window.FareHarborResellerItems) {
      return { enabled: false, reason: fallbackReason };
    }
    if (probeGygSingleItem()) {
      return { enabled: false, reason: MAPPING_COMPLETE_ON_SINGLE_PAGE_REASON };
    }
    if (!isGygResellerListPage()) {
      return { enabled: false, reason: fallbackReason };
    }
    const data = window.FareHarborResellerItems.scrapeResellerItems(false);
    const enabled = !!(data && data.length > 0);
    return {
      enabled,
      reason: enabled ? "" : fallbackReason
    };
  }

  function getMappingActionAvailability(buttonKey) {
    const fallbackReason = MAPPING_COMPAT_HINTS[buttonKey] || "Not available on this page.";
    if (buttonKey === "google-zendesk" || buttonKey === "google-sheets") {
      return probeGoogleMappingCopyAvailability();
    }
    if (!areMappingModulesReady()) {
      return { enabled: false, reason: fallbackReason };
    }

    if (buttonKey === "expedia-single" || buttonKey === "expedia-ro") {
      const enabled = probeExpediaSingleItem();
      return { enabled, reason: enabled ? "" : fallbackReason };
    }
    if (buttonKey === "expedia-complete") {
      return probeExpediaCompleteAvailability();
    }
    if (buttonKey === "gyg-single") {
      const enabled = probeGygSingleItem();
      return { enabled, reason: enabled ? "" : fallbackReason };
    }
    if (buttonKey === "gyg-complete") {
      return probeGygCompleteAvailability();
    }
    if (buttonKey === "gyg-explanation") {
      const apiOn = getGygToggleState().includeApiEnrichment;
      if (!apiOn) {
        return {
          enabled: false,
          reason: "Turn on Price and min/max settings to copy the detailed explanation."
        };
      }
      const singleReady = probeGygSingleItem();
      const complete = probeGygCompleteAvailability();
      const enabled = singleReady || complete.enabled;
      return {
        enabled,
        reason: enabled ? "Ready on this page." : complete.reason || MAPPING_COMPAT_HINTS["gyg-single"]
      };
    }
    if (buttonKey === "items-copy") {
      const data = window.FareHarborItems.scrapeFareHarborItems();
      const enabled = !!(data && data.length > 0);
      return { enabled, reason: enabled ? "" : fallbackReason };
    }
    if (buttonKey === "viator-complete") {
      const data = window.ViatorMappingFile.scrapeViatorMappingFile();
      const enabled = !!(data && data.length > 0);
      return { enabled, reason: enabled ? "" : fallbackReason };
    }
    if (buttonKey === "airbnb-complete") {
      const data = window.AirbnbMappingFile.scrapeAirbnbMappingFile();
      const enabled = !!(data && data.length > 0);
      return { enabled, reason: enabled ? "" : fallbackReason };
    }
    return { enabled: false, reason: fallbackReason };
  }

  function evaluateMappingCompatForKeys(keys) {
    const availability = {};
    let anyReady = false;
    keys.forEach((key) => {
      const action = getMappingActionAvailability(key);
      availability[key] = action;
      if (action.enabled) anyReady = true;
    });
    return { availability, anyReady };
  }

  function applyMappingCompatResults(keys, availability) {
    keys.forEach((key) => {
      const action = availability[key];
      if (!action) return;
      setMappingButtonCompat(
        key,
        action.enabled,
        action.enabled ? "Ready on this page." : action.reason
      );
    });
  }

  function mappingCheckSleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function clearMappingCheckingStatusIfCurrent(token) {
    if (token !== copyMappingCheckToken) return;
    const statusEl = document.getElementById("fh-automator-status");
    if (statusEl && statusEl.textContent === "Checking current page…") {
      clearStatus();
    }
  }

  async function refreshCopyMappingPageCheck(options) {
    const retry = !options || options.retry !== false;

    if (!isMappingView()) return;

    const hubCompat = document.getElementById("fh-automator-mapping-hub-compat");
    if (activeView === "mapping") {
      if (hubCompat) {
        hubCompat.textContent =
          "Select an integration to see page-specific copy options and compatibility.";
      }
      return;
    }

    const viewAtStart = activeView;
    const keys = getMappingButtonKeysForView(viewAtStart);
    if (keys.length === 0) return;

    copyMappingCheckToken += 1;
    const token = copyMappingCheckToken;

    keys.forEach((key) => {
      setMappingButtonCompat(key, false, "");
    });

    if (retry) {
      setStatus("Checking current page…", "info");
    }

    const startedAt = Date.now();

    while (true) {
      if (token !== copyMappingCheckToken || !isMappingView() || activeView !== viewAtStart) {
        return;
      }

      if (areMappingModulesReady()) {
        const { availability, anyReady } = evaluateMappingCompatForKeys(keys);
        applyMappingCompatResults(keys, availability);

        if (anyReady) {
          clearMappingCheckingStatusIfCurrent(token);
          return;
        }
      }

      if (!retry || Date.now() - startedAt >= MAPPING_CHECK_TIMEOUT_MS) {
        break;
      }

      await mappingCheckSleep(MAPPING_CHECK_POLL_MS);
    }

    if (token !== copyMappingCheckToken || !isMappingView() || activeView !== viewAtStart) {
      return;
    }

    if (areMappingModulesReady()) {
      const { availability } = evaluateMappingCompatForKeys(keys);
      applyMappingCompatResults(keys, availability);
    } else {
      keys.forEach((key) => {
        setMappingButtonCompat(key, false, "");
      });
    }

    clearMappingCheckingStatusIfCurrent(token);
  }

  function runMappingPageCheck() {
    refreshCopyMappingPageCheck({ retry: true });
  }

  function wireMappingToggle(switchEl, leftLabelEl, rightLabelEl, initialRightActive, onChange) {
    if (!switchEl || !leftLabelEl || !rightLabelEl) return () => false;

    let rightActive = !!initialRightActive;

    function applyState() {
      if (rightActive) {
        switchEl.classList.add("fh-automator-toggle-switch--active");
        leftLabelEl.classList.remove("fh-automator-toggle-label--active");
        rightLabelEl.classList.add("fh-automator-toggle-label--active");
      } else {
        switchEl.classList.remove("fh-automator-toggle-switch--active");
        leftLabelEl.classList.add("fh-automator-toggle-label--active");
        rightLabelEl.classList.remove("fh-automator-toggle-label--active");
      }
    }

    applyState();

    switchEl.addEventListener("click", () => {
      rightActive = !rightActive;
      applyState();
      if (onChange) onChange(rightActive);
    });

    return () => rightActive;
  }

  function applyGygApiEnrichmentState(enabled) {
    gygIncludeApiEnrichment = !!enabled;
    const apiEnrichmentCheckbox = document.getElementById("fh-automator-gyg-api-enrichment");
    if (apiEnrichmentCheckbox) {
      apiEnrichmentCheckbox.checked = gygIncludeApiEnrichment;
    }
  }

  function applyViatorPriceSheetsState(enabled) {
    viatorIncludePriceSheets = !!enabled;
    const checkbox = document.getElementById("fh-automator-viator-price-sheets");
    if (checkbox) {
      checkbox.checked = viatorIncludePriceSheets;
    }
  }

  function getGygToggleState() {
    const nameSwitch = document.getElementById("fh-automator-gyg-name-toggle");
    const formatSwitch = document.getElementById("fh-automator-gyg-format-toggle");
    const headerSwitch = document.getElementById("fh-automator-gyg-header-toggle");
    const apiEnrichmentCheckbox = document.getElementById("fh-automator-gyg-api-enrichment");
    return {
      useChannelName: nameSwitch
        ? nameSwitch.classList.contains("fh-automator-toggle-switch--active")
        : false,
      useTSVFormat: formatSwitch
        ? formatSwitch.classList.contains("fh-automator-toggle-switch--active")
        : false,
      includeHeaderRow: headerSwitch
        ? headerSwitch.classList.contains("fh-automator-toggle-switch--active")
        : false,
      includeApiEnrichment: apiEnrichmentCheckbox
        ? apiEnrichmentCheckbox.checked
        : gygIncludeApiEnrichment
    };
  }

  function getViatorToggleState() {
    const formatSwitch = document.getElementById("fh-automator-viator-format-toggle");
    const priceSheetsCheckbox = document.getElementById("fh-automator-viator-price-sheets");
    return {
      useTSVFormat: formatSwitch
        ? formatSwitch.classList.contains("fh-automator-toggle-switch--active")
        : true,
      includePriceSheets: devModeEnabled && (priceSheetsCheckbox
        ? priceSheetsCheckbox.checked
        : viatorIncludePriceSheets)
    };
  }

  function getAirbnbToggleState() {
    const formatSwitch = document.getElementById("fh-automator-airbnb-format-toggle");
    return {
      useTSVFormat: formatSwitch
        ? formatSwitch.classList.contains("fh-automator-toggle-switch--active")
        : true,
      useDetailed: false
    };
  }

  function handleMappingExtract(buttonKey, btn) {
    const finish = () => {
      if (btn) {
        btn.disabled = false;
        runMappingPageCheck();
      }
    };

    const snapshotBase = {
      completedAt: Date.now(),
      pageUrl: location.href
    };

    if (buttonKey === "expedia-single") {
      if (!window.ExpediaMapping) {
        setStatus("Expedia mapping module not loaded. Reload the page.", "error");
        return;
      }
      if (btn) btn.disabled = true;
      setStatus("Extracting mapping data...", "info");
      dispatchToModule(window.ExpediaMapping, { action: "runExtract" }, (response) => {
        const data = response && response.data;
        if (!data || data.length === 0) {
          setStatus(
            "No single item data found on this page. Make sure you're on an Expedia single item configuration page.",
            "error"
          );
          finish();
          return;
        }
        const formattedText = formatExpediaDataForClipboard(data);
        copyTextToClipboard(
          formattedText,
          () => {
            const msg = "Successfully copied item to clipboard!";
            setStatus(msg, "success");
            setMappingStatusSnapshot({
              ...snapshotBase,
              label: "Expedia — Copy 1 Item",
              message: msg,
              type: "success"
            });
            finish();
          },
          () => {
            setStatus("Failed to copy to clipboard.", "error");
            finish();
          }
        );
      });
      return;
    }

    if (buttonKey === "expedia-ro") {
      if (!window.ExpediaMapping) {
        setStatus("Expedia mapping module not loaded. Reload the page.", "error");
        return;
      }
      if (btn) btn.disabled = true;
      setStatus("Extracting Ro codes...", "info");
      dispatchToModule(window.ExpediaMapping, { action: "runExtractAllRoCodes" }, (response) => {
        if (!response || !response.success) {
          setStatus(
            response?.error ||
              "No Available Times external identifiers found on this page.",
            "error"
          );
          finish();
          return;
        }
        copyTextToClipboard(
          response.text,
          () => {
            const msg = "Successfully copied Ro codes to clipboard!";
            setStatus(msg, "success");
            setMappingStatusSnapshot({
              ...snapshotBase,
              label: "Expedia — Ro codes",
              message: msg,
              type: "success"
            });
            finish();
          },
          () => {
            setStatus("Failed to copy to clipboard.", "error");
            finish();
          }
        );
      });
      return;
    }

    if (buttonKey === "expedia-complete") {
      if (!window.ExpediaMapping) {
        setStatus("Expedia mapping module not loaded. Reload the page.", "error");
        return;
      }
      if (btn) btn.disabled = true;
      setStatus("Extracting complete mapping file...", "info");
      dispatchToModule(window.ExpediaMapping, { action: "runCompleteExtract" }, (response) => {
        if (!response || !response.success) {
          setStatus(
            response?.error ||
              "No reseller items found on this page. Make sure you're on the Expedia reseller items page.",
            "error"
          );
          finish();
          return;
        }
        copyTextToClipboard(
          response.htmlData,
          () => {
            const msg = "Successfully copied mapping file to clipboard!";
            setStatus(msg, "success");
            setMappingStatusSnapshot({
              ...snapshotBase,
              label: "Expedia — Complete Mapping File",
              message: msg,
              type: "success"
            });
            finish();
          },
          (err) => {
            setStatus(
              `Extracted ${response.count} reseller items, but clipboard copy failed.`,
              "error"
            );
            finish();
          }
        );
      });
      return;
    }

    if (buttonKey === "gyg-explanation") {
      if (!window.FareHarborResellerItems) {
        setStatus("GetYourGuide mapping module not loaded. Reload the page.", "error");
        return;
      }
      const { useChannelName, includeHeaderRow, includeApiEnrichment } = getGygToggleState();
      if (!includeApiEnrichment) {
        setStatus("Turn on Price and min/max settings to copy the detailed explanation.", "error");
        return;
      }
      if (btn) btn.disabled = true;
      setStatus("Building enrichment explanation...", "info");
      dispatchToModule(
        window.FareHarborResellerItems,
        {
          action: "runFareHarborResellerItemsExplanationExtract",
          useChannelName,
          includeHeaderRow,
          includeApiEnrichment
        },
        (response) => {
          if (!response || !response.success) {
            setStatus(
              response?.error || "No enrichment explanation available for this page.",
              "error"
            );
            finish();
            return;
          }
          copyTextToClipboard(
            response.explanationText,
            () => {
              const msg = "Successfully copied detailed explanation to clipboard!";
              setStatus(msg, "success");
              setMappingStatusSnapshot({
                ...snapshotBase,
                label: "GetYourGuide — Copy detailed explanation",
                message: msg,
                type: "success"
              });
              finish();
            },
            () => {
              setStatus("Failed to copy explanation to clipboard.", "error");
              finish();
            }
          );
        }
      );
      return;
    }

    if (buttonKey === "gyg-single" || buttonKey === "gyg-complete") {
      if (!window.FareHarborResellerItems) {
        setStatus("GetYourGuide mapping module not loaded. Reload the page.", "error");
        return;
      }
      const { useChannelName, useTSVFormat, includeHeaderRow, includeApiEnrichment } =
        getGygToggleState();
      const action =
        buttonKey === "gyg-single"
          ? "runFareHarborResellerItemsSingleExtract"
          : "runFareHarborResellerItemsExtract";
      const formatName = useTSVFormat ? "TSV" : "HTML";
      if (btn) btn.disabled = true;
      setStatus(
        buttonKey === "gyg-single" ? "Extracting single item data..." : "Extracting reseller items data...",
        "info"
      );
      dispatchToModule(
        window.FareHarborResellerItems,
        { action, useChannelName, useTSVFormat, includeHeaderRow, includeApiEnrichment },
        (response) => {
          if (!response || !response.success) {
            setStatus(
              response?.error ||
                (buttonKey === "gyg-single"
                  ? "No single item data found on this page. Make sure you're on a GetYourGuide single item page."
                  : "No reseller items found on this page. Make sure you're on the FareHarbor reseller items page."),
              "error"
            );
            finish();
            return;
          }
          const dataToCopy = useTSVFormat ? response.tsvData : response.htmlData;
          copyTextToClipboard(
            dataToCopy,
            () => {
              const msg =
                buttonKey === "gyg-single"
                  ? `Successfully copied item to clipboard (${formatName} format)!`
                  : `Successfully copied mapping file to clipboard (${formatName} format)!`;
              setStatus(msg, "success");
              setMappingStatusSnapshot({
                ...snapshotBase,
                label:
                  buttonKey === "gyg-single"
                    ? "GetYourGuide — Copy 1 Item"
                    : "GetYourGuide — Complete Mapping File",
                message: msg,
                type: "success"
              });
              finish();
            },
            () => {
              setStatus("Failed to copy to clipboard.", "error");
              finish();
            }
          );
        }
      );
      return;
    }

    if (buttonKey === "items-copy") {
      if (!window.FareHarborItems) {
        setStatus("FareHarbor Items module not loaded. Reload the page.", "error");
        return;
      }
      if (btn) btn.disabled = true;
      setStatus("Extracting FareHarbor items data...", "info");
      dispatchToModule(window.FareHarborItems, { action: "runFareHarborItemsExtract" }, (response) => {
        if (!response || !response.success) {
          setStatus(
            response?.error ||
              "No FareHarbor items found on this page. Make sure you're on the Items list page and the ID column is visible.",
            "error"
          );
          finish();
          return;
        }
        copyTextToClipboard(
          response.tsvData,
          () => {
            const msg = `Successfully copied ${response.count} items to clipboard! Ready to paste into Google Sheets.`;
            setStatus(msg, "success");
            setMappingStatusSnapshot({
              ...snapshotBase,
              label: "FareHarbor Items",
              message: msg,
              type: "success"
            });
            finish();
          },
          () => {
            setStatus(`Extracted ${response.count} items, but clipboard copy failed.`, "error");
            finish();
          }
        );
      });
      return;
    }

    if (buttonKey === "viator-complete") {
      if (!window.ViatorMappingFile) {
        setStatus("Viator mapping module not loaded. Reload the page.", "error");
        return;
      }
      const { useTSVFormat, includePriceSheets } = getViatorToggleState();
      const formatName = useTSVFormat ? "For sheets" : "For Zendesk";
      if (btn) btn.disabled = true;
      setStatus(
        includePriceSheets ? "Loading Viator mappings…" : "Extracting Viator mapping file data...",
        "info"
      );
      dispatchToModule(
        window.ViatorMappingFile,
        { action: "runViatorMappingFileExtract", useTSVFormat, includePriceSheets },
        (response) => {
          if (!response || !response.success) {
            setStatus(
              response?.error ||
                "No Viator mapping data found on this page. Make sure you're on the Viator reseller items page.",
              "error"
            );
            finish();
            return;
          }
          const dataToCopy = useTSVFormat ? response.tsvData : response.htmlData;
          copyTextToClipboard(
            dataToCopy,
            () => {
              let msg = `Successfully copied mapping file to clipboard (${formatName})!`;
              if (includePriceSheets && response.summaryMessage) {
                msg = response.summaryMessage;
              } else if (includePriceSheets && response.hasPriceSheetWarning) {
                msg =
                  "Copied the Viator mapping file, but no Viator-associated price sheets could be resolved.";
              }
              setStatus(msg, includePriceSheets && response.hasPriceSheetWarning ? "warning" : "success");
              setMappingStatusSnapshot({
                ...snapshotBase,
                label: "Viator — Complete Mapping File",
                message: msg,
                type: includePriceSheets && response.hasPriceSheetWarning ? "warning" : "success"
              });
              finish();
            },
            () => {
              setStatus(`Extracted ${response.count} items, but clipboard copy failed.`, "error");
              finish();
            }
          );
        }
      );
      return;
    }

    if (buttonKey === "airbnb-complete") {
      if (!window.AirbnbMappingFile) {
        setStatus("Airbnb mapping module not loaded. Reload the page.", "error");
        return;
      }
      const { useTSVFormat, useDetailed } = getAirbnbToggleState();
      const formatName = useTSVFormat ? "For sheets" : "For Zendesk";
      if (btn) btn.disabled = true;
      setStatus("Extracting Airbnb mapping file data...", "info");
      dispatchToModule(
        window.AirbnbMappingFile,
        { action: "runAirbnbMappingFileExtract", useTSVFormat, useDetailed },
        (response) => {
          if (!response || !response.success) {
            setStatus(
              response?.error ||
                "No Airbnb mapping data found on this page. Make sure you're on the Airbnb reseller items page.",
              "error"
            );
            finish();
            return;
          }
          const dataToCopy = useTSVFormat ? response.tsvData : response.htmlData;
          copyTextToClipboard(
            dataToCopy,
            () => {
              const msg = `Successfully copied mapping file to clipboard (${formatName})!`;
              setStatus(msg, "success");
              setMappingStatusSnapshot({
                ...snapshotBase,
                label: "Airbnb — Complete Mapping File",
                message: msg,
                type: "success"
              });
              finish();
            },
            () => {
              setStatus(`Extracted ${response.count} items, but clipboard copy failed.`, "error");
              finish();
            }
          );
        }
      );
      return;
    }

    if (buttonKey === "google-zendesk" || buttonKey === "google-sheets") {
      if (!window.GoogleMappingData?.runGoogleMappingCopy) {
        setStatus("Google mapping module not loaded. Reload the page.", "error");
        return;
      }
      const outputFormat = buttonKey === "google-sheets" ? "sheets" : "zendesk";
      const formatLabel = outputFormat === "sheets" ? "Sheets" : "Zendesk";
      if (btn) btn.disabled = true;
      setStatus(`Copying Google mapping data for ${formatLabel}...`, "info");
      window.GoogleMappingData.runGoogleMappingCopy(outputFormat)
        .then((response) => {
          if (!response || !response.success) {
            setStatus(response?.error || "No Google mappings found.", "error");
            finish();
            return;
          }
          copyTextToClipboard(
            response.outputText,
            () => {
              const msg = `Successfully copied ${response.count} Google mapping${response.count === 1 ? "" : "s"} to clipboard (${formatLabel})!`;
              setStatus(msg, "success");
              setMappingStatusSnapshot({
                ...snapshotBase,
                label: `Google — ${formatLabel}`,
                message: msg,
                type: "success"
              });
              finish();
            },
            () => {
              setStatus(
                `Extracted ${response.count} Google mappings, but clipboard copy failed.`,
                "error"
              );
              finish();
            }
          );
        })
        .catch((err) => {
          console.error("[overlay] Google mapping copy failed", err);
          setStatus(err?.message || "Google mapping copy failed.", "error");
          finish();
        });
    }
  }

  function wireMappingSection(root) {
    const refreshBtn = root.querySelector("#fh-automator-refresh-mapping-compat");
    if (refreshBtn) {
      refreshBtn.addEventListener("click", () => refreshCopyMappingPageCheck({ retry: true }));
    }

    const clearBtn = root.querySelector("#fh-automator-clear-mapping-status");
    if (clearBtn) {
      clearBtn.addEventListener("click", () => clearMappingStatusSnapshot());
    }

    root.querySelectorAll("[data-mapping-button]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const key = btn.getAttribute("data-mapping-button");
        if (!key) return;
        if (btn.disabled) {
          const compatEl = document.querySelector(`[data-mapping-compat="${key}"]`);
          setStatus(
            compatEl?.textContent ||
              MAPPING_COMPAT_HINTS[key] ||
              "This action is not available on the current page.",
            "error"
          );
          return;
        }
        handleMappingExtract(key, btn);
      });
    });

    wireMappingToggle(
      root.querySelector("#fh-automator-gyg-name-toggle"),
      root.querySelector("#fh-automator-gyg-name-left"),
      root.querySelector("#fh-automator-gyg-name-right"),
      false
    );
    wireMappingToggle(
      root.querySelector("#fh-automator-gyg-format-toggle"),
      root.querySelector("#fh-automator-gyg-format-left"),
      root.querySelector("#fh-automator-gyg-format-right"),
      false
    );
    wireMappingToggle(
      root.querySelector("#fh-automator-gyg-header-toggle"),
      root.querySelector("#fh-automator-gyg-header-left"),
      root.querySelector("#fh-automator-gyg-header-right"),
      false
    );

    const gygApiEnrichmentCheckbox = root.querySelector("#fh-automator-gyg-api-enrichment");
    if (gygApiEnrichmentCheckbox) {
      chrome.storage.local.get({ [GYG_MAPPING_API_ENRICHMENT_STORAGE_KEY]: false }, (result) => {
        applyGygApiEnrichmentState(!!result[GYG_MAPPING_API_ENRICHMENT_STORAGE_KEY]);
      });
      gygApiEnrichmentCheckbox.addEventListener("change", () => {
        applyGygApiEnrichmentState(gygApiEnrichmentCheckbox.checked);
        chrome.storage.local.set({
          [GYG_MAPPING_API_ENRICHMENT_STORAGE_KEY]: gygIncludeApiEnrichment
        });
        if (activeView === "mapping-gyg") {
          refreshCopyMappingPageCheck({ retry: false });
        }
      });
    }

    wireMappingToggle(
      root.querySelector("#fh-automator-viator-format-toggle"),
      root.querySelector("#fh-automator-viator-format-left"),
      root.querySelector("#fh-automator-viator-format-right"),
      true
    );

    const viatorPriceSheetsCheckbox = root.querySelector("#fh-automator-viator-price-sheets");
    if (viatorPriceSheetsCheckbox) {
      chrome.storage.local.get({ [VIATOR_MAPPING_INCLUDE_PRICE_SHEETS_STORAGE_KEY]: false }, (result) => {
        applyViatorPriceSheetsState(!!result[VIATOR_MAPPING_INCLUDE_PRICE_SHEETS_STORAGE_KEY]);
      });
      viatorPriceSheetsCheckbox.addEventListener("change", () => {
        applyViatorPriceSheetsState(viatorPriceSheetsCheckbox.checked);
        chrome.storage.local.set({
          [VIATOR_MAPPING_INCLUDE_PRICE_SHEETS_STORAGE_KEY]: viatorIncludePriceSheets
        });
      });
    }

    wireMappingToggle(
      root.querySelector("#fh-automator-airbnb-format-toggle"),
      root.querySelector("#fh-automator-airbnb-format-left"),
      root.querySelector("#fh-automator-airbnb-format-right"),
      true
    );

    document.addEventListener("visibilitychange", () => {
      if (
        document.visibilityState === "visible" &&
        isOverlayVisible() &&
        isMappingView()
      ) {
        refreshCopyMappingPageCheck({ retry: true });
      }
    });
  }

  function wireOverlayNavigation(root) {
    root.querySelectorAll("[data-nav]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const view = btn.getAttribute("data-nav");
        if (isKnownView(view)) {
          showView(view);
        }
      });
    });
  }

  function refreshGygApiEnrichmentOverlayUI() {
    // GYG price/min-max enrichment is user-facing; no dev-mode gating.
  }

  function refreshViatorPriceSheetsOverlayUI(root) {
    const overlayRoot = root || getOverlayEl();
    if (!overlayRoot) return;
    const group = overlayRoot.querySelector("#fh-automator-viator-price-sheets-group");
    if (group) {
      group.classList.toggle("fh-automator-view--hidden", !devModeEnabled);
    }
  }

  function refreshEndpointScoutOverlayUI(root) {
    const overlayRoot = root || getOverlayEl();
    if (!overlayRoot) return;
    const enabled = Boolean(window.EndpointScout?.isEnabled?.());
    const showDev = enabled && devModeEnabled;
    const badge = overlayRoot.querySelector("#fh-automator-dev-badge");
    const btn = overlayRoot.querySelector("#fh-automator-copy-endpoint-report");
    const apiBtn = overlayRoot.querySelector("#fh-automator-debug-api-capacity");
    const inspectBtn = overlayRoot.querySelector("#fh-automator-inspect-api-resource-sources");
    const apiHint = overlayRoot.querySelector("#fh-automator-api-capacity-hint");
    const apiEngineRow = overlayRoot.querySelector("#fh-automator-capacity-engine-row");
    const apiSummary = overlayRoot.querySelector("#fh-automator-api-capacity-summary");
    if (badge) {
      badge.classList.toggle("fh-automator-view--hidden", !showDev);
    }
    if (btn) {
      btn.classList.toggle("fh-automator-view--hidden", !showDev);
    }
    if (apiBtn) {
      apiBtn.classList.toggle("fh-automator-view--hidden", !showDev);
    }
    if (inspectBtn) {
      inspectBtn.classList.toggle("fh-automator-view--hidden", !showDev);
    }
    if (apiHint) {
      apiHint.classList.toggle("fh-automator-view--hidden", !showDev);
    }
    if (apiEngineRow) {
      apiEngineRow.classList.toggle("fh-automator-view--hidden", !showDev);
    }
    if (apiSummary) {
      apiSummary.classList.toggle("fh-automator-view--hidden", !showDev);
    }
  }

  function loadDevModeFromStorage(callback) {
    FareHarborDeveloperAuth.syncDevModeState().then((active) => {
      devModeEnabled = active;
      if (typeof callback === "function") callback();
    });
  }

  function resolveOverlayCapacityTargetTimestamp() {
    const separateFields = document.getElementById("fh-automator-separate-fields")?.checked;
    let validatedDate;
    let validatedTime;

    if (separateFields) {
      const targetDate = document.getElementById("fh-automator-audit-date")?.value.trim() || "";
      const targetTime = document.getElementById("fh-automator-audit-time")?.value.trim() || "";
      if (!targetDate) return { ok: false, error: "Please enter a target date." };
      if (!targetTime) return { ok: false, error: "Please enter a target time." };

      const dateValidation = validateDateFormat(targetDate);
      if (!dateValidation.valid) {
        return { ok: false, error: `Invalid date: ${dateValidation.error}` };
      }

      const timeValidation = validateTimeFormat(targetTime);
      if (!timeValidation.valid) {
        return { ok: false, error: `Invalid time: ${timeValidation.error}` };
      }

      validatedDate = dateValidation.date;
      validatedTime = timeValidation.time;
    } else {
      const isoValue = document.getElementById("fh-automator-iso-datetime")?.value.trim() || "";
      if (!isoValue) return { ok: false, error: "Please enter a target date and time." };

      const isoValidation = validateISODateTimeFormat(isoValue);
      if (!isoValidation.valid) {
        return { ok: false, error: `Invalid date/time: ${isoValidation.error}` };
      }

      validatedDate = isoValidation.date;
      validatedTime = isoValidation.time;
    }

    const targetDateTime = new Date(`${validatedDate}T${validatedTime}:00`);
    if (Number.isNaN(targetDateTime.getTime())) {
      return { ok: false, error: `Invalid target date/time: ${validatedDate} ${validatedTime}` };
    }

    return {
      ok: true,
      targetTimestamp: targetDateTime.toISOString(),
      targetDate: validatedDate,
      targetTime: validatedTime
    };
  }

  function formatCustomerTypesUsedSummary(customerTypesUsed) {
    const entries = Object.entries(customerTypesUsed || {});
    if (entries.length === 0) return "n/a";
    return entries.map(([name, count]) => `${name}: ${count}`).join(", ");
  }

  function formatResourcesUsedAtTimestampSummary(resourcesUsedAtTimestamp) {
    const entries = Object.values(resourcesUsedAtTimestamp || {});
    if (entries.length === 0) return "n/a";
    return entries
      .map((resource) => {
        const labelParts = [];
        if (resource.unicode) labelParts.push(resource.unicode);
        labelParts.push(resource.resourceName);
        if (resource.resourceId != null && resource.resourceId !== "") {
          labelParts.push(`id:${resource.resourceId}`);
        }
        return `${labelParts.join(" ")} × ${resource.quantity}`;
      })
      .join("\n  ");
  }

  function formatResourcesUsedFlatSummary(resourcesUsed) {
    if (!resourcesUsed || typeof resourcesUsed !== "object") return "n/a";
    const entries = Object.entries(resourcesUsed);
    if (entries.length === 0) return "n/a";
    return entries.map(([name, count]) => `${name}: ${count}`).join(", ");
  }

  function buildMetricsSummaryLines(metrics, title) {
    if (!metrics) return [`${title}: (no data)`];
    return [
      title,
      `Total scanned: ${metrics.totalBookingsScanned}`,
      `Active at timestamp: ${metrics.activeAtTimestamp}`,
      `Skipped: ${metrics.skippedBookingsCount}`,
      `Capacity used: ${metrics.totalCapacityUsed}`,
      `Customer types: ${formatCustomerTypesUsedSummary(metrics.customerTypesUsed)}`,
      `Resources: ${formatResourcesUsedFlatSummary(metrics.resourcesUsed)}`
    ];
  }

  function formatResourcesUsedByCustomerTypeSummary(resourcesUsedByCustomerType) {
    const resources = Object.entries(resourcesUsedByCustomerType || {});
    if (resources.length === 0) return "n/a";

    return resources
      .map(([resourceName, breakdown]) => {
        const total = breakdown._total ?? 0;
        const typeLines = Object.entries(breakdown)
          .filter(([key]) => key !== "_total")
          .map(([typeName, count]) => `  ${typeName}: ${count}`)
          .join("\n");
        return `${resourceName} (${total}):\n${typeLines}`;
      })
      .join("\n");
  }

  function buildApiFetchSummaryLines(apiResult) {
    if (!apiResult?.ok) return [];
    const lines = [];
    const bookings = apiResult.bookings || [];
    const availabilityId = apiResult.context?.availabilityId || "n/a";
    lines.push(
      `Availability ID: ${availabilityId}`,
      `Bookings fetched: ${bookings.length}`
    );
    const snapshot = apiResult.snapshot;
    if (snapshot?.ok) {
      lines.push(
        "",
        `Target timestamp: ${snapshot.targetTimestamp}`,
        `Total bookings scanned: ${snapshot.totalBookingsScanned}`,
        `Active at timestamp: ${snapshot.activeAtTimestampCount}`,
        `Skipped: ${snapshot.skippedCount}`,
        `Total capacity used: ${snapshot.totalCapacityUsed}`,
        `Customer types used: ${formatCustomerTypesUsedSummary(snapshot.customerTypesUsed)}`,
        `Total resource reapply events before target: ${snapshot.totalReapplyEventsBeforeTarget ?? 0}`,
        `Total resource reapply events after target: ${snapshot.totalReapplyEventsAfterTarget ?? 0}`,
        "Resources used at timestamp:",
        `  ${formatResourcesUsedAtTimestampSummary(snapshot.resourcesUsedAtTimestamp)}`,
        "Resources by customer type:",
        `  ${formatResourcesUsedByCustomerTypeSummary(snapshot.resourcesUsedByCustomerType)}`
      );
    }
    return lines;
  }

  function buildDevCapacityCheckSummaryText(result) {
    if (!result || result.ok === false) {
      return `Error: ${result?.error || "Dev capacity check failed"}`;
    }

    const engine = result.engine || "api";

    if (engine === "dom") {
      return buildMetricsSummaryLines(result.metrics, "DOM current").join("\n");
    }

    if (engine === "api") {
      const lines = ["API experimental"];
      lines.push(...buildApiFetchSummaryLines(result.apiResult));
      if (result.metrics) {
        lines.push("", "--- Normalized metrics ---");
        lines.push(...buildMetricsSummaryLines(result.metrics, "Snapshot").slice(1));
      }
      return lines.join("\n");
    }

    if (engine === "both") {
      const lines = [];
      lines.push(...buildMetricsSummaryLines(result.domMetrics, "DOM current"));
      lines.push("");
      lines.push(...buildMetricsSummaryLines(result.apiMetrics, "API experimental"));

      if (result.comparison?.resourcesCompareSkipped) {
        lines.push("", "Note: Resources comparison skipped (enable detailed DOM check for resource data).");
      }

      if (result.comparison?.allMatch) {
        lines.push("", "All compared metrics match.");
      } else if (result.comparison?.mismatches?.length) {
        lines.push("", "Mismatch warnings:");
        for (const m of result.comparison.mismatches) {
          if (m.field === "_error") continue;
          lines.push(`- ${m.field}: DOM=${JSON.stringify(m.dom)}, API=${JSON.stringify(m.api)}`);
        }
      }

      return lines.join("\n");
    }

    return "Error: Unknown engine result";
  }

  function showApiCapacityDevSummary(overlay, message, isError, hasWarnings, isInspect) {
    const el = overlay.querySelector("#fh-automator-api-capacity-summary");
    if (!el) return;
    el.textContent = message;
    el.classList.remove("fh-automator-view--hidden");
    el.classList.toggle("fh-automator-api-capacity-summary--error", Boolean(isError));
    el.classList.toggle("fh-automator-api-capacity-summary--warn", Boolean(hasWarnings) && !isError);
    el.classList.toggle("fh-automator-api-capacity-summary--inspect", Boolean(isInspect) && !isError);
  }

  function wireApiCapacityDevSection(overlay) {
    const btn = overlay.querySelector("#fh-automator-debug-api-capacity");
    if (!btn) return;

    btn.addEventListener("click", async () => {
      if (!(await FareHarborDeveloperAuth.isDevModeActiveAsync())) {
        FareHarborDeveloperAuth.logUnavailable('overlay dev capacity check blocked: DEV mode is not available');
        setStatus("Dev tools not available.", "error");
        return;
      }
      if (!window.EndpointScout?.isEnabled?.()) {
        setStatus("Dev tools not available.", "error");
        return;
      }
      if (!window.AvailabilityAudit?.runDevCapacityCheckEngine) {
        setStatus("Dev capacity engine not loaded.", "error");
        return;
      }

      const timestampResult = resolveOverlayCapacityTargetTimestamp();
      if (!timestampResult.ok) {
        showApiCapacityDevSummary(overlay, timestampResult.error, true);
        setStatus(timestampResult.error, "error");
        return;
      }

      const engine =
        overlay.querySelector("#fh-automator-capacity-engine")?.value || "api";
      const fetchDetailedInfo =
        document.getElementById("fh-automator-fetch-detailed")?.checked === true;

      btn.disabled = true;
      const statusMsg =
        engine === "both"
          ? "Running DOM and API capacity checks…"
          : engine === "dom"
            ? "Running DOM capacity check…"
            : "Running API capacity check…";
      showApiCapacityDevSummary(overlay, statusMsg, false);
      setStatus(statusMsg, "info");

      try {
        const result = await window.AvailabilityAudit.runDevCapacityCheckEngine({
          engine,
          targetDate: timestampResult.targetDate,
          targetTime: timestampResult.targetTime,
          targetTimestamp: timestampResult.targetTimestamp,
          fetchDetailedInfo
        });
        console.log("[overlay] Dev capacity check full result:", result);
        if (result?.comparison) {
          console.log("[overlay] Dev capacity check comparison:", result.comparison);
        }

        const hasWarnings =
          engine === "both" && result?.comparison && !result.comparison.allMatch;
        showApiCapacityDevSummary(
          overlay,
          buildDevCapacityCheckSummaryText(result),
          result?.ok === false,
          hasWarnings
        );
        if (result?.ok !== false) {
          setStatus("Dev capacity check complete — see summary below.", "ok");
        } else {
          setStatus(result?.error || "Dev capacity check failed.", "error");
        }
      } catch (err) {
        console.error("[overlay] Dev capacity check failed", err);
        const message = err?.message || "Unexpected error";
        showApiCapacityDevSummary(overlay, `Error: ${message}`, true);
        setStatus(message, "error");
      } finally {
        btn.disabled = false;
      }
    });

    const inspectBtn = overlay.querySelector("#fh-automator-inspect-api-resource-sources");
    if (!inspectBtn) return;

    inspectBtn.addEventListener("click", async () => {
      if (!(await FareHarborDeveloperAuth.isDevModeActiveAsync())) {
        FareHarborDeveloperAuth.logUnavailable('overlay API resource inspection blocked: DEV mode is not available');
        setStatus("Dev tools not available.", "error");
        return;
      }
      if (!window.EndpointScout?.isEnabled?.()) {
        setStatus("Dev tools not available.", "error");
        return;
      }
      if (!window.AvailabilityAudit?.inspectApiResourceSources) {
        setStatus("API resource inspect module not loaded.", "error");
        return;
      }

      const timestampResult = resolveOverlayCapacityTargetTimestamp();
      if (!timestampResult.ok) {
        showApiCapacityDevSummary(overlay, timestampResult.error, true);
        setStatus(timestampResult.error, "error");
        return;
      }

      inspectBtn.disabled = true;
      showApiCapacityDevSummary(
        overlay,
        "Inspecting API resource sources… (see console for raw payloads)",
        false,
        false,
        true
      );
      setStatus("Inspecting API resource sources…", "info");

      try {
        const result = await window.AvailabilityAudit.inspectApiResourceSources({
          targetTimestamp: timestampResult.targetTimestamp
        });
        console.log("[overlay] Inspect API resource sources full result:", result);

        if (result?.ok === false) {
          showApiCapacityDevSummary(overlay, result?.error || "Inspection failed", true);
          setStatus(result?.error || "Inspection failed.", "error");
          return;
        }

        showApiCapacityDevSummary(
          overlay,
          result?.summaryText || "Inspection complete — see console for raw payloads.",
          false,
          false,
          true
        );
        setStatus("API resource source inspection complete — see summary below.", "ok");
      } catch (err) {
        console.error("[overlay] Inspect API resource sources failed", err);
        const message = err?.message || "Unexpected error";
        showApiCapacityDevSummary(overlay, `Error: ${message}`, true);
        setStatus(message, "error");
      } finally {
        inspectBtn.disabled = false;
      }
    });
  }

  function wireEndpointScoutSection(overlay) {
    const btn = overlay.querySelector("#fh-automator-copy-endpoint-report");
    if (btn) {
      btn.addEventListener("click", async () => {
        if (!(await FareHarborDeveloperAuth.isDevModeActiveAsync())) {
          FareHarborDeveloperAuth.logUnavailable('overlay endpoint report copy blocked: DEV mode is not available');
          setStatus("Dev tools not available.", "error");
          return;
        }
        if (!window.EndpointScout?.isEnabled?.()) {
          setStatus("Endpoint Scout not available.", "error");
          return;
        }
        try {
          const report = await window.EndpointScout.getReport();
          await navigator.clipboard.writeText(report);
          setStatus("Endpoint report copied to clipboard.", "ok");
        } catch (err) {
          setStatus(
            err && err.message ? err.message : "Failed to copy endpoint report.",
            "error"
          );
        }
      });
    }
    document.addEventListener("endpoint-scout-enabled", () => {
      refreshEndpointScoutOverlayUI(overlay);
    });
    refreshEndpointScoutOverlayUI(overlay);
    refreshGygApiEnrichmentOverlayUI(overlay);
    refreshViatorPriceSheetsOverlayUI(overlay);
  }

  function createOverlay() {
    if (getOverlayEl()) return getOverlayEl();
    if (!isFareHarborHost()) return null;

    injectStyles();

    const overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;
    overlay.className = "fh-automator-overlay fh-automator-overlay--hidden";
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-label", "FareHarbor Automator");

    overlay.innerHTML = `
      <div class="fh-automator-header">
        <div class="fh-automator-header-text">
          <span class="fh-automator-title">FareHarbor Automator</span>
          <span class="fh-automator-subtitle">Automation tools<span id="fh-automator-dev-badge" class="fh-automator-dev-badge fh-automator-view--hidden">DEV MODE</span></span>
        </div>
        <div class="fh-automator-header-actions">
          <button type="button" id="fh-automator-reset-position" class="fh-automator-reset-position" title="Reset position">Reset</button>
          <button type="button" class="fh-automator-close" aria-label="Close overlay">&times;</button>
        </div>
      </div>
      <div class="fh-automator-body">
        <div id="fh-automator-view-home" class="fh-automator-view">
          <div class="fh-automator-action-list">
            <button type="button" class="fh-automator-action" data-nav="duplicate" data-home-action="duplicate">
              <span class="fh-automator-action-label">Duplicate Customer Types</span>
              <span class="fh-automator-action-status" data-home-status="duplicate" aria-live="polite"></span>
            </button>
            <button type="button" class="fh-automator-action" data-nav="mapping" data-home-action="mapping">
              <span class="fh-automator-action-label">Copy Mapping Data</span>
              <span class="fh-automator-action-status" data-home-status="mapping" aria-live="polite"></span>
            </button>
            <button type="button" class="fh-automator-action" data-nav="capacity" data-home-action="capacity">
              <span class="fh-automator-action-label">Capacity Check</span>
              <span class="fh-automator-action-status" data-home-status="capacity" aria-live="polite"></span>
            </button>
            <button type="button" class="fh-automator-action" data-nav="qc" data-home-action="qc">
              <span class="fh-automator-action-label">QC Check</span>
              <span class="fh-automator-action-status" data-home-status="qc" aria-live="polite"></span>
            </button>
            <button type="button" id="fh-automator-copy-endpoint-report" class="fh-automator-endpoint-scout fh-automator-view--hidden">
              Copy Endpoint Report
            </button>
          </div>
        </div>
        <div id="fh-automator-mapping-toolbar" class="fh-automator-mapping-toolbar fh-automator-view--hidden" aria-label="Copy mapping toolbar">
          <div class="fh-automator-mapping-toolbar-header">
            <p class="fh-automator-mapping-toolbar-title">Copy Mapping Data</p>
            <div class="fh-automator-mapping-toolbar-actions">
              <button type="button" id="fh-automator-refresh-mapping-compat" class="fh-automator-refresh">Refresh page check</button>
              <button type="button" id="fh-automator-clear-mapping-status" class="fh-automator-mapping-clear-status">Clear status</button>
            </div>
          </div>
          <p id="fh-automator-mapping-status-snapshot" class="fh-automator-mapping-status-snapshot fh-automator-mapping-status-snapshot--empty" aria-live="polite"></p>
        </div>
        <div id="fh-automator-view-mapping" class="fh-automator-view fh-automator-view--hidden">
          <button type="button" class="fh-automator-back" data-nav="home">&larr; Back</button>
          <section class="fh-automator-mapping-panel" aria-label="FareHarbor Dashboard">
            <h3 class="fh-automator-mapping-title">FareHarbor Dashboard</h3>
            <p class="fh-automator-mapping-subtitle">Copy data from the FareHarbor dashboard</p>
            <p id="fh-automator-mapping-hub-compat" class="fh-automator-mapping-hub-compat">Select an integration to see page-specific copy options and compatibility.</p>
            <button type="button" class="fh-automator-mapping-menu-option" data-nav="mapping-expedia">
              <div class="fh-automator-mapping-menu-option-title">Expedia Mapping File</div>
              <div class="fh-automator-mapping-menu-option-desc">Extract and copy mapping codes for Expedia</div>
            </button>
            <button type="button" class="fh-automator-mapping-menu-option" data-nav="mapping-gyg">
              <div class="fh-automator-mapping-menu-option-title">GetYourGuide Mapping File</div>
              <div class="fh-automator-mapping-menu-option-desc">Extract and copy mapping for GetYourGuide</div>
            </button>
            <button type="button" class="fh-automator-mapping-menu-option" data-nav="mapping-items">
              <div class="fh-automator-mapping-menu-option-title">FareHarbor Items</div>
              <div class="fh-automator-mapping-menu-option-desc">Copy FareHarbor Item IDs and Names</div>
            </button>
            <button type="button" class="fh-automator-mapping-menu-option" data-nav="mapping-viator">
              <div class="fh-automator-mapping-menu-option-title">Viator Mapping File</div>
              <div class="fh-automator-mapping-menu-option-desc">Extract and copy mapping for Viator</div>
            </button>
            <button type="button" class="fh-automator-mapping-menu-option" data-nav="mapping-airbnb">
              <div class="fh-automator-mapping-menu-option-title">Airbnb Mapping File</div>
              <div class="fh-automator-mapping-menu-option-desc">Extract and copy mapping for Airbnb</div>
            </button>
            <button type="button" class="fh-automator-mapping-menu-option" data-nav="mapping-google">
              <div class="fh-automator-mapping-menu-option-title">Google Mapping Data</div>
              <div class="fh-automator-mapping-menu-option-desc">Copy Google mappings for Zendesk or Sheets</div>
            </button>
          </section>
        </div>
        <div id="fh-automator-view-mapping-expedia" class="fh-automator-view fh-automator-view--hidden">
          <button type="button" class="fh-automator-back" data-nav="mapping">&larr; Back</button>
          <section class="fh-automator-mapping-panel" aria-label="Expedia Mapping File">
            <h3 class="fh-automator-mapping-title">Expedia Mapping File</h3>
            <p class="fh-automator-mapping-hint">This will extract the mapping data from the current page and copy it to your clipboard.</p>
            <button type="button" class="fh-automator-mapping-run" data-mapping-button="expedia-single">Copy 1 Item</button>
            <p class="fh-automator-mapping-button-compat" data-mapping-compat="expedia-single"></p>
            <button type="button" class="fh-automator-mapping-run" data-mapping-button="expedia-ro">Copy all Ro codes (CSV ready)</button>
            <p class="fh-automator-mapping-button-compat" data-mapping-compat="expedia-ro"></p>
            <button type="button" class="fh-automator-mapping-run" data-mapping-button="expedia-complete">Copy Complete Mapping File</button>
            <p class="fh-automator-mapping-button-compat" data-mapping-compat="expedia-complete"></p>
          </section>
        </div>
        <div id="fh-automator-view-mapping-gyg" class="fh-automator-view fh-automator-view--hidden">
          <button type="button" class="fh-automator-back" data-nav="mapping">&larr; Back</button>
          <section class="fh-automator-mapping-panel" aria-label="GetYourGuide Mapping File">
            <h3 class="fh-automator-mapping-title">GetYourGuide Mapping File</h3>
            <p class="fh-automator-mapping-hint">Extract and copy mapping for GetYourGuide from current page (paste in macro directly!)</p>
            <div id="fh-automator-gyg-api-enrichment-group" class="fh-automator-gyg-api-enrichment-group">
              <label id="fh-automator-gyg-api-enrichment-row" class="fh-automator-checkbox-row" for="fh-automator-gyg-api-enrichment">
                <input type="checkbox" id="fh-automator-gyg-api-enrichment" />
                <span>Include Price and min/max settings (slower)</span>
              </label>
              <p class="fh-automator-gyg-api-enrichment-beta">⚠️ Beta: For complex setups (for example, multiple price sheets, price schedules, or advanced capacity rules), please double-check that the copied prices and booking limits are correct.</p>
            </div>
            <button type="button" class="fh-automator-mapping-run" data-mapping-button="gyg-single">Copy 1 Item</button>
            <p class="fh-automator-mapping-button-compat" data-mapping-compat="gyg-single"></p>
            <button type="button" class="fh-automator-mapping-run" data-mapping-button="gyg-complete">Copy Complete Mapping File</button>
            <p class="fh-automator-mapping-button-compat" data-mapping-compat="gyg-complete"></p>
            <button type="button" class="fh-automator-mapping-run" data-mapping-button="gyg-explanation">Copy detailed explanation</button>
            <p class="fh-automator-mapping-button-compat" data-mapping-compat="gyg-explanation"></p>
            <div class="fh-automator-mapping-toggles">
              <div class="fh-automator-toggle-row">
                <span id="fh-automator-gyg-name-left" class="fh-automator-toggle-label fh-automator-toggle-label--active">Item name</span>
                <div id="fh-automator-gyg-name-toggle" class="fh-automator-toggle-switch" role="switch" aria-checked="false" tabindex="0">
                  <div class="fh-automator-toggle-slider"></div>
                </div>
                <span id="fh-automator-gyg-name-right" class="fh-automator-toggle-label">Channel name</span>
              </div>
              <div class="fh-automator-toggle-row">
                <span id="fh-automator-gyg-format-left" class="fh-automator-toggle-label fh-automator-toggle-label--active">For Zendesk</span>
                <div id="fh-automator-gyg-format-toggle" class="fh-automator-toggle-switch" role="switch" aria-checked="false" tabindex="0">
                  <div class="fh-automator-toggle-slider"></div>
                </div>
                <span id="fh-automator-gyg-format-right" class="fh-automator-toggle-label">For sheets</span>
              </div>
              <div class="fh-automator-toggle-row">
                <span id="fh-automator-gyg-header-left" class="fh-automator-toggle-label fh-automator-toggle-label--active">No header row</span>
                <div id="fh-automator-gyg-header-toggle" class="fh-automator-toggle-switch" role="switch" aria-checked="false" tabindex="0">
                  <div class="fh-automator-toggle-slider"></div>
                </div>
                <span id="fh-automator-gyg-header-right" class="fh-automator-toggle-label">Include header row</span>
              </div>
            </div>
          </section>
        </div>
        <div id="fh-automator-view-mapping-items" class="fh-automator-view fh-automator-view--hidden">
          <button type="button" class="fh-automator-back" data-nav="mapping">&larr; Back</button>
          <section class="fh-automator-mapping-panel" aria-label="FareHarbor Items">
            <h3 class="fh-automator-mapping-title">FareHarbor Items</h3>
            <p class="fh-automator-mapping-hint">Copy Item IDs and Names from the Items list page. Make sure the ID column is visible.</p>
            <button type="button" class="fh-automator-mapping-run" data-mapping-button="items-copy">Copy Items Data</button>
            <p class="fh-automator-mapping-button-compat" data-mapping-compat="items-copy"></p>
          </section>
        </div>
        <div id="fh-automator-view-mapping-viator" class="fh-automator-view fh-automator-view--hidden">
          <button type="button" class="fh-automator-back" data-nav="mapping">&larr; Back</button>
          <section class="fh-automator-mapping-panel" aria-label="Viator Mapping File">
            <h3 class="fh-automator-mapping-title">Viator Mapping File</h3>
            <p class="fh-automator-mapping-hint">Extract and copy mapping for Viator from current page (paste in macro directly!)</p>
            <button type="button" class="fh-automator-mapping-run" data-mapping-button="viator-complete">Copy Complete Mapping File</button>
            <p class="fh-automator-mapping-button-compat" data-mapping-compat="viator-complete"></p>
            <div id="fh-automator-viator-price-sheets-group" class="fh-automator-view--hidden">
              <label class="fh-automator-checkbox-row" for="fh-automator-viator-price-sheets">
                <input type="checkbox" id="fh-automator-viator-price-sheets" />
                <span>Include customer type prices</span>
              </label>
              <p class="fh-automator-mapping-hint">Add mapped customer types and one column per Viator price sheet.</p>
            </div>
            <div class="fh-automator-mapping-toggles">
              <div class="fh-automator-toggle-row">
                <span id="fh-automator-viator-format-left" class="fh-automator-toggle-label">For Zendesk</span>
                <div id="fh-automator-viator-format-toggle" class="fh-automator-toggle-switch fh-automator-toggle-switch--active" role="switch" aria-checked="true" tabindex="0">
                  <div class="fh-automator-toggle-slider"></div>
                </div>
                <span id="fh-automator-viator-format-right" class="fh-automator-toggle-label fh-automator-toggle-label--active">For sheets</span>
              </div>
            </div>
          </section>
        </div>
        <div id="fh-automator-view-mapping-airbnb" class="fh-automator-view fh-automator-view--hidden">
          <button type="button" class="fh-automator-back" data-nav="mapping">&larr; Back</button>
          <section class="fh-automator-mapping-panel" aria-label="Airbnb Mapping File">
            <h3 class="fh-automator-mapping-title">Airbnb Mapping File</h3>
            <p class="fh-automator-mapping-hint">Extract and copy mapping for Airbnb from current page (paste in macro directly!)</p>
            <button type="button" class="fh-automator-mapping-run" data-mapping-button="airbnb-complete">Copy Complete Mapping File</button>
            <p class="fh-automator-mapping-button-compat" data-mapping-compat="airbnb-complete"></p>
            <div class="fh-automator-mapping-toggles">
              <div class="fh-automator-toggle-row">
                <span id="fh-automator-airbnb-format-left" class="fh-automator-toggle-label">For Zendesk</span>
                <div id="fh-automator-airbnb-format-toggle" class="fh-automator-toggle-switch fh-automator-toggle-switch--active" role="switch" aria-checked="true" tabindex="0">
                  <div class="fh-automator-toggle-slider"></div>
                </div>
                <span id="fh-automator-airbnb-format-right" class="fh-automator-toggle-label fh-automator-toggle-label--active">For sheets</span>
              </div>
            </div>
          </section>
        </div>
        <div id="fh-automator-view-mapping-google" class="fh-automator-view fh-automator-view--hidden">
          <button type="button" class="fh-automator-back" data-nav="mapping">&larr; Back</button>
          <section class="fh-automator-mapping-panel" aria-label="Google Mapping Data">
            <h3 class="fh-automator-mapping-title">Google Mapping Data</h3>
            <p class="fh-automator-mapping-hint">Copy Google mappings from the FareHarbor dashboard using API data. Open any FareHarbor dashboard page for the company first.</p>
            <button type="button" class="fh-automator-mapping-run" data-mapping-button="google-zendesk">Copy Google Mapping for Zendesk</button>
            <p class="fh-automator-mapping-button-compat" data-mapping-compat="google-zendesk"></p>
            <button type="button" class="fh-automator-mapping-run" data-mapping-button="google-sheets">Copy Google Mapping for Sheets</button>
            <p class="fh-automator-mapping-button-compat" data-mapping-compat="google-sheets"></p>
          </section>
        </div>
        <div id="fh-automator-view-capacity" class="fh-automator-view fh-automator-view--hidden">
          <button type="button" class="fh-automator-back" data-nav="home">&larr; Back</button>
          <section class="fh-automator-capacity" aria-label="Capacity Check">
            <div class="fh-automator-capacity-header">
              <h3 class="fh-automator-capacity-title">Capacity Check</h3>
              <button type="button" id="fh-automator-refresh-compat" class="fh-automator-refresh">Refresh page check</button>
            </div>
            <p id="fh-automator-capacity-compat" class="fh-automator-capacity-compat"></p>
            <div id="fh-automator-iso-group" class="fh-automator-field">
              <label class="fh-automator-label" for="fh-automator-iso-datetime">Target Date &amp; Time (ISO)</label>
              <input type="text" id="fh-automator-iso-datetime" class="fh-automator-input" placeholder="YYYY-MM-DDTHH:MM:SS" />
            </div>
            <label class="fh-automator-checkbox-row" for="fh-automator-separate-fields">
              <input type="checkbox" id="fh-automator-separate-fields" />
              <span>Separate date and time fields</span>
            </label>
            <div id="fh-automator-date-group" class="fh-automator-field fh-automator-field--hidden">
              <label class="fh-automator-label" for="fh-automator-audit-date">Target Date</label>
              <input type="text" id="fh-automator-audit-date" class="fh-automator-input" placeholder="YYYY-MM-DD" />
            </div>
            <div id="fh-automator-time-group" class="fh-automator-field fh-automator-field--hidden">
              <label class="fh-automator-label" for="fh-automator-audit-time">Target Time</label>
              <input type="text" id="fh-automator-audit-time" class="fh-automator-input" placeholder="HH:MM AM/PM or HH:MM" />
            </div>
            <label class="fh-automator-checkbox-row fh-automator-view--hidden" for="fh-automator-fetch-detailed">
              <input type="checkbox" id="fh-automator-fetch-detailed" />
              <span>Check detailed capacity (includes resources)</span>
            </label>
            <button type="button" id="fh-automator-run-audit" class="fh-automator-run" disabled>Run</button>
            <div id="fh-automator-capacity-engine-row" class="fh-automator-capacity-engine-row fh-automator-view--hidden">
              <label for="fh-automator-capacity-engine" class="fh-automator-capacity-engine-label">Dev engine:</label>
              <select id="fh-automator-capacity-engine" class="fh-automator-capacity-engine-select">
                <option value="dom">DOM current</option>
                <option value="api" selected>API experimental</option>
                <option value="both">Run both and compare</option>
              </select>
            </div>
            <button type="button" id="fh-automator-debug-api-capacity" class="fh-automator-endpoint-scout fh-automator-view--hidden">
              Dev: Run Capacity Check
            </button>
            <button type="button" id="fh-automator-inspect-api-resource-sources" class="fh-automator-endpoint-scout fh-automator-view--hidden">
              Dev: Inspect API Resource Sources
            </button>
            <p id="fh-automator-api-capacity-hint" class="fh-automator-hint fh-automator-view--hidden">
              Dev tools below. Production Run uses API first and falls back to DOM on failure.
            </p>
            <div id="fh-automator-api-capacity-summary" class="fh-automator-api-capacity-summary fh-automator-view--hidden" aria-live="polite"></div>
            <p id="fh-automator-results-stale-warning" class="fh-automator-results-stale-warning fh-automator-view--hidden" aria-live="polite"></p>
            <div id="fh-automator-audit-results" class="fh-automator-audit-results" aria-live="polite"></div>
          </section>
        </div>
        <div id="fh-automator-view-duplicate" class="fh-automator-view fh-automator-view--hidden">
          <button type="button" class="fh-automator-back" data-nav="home">&larr; Back</button>
          <section class="fh-automator-capacity" aria-label="Duplicate Customer Types">
            <div class="fh-automator-capacity-header">
              <h3 class="fh-automator-capacity-title">Duplicate Customer Types</h3>
              <button type="button" id="fh-automator-refresh-duplicate-types" class="fh-automator-refresh">Refresh customer types</button>
            </div>
            <p id="fh-automator-duplicate-compat" class="fh-automator-capacity-compat"></p>
            <div class="fh-automator-field">
              <label class="fh-automator-label" for="fh-automator-customer-type-select">Customer Type to duplicate</label>
              <select id="fh-automator-customer-type-select" class="fh-automator-select"></select>
            </div>
            <div class="fh-automator-field">
              <label class="fh-automator-label" for="fh-automator-basename">Base name</label>
              <input type="text" id="fh-automator-basename" class="fh-automator-input" value="Adult" placeholder="e.g., Adult, Child" />
            </div>
            <div class="fh-automator-field">
              <label class="fh-automator-label" for="fh-automator-duplicate-count">Number of duplicates</label>
              <input type="number" id="fh-automator-duplicate-count" class="fh-automator-input" min="1" max="15" value="5" />
            </div>
            <div class="fh-automator-field">
              <label class="fh-automator-label" for="fh-automator-price-input">Total Group Price (optional)</label>
              <input type="text" id="fh-automator-price-input" class="fh-automator-input" placeholder="e.g., 76.45" />
              <p class="fh-automator-hint">Each duplicate will get this price divided by its number</p>
            </div>
            <button type="button" id="fh-automator-start-duplicate" class="fh-automator-run" disabled>Start Duplication</button>
          </section>
        </div>
        <div id="fh-automator-view-qc" class="fh-automator-view fh-automator-view--hidden">
          <button type="button" class="fh-automator-back" data-nav="home">&larr; Back</button>
          <section class="fh-automator-capacity" aria-label="QC Check">
            <div class="fh-automator-capacity-header">
              <h3 class="fh-automator-capacity-title">QC Checks</h3>
              <button type="button" id="fh-automator-refresh-qc-compat" class="fh-automator-refresh">Refresh page check</button>
            </div>
            <p id="fh-automator-qc-compat" class="fh-automator-capacity-compat"></p>
            <button type="button" id="fh-automator-go-advanced" class="fh-automator-secondary fh-automator-secondary--hidden">Go to Advanced Settings</button>
            <p class="fh-automator-hint" style="text-align: left;">Verify required FareHarbor dashboard defaults on the current company.</p>
            <div class="fh-automator-qc-integrations">
              <p class="fh-automator-qc-integrations-heading">Integrations to check:</p>
              <label class="fh-automator-checkbox-row">
                <input type="checkbox" class="fh-automator-qc-integration-checkbox" value="getyourguide" />
                <span>GetYourGuide</span>
              </label>
              <label class="fh-automator-checkbox-row">
                <input type="checkbox" class="fh-automator-qc-integration-checkbox" value="viator" />
                <span>Viator</span>
              </label>
              <label class="fh-automator-checkbox-row">
                <input type="checkbox" class="fh-automator-qc-integration-checkbox" value="airbnb" />
                <span>Airbnb</span>
              </label>
              <label class="fh-automator-checkbox-row">
                <input type="checkbox" class="fh-automator-qc-integration-checkbox" value="expedia" />
                <span>Expedia</span>
              </label>
              <label class="fh-automator-checkbox-row">
                <input type="checkbox" class="fh-automator-qc-integration-checkbox" value="google" />
                <span>Google</span>
              </label>
              <p class="fh-automator-hint" style="text-align: left;">General checks always run. Integration-specific checks run only for selected integrations.</p>
            </div>
            <button type="button" id="fh-automator-run-qc" class="fh-automator-run" disabled>Run QC Checks</button>
            <p id="fh-automator-qc-results-stale-warning" class="fh-automator-results-stale-warning fh-automator-view--hidden" aria-live="polite"></p>
            <div id="fh-automator-qc-results" class="fh-automator-audit-results" aria-live="polite"></div>
          </section>
        </div>
        <p id="fh-automator-status" class="fh-automator-status" aria-live="polite"></p>
      </div>
      <div class="fh-automator-resize-handle fh-automator-resize-handle--right" data-resize="e" aria-hidden="true"></div>
      <div class="fh-automator-resize-handle fh-automator-resize-handle--bottom" data-resize="s" aria-hidden="true"></div>
      <div class="fh-automator-resize-handle fh-automator-resize-handle--corner" data-resize="se" aria-hidden="true"></div>
    `;

    overlay.querySelector(".fh-automator-close").addEventListener("click", () => {
      setOverlayVisible(false);
    });

    wireOverlayNavigation(overlay);
    wireOverlayHomeStatusRefresh();
    wireOverlayDrag(overlay);
    wireOverlayResize(overlay);
    wireCapacitySection(overlay);
    wireApiCapacityDevSection(overlay);
    wireDuplicateSection(overlay);
    wireQcSection(overlay);
    wireMappingSection(overlay);
    wireEndpointScoutSection(overlay);
    startSpaUrlWatcher();
    document.body.appendChild(overlay);
    restoreOverlayLayout(overlay);
    return overlay;
  }

  function ensureOverlay() {
    let el = getOverlayEl();
    if (!el && isFareHarborHost()) {
      el = createOverlay();
    }
    return el;
  }

  function setOverlayVisible(visible) {
    if (!visible) {
      const el = getOverlayEl();
      if (!el) {
        persistOverlayOpen(false);
        return;
      }
      el.classList.add("fh-automator-overlay--hidden");
      persistOverlayOpen(false);
      return;
    }

    const el = ensureOverlay();
    if (!el) return;
    el.classList.remove("fh-automator-overlay--hidden");
    showView("home");
    refreshEndpointScoutOverlayUI(el);
    refreshGygApiEnrichmentOverlayUI(el);
    refreshViatorPriceSheetsOverlayUI(el);
    persistOverlayOpen(true);
  }

  function toggleOverlay(sendResponse) {
    if (!isFareHarborHost()) {
      sendResponse({ status: "error", error: "Overlay is only available on FareHarbor pages." });
      return;
    }
    const nextVisible = getOverlayEl() ? !isOverlayVisible() : true;
    if (nextVisible) {
      ensureOverlay();
      setOverlayVisible(true);
    } else {
      setOverlayVisible(false);
    }
    sendResponse({ status: "ok", visible: nextVisible });
  }

  function whenBodyReady(fn) {
    if (document.body) {
      fn();
      return;
    }
    document.addEventListener("DOMContentLoaded", fn, { once: true });
  }

  function restoreOverlayFromStorage() {
    if (!isFareHarborHost()) return;
    chrome.storage.local.get([STORAGE_KEY], (r) => {
      if (!r[STORAGE_KEY]) return;
      const showRestored = () => {
        ensureOverlay();
        setOverlayVisible(true);
      };
      if (typeof requestIdleCallback === "function") {
        requestIdleCallback(showRestored, { timeout: 150 });
      } else {
        setTimeout(showRestored, 50);
      }
    });
  }

  function handleMessage(req, sender, sendResponse) {
    if (req.action === "toggleOverlay") {
      toggleOverlay(sendResponse);
      return true;
    }
    sendResponse({ status: "error", error: `Unknown overlay action: ${req.action}` });
    return true;
  }

  window.FareHarborOverlay = { handleMessage };

  whenBodyReady(restoreOverlayFromStorage);

  loadDevModeFromStorage(() => {
    refreshEndpointScoutOverlayUI();
    refreshGygApiEnrichmentOverlayUI();
    refreshViatorPriceSheetsOverlayUI();
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes[DEV_MODE_STORAGE_KEY]) return;
    FareHarborDeveloperAuth.syncDevModeState().then((active) => {
      devModeEnabled = active;
      refreshEndpointScoutOverlayUI();
      refreshGygApiEnrichmentOverlayUI();
      refreshViatorPriceSheetsOverlayUI();
    });
  });

  console.log("[overlay] Module initialized successfully");
})();
