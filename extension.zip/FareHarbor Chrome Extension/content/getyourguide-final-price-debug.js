console.log("[getyourguide-final-price-debug] getyourguide-final-price-debug.js loaded");

(function initializeGetYourGuideFinalPriceDebug() {
  "use strict";

  var DEV_MODE_STORAGE_KEY = FareHarborDeveloperAuth.DEV_MODE_STORAGE_KEY;
  var LOG_PREFIX = "[getyourguide-final-price-debug]";
  var MSG_TYPE = "FH_GYG_FINAL_PRICE_DEBUG";
  var CMD_TYPE = "FH_GYG_FINAL_PRICE_DEBUG_CMD";
  var PRICING_URL_RE = /\/total-sheets\/\d+\/pricing|pricing-for-editing|overlay=.*pricing/i;

  var pageScriptInjected = false;
  var domWatcherStarted = false;
  var inspectedTestIds = new Set();
  var lastReportAppendix = "";
  var hrefPollTimer = null;
  var domMutationObserver = null;
  var domScanInterval = null;
  var scoutPatchPollTimer = null;
  var messageListenerAttached = false;
  var moduleActive = false;

  function log() {
    var args = [LOG_PREFIX].concat(Array.prototype.slice.call(arguments));
    console.log.apply(console, args);
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function isPricingPage() {
    var href = location.href;
    if (PRICING_URL_RE.test(href)) return true;
    return !!(
      document.querySelector('[data-test-id="edit-adult-pricing-button"]') ||
      document.querySelector('[data-test-id*="pricing-button"]')
    );
  }

  function injectPageScript() {
    if (pageScriptInjected) return;
    pageScriptInjected = true;

    var script = document.createElement("script");
    script.src = chrome.runtime.getURL("content/getyourguide-final-price-debug-page.js");
    script.onload = function () {
      script.remove();
    };
    script.onerror = function () {
      console.warn(LOG_PREFIX, "failed to load page script");
    };
    (document.documentElement || document.head || document.body).appendChild(script);
    log("page script injected");
  }

  function postPageCommand(action, extra) {
    var payload = { type: CMD_TYPE, action: action };
    if (extra) {
      for (var key in extra) {
        if (Object.prototype.hasOwnProperty.call(extra, key)) {
          payload[key] = extra[key];
        }
      }
    }
    window.postMessage(payload, window.location.origin);
  }

  function summarizeRowInspection(report) {
    if (!report) return;
    log("=== Adult / row pricing summary ===");
    log("row:", report.rowLabel || report.testId);
    log(
      "base price:",
      report.basePrice ? report.basePrice.value + " (" + report.basePrice.source + ")" : "not found"
    );
    log(
      "final UI price:",
      report.finalUiPrice
        ? report.finalUiPrice.value + " (source: DOM " + report.finalUiPrice.path + ")"
        : "not found in DOM"
    );
    log("controller path:", report.controllerPath || "not found");
    if (report.costPreview && !report.costPreview.skipped) {
      log("costPreview:", report.costPreview);
    }
    if (report.candidateFinalPrices && report.candidateFinalPrices.length) {
      log("candidate final price fields in scope/controller:", report.candidateFinalPrices);
    }
    if (report.keywordHits && report.keywordHits.length) {
      log("keyword scope hits:", report.keywordHits);
    }
    log("effectivePricing:", report.effectivePricing);
  }

  function onPageMessage(event) {
    if (event.source !== window || event.origin !== location.origin) return;
    var data = event.data;
    if (!data || data.type !== MSG_TYPE) return;

    if (data.event === "row-inspection") {
      summarizeRowInspection(data.payload);
      return;
    }

    if (data.event === "pricing-for-editing") {
      log("pricing-for-editing response captured", data.payload);
      return;
    }

    if (data.event === "network") {
      var capture = data.payload;
      if (capture && /cost|preview|pricing|tax|total|gross/i.test(capture.url || "")) {
        log("pricing-related network", capture.method, capture.url, {
          status: capture.status,
          trigger: capture.trigger,
          bodyBytes: capture.bodyBytes
        });
      }
      return;
    }

    if (data.event === "report-appendix") {
      lastReportAppendix = (data.payload && data.payload.appendix) || "";
      log("report appendix ready (" + lastReportAppendix.length + " chars)");
      return;
    }

    if (data.event === "started") {
      log("page debug active on", data.payload && data.payload.href);
      postPageCommand("inspect-all");
    }
  }

  function scanPricingButtons() {
    var buttons = document.querySelectorAll('[data-test-id*="pricing-button"]');
    for (var i = 0; i < buttons.length; i++) {
      var btn = buttons[i];
      var testId = btn.getAttribute("data-test-id");
      if (!testId || inspectedTestIds.has(testId)) continue;
      inspectedTestIds.add(testId);
      postPageCommand("inspect-row", { testId: testId });
    }
  }

  function stopDomWatcher() {
    if (domMutationObserver) {
      domMutationObserver.disconnect();
      domMutationObserver = null;
    }
    if (domScanInterval) {
      clearInterval(domScanInterval);
      domScanInterval = null;
    }
    domWatcherStarted = false;
  }

  function startDomWatcher() {
    if (domWatcherStarted) return;
    domWatcherStarted = true;

    var debounceTimer = null;
    var scheduleScan = function () {
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(scanPricingButtons, 300);
    };

    try {
      domMutationObserver = new MutationObserver(scheduleScan);
      domMutationObserver.observe(document.documentElement, { childList: true, subtree: true });
    } catch (e) {
      log("MutationObserver unavailable", e && e.message);
    }

    window.addEventListener("popstate", scheduleScan);
    window.addEventListener("hashchange", scheduleScan);
    domScanInterval = setInterval(scheduleScan, 2000);
    scheduleScan();
  }

  function patchEndpointScoutReport() {
    if (!window.EndpointScout || window.EndpointScout.__fhGygFinalPricePatched) return false;

    var originalGetReport = window.EndpointScout.getReport.bind(window.EndpointScout);
    window.EndpointScout.getReport = function (options) {
      return originalGetReport(options).then(function (report) {
        postPageCommand("get-report-appendix");
        return new Promise(function (resolve) {
          setTimeout(function () {
            if (lastReportAppendix) {
              log("appending final-price debug section to endpoint scout report");
              resolve(report + "\n" + lastReportAppendix);
            } else {
              resolve(
                report +
                  "\n\n## GetYourGuide Final Price Debug (temporary)\n\n_No final-price debug captures on this page yet. Open the pricing table and interact with a customer type row, then regenerate the report._\n"
              );
            }
          }, 250);
        });
      });
    };

    window.EndpointScout.__fhGygFinalPricePatched = true;
    log("patched EndpointScout.getReport for pricing-page appendix");
    return true;
  }

  function tryPatchEndpointScout() {
    if (patchEndpointScoutReport()) return;
    document.addEventListener("endpoint-scout-enabled", patchEndpointScoutReport);
    var attempts = 0;
    if (scoutPatchPollTimer) {
      clearInterval(scoutPatchPollTimer);
    }
    scoutPatchPollTimer = setInterval(function () {
      attempts += 1;
      if (patchEndpointScoutReport() || attempts > 40) {
        clearInterval(scoutPatchPollTimer);
        scoutPatchPollTimer = null;
      }
    }, 500);
  }

  function enhanceEndpointScoutWhileOnPricingPage() {
    if (!isPricingPage()) return;

    tryPatchEndpointScout();

    if (window.EndpointScout && !window.EndpointScout.__fhGygPricingPatternsPatched) {
      log("pricing page detected — endpoint scout captures should include pricing/tax/cost URLs");
      window.EndpointScout.__fhGygPricingPatternsPatched = true;
    }
  }

  function activateIfNeeded() {
    if (!moduleActive || !isFareHarborHost()) return;
    if (!isPricingPage()) {
      stopDomWatcher();
      return;
    }

    injectPageScript();
    startDomWatcher();
    enhanceEndpointScoutWhileOnPricingPage();
  }

  function stopHrefWatcher() {
    if (hrefPollTimer) {
      clearInterval(hrefPollTimer);
      hrefPollTimer = null;
    }
  }

  function startHrefWatcher() {
    if (hrefPollTimer) return;
    var lastHref = location.href;
    hrefPollTimer = setInterval(function () {
      if (location.href !== lastHref) {
        lastHref = location.href;
        inspectedTestIds.clear();
        activateIfNeeded();
      } else if (isPricingPage()) {
        activateIfNeeded();
      }
    }, 1000);
  }

  function attachMessageListener() {
    if (messageListenerAttached) return;
    messageListenerAttached = true;
    window.addEventListener("message", onPageMessage);
  }

  function startModule() {
    if (moduleActive) return;
    moduleActive = true;
    attachMessageListener();
    startHrefWatcher();

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", activateIfNeeded, { once: true });
    } else {
      activateIfNeeded();
    }

    log("content script initialized (DEV mode)");
  }

  function stopModule() {
    moduleActive = false;
    stopHrefWatcher();
    stopDomWatcher();
    if (scoutPatchPollTimer) {
      clearInterval(scoutPatchPollTimer);
      scoutPatchPollTimer = null;
    }
    if (messageListenerAttached) {
      window.removeEventListener("message", onPageMessage);
      messageListenerAttached = false;
    }
    pageScriptInjected = false;
    inspectedTestIds.clear();
    lastReportAppendix = "";
  }

  window.GetYourGuideFinalPriceDebug = {
    inspectAll: function () {
      if (!moduleActive) return;
      postPageCommand("inspect-all");
    },
    inspectAdult: function () {
      if (!moduleActive) return;
      postPageCommand("inspect-row", { testId: "edit-adult-pricing-button" });
    },
    getLastReportAppendix: function () {
      return lastReportAppendix;
    }
  };

  function bootFromDevMode() {
    FareHarborDeveloperAuth.isDevModeActiveAsync().then(function (enabled) {
      if (enabled) {
        startModule();
      } else {
        stopModule();
      }
    });
  }

  try {
    bootFromDevMode();
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "local" || !changes[DEV_MODE_STORAGE_KEY]) return;
      bootFromDevMode();
    });
  } catch {
    FareHarborDeveloperAuth.logUnavailable("getyourguide-final-price-debug module inactive");
  }
})();
