console.log("[getyourguide-mapping] getyourguide-mapping-enrichment.js loaded");

(function initializeGetYourGuideMappingEnrichment() {
  "use strict";

  const LOG_PREFIX = "[getyourguide-mapping]";
  const CONCURRENCY_LIMIT = 4;
  const AVAILABILITY_SAMPLE_SIZE = 5;
  const AVAILABILITY_MAX_DAYS_TO_SEARCH = 30;

  let rawShapeLogged = {
    item: false,
    availability: false,
    availabilityList: false,
    prototypes: false,
    affiliation: false,
    pricing: false,
    company: false,
    requirementGroups: false,
    resourceRequirements: false,
    resources: false
  };

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function warn(...args) {
    console.warn(LOG_PREFIX, ...args);
  }

  function logRawShapeOnce(key, label, data) {
    if (rawShapeLogged[key]) return;
    rawShapeLogged[key] = true;
    log(`Raw ${label} shape:`, data);
  }

  async function timedAsync(label, fn) {
    const start = performance.now();
    const result = await fn();
    const durationMs = performance.now() - start;
    log(`${label} duration: ${durationMs.toFixed(1)}ms`);
    return { result, durationMs };
  }

  function escapeRegExp(str) {
    return String(str).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function formatUnknown(value) {
    if (value === null || value === undefined || value === "") {
      return "unknown";
    }
    return String(value);
  }

  function formatList(values) {
    if (!Array.isArray(values) || values.length === 0) {
      return "unknown";
    }
    return values.map((value) => formatUnknown(value)).join(", ");
  }

  function isBlankValue(value) {
    return value === null || value === undefined || value === "";
  }

  function toNumberOrNull(value) {
    if (isBlankValue(value)) return null;
    const num = Number(value);
    if (Number.isNaN(num)) return null;
    if (num === 0) {
      log("Observed numeric value 0 in API response:", value);
    }
    return num;
  }

  function pickHighest(...values) {
    const nums = values.map(toNumberOrNull).filter((n) => n !== null);
    return nums.length ? Math.max(...nums) : null;
  }

  function pickLowest(...values) {
    const nums = values.map(toNumberOrNull).filter((n) => n !== null);
    return nums.length ? Math.min(...nums) : null;
  }

  function parseItemAvailabilityFromOverlay(href) {
    try {
      const u = new URL(href, window.location.origin);
      const overlay = u.searchParams.get("overlay");
      if (!overlay) return null;
      const decoded = decodeURIComponent(overlay);
      const m = decoded.match(/\/items\/(\d+)\/availabilities\/(\d+)/i);
      if (!m) return null;
      return { itemId: m[1], availabilityId: m[2] };
    } catch (e) {
      return null;
    }
  }

  function parseCompanyShortname() {
    const parts = (window.location.pathname || "").split("/").filter(Boolean);
    return parts[0] || null;
  }

  function parseItemIdFromDom() {
    let link = document.querySelector(".block-list-content.ng-binding");
    if (!link) link = document.querySelector(".block-list-content");
    if (!link) return null;
    const href = link.getAttribute("href") || "";
    const match = href.match(/\/items\/(\d+)/);
    return match ? match[1] : null;
  }

  function resolveEnrichmentContext(scrapedRows, pageUrl) {
    const company = parseCompanyShortname();
    const href = pageUrl || window.location.href;
    const pathname = (() => {
      try {
        return new URL(href).pathname;
      } catch {
        return window.location.pathname || "";
      }
    })();
    const overlayIds = parseItemAvailabilityFromOverlay(href);

    let availabilityId = overlayIds ? overlayIds.availabilityId : null;
    let itemId = overlayIds ? overlayIds.itemId : null;

    if (!itemId && Array.isArray(scrapedRows) && scrapedRows.length > 0) {
      const first = scrapedRows[0];
      if (first.itemId) {
        itemId = String(first.itemId);
      } else if (first.itemLabel) {
        itemId = extractIdNumberFromLabel(first.itemLabel);
      }
    }

    if (!itemId) {
      itemId = parseItemIdFromDom();
    }

    if (!itemId) {
      const itemMatch = pathname.match(/\/items\/(\d+)/);
      itemId = itemMatch ? itemMatch[1] : null;
    }

    if (!availabilityId) {
      const availMatch = pathname.match(/\/availabilities\/(\d+)/);
      availabilityId = availMatch ? availMatch[1] : null;
    }

    return { company, itemId, availabilityId, pageUrl: href };
  }

  function extractIdNumberFromLabel(itemLabel) {
    if (!itemLabel) return null;
    let match = String(itemLabel).match(/\(ID:\s*(\d+)\)/);
    if (match) return match[1];
    match = String(itemLabel).match(/\((\d+)\)/);
    return match ? match[1] : null;
  }

  function extractItemNameFromLabel(itemLabel) {
    if (!itemLabel) return "";
    let cleaned = String(itemLabel).replace(/\(ID:\s*\d+\)/g, "").trim();
    if (cleaned === String(itemLabel).trim()) {
      cleaned = String(itemLabel).replace(/\(\d+\)/g, "").trim();
    }
    return cleaned;
  }

  async function apiGetJson(url) {
    try {
      const response = await fetch(url, {
        method: "GET",
        credentials: "include",
        headers: { Accept: "application/json" }
      });

      if (!response.ok) {
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `API request failed with status ${response.status}`
        };
      }

      try {
        const data = await response.json();
        return { ok: true, status: response.status, data, error: null };
      } catch (err) {
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `Response is not valid JSON: ${err.message}`
        };
      }
    } catch (err) {
      return { ok: false, status: null, data: null, error: `Fetch failed: ${err.message}` };
    }
  }

  async function fetchItemData(company, itemId) {
    const url = `/api/v1/companies/${encodeURIComponent(company)}/items/${encodeURIComponent(itemId)}/`;
    log("Fetching item:", url);
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, item: null, error: result.error };
    }
    const item = result.data?.item ?? result.data ?? null;
    logRawShapeOnce("item", "item data", item);
    if (!item || typeof item !== "object") {
      return { ok: false, item: null, error: "Response missing item object" };
    }
    return { ok: true, item, error: null };
  }

  async function fetchCompanyData(company) {
    const url = `/api/v1/companies/${encodeURIComponent(company)}/`;
    log("Fetching company:", url);
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, company: null, error: result.error };
    }
    const companyData = result.data?.company ?? result.data ?? null;
    logRawShapeOnce("company", "company data", companyData);
    if (!companyData || typeof companyData !== "object") {
      return { ok: false, company: null, error: "Response missing company object" };
    }
    return { ok: true, company: companyData, error: null };
  }

  function getProcessorCurrency(companyData) {
    if (!companyData || typeof companyData !== "object") return null;
    const currency = companyData.processor_currency ?? companyData.processorCurrency ?? null;
    if (isBlankValue(currency)) return null;
    return String(currency).toLowerCase().trim();
  }

  function formatCurrencyAmount(amount, processorCurrency) {
    if (isBlankValue(amount)) return "unknown";
    const num = Number(amount);
    if (Number.isNaN(num)) return "unknown";

    const formatted = num.toFixed(2);
    if (isBlankValue(processorCurrency)) {
      return formatted;
    }

    const currency = String(processorCurrency).toLowerCase().trim();
    if (currency === "eur") return `€${formatted}`;
    if (currency === "usd") return `$${formatted}`;
    if (currency) return `${currency.toUpperCase()} ${formatted}`;
    return formatted;
  }

  function formatEnrichmentPriceDisplay(amount, processorCurrency) {
    if (isBlankValue(amount)) return "unknown";
    return formatCurrencyAmount(amount, processorCurrency);
  }

  function normalizeUniqueSortedPrices(values) {
    const numericValues = [];
    for (const value of values || []) {
      if (isBlankValue(value)) continue;
      const num = toNumberOrNull(value);
      if (num === null) continue;
      numericValues.push(num);
    }
    if (numericValues.length === 0) return [];

    const unique = [...new Set(numericValues)];
    unique.sort((a, b) => a - b);
    return unique;
  }

  function formatAggregatedPriceDisplay(prices, processorCurrency) {
    const uniqueSorted = normalizeUniqueSortedPrices(prices);
    if (uniqueSorted.length === 0) return "unknown";
    if (uniqueSorted.length === 1) {
      return formatEnrichmentPriceDisplay(uniqueSorted[0], processorCurrency);
    }
    return uniqueSorted
      .map((price) => formatEnrichmentPriceDisplay(price, processorCurrency))
      .join(" / ");
  }

  function formatMultipleEnrichmentPrices(prices, processorCurrency) {
    return formatAggregatedPriceDisplay(prices, processorCurrency);
  }

  function collectEnrichmentPrices(typeReport, kind) {
    const listKey = kind === "final" ? "finalPrices" : "basePrices";
    const singleKey = kind === "final" ? "finalPrice" : "basePrice";
    const perSheetKey = kind === "final" ? "finalPricesPerSheet" : "basePricesPerSheet";

    if (Array.isArray(typeReport?.[listKey]) && typeReport[listKey].length > 0) {
      return typeReport[listKey];
    }
    if (Array.isArray(typeReport?.[perSheetKey]) && typeReport[perSheetKey].length > 0) {
      return typeReport[perSheetKey].flat();
    }
    if (!isBlankValue(typeReport?.[singleKey])) {
      return [typeReport[singleKey]];
    }
    return [];
  }

  function getTotalPricingResolution() {
    return window.FareHarborTotalPricingResolution ?? null;
  }

  function extractTotalSheetsFromSchedule(schedule) {
    const resolver = getTotalPricingResolution();
    if (resolver?.extractTotalSheetsFromSchedule) {
      return resolver.extractTotalSheetsFromSchedule(schedule);
    }
    return [];
  }

  function extractScheduleFromDetailResponse(data) {
    if (!data || typeof data !== "object") return null;
    return data.total_schedule ?? data.schedule ?? data;
  }

  async function fetchTotalScheduleDetail(company, schedulePk) {
    const url =
      `/api/v1/companies/${encodeURIComponent(company)}/total-schedules/${encodeURIComponent(schedulePk)}/`;
    log("Fetching total schedule detail:", url);
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, schedule: null, error: result.error };
    }
    const schedule = extractScheduleFromDetailResponse(result.data);
    if (!schedule || typeof schedule !== "object") {
      return { ok: false, schedule: null, error: "Response missing total schedule object" };
    }
    logRawShapeOnce("totalSchedule", "total schedule detail", schedule);
    return { ok: true, schedule, error: null };
  }

  async function fetchTotalSchedulesList(company) {
    const url = `/api/v1/companies/${encodeURIComponent(company)}/total-schedules/`;
    log("Fetching total schedules list:", url);
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, schedules: [], error: result.error };
    }
    const schedules = result.data?.total_schedules ?? result.data?.schedules ?? [];
    if (!Array.isArray(schedules)) {
      return { ok: false, schedules: [], error: "Response missing total_schedules array" };
    }
    return { ok: true, schedules, error: null };
  }

  async function resolveTotalScheduleWithSheets(company, schedulePk) {
    const detailResult = await fetchTotalScheduleDetail(company, schedulePk);
    let schedule = detailResult.ok ? detailResult.schedule : null;

    if (schedule) {
      const sheets = extractTotalSheetsFromSchedule(schedule);
      if (sheets.length > 0) {
        return { ok: true, schedule, sheets, error: null };
      }
    }

    const listResult = await fetchTotalSchedulesList(company);
    if (listResult.ok) {
      const resolver = getTotalPricingResolution();
      const getPk = resolver?.getPricingObjectPk ?? getPricingObjectPk;
      const match = listResult.schedules.find(
        (candidate) => String(getPk(candidate)) === String(schedulePk)
      );
      if (match) {
        schedule = match;
        const sheets = extractTotalSheetsFromSchedule(match);
        if (sheets.length > 0) {
          return { ok: true, schedule, sheets, error: null };
        }
      }
    }

    return {
      ok: false,
      schedule,
      sheets: [],
      error:
        detailResult.error ||
        listResult.error ||
        "Could not read total sheets from assigned schedule"
    };
  }

  async function fetchPricingForAssignedSchedule(company, assignedPricing, itemId) {
    const schedulePk = assignedPricing.pk;
    const scheduleName = assignedPricing.displayName;
    log("Assigned total schedule pk:", schedulePk);
    log("Assigned total schedule name:", scheduleName);

    const scheduleResult = await resolveTotalScheduleWithSheets(company, schedulePk);
    if (!scheduleResult.ok) {
      return {
        kind: "schedule",
        ok: false,
        schedulePk,
        scheduleName,
        sheetResults: [],
        error: scheduleResult.error
      };
    }

    const sheets = scheduleResult.sheets;
    log(
      "Total sheet pks found in schedule:",
      sheets.map((sheet) => sheet.pk)
    );

    const sheetResults = [];
    for (const sheet of sheets) {
      const pricingResult = await fetchPricingForEditing(company, sheet.pk, itemId);
      log(
        `Pricing endpoint fetched for sheet ${sheet.pk} (${sheet.name}):`,
        pricingResult.ok ? "ok" : pricingResult.error
      );
      sheetResults.push({
        pk: sheet.pk,
        name: sheet.name,
        ok: pricingResult.ok,
        error: pricingResult.error,
        pricing: pricingResult.pricing,
        pricingRows: pricingResult.ok ? getEffectivePricings(pricingResult.pricing) : [],
        matchedByDisplayName: {}
      });
    }

    const anyOk = sheetResults.some((sheet) => sheet.ok);
    return {
      kind: "schedule",
      ok: anyOk,
      schedulePk,
      scheduleName,
      sheetResults,
      error: anyOk
        ? null
        : sheetResults.length > 0
          ? "All schedule sheet pricing fetches failed"
          : "No total sheets found in assigned schedule"
    };
  }

  async function fetchAvailabilityData(company, itemId, availabilityId) {
    const url = getAvailabilityDetailEndpoint(company, itemId, availabilityId);
    log("Fetching availability:", url);
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, availability: null, error: result.error };
    }
    const availability = result.data?.availability ?? result.data ?? null;
    logRawShapeOnce("availability", "availability data", availability);
    if (!availability || typeof availability !== "object") {
      return { ok: false, availability: null, error: "Response missing availability object" };
    }
    return { ok: true, availability, error: null };
  }

  function formatIsoDate(date) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  function extractAvailabilitiesFromListResponse(data) {
    if (!data) return [];
    if (Array.isArray(data.availabilities)) return data.availabilities;
    if (Array.isArray(data.availability_list)) return data.availability_list;
    if (Array.isArray(data.calendar_availabilities)) return data.calendar_availabilities;
    if (Array.isArray(data.calendarAvailabilities)) return data.calendarAvailabilities;
    if (Array.isArray(data.days)) {
      const flattened = [];
      for (const day of data.days) {
        if (Array.isArray(day?.availabilities)) flattened.push(...day.availabilities);
        if (Array.isArray(day?.availability_list)) flattened.push(...day.availability_list);
      }
      if (flattened.length > 0) return flattened;
    }
    if (Array.isArray(data.results)) return data.results;

    if (data && typeof data === "object" && !Array.isArray(data)) {
      const flattened = [];
      for (const value of Object.values(data)) {
        if (Array.isArray(value)) {
          flattened.push(...value);
        } else if (value && typeof value === "object" && getAvailabilityPk(value)) {
          flattened.push(value);
        }
      }
      if (flattened.length > 0) return flattened;
    }

    if (Array.isArray(data)) return data;
    return [];
  }

  function getAvailabilityPk(availability) {
    const pk = availability?.pk ?? availability?.id ?? null;
    return pk === null || pk === undefined ? null : String(pk);
  }

  function getAvailabilityStartAt(availability) {
    return (
      availability?.start_at ??
      availability?.startAt ??
      availability?.start ??
      availability?.start_time ??
      availability?.startTime ??
      null
    );
  }

  function getAvailabilityDetailEndpoint(company, itemId, availabilityId) {
    return (
      `/api/v1/companies/${encodeURIComponent(company)}/items/${encodeURIComponent(itemId)}` +
      `/availabilities/${encodeURIComponent(availabilityId)}/?include_custom_field_details=no`
    );
  }

  function getAvailabilityDateEndpoint(company, itemId, date) {
    return (
      `/api/v1/companies/${encodeURIComponent(company)}/items/${encodeURIComponent(itemId)}` +
      `/availabilities/date/${date}/`
    );
  }

  async function fetchAvailabilitiesForDate(company, itemId, date) {
    const url = getAvailabilityDateEndpoint(company, itemId, date);
    const result = await apiGetJson(url);
    if (!result.ok) {
      return {
        ok: false,
        url,
        date,
        status: result.status,
        error: result.error,
        availabilities: []
      };
    }
    logRawShapeOnce("availabilityList", `availability list (date ${date})`, result.data);
    return {
      ok: true,
      url,
      date,
      status: result.status,
      error: null,
      availabilities: extractAvailabilitiesFromListResponse(result.data)
    };
  }

  function addCandidatesFromEntries(byPk, entries, source) {
    for (const entry of entries || []) {
      const pk = getAvailabilityPk(entry);
      if (!pk) continue;
      const startAt = getAvailabilityStartAt(entry);
      const existing = byPk.get(pk);
      if (!existing || (!existing.startAt && startAt)) {
        byPk.set(pk, { pk, startAt, source });
      }
    }
  }

  function sortAvailabilityCandidates(candidates) {
    const nowMs = Date.now();
    return candidates.sort((a, b) => {
      const aMs = a.startAt ? new Date(a.startAt).getTime() : Number.MAX_SAFE_INTEGER;
      const bMs = b.startAt ? new Date(b.startAt).getTime() : Number.MAX_SAFE_INTEGER;
      const aUpcoming = Number.isFinite(aMs) ? aMs >= nowMs - 24 * 60 * 60 * 1000 : true;
      const bUpcoming = Number.isFinite(bMs) ? bMs >= nowMs - 24 * 60 * 60 * 1000 : true;
      if (aUpcoming !== bUpcoming) return aUpcoming ? -1 : 1;
      return aMs - bMs;
    });
  }

  async function collectAvailabilityCandidates(company, itemId) {
    const byPk = new Map();
    const attemptLog = [];
    let successfulEndpoint = null;
    const now = new Date();

    for (let dayOffset = 0; dayOffset < AVAILABILITY_MAX_DAYS_TO_SEARCH; dayOffset += 1) {
      if (byPk.size >= AVAILABILITY_SAMPLE_SIZE) {
        break;
      }

      const day = new Date(now.getFullYear(), now.getMonth(), now.getDate() + dayOffset);
      const date = formatIsoDate(day);
      const result = await fetchAvailabilitiesForDate(company, itemId, date);
      const candidateCountBefore = byPk.size;

      if (!result.ok) {
        attemptLog.push({
          key: "availabilities-date",
          url: result.url,
          date,
          status: result.status,
          error: result.error,
          candidateCount: 0
        });
        return {
          candidates: [],
          attemptLog,
          successfulEndpoint: null,
          failed: true,
          error: `Availability date endpoint failed for ${date}: ${result.error}`
        };
      }

      addCandidatesFromEntries(byPk, result.availabilities, "availabilities-date");
      const added = byPk.size - candidateCountBefore;
      attemptLog.push({
        key: "availabilities-date",
        url: result.url,
        date,
        status: result.status,
        error: null,
        candidateCount: added
      });

      if (added > 0 && !successfulEndpoint) {
        successfulEndpoint = result.url;
      }
    }

    const candidates = sortAvailabilityCandidates([...byPk.values()]).slice(0, AVAILABILITY_SAMPLE_SIZE);
    if (candidates.length === 0) {
      return {
        candidates: [],
        attemptLog,
        successfulEndpoint: null,
        failed: true,
        error: "No availability candidates found via date endpoint"
      };
    }

    return { candidates, attemptLog, successfulEndpoint, failed: false, error: null };
  }

  function calculateTotalAvailabilityCapacity(availability) {
    if (!availability) {
      return { total: null, customerCount: null, bookableCapacity: null, sampleWarning: null };
    }

    const rawCustomerCount = availability.customer_count ?? availability.customerCount;
    const bookableCapacity = toNumberOrNull(
      availability.bookable_capacity ?? availability.bookableCapacity
    );

    if (bookableCapacity === null) {
      return {
        total: null,
        customerCount: toNumberOrNull(rawCustomerCount),
        bookableCapacity: null,
        sampleWarning: "bookable_capacity missing; total capacity not calculated"
      };
    }

    let customerCount = toNumberOrNull(rawCustomerCount);
    let sampleWarning = null;

    if (customerCount === null) {
      customerCount = 0;
      sampleWarning = "customer_count missing; assumed 0 for total capacity calculation";
    }

    return {
      total: customerCount + bookableCapacity,
      customerCount,
      bookableCapacity,
      sampleWarning
    };
  }

  function buildCapacitySampleFromAvailability(availabilityId, availability) {
    const capacity = calculateTotalAvailabilityCapacity(availability);
    return {
      availabilityId: String(availabilityId),
      startAt: getAvailabilityStartAt(availability),
      customerCount: capacity.customerCount,
      bookableCapacity: capacity.bookableCapacity,
      totalCapacity: capacity.total,
      sampleWarning: capacity.sampleWarning
    };
  }

  function analyzeCapacitySamples(samples) {
    const validSamples = (samples || []).filter(
      (sample) => sample.totalCapacity !== null && sample.totalCapacity !== undefined
    );

    if (validSamples.length === 0) {
      return {
        selectedFallbackCapacity: null,
        capacitySampleWarning: null,
        uniform: false
      };
    }

    const uniqueTotals = [...new Set(validSamples.map((sample) => sample.totalCapacity))];
    if (uniqueTotals.length === 1) {
      return {
        selectedFallbackCapacity: uniqueTotals[0],
        capacitySampleWarning: null,
        uniform: true
      };
    }

    const minCap = Math.min(...uniqueTotals);
    const maxCap = Math.max(...uniqueTotals);

    return {
      selectedFallbackCapacity: null,
      capacitySampleWarning: `Multiple capacities detected (${minCap}–${maxCap}). This item appears to use different capacities across availabilities.`,
      uniform: false
    };
  }

  function fetchAvailabilityDetail(company, itemId, availabilityId) {
    return fetchAvailabilityData(company, itemId, availabilityId);
  }

  function isValidCapacityCandidate(value) {
    const num = toNumberOrNull(value);
    return num !== null && num > 0;
  }

  function getCustomerTypeRatesFromAvailability(availability) {
    const rates = availability?.customer_type_rates ?? availability?.customerTypeRates;
    if (Array.isArray(rates)) return rates;
    if (rates && Array.isArray(rates.items)) return rates.items;
    return [];
  }

  function extractAvailabilityCapacityDetails(availability) {
    const pk = availability?.pk ?? availability?.id ?? null;
    return {
      availabilityPk: pk,
      startAt: getAvailabilityStartAt(availability),
      capacity: toNumberOrNull(availability?.capacity),
      nonResourceBookableCapacity: toNumberOrNull(
        availability?.non_resource_bookable_capacity ?? availability?.nonResourceBookableCapacity
      ),
      blocksIncludedNonResourceBookableCapacity: toNumberOrNull(
        availability?.blocks_included_non_resource_bookable_capacity ??
          availability?.blocksIncludedNonResourceBookableCapacity
      ),
      customerTypeRates: getCustomerTypeRatesFromAvailability(availability).map((rate) => {
        const prototype = rate?.customer_prototype ?? rate?.customerPrototype ?? {};
        return {
          prototypePk: prototype?.pk ?? null,
          prototypeName:
            prototype?.display_name ??
            prototype?.displayName ??
            prototype?.name ??
            rate?.unicode ??
            null,
          capacity: toNumberOrNull(rate?.capacity),
          minimumPartySize: toNumberOrNull(rate?.minimum_party_size ?? rate?.minimumPartySize),
          maximumPartySize: toNumberOrNull(rate?.maximum_party_size ?? rate?.maximumPartySize),
          capacityRemaining: toNumberOrNull(rate?.capacity_remaining ?? rate?.capacityRemaining)
        };
      })
    };
  }

  function matchCustomerTypeRateToMapping(rate, prototype) {
    if (!prototype || !rate) return false;
    const ratePrototype = rate?.customer_prototype ?? rate?.customerPrototype ?? rate;
    const ratePk = ratePrototype?.pk ?? rate?.prototypePk ?? null;
    return identifiersMatch(ratePk, prototype?.pk);
  }

  function gatherMatchedAvailabilityRates(availabilityDetails, prototype) {
    const matches = [];
    for (const detail of availabilityDetails || []) {
      for (const rate of detail.customerTypeRates || []) {
        const wrappedRate = {
          customer_prototype: { pk: rate.prototypePk },
          prototypePk: rate.prototypePk
        };
        if (!matchCustomerTypeRateToMapping(wrappedRate, prototype)) continue;
        matches.push({
          ...rate,
          availabilityPk: detail.availabilityPk,
          startAt: detail.startAt
        });
      }
    }
    return matches;
  }

  function gatherAllMatchedRatesForMappedPrototypes(availabilityDetail, mappedPrototypes) {
    const matches = [];
    for (const prototype of mappedPrototypes || []) {
      matches.push(...gatherMatchedAvailabilityRates([availabilityDetail], prototype));
    }
    return matches;
  }

  function isPresentNumericValue(value) {
    const num = toNumberOrNull(value);
    return num !== null;
  }

  function hasUsefulMatchedRateFields(matches) {
    for (const match of matches || []) {
      if (isPresentNumericValue(match.capacity)) return true;
      if (isPresentNumericValue(match.minimumPartySize)) return true;
      if (isPresentNumericValue(match.maximumPartySize)) return true;
      if (isPresentNumericValue(match.capacityRemaining)) return true;
    }
    return false;
  }

  function detailHasMatchingRates(availabilityDetail, mappedPrototypes) {
    if (!availabilityDetail) return false;
    if (!mappedPrototypes || mappedPrototypes.length === 0) {
      return (availabilityDetail.customerTypeRates || []).length > 0;
    }
    return gatherAllMatchedRatesForMappedPrototypes(availabilityDetail, mappedPrototypes).length > 0;
  }

  function getInspectionMatchesForDetail(availabilityDetail, mappedPrototypes) {
    if (!availabilityDetail) return [];
    if (!mappedPrototypes || mappedPrototypes.length === 0) {
      return availabilityDetail.customerTypeRates || [];
    }
    return gatherAllMatchedRatesForMappedPrototypes(availabilityDetail, mappedPrototypes);
  }

  function buildAvailabilityDetailFetchSummary(fetchedCount, totalSampled, noteKey) {
    const summary = {
      fetchedCount,
      totalSampled,
      noteKey,
      message: null
    };

    if (noteKey === "additional_fetched") {
      summary.message = `Fetched ${fetchedCount} of ${totalSampled} sampled availability details.\nAdditional details fetched because per-customer-type capacity/min/max values were found.`;
    } else if (noteKey === "skipped_no_useful_first") {
      summary.message = `Fetched ${fetchedCount} of ${totalSampled} sampled availability details.\nSkipped remaining details because the first matched availability detail had no per-customer-type capacity/min/max values.`;
    } else if (noteKey === "skipped_after_retry") {
      summary.message = `Fetched ${fetchedCount} of ${totalSampled} sampled availability details.\nSkipped remaining details because no useful matched customer type rate values were found after retrying a second sampled availability.`;
    } else if (fetchedCount > 0) {
      summary.message = `Fetched ${fetchedCount} of ${totalSampled} sampled availability details.`;
    }

    return summary;
  }

  async function fetchAvailabilityDetailSample(company, itemId, candidate) {
    const detailUrl = getAvailabilityDetailEndpoint(company, itemId, candidate.pk);
    const availResult = await fetchAvailabilityDetail(company, itemId, candidate.pk);
    return { candidate, detailUrl, availResult };
  }

  async function fetchAvailabilityDetailsProgressively(
    company,
    itemId,
    candidates,
    mappedPrototypes,
    detailAttemptLog
  ) {
    const totalSampled = candidates.length;
    const availabilityDetails = [];
    const samples = [];
    let fetchedCount = 0;
    let noteKey = null;

    function recordSuccess(candidate, availResult, detailUrl) {
      detailAttemptLog.push({
        availabilityId: candidate.pk,
        url: detailUrl,
        status: "ok",
        error: null
      });
      log("Availability detail endpoint fetched:", detailUrl);
      const detail = extractAvailabilityCapacityDetails(availResult.availability);
      availabilityDetails.push(detail);
      samples.push(buildCapacitySampleFromAvailability(candidate.pk, availResult.availability));
      fetchedCount += 1;
      log(`customer_type_rates found for availability ${candidate.pk}:`, detail.customerTypeRates.length);
      return detail;
    }

    function recordFailure(candidate, detailUrl, error) {
      detailAttemptLog.push({
        availabilityId: candidate.pk,
        url: detailUrl,
        status: error,
        error
      });
      warn(`Sample availability fetch failed for ${candidate.pk}:`, error);
    }

    async function fetchAdditionalFromIndex(startIndex, maxAdditional) {
      let added = 0;
      for (
        let index = startIndex;
        index < candidates.length && added < maxAdditional;
        index += 1
      ) {
        const { candidate, detailUrl, availResult } = await fetchAvailabilityDetailSample(
          company,
          itemId,
          candidates[index]
        );
        if (!availResult.ok) {
          recordFailure(candidate, detailUrl, availResult.error);
          continue;
        }
        recordSuccess(candidate, availResult, detailUrl);
        added += 1;
      }
    }

    const first = await fetchAvailabilityDetailSample(company, itemId, candidates[0]);
    if (!first.availResult.ok) {
      recordFailure(first.candidate, first.detailUrl, first.availResult.error);

      if (candidates.length > 1) {
        const second = await fetchAvailabilityDetailSample(company, itemId, candidates[1]);
        if (!second.availResult.ok) {
          recordFailure(second.candidate, second.detailUrl, second.availResult.error);
          noteKey = "skipped_after_retry";
        } else {
          const secondDetail = recordSuccess(second.candidate, second.availResult, second.detailUrl);
          const secondMatches = getInspectionMatchesForDetail(secondDetail, mappedPrototypes);
          if (
            detailHasMatchingRates(secondDetail, mappedPrototypes) &&
            hasUsefulMatchedRateFields(secondMatches)
          ) {
            await fetchAdditionalFromIndex(2, AVAILABILITY_SAMPLE_SIZE - fetchedCount);
            noteKey = "additional_fetched";
          } else {
            noteKey = "skipped_after_retry";
          }
        }
      } else {
        noteKey = "skipped_after_retry";
      }
    } else {
      const firstDetail = recordSuccess(first.candidate, first.availResult, first.detailUrl);
      const firstMatches = getInspectionMatchesForDetail(firstDetail, mappedPrototypes);

      if (detailHasMatchingRates(firstDetail, mappedPrototypes)) {
        if (hasUsefulMatchedRateFields(firstMatches)) {
          await fetchAdditionalFromIndex(1, AVAILABILITY_SAMPLE_SIZE - fetchedCount);
          noteKey = "additional_fetched";
        } else {
          noteKey = "skipped_no_useful_first";
        }
      } else if (candidates.length > 1) {
        const second = await fetchAvailabilityDetailSample(company, itemId, candidates[1]);
        if (!second.availResult.ok) {
          recordFailure(second.candidate, second.detailUrl, second.availResult.error);
          noteKey = "skipped_after_retry";
        } else {
          const secondDetail = recordSuccess(second.candidate, second.availResult, second.detailUrl);
          const secondMatches = getInspectionMatchesForDetail(secondDetail, mappedPrototypes);
          if (
            detailHasMatchingRates(secondDetail, mappedPrototypes) &&
            hasUsefulMatchedRateFields(secondMatches)
          ) {
            await fetchAdditionalFromIndex(2, AVAILABILITY_SAMPLE_SIZE - fetchedCount);
            noteKey = "additional_fetched";
          } else {
            noteKey = "skipped_after_retry";
          }
        }
      }
    }

    return {
      availabilityDetails,
      samples,
      detailFetchSummary: buildAvailabilityDetailFetchSummary(fetchedCount, totalSampled, noteKey)
    };
  }

  function selectSmallestSampledValue(values) {
    const valid = (values || []).map(toNumberOrNull).filter((v) => isValidCapacityCandidate(v));
    if (valid.length === 0) {
      return { selected: null, sampled: [], uniform: false };
    }
    const unique = [...new Set(valid)];
    return {
      selected: Math.min(...valid),
      sampled: valid,
      uniform: unique.length === 1
    };
  }

  function selectLargestSampledValue(values) {
    const valid = (values || []).map(toNumberOrNull).filter((v) => isValidCapacityCandidate(v));
    if (valid.length === 0) {
      return { selected: null, sampled: [], uniform: false };
    }
    const unique = [...new Set(valid)];
    return {
      selected: Math.max(...valid),
      sampled: valid,
      uniform: unique.length === 1
    };
  }

  function dedupePreservingOrder(values) {
    const seen = new Set();
    const result = [];
    for (const value of values || []) {
      if (value === null || value === undefined) continue;
      const key = String(value);
      if (seen.has(key)) continue;
      seen.add(key);
      result.push(value);
    }
    return result;
  }

  function calculateGroupedMappedCustomerTypeMin(item, prototypes) {
    const mins = (prototypes || [])
      .map((prototype) => calculateEffectiveMin(item, prototype))
      .map(toNumberOrNull)
      .filter((value) => value !== null);
    return mins.length ? Math.min(...mins) : null;
  }

  function calculateGroupedMappedCustomerTypeMax(prototypes) {
    const maxes = [];
    for (const prototype of prototypes || []) {
      for (const field of [
        prototype?.maximum_party_size,
        prototype?.maximum_group_size,
        prototype?.capacity
      ]) {
        if (isValidCapacityCandidate(field)) {
          maxes.push(toNumberOrNull(field));
        }
      }
    }
    return maxes.length ? Math.max(...maxes) : null;
  }

  function gatherMatchedAvailabilityRatesForPrototypes(availabilityDetails, prototypes) {
    const matches = [];
    for (const prototype of prototypes || []) {
      matches.push(...gatherMatchedAvailabilityRates(availabilityDetails, prototype));
    }
    return matches;
  }

  function formatDiagnosticPriceList(prices, processorCurrency) {
    const formatted = (prices || [])
      .filter((price) => !isBlankValue(price))
      .map((price) => formatEnrichmentPriceDisplay(price, processorCurrency))
      .filter((price) => price !== "unknown");
    return formatted.length > 0 ? formatted.join(" / ") : "unknown";
  }

  function formatPriceRangeLabel(prices, processorCurrency) {
    const deduped = dedupePreservingOrder(
      (prices || []).filter((price) => !isBlankValue(price))
    );
    if (deduped.length === 0) return "unknown";
    if (deduped.length === 1) {
      return formatEnrichmentPriceDisplay(deduped[0], processorCurrency);
    }

    const numericPrices = deduped.map(toNumberOrNull).filter((value) => value !== null);
    if (numericPrices.length >= 2) {
      const min = Math.min(...numericPrices);
      const max = Math.max(...numericPrices);
      const minLabel = formatEnrichmentPriceDisplay(min, processorCurrency);
      const maxLabel = formatEnrichmentPriceDisplay(max, processorCurrency);
      if (minLabel !== maxLabel) {
        return `${minLabel}-${maxLabel}`;
      }
    }

    return formatDiagnosticPriceList(deduped, processorCurrency);
  }

  function formatScheduleSheetPriceLabels(sheetPriceLabels) {
    const labels = (sheetPriceLabels || []).filter((label) => label && label !== "unknown");
    return labels.length > 0 ? labels.join(" / ") : "unknown";
  }

  function getEnrichmentPriceDisplay(typeReport, processorCurrency) {
    return formatAggregatedPriceDisplay(
      collectEnrichmentPrices(typeReport, "final"),
      processorCurrency
    );
  }

  function getEnrichmentBasePriceDisplay(typeReport, processorCurrency) {
    return formatAggregatedPriceDisplay(
      collectEnrichmentPrices(typeReport, "base"),
      processorCurrency
    );
  }

  function collectCapacityCandidates({
    item,
    prototype,
    prototypes,
    resourceDerivedCapacity,
    availabilityDetailMatches,
    pollingFallbackCapacity
  }) {
    const prototypeList =
      prototypes?.length > 0 ? prototypes : prototype ? [prototype] : [];
    const isGroupedMappedCustomerTypes = prototypeList.length > 1;
    const candidates = [];

    function addCandidate(value, source) {
      if (!isValidCapacityCandidate(value)) return;
      candidates.push({ value: toNumberOrNull(value), source });
    }

    if (prototypeList.length > 1) {
      const groupedMappedMax = calculateGroupedMappedCustomerTypeMax(prototypeList);
      addCandidate(groupedMappedMax, "mapped customer type maximum");
    } else if (prototypeList.length === 1) {
      const singlePrototype = prototypeList[0];
      addCandidate(singlePrototype.maximum_party_size, "customer prototype maximum_party_size");
      addCandidate(singlePrototype.maximum_group_size, "customer prototype maximum_group_size");
      addCandidate(singlePrototype.capacity, "customer prototype capacity");
    }

    if (item) {
      addCandidate(item.maximum_initial_party_size, "item maximum_initial_party_size");
      addCandidate(item.maximum_subsequent_party_size, "item maximum_subsequent_party_size");
    }

    addCandidate(resourceDerivedCapacity, "resource requirement endpoint");

    const rateCapacitySelection = selectSmallestSampledValue(
      (availabilityDetailMatches || []).map((match) => match.capacity)
    );
    if (rateCapacitySelection.selected !== null) {
      candidates.push({
        value: rateCapacitySelection.selected,
        source: "availability customer_type_rates.capacity"
      });
    }

    const perBookingMinSelection = selectSmallestSampledValue(
      (availabilityDetailMatches || []).map((match) => match.minimumPartySize)
    );
    const perBookingMaxSelection = isGroupedMappedCustomerTypes
      ? selectLargestSampledValue(
          (availabilityDetailMatches || []).map((match) => match.maximumPartySize)
        )
      : selectSmallestSampledValue(
          (availabilityDetailMatches || []).map((match) => match.maximumPartySize)
        );
    if (perBookingMaxSelection.selected !== null) {
      candidates.push({
        value: perBookingMaxSelection.selected,
        source: "availability customer_type_rates.maximum_party_size"
      });
    }

    addCandidate(pollingFallbackCapacity, "availability endpoint");

    const availabilityPerBookingMinimum = perBookingMinSelection.selected;
    const availabilityPerBookingMaximum = perBookingMaxSelection.selected;

    if (isGroupedMappedCustomerTypes) {
      log("Grouped availability per-booking limits:", {
        minimum: availabilityPerBookingMinimum,
        maximum: availabilityPerBookingMaximum,
        sampledMinimums: perBookingMinSelection.sampled,
        sampledMaximums: perBookingMaxSelection.sampled
      });
    }

    const matchMethod =
      availabilityDetailMatches && availabilityDetailMatches.length > 0
        ? "customer_prototype.pk"
        : null;

    if (candidates.length === 0) {
      return {
        effectiveMax: null,
        capacitySource: null,
        candidates: [],
        availabilityCustomerTypeCapacity: rateCapacitySelection.selected,
        availabilityPerBookingMinimum,
        availabilityPerBookingMaximum,
        availabilitySampledCapacities: rateCapacitySelection.sampled,
        availabilitySampledPerBookingMinimums: perBookingMinSelection.sampled,
        availabilitySampledPerBookingMaximums: perBookingMaxSelection.sampled,
        availabilityCapacityDisagreement:
          !rateCapacitySelection.uniform && rateCapacitySelection.sampled.length > 1,
        availabilityPerBookingMinDisagreement:
          !perBookingMinSelection.uniform && perBookingMinSelection.sampled.length > 1,
        availabilityPerBookingMaxDisagreement:
          !perBookingMaxSelection.uniform && perBookingMaxSelection.sampled.length > 1,
        availabilityCapacityMatchMethod: matchMethod
      };
    }

    const effectiveMax = Math.min(...candidates.map((candidate) => candidate.value));
    const winner = candidates.find((candidate) => candidate.value === effectiveMax);

    log("Capacity candidates for mapped customer type:", candidates);
    log("Selected effective max:", effectiveMax, "source:", winner?.source ?? null);

    return {
      effectiveMax,
      capacitySource: winner?.source ?? null,
      candidates,
      availabilityCustomerTypeCapacity: rateCapacitySelection.selected,
      availabilityPerBookingMinimum,
      availabilityPerBookingMaximum,
      availabilitySampledCapacities: rateCapacitySelection.sampled,
      availabilitySampledPerBookingMinimums: perBookingMinSelection.sampled,
      availabilitySampledPerBookingMaximums: perBookingMaxSelection.sampled,
      availabilityCapacityDisagreement:
        !rateCapacitySelection.uniform && rateCapacitySelection.sampled.length > 1,
      availabilityPerBookingMinDisagreement:
        !perBookingMinSelection.uniform && perBookingMinSelection.sampled.length > 1,
      availabilityPerBookingMaxDisagreement:
        !perBookingMaxSelection.uniform && perBookingMaxSelection.sampled.length > 1,
      availabilityCapacityMatchMethod: matchMethod
    };
  }

  async function resolveAvailabilityCapacity(
    company,
    itemId,
    directAvailabilityId,
    preCollected,
    options
  ) {
    const mappedPrototypes = options?.mappedPrototypes || [];
    const detailEndpoint = getAvailabilityDetailEndpoint(company, itemId, "{availabilityId}");
    const result = {
      availabilityCustomerCount: null,
      availabilityBookableCapacity: null,
      totalAvailabilityCapacity: null,
      selectedFallbackCapacity: null,
      capacitySampleWarning: null,
      samples: [],
      availabilityDetails: [],
      availabilityDetailFetchSummary: null,
      usedDirectAvailability: false,
      candidateCollectionEndpoint: null,
      availabilityDetailEndpoint: detailEndpoint,
      candidateAttemptLog: []
    };

    if (directAvailabilityId) {
      const availResult = await fetchAvailabilityDetail(company, itemId, directAvailabilityId);
      if (!availResult.ok) {
        return { ok: false, error: availResult.error, data: result };
      }

      const detail = extractAvailabilityCapacityDetails(availResult.availability);
      result.availabilityDetails = [detail];
      result.availabilityDetailFetchSummary = buildAvailabilityDetailFetchSummary(1, 1, null);
      log("Availability detail endpoint fetched:", getAvailabilityDetailEndpoint(company, itemId, directAvailabilityId));
      log("customer_type_rates found:", detail.customerTypeRates.length);

      const sample = buildCapacitySampleFromAvailability(directAvailabilityId, availResult.availability);
      result.samples = [sample];
      result.availabilityCustomerCount = sample.customerCount;
      result.availabilityBookableCapacity = sample.bookableCapacity;
      result.totalAvailabilityCapacity = sample.totalCapacity;
      result.selectedFallbackCapacity = sample.totalCapacity;
      result.usedDirectAvailability = true;
      result.candidateCollectionEndpoint = "direct-availability-id";
      result.availabilityDetailEndpoint = getAvailabilityDetailEndpoint(company, itemId, directAvailabilityId);

      return { ok: true, error: null, data: result };
    }

    const collection = preCollected ?? (await collectAvailabilityCandidates(company, itemId));
    result.candidateAttemptLog = collection.attemptLog;
    result.candidateCollectionEndpoint = collection.successfulEndpoint;
    log("Availability candidates collected:", collection.candidates.length);

    if (collection.failed || collection.candidates.length === 0) {
      return {
        ok: false,
        error: collection.error || "No availability candidates found via date endpoint",
        data: result
      };
    }

    const detailAttemptLog = [];
    const progressive = await fetchAvailabilityDetailsProgressively(
      company,
      itemId,
      collection.candidates,
      mappedPrototypes,
      detailAttemptLog
    );

    result.samples = progressive.samples;
    result.availabilityDetails = progressive.availabilityDetails;
    result.availabilityDetailFetchSummary = progressive.detailFetchSummary;
    if (detailAttemptLog.length > 0) {
      result.availabilityDetailEndpoint = detailAttemptLog
        .map((entry) => `${entry.availabilityId}: ${entry.url}`)
        .join(" | ");
    }

    if (progressive.detailFetchSummary?.message) {
      log("Availability detail fetch summary:", progressive.detailFetchSummary.message);
    }

    if (progressive.samples.length === 0) {
      return {
        ok: false,
        error: `Could not fetch any sampled availability details. Detail attempts: ${detailAttemptLog.map((entry) => `${entry.availabilityId} -> ${entry.error || "ok"}`).join(" | ")}`,
        data: result
      };
    }

    const analysis = analyzeCapacitySamples(progressive.samples);
    result.selectedFallbackCapacity = analysis.selectedFallbackCapacity;
    result.capacitySampleWarning = analysis.capacitySampleWarning;

    const primary = progressive.samples.find((sample) => sample.totalCapacity != null) || progressive.samples[0];
    result.availabilityCustomerCount = primary.customerCount;
    result.availabilityBookableCapacity = primary.bookableCapacity;
    result.totalAvailabilityCapacity = primary.totalCapacity;

    for (const sample of progressive.samples) {
      if (sample.sampleWarning) {
        log(`Sample warning for availability ${sample.availabilityId}:`, sample.sampleWarning);
      }
    }

    return { ok: true, error: null, data: result };
  }

  function extractNestedArray(data, pluralKey) {
    if (!data) return [];
    const container = data[pluralKey];
    if (Array.isArray(container)) return container;
    if (container && Array.isArray(container.items)) return container.items;
    if (Array.isArray(data)) return data;
    return [];
  }

  function isActiveRecord(record) {
    if (!record || typeof record !== "object") return false;
    if (record.is_inactive === true || record.isInactive === true) return false;
    if (record.is_active === false || record.isActive === false) return false;
    return true;
  }

  function getRequirementGroupPk(group) {
    return group?.pk ?? group?.requirement_group?.pk ?? null;
  }

  function getRequirementsFromGroup(group) {
    const reqs = group?.requirements;
    if (Array.isArray(reqs)) return reqs;
    if (reqs && Array.isArray(reqs.items)) return reqs.items;
    return [];
  }

  function normalizeResourceRequirementsList(resourceReqs) {
    if (Array.isArray(resourceReqs)) return resourceReqs;
    if (resourceReqs && Array.isArray(resourceReqs.items)) return resourceReqs.items;
    return [];
  }

  function hasEmbeddedResourceRequirements(requirement) {
    const resourceReqs = normalizeResourceRequirementsList(requirement?.resource_requirements);
    return resourceReqs.length > 0;
  }

  async function fetchRequirementGroups(company, itemId) {
    const url =
      `/api/v1/companies/${encodeURIComponent(company)}/items/${encodeURIComponent(itemId)}` +
      `/requirement-groups/?include-is-inactive=yes`;
    log("Fetching requirement groups:", url);
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, requirementGroups: [], error: result.error };
    }
    const requirementGroups = extractNestedArray(result.data, "requirement_groups");
    logRawShapeOnce("requirementGroups", "requirement groups", requirementGroups);
    log("Requirement groups found:", requirementGroups.length);
    return { ok: true, requirementGroups, error: null };
  }

  async function fetchResourceRequirements(company, requirementGroupPk, requirementPk) {
    const url =
      `/api/v1/companies/${encodeURIComponent(company)}/requirement-groups/` +
      `${encodeURIComponent(requirementGroupPk)}/requirements/${encodeURIComponent(requirementPk)}` +
      `/resource-requirements/`;
    log("Fetching resource requirements:", url);
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, resourceRequirements: [], error: result.error };
    }
    const resourceRequirements = extractNestedArray(result.data, "resource_requirements");
    logRawShapeOnce("resourceRequirements", "resource requirements", resourceRequirements);
    return { ok: true, resourceRequirements, error: null };
  }

  async function fetchCompanyResources(company) {
    const url = `/api/v1/companies/${encodeURIComponent(company)}/resources/?include-archived=yes`;
    log("Fetching company resources:", url);
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, resources: [], error: result.error };
    }
    const resources = extractNestedArray(result.data, "resources");
    logRawShapeOnce("resources", "company resources", resources);
    log("Company resources found:", resources.length);
    return { ok: true, resources, error: null };
  }

  function deriveResourceCapacity(requirementGroups, resourceRequirementsByKey, resources) {
    const resourceByPk = new Map();
    for (const resource of resources || []) {
      const pk = resource?.pk;
      if (pk !== null && pk !== undefined) {
        resourceByPk.set(String(pk), resource);
      }
    }

    const entries = [];
    const activeCapacities = [];
    const archivedCapacities = [];

    for (const group of requirementGroups || []) {
      if (!isActiveRecord(group)) continue;

      const groupPk = getRequirementGroupPk(group);
      const groupName = group?.name ?? group?.unicode ?? null;
      const usedForBookableCapacity =
        group?.is_used_for_bookable_capacity ?? group?.isUsedForBookableCapacity ?? null;

      for (const requirement of getRequirementsFromGroup(group)) {
        if (!isActiveRecord(requirement)) continue;

        const requirementPk = requirement?.pk;
        const requirementType = requirement?.type ?? "unknown";
        const mapKey = `${groupPk}:${requirementPk}`;

        let resourceReqs = normalizeResourceRequirementsList(requirement?.resource_requirements);
        if (resourceReqs.length === 0 && resourceRequirementsByKey) {
          resourceReqs = resourceRequirementsByKey.get(mapKey) || [];
        }

        for (const rawResourceReq of resourceReqs) {
          const resourceRequirement = rawResourceReq?.resource_requirement ?? rawResourceReq;
          const useCount = toNumberOrNull(
            resourceRequirement?.use_count ?? resourceRequirement?.useCount
          );
          const resourceRef = resourceRequirement?.resource ?? {};
          const resourcePk =
            resourceRef?.pk ??
            resourceRequirement?.resource_pk ??
            resourceRequirement?.resourcePk ??
            null;
          const matchedResource =
            resourcePk !== null && resourcePk !== undefined
              ? resourceByPk.get(String(resourcePk))
              : null;
          const resourceMaximumUseCount = toNumberOrNull(
            matchedResource?.maximum_use_count ??
              matchedResource?.maximumUseCount ??
              resourceRef?.maximum_use_count ??
              resourceRef?.maximumUseCount
          );
          const isArchived = Boolean(
            matchedResource?.is_archived ?? matchedResource?.isArchived ?? false
          );

          const entry = {
            requirementGroupPk: groupPk,
            requirementGroupName: groupName,
            usedForBookableCapacity,
            requirementPk,
            requirementType,
            resourcePk,
            resourceName: matchedResource?.name ?? resourceRef?.name ?? null,
            resourceMaximumUseCount,
            requirementUseCount: useCount,
            derivedResourceCapacity: null,
            isArchived
          };

          if (
            resourceMaximumUseCount !== null &&
            resourceMaximumUseCount > 0 &&
            useCount !== null &&
            useCount > 0
          ) {
            entry.derivedResourceCapacity = Math.floor(resourceMaximumUseCount / useCount);
            if (!isArchived) {
              activeCapacities.push(entry.derivedResourceCapacity);
            } else {
              archivedCapacities.push(entry.derivedResourceCapacity);
            }
          }

          entries.push(entry);
        }
      }
    }

    let selectedCapacity = null;
    if (activeCapacities.length > 0) {
      selectedCapacity = Math.min(...activeCapacities);
    } else if (archivedCapacities.length > 0) {
      selectedCapacity = Math.min(...archivedCapacities);
    }

    const matchedResources = entries.filter((entry) => entry.resourcePk != null);
    log("Matched resources for capacity derivation:", matchedResources.length);
    if (selectedCapacity !== null) {
      log("Selected resource-derived capacity:", selectedCapacity);
    }

    return { entries, selectedCapacity };
  }

  async function resolveResourceCapacity(company, itemId, preFetched) {
    const groupsResult =
      preFetched?.requirementGroupsResult ??
      (await fetchRequirementGroups(company, itemId));
    const resourcesResult =
      preFetched?.resourcesResult ?? (await fetchCompanyResources(company));

    const result = {
      entries: [],
      selectedCapacity: null,
      requirementGroupsCount: 0,
      resourceRequirementsFetchCount: 0,
      resourcesCount: 0,
      errors: []
    };

    if (!groupsResult.ok) {
      result.errors.push(`Requirement groups fetch failed: ${groupsResult.error}`);
      return result;
    }
    if (!resourcesResult.ok) {
      result.errors.push(`Company resources fetch failed: ${resourcesResult.error}`);
      return result;
    }

    const requirementGroups = groupsResult.requirementGroups || [];
    const resources = resourcesResult.resources || [];
    result.requirementGroupsCount = requirementGroups.length;
    result.resourcesCount = resources.length;

    const fetchTasks = [];
    for (const group of requirementGroups) {
      if (!isActiveRecord(group)) continue;
      const groupPk = getRequirementGroupPk(group);
      if (groupPk === null || groupPk === undefined) continue;

      for (const requirement of getRequirementsFromGroup(group)) {
        if (!isActiveRecord(requirement)) continue;
        const requirementPk = requirement?.pk;
        if (requirementPk === null || requirementPk === undefined) continue;
        if (hasEmbeddedResourceRequirements(requirement)) continue;
        fetchTasks.push({ groupPk, requirementPk });
      }
    }

    const resourceRequirementsByKey = new Map();
    if (fetchTasks.length > 0) {
      const fetchResults = await runWithConcurrencyLimit(
        fetchTasks,
        CONCURRENCY_LIMIT,
        async (task) => {
          const resourceReqResult = await fetchResourceRequirements(
            company,
            task.groupPk,
            task.requirementPk
          );
          return { task, resourceReqResult };
        }
      );

      for (const { task, resourceReqResult } of fetchResults) {
        result.resourceRequirementsFetchCount += 1;
        if (!resourceReqResult.ok) {
          warn(
            `Resource requirements fetch failed for group ${task.groupPk} requirement ${task.requirementPk}:`,
            resourceReqResult.error
          );
          continue;
        }
        const mapKey = `${task.groupPk}:${task.requirementPk}`;
        resourceRequirementsByKey.set(mapKey, resourceReqResult.resourceRequirements || []);
        log(
          `Resource requirements found for group ${task.groupPk} requirement ${task.requirementPk}:`,
          (resourceReqResult.resourceRequirements || []).length
        );
      }
    }

    const derived = deriveResourceCapacity(
      requirementGroups,
      resourceRequirementsByKey,
      resources
    );
    result.entries = derived.entries;
    result.selectedCapacity = derived.selectedCapacity;
    return result;
  }

  async function fetchCustomerPrototypes(company, itemId) {
    const url =
      `/api/v1/companies/${encodeURIComponent(company)}/items/${encodeURIComponent(itemId)}` +
      `/customer-prototypes/?include-is-inactive=yes`;
    log("Fetching customer prototypes:", url);
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, prototypes: null, error: result.error };
    }
    const prototypes = result.data?.customer_prototypes ?? result.data?.customerPrototypes;
    logRawShapeOnce("prototypes", "customer prototypes", prototypes);
    if (!Array.isArray(prototypes)) {
      return { ok: false, prototypes: null, error: "Response missing customer_prototypes array" };
    }
    return { ok: true, prototypes, error: null };
  }

  function getAffiliateCompanyFields(affiliate) {
    const ac = affiliate?.affiliate_company ?? affiliate?.affiliateCompany ?? {};
    return {
      name: typeof ac.name === "string" ? ac.name.trim() : null,
      shortname: typeof ac.shortname === "string" ? ac.shortname.trim() : null,
      unicode: typeof ac.unicode === "string" ? ac.unicode.trim() : null
    };
  }

  function normalizeAffiliateNameForMatch(name) {
    return String(name ?? "")
      .toLowerCase()
      .replace(/[\s\-_]/g, "");
  }

  function isGetYourGuideAffiliate(affiliate) {
    const ac = getAffiliateCompanyFields(affiliate);
    const shortname = String(ac.shortname ?? "").toLowerCase();
    const name = String(ac.name ?? "");
    const normalizedName = normalizeAffiliateNameForMatch(name);
    const unicode = String(ac.unicode ?? "");
    return (
      shortname.includes("getyourguide") ||
      name === "GetYourGuide" ||
      name.includes("GetYourGuide") ||
      normalizedName.includes("getyourguide") ||
      unicode.includes("GetYourGuide")
    );
  }

  async function fetchAllNetworkAffiliates(company) {
    try {
      const allResults = [];
      let page = 1;
      let totalPages = 1;

      while (page <= totalPages) {
        const url =
          `/api-affiliations-v2/companies/${encodeURIComponent(company)}/affiliates/` +
          `?page=${page}&page_size=50`;
        log("Fetching affiliates page:", page, url);
        const result = await apiGetJson(url);
        if (!result.ok) {
          return { ok: false, affiliates: null, error: result.error };
        }

        const data = result.data;
        if (!data || typeof data !== "object") {
          return { ok: false, affiliates: null, error: "Affiliates API response is not a valid object" };
        }

        if (page === 1) {
          const reportedTotalPages = Number(data.total_pages);
          totalPages =
            Number.isFinite(reportedTotalPages) && reportedTotalPages >= 1 ? reportedTotalPages : 1;
        }

        const pageResults = data.results;
        if (!Array.isArray(pageResults)) {
          return { ok: false, affiliates: null, error: "Affiliates API response missing results array" };
        }
        allResults.push(...pageResults);
        page += 1;
      }

      return { ok: true, affiliates: allResults, error: null };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      return { ok: false, affiliates: null, error: message };
    }
  }

  async function fetchAffiliateDetail(company, affiliationPk) {
    const url = `/api/v1/companies/${encodeURIComponent(company)}/affiliates/${encodeURIComponent(affiliationPk)}/`;
    log("Fetching affiliate detail:", url);
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, detail: null, error: result.error };
    }
    const detail = result.data?.affiliation ?? null;
    logRawShapeOnce("affiliation", "affiliate detail", detail);
    if (!detail || typeof detail !== "object") {
      return { ok: false, detail: null, error: "Affiliate detail response missing affiliation object" };
    }
    return { ok: true, detail, error: null };
  }

  function getPricingObjectPk(pricingObject) {
    if (!pricingObject || typeof pricingObject !== "object") return null;
    if (pricingObject.pk !== null && pricingObject.pk !== undefined) {
      return pricingObject.pk;
    }
    const uri = String(pricingObject.uri ?? "");
    const sheetMatch = uri.match(/total-sheets\/(\d+)/i);
    if (sheetMatch) return sheetMatch[1];
    const scheduleMatch = uri.match(/total-schedules\/(\d+)/i);
    if (scheduleMatch) return scheduleMatch[1];
    return null;
  }

  function getPricingObjectType(pricingObject) {
    if (!pricingObject || typeof pricingObject !== "object") return null;
    const cls = String(pricingObject.cls ?? "").trim();
    if (cls === "TotalSheet" || cls === "total_sheet" || cls === "Total Sheet") {
      return "sheet";
    }
    if (cls === "TotalSchedule" || cls === "total_schedule" || cls === "Total Schedule") {
      return "schedule";
    }
    const uri = String(pricingObject.uri ?? "");
    if (uri.includes("/total-sheets/")) return "sheet";
    if (uri.includes("/total-schedules/")) return "schedule";
    return null;
  }

  function getPricingObjectDisplayName(pricingObject) {
    if (!pricingObject) return "unknown";
    return (
      pricingObject.display_name ??
      pricingObject.displayName ??
      pricingObject.name ??
      pricingObject.unicode ??
      (getPricingObjectPk(pricingObject) != null
        ? `${getPricingObjectType(pricingObject) === "schedule" ? "Schedule" : "Sheet"} ${getPricingObjectPk(pricingObject)}`
        : "unknown")
    );
  }

  function isAssignedPricingObject(pricingObject) {
    if (!pricingObject || typeof pricingObject !== "object") return false;
    return getPricingObjectPk(pricingObject) != null || Boolean(pricingObject.uri);
  }

  function resolveAssignedPricing(affiliateListRow, affiliationDetail) {
    const candidates = [
      {
        source: "totalPricingObject",
        obj: affiliateListRow?.totalPricingObject ?? affiliateListRow?.total_pricing_object ?? null
      },
      {
        source: "default_total_sheet",
        obj: affiliationDetail?.default_total_sheet ?? affiliationDetail?.defaultTotalSheet ?? null
      },
      {
        source: "default_total_schedule",
        obj: affiliationDetail?.default_total_schedule ?? affiliationDetail?.defaultTotalSchedule ?? null
      }
    ];

    for (const candidate of candidates) {
      if (!isAssignedPricingObject(candidate.obj)) continue;
      const type = getPricingObjectType(candidate.obj);
      const pk = getPricingObjectPk(candidate.obj);
      return {
        pricingObject: candidate.obj,
        type,
        pk,
        source: candidate.source,
        displayName: getPricingObjectDisplayName(candidate.obj)
      };
    }

    return null;
  }

  async function findGetYourGuideAffiliation(company) {
    const listResult = await fetchAllNetworkAffiliates(company);
    if (!listResult.ok) {
      return {
        ok: false,
        affiliation: null,
        affiliateListRow: null,
        assignedPricing: null,
        debug: null,
        error: listResult.error
      };
    }

    const affiliateListRow = (listResult.affiliates || []).find(isGetYourGuideAffiliate);
    if (!affiliateListRow) {
      return {
        ok: false,
        affiliation: null,
        affiliateListRow: null,
        assignedPricing: null,
        debug: null,
        error: "No GetYourGuide affiliation found"
      };
    }

    const affiliationPk = affiliateListRow?.pk ?? null;
    const affiliateCompany = getAffiliateCompanyFields(affiliateListRow);
    const debug = {
      affiliationPk,
      affiliateCompanyName: affiliateCompany.name,
      affiliateCompanyShortname: affiliateCompany.shortname,
      assignedTotalSheetPk: null,
      assignedTotalSheetName: null,
      assignedTotalSheetUnicode: null,
      assignedTotalSchedulePk: null,
      assignedTotalScheduleName: null,
      assignedPricingSource: null,
      noPricingReason: null
    };

    if (affiliationPk === null || affiliationPk === undefined) {
      debug.noPricingReason = "GetYourGuide affiliation list row is missing pk";
      return {
        ok: false,
        affiliation: null,
        affiliateListRow,
        assignedPricing: null,
        debug,
        error: debug.noPricingReason
      };
    }

    const detailResult = await fetchAffiliateDetail(company, affiliationPk);
    if (!detailResult.ok) {
      debug.noPricingReason = `Affiliate detail fetch failed: ${detailResult.error}`;
      return {
        ok: false,
        affiliation: null,
        affiliateListRow,
        assignedPricing: null,
        debug,
        error: detailResult.error
      };
    }

    const assignedPricing = resolveAssignedPricing(affiliateListRow, detailResult.detail);
    log("Resolved assigned pricing:", assignedPricing);

    if (assignedPricing) {
      debug.assignedPricingSource = assignedPricing.source;
      if (assignedPricing.type === "sheet") {
        debug.assignedTotalSheetPk = assignedPricing.pk;
        debug.assignedTotalSheetName = assignedPricing.pricingObject?.name ?? null;
        debug.assignedTotalSheetUnicode =
          assignedPricing.pricingObject?.unicode ??
          assignedPricing.pricingObject?.display_name ??
          assignedPricing.pricingObject?.displayName ??
          null;
      } else if (assignedPricing.type === "schedule") {
        debug.assignedTotalSchedulePk = assignedPricing.pk;
        debug.assignedTotalScheduleName = assignedPricing.displayName;
      } else if (assignedPricing.pk != null) {
        debug.assignedTotalSheetPk = assignedPricing.pk;
        debug.assignedTotalSheetName = assignedPricing.displayName;
      }
    } else {
      debug.noPricingReason = "GetYourGuide affiliation found but no assigned total sheet, schedule, or pricing object";
    }

    return {
      ok: true,
      affiliation: detailResult.detail,
      affiliateListRow,
      assignedPricing,
      debug,
      error: null
    };
  }

  async function fetchPricingForEditing(company, totalSheetPk, itemId) {
    const url =
      `/api/v1/companies/${encodeURIComponent(company)}/total-sheets/${encodeURIComponent(totalSheetPk)}` +
      `/pricing-for-editing/Item/${encodeURIComponent(itemId)}/`;
    log("Fetching pricing for editing:", url);
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, pricing: null, error: result.error };
    }
    logRawShapeOnce("pricing", "pricing data", result.data);
    return { ok: true, pricing: result.data, error: null };
  }

  function getPrototypeCustomerType(prototype) {
    return prototype?.customer_type ?? prototype?.customerType ?? {};
  }

  function normalizeName(value) {
    if (typeof value !== "string") return null;
    const trimmed = value.trim();
    return trimmed !== "" ? trimmed : null;
  }

  function findPrototypeByMappedName(prototypes, displayName) {
    const target = normalizeName(displayName);
    if (!target) return null;

    for (const prototype of prototypes || []) {
      const candidates = [prototype?.display_name, prototype?.displayName, prototype?.name];
      for (const candidate of candidates) {
        if (normalizeName(candidate) === target) {
          return prototype;
        }
      }
    }
    return null;
  }

  const RESELLER_CHANNEL_ITEM_PATH_RE = /\/integrations\/channels\/(\d+)\/items\/(\d+)/;
  const LEGACY_RESELLER_ITEM_PATH_RE = /\/reseller-companies\/(\d+)\/reseller-items\/(\d+)/;

  function parseCompanyShortnameFromPathname(pathname) {
    const parts = String(pathname || "").split("/").filter(Boolean);
    return parts[0] || null;
  }

  function matchResellerIdsFromText(text) {
    if (!text) return null;
    const value = String(text);
    const channelMatch = value.match(RESELLER_CHANNEL_ITEM_PATH_RE);
    if (channelMatch) {
      return {
        resellerCompanyId: channelMatch[1],
        resellerItemId: channelMatch[2]
      };
    }
    const legacyMatch = value.match(LEGACY_RESELLER_ITEM_PATH_RE);
    if (legacyMatch) {
      return {
        resellerCompanyId: legacyMatch[1],
        resellerItemId: legacyMatch[2]
      };
    }
    return null;
  }

  function parseResellerItemContextFromUrl(url) {
    const raw = String(url || "").trim();
    if (!raw) return null;

    let pathname = raw;
    try {
      if (/^https?:\/\//i.test(raw)) {
        pathname = new URL(raw).pathname;
      } else {
        pathname = raw.split("?")[0].split("#")[0];
      }
    } catch {
      pathname = raw.split("?")[0].split("#")[0];
    }

    const ids = matchResellerIdsFromText(pathname);
    if (!ids) return null;

    return {
      company: parseCompanyShortnameFromPathname(pathname),
      resellerCompanyId: ids.resellerCompanyId,
      resellerItemId: ids.resellerItemId
    };
  }

  function parseResellerIdsFromPath(pathname) {
    const ids = matchResellerIdsFromText(pathname);
    if (!ids) return null;
    return ids;
  }

  function extractResellerContextFromScrapedRows(scrapedRows) {
    for (const row of scrapedRows || []) {
      if (row?.resellerCompanyId != null && row?.resellerItemId != null) {
        return {
          company: row.company || null,
          resellerCompanyId: String(row.resellerCompanyId),
          resellerItemId: String(row.resellerItemId),
          resellerItemUrl: row.resellerItemUrl || null,
          enrichmentPageUrl: row.enrichmentPageUrl || row.resellerItemUrl || null
        };
      }

      const candidates = [
        row?.enrichmentPageUrl,
        row?.resellerItemUrl,
        row?.itemLabelHTML,
        row?.itemHref,
        row?.href,
        row?.pageUrl
      ];
      for (const candidate of candidates) {
        if (!candidate) continue;
        const candidateText = String(candidate);
        const looksLikeUrl =
          /^https?:\/\//i.test(candidateText) || candidateText.startsWith("/");
        if (looksLikeUrl) {
          const parsed = parseResellerItemContextFromUrl(candidateText);
          if (parsed?.resellerCompanyId && parsed?.resellerItemId) {
            return {
              company: parsed.company,
              resellerCompanyId: parsed.resellerCompanyId,
              resellerItemId: parsed.resellerItemId,
              resellerItemUrl: candidateText,
              enrichmentPageUrl: candidateText
            };
          }
        }
        const match = matchResellerIdsFromText(candidateText);
        if (match) {
          const parsedCompany = looksLikeUrl
            ? parseResellerItemContextFromUrl(candidateText)?.company
            : null;
          return {
            company: parsedCompany || null,
            resellerCompanyId: match.resellerCompanyId,
            resellerItemId: match.resellerItemId,
            resellerItemUrl: looksLikeUrl ? candidateText : null,
            enrichmentPageUrl: looksLikeUrl ? candidateText : null
          };
        }
      }
    }
    return null;
  }

  function isGygResellerCompanyValue(value) {
    const normalized = normalizeName(value);
    if (!normalized) return false;
    if (normalized === "getyourguide" || normalized === "gyg") return true;
    return normalized.includes("getyourguide");
  }

  function isGygResellerCompany(resellerCompany) {
    const candidates = [
      resellerCompany?.ota_type,
      resellerCompany?.otaType,
      resellerCompany?.name,
      resellerCompany?.short_name,
      resellerCompany?.shortName,
      resellerCompany?.external_identifier,
      resellerCompany?.externalIdentifier
    ];
    return candidates.some((value) => isGygResellerCompanyValue(value));
  }

  function filterGygResellerCompanies(companies) {
    return (companies || []).filter((company) => isGygResellerCompany(company));
  }

  function buildResellerItemApiBase(company, resellerCompanyId, resellerItemId) {
    return (
      `/api/v1/companies/${encodeURIComponent(company)}` +
      `/reseller-companies/${encodeURIComponent(resellerCompanyId)}` +
      `/reseller-items/${encodeURIComponent(resellerItemId)}`
    );
  }

  async function fetchResellerCompanies(company) {
    const url = `/api/v1/companies/${encodeURIComponent(company)}/reseller-companies/`;
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, companies: [], error: result.error };
    }
    const companies = result.data?.reseller_companies ?? result.data?.resellerCompanies ?? [];
    if (!Array.isArray(companies)) {
      return { ok: false, companies: [], error: "Response missing reseller_companies array" };
    }
    return { ok: true, companies, error: null };
  }

  async function fetchResellerItems(company, resellerCompanyId) {
    const url =
      `/api/v1/companies/${encodeURIComponent(company)}` +
      `/reseller-companies/${encodeURIComponent(resellerCompanyId)}/reseller-items/`;
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, items: [], error: result.error };
    }
    const items = result.data?.reseller_items ?? result.data?.resellerItems ?? [];
    if (!Array.isArray(items)) {
      return { ok: false, items: [], error: "Response missing reseller_items array" };
    }
    return { ok: true, items, error: null };
  }

  async function findGetYourGuideAffiliationCached(company, cache) {
    if (cache?.has(company)) {
      log("Affiliate cache hit for company:", company);
      return cache.get(company);
    }
    const result = await findGetYourGuideAffiliation(company);
    cache?.set(company, result);
    return result;
  }

  async function resolveResellerItemContext(company, itemId, scrapedRows, pageUrl) {
    const fromScraped = extractResellerContextFromScrapedRows(scrapedRows);
    if (fromScraped?.resellerCompanyId && fromScraped?.resellerItemId) {
      log("Enriching row with resellerItemId", fromScraped.resellerItemId);
      log("Parsed reseller context from scraped row:", fromScraped);
      return {
        ok: true,
        company: fromScraped.company || company,
        resellerCompanyId: fromScraped.resellerCompanyId,
        resellerItemId: fromScraped.resellerItemId,
        source: "row"
      };
    }

    const effectivePageUrl = pageUrl || window.location.href;
    log("Enrichment page URL:", effectivePageUrl);

    const fromUrl = parseResellerItemContextFromUrl(effectivePageUrl);
    if (fromUrl?.resellerCompanyId && fromUrl?.resellerItemId) {
      log("Enriching row with resellerItemId", fromUrl.resellerItemId);
      log("Parsed reseller context from page URL:", fromUrl);
      return {
        ok: true,
        company: fromUrl.company || company,
        resellerCompanyId: fromUrl.resellerCompanyId,
        resellerItemId: fromUrl.resellerItemId,
        source: "url"
      };
    }

    if (Array.isArray(scrapedRows) && scrapedRows.length > 0) {
      log(
        "Complete mapping row has no reseller item context; customer type mapping cannot be resolved"
      );
    }

    return { ok: false, error: "Could not resolve reseller item context" };
  }

  function extractRctExternalId(value) {
    if (value == null) return null;
    const text = String(value).trim();
    if (/^rct\S+/i.test(text)) return text;
    const match = text.match(/\brct\S+/i);
    return match ? match[0] : null;
  }

  function normalizeResellerExternalId(value) {
    const extracted = extractRctExternalId(value);
    return extracted ? extracted.toLowerCase() : null;
  }

  function getResellerCustomerTypeExternalId(resellerCustomerType) {
    if (!resellerCustomerType || typeof resellerCustomerType !== "object") return null;

    const scalarCandidates = [
      resellerCustomerType.external_identifier,
      resellerCustomerType.externalIdentifier,
      resellerCustomerType.unicode,
      resellerCustomerType.short_name,
      resellerCustomerType.shortName
    ];
    for (const candidate of scalarCandidates) {
      const extracted = extractRctExternalId(candidate);
      if (extracted) return extracted;
    }

    const collections = [
      resellerCustomerType.reseller_customer_types_external_identifiers,
      resellerCustomerType.resellerCustomerTypesExternalIdentifiers,
      resellerCustomerType.external_identifiers,
      resellerCustomerType.externalIdentifiers
    ];
    for (const collection of collections) {
      if (!Array.isArray(collection)) continue;
      for (const entry of collection) {
        const candidate =
          entry?.external_identifier ??
          entry?.externalIdentifier ??
          entry?.identifier ??
          entry?.value ??
          entry;
        const extracted = extractRctExternalId(candidate);
        if (extracted) return extracted;
      }
    }

    return null;
  }

  function getResellerCustomerTypeChannelName(resellerCustomerType) {
    if (!resellerCustomerType || typeof resellerCustomerType !== "object") return null;
    return (
      resellerCustomerType.name ??
      resellerCustomerType.display_name ??
      resellerCustomerType.displayName ??
      null
    );
  }

  function getFareHarborCustomerTypeNameFromMapping(mapping) {
    const prototype = mapping?.customer_prototype ?? mapping?.customerPrototype ?? {};
    const customerType = prototype?.customer_type ?? prototype?.customerType ?? {};
    return (
      prototype?.display_name ??
      prototype?.displayName ??
      prototype?.name ??
      customerType?.singular ??
      customerType?.name ??
      customerType?.display_name ??
      customerType?.displayName ??
      null
    );
  }

  function appendLookupEntry(map, key, value) {
    if (!key) return;
    if (!map.has(key)) {
      map.set(key, []);
    }
    map.get(key).push(value);
  }

  function buildResellerCustomerTypeLookup(entries) {
    const byExternalId = new Map();
    const byResellerCustomerTypePk = new Map();
    const byChannelName = new Map();
    const lookupKeys = [];

    for (const entry of entries || []) {
      const { resellerCustomerType, mapping } = entry;
      const prototype = mapping?.customer_prototype ?? mapping?.customerPrototype ?? {};
      const customerType = prototype?.customer_type ?? prototype?.customerType ?? {};
      const resolved = {
        customerPrototypePk: prototype?.pk ?? null,
        customerTypePk: customerType?.pk ?? null,
        fareHarborDisplayName: getFareHarborCustomerTypeNameFromMapping(mapping),
        resellerCustomerTypePk: resellerCustomerType?.pk ?? null,
        channelDisplayName: getResellerCustomerTypeChannelName(resellerCustomerType),
        externalId: getResellerCustomerTypeExternalId(resellerCustomerType)
      };

      if (resolved.externalId) {
        const key = normalizeResellerExternalId(resolved.externalId);
        if (key) {
          appendLookupEntry(byExternalId, key, resolved);
          lookupKeys.push(`externalId:${key}`);
        }
      }
      if (resolved.resellerCustomerTypePk != null) {
        appendLookupEntry(byResellerCustomerTypePk, String(resolved.resellerCustomerTypePk), resolved);
        lookupKeys.push(`resellerCustomerTypePk:${resolved.resellerCustomerTypePk}`);
      }
      const channelName = normalizeName(resolved.channelDisplayName);
      if (channelName) {
        appendLookupEntry(byChannelName, channelName, resolved);
        lookupKeys.push(`channelName:${channelName}`);
      }
    }

    log("Reseller customer type mapping lookup keys built:", lookupKeys);
    return { byExternalId, byResellerCustomerTypePk, byChannelName, entries: entries || [] };
  }

  async function fetchResellerCustomerTypeMappingsForItem(
    company,
    itemId,
    scrapedRows,
    pageUrl,
    mappingCache
  ) {
    const context = await resolveResellerItemContext(company, itemId, scrapedRows, pageUrl);
    if (!context.ok) {
      log(
        "Reseller customer type mapping unavailable; falling back to display-name matching:",
        context.error
      );
      return { ok: false, lookup: null, error: context.error, context: null };
    }

    const apiCompany = context.company || company;
    const cacheKey = `${apiCompany}:${context.resellerCompanyId}:${context.resellerItemId}`;
    if (mappingCache?.has(cacheKey)) {
      log("Reseller customer type mappings cache hit for resellerItemId", context.resellerItemId);
      return mappingCache.get(cacheKey);
    }

    log("Resolved reseller item context:", context);
    const base = buildResellerItemApiBase(
      apiCompany,
      context.resellerCompanyId,
      context.resellerItemId
    );
    const typesUrl = `${base}/reseller-customer-types/`;
    log("Reseller customer type mapping endpoint fetched:", typesUrl);
    const typesResult = await apiGetJson(typesUrl);
    if (!typesResult.ok) {
      log(
        "Reseller customer type mapping unavailable; falling back to display-name matching:",
        typesResult.error
      );
      const failure = { ok: false, lookup: null, error: typesResult.error, context };
      mappingCache?.set(cacheKey, failure);
      return failure;
    }

    const types =
      typesResult.data?.reseller_customer_types ?? typesResult.data?.resellerCustomerTypes ?? [];
    if (!Array.isArray(types)) {
      const failure = {
        ok: false,
        lookup: null,
        error: "Response missing reseller_customer_types array",
        context
      };
      mappingCache?.set(cacheKey, failure);
      return failure;
    }

    log("Reseller customer type mappings fetched for resellerItemId", context.resellerItemId, types.length);

    const entries = [];
    await Promise.all(
      types.map(async (resellerCustomerType) => {
        const resellerCustomerTypeId = resellerCustomerType?.pk;
        if (resellerCustomerTypeId == null) return;
        const mappingUrl =
          `${base}/reseller-customer-types/${encodeURIComponent(resellerCustomerTypeId)}` +
          `/reseller-customer-type-mappings/`;
        const mappingResult = await apiGetJson(mappingUrl);
        log(
          `Reseller customer type mapping endpoint fetched for ${resellerCustomerTypeId}:`,
          mappingResult.ok ? "ok" : mappingResult.error
        );
        if (!mappingResult.ok) return;
        const mappings =
          mappingResult.data?.reseller_customer_type_mappings ??
          mappingResult.data?.resellerCustomerTypeMappings ??
          [];
        if (!Array.isArray(mappings) || mappings.length === 0) return;
        for (const mapping of mappings) {
          entries.push({
            resellerCustomerType,
            mapping
          });
        }
      })
    );

    const lookup = buildResellerCustomerTypeLookup(entries);
    const result = { ok: true, lookup, error: null, context, mappingCount: entries.length };
    mappingCache?.set(cacheKey, result);
    return result;
  }

  function findPrototypeByPk(prototypes, pk) {
    if (pk == null) return null;
    for (const prototype of prototypes || []) {
      if (identifiersMatch(prototype?.pk, pk)) return prototype;
    }
    return null;
  }

  function findPrototypeByCustomerTypePk(prototypes, customerTypePk) {
    if (customerTypePk == null) return null;
    for (const prototype of prototypes || []) {
      const customerType = getPrototypeCustomerType(prototype);
      if (identifiersMatch(customerType?.pk, customerTypePk)) return prototype;
    }
    return null;
  }

  function resolveMappingEntriesForChannelCustomerType(mapped, lookup) {
    if (!lookup) return [];

    const asList = (value) => (Array.isArray(value) ? value : value ? [value] : []);

    const externalKey = normalizeResellerExternalId(mapped?.externalId);
    if (externalKey && lookup.byExternalId.has(externalKey)) {
      return asList(lookup.byExternalId.get(externalKey));
    }
    if (mapped?.resellerCustomerTypePk != null) {
      const key = String(mapped.resellerCustomerTypePk);
      if (lookup.byResellerCustomerTypePk.has(key)) {
        return asList(lookup.byResellerCustomerTypePk.get(key));
      }
    }
    const channelName = normalizeName(mapped?.displayName);
    if (channelName && lookup.byChannelName.has(channelName)) {
      return asList(lookup.byChannelName.get(channelName));
    }
    return [];
  }

  function buildMappedCustomerTypeFromEntry(entry, prototypes) {
    if (!entry) return null;

    let prototype = null;
    if (entry.customerPrototypePk != null) {
      prototype = findPrototypeByPk(prototypes, entry.customerPrototypePk);
    }
    if (!prototype && entry.customerTypePk != null) {
      prototype = findPrototypeByCustomerTypePk(prototypes, entry.customerTypePk);
    }

    const name =
      entry.fareHarborDisplayName ??
      prototype?.display_name ??
      prototype?.displayName ??
      prototype?.name ??
      null;

    return {
      name,
      customerPrototypePk: entry.customerPrototypePk ?? prototype?.pk ?? null,
      customerTypePk:
        entry.customerTypePk ?? getPrototypeCustomerType(prototype || {})?.pk ?? null,
      prototype,
      mappingEntry: entry,
      rawMin: prototype?.minimum_party_size ?? null,
      rawMax: prototype?.maximum_party_size ?? null,
      rawCapacity: prototype?.capacity ?? null
    };
  }

  function resolvePrototypeForChannelCustomerType(mapped, prototypes, lookup) {
    const result = {
      prototype: null,
      prototypes: [],
      mappedCustomerTypes: [],
      mappedFareHarborCustomerTypeName: null,
      mappedFareHarborCustomerTypeNames: [],
      mappingEntry: null,
      mappingEntries: [],
      resolutionMethod: null
    };

    const mappingEntries = resolveMappingEntriesForChannelCustomerType(mapped, lookup);
    let lookupMethod = null;

    if (mappingEntries.length > 0) {
      const externalKey = normalizeResellerExternalId(mapped?.externalId);
      if (externalKey && lookup.byExternalId.has(externalKey)) {
        lookupMethod = "reseller customer type external ID";
      } else if (mapped?.resellerCustomerTypePk != null) {
        lookupMethod = "reseller customer type ID";
      } else {
        lookupMethod = "reseller customer type name";
      }

      for (const entry of mappingEntries) {
        const built = buildMappedCustomerTypeFromEntry(entry, prototypes);
        if (built) {
          result.mappedCustomerTypes.push(built);
        }
      }

      result.mappingEntries = mappingEntries;
      result.mappingEntry = mappingEntries[0] ?? null;
      result.prototypes = result.mappedCustomerTypes
        .map((mappedType) => mappedType.prototype)
        .filter(Boolean);
      result.prototype = result.prototypes[0] ?? null;
      result.mappedFareHarborCustomerTypeNames = result.mappedCustomerTypes
        .map((mappedType) => mappedType.name)
        .filter(Boolean);
      result.mappedFareHarborCustomerTypeName = result.mappedFareHarborCustomerTypeNames[0] ?? null;

      if (result.prototypes.length > 0) {
        result.resolutionMethod = "reseller customer type mapping";
      } else if (lookupMethod) {
        result.resolutionMethod = `${lookupMethod} (prototype not found on item)`;
      }
    }

    if (result.mappedCustomerTypes.length === 0) {
      const prototype = findPrototypeByMappedName(prototypes, mapped?.displayName);
      if (prototype) {
        const built = {
          name:
            prototype?.display_name ??
            prototype?.displayName ??
            prototype?.name ??
            mapped?.displayName ??
            null,
          customerPrototypePk: prototype?.pk ?? null,
          customerTypePk: getPrototypeCustomerType(prototype)?.pk ?? null,
          prototype,
          mappingEntry: null,
          rawMin: prototype?.minimum_party_size ?? null,
          rawMax: prototype?.maximum_party_size ?? null,
          rawCapacity: prototype?.capacity ?? null
        };
        result.mappedCustomerTypes = [built];
        result.prototypes = [prototype];
        result.prototype = prototype;
        result.mappedFareHarborCustomerTypeNames = built.name ? [built.name] : [];
        result.mappedFareHarborCustomerTypeName = built.name;
        result.resolutionMethod = "customer type display name";
      }
    }

    return result;
  }

  function buildDisplayedPriceMatchMethod(typeReport) {
    const viaResellerMapping =
      typeReport?.prototypeResolutionMethod === "reseller customer type mapping";
    const base = typeReport?.priceMatchMethod;

    if (viaResellerMapping && base === "customer_prototype.pk via total schedule") {
      return "mapped reseller customer type -> customer prototype ID via total price schedule";
    }
    if (viaResellerMapping && base === "customer_prototype.pk") {
      return "mapped FareHarbor customer type via reseller customer type mapping";
    }
    return formatMatchMethodLabel(base);
  }

  function getEffectivePricings(pricingData) {
    const rows = pricingData?.effective_pricings ?? pricingData?.effectivePricings;
    return Array.isArray(rows) ? rows : [];
  }

  function getPricingRowPrototype(row) {
    return row?.customer_prototype ?? row?.customerPrototype ?? row?.for_object ?? row?.forObject ?? null;
  }

  function getPricingRowCustomerType(row) {
    return row?.customer_type ?? row?.customerType ?? getPrototypeCustomerType(getPricingRowPrototype(row) || {});
  }

  function identifiersMatch(a, b) {
    if (a === null || a === undefined || b === null || b === undefined) return false;
    return String(a) === String(b);
  }

  function urisMatch(a, b) {
    if (!a || !b) return false;
    return String(a) === String(b);
  }

  function getPricingRowMatchKey(row) {
    const rowProto = getPricingRowPrototype(row);
    if (rowProto?.pk != null) return `prototype:${rowProto.pk}`;
    if (rowProto?.uri) return `prototype-uri:${rowProto.uri}`;
    const rowType = getPricingRowCustomerType(row);
    if (rowType?.pk != null) return `type:${rowType.pk}`;
    if (rowType?.uri) return `type-uri:${rowType.uri}`;
    if (row?.pk != null) return `row:${row.pk}`;
    return null;
  }

  function matchPricingRow(prototype, pricingRows) {
    if (!prototype) {
      return { row: null, method: null };
    }

    const protoPk = prototype?.pk;
    const protoUri = prototype?.uri;
    const customerType = getPrototypeCustomerType(prototype);
    const typePk = customerType?.pk;
    const typeUri = customerType?.uri;
    const displayName = normalizeName(prototype?.display_name ?? prototype?.displayName ?? prototype?.name);
    const name = normalizeName(prototype?.name);

    for (const row of pricingRows) {
      const rowProto = getPricingRowPrototype(row);
      if (rowProto && identifiersMatch(rowProto.pk, protoPk)) {
        return { row, method: "customer_prototype.pk" };
      }
    }

    for (const row of pricingRows) {
      const rowProto = getPricingRowPrototype(row);
      if (rowProto && urisMatch(rowProto.uri, protoUri)) {
        return { row, method: "customer_prototype.uri" };
      }
    }

    for (const row of pricingRows) {
      const rowType = getPricingRowCustomerType(row);
      if (identifiersMatch(rowType?.pk, typePk)) {
        return { row, method: "customer_type.pk" };
      }
    }

    for (const row of pricingRows) {
      const rowType = getPricingRowCustomerType(row);
      if (urisMatch(rowType?.uri, typeUri)) {
        return { row, method: "customer_type.uri" };
      }
    }

    for (const row of pricingRows) {
      const rowProto = getPricingRowPrototype(row);
      const rowNames = [rowProto?.display_name, rowProto?.displayName, rowProto?.name];
      for (const rowName of rowNames) {
        const normalized = normalizeName(rowName);
        if (normalized && (normalized === displayName || normalized === name)) {
          return { row, method: "display_name/name" };
        }
      }
    }

    return { row: null, method: null };
  }

  function formatPriceAmount(value) {
    const num = toNumberOrNull(value);
    if (num === null) return null;
    return num.toFixed(2);
  }

  function extractBasePriceFromRow(row) {
    if (!row) return null;

    const price = row?.price ?? {};
    const modifierKind = price.modifier_kind ?? price.modifierKind ?? null;
    const offset = toNumberOrNull(row?.price_offset ?? row?.priceOffset ?? price?.offset);
    const rate = toNumberOrNull(row?.price_rate ?? row?.priceRate ?? price?.rate);

    if (modifierKind === "offset" && offset !== null) {
      return offset / 100;
    }
    if (offset !== null && offset !== 0) {
      return offset / 100;
    }
    if (rate !== null && rate !== 0) {
      return rate;
    }
    if (offset === 0) {
      return 0;
    }
    return null;
  }

  function formatPriceFromRow(row) {
    return formatPriceAmount(extractBasePriceFromRow(row));
  }

  function getPriceTaxInclusion(row) {
    const price = row?.price ?? {};
    return price.tax_inclusion ?? price.taxInclusion ?? row?.tax_inclusion ?? row?.taxInclusion ?? null;
  }

  function taxesAreIncluded(taxInclusion) {
    if (!taxInclusion) return false;
    const normalized = String(taxInclusion).toLowerCase().trim();
    if (normalized === "not-included" || normalized === "not_included") return false;
    if (normalized === "included" || normalized.includes("included")) return true;
    return false;
  }

  function normalizePercentageTaxRate(rate) {
    const num = toNumberOrNull(rate);
    if (num === null) return null;
    if (num > 0 && num < 1) return num;
    if (num > 1) return num / 100;
    return null;
  }

  function sumTaxRatesFromRow(row) {
    const taxes = row?.taxes ?? {};
    const ratesByType = taxes.ratesByType ?? taxes.rates_by_type ?? {};
    let totalRate = 0;

    for (const rawRate of Object.values(ratesByType)) {
      const normalizedRate = normalizePercentageTaxRate(rawRate);
      if (normalizedRate !== null) {
        totalRate += normalizedRate;
      }
    }

    return totalRate;
  }

  function sumTaxOffsetsFromRow(row) {
    const taxes = row?.taxes ?? {};
    const offsetsByType = taxes.offsetsByType ?? taxes.offsets_by_type ?? {};
    let totalOffset = 0;

    for (const rawOffset of Object.values(offsetsByType)) {
      const num = toNumberOrNull(rawOffset);
      if (num !== null) {
        totalOffset += num / 100;
      }
    }

    return totalOffset;
  }

  function hasTaxData(row) {
    const taxes = row?.taxes ?? {};
    const ratesByType = taxes.ratesByType ?? taxes.rates_by_type ?? {};
    const offsetsByType = taxes.offsetsByType ?? taxes.offsets_by_type ?? {};
    return Object.keys(ratesByType).length > 0 || Object.keys(offsetsByType).length > 0;
  }

  function calculateGetYourGuideFinalPrice(row) {
    const base = extractBasePriceFromRow(row);
    if (base === null) {
      return {
        basePrice: null,
        finalPrice: null,
        taxRateUsed: null,
        taxOffsetUsed: null,
        calculationPath: "base price missing or invalid",
        calculationNote: null,
        warning: "Could not extract base price from effective_pricing row"
      };
    }

    const baseFormatted = formatPriceAmount(base);
    const taxInclusion = getPriceTaxInclusion(row);

    if (taxesAreIncluded(taxInclusion)) {
      return {
        basePrice: baseFormatted,
        finalPrice: baseFormatted,
        taxRateUsed: null,
        taxOffsetUsed: null,
        calculationPath: `base=${baseFormatted}`,
        calculationNote: `tax_inclusion=${taxInclusion}; taxes already included in base price`,
        warning: null
      };
    }

    const taxRateUsed = sumTaxRatesFromRow(row);
    const taxOffsetUsed = sumTaxOffsetsFromRow(row);

    if (taxRateUsed <= 0 && taxOffsetUsed <= 0) {
      return {
        basePrice: baseFormatted,
        finalPrice: baseFormatted,
        taxRateUsed: null,
        taxOffsetUsed: null,
        calculationPath: `base=${baseFormatted}`,
        calculationNote: null,
        warning: hasTaxData(row)
          ? "Tax data present but no usable rates/offsets found; using base price"
          : "Tax data missing; using base price"
      };
    }

    const pathParts = [`base=${baseFormatted}`];
    let amount = base;

    if (taxRateUsed > 0) {
      amount = base * (1 + taxRateUsed);
      pathParts.push(`* (1 + ${taxRateUsed})`);
    }
    if (taxOffsetUsed > 0) {
      amount += taxOffsetUsed;
      pathParts.push(`+ offset ${taxOffsetUsed}`);
    }

    return {
      basePrice: baseFormatted,
      finalPrice: formatPriceAmount(amount),
      taxRateUsed,
      taxOffsetUsed: taxOffsetUsed > 0 ? taxOffsetUsed : null,
      calculationPath: pathParts.join(" "),
      calculationNote:
        taxInclusion === null || taxInclusion === undefined
          ? null
          : `tax_inclusion=${taxInclusion}`,
      warning: null
    };
  }

  function calculateEffectiveMin(item, prototype) {
    return pickHighest(
      item?.minimum_initial_party_size,
      item?.minimum_subsequent_party_size,
      prototype?.minimum_party_size,
      prototype?.minimum_group_size
    );
  }

  function collectMappedCustomerTypes(scrapedRows, itemId) {
    const seen = new Set();
    const collected = [];

    for (const row of scrapedRows || []) {
      const rowItemId = row.itemId || extractIdNumberFromLabel(row.itemLabel);
      if (itemId && rowItemId && String(rowItemId) !== String(itemId)) {
        continue;
      }

      if (Array.isArray(row.mappedCustomerTypes) && row.mappedCustomerTypes.length > 0) {
        for (const mapped of row.mappedCustomerTypes) {
          const key = `${mapped.externalId || ""}::${mapped.displayName || ""}`;
          if (seen.has(key)) continue;
          seen.add(key);
          collected.push({
            displayName: mapped.displayName || "",
            externalId: mapped.externalId || ""
          });
        }
      } else if (row.customerType) {
        const names = String(row.customerType).split("\n").map((s) => s.trim()).filter(Boolean);
        for (const name of names) {
          const key = `::${name}`;
          if (seen.has(key)) continue;
          seen.add(key);
          collected.push({ displayName: name, externalId: "" });
        }
      }
    }

    return collected;
  }

  function formatStartAtForCapacitySample(startAt) {
    if (!startAt) return "unknown time";
    const date = new Date(startAt);
    if (!Number.isNaN(date.getTime())) {
      const y = date.getFullYear();
      const m = String(date.getMonth() + 1).padStart(2, "0");
      const d = String(date.getDate()).padStart(2, "0");
      const h = String(date.getHours()).padStart(2, "0");
      const min = String(date.getMinutes()).padStart(2, "0");
      return `${y}-${m}-${d} ${h}:${min}`;
    }

    const match = String(startAt).match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})/);
    if (match) {
      return `${match[1]} ${match[2]}`;
    }
    return String(startAt);
  }

  function buildCapacitySampleLines(report) {
    const sampleCount = report.sampledAvailabilityStartTimes?.length || 0;
    if (sampleCount === 0) return [];

    const lines = [];
    for (let index = 0; index < sampleCount; index += 1) {
      const startAt = formatStartAtForCapacitySample(report.sampledAvailabilityStartTimes[index]);
      const customerCount = formatUnknown(report.sampledCustomerCounts[index]);
      const bookableCapacity = formatUnknown(report.sampledBookableCapacities[index]);
      const totalCapacity = formatUnknown(report.sampledTotalCapacities[index]);
      lines.push(
        `- ${startAt}: total capacity ${totalCapacity} (customer_count ${customerCount} + bookable_capacity ${bookableCapacity})`
      );
    }
    return lines;
  }

  function isUserRelevantWarning(warning) {
    const text = String(warning || "");
    if (text.startsWith("Multiple capacities detected")) return true;
    if (text.startsWith("Availability capacity could not be determined")) return true;
    if (
      text.includes("No GetYourGuide total price sheet assigned") ||
      text.includes("no assigned total sheet, schedule, or pricing object")
    ) {
      return true;
    }
    if (text.startsWith("GetYourGuide price for") && text.includes("using base price")) return true;
    if (text.includes("has no matched pricing row")) return true;
    return false;
  }

  function normalizeWarningForDisplay(warning) {
    const text = String(warning || "");
    if (text.startsWith("Availability capacity could not be determined")) {
      return "Could not determine availability capacity.";
    }
    if (text.startsWith("GetYourGuide price for") && text.includes("using base price")) {
      return "Could not calculate final price, using base price.";
    }
    if (text.includes("no assigned total sheet, schedule, or pricing object")) {
      return "No GetYourGuide total price sheet assigned.";
    }
    return text;
  }

  function buildResourceCapacityLines(report) {
    const lines = [];
    const entries = report.resourceCapacityEntries || [];

    if (report.selectedResourceDerivedCapacity == null) {
      lines.push("No valid resource-derived capacity found. Using availability fallback if needed.");
      return lines;
    }

    for (const entry of entries) {
      if (entry.derivedResourceCapacity == null) continue;
      const groupNamePart = entry.requirementGroupName
        ? `${entry.requirementGroupName} (pk ${formatUnknown(entry.requirementGroupPk)}`
        : `pk ${formatUnknown(entry.requirementGroupPk)}`;
      lines.push(
        `- Requirement group: ${groupNamePart}, used for bookable capacity: ${formatUnknown(entry.usedForBookableCapacity)})`
      );
      lines.push(`- Requirement: ${formatUnknown(entry.requirementPk)} (${formatUnknown(entry.requirementType)})`);
      lines.push(
        `- Resource: ${formatUnknown(entry.resourceName)} (pk ${formatUnknown(entry.resourcePk)})`
      );
      lines.push(`- Resource maximum use count: ${formatUnknown(entry.resourceMaximumUseCount)}`);
      lines.push(`- Requirement use count: ${formatUnknown(entry.requirementUseCount)}`);
      lines.push(`- Derived resource capacity: ${formatUnknown(entry.derivedResourceCapacity)}`);
    }

    lines.push(`Selected resource-derived capacity: ${formatUnknown(report.selectedResourceDerivedCapacity)}`);
    return lines;
  }

  function buildAvailabilityDetailCapacityLines(report) {
    const lines = [];
    if (report.availabilityDetailFetchSummary?.message) {
      for (const line of String(report.availabilityDetailFetchSummary.message).split("\n")) {
        lines.push(line);
      }
      lines.push("");
    }

    const details = report.availabilityDetailCapacity || [];
    if (details.length === 0) {
      lines.push("- No availability detail capacity data found.");
      return lines;
    }
    for (const detail of details) {
      lines.push(
        `- Availability: ${formatStartAtForCapacitySample(detail.startAt)} (pk ${formatUnknown(detail.availabilityPk)})`
      );
      lines.push(`- Total availability capacity: ${formatUnknown(detail.capacity)}`);
      lines.push(`- Non-resource availability capacity: ${formatUnknown(detail.nonResourceBookableCapacity)}`);
      for (const rate of detail.customerTypeRates || []) {
        lines.push(
          `- Customer type rate: ${formatUnknown(rate.prototypeName)} / customer_prototype.pk ${formatUnknown(rate.prototypePk)}`
        );
        lines.push(`  - Customer type rate capacity: ${formatUnknown(rate.capacity)}`);
        lines.push(`  - Per-booking minimum: ${formatUnknown(rate.minimumPartySize)}`);
        lines.push(`  - Per-booking maximum: ${formatUnknown(rate.maximumPartySize)}`);
        lines.push(`  - Capacity remaining: ${formatUnknown(rate.capacityRemaining)}`);
      }
      lines.push("");
    }

    while (lines.length > 0 && lines[lines.length - 1] === "") {
      lines.pop();
    }
    return lines;
  }

  function buildCustomerTypeAvailabilityLines(typeReport) {
    const lines = [];
    lines.push(
      `availability customer type capacity: ${formatUnknown(typeReport.availabilityCustomerTypeCapacity)}`
    );
    lines.push(
      `availability per-booking minimum: ${formatUnknown(typeReport.availabilityPerBookingMinimum)}`
    );
    lines.push(
      `availability per-booking maximum: ${formatUnknown(typeReport.availabilityPerBookingMaximum)}`
    );
    if (typeReport.availabilityCapacityDisagreement) {
      lines.push(
        `availability sampled customer type capacities: ${formatList(typeReport.availabilitySampledCapacities)} (selected: ${formatUnknown(typeReport.availabilityCustomerTypeCapacity)})`
      );
    }
    if (typeReport.availabilityPerBookingMinDisagreement) {
      lines.push(
        `availability sampled per-booking minimums: ${formatList(typeReport.availabilitySampledPerBookingMinimums)} (selected: ${formatUnknown(typeReport.availabilityPerBookingMinimum)})`
      );
    }
    if (typeReport.availabilityPerBookingMaxDisagreement) {
      lines.push(
        `availability sampled per-booking maximums: ${formatList(typeReport.availabilitySampledPerBookingMaximums)} (selected: ${formatUnknown(typeReport.availabilityPerBookingMaximum)})`
      );
    }
    if (typeReport.availabilityCapacityMatchMethod) {
      lines.push(
        `availability capacity match method: ${typeReport.availabilityCapacityMatchMethod}`
      );
    }
    return lines;
  }

  function buildSchedulePricingExplanationLines(report) {
    const lines = [];
    const schedulePricing = report.schedulePricing;
    if (!schedulePricing) {
      return lines;
    }

    const scheduleName = schedulePricing.scheduleName || report.totalSheetName || "unknown";
    lines.push(`GetYourGuide pricing source: Total price schedule "${scheduleName}"`);

    const sheetResults = schedulePricing.sheetResults || [];
    if (sheetResults.length === 0) {
      lines.push("Price sheets checked: none (schedule sheets could not be read)");
      return lines;
    }

    lines.push("Price sheets checked:");
    const customerTypes = report.customerTypes || [];

    for (const sheet of sheetResults) {
      if (!sheet.ok) {
        lines.push(`- ${sheet.name}: pricing fetch failed (${sheet.error || "unknown error"})`);
        continue;
      }

      const parts = [];
      for (const typeReport of customerTypes) {
        const match = sheet.matchedByDisplayName?.[typeReport.displayName];
        if (match?.finalPrices?.length) {
          parts.push(
            `${typeReport.displayName} ${formatPriceRangeLabel(match.finalPrices, report.processorCurrency)}`
          );
        } else if (match?.finalPrice != null) {
          parts.push(
            `${typeReport.displayName} ${formatEnrichmentPriceDisplay(match.finalPrice, report.processorCurrency)}`
          );
        }
      }

      if (parts.length > 0) {
        lines.push(`- ${sheet.name}: ${parts.join(", ")}`);
      } else {
        lines.push(`- ${sheet.name}: no matched prices`);
      }
    }

    return lines;
  }

  function formatCapacitySourceLabel(source) {
    const labels = {
      "mapped customer type maximum": "mapped customer type maximum",
      "customer prototype maximum_party_size": "customer type maximum party size",
      "customer prototype maximum_group_size": "customer type maximum group size",
      "customer prototype capacity": "customer type capacity",
      "item maximum_initial_party_size": "item maximum with no existing bookings",
      "item maximum_subsequent_party_size": "item maximum with existing bookings",
      "resource requirement endpoint": "resource capacity",
      "availability customer_type_rates.capacity": "availability customer type capacity",
      "availability customer_type_rates.maximum_party_size": "availability per-booking maximum",
      "availability endpoint": "availability fallback capacity"
    };
    return labels[source] || source || "unknown";
  }

  function formatMatchMethodLabel(method) {
    if (!method) return "unknown";
    if (method === "customer_prototype.pk") return "customer prototype ID";
    if (method === "customer_prototype.uri") return "customer prototype URI";
    if (method === "customer_type.pk") return "customer type ID";
    if (method === "customer_type.uri") return "customer type URI";
    if (method === "customer_prototype.pk via total schedule") {
      return "customer prototype ID via total price schedule";
    }
    if (method === "display_name") return "customer type name";
    if (method === "name") return "customer type name";
    return String(method)
      .replace(/customer_prototype\.pk/g, "customer prototype ID")
      .replace(/customer_type\.pk/g, "customer type ID");
  }

  function formatProcessorCurrencyLabel(processorCurrency) {
    if (isBlankValue(processorCurrency)) return "unknown";
    const code = String(processorCurrency).toUpperCase();
    const names = {
      EUR: "Euro",
      USD: "US Dollar",
      GBP: "British Pound",
      AUD: "Australian Dollar",
      CAD: "Canadian Dollar",
      NZD: "New Zealand Dollar",
      CHF: "Swiss Franc",
      NOK: "Norwegian Krone",
      SEK: "Swedish Krona",
      DKK: "Danish Krone"
    };
    return names[code] ? `${code} / ${names[code]}` : code;
  }

  function formatItemLabelForExplanation(row, report) {
    const name =
      report?.itemName ||
      extractItemNameFromLabel(row?.itemLabel) ||
      extractItemNameFromLabel(row?.itemLabelHTML) ||
      "unknown";
    const itemId =
      row?.itemId || report?.itemId || extractIdNumberFromLabel(row?.itemLabel) || null;
    return itemId ? `${name} (ID: ${itemId})` : name;
  }

  function findAvailabilityRateForCustomerType(rates, typeReport) {
    if (!Array.isArray(rates) || !typeReport) return null;
    for (const rate of rates) {
      if (
        typeReport.prototypePk != null &&
        rate?.prototypePk != null &&
        String(rate.prototypePk) === String(typeReport.prototypePk)
      ) {
        return rate;
      }
    }
    const targetName = normalizeName(typeReport.displayName);
    if (!targetName) return null;
    for (const rate of rates) {
      if (normalizeName(rate?.prototypeName) === targetName) {
        return rate;
      }
    }
    return null;
  }

  function buildUserFriendlyCapacitySampleLines(report) {
    const sampleCount = report.sampledAvailabilityStartTimes?.length || 0;
    if (sampleCount === 0) return [];

    const lines = [];
    for (let index = 0; index < sampleCount; index += 1) {
      const startAt = formatStartAtForCapacitySample(report.sampledAvailabilityStartTimes[index]);
      const alreadyBooked = formatUnknown(report.sampledCustomerCounts[index]);
      const stillBookable = formatUnknown(report.sampledBookableCapacities[index]);
      const totalCapacity = formatUnknown(report.sampledTotalCapacities[index]);
      lines.push(
        `- ${startAt}: total capacity ${totalCapacity} (${alreadyBooked} already booked + ${stillBookable} still bookable)`
      );
    }
    return lines;
  }

  function buildUserFriendlyAvailabilityDetailFetchLines(summary) {
    if (!summary) return [];
    const lines = [];
    if (summary.fetchedCount > 0 && summary.totalSampled > 0) {
      lines.push(`Fetched ${summary.fetchedCount} of ${summary.totalSampled} sampled availability details.`);
    }
    if (summary.noteKey === "additional_fetched") {
      lines.push(
        "Additional details were fetched because per-customer-type capacity, minimum, or maximum values were found."
      );
    } else if (summary.noteKey === "skipped_no_useful_first") {
      lines.push(
        "Skipped the remaining details because the first matched availability did not contain per-customer-type capacity, minimum, or maximum values."
      );
    } else if (summary.noteKey === "skipped_after_retry") {
      lines.push(
        "Skipped the remaining details because no useful per-customer-type values were found after retrying a second sampled availability."
      );
    }
    return lines;
  }

  function buildUserFriendlyResourceCapacityLines(report) {
    const entries = (report.resourceCapacityEntries || []).filter(
      (entry) => entry.derivedResourceCapacity != null
    );
    if (entries.length === 0 && report.selectedResourceDerivedCapacity == null) {
      return [
        "No usable resource capacity was found. The extension will use availability limits if available."
      ];
    }

    const lines = ["The item uses these resources:"];
    for (const entry of entries) {
      lines.push(
        `- ${formatUnknown(entry.resourceName)}: ${formatUnknown(entry.derivedResourceCapacity)} spots available`
      );
      lines.push(`  - Resource maximum use count: ${formatUnknown(entry.resourceMaximumUseCount)}`);
      lines.push(`  - Requirement use count: ${formatUnknown(entry.requirementUseCount)}`);
      lines.push(`  - Derived capacity: ${formatUnknown(entry.derivedResourceCapacity)}`);
    }

    if (report.selectedResourceDerivedCapacity != null) {
      lines.push("");
      lines.push(`Selected resource capacity: ${formatUnknown(report.selectedResourceDerivedCapacity)}`);
      const restrictive = entries.filter(
        (entry) =>
          Number(entry.derivedResourceCapacity) === Number(report.selectedResourceDerivedCapacity)
      );
      if (restrictive.length === 1) {
        lines.push(`Reason: ${restrictive[0].resourceName || "A resource"} is the most restrictive resource.`);
      } else if (restrictive.length > 1) {
        const names = restrictive.map((entry) => entry.resourceName || "unknown").join(", ");
        lines.push(`Reason: ${names} tie as the most restrictive resources.`);
      }
    }

    return lines;
  }

  function buildUserFriendlyAvailabilityDetailLines(report) {
    const lines = [];
    const fetchLines = buildUserFriendlyAvailabilityDetailFetchLines(
      report.availabilityDetailFetchSummary
    );
    if (fetchLines.length > 0) {
      lines.push(...fetchLines);
      lines.push("");
    }

    const details = report.availabilityDetailCapacity || [];
    if (details.length === 0) {
      lines.push("No availability details were checked.");
      return lines;
    }

    lines.push("Checked availability:");
    for (let detailIndex = 0; detailIndex < details.length; detailIndex += 1) {
      const detail = details[detailIndex];
      if (detailIndex > 0) {
        lines.push("");
      }
      lines.push(
        `- ${formatStartAtForCapacitySample(detail.startAt)} (availability ID ${formatUnknown(detail.availabilityPk)})`
      );
      lines.push(`  - Total availability capacity: ${formatUnknown(detail.capacity)}`);
      lines.push(
        `  - Non-resource availability capacity: ${formatUnknown(detail.nonResourceBookableCapacity)}`
      );

      const customerTypes = report.customerTypes || [];
      if (customerTypes.length === 0) {
        for (const rate of detail.customerTypeRates || []) {
          lines.push(`  - ${formatUnknown(rate.prototypeName)}:`);
          lines.push(`    - Customer type capacity: ${formatUnknown(rate.capacity)}`);
          lines.push(`    - Per-booking minimum: ${formatUnknown(rate.minimumPartySize)}`);
          lines.push(`    - Per-booking maximum: ${formatUnknown(rate.maximumPartySize)}`);
          lines.push(`    - Capacity remaining: ${formatUnknown(rate.capacityRemaining)}`);
        }
      } else {
        for (const typeReport of customerTypes) {
          const rate = findAvailabilityRateForCustomerType(detail.customerTypeRates, typeReport);
          lines.push(`  - ${typeReport.displayName || "Unknown"}:`);
          lines.push(
            `    - Customer type capacity: ${formatUnknown(rate?.capacity)}`
          );
          lines.push(
            `    - Per-booking minimum: ${formatUnknown(rate?.minimumPartySize)}`
          );
          lines.push(
            `    - Per-booking maximum: ${formatUnknown(rate?.maximumPartySize)}`
          );
          lines.push(
            `    - Capacity remaining: ${formatUnknown(rate?.capacityRemaining)}`
          );
        }
      }
    }

    return lines;
  }

  function buildTechnicalIdsLines(report) {
    const lines = [];
    const seenGroups = new Set();
    const seenRequirements = new Set();
    const seenResources = new Set();

    for (const entry of report.resourceCapacityEntries || []) {
      if (entry.requirementGroupPk != null && !seenGroups.has(String(entry.requirementGroupPk))) {
        seenGroups.add(String(entry.requirementGroupPk));
        lines.push(
          `- Requirement group: ${formatUnknown(entry.requirementGroupName)}, ID ${formatUnknown(entry.requirementGroupPk)}, used for bookable capacity: ${formatUnknown(entry.usedForBookableCapacity)}`
        );
      }
      if (entry.requirementPk != null && !seenRequirements.has(String(entry.requirementPk))) {
        seenRequirements.add(String(entry.requirementPk));
        lines.push(
          `- Requirement: ${formatUnknown(entry.requirementPk)}, type ${formatUnknown(entry.requirementType)}`
        );
      }
      if (entry.resourcePk != null && !seenResources.has(String(entry.resourcePk))) {
        seenResources.add(String(entry.resourcePk));
        lines.push(
          `- Resource: ${formatUnknown(entry.resourceName)}, ID ${formatUnknown(entry.resourcePk)}`
        );
      }
    }

    const debug = report.affiliationDebug || {};
    if (debug.affiliationPk != null) {
      lines.push(`- GetYourGuide affiliation ID: ${formatUnknown(debug.affiliationPk)}`);
    }
    if (debug.assignedTotalSheetPk != null) {
      lines.push(`- Assigned total price sheet ID: ${formatUnknown(debug.assignedTotalSheetPk)}`);
    }
    if (debug.assignedTotalSchedulePk != null) {
      lines.push(`- Assigned total price schedule ID: ${formatUnknown(debug.assignedTotalSchedulePk)}`);
    }
    if (report.itemId != null) {
      lines.push(`- FareHarbor item ID: ${formatUnknown(report.itemId)}`);
    }

    return lines;
  }

  function buildCopiedRowSummaryLines(report, scrapedRowsForItem) {
    const lines = [];
    const rows = scrapedRowsForItem || [];
    const customerTypes = report.customerTypes || [];
    const { minLabel, maxLabel } = aggregateEnrichedMinMax(customerTypes);
    const processorCurrency = report.processorCurrency;

    if (rows.length <= 1) {
      const row = rows[0] || {};
      lines.push(`Item: ${formatItemLabelForExplanation(row, report)}`);
      lines.push(`GetYourGuide option ID: ${formatUnknown(row.channelOption)}`);
    } else {
      rows.forEach((row, index) => {
        lines.push(`Row ${index + 1}:`);
        lines.push(`- Item: ${formatItemLabelForExplanation(row, report)}`);
        lines.push(`- GetYourGuide option ID: ${formatUnknown(row.channelOption)}`);
      });
    }

    lines.push("");
    lines.push("Customer types copied:");
    if (customerTypes.length === 0) {
      lines.push("- unknown");
    } else {
      for (const typeReport of customerTypes) {
        const priceLabel = getEnrichmentPriceDisplay(typeReport, processorCurrency);
        lines.push(`- ${typeReport.displayName || "Unknown"}: ${priceLabel}`);
      }
    }

    lines.push("");
    lines.push("Displayed booking limits:");
    lines.push(`- Minimum: ${minLabel}`);
    lines.push(`- Maximum: ${maxLabel}`);
    return lines;
  }

  function buildMappedFareHarborCustomerTypeExplanationLines(typeReport) {
    const lines = [];
    const mappedTypes = typeReport.mappedCustomerTypes || [];

    if (mappedTypes.length > 1) {
      lines.push("- Mapped FareHarbor customer types:");
      for (const mappedType of mappedTypes) {
        lines.push(
          `  - ${formatUnknown(mappedType.name)} (min ${formatUnknown(mappedType.rawMin)}, max ${formatUnknown(mappedType.rawMax)})`
        );
      }
      lines.push("");
      lines.push(
        `- Mapped customer type range minimum: ${formatUnknown(typeReport.mappedCustomerTypeRangeMin)}`
      );
      lines.push(
        `- Mapped customer type range maximum: ${formatUnknown(typeReport.mappedCustomerTypeRangeMax)}`
      );
      return lines;
    }

    lines.push(
      `- Mapped FareHarbor customer type: ${formatUnknown(typeReport.mappedFareHarborCustomerTypeName)}`
    );
    lines.push(`- Customer prototype ID: ${formatUnknown(typeReport.prototypePk)}`);
    lines.push(`- Customer type ID: ${formatUnknown(typeReport.customerTypePk)}`);
    lines.push(`- Raw customer type minimum: ${formatUnknown(typeReport.rawMin)}`);
    lines.push(`- Raw customer type maximum: ${formatUnknown(typeReport.rawMax)}`);
    lines.push(`- Raw customer type capacity: ${formatUnknown(typeReport.rawCapacity)}`);
    return lines;
  }

  function formatEnrichmentExplanation(report, scrapedRowsForItem) {
    const lines = [];
    lines.push("=== GetYourGuide Mapping Explanation ===");
    lines.push("");
    lines.push("Copied row");
    lines.push("");
    lines.push(...buildCopiedRowSummaryLines(report, scrapedRowsForItem));
    lines.push("");
    lines.push("How the extension chose the booking limits");
    lines.push("The extension checks all available limits and uses the most restrictive valid value.");
    lines.push("");
    lines.push("Item-level booking limits");
    lines.push(`- Minimum with no existing bookings: ${formatUnknown(report.itemMinNoBookings)}`);
    lines.push(`- Minimum with existing bookings: ${formatUnknown(report.itemMinAlreadyBooked)}`);
    lines.push(`- Maximum with no existing bookings: ${formatUnknown(report.itemMaxNoBookings)}`);
    lines.push(`- Maximum with existing bookings: ${formatUnknown(report.itemMaxAlreadyBooked)}`);
    lines.push("");
    lines.push("Resource capacity");
    lines.push(...buildUserFriendlyResourceCapacityLines(report));
    lines.push("");
    lines.push("Availability check");
    lines.push("The extension checked upcoming availability to look for availability-specific limits.");
    lines.push("");
    const capacitySampleLines = buildUserFriendlyCapacitySampleLines(report);
    if (capacitySampleLines.length > 0) {
      lines.push("Availability capacity sample:");
      lines.push("");
      lines.push(...capacitySampleLines);
      lines.push("");
    }
    lines.push(
      `Selected availability fallback capacity: ${formatUnknown(report.selectedFallbackCapacity)}`
    );
    lines.push("");
    lines.push("Availability detail check:");
    lines.push("");
    lines.push(...buildUserFriendlyAvailabilityDetailLines(report));
    lines.push("");
    lines.push("Customer type results");
    lines.push("");

    for (const typeReport of report.customerTypes || []) {
      lines.push(typeReport.displayName || "Unknown");
      lines.push(`- GetYourGuide external ID: ${formatUnknown(typeReport.externalId)}`);
      if (typeReport.prototypeResolutionMethod) {
        lines.push(`- Customer type resolution: ${typeReport.prototypeResolutionMethod}`);
      }
      lines.push(...buildMappedFareHarborCustomerTypeExplanationLines(typeReport));
      lines.push(`- Effective minimum: ${formatUnknown(typeReport.effectiveMin)}`);
      lines.push(`- Effective maximum: ${formatUnknown(typeReport.effectiveMax)}`);
      if (typeReport.capacitySource) {
        lines.push(`- Maximum came from: ${formatCapacitySourceLabel(typeReport.capacitySource)}`);
      }
      lines.push(
        `- Availability customer type capacity: ${formatUnknown(typeReport.availabilityCustomerTypeCapacity)}`
      );
      lines.push(
        `- Availability per-booking minimum: ${formatUnknown(typeReport.availabilityPerBookingMinimum)}`
      );
      lines.push(
        `- Availability per-booking maximum: ${formatUnknown(typeReport.availabilityPerBookingMaximum)}`
      );
      if (typeReport.availabilityCapacityDisagreement) {
        lines.push(
          `- Availability sampled customer type capacities: ${formatList(typeReport.availabilitySampledCapacities)} (selected: ${formatUnknown(typeReport.availabilityCustomerTypeCapacity)})`
        );
      }
      if (typeReport.availabilityPerBookingMinDisagreement) {
        lines.push(
          `- Availability sampled per-booking minimums: ${formatList(typeReport.availabilitySampledPerBookingMinimums)} (selected: ${formatUnknown(typeReport.availabilityPerBookingMinimum)})`
        );
      }
      if (typeReport.availabilityPerBookingMaxDisagreement) {
        lines.push(
          `- Availability sampled per-booking maximums: ${formatList(typeReport.availabilitySampledPerBookingMaximums)} (selected: ${formatUnknown(typeReport.availabilityPerBookingMaximum)})`
        );
      }
      if (typeReport.availabilityCapacityMatchMethod) {
        lines.push(
          `- Availability match method: ${formatMatchMethodLabel(typeReport.availabilityCapacityMatchMethod)}`
        );
      }
      lines.push(
        `- GetYourGuide base price: ${getEnrichmentBasePriceDisplay(typeReport, report.processorCurrency)}`
      );
      lines.push(
        `- GetYourGuide final price${
          (typeReport.finalPricesPerSheet?.length || 0) > 1 ? "s" : ""
        }: ${getEnrichmentPriceDisplay(typeReport, report.processorCurrency)}`
      );
      lines.push(`- Price match method: ${buildDisplayedPriceMatchMethod(typeReport)}`);
      lines.push("");
    }

    lines.push("Pricing");
    if (report.pricingSourceType === "schedule") {
      lines.push(
        `GetYourGuide pricing source: Total price schedule "${formatUnknown(report.pricingScheduleName || report.totalSheetName)}"`
      );
      const schedulePricingLines = buildSchedulePricingExplanationLines(report);
      if (schedulePricingLines.length > 1) {
        lines.push(...schedulePricingLines.slice(1));
      } else if (schedulePricingLines.length === 1) {
        lines.push(...schedulePricingLines);
      }
    } else {
      lines.push(`GetYourGuide total price sheet: ${formatUnknown(report.totalSheetName)}`);
    }
    lines.push(`Currency: ${formatProcessorCurrencyLabel(report.processorCurrency)}`);
    lines.push("");

    const technicalLines = buildTechnicalIdsLines(report);
    if (technicalLines.length > 0) {
      lines.push("Technical IDs checked");
      lines.push(...technicalLines);
      lines.push("");
    }

    const userWarnings = (report.warnings || [])
      .filter(isUserRelevantWarning)
      .map(normalizeWarningForDisplay);
    if (userWarnings.length > 0) {
      lines.push("Notes and warnings");
      for (const warning of userWarnings) {
        lines.push(`- ${warning}`);
      }
    }

    return lines.join("\n").trimEnd();
  }

  function buildEnrichmentExplanation(reports, scrapedRows) {
    if (!Array.isArray(reports) || reports.length === 0) {
      return "";
    }

    const rowsByItemId = groupRowsByItemId(scrapedRows);
    const blocks = [];

    for (const report of reports) {
      const itemRows =
        (report.itemId != null ? rowsByItemId.get(String(report.itemId)) : null) || scrapedRows || [];
      blocks.push(formatEnrichmentExplanation(report, itemRows));
    }

    return blocks.join("\n\n");
  }

  function hasEnrichmentExplanationData(reports) {
    return (
      Array.isArray(reports) &&
      reports.length > 0 &&
      reports.some((report) => Array.isArray(report.customerTypes) && report.customerTypes.length > 0)
    );
  }

  function formatEnrichmentBlock(report) {
    const lines = [];
    lines.push("=== GetYourGuide Mapping Enrichment ===");
    lines.push("ITEM SUMMARY");
    lines.push(`Item ID: ${formatUnknown(report.itemId)}`);
    lines.push(`Item name: ${formatUnknown(report.itemName)}`);
    lines.push(`Item min (no bookings): ${formatUnknown(report.itemMinNoBookings)}`);
    lines.push(`Item min (already booked): ${formatUnknown(report.itemMinAlreadyBooked)}`);
    lines.push(`Item max (no bookings): ${formatUnknown(report.itemMaxNoBookings)}`);
    lines.push(`Item max (already booked): ${formatUnknown(report.itemMaxAlreadyBooked)}`);
    if (report.pricingSourceType === "schedule") {
      lines.push(
        `GetYourGuide pricing: Total price schedule "${formatUnknown(report.pricingScheduleName || report.totalSheetName)}"`
      );
    } else {
      lines.push(`GetYourGuide total sheet: ${formatUnknown(report.totalSheetName)}`);
    }
    const schedulePricingLines = buildSchedulePricingExplanationLines(report);
    if (schedulePricingLines.length > 0) {
      lines.push(...schedulePricingLines);
    }
    lines.push("");
    lines.push("RESOURCE CAPACITY");
    lines.push(...buildResourceCapacityLines(report));
    lines.push("");
    lines.push("AVAILABILITY CAPACITY SAMPLE");
    const capacitySampleLines = buildCapacitySampleLines(report);
    if (capacitySampleLines.length > 0) {
      lines.push(...capacitySampleLines);
    } else {
      lines.push("- unknown");
    }
    lines.push(
      `Selected availability fallback capacity: ${formatUnknown(report.selectedFallbackCapacity)}`
    );
    lines.push("");
    lines.push("AVAILABILITY DETAIL CAPACITY");
    lines.push(...buildAvailabilityDetailCapacityLines(report));
    lines.push("");
    lines.push("CUSTOMER TYPES");

    for (const typeReport of report.customerTypes) {
      lines.push(`--- ${typeReport.displayName || "Unknown"} ---`);
      lines.push(`GYG external ID: ${formatUnknown(typeReport.externalId)}`);
      if (typeReport.prototypeResolutionMethod) {
        lines.push(`Customer type resolution: ${typeReport.prototypeResolutionMethod}`);
      }
      const mappedTypes = typeReport.mappedCustomerTypes || [];
      if (mappedTypes.length > 1) {
        lines.push("Mapped FareHarbor customer types:");
        for (const mappedType of mappedTypes) {
          lines.push(
            `- ${formatUnknown(mappedType.name)} (min ${formatUnknown(mappedType.rawMin)}, max ${formatUnknown(mappedType.rawMax)})`
          );
        }
        lines.push(
          `Mapped customer type range min: ${formatUnknown(typeReport.mappedCustomerTypeRangeMin)}`
        );
        lines.push(
          `Mapped customer type range max: ${formatUnknown(typeReport.mappedCustomerTypeRangeMax)}`
        );
      } else {
        lines.push(
          `Mapped FareHarbor customer type: ${formatUnknown(typeReport.mappedFareHarborCustomerTypeName)}`
        );
        lines.push(`customer_prototype.pk: ${formatUnknown(typeReport.prototypePk)}`);
        lines.push(`customer_type.pk: ${formatUnknown(typeReport.customerTypePk)}`);
        lines.push(`raw customer type min: ${formatUnknown(typeReport.rawMin)}`);
        lines.push(`raw customer type max: ${formatUnknown(typeReport.rawMax)}`);
        lines.push(`raw customer type capacity: ${formatUnknown(typeReport.rawCapacity)}`);
      }
      lines.push(`effective min: ${formatUnknown(typeReport.effectiveMin)}`);
      lines.push(...buildCustomerTypeAvailabilityLines(typeReport));
      lines.push(`effective max: ${formatUnknown(typeReport.effectiveMax)}`);
      if (typeReport.capacitySource) {
        lines.push(`capacity source: ${typeReport.capacitySource}`);
      }
      lines.push(`GetYourGuide base price: ${getEnrichmentBasePriceDisplay(typeReport, report.processorCurrency)}`);
      lines.push(
        `GetYourGuide final price${
          (typeReport.finalPricesPerSheet?.length || 0) > 1 ? "s" : ""
        }: ${getEnrichmentPriceDisplay(typeReport, report.processorCurrency)}`
      );
      lines.push(`price match method: ${buildDisplayedPriceMatchMethod(typeReport)}`);
      lines.push("");
    }

    const userWarnings = (report.warnings || [])
      .filter(isUserRelevantWarning)
      .map(normalizeWarningForDisplay);

    if (userWarnings.length > 0) {
      lines.push("WARNINGS / DEBUG");
      for (const warning of userWarnings) {
        lines.push(`- ${warning}`);
      }
    }

    return lines.join("\n").trimEnd();
  }

  const GYG_ENRICHED_HTML_HEADER_ROW =
    "<tr>\n" +
    "      <th>External Product ID</th>\n" +
    "      <th>FareHarbor Name &amp; Item ID</th>\n" +
    "      <th>Ticket Category</th>\n" +
    "      <th>Min / Max</th>\n" +
    "    </tr>\n";

  function buildEnrichedCustomerTypeCell(enrichedCustomerTypes, processorCurrency) {
    const lines = [];

    for (const typeReport of enrichedCustomerTypes || []) {
      const name = escapeHtmlText(typeReport?.displayName || "Unknown");
      const price = getEnrichmentPriceDisplay(typeReport, processorCurrency);
      if (price !== "unknown") {
        lines.push(`<strong>${name}:</strong> ${escapeHtmlText(price)}`);
      } else {
        lines.push(`<strong>${name}:</strong>`);
      }
    }

    return lines.join("<br>");
  }

  function reportHasCompactHtmlEnrichment(report) {
    return Array.isArray(report?.customerTypes) && report.customerTypes.length > 0;
  }

  function canBuildEnrichedHtmlForData(scrapedRows, reports) {
    if (!Array.isArray(reports) || reports.length === 0) return false;
    if (!Array.isArray(scrapedRows) || scrapedRows.length === 0) return false;

    const reportsByItemId = new Map(
      reports.filter((report) => report?.itemId != null).map((report) => [String(report.itemId), report])
    );
    const itemIds = [
      ...new Set(
        scrapedRows.map((row) => row.itemId || extractIdNumberFromLabel(row.itemLabel)).filter(Boolean)
      )
    ];

    if (itemIds.length === 0) return false;
    return itemIds.every((itemId) => reportHasCompactHtmlEnrichment(reportsByItemId.get(String(itemId))));
  }

  function aggregateEnrichedMinMax(enrichedCustomerTypes) {
    let min = null;
    let max = null;

    for (const typeReport of enrichedCustomerTypes || []) {
      const typeMin = toNumberOrNull(typeReport?.effectiveMin);
      const typeMax = toNumberOrNull(typeReport?.effectiveMax);
      if (typeMin !== null) {
        min = min === null ? typeMin : Math.max(min, typeMin);
      }
      if (typeMax !== null) {
        max = max === null ? typeMax : Math.min(max, typeMax);
      }
    }

    return {
      min,
      max,
      minLabel: min !== null ? String(min) : "unknown",
      maxLabel: max !== null ? String(max) : "unknown"
    };
  }

  function buildEnrichedMinMaxCell(enrichedCustomerTypes) {
    const { minLabel, maxLabel } = aggregateEnrichedMinMax(enrichedCustomerTypes);
    return `<strong>Min:</strong> ${escapeHtmlText(minLabel)}<br><strong>Max:</strong> ${escapeHtmlText(maxLabel)}`;
  }

  function buildEnrichedCopyTableHtml(scrapedRows, reports, includeHeaderRow = false) {
    if (!canBuildEnrichedHtmlForData(scrapedRows, reports)) {
      return null;
    }

    const reportsByItemId = new Map(
      reports.map((report) => [String(report.itemId), report])
    );

    let html = '<table border="1" cellpadding="5" cellspacing="0">\n<tbody>\n';
    if (includeHeaderRow) {
      html += GYG_ENRICHED_HTML_HEADER_ROW;
    }

    for (const row of scrapedRows) {
      const itemId = row.itemId || extractIdNumberFromLabel(row.itemLabel);
      const report = itemId ? reportsByItemId.get(String(itemId)) : null;
      const customerTypes = report?.customerTypes || [];
      const processorCurrency = report?.processorCurrency ?? null;
      const itemLabelContent = row.itemLabelHTML || escapeHtmlText(row.itemLabel || "");

      html += "<tr>\n";
      html += `<td><strong>${escapeHtmlText(row.channelOption || "")}</strong></td>\n`;
      html += `<td>${itemLabelContent}</td>\n`;
      html += `<td>${buildEnrichedCustomerTypeCell(customerTypes, processorCurrency)}</td>\n`;
      html += `<td>${buildEnrichedMinMaxCell(customerTypes)}</td>\n`;
      html += "</tr>\n";
    }

    html += "</tbody>\n</table>";
    return html;
  }

  function escapeHtmlText(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function applyCapacitySampleToReport(report, capacityResult) {
    const data = capacityResult.data || {};
    const samples = data.samples || [];
    report.sampledAvailabilityIds = samples.map((sample) => sample.availabilityId);
    report.sampledAvailabilityStartTimes = samples.map((sample) => sample.startAt);
    report.sampledCustomerCounts = samples.map((sample) => sample.customerCount);
    report.sampledBookableCapacities = samples.map((sample) => sample.bookableCapacity);
    report.sampledTotalCapacities = samples.map((sample) => sample.totalCapacity);
    report.selectedFallbackCapacity = data.selectedFallbackCapacity;
    report.capacitySampleWarning = data.capacitySampleWarning;
    report.availabilityCustomerCount = data.availabilityCustomerCount;
    report.availabilityBookableCapacity = data.availabilityBookableCapacity;
    report.totalAvailabilityCapacity = data.totalAvailabilityCapacity;
    report.candidateCollectionEndpoint = data.candidateCollectionEndpoint;
    report.availabilityDetailEndpoint = data.availabilityDetailEndpoint;
    report.candidateAttemptLog = data.candidateAttemptLog || [];
    report.availabilityDetailCapacity = data.availabilityDetails || [];
    report.availabilityDetailFetchSummary = data.availabilityDetailFetchSummary || null;
    return data.selectedFallbackCapacity ?? data.totalAvailabilityCapacity;
  }

  function applyResourceCapacityToReport(report, resourceCapacityResult) {
    report.resourceCapacityEntries = resourceCapacityResult.entries || [];
    report.selectedResourceDerivedCapacity = resourceCapacityResult.selectedCapacity;
    report.resourceCapacityErrors = resourceCapacityResult.errors || [];
    return resourceCapacityResult.selectedCapacity;
  }

  async function enrichSingleItem(
    company,
    itemId,
    scrapedRows,
    availabilityIdOverride,
    pageUrl,
    runCaches = null
  ) {
    const warnings = [];
    const report = {
      itemId,
      itemName: null,
      itemMinNoBookings: null,
      itemMinAlreadyBooked: null,
      itemMaxNoBookings: null,
      itemMaxAlreadyBooked: null,
      availabilityCustomerCount: null,
      availabilityBookableCapacity: null,
      totalAvailabilityCapacity: null,
      selectedFallbackCapacity: null,
      capacitySampleWarning: null,
      sampledAvailabilityIds: [],
      sampledAvailabilityStartTimes: [],
      sampledCustomerCounts: [],
      sampledBookableCapacities: [],
      sampledTotalCapacities: [],
      candidateCollectionEndpoint: null,
      availabilityDetailEndpoint: null,
      candidateAttemptLog: [],
      resourceCapacityEntries: [],
      selectedResourceDerivedCapacity: null,
      resourceCapacityErrors: [],
      availabilityDetailCapacity: [],
      availabilityDetailFetchSummary: null,
      totalSheetName: null,
      pricingSourceType: null,
      pricingScheduleName: null,
      pricingSchedulePk: null,
      schedulePricing: null,
      affiliationDebug: null,
      processorCurrency: null,
      customerTypes: [],
      warnings
    };

    if (!company) {
      warnings.push("Could not determine company shortname from URL");
      return report;
    }
    if (!itemId) {
      warnings.push("Could not determine FareHarbor item ID for enrichment");
      return report;
    }

    const enrichmentItemStart = performance.now();
    const enrichmentContext = resolveEnrichmentContext(scrapedRows, pageUrl);
    const availabilityId = availabilityIdOverride ?? enrichmentContext.availabilityId;
    const rowContext = extractResellerContextFromScrapedRows(scrapedRows);
    const effectivePageUrl =
      rowContext?.enrichmentPageUrl ||
      rowContext?.resellerItemUrl ||
      (parseResellerItemContextFromUrl(pageUrl)?.resellerItemId ? pageUrl : null) ||
      enrichmentContext.pageUrl;

    const [itemWrap, prototypesWrap, affiliationWrap, requirementGroupsWrap, resourcesWrap, resellerMappingWrap] =
      await Promise.all([
        timedAsync("item fetch", () => fetchItemData(company, itemId)),
        timedAsync("customer prototype fetch", () => fetchCustomerPrototypes(company, itemId)),
        timedAsync("affiliate fetch", () =>
          findGetYourGuideAffiliationCached(company, runCaches?.affiliationCache)
        ),
        timedAsync("requirement groups fetch", () => fetchRequirementGroups(company, itemId)),
        timedAsync("company resources fetch", () => fetchCompanyResources(company)),
        timedAsync("reseller customer type mappings fetch", () =>
          fetchResellerCustomerTypeMappingsForItem(
            company,
            itemId,
            scrapedRows,
            effectivePageUrl,
            runCaches?.mappingCache
          )
        )
      ]);

    const itemResult = itemWrap.result;
    const prototypesResult = prototypesWrap.result;
    const affiliationResult = affiliationWrap.result;
    const requirementGroupsResult = requirementGroupsWrap.result;
    const resourcesResult = resourcesWrap.result;
    const resellerMappingResult = resellerMappingWrap.result;
    const mappingLookup = resellerMappingResult?.ok ? resellerMappingResult.lookup : null;

    if (resellerMappingResult?.ok) {
      log(
        "Reseller customer type mapping entries loaded:",
        resellerMappingResult.mappingCount ?? 0
      );
    } else if (resellerMappingResult?.error) {
      log(
        "Reseller customer type mapping unavailable; falling back to display-name matching:",
        resellerMappingResult.error
      );
    }

    let item = null;
    if (!itemResult.ok) {
      warnings.push(`Item data fetch failed: ${itemResult.error}`);
    } else {
      item = itemResult.item;
      report.itemName = item?.name ?? item?.unicode ?? extractItemNameFromLabel(scrapedRows[0]?.itemLabel);
      report.itemMinNoBookings = item?.minimum_initial_party_size ?? null;
      report.itemMinAlreadyBooked = item?.minimum_subsequent_party_size ?? null;
      report.itemMaxNoBookings = item?.maximum_initial_party_size ?? null;
      report.itemMaxAlreadyBooked = item?.maximum_subsequent_party_size ?? null;
    }

    if (!report.itemName && scrapedRows[0]?.itemLabel) {
      report.itemName = extractItemNameFromLabel(scrapedRows[0].itemLabel);
    }

    let prototypes = [];
    if (!prototypesResult.ok) {
      warnings.push(`Customer prototypes fetch failed: ${prototypesResult.error}`);
    } else {
      prototypes = prototypesResult.prototypes;
    }

    function resolveMappedCustomerType(mapped) {
      const resolved = resolvePrototypeForChannelCustomerType(mapped, prototypes, mappingLookup);
      const mappedCustomerTypes = resolved.mappedCustomerTypes || [];
      const prototypesForType = mappedCustomerTypes
        .map((entry) => entry.prototype)
        .filter(Boolean);

      if (mappedCustomerTypes.length > 1) {
        log(
          `Channel customer type "${mapped.displayName || "unknown"}" mapped to ${mappedCustomerTypes.length} FareHarbor customer types`
        );
        log(
          "Mapped FareHarbor customer type names and prototype IDs:",
          mappedCustomerTypes.map((entry) => ({
            name: entry.name,
            customerPrototypePk: entry.customerPrototypePk,
            customerTypePk: entry.customerTypePk
          }))
        );
      }

      for (const entry of mappedCustomerTypes) {
        if (!entry.prototype) continue;
        log(
          `Resolved channel customer type mapping: ${mapped.displayName || "unknown"} / ${mapped.externalId || "unknown"} -> ${entry.name || "unknown"} / customer_type.pk ${formatUnknown(entry.customerTypePk)} / customer_prototype.pk ${formatUnknown(entry.customerPrototypePk)} (${resolved.resolutionMethod || "unknown"})`
        );
      }

      if (mappedCustomerTypes.length === 0) {
        if (resolved.mappingEntry || resolved.resolutionMethod) {
          log(
            `Partial reseller customer type mapping for ${mapped.displayName || "unknown"} / ${mapped.externalId || "unknown"} -> ${resolved.mappedFareHarborCustomerTypeName || "unknown"}; prototype not found on item`
          );
        } else {
          log(
            `Unresolved channel customer type mapping for ${mapped.displayName || "unknown"} / ${mapped.externalId || "unknown"}; display-name fallback will be used if available`
          );
        }
      }

      if (
        prototypesForType.length === 0 &&
        resolved.resolutionMethod === "customer type display name" &&
        !mappingLookup
      ) {
        log(
          "Reseller customer type mapping unavailable; falling back to display-name matching for",
          mapped.displayName || "unknown"
        );
      }
      return resolved;
    }

    report.affiliationDebug = affiliationResult.debug;
    if (report.affiliationDebug) {
      log("Affiliate pricing debug:", report.affiliationDebug);
    }

    const pricingPromise = (async () => {
      if (!affiliationResult.ok) {
        warnings.push(`GetYourGuide affiliation lookup failed: ${affiliationResult.error}`);
        return { result: null, durationMs: 0 };
      }

      const assignedPricing = affiliationResult.assignedPricing;
      if (!assignedPricing) {
        warnings.push(
          affiliationResult.debug?.noPricingReason ||
            "No GetYourGuide total price sheet assigned"
        );
        return { result: null, durationMs: 0 };
      }

      if (assignedPricing.type === "schedule") {
        report.totalSheetName = assignedPricing.displayName;
        report.pricingSourceType = "schedule";
        report.pricingScheduleName = assignedPricing.displayName;
        report.pricingSchedulePk = assignedPricing.pk;

        if (assignedPricing.pk == null) {
          warnings.push("Assigned GetYourGuide total schedule is missing a pk; pricing lookup skipped");
          return { result: null, durationMs: 0 };
        }

        const pricingWrap = await timedAsync("schedule pricing fetch", () =>
          fetchPricingForAssignedSchedule(company, assignedPricing, itemId)
        );
        return pricingWrap;
      }

      report.pricingSourceType = "sheet";
      report.totalSheetName = assignedPricing.displayName;
      if (assignedPricing.pk == null) {
        warnings.push("Assigned GetYourGuide total sheet is missing a pk; pricing lookup skipped");
        return { result: null, durationMs: 0 };
      }

      const pricingWrap = await timedAsync("pricing fetch", () =>
        fetchPricingForEditing(company, assignedPricing.pk, itemId)
      );
      return pricingWrap;
    })();

    const resourceCapacityWrap = await timedAsync("resource capacity resolve", () =>
      resolveResourceCapacity(company, itemId, {
        requirementGroupsResult,
        resourcesResult
      })
    );
    const resourceCapacityResult = resourceCapacityWrap.result;
    let resourceDerivedCapacity = applyResourceCapacityToReport(report, resourceCapacityResult);
    for (const error of report.resourceCapacityErrors || []) {
      log("Resource capacity warning:", error);
    }

    let totalAvailabilityCapacity = null;
    const mappedPrototypes = [];
    const mappedPrototypeKeys = new Set();
    for (const mapped of collectMappedCustomerTypes(scrapedRows, itemId)) {
      const resolved = resolveMappedCustomerType(mapped);
      for (const entry of resolved.mappedCustomerTypes || []) {
        if (!entry.prototype?.pk) continue;
        const key = String(entry.prototype.pk);
        if (mappedPrototypeKeys.has(key)) continue;
        mappedPrototypeKeys.add(key);
        mappedPrototypes.push(entry.prototype);
      }
    }
    const capacityPromise = (async () => {
      const candidateCollection = availabilityId
        ? null
        : (await timedAsync("availability candidate fetch", () =>
            collectAvailabilityCandidates(company, itemId)
          )).result;
      return timedAsync("availability detail fetch", () =>
        resolveAvailabilityCapacity(company, itemId, availabilityId, candidateCollection, {
          mappedPrototypes
        })
      );
    })();

    const [pricingWrap, capacityWrap] = await Promise.all([pricingPromise, capacityPromise]);
    const capacityResult = capacityWrap.result;
    let pricingRows = [];
    let pricingFetched = false;
    let schedulePricingResult = null;

    if (capacityResult.ok) {
      totalAvailabilityCapacity = applyCapacitySampleToReport(report, capacityResult);
      if (report.candidateCollectionEndpoint) {
        log("Availability candidate collection endpoint:", report.candidateCollectionEndpoint);
      }
      if (report.capacitySampleWarning) {
        warnings.push(report.capacitySampleWarning);
      }
      log("Availability polling used for capacity fallback");
    } else {
      log("Availability capacity sampling failed:", capacityResult.error);
      applyCapacitySampleToReport(report, capacityResult);
      warnings.push(`Availability capacity could not be determined: ${capacityResult.error}`);
    }

    const pricingResult = pricingWrap.result;
    if (pricingResult?.kind === "schedule") {
      schedulePricingResult = pricingResult;
      report.schedulePricing = schedulePricingResult;

      if (!schedulePricingResult.ok) {
        const scheduleError =
          schedulePricingResult.error ||
          "Assigned GetYourGuide pricing is a total schedule but its sheets could not be read";
        warnings.push(`GetYourGuide pricing fetch failed: ${scheduleError}`);
      } else {
        pricingFetched = true;
        for (const sheet of schedulePricingResult.sheetResults) {
          if (sheet.ok) {
            log(
              `Loaded ${sheet.pricingRows.length} effective pricing row(s) from schedule sheet ${sheet.pk} (${sheet.name})`
            );
          } else {
            warnings.push(
              `GetYourGuide pricing fetch failed for sheet "${sheet.name}" (pk ${sheet.pk}): ${sheet.error}`
            );
          }
        }
      }
    } else if (pricingResult) {
      if (!pricingResult.ok) {
        warnings.push(`GetYourGuide pricing fetch failed: ${pricingResult.error}`);
      } else {
        pricingRows = getEffectivePricings(pricingResult.pricing);
        pricingFetched = true;
        log(`Loaded ${pricingRows.length} effective pricing row(s) from assigned total sheet`);
      }
    }

    log(`item enrichment duration: ${(performance.now() - enrichmentItemStart).toFixed(1)}ms`);

    const mappedTypes = collectMappedCustomerTypes(scrapedRows, itemId);

    for (const mapped of mappedTypes) {
      const resolvedMapping = resolveMappedCustomerType(mapped);
      const mappedCustomerTypes = resolvedMapping.mappedCustomerTypes || [];
      const prototypesForType = mappedCustomerTypes
        .map((entry) => entry.prototype)
        .filter(Boolean);
      const prototype = prototypesForType[0] ?? resolvedMapping.prototype ?? null;
      const typeReport = {
        displayName: mapped.displayName,
        externalId: mapped.externalId,
        mappedFareHarborCustomerTypeName: resolvedMapping.mappedFareHarborCustomerTypeName,
        mappedFareHarborCustomerTypeNames: resolvedMapping.mappedFareHarborCustomerTypeNames || [],
        mappedCustomerTypes: mappedCustomerTypes.map((entry) => ({
          name: entry.name,
          customerPrototypePk: entry.customerPrototypePk,
          customerTypePk: entry.customerTypePk,
          rawMin: entry.rawMin,
          rawMax: entry.rawMax,
          rawCapacity: entry.rawCapacity
        })),
        mappedCustomerTypeRangeMin: null,
        mappedCustomerTypeRangeMax: null,
        prototypeResolutionMethod: resolvedMapping.resolutionMethod,
        prototypePk: prototype?.pk ?? null,
        customerTypePk: getPrototypeCustomerType(prototype || {})?.pk ?? null,
        rawMin: null,
        rawMax: null,
        rawCapacity: null,
        effectiveMin: null,
        effectiveMax: null,
        capacitySource: null,
        availabilityCustomerTypeCapacity: null,
        availabilityPerBookingMinimum: null,
        availabilityPerBookingMaximum: null,
        availabilitySampledCapacities: [],
        availabilitySampledPerBookingMinimums: [],
        availabilitySampledPerBookingMaximums: [],
        availabilityCapacityDisagreement: false,
        availabilityPerBookingMinDisagreement: false,
        availabilityPerBookingMaxDisagreement: false,
        availabilityCapacityMatchMethod: null,
        basePrice: null,
        finalPrice: null,
        basePrices: [],
        finalPrices: [],
        basePricesPerSheet: [],
        finalPricesPerSheet: [],
        taxRateUsed: null,
        taxOffsetUsed: null,
        priceCalculationPath: null,
        priceCalculationNote: null,
        priceMatchMethod: null
      };

      if (prototypesForType.length === 0) {
        warnings.push(
          `Mapped customer type "${mapped.displayName}"${mapped.externalId ? ` (${mapped.externalId})` : ""} has no matched customer_prototype via reseller mapping or name fallback`
        );
      } else {
        typeReport.mappedCustomerTypeRangeMin = calculateGroupedMappedCustomerTypeMin(
          item,
          prototypesForType
        );
        typeReport.mappedCustomerTypeRangeMax = calculateGroupedMappedCustomerTypeMax(
          prototypesForType
        );
        log(
          `Grouped mapped customer type range for "${mapped.displayName}" before constraints:`,
          {
            minimum: typeReport.mappedCustomerTypeRangeMin,
            maximum: typeReport.mappedCustomerTypeRangeMax
          }
        );

        if (prototypesForType.length === 1) {
          const singlePrototype = prototypesForType[0];
          typeReport.rawMin = singlePrototype.minimum_party_size ?? null;
          typeReport.rawMax = singlePrototype.maximum_party_size ?? null;
          typeReport.rawCapacity = singlePrototype.capacity ?? null;
        } else {
          typeReport.rawMin = typeReport.mappedCustomerTypeRangeMin;
          typeReport.rawMax = typeReport.mappedCustomerTypeRangeMax;
        }

        typeReport.effectiveMin = typeReport.mappedCustomerTypeRangeMin;

        const availabilityDetailMatches = gatherMatchedAvailabilityRatesForPrototypes(
          report.availabilityDetailCapacity,
          prototypesForType
        );
        if (availabilityDetailMatches.length > 0) {
          log(
            `customer_type_rates found for "${mapped.displayName}" across ${prototypesForType.length} mapped prototype(s):`,
            availabilityDetailMatches.length
          );
          log("customer_type_rates match method: customer_prototype.pk");
        }

        const maxResult = collectCapacityCandidates({
          item,
          prototypes: prototypesForType,
          resourceDerivedCapacity,
          availabilityDetailMatches,
          pollingFallbackCapacity: totalAvailabilityCapacity ?? report.selectedFallbackCapacity
        });

        typeReport.effectiveMax = maxResult.effectiveMax;
        typeReport.capacitySource = maxResult.capacitySource;
        typeReport.availabilityCustomerTypeCapacity = maxResult.availabilityCustomerTypeCapacity;
        typeReport.availabilityPerBookingMinimum = maxResult.availabilityPerBookingMinimum;
        typeReport.availabilityPerBookingMaximum = maxResult.availabilityPerBookingMaximum;
        typeReport.availabilitySampledCapacities = maxResult.availabilitySampledCapacities;
        typeReport.availabilitySampledPerBookingMinimums =
          maxResult.availabilitySampledPerBookingMinimums;
        typeReport.availabilitySampledPerBookingMaximums =
          maxResult.availabilitySampledPerBookingMaximums;
        typeReport.availabilityCapacityDisagreement = maxResult.availabilityCapacityDisagreement;
        typeReport.availabilityPerBookingMinDisagreement =
          maxResult.availabilityPerBookingMinDisagreement;
        typeReport.availabilityPerBookingMaxDisagreement =
          maxResult.availabilityPerBookingMaxDisagreement;
        typeReport.availabilityCapacityMatchMethod = maxResult.availabilityCapacityMatchMethod;

        log(`Final effective min/max for "${mapped.displayName}":`, {
          effectiveMin: typeReport.effectiveMin,
          effectiveMax: typeReport.effectiveMax,
          capacitySource: maxResult.capacitySource,
          candidates: maxResult.candidates
        });
      }

      if (schedulePricingResult && prototypesForType.length > 0) {
        const finalPricesPerSheet = [];
        const basePricesPerSheet = [];
        let firstPriceResult = null;

        for (const sheet of schedulePricingResult.sheetResults) {
          if (!sheet.ok) continue;
          const sheetFinalPrices = [];
          const sheetBasePrices = [];

          for (const mappedType of mappedCustomerTypes) {
            if (!mappedType.prototype) continue;
            const { row } = matchPricingRow(mappedType.prototype, sheet.pricingRows);
            if (!row) continue;
            const priceResult = calculateGetYourGuideFinalPrice(row);
            sheetFinalPrices.push(priceResult.finalPrice);
            sheetBasePrices.push(priceResult.basePrice);
            if (!firstPriceResult) {
              firstPriceResult = { priceResult };
            }
            log(
              `Matched price for "${mapped.displayName}" (customer_prototype.pk ${mappedType.prototype.pk}) on sheet ${sheet.pk} (${sheet.name}):`,
              {
                basePrice: priceResult.basePrice,
                finalPrice: priceResult.finalPrice
              }
            );
            if (priceResult.warning) {
              warnings.push(
                `GetYourGuide price for "${mapped.displayName}" on sheet "${sheet.name}": ${priceResult.warning}`
              );
            }
          }

          const dedupedFinal = dedupePreservingOrder(sheetFinalPrices);
          const dedupedBase = dedupePreservingOrder(sheetBasePrices);
          finalPricesPerSheet.push(dedupedFinal);
          basePricesPerSheet.push(dedupedBase);
          sheet.matchedByDisplayName[mapped.displayName] = {
            finalPrices: dedupedFinal,
            basePrices: dedupedBase,
            finalPrice: dedupedFinal[0] ?? null,
            basePrice: dedupedBase[0] ?? null
          };
        }

        if (finalPricesPerSheet.length > 0) {
          typeReport.finalPricesPerSheet = finalPricesPerSheet;
          typeReport.basePricesPerSheet = basePricesPerSheet;
          typeReport.finalPrices = finalPricesPerSheet.flat();
          typeReport.basePrices = basePricesPerSheet.flat();
          typeReport.finalPrice = finalPricesPerSheet[0]?.[0] ?? null;
          typeReport.basePrice = basePricesPerSheet[0]?.[0] ?? null;
          typeReport.priceMatchMethod = "customer_prototype.pk via total schedule";
          if (firstPriceResult) {
            typeReport.taxRateUsed = firstPriceResult.priceResult.taxRateUsed;
            typeReport.taxOffsetUsed = firstPriceResult.priceResult.taxOffsetUsed;
            typeReport.priceCalculationPath = firstPriceResult.priceResult.calculationPath;
            typeReport.priceCalculationNote = firstPriceResult.priceResult.calculationNote;
          }

          log(
            `GetYourGuide final prices for "${mapped.displayName}" across ${prototypesForType.length} mapped prototype(s):`,
            finalPricesPerSheet
          );
        } else if (schedulePricingResult.ok) {
          warnings.push(
            `Mapped customer type "${mapped.displayName}" has no matched pricing row on any schedule sheet`
          );
          log(`Unmatched mapped customer type for schedule pricing: "${mapped.displayName}"`, {
            prototypePks: prototypesForType.map((entry) => entry.pk),
            customerTypePks: prototypesForType.map((entry) => getPrototypeCustomerType(entry)?.pk)
          });
        }
      } else if (pricingFetched && prototypesForType.length > 0) {
        const matchedFinalPrices = [];
        const matchedBasePrices = [];
        let firstPriceResult = null;
        let priceMatchMethod = null;

        for (const mappedType of mappedCustomerTypes) {
          if (!mappedType.prototype) continue;
          const { row, method } = matchPricingRow(mappedType.prototype, pricingRows);
          if (!row) continue;
          const priceResult = calculateGetYourGuideFinalPrice(row);
          matchedFinalPrices.push(priceResult.finalPrice);
          matchedBasePrices.push(priceResult.basePrice);
          if (!firstPriceResult) {
            firstPriceResult = { priceResult, method };
            priceMatchMethod = method;
          }
          log(
            `GetYourGuide final price for "${mapped.displayName}" (customer_prototype.pk ${mappedType.prototype.pk}):`,
            {
              basePrice: priceResult.basePrice,
              finalPrice: priceResult.finalPrice,
              taxRateUsed: priceResult.taxRateUsed,
              taxOffsetUsed: priceResult.taxOffsetUsed,
              calculationPath: priceResult.calculationPath,
              calculationNote: priceResult.calculationNote
            }
          );
          if (priceResult.warning) {
            warnings.push(
              `GetYourGuide price for "${mapped.displayName}": ${priceResult.warning}`
            );
          }
        }

        const finalPrices = dedupePreservingOrder(matchedFinalPrices);
        const basePrices = dedupePreservingOrder(matchedBasePrices);

        if (finalPrices.length > 0) {
          typeReport.finalPrices = finalPrices;
          typeReport.basePrices = basePrices;
          typeReport.finalPricesPerSheet = [finalPrices];
          typeReport.basePricesPerSheet = [basePrices];
          typeReport.finalPrice = finalPrices[0] ?? null;
          typeReport.basePrice = basePrices[0] ?? null;
          typeReport.taxRateUsed = firstPriceResult?.priceResult.taxRateUsed ?? null;
          typeReport.taxOffsetUsed = firstPriceResult?.priceResult.taxOffsetUsed ?? null;
          typeReport.priceCalculationPath = firstPriceResult?.priceResult.calculationPath ?? null;
          typeReport.priceCalculationNote = firstPriceResult?.priceResult.calculationNote ?? null;
          typeReport.priceMatchMethod = priceMatchMethod;
        } else {
          warnings.push(`Mapped customer type "${mapped.displayName}" has no matched pricing row`);
          log(`Unmatched mapped customer type for pricing: "${mapped.displayName}"`, {
            prototypePks: prototypesForType.map((entry) => entry.pk),
            customerTypePks: prototypesForType.map((entry) => getPrototypeCustomerType(entry)?.pk)
          });
        }
      } else if (pricingFetched && prototypesForType.length === 0) {
        warnings.push(`Mapped customer type "${mapped.displayName}" has no matched pricing (no prototype match)`);
      }

      report.customerTypes.push(typeReport);
    }

    return report;
  }

  function groupRowsByItemId(scrapedRows) {
    const groups = new Map();

    for (const row of scrapedRows || []) {
      const itemId = row.itemId || extractIdNumberFromLabel(row.itemLabel);
      if (!itemId) continue;
      if (!groups.has(itemId)) {
        groups.set(itemId, []);
      }
      groups.get(itemId).push(row);
    }

    return groups;
  }

  async function runWithConcurrencyLimit(tasks, limit, worker) {
    const results = new Array(tasks.length);
    let nextIndex = 0;

    async function runWorker() {
      while (nextIndex < tasks.length) {
        const currentIndex = nextIndex;
        nextIndex += 1;
        results[currentIndex] = await worker(tasks[currentIndex], currentIndex);
      }
    }

    const workerCount = Math.min(limit, tasks.length);
    await Promise.all(Array.from({ length: workerCount }, () => runWorker()));
    return results;
  }

  function resolveTaskEnrichmentPageUrl(rows, fallbackPageUrl) {
    const rowContext = extractResellerContextFromScrapedRows(rows);
    if (rowContext?.enrichmentPageUrl) return rowContext.enrichmentPageUrl;
    if (rowContext?.resellerItemUrl) return rowContext.resellerItemUrl;
    if (parseResellerItemContextFromUrl(fallbackPageUrl)?.resellerItemId) {
      return fallbackPageUrl;
    }
    return fallbackPageUrl;
  }

  async function enrichCopyOutput({ scrapedRows, mode, pageUrl }) {
    const enrichmentStart = performance.now();
    const context = resolveEnrichmentContext(scrapedRows, pageUrl);
    const allWarnings = [];
    let reports = [];

    if (!context.company) {
      allWarnings.push("Could not determine company shortname; enrichment skipped");
      const explanationText = [
        "=== GetYourGuide Mapping Explanation ===",
        "",
        "Notes and warnings",
        "- Could not determine company shortname; enrichment skipped"
      ].join("\n");
      return {
        explanationText,
        hasEnrichmentExplanation: false,
        warnings: allWarnings,
        reports
      };
    }

    const itemGroups = groupRowsByItemId(scrapedRows);
    const tasks = [];

    if (itemGroups.size > 0) {
      for (const [itemId, rows] of itemGroups.entries()) {
        tasks.push({ itemId, rows });
      }
    } else if (context.itemId) {
      tasks.push({ itemId: context.itemId, rows: scrapedRows });
    }

    if (tasks.length === 0) {
      allWarnings.push("Could not determine any item IDs for enrichment");
    } else {
      const companyWrap = await timedAsync("company fetch", () => fetchCompanyData(context.company));
      let processorCurrency = null;
      if (companyWrap.result?.ok) {
        processorCurrency = getProcessorCurrency(companyWrap.result.company);
        log("Company processor currency:", processorCurrency || "unknown");
      } else if (companyWrap.result?.error) {
        log("Company fetch failed; prices will omit currency:", companyWrap.result.error);
      }

      const availabilityId = mode === "single" ? context.availabilityId : null;
      const runCaches = {
        mappingCache: new Map(),
        affiliationCache: new Map()
      };
      reports = await runWithConcurrencyLimit(tasks, CONCURRENCY_LIMIT, async (task) => {
        const taskPageUrl = resolveTaskEnrichmentPageUrl(task.rows, context.pageUrl);
        return enrichSingleItem(
          context.company,
          task.itemId,
          task.rows,
          mode === "single" ? availabilityId : null,
          taskPageUrl,
          runCaches
        );
      });

      for (const report of reports) {
        report.processorCurrency = processorCurrency;
      }

      for (const report of reports) {
        allWarnings.push(...report.warnings);
      }
    }

    const explanationText = buildEnrichmentExplanation(reports, scrapedRows);

    log(`total enrichment duration: ${(performance.now() - enrichmentStart).toFixed(1)}ms`);

    return {
      explanationText,
      hasEnrichmentExplanation: hasEnrichmentExplanationData(reports),
      warnings: allWarnings,
      reports
    };
  }

  window.GetYourGuideMappingEnrichment = {
    enrichCopyOutput,
    buildEnrichmentExplanation,
    formatEnrichmentExplanation,
    buildEnrichedCopyTableHtml,
    formatCurrencyAmount,
    formatEnrichmentPriceDisplay,
    formatMultipleEnrichmentPrices,
    getProcessorCurrency,
    buildEnrichedCustomerTypeCell,
    buildEnrichedMinMaxCell,
    aggregateEnrichedMinMax,
    canBuildEnrichedHtmlForData,
    __test__: {
      pickHighest,
      pickLowest,
      calculateTotalAvailabilityCapacity,
      calculateEffectiveMin,
      selectSmallestSampledValue,
      selectLargestSampledValue,
      calculateGroupedMappedCustomerTypeMin,
      calculateGroupedMappedCustomerTypeMax,
      dedupePreservingOrder,
      normalizeUniqueSortedPrices,
      formatAggregatedPriceDisplay,
      collectEnrichmentPrices,
      formatDiagnosticPriceList,
      formatPriceRangeLabel,
      formatScheduleSheetPriceLabels,
      collectCapacityCandidates,
      extractAvailabilityCapacityDetails,
      matchCustomerTypeRateToMapping,
      gatherMatchedAvailabilityRates,
      gatherAllMatchedRatesForMappedPrototypes,
      hasUsefulMatchedRateFields,
      getInspectionMatchesForDetail,
      buildAvailabilityDetailFetchSummary,
      detailHasMatchingRates,
      isValidCapacityCandidate,
      deriveResourceCapacity,
      extractNestedArray,
      analyzeCapacitySamples,
      matchPricingRow,
      findPrototypeByMappedName,
      isGetYourGuideAffiliate,
      formatPriceFromRow,
      extractBasePriceFromRow,
      normalizePercentageTaxRate,
      calculateGetYourGuideFinalPrice,
      getEffectivePricings,
      resolveAssignedPricing,
      getPricingObjectPk,
      getPricingObjectType,
      aggregateEnrichedMinMax,
      buildEnrichedCustomerTypeCell,
      buildEnrichedMinMaxCell,
      canBuildEnrichedHtmlForData,
      buildEnrichedCopyTableHtml,
      formatCurrencyAmount,
      formatEnrichmentPriceDisplay,
      formatMultipleEnrichmentPrices,
      extractTotalSheetsFromSchedule,
      formatEnrichmentExplanation,
      buildEnrichmentExplanation,
      hasEnrichmentExplanationData,
      formatCapacitySourceLabel,
      parseResellerItemContextFromUrl,
      matchResellerIdsFromText,
      extractResellerContextFromScrapedRows,
      resolvePrototypeForChannelCustomerType,
      buildResellerCustomerTypeLookup,
      normalizeResellerExternalId,
      extractRctExternalId,
      findPrototypeByPk,
      buildDisplayedPriceMatchMethod,
      getProcessorCurrency
    }
  };

  log("Module initialized successfully");
})();
