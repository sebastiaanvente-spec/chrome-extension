console.log("[activity-listings] activity-listings.js loaded");

// Wait for utilities to be available and initialize module
(function initializeActivityListings() {
  // Wait for FareHarborUtils to be available
  if (!window.FareHarborUtils) {
    setTimeout(initializeActivityListings, 10);
    return;
  }
  
  // Now utilities are available, set up the module
  const utils = window.FareHarborUtils;

  const API_BASE = "https://www.airbnb.com/api/v3/GetConnectedActivityListingsQuery/d7c68b3827775aec9c8fa11cea77977814a96ac84966673d3f037ee573e5052e";
  const PAGE_SIZE = 25;
  const API_HEADERS = {
    "x-airbnb-api-key": "d306zoyjsyarp7ifhu67rjxn52tv0t20",
    "x-airbnb-graphql-platform": "web",
    "x-airbnb-graphql-platform-client": "minimalist-niobe",
    "x-airbnb-supports-airlock-v2": "true",
    "x-csrf-without-token": "1",
    "content-type": "application/json"
  };

  function encodeAirbnbId(type, id) {
    return btoa(`${type}:${id}`);
  }

  function decodeListingId(base64Id) {
    if (!base64Id) return "";
    try {
      return atob(base64Id).split(":").pop() || "";
    } catch (e) {
      console.warn("[activity-listings] Failed to decode listing ID:", base64Id, e);
      return "";
    }
  }

  function parseClientIdFromUrl() {
    const match = window.location.pathname.match(/\/client\/(\d+)\//);
    if (!match) {
      throw new Error("No client ID found in URL. Expected path like /client/2724/");
    }
    return encodeAirbnbId("ApiPartnerClient", match[1]);
  }

  function parseHostUserIdFromUrl() {
    const hostUserId = new URLSearchParams(window.location.search).get("hostUserID");
    if (!hostUserId) {
      throw new Error("No hostUserID found in URL query params.");
    }
    return encodeAirbnbId("User", hostUserId);
  }

  function mapListingStatus(raw) {
    if (raw === "LISTED") return "Listed";
    if (raw === "SUSPENDED") return "Suspended";
    return raw || "";
  }

  function mapApiSyncStatus(syncAvailability) {
    return syncAvailability === true ? "SYNCED" : "NOT SYNCED";
  }

  function mapVettingQueueStatus(raw) {
    if (raw === "PUBLISHING_ENABLED") return "Publishing enabled";
    if (raw === "SUSPENDED") return "Suspended";
    return raw || "";
  }

  function mapNodeToListing(node) {
    if (!node) return null;
    const id = decodeListingId(node.id);
    if (!id) return null;
    return {
      id,
      name: node.descriptions?.name || "",
      status: mapListingStatus(node.listingStatus?.displayState?.listOfListingsDisplayState),
      apiSyncStatus: mapApiSyncStatus(node.apiData?.syncAvailability),
      vettingQueueStatus: mapVettingQueueStatus(node.statusInfo?.queueStatus),
      country: node.location?.localizedAddress?.countryCode || ""
    };
  }

  function buildRetryDataFromNode(node) {
    return {
      syncAvailability: node.apiData?.syncAvailability,
      apiData: node.apiData,
      name: node.descriptions?.name || "",
      status: mapListingStatus(node.listingStatus?.displayState?.listOfListingsDisplayState),
      vettingQueueStatus: mapVettingQueueStatus(node.statusInfo?.queueStatus),
      country: node.location?.localizedAddress?.countryCode || ""
    };
  }

  function hasBlankField(value) {
    return !value || !String(value).trim();
  }

  function hasBlankName(row) {
    return hasBlankField(row.name);
  }

  function isMissingNameRow(row) {
    return !!row.id && hasBlankName(row);
  }

  function isMissingStatusRow(row) {
    return !!row.id && hasBlankField(row.status);
  }

  function isMissingQueueStatusRow(row) {
    return !!row.id && hasBlankField(row.vettingQueueStatus);
  }

  function isMissingCountryRow(row) {
    return !!row.id && hasBlankField(row.country);
  }

  function isSuspiciousNotSyncedRow(row) {
    return row.status === "Listed"
      && row.vettingQueueStatus === "Publishing enabled"
      && row.apiSyncStatus === "NOT SYNCED";
  }

  function summarizeIncompleteRows(rows) {
    const missingName = rows.filter(isMissingNameRow).map((row) => row.id);
    const missingStatus = rows.filter(isMissingStatusRow).map((row) => row.id);
    const missingQueueStatus = rows.filter(isMissingQueueStatusRow).map((row) => row.id);
    const missingCountry = rows.filter(isMissingCountryRow).map((row) => row.id);
    return {
      missingNameCount: missingName.length,
      missingNameIds: missingName,
      missingStatusCount: missingStatus.length,
      missingStatusIds: missingStatus,
      missingQueueStatusCount: missingQueueStatus.length,
      missingQueueStatusIds: missingQueueStatus,
      missingCountryCount: missingCountry.length,
      missingCountryIds: missingCountry
    };
  }

  function logIncompleteRows(label, rows) {
    const summary = summarizeIncompleteRows(rows);
    const hasIncomplete = summary.missingNameCount > 0
      || summary.missingStatusCount > 0
      || summary.missingQueueStatusCount > 0
      || summary.missingCountryCount > 0;
    if (hasIncomplete) {
      console.log(`[airbnb-copy] ${label}`, summary);
    }
  }

  function applyRetryFieldCorrection(row, field, retryValue, attempt, correctedIds, logMessage) {
    if (!hasBlankField(row[field]) || hasBlankField(retryValue)) {
      return false;
    }
    const from = row[field];
    row[field] = retryValue;
    console.log(`[airbnb-copy] ${logMessage}`, {
      id: row.id,
      from,
      to: retryValue,
      attempt
    });
    correctedIds.push(row.id);
    return true;
  }

  function buildBaseVariables(clientB64, hostUserB64) {
    return {
      id: clientB64,
      filters: { hostUserID: hostUserB64 },
      first: PAGE_SIZE
    };
  }

  async function fetchAirbnbPage(variables) {
    const extensions = {
      persistedQuery: {
        version: 1,
        sha256Hash: "d7c68b3827775aec9c8fa11cea77977814a96ac84966673d3f037ee573e5052e"
      }
    };

    const url = `${API_BASE}?operationName=GetConnectedActivityListingsQuery&locale=en&currency=EUR&variables=${encodeURIComponent(JSON.stringify(variables))}&extensions=${encodeURIComponent(JSON.stringify(extensions))}`;
    const response = await fetch(url, {
      method: "GET",
      credentials: "include",
      headers: API_HEADERS
    });

    if (!response.ok) {
      const text = await response.text().catch(() => "");
      throw new Error(`API request failed: ${response.status} ${response.statusText}. ${text}`);
    }

    const json = await response.json();

    if (json.errors && Array.isArray(json.errors) && json.errors.length > 0) {
      throw new Error("GraphQL errors: " + JSON.stringify(json.errors));
    }

    return json;
  }

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async function fetchAllPaginatedListings(clientB64, hostUserB64, options = {}) {
    const {
      collectRetryData = false,
      validateTotalCount = true,
      logLabel = ""
    } = options;
    const logPrefix = logLabel ? `[airbnb-copy] ${logLabel}` : "[airbnb-copy]";
    const baseVariables = buildBaseVariables(clientB64, hostUserB64);
    const allRows = [];
    const retryById = new Map();
    const seenIds = new Set();
    let after = null;
    let page = 1;
    let expectedTotal = null;
    let nodesReceived = 0;
    const MAX_PAGES = 100;

    while (true) {
      if (page > MAX_PAGES) {
        throw new Error(`Airbnb API pagination exceeded maximum pages (${MAX_PAGES})`);
      }

      const variables = {
        ...baseVariables,
        filters: { ...baseVariables.filters }
      };
      if (after) {
        variables.after = after;
      }

      const json = await fetchAirbnbPage(variables);
      const connection = json?.data?.node?.connectedPartnerPortalActivityListings;
      if (!connection) {
        throw new Error("Response missing connectedPartnerPortalActivityListings");
      }

      const edges = connection.edges || [];
      const pageInfo = connection.pageInfo || {};

      if (expectedTotal === null && pageInfo.totalCount != null) {
        expectedTotal = pageInfo.totalCount;
      }

      const pageRows = [];
      let pageNodesReceived = 0;

      for (const edge of edges) {
        const node = edge?.node;
        if (!node) continue;

        pageNodesReceived++;
        const id = decodeListingId(node.id);

        if (collectRetryData && id) {
          retryById.set(id, buildRetryDataFromNode(node));
        }

        const row = mapNodeToListing(node);
        if (!row) continue;

        if (seenIds.has(row.id)) {
          console.warn(`${logPrefix} Duplicate listing ID: ${row.id} on page ${page}`);
        } else {
          seenIds.add(row.id);
        }

        pageRows.push(row);
      }

      nodesReceived += pageNodesReceived;
      allRows.push(...pageRows);

      console.log(`${logPrefix} page ${page}`, {
        pageNodesReceived,
        pageRows: pageRows.length,
        totalRows: allRows.length,
        nodesReceived,
        totalCount: pageInfo.totalCount,
        startCursor: pageInfo.startCursor,
        endCursor: pageInfo.endCursor,
        hasNextPage: pageInfo.hasNextPage
      });

      if (!pageInfo.hasNextPage) {
        break;
      }

      if (!pageInfo.endCursor) {
        throw new Error("Airbnb API pagination expected endCursor but none was returned");
      }

      after = pageInfo.endCursor;
      page += 1;
    }

    if (allRows.length === 0) {
      throw new Error("zero listings found");
    }

    if (validateTotalCount && expectedTotal != null && nodesReceived !== expectedTotal) {
      console.error(`${logPrefix} Pagination count mismatch`, {
        nodesReceived,
        rowsNormalized: allRows.length,
        expectedTotal: expectedTotal,
        pagesFetched: page
      });
      throw new Error(`Airbnb API pagination incomplete: got ${nodesReceived} nodes, expected ${expectedTotal}`);
    }

    return { rows: allRows, retryById, expectedTotal, pagesFetched: page, nodesReceived };
  }

  function hasRowsNeedingRetry(notSynced, missingName, missingStatus, missingQueue, missingCountry) {
    return notSynced.length > 0
      || missingName.length > 0
      || missingStatus.length > 0
      || missingQueue.length > 0
      || missingCountry.length > 0;
  }

  function collectSuspiciousIds(notSynced, missingName, missingStatus, missingQueue, missingCountry) {
    return [...new Set(
      [...notSynced, ...missingName, ...missingStatus, ...missingQueue, ...missingCountry].map((row) => row.id)
    )];
  }

  async function verifySuspiciousRows(allRows, clientB64, hostUserB64) {
    const VERIFY_RETRY_DELAY_MS = 750;
    const MAX_VERIFY_RETRIES = 2;

    let notSyncedSuspicious = allRows.filter(isSuspiciousNotSyncedRow);
    let missingNameSuspicious = allRows.filter(isMissingNameRow);
    let missingStatusSuspicious = allRows.filter(isMissingStatusRow);
    let missingQueueSuspicious = allRows.filter(isMissingQueueStatusRow);
    let missingCountrySuspicious = allRows.filter(isMissingCountryRow);

    if (!hasRowsNeedingRetry(
      notSyncedSuspicious,
      missingNameSuspicious,
      missingStatusSuspicious,
      missingQueueSuspicious,
      missingCountrySuspicious
    )) {
      return;
    }

    console.log("[airbnb-copy] suspicious rows found", {
      notSyncedCount: notSyncedSuspicious.length,
      missingNameCount: missingNameSuspicious.length,
      missingStatusCount: missingStatusSuspicious.length,
      missingQueueStatusCount: missingQueueSuspicious.length,
      missingCountryCount: missingCountrySuspicious.length,
      ids: collectSuspiciousIds(
        notSyncedSuspicious,
        missingNameSuspicious,
        missingStatusSuspicious,
        missingQueueSuspicious,
        missingCountrySuspicious
      )
    });

    let lastRetryById = null;
    const syncCorrectedIds = [];
    const nameCorrectedIds = [];
    const statusCorrectedIds = [];
    const queueCorrectedIds = [];
    const countryCorrectedIds = [];

    for (let attempt = 1; attempt <= MAX_VERIFY_RETRIES; attempt++) {
      if (!hasRowsNeedingRetry(
        notSyncedSuspicious,
        missingNameSuspicious,
        missingStatusSuspicious,
        missingQueueSuspicious,
        missingCountrySuspicious
      )) {
        break;
      }

      console.log("[airbnb-copy] verifying suspicious rows with retry fetch", { attempt });
      await delay(VERIFY_RETRY_DELAY_MS);

      let retryById;
      try {
        const retryResult = await fetchAllPaginatedListings(clientB64, hostUserB64, {
          collectRetryData: true,
          validateTotalCount: false,
          logLabel: `retry-${attempt}`
        });
        retryById = retryResult.retryById;
        lastRetryById = retryById;
      } catch (retryError) {
        console.warn("[airbnb-copy] retry fetch failed, skipping verification", {
          attempt,
          error: retryError.message
        });
        break;
      }

      const stillNotSynced = [];
      for (const row of notSyncedSuspicious) {
        const retryData = retryById.get(row.id);
        if (retryData?.syncAvailability === true) {
          console.log("[airbnb-copy] corrected sync status after retry", {
            id: row.id,
            name: row.name,
            from: "NOT SYNCED",
            to: "SYNCED",
            attempt
          });
          row.apiSyncStatus = "SYNCED";
          syncCorrectedIds.push(row.id);
        } else {
          stillNotSynced.push(row);
        }
      }
      notSyncedSuspicious = stillNotSynced;

      const stillMissingName = [];
      for (const row of missingNameSuspicious) {
        const retryData = retryById.get(row.id);
        if (applyRetryFieldCorrection(
          row,
          "name",
          (retryData?.name || "").trim(),
          attempt,
          nameCorrectedIds,
          "corrected missing name after retry"
        )) {
          continue;
        }
        if (hasBlankName(row)) {
          stillMissingName.push(row);
        }
      }
      missingNameSuspicious = stillMissingName;

      const stillMissingStatus = [];
      for (const row of missingStatusSuspicious) {
        const retryData = retryById.get(row.id);
        if (applyRetryFieldCorrection(
          row,
          "status",
          retryData?.status,
          attempt,
          statusCorrectedIds,
          "corrected missing status after retry"
        )) {
          continue;
        }
        if (isMissingStatusRow(row)) {
          stillMissingStatus.push(row);
        }
      }
      missingStatusSuspicious = stillMissingStatus;

      const stillMissingQueue = [];
      for (const row of missingQueueSuspicious) {
        const retryData = retryById.get(row.id);
        if (applyRetryFieldCorrection(
          row,
          "vettingQueueStatus",
          retryData?.vettingQueueStatus,
          attempt,
          queueCorrectedIds,
          "corrected missing queue status after retry"
        )) {
          continue;
        }
        if (isMissingQueueStatusRow(row)) {
          stillMissingQueue.push(row);
        }
      }
      missingQueueSuspicious = stillMissingQueue;

      const stillMissingCountry = [];
      for (const row of missingCountrySuspicious) {
        const retryData = retryById.get(row.id);
        if (applyRetryFieldCorrection(
          row,
          "country",
          retryData?.country,
          attempt,
          countryCorrectedIds,
          "corrected missing country after retry"
        )) {
          continue;
        }
        if (isMissingCountryRow(row)) {
          stillMissingCountry.push(row);
        }
      }
      missingCountrySuspicious = stillMissingCountry;
    }

    for (const row of notSyncedSuspicious) {
      const retryData = lastRetryById?.get(row.id);
      console.log("[airbnb-copy] still not synced after retry", {
        id: row.id,
        name: row.name,
        apiData: retryData?.apiData ?? null
      });
    }

    for (const row of missingNameSuspicious) {
      if (hasBlankName(row)) {
        console.warn("[airbnb-copy] still missing name after retry", { id: row.id });
      }
    }

    for (const row of missingStatusSuspicious) {
      if (isMissingStatusRow(row)) {
        console.warn("[airbnb-copy] still missing status after retry", { id: row.id });
      }
    }

    for (const row of missingQueueSuspicious) {
      if (isMissingQueueStatusRow(row)) {
        console.warn("[airbnb-copy] still missing queue status after retry", { id: row.id });
      }
    }

    for (const row of missingCountrySuspicious) {
      if (isMissingCountryRow(row)) {
        console.warn("[airbnb-copy] still missing country after retry", { id: row.id });
      }
    }

    if (syncCorrectedIds.length > 0
      || nameCorrectedIds.length > 0
      || statusCorrectedIds.length > 0
      || queueCorrectedIds.length > 0
      || countryCorrectedIds.length > 0) {
      console.log("[airbnb-copy] Retry corrections applied", {
        syncCount: syncCorrectedIds.length,
        syncIds: syncCorrectedIds,
        nameCount: nameCorrectedIds.length,
        nameIds: nameCorrectedIds,
        statusCount: statusCorrectedIds.length,
        statusIds: statusCorrectedIds,
        queueCount: queueCorrectedIds.length,
        queueIds: queueCorrectedIds,
        countryCount: countryCorrectedIds.length,
        countryIds: countryCorrectedIds
      });
    }
  }

  async function fetchActivityListingsViaApi() {
    const clientB64 = parseClientIdFromUrl();
    const hostUserB64 = parseHostUserIdFromUrl();

    const { rows: allRows, expectedTotal, pagesFetched, nodesReceived } = await fetchAllPaginatedListings(
      clientB64,
      hostUserB64
    );

    console.log("[airbnb-copy] API nodes received", {
      nodesReceived,
      expectedTotal
    });

    logIncompleteRows("incomplete rows after initial fetch", allRows);

    await verifySuspiciousRows(allRows, clientB64, hostUserB64);

    logIncompleteRows("incomplete rows after retry", allRows);

    console.log("[airbnb-copy] API extraction completed", {
      rowsCopied: allRows.length,
      nodesReceived,
      expectedTotal: expectedTotal,
      pagesFetched: pagesFetched
    });

    return allRows;
  }

  async function extractActivityListings() {
    console.log("[airbnb-copy] Using API extraction");
    try {
      const rows = await fetchActivityListingsViaApi();
      console.log("[airbnb-copy] API extraction succeeded");
      return { rows, source: "api" };
    } catch (apiError) {
      console.warn("[airbnb-copy] Falling back to DOM extraction:", apiError.message);
      const rows = await scrapeActivityListings();
      console.log("[airbnb-copy] DOM extraction succeeded");
      return { rows, source: "dom" };
    }
  }

  // Activity listings data extraction functions
  function scrapeCurrentPage() {
    const result = [];
    
    console.log("[activity-listings] Scraping current page...");
    
    // Find the table container
    const tableContainer = document.querySelector('[role="table"][aria-label="Activity listings"]');
    if (!tableContainer) {
      console.warn("[activity-listings] Activity listings table not found");
      return null;
    }
    
    // Find all data rows (skip header row)
    const rows = tableContainer.querySelectorAll('[role="row"]');
    console.log(`[activity-listings] Found ${rows.length} total rows on current page`);
    
    // Process each row (skip first row which is the header)
    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const cells = row.querySelectorAll('[role="cell"]');
      
      if (cells.length >= 7) { // Make sure we have enough cells
        // Extract data from specific columns
        // Column mapping: 0=ID, 1=Name, 2=Owner ID (skip), 3=Status, 4=API Sync Status, 5=Vetting queue status, 6=Country, 7=Product type (skip), 8=Last updated (skip)
        
        const id = extractCellText(cells[0]);
        const name = extractCellText(cells[1]);
        const status = extractCellText(cells[3]);
        const apiSyncStatus = extractCellText(cells[4]);
        const vettingQueueStatus = extractCellText(cells[5]);
        const country = extractCellText(cells[6]);
        
        if (id && name) {
          result.push({
            id,
            name,
            status,
            apiSyncStatus,
            vettingQueueStatus,
            country
          });
          
          console.log(`[activity-listings] Extracted row ${i}: ID=${id}, Name=${name}`);
        } else {
          console.warn(`[activity-listings] Skipped row ${i} - missing required data`);
        }
      } else {
        console.warn(`[activity-listings] Skipped row ${i} - insufficient cells (${cells.length})`);
      }
    }
    
    console.log(`[activity-listings] Successfully extracted ${result.length} activity listings from current page`);
    return result;
  }

  function hasPreviousPage() {
    const prevButton = document.querySelector('button[data-testid="previous_page"]');
    if (!prevButton) {
      console.log("[activity-listings] No previous page button found");
      return false;
    }
    
    // Check if button is disabled
    const isDisabled = prevButton.disabled || prevButton.hasAttribute('disabled') || 
                      prevButton.getAttribute('aria-disabled') === 'true';
    
    console.log(`[activity-listings] Previous page button found, disabled: ${isDisabled}`);
    return !isDisabled;
  }

  function clickPreviousPage() {
    const prevButton = document.querySelector('button[data-testid="previous_page"]');
    if (!prevButton) {
      console.warn("[activity-listings] Previous page button not found");
      return false;
    }
    
    console.log("[activity-listings] Clicking previous page button...");
    prevButton.click();
    return true;
  }

  function hasNextPage() {
    const nextButton = document.querySelector('button[data-testid="next_page"]');
    if (!nextButton) {
      console.log("[activity-listings] No next page button found");
      return false;
    }
    
    // Check if button is disabled
    const isDisabled = nextButton.disabled || nextButton.hasAttribute('disabled') || 
                      nextButton.getAttribute('aria-disabled') === 'true';
    
    console.log(`[activity-listings] Next page button found, disabled: ${isDisabled}`);
    return !isDisabled;
  }

  function clickNextPage() {
    const nextButton = document.querySelector('button[data-testid="next_page"]');
    if (!nextButton) {
      console.warn("[activity-listings] Next page button not found");
      return false;
    }
    
    console.log("[activity-listings] Clicking next page button...");
    nextButton.click();
    return true;
  }

  function waitForPageLoad() {
    return new Promise((resolve) => {
      // Wait for the page to finish loading/updating
      setTimeout(() => {
        console.log("[activity-listings] Page load wait completed");
        resolve();
      }, 2000); // Wait 2 seconds for page transition
    });
  }

  async function navigateToFirstPage() {
    console.log("[activity-listings] Checking if we need to navigate to first page...");
    
    let attempts = 0;
    const maxAttempts = 50; // Safety limit to prevent infinite loops
    
    while (hasPreviousPage() && attempts < maxAttempts) {
      console.log(`[activity-listings] Found previous page button, going back (attempt ${attempts + 1})...`);
      
      if (!clickPreviousPage()) {
        console.error("[activity-listings] Failed to click previous page button");
        break;
      }
      
      // Wait for page to load
      await waitForPageLoad();
      attempts++;
    }
    
    if (attempts === 0) {
      console.log("[activity-listings] Already on first page");
    } else if (attempts >= maxAttempts) {
      console.warn(`[activity-listings] Reached maximum attempts (${maxAttempts}) while navigating to first page`);
    } else {
      console.log(`[activity-listings] Successfully navigated to first page after ${attempts} steps`);
    }
    
    return true;
  }

  async function scrapeActivityListings() {
    const allResults = [];
    let currentPage = 1;
    const maxPages = 50; // Safety limit to prevent infinite loops
    
    console.log("[activity-listings] Starting to scrape activity listings with pagination...");
    
    try {
      // First, navigate to the first page to ensure we capture all data
      await navigateToFirstPage();
      
      do {
        console.log(`[activity-listings] Scraping page ${currentPage}...`);
        
        // Scrape current page
        const pageResults = scrapeCurrentPage();
        if (!pageResults) {
          console.error("[activity-listings] Failed to scrape current page");
          break;
        }
        
        if (pageResults.length === 0) {
          console.log("[activity-listings] No data found on current page, stopping");
          break;
        }
        
        // Add results from this page
        allResults.push(...pageResults);
        console.log(`[activity-listings] Page ${currentPage}: Added ${pageResults.length} items (total: ${allResults.length})`);
        
        // Check if there's a next page
        if (!hasNextPage()) {
          console.log("[activity-listings] No more pages available");
          break;
        }
        
        // Safety check
        if (currentPage >= maxPages) {
          console.warn(`[activity-listings] Reached maximum page limit (${maxPages}), stopping`);
          break;
        }
        
        // Go to next page
        if (!clickNextPage()) {
          console.error("[activity-listings] Failed to click next page");
          break;
        }
        
        // Wait for page to load
        await waitForPageLoad();
        currentPage++;
        
      } while (true);
      
    } catch (error) {
      console.error("[activity-listings] Error during pagination:", error);
    }
    
    console.log(`[activity-listings] Pagination complete. Scraped ${currentPage} pages with ${allResults.length} total items`);
    return allResults;
  }
  
  function extractCellText(cell) {
    if (!cell) return '';
    
    // Try to get text from links first
    const link = cell.querySelector('a');
    if (link) {
      return link.textContent.trim();
    }
    
    // Try to get text from spans with status indicators
    const statusSpan = cell.querySelector('span[class*="b16ycy69"] span:last-child');
    if (statusSpan) {
      return statusSpan.textContent.trim();
    }
    
    // Try to get text from div containers (for country codes)
    const divText = cell.querySelector('div');
    if (divText) {
      return divText.textContent.trim();
    }
    
    // Fall back to cell text content
    return cell.textContent.trim();
  }
  
  function formatAsCSV(data) {
    if (!data || data.length === 0) {
      return '';
    }
    
    // TSV headers for Google Sheets compatibility
    const headers = ['ID', 'Name', 'Status', 'API Sync Status', 'Vetting queue status', 'Country'];
    
    // Start with headers (using tabs for Google Sheets)
    const csvLines = [headers.join('\t')];
    
    // Add data rows (using tabs for Google Sheets)
    data.forEach(item => {
      const row = [
        escapeTsvField(item.id),
        escapeTsvField(item.name),
        escapeTsvField(item.status),
        escapeTsvField(item.apiSyncStatus),
        escapeTsvField(item.vettingQueueStatus),
        escapeTsvField(item.country)
      ];
      csvLines.push(row.join('\t'));
    });
    
    return csvLines.join('\n');
  }
  
  function escapeTsvField(field) {
    if (!field) return '';
    
    // Convert to string and trim
    const str = String(field).trim();
    
    // For TSV, replace tabs, newlines, and carriage returns with spaces
    return str.replace(/[\t\n\r]/g, ' ');
  }
  
  // Note: Clipboard copying moved to popup due to focus requirements

  // Message handling for Activity Listings actions
  function handleMessage(req, sender, sendResponse) {
    console.log("[activity-listings] Message received:", req);

    if (req.action === "runActivityListingsExtract") {
      extractActivityListings()
        .then(({ rows, source }) => {
          if (!rows || rows.length === 0) {
            sendResponse({ 
              success: false, 
              error: "No Airbnb listings found. Open the Activity Listings diagnostics page and try again." 
            });
            return;
          }
          
          const csvData = formatAsCSV(rows);
          
          sendResponse({ 
            success: true, 
            rows: rows,
            csvData: csvData,
            count: rows.length,
            source: source
          });
        })
        .catch(error => {
          console.error("[activity-listings] Error during extraction:", error);
          sendResponse({ 
            success: false, 
            error: "An error occurred while extracting activity listings: " + error.message 
          });
        });
      
      return true; // Indicates we will send response asynchronously
    }

    return false; // Not handled by this module
  }

  // Export the module
  window.ActivityListings = {
    handleMessage,
    extractActivityListings,
    fetchActivityListingsViaApi,
    scrapeActivityListings,
    scrapeCurrentPage,
    formatAsCSV,
    hasPreviousPage,
    clickPreviousPage,
    hasNextPage,
    clickNextPage,
    navigateToFirstPage
  };

  console.log("[activity-listings] Module initialized successfully");

})(); // End of initialization function
