console.log("[expedia-mapping] expedia-mapping.js loaded");

// Wait for utilities to be available and initialize module
(function initializeExpediaMapping() {
  // Wait for FareHarborUtils to be available
  if (!window.FareHarborUtils) {
    setTimeout(initializeExpediaMapping, 10);
    return;
  }
  
  // Now utilities are available, set up the module
  const utils = window.FareHarborUtils;
  const trimItemDisplayText = (text) => utils.trimFareHarborItemDisplayText(text);

  // Function to reorder customer types according to GetYourGuide priority
  function reorderCustomerTypes(customerTypes) {
    if (!customerTypes || customerTypes.length === 0) {
      return customerTypes;
    }
    
    // Define the priority order (case-insensitive)
    const priorityOrder = [
      'Adult',
      'Child', 
      'Youth',
      'Infant',
      'Senior',
      'Student',
      'EU Citizen',
      'EU Citizen Student',
      'Military',
      'Group'
    ];
    
    // Convert priority order to lowercase for case-insensitive comparison
    const priorityOrderLower = priorityOrder.map(type => type.toLowerCase());
    
    // Separate known and unknown customer types
    const knownTypes = [];
    const unknownTypes = [];
    
    customerTypes.forEach(customerType => {
      const lowerCaseType = customerType.toLowerCase();
      const priorityIndex = priorityOrderLower.indexOf(lowerCaseType);
      
      if (priorityIndex !== -1) {
        // Known type - store with its priority index and original case
        knownTypes.push({
          original: customerType,
          priority: priorityIndex
        });
      } else {
        // Unknown type - will be sorted alphabetically
        unknownTypes.push(customerType);
      }
    });
    
    // Sort known types by priority order
    knownTypes.sort((a, b) => a.priority - b.priority);
    
    // Sort unknown types alphabetically (case-insensitive)
    unknownTypes.sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));
    
    // Combine known types (in priority order) + unknown types (alphabetically)
    const reorderedTypes = [
      ...knownTypes.map(item => item.original),
      ...unknownTypes
    ];
    
    return reorderedTypes;
  }

  // Function to parse time strings and convert to 24-hour format for sorting
  function parseTimeToMinutes(timeStr) {
    if (!timeStr) return -1;
    
    const cleanTime = timeStr.trim().toLowerCase();
    
    // Handle various time formats
    let hours = 0;
    let minutes = 0;
    
    // Match patterns: 07:00, 7:00, 7AM, 7am, 7:00am, 7:00 AM, 7
    const timePatterns = [
      // Military time: 07:00, 7:00, 23:30
      /^(\d{1,2}):(\d{2})$/,
      // AM/PM with colon: 7:00am, 12:30pm, 7:00 AM
      /^(\d{1,2}):(\d{2})\s*(am|pm)$/,
      // AM/PM without colon: 7am, 12pm, 7 AM
      /^(\d{1,2})\s*(am|pm)$/,
      // Just number: 7, 12 (assume hours)
      /^(\d{1,2})$/
    ];
    
    let matched = false;
    
    for (let i = 0; i < timePatterns.length; i++) {
      const pattern = timePatterns[i];
      const match = cleanTime.match(pattern);
      if (match) {
        hours = parseInt(match[1], 10);
        
        // Handle different patterns correctly
        let amPm = '';
        if (i === 0) {
          // Military time: 07:00, 7:00, 23:30 - no AM/PM
          minutes = parseInt(match[2], 10);
        } else if (i === 1) {
          // AM/PM with colon: 7:00am, 12:30pm, 7:00 AM
          minutes = parseInt(match[2], 10);
          amPm = match[3];
        } else if (i === 2) {
          // AM/PM without colon: 7am, 12pm, 7 AM
          minutes = 0; // No minutes specified
          amPm = match[2];
        } else if (i === 3) {
          // Just number: 7, 12 (assume hours, no AM/PM)
          minutes = 0;
        }
        
        // Handle AM/PM conversion
        if (amPm === 'pm' && hours !== 12) {
          hours += 12;
        } else if (amPm === 'am' && hours === 12) {
          hours = 0;
        }
        
        matched = true;
        break;
      }
    }
    
    if (!matched) {
      console.warn(`[expedia-mapping] Could not parse time format: "${timeStr}"`);
      return -1; // Will sort to the end
    }
    
    // Convert to total minutes for easy sorting
    const totalMinutes = hours * 60 + minutes;
    
    return totalMinutes;
  }

  // Function to sort times from earliest to latest
  function sortTimeEntries(timeEntries) {
    if (!timeEntries || timeEntries.length === 0) {
      return timeEntries;
    }
    
    // Create array with parsed times for sorting
    const entriesWithTimes = timeEntries.map(entry => {
      // Extract time from entry (could be string, array, or object)
      let timeStr = '';
      
      if (typeof entry === 'string') {
        timeStr = entry;
      } else if (Array.isArray(entry)) {
        timeStr = entry[0] || entry[1] || ''; // Try first, then second element
      } else if (typeof entry === 'object') {
        // Handle different object structures
        timeStr = entry.time || entry.tip || entry.timeStr || (entry.formatted && entry.time) || '';
      }
      
      return {
        original: entry,
        timeStr: timeStr,
        minutes: parseTimeToMinutes(timeStr)
      };
    });
    
    // Sort by parsed time, with unparseable times at the end
    entriesWithTimes.sort((a, b) => {
      if (a.minutes === -1 && b.minutes === -1) return 0;
      if (a.minutes === -1) return 1;
      if (b.minutes === -1) return -1;
      return a.minutes - b.minutes;
    });
    
    const sortedEntries = entriesWithTimes.map(item => item.original);
    
    return sortedEntries;
  }

  // Expedia data extraction functions
  function scrapeResellerOptions() {
    const result = [];

    // Each <tbody> represents one row
    const bodies = document.querySelectorAll('table.spreadsheet > tbody');

    bodies.forEach(tbody => {
      const tds = tbody.querySelectorAll('td');
      const time = tds[0]?.innerText.trim() || '';
      const code = tds[2]?.innerText.trim() || '';

      if (time && code) {
        result.push([time, code]);
      }
    });

    return result;
  }

  function scrapeCustomerTypes() {
    const result = [];

    const bodies = document.querySelectorAll('table.spreadsheet > tbody');

    bodies.forEach(tbody => {
      const tds = tbody.querySelectorAll('td');
      const name = tds[0]?.innerText.trim() || '';
      const externalId = tds[2]?.innerText.trim() || '';

      if (name && externalId) {
        result.push([name, externalId]);
      }
    });

    return result;
  }

  function getItemCode() {
    const link = utils.$(utils.SELECTORS.TABS_LINK);
    const match = link?.href.match(/\/items\/(\d+)\//);
    return match ? `ri${match[1]}` : null;
  }



  function getActivityName() {
    // Try multiple strategies to find the activity name
    
    // Strategy 1: Look for the activity name in the block-list element (with ng-binding)
    let activityLink = document.querySelector('a.block-list-content.ng-binding');
    if (activityLink) {
      return trimItemDisplayText(activityLink.textContent.trim());
    }
    
    // Strategy 2: Look for any block-list content element (fallback for different page structures)
    activityLink = document.querySelector('.block-list-content');
    if (activityLink) {
      return trimItemDisplayText(activityLink.textContent.trim());
    }
    
    // Strategy 3: Look in breadcrumb navigation
    const breadcrumb = document.querySelector('.breadcrumb a:last-child, .breadcrumbs a:last-child');
    if (breadcrumb) {
      return breadcrumb.textContent.trim();
    }
    
    // Strategy 4: Look for page title or main heading
    const pageTitle = document.querySelector('h1, h2, .page-title, .item-title');
    if (pageTitle) {
      const titleText = pageTitle.textContent.trim();
      // Remove common prefixes/suffixes
      const cleanTitle = titleText.replace(/^(Item:|Activity:)\s*/i, '').replace(/\s*-\s*\w+$/, '');
      return cleanTitle;
    }
    
    // Strategy 5: Extract from document title as last resort
    const docTitle = document.title;
    if (docTitle && !docTitle.includes('FareHarbor') && docTitle !== 'FareHarbor') {
      const match = docTitle.match(/^(.+?)\s*-\s*FareHarbor$/);
      return match ? match[1].trim() : docTitle.split(' - ')[0].trim();
    }
    
    console.warn('[expedia-mapping] Could not find activity name using any strategy');
    return '';
  }

  /** Available Times external identifiers (same source as Copy 1 item), chronologically sorted. */
  function collectSortedResellerTimeIdentifiers() {
    const tables = utils.$$(utils.SELECTORS.SPREADSHEET_TABLE);
    const resellerTable = tables.find(t => {
      const header = t.querySelector('thead')?.innerText || '';
      return header.includes('External Identifier') && !header.includes('Customer Types Used');
    });

    const timeEntries = [];
    const resellerBodies = resellerTable?.querySelectorAll('tbody') || [];
    resellerBodies.forEach(tbody => {
      const tds = tbody.querySelectorAll('td');
      const time = tds[0]?.innerText.trim();
      const optionCode = tds[2]?.innerText.trim();
      if (time && optionCode) {
        timeEntries.push([time, optionCode]);
      }
    });

    return sortTimeEntries(timeEntries);
  }

  function scrapeCombinedData() {
    const result = [];
    const itemCode = getItemCode();
    const activityName = getActivityName();

    if (!itemCode) {
      console.warn("[expedia-mapping] Item code not found");
      return null;
    }

    // Add the "Activity" row with activity name
    result.push(['Activity', activityName, itemCode]);

    const sortedTimeEntries = collectSortedResellerTimeIdentifiers();
    sortedTimeEntries.forEach(([time, optionCode]) => {
      result.push(['Offer', time, optionCode]);
    });

    const tables = utils.$$(utils.SELECTORS.SPREADSHEET_TABLE);

    // 🔹 Customer Types Table - collect customer types first for reordering
    const customerTypesTable = tables.find(t => {
      const header = t.querySelector('thead')?.innerText || '';
      return header.includes('Customer Types Used');
    });

    const customerTypeEntries = [];
    const customerBodies = customerTypesTable?.querySelectorAll('tbody') || [];
    customerBodies.forEach(tbody => {
      const tds = tbody.querySelectorAll('td');
      const name = tds[0]?.innerText.trim();
      const externalId = tds[2]?.innerText.trim();
      if (name && externalId) {
        customerTypeEntries.push([name, externalId]);
      }
    });

    // Reorder customer types according to priority
    const customerTypeNames = customerTypeEntries.map(([name]) => name);
    const reorderedNames = reorderCustomerTypes(customerTypeNames);
    
    // Rebuild entries in the correct order
    reorderedNames.forEach(name => {
      const entry = customerTypeEntries.find(([entryName]) => entryName === name);
      if (entry) {
        const [customerName, externalId] = entry;
        result.push(['TicketType', customerName, externalId]);
      }
    });

    return result;
  }

  function scrapeCompleteResellerItems() {
    console.log("[expedia-mapping] Starting complete reseller items extraction");
    
    // Find the main reseller items table
    const resellerTable = document.querySelector('table.spreadsheet.highlight-rows.white-bg');
    if (!resellerTable) {
      console.warn("[expedia-mapping] Reseller items table not found");
      return { success: false, error: "Reseller items table not found on this page" };
    }

    // Extract channel name and ID for header
    const channelHeader = document.querySelector('h1.test-header-channel-company-expedia, h1[data-test-id*="test-header-channel-company"]');
    const channelName = channelHeader ? channelHeader.textContent.trim() : 'Unknown Channel';
    
    // Extract channel ID from URL (e.g., /channels/939/ -> 939)
    const urlMatch = window.location.href.match(/\/channels\/(\d+)\//);
    const channelId = urlMatch ? urlMatch[1] : 'unknown';
    const channelInfo = `${channelName} rc${channelId}`;
    
    console.log(`[expedia-mapping] Channel header found:`, channelHeader);
    console.log(`[expedia-mapping] Channel name: "${channelName}"`);
    console.log(`[expedia-mapping] URL: ${window.location.href}`);
    console.log(`[expedia-mapping] Channel ID: ${channelId}`);
    console.log(`[expedia-mapping] Final channel info: "${channelInfo}"`);

    const result = [];
    
    // Get the base URL for creating full links
    const baseUrl = window.location.origin; // e.g., https://demo.fareharbor.com or https://fareharbor.com
    
    // Find all tbody elements (each represents one reseller item)
    const tbodies = resellerTable.querySelectorAll('tbody');
    console.log(`[expedia-mapping] Found ${tbodies.length} reseller items`);
    
    tbodies.forEach((tbody, index) => {
      const tds = tbody.querySelectorAll('td');
      
      if (tds.length < 6) {
        console.warn(`[expedia-mapping] Skipping row ${index} - insufficient columns`);
        return;
      }
      
      // Column 1: Name with href links (extract from aria-label of item link)
      const nameCell = tds[0];
      const itemNameFromCell = nameCell?.textContent?.trim() || '';
      
      // Extract href and proper name from item mappings (column 4, index 3)
      const itemMappingsCell = tds[3];
      const itemLink = itemMappingsCell?.querySelector('a');
      let nameWithLink = itemNameFromCell;
      let displayName = itemNameFromCell;
      
      if (itemLink) {
        const ariaLabel = itemLink.getAttribute('aria-label');
        if (ariaLabel) {
          displayName = ariaLabel;
        } else {
          const ngTip = itemLink.getAttribute('ng-tip');
          if (ngTip) {
            const itemId = itemLink.textContent?.trim() || '';
            displayName = `${ngTip} (${itemId})`;
          }
        }
      }

      if (displayName) {
        displayName = trimItemDisplayText(displayName);
        if (itemLink && itemLink.href) {
          const fullUrl = baseUrl + itemLink.getAttribute('href');
          nameWithLink = `<a href="${fullUrl}">${displayName}</a>`;
        } else {
          nameWithLink = displayName;
        }
      }
      
      // Column 2: External Identifier (from column 3, index 2)
      const externalIdCell = tds[2];
      const externalId = externalIdCell?.textContent?.trim() || '';
      
      // Column 3: Channel Options with ng-tip (make ro codes bold) - collect and sort by time
      const channelOptionsCell = tds[5];
      const rawChannelOptions = [];
      // Try both selectors for different environments
      let optionSpans = channelOptionsCell?.querySelectorAll('span.text-link.ng-binding');
      if (!optionSpans || optionSpans.length === 0) {
        optionSpans = channelOptionsCell?.querySelectorAll('span.text-link');
      }
      
      optionSpans?.forEach(span => {
        const code = span.textContent?.trim() || '';
        const tip = span.getAttribute('ng-tip') || '';
        if (code) {
          // Make codes starting with "ro" bold
          const formattedCode = code.startsWith('ro') ? `<strong>${code}</strong>` : code;
          rawChannelOptions.push({
            formatted: `${formattedCode} ${tip}`,
            time: tip, // Use ng-tip for time sorting
            code: code
          });
        }
      });
      
      // Sort channel options by time (earliest to latest)
      const sortedChannelOptions = sortTimeEntries(rawChannelOptions);
      const channelOptions = sortedChannelOptions.map(option => option.formatted);
      const channelOptionsText = channelOptions.join('\n');
      
      // Column 4: Channel Customer Types with ng-tip (make rct codes bold) - collect and reorder by priority
      const customerTypesCell = tds[4];
      const rawCustomerTypes = [];
      // Try both selectors for different environments
      let customerSpans = customerTypesCell?.querySelectorAll('span.text-link.ng-binding');
      if (!customerSpans || customerSpans.length === 0) {
        customerSpans = customerTypesCell?.querySelectorAll('span.text-link');
      }
      
      customerSpans?.forEach(span => {
        const code = span.textContent?.trim() || '';
        const tip = span.getAttribute('ng-tip') || '';
        if (code) {
          // Make codes starting with "rct" bold
          const formattedCode = code.startsWith('rct') ? `<strong>${code}</strong>` : code;
          rawCustomerTypes.push({
            formatted: `${formattedCode} (${tip})`,
            name: tip, // Use ng-tip for customer type reordering
            code: code
          });
        }
      });
      
      // Reorder customer types according to priority
      const customerTypeNames = rawCustomerTypes.map(ct => ct.name);
      const reorderedCustomerTypeNames = reorderCustomerTypes(customerTypeNames);
      
      // Rebuild customer types in the correct order
      const customerTypes = [];
      reorderedCustomerTypeNames.forEach(name => {
        const rawType = rawCustomerTypes.find(ct => ct.name === name);
        if (rawType) {
          customerTypes.push(rawType.formatted);
        }
      });
      
      const customerTypesText = customerTypes.join('\n');
      
      if (displayName) {
        result.push([nameWithLink, externalId, channelOptionsText, customerTypesText]);
        console.log(`[expedia-mapping] Extracted item: ${displayName} with external ID: ${externalId}, ${channelOptions.length} options and ${customerTypes.length} customer types`);
      }
    });
    
    console.log(`[expedia-mapping] Successfully extracted ${result.length} reseller items`);
    return { success: true, data: result, channelInfo: channelInfo };
  }

  function formatCompleteDataAsHTML(data, channelInfo = '') {
    if (!data || data.length === 0) {
      return '';
    }
    
    let html = `<table border="1" cellpadding="5" cellspacing="0">
<tbody>`;
    
    // Always add channel info header row first (even if empty, for debugging)
    const channelInfoRow = `
<tr>
<td colspan="4" style="text-align: center; font-weight: bold; background-color: #f0f0f0;">${channelInfo || 'Channel Info Not Found'}</td>
</tr>`;
    
    html += channelInfoRow;
    
    // Add column headers row second (using <td> instead of <th> to prevent Zendesk reordering)
    const headerRow = `
<tr>
<td style="font-weight: bold; background-color: #e8e8e8; text-align: center;">Name</td>
<td style="font-weight: bold; background-color: #e8e8e8; text-align: center;">External Identifier</td>
<td style="font-weight: bold; background-color: #e8e8e8; text-align: center;">Channel Options</td>
<td style="font-weight: bold; background-color: #e8e8e8; text-align: center;">Channel Customer Types</td>
</tr>`;
    
    html += headerRow;
    
    data.forEach(row => {
      const [name, externalId, options, customerTypes] = row;
      // Replace newlines with <br> tags for proper HTML display
      const optionsHtml = options.replace(/\n/g, '<br>');
      const customerTypesHtml = customerTypes.replace(/\n/g, '<br>');
      
      html += `
<tr>
<td>${name}</td>
<td>${externalId}</td>
<td>${optionsHtml}</td>
<td>${customerTypesHtml}</td>
</tr>`;
    });
    
    html += `
</tbody>
</table>`;
    
    return html;
  }

  function formatExpediaDataForClipboard(data) {
    let formattedText = "";

    (data || []).forEach((row) => {
      const [type, detail, code] = row;
      if (type === "Activity") {
        formattedText += `Activity: ${detail}\n`;
        formattedText += `Code: ${code}\n\n`;
      } else if (type === "Offer") {
        if (formattedText && !formattedText.includes("Available Times:")) {
          formattedText += "Available Times:\n";
        }
        formattedText += `- ${detail} (${code})\n`;
      } else if (type === "TicketType") {
        if (formattedText && !formattedText.includes("Ticket Types:")) {
          formattedText += "\nTicket Types:\n";
        }
        formattedText += `- ${detail} (${code})\n`;
      }
    });

    return formattedText;
  }

  function runSingleItemMappingCopy() {
    const data = scrapeCombinedData();
    if (!data || data.length === 0) {
      return {
        success: false,
        error: "No item mapping data found."
      };
    }

    return {
      success: true,
      outputText: formatExpediaDataForClipboard(data),
      count: data.length
    };
  }

  function copyToClipboard(data) {
    const formattedText = formatExpediaDataForClipboard(data);

    navigator.clipboard.writeText(formattedText)
      .then(() => console.log("Data copied to clipboard"))
      .catch(err => console.error("Clipboard copy failed", err));
  }

  // Message handling for Expedia-related actions
  function handleMessage(req, sender, sendResponse) {
    console.log("[expedia-mapping] Message received:", req);

    if (req.action === "runExtract") {
      const data = scrapeCombinedData();
      sendResponse({ data }); // Send it back to the popup
      return true;
    }

    if (req.action === "runExtractAllRoCodes") {
      if (!getItemCode()) {
        sendResponse({
          success: false,
          error: "No single item data found on this page. Make sure you're on a Expedia single item configuration page."
        });
        return true;
      }
      const sortedPairs = collectSortedResellerTimeIdentifiers();
      const seen = new Set();
      const codes = [];
      for (const [, code] of sortedPairs) {
        if (!seen.has(code)) {
          seen.add(code);
          codes.push(code);
        }
      }
      if (codes.length === 0) {
        sendResponse({
          success: false,
          error: "No Available Times external identifiers found on this page."
        });
        return true;
      }
      sendResponse({ success: true, text: codes.join('_') });
      return true;
    }

    if (req.action === "runCompleteExtract") {
      const extractResult = scrapeCompleteResellerItems();
      
      if (extractResult.success) {
        const htmlData = formatCompleteDataAsHTML(extractResult.data, extractResult.channelInfo);
        sendResponse({ 
          success: true, 
          htmlData: htmlData,
          count: extractResult.data.length 
        });
      } else {
        sendResponse({ 
          success: false, 
          error: extractResult.error || "Failed to extract reseller items" 
        });
      }
      return true;
    }

    return false; // Not handled by this module
  }

  // Export the module
  window.ExpediaMapping = {
    handleMessage,
    scrapeResellerOptions,
    scrapeCustomerTypes,
    getItemCode,
    getActivityName,
    collectSortedResellerTimeIdentifiers,
    scrapeCombinedData,
    scrapeCompleteResellerItems,
    formatCompleteDataAsHTML,
    formatExpediaDataForClipboard,
    runSingleItemMappingCopy,
    copyToClipboard
  };

  console.log("[expedia-mapping] Module initialized successfully");

})(); // End of initialization function