(function initializeItemMappingLinkCopy() {
  "use strict";

  if (!window.FareHarborUtils) {
    setTimeout(initializeItemMappingLinkCopy, 10);
    return;
  }

  const utils = window.FareHarborUtils;
  const DEBUG = false;
  const LOG_PREFIX = "[item-mapping-link-copy]";
  const INJECTED_ATTR = "data-fh-copy-item-mapping-links";
  const ACTIONS_BAR_ATTR = "data-fh-ext-item-mapping-actions";
  const ACTIONS_BAR_CLASS = "fh-ext-item-mapping-actions";
  const LINK_ACTION_CLASS = "fh-ext-link-action";
  const LINK_ACTION_LABEL_CLASS = "fh-ext-link-action-label";
  const SEPARATOR_CLASS = "fh-ext-action-separator";
  const STYLE_ID = "fh-ext-item-mapping-actions-styles";
  const ITEM_MAPPINGS_HEADING_RE = /^Item Mappings$/i;
  const SECTION_SELECTORS = [
    'div[ng-can-list="ResellerItemMapping on company"]',
    'div[ng-controller="dashboard.settings.reseller.ResellerItemMappingsCtrl"]'
  ];
  const LINK_SELECTOR = "a.block-list-content[href]";
  const SCAN_DEBOUNCE_MS = 300;
  const FEEDBACK_MS = 2000;
  const ROUTE_REEVAL_DELAY_MS = 150;
  const ROUTE_POLL_MS = 500;
  const CHANNEL_ITEM_PATH_RE =
    /\/dashboard\/settings\/integrations\/channels\/[^/]+\/items\/[^/]+/;

  if (DEBUG) {
    console.log("[item-mapping-link-copy] item-mapping-link-copy.js loaded");
  }

  let observer = null;
  let debounceTimer = null;
  let copyInProgress = false;
  let hrefPollTimer = null;
  let lastTrackedHref = location.href;
  let lifecycleEvalTimer = null;
  let watchersActive = false;
  let routeWatchersStarted = false;
  let lastScanCache = null;
  const loggedInsertions = new Set();

  function log(...args) {
    if (DEBUG) {
      console.log(LOG_PREFIX, ...args);
    }
  }

  function warn(...args) {
    console.warn(LOG_PREFIX, ...args);
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function isChannelItemPath() {
    if (!isFareHarborHost()) {
      return false;
    }
    return CHANNEL_ITEM_PATH_RE.test((location.pathname || "").replace(/\/+$/, ""));
  }

  function hasItemMappingsDomMarkers() {
    return findItemMappingsSections().length > 0;
  }

  function isPageEligibleForItemLinkCopy() {
    if (!isFareHarborHost()) {
      return false;
    }
    if (isChannelItemPath()) {
      return true;
    }
    return hasItemMappingsDomMarkers();
  }

  function normalizeVisibleText(text) {
    return String(text || "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function isExtensionNode(node) {
    if (!node) {
      return false;
    }
    if (node.nodeType === Node.TEXT_NODE) {
      return isExtensionNode(node.parentElement);
    }
    if (!(node instanceof Element)) {
      return false;
    }
    if (node.id === STYLE_ID) {
      return true;
    }
    if (
      node.getAttribute(INJECTED_ATTR) === "true" ||
      node.getAttribute(ACTIONS_BAR_ATTR) === "true" ||
      node.getAttribute("data-fh-copy-item-mapping-data") === "true" ||
      node.getAttribute("data-fh-ext-copy-item-button") === "true" ||
      node.hasAttribute("data-fhx-mapping-copy-btn") ||
      node.hasAttribute("data-fhx-copy-item-mapping-btn")
    ) {
      return true;
    }
    if (
      node.classList?.contains(ACTIONS_BAR_CLASS) ||
      node.classList?.contains(LINK_ACTION_CLASS) ||
      node.classList?.contains(SEPARATOR_CLASS) ||
      node.classList?.contains("fhx-mapping-copy-toolbar-control") ||
      node.classList?.contains("fhx-mapping-copy-status")
    ) {
      return true;
    }
    return !!node.closest?.(
      `[${INJECTED_ATTR}="true"], [${ACTIONS_BAR_ATTR}="true"], .${ACTIONS_BAR_CLASS}, [data-fh-copy-item-mapping-data="true"], .fhx-mapping-copy-toolbar-control, #fh-ext-copy-item-mapping-button, #fh-ext-copy-mapping-button`
    );
  }

  function isExtensionMutation(mutation) {
    if (isExtensionNode(mutation.target)) {
      return true;
    }
    for (const node of mutation.addedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    for (const node of mutation.removedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    return false;
  }

  function getScanSnapshot() {
    const sections = findItemMappingsSections();
    const linkCounts = sections.map((section) => collectItemMappingLinks(section).length);
    let allButtonsPresent = sections.length > 0;

    for (const section of sections) {
      const bar = section.querySelector(`[${ACTIONS_BAR_ATTR}="true"]`);
      const button = bar?.querySelector(`[${INJECTED_ATTR}="true"]`);
      if (!button) {
        allButtonsPresent = false;
        break;
      }
    }

    return {
      href: location.href,
      sectionCount: sections.length,
      linkCounts: linkCounts.join(","),
      buttonsPresent: allButtonsPresent
    };
  }

  function scanSnapshotUnchanged(snapshot) {
    if (!lastScanCache || !snapshot.buttonsPresent) {
      return false;
    }
    return (
      lastScanCache.href === snapshot.href &&
      lastScanCache.sectionCount === snapshot.sectionCount &&
      lastScanCache.linkCounts === snapshot.linkCounts &&
      lastScanCache.buttonsPresent === snapshot.buttonsPresent
    );
  }

  function resetScanState() {
    lastScanCache = null;
    loggedInsertions.clear();
  }

  function logInsertionOnce(key, message, data) {
    if (loggedInsertions.has(key)) {
      return;
    }
    loggedInsertions.add(key);
    console.log(LOG_PREFIX, message, data ?? "");
  }

  function getButtonLabel(linkCount) {
    return linkCount === 1 ? "Copy link" : "Copy links";
  }

  function resolveSectionRoot(root) {
    if (root.matches('[ng-can-list="ResellerItemMapping on company"]')) {
      return root;
    }
    return (
      root.querySelector('div[ng-can-list="ResellerItemMapping on company"]') || root
    );
  }

  function isFeedbackLabel(label) {
    return label === "Copied!" || label === "Copy failed";
  }

  function createActionIcon(pathD) {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    svg.setAttribute("aria-hidden", "true");
    svg.setAttribute("focusable", "false");
    svg.setAttribute("viewBox", "0 0 14 14");
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("fill", "currentColor");
    path.setAttribute("d", pathD);
    svg.appendChild(path);
    return svg;
  }

  function createLinkIcon() {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    svg.setAttribute("aria-hidden", "true");
    svg.setAttribute("focusable", "false");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("fill", "none");
    svg.setAttribute("stroke", "currentColor");
    svg.setAttribute("stroke-width", "2");
    svg.setAttribute("stroke-linecap", "round");
    svg.setAttribute("stroke-linejoin", "round");
    svg.setAttribute("data-fh-icon", "link-v2");

    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute(
      "d",
      "M13.828 10.172a4 4 0 0 0-5.656 0l-4 4a4 4 0 1 0 5.656 5.656l1.102-1.101m-.758-4.899a4 4 0 0 1 5.656 0l4-4a4 4 0 0 0-5.656-5.656l-1.1 1.1"
    );
    svg.appendChild(path);
    return svg;
  }

  function createClipboardIcon() {
    const svg = createActionIcon(
      "M4.88 1.13a.63.63 0 0 1 .62-.63h2.75a.63.63 0 0 1 .62.63V2.5h1.38A1.38 1.38 0 0 1 11.63 3.88v7.25A1.38 1.38 0 0 1 10.25 12.5H3.75A1.38 1.38 0 0 1 2.38 11.13V3.88A1.38 1.38 0 0 1 3.75 2.5H5.13V1.13ZM5.5 2.5V1.75h2.75V2.5H5.5ZM3.75 3.25c-.42 0-.75.33-.75.75v7.25c0 .42.33.75.75.75h6.5c.42 0 .75-.33.75-.75V4c0-.42-.33-.75-.75-.75H9.25v.63a.63.63 0 0 1-.62.62H5.38a.63.63 0 0 1-.62-.62V3.25H3.75Z"
    );
    svg.setAttribute("data-fh-icon", "clipboard-v1");
    return svg;
  }

  function getLinkActionLabel(button) {
    const labelEl = button?.querySelector(`.${LINK_ACTION_LABEL_CLASS}`);
    if (labelEl) {
      return labelEl.textContent;
    }
    return button?.textContent || "";
  }

  function setLinkActionLabel(button, label) {
    const labelEl = button?.querySelector(`.${LINK_ACTION_LABEL_CLASS}`);
    if (labelEl) {
      labelEl.textContent = label;
      return;
    }
    if (button) {
      button.textContent = label;
    }
  }

  function ensureLinkActionButtonStructure(button, label, iconCreator) {
    if (!button) {
      return;
    }

    const newIcon = iconCreator();
    const iconKey = newIcon.getAttribute("data-fh-icon");
    const existingSvg = button.querySelector("svg");
    if (!existingSvg || existingSvg.getAttribute("data-fh-icon") !== iconKey) {
      if (existingSvg) {
        existingSvg.replaceWith(newIcon);
      } else {
        button.prepend(newIcon);
      }
    }

    let labelEl = button.querySelector(`.${LINK_ACTION_LABEL_CLASS}`);
    if (!labelEl) {
      const existingText = normalizeVisibleText(button.textContent);
      button.textContent = "";
      if (!button.querySelector("svg")) {
        button.prepend(iconCreator());
      }
      labelEl = document.createElement("span");
      labelEl.className = LINK_ACTION_LABEL_CLASS;
      button.appendChild(labelEl);
      labelEl.textContent = label || existingText;
      return;
    }

    labelEl.textContent = label;
  }

  function trimLinkText(rawText) {
    return utils.trimFareHarborItemDisplayText(normalizeVisibleText(rawText));
  }

  function escapeHtml(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function escapeHtmlAttr(text) {
    return escapeHtml(text).replace(/'/g, "&#39;");
  }

  function collectItemMappingLinks(section) {
    const links = [];

    section.querySelectorAll(LINK_SELECTOR).forEach((anchor) => {
      const href = anchor.href;
      if (!href) {
        return;
      }

      const text = trimLinkText(anchor.textContent);
      if (!text) {
        return;
      }

      links.push({ href, text });
    });

    return links;
  }

  function formatClipboardContent(links) {
    const html = links
      .map(
        (link) =>
          `<a href="${escapeHtmlAttr(link.href)}">${escapeHtml(link.text)}</a>`
      )
      .join("<br>");
    const plain = links.map((link) => link.text).join("\n");
    return { html, plain };
  }

  async function writeRichClipboard(html, plain) {
    try {
      const item = new ClipboardItem({
        "text/html": new Blob([html], { type: "text/html" }),
        "text/plain": new Blob([plain], { type: "text/plain" })
      });
      await navigator.clipboard.write([item]);
      return true;
    } catch (err) {
      try {
        await navigator.clipboard.writeText(plain);
        return true;
      } catch (fallbackErr) {
        warn("Clipboard copy failed:", err, fallbackErr);
        return false;
      }
    }
  }

  function findItemMappingsSections() {
    const sections = [];
    const seen = new Set();

    for (const selector of SECTION_SELECTORS) {
      for (const root of document.querySelectorAll(selector)) {
        if (seen.has(root)) {
          continue;
        }

        const header = root.querySelector(".reseller-header");
        const heading = header?.querySelector("h2");
        if (
          !heading ||
          !ITEM_MAPPINGS_HEADING_RE.test(normalizeVisibleText(heading.textContent))
        ) {
          continue;
        }

        const sectionRoot = resolveSectionRoot(root);
        if (seen.has(sectionRoot)) {
          continue;
        }

        seen.add(sectionRoot);
        sections.push(sectionRoot);
      }
    }

    return sections;
  }

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) {
      return;
    }

    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .fh-ext-item-mapping-actions {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-top: 10px;
        padding-top: 8px;
        position: relative;
        flex-wrap: wrap;
      }
      .fh-ext-link-action {
        appearance: none;
        -webkit-appearance: none;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: transparent;
        border: 0;
        padding: 0;
        margin: 0;
        color: #5f7f99;
        font-size: 13px;
        font-weight: 600;
        line-height: 1.4;
        cursor: pointer;
        font-family: inherit;
        box-shadow: none;
        white-space: nowrap;
      }
      .fh-ext-link-action svg {
        width: 15px;
        height: 15px;
        flex-shrink: 0;
        color: inherit;
      }
      .fh-ext-link-action:hover:not(:disabled) {
        color: #315f7c;
        text-decoration: none;
      }
      .fh-ext-link-action:hover:not(:disabled) .fh-ext-link-action-label {
        text-decoration: underline;
      }
      .fh-ext-link-action:disabled {
        opacity: 0.6;
        cursor: default;
      }
      .fh-ext-action-separator {
        color: #9aa8b3;
        user-select: none;
      }
      .fh-ext-item-mapping-actions .fhx-mapping-copy-status {
        position: absolute;
        top: calc(100% + 2px);
        left: 0;
        right: auto;
      }
    `;
    document.documentElement.appendChild(style);
  }

  function ensureActionsBar(section) {
    const blockList = section.querySelector("ul.block-list");
    let bar = section.querySelector(`[${ACTIONS_BAR_ATTR}="true"]`);

    if (!bar) {
      bar = document.createElement("div");
      bar.className = ACTIONS_BAR_CLASS;
      bar.setAttribute(ACTIONS_BAR_ATTR, "true");
    }

    if (blockList) {
      if (blockList.nextElementSibling !== bar) {
        blockList.insertAdjacentElement("afterend", bar);
      }
    } else if (!section.contains(bar)) {
      section.appendChild(bar);
    }

    return bar;
  }

  function syncActionsBarLayout(section) {
    const bar = section.querySelector(`[${ACTIONS_BAR_ATTR}="true"]`);
    if (!bar) {
      return null;
    }

    const linkBtn = bar.querySelector(`[${INJECTED_ATTR}="true"]`);
    const dataBtn = bar.querySelector('[data-fh-copy-item-mapping-data="true"]');
    const statusEl = bar.querySelector(".fhx-mapping-copy-status");
    let separator = bar.querySelector(`.${SEPARATOR_CLASS}`);

    if (!linkBtn && !dataBtn) {
      bar.remove();
      return null;
    }

    const ordered = [];
    if (linkBtn) {
      ordered.push(linkBtn);
    }

    if (linkBtn && dataBtn) {
      if (!separator) {
        separator = document.createElement("span");
        separator.className = SEPARATOR_CLASS;
        separator.setAttribute("aria-hidden", "true");
        separator.textContent = "·";
      }
      ordered.push(separator);
    } else if (separator) {
      separator.remove();
      separator = null;
    }

    if (dataBtn) {
      ordered.push(dataBtn);
    }

    ordered.forEach((node) => {
      bar.appendChild(node);
    });

    if (statusEl) {
      bar.appendChild(statusEl);
    }

    return bar;
  }

  function cleanupStaleActions(validSections) {
    document.querySelectorAll(`[${ACTIONS_BAR_ATTR}="true"]`).forEach((bar) => {
      const inValidSection = validSections.some((section) => section.contains(bar));
      if (!inValidSection) {
        bar.remove();
      }
    });

    document.querySelectorAll(`[${INJECTED_ATTR}="true"]`).forEach((button) => {
      const inValidSection = validSections.some((section) => section.contains(button));
      if (!inValidSection) {
        button.remove();
      }
    });

    validSections.forEach((section) => {
      syncActionsBarLayout(section);
    });
  }

  function ensureCopyButton(section) {
    const links = collectItemMappingLinks(section);
    const label = getButtonLabel(links.length);
    const bar = ensureActionsBar(section);
    let button = bar.querySelector(`[${INJECTED_ATTR}="true"]`);
    let inserted = false;

    if (button) {
      if (!copyInProgress && !isFeedbackLabel(getLinkActionLabel(button))) {
        setLinkActionLabel(button, label);
      }
      ensureLinkActionButtonStructure(button, getLinkActionLabel(button), createLinkIcon);
      syncActionsBarLayout(section);
      return { button, bar, inserted: false };
    }

    if (!section.querySelector(".reseller-header")) {
      return null;
    }

    button = document.createElement("button");
    button.type = "button";
    button.className = LINK_ACTION_CLASS;
    button.setAttribute(INJECTED_ATTR, "true");
    ensureLinkActionButtonStructure(button, label, createLinkIcon);
    button.addEventListener("click", () => {
      handleCopyClick(button, section);
    });

    bar.appendChild(button);
    syncActionsBarLayout(section);
    inserted = true;

    return { button, bar, inserted };
  }

  async function handleCopyClick(button, section) {
    if (copyInProgress) {
      return;
    }

    copyInProgress = true;
    button.disabled = true;

    const links = collectItemMappingLinks(section);

    try {
      if (!links.length) {
        setLinkActionLabel(button, "Copy failed");
        return;
      }

      const { html, plain } = formatClipboardContent(links);
      const success = await writeRichClipboard(html, plain);
      setLinkActionLabel(button, success ? "Copied!" : "Copy failed");
    } catch (err) {
      setLinkActionLabel(button, "Copy failed");
      warn("Copy item mapping links failed:", err);
    } finally {
      copyInProgress = false;
      button.disabled = false;

      const restoreLabel = getButtonLabel(links.length);
      setTimeout(() => {
        if (button.isConnected) {
          setLinkActionLabel(button, restoreLabel);
        }
      }, FEEDBACK_MS);
    }
  }

  function scanAndInject() {
    if (!isFareHarborHost()) {
      return;
    }

    const snapshot = getScanSnapshot();
    if (scanSnapshotUnchanged(snapshot)) {
      log("insertion pass skipped, state unchanged", snapshot);
      return;
    }

    injectStyles();

    const sections = findItemMappingsSections();
    cleanupStaleActions(sections);

    for (let i = 0; i < sections.length; i++) {
      const section = sections[i];
      const result = ensureCopyButton(section);
      if (result?.inserted) {
        logInsertionOnce(
          `${location.href}:link-copy:${i}`,
          "Inserted copy link action in Item Mappings footer"
        );
      } else if (result?.button) {
        log("button already exists", { sectionIndex: i, href: location.href });
      }
    }

    lastScanCache = getScanSnapshot();
    log("insertion pass ran", { href: location.href, sections: sections.length });
  }

  function scheduleScan() {
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }

    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      scanAndInject();
    }, SCAN_DEBOUNCE_MS);
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  function evaluateLifecycle(reason) {
    if (!isFareHarborHost()) {
      if (watchersActive) {
        log("observer stopped because page became ineligible (not FareHarbor)", { reason });
      }
      stopObserver();
      watchersActive = false;
      return;
    }

    const eligible = isPageEligibleForItemLinkCopy();
    if (eligible) {
      if (!watchersActive) {
        log("eligible page detected", { reason, href: location.href });
        startObserver();
        log("observer started", { reason });
        watchersActive = true;
      }
      scheduleScan();
      log("insertion pass scheduled", { reason });
      return;
    }

    if (watchersActive) {
      log("observer stopped because page became ineligible", { reason, href: location.href });
    }
    stopObserver();
    watchersActive = false;
  }

  function onRouteChange(reason) {
    lastTrackedHref = location.href;
    resetScanState();
    scheduleLifecycleEval(reason || "route-change");
  }

  function startRouteWatchers() {
    if (routeWatchersStarted) {
      return;
    }
    routeWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", () => onRouteChange("popstate"));
    window.addEventListener("hashchange", () => onRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        onRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        onRouteChange("replaceState");
        return result;
      };
    } catch (err) {
      warn("history hook unavailable:", err);
    }

    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        onRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  function startObserver() {
    if (observer) {
      return;
    }

    observer = new MutationObserver((mutations) => {
      if (!isPageEligibleForItemLinkCopy()) {
        return;
      }
      if (mutations.length > 0 && mutations.every(isExtensionMutation)) {
        return;
      }
      scheduleScan();
    });

    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function init() {
    const boot = () => {
      if (isFareHarborHost()) {
        startRouteWatchers();
      }
      evaluateLifecycle("dom-content-loaded");
      scheduleLifecycleEval("body-ready");
    };

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", boot, { once: true });
    } else {
      boot();
    }
  }

  window.ItemMappingLinkCopy = {
    ACTIONS_BAR_ATTR,
    ACTIONS_BAR_CLASS,
    LINK_ACTION_CLASS,
    LINK_ACTION_LABEL_CLASS,
    SEPARATOR_CLASS,
    INJECTED_ATTR,
    normalizeVisibleText,
    getButtonLabel,
    trimLinkText,
    escapeHtml,
    escapeHtmlAttr,
    formatClipboardContent,
    collectItemMappingLinks,
    findItemMappingsSections,
    ensureActionsBar,
    syncActionsBarLayout,
    injectActionStyles: injectStyles,
    createLinkIcon,
    createClipboardIcon,
    getLinkActionLabel,
    setLinkActionLabel,
    ensureLinkActionButtonStructure
  };

  init();
  log("Module initialized successfully");
})();
