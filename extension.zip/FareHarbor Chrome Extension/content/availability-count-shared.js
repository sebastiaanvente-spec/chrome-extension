(function availabilityCountSharedModule() {
  "use strict";

  const CHANNEL_COMPANY_NUMERIC_RE =
    /^\/[^/]+\/dashboard\/settings\/integrations\/channels\/(\d+)\/?$/;
  const RESELLER_ITEM_EXTERNAL_ID_RE = /\bri(\d+)\b/i;

  /** @type {Map<string, Promise<{ ok: boolean, count: number | null, error: string | null }>>} */
  const inflightFetches = new Map();

  function findAvailabilityCount(data) {
    if (!data || typeof data !== "object") {
      return null;
    }
    if (typeof data.availability_count === "number") {
      return data.availability_count;
    }
    if (typeof data.availabilityCount === "number") {
      return data.availabilityCount;
    }
    const stack = [data];
    const seen = new Set();
    while (stack.length) {
      const obj = stack.pop();
      if (!obj || typeof obj !== "object" || seen.has(obj)) {
        continue;
      }
      seen.add(obj);
      for (const [k, v] of Object.entries(obj)) {
        if (
          (k === "availability_count" ||
            k === "availabilityCount" ||
            k === "futureAvailabilitiesCount") &&
          typeof v === "number"
        ) {
          return v;
        }
        if (v && typeof v === "object") {
          stack.push(v);
        }
      }
    }
    return null;
  }

  function normalizeCount(value) {
    if (typeof value !== "number" || !Number.isFinite(value)) {
      return null;
    }
    return value;
  }

  function formatCount(count) {
    return String(count);
  }

  function parseNumericChannelCompanyPageContext(pathname) {
    const normalized = String(pathname || "").replace(/\/+$/, "");
    if (!normalized || /\/items\/\d+/.test(normalized)) {
      return null;
    }

    const numericMatch = normalized.match(CHANNEL_COMPANY_NUMERIC_RE);
    if (!numericMatch) {
      return null;
    }

    const parts = normalized.split("/").filter(Boolean);
    return {
      companyShortname: parts[0],
      channelId: numericMatch[1]
    };
  }

  function parseResellerItemIdFromExternalId(text) {
    const match = String(text || "").match(RESELLER_ITEM_EXTERNAL_ID_RE);
    return match ? match[1] : null;
  }

  function buildResellerItemApiUrl(ctx, resellerItemId) {
    return (
      `/api/v1/companies/${ctx.companyShortname}` +
      `/reseller-companies/${ctx.channelId}` +
      `/reseller-items/${resellerItemId}/`
    );
  }

  function buildResellerItemFetchCacheKey(ctx, resellerItemId) {
    return `${ctx.companyShortname}|${ctx.channelId}|${resellerItemId}`;
  }

  async function fetchResellerItemAvailabilityCount(ctx, resellerItemId) {
    if (!ctx?.companyShortname || !ctx?.channelId || !resellerItemId) {
      return { ok: false, count: null, error: "missing context" };
    }

    const cacheKey = buildResellerItemFetchCacheKey(ctx, resellerItemId);
    const inflight = inflightFetches.get(cacheKey);
    if (inflight) {
      return inflight;
    }

    const promise = (async () => {
      const path = `${buildResellerItemApiUrl(ctx, resellerItemId)}?availability_count=yes`;
      const url = new URL(path, window.location.origin).href;
      try {
        const resp = await fetch(url, { credentials: "include" });
        const text = await resp.text();
        if (!resp.ok) {
          return { ok: false, count: null, error: `${resp.status}` };
        }

        let json;
        try {
          json = JSON.parse(text);
        } catch {
          return { ok: false, count: null, error: "non-JSON response" };
        }

        const count = normalizeCount(findAvailabilityCount(json));
        if (count !== null) {
          return { ok: true, count, error: null };
        }

        return { ok: true, count: null, error: "no availability count in response" };
      } catch (err) {
        return {
          ok: false,
          count: null,
          error: String(err?.message || err)
        };
      }
    })();

    inflightFetches.set(cacheKey, promise);
    try {
      return await promise;
    } finally {
      if (inflightFetches.get(cacheKey) === promise) {
        inflightFetches.delete(cacheKey);
      }
    }
  }

  window.FareHarborAvailabilityCount = {
    findAvailabilityCount,
    normalizeCount,
    formatCount,
    parseNumericChannelCompanyPageContext,
    parseResellerItemIdFromExternalId,
    buildResellerItemApiUrl,
    fetchResellerItemAvailabilityCount
  };
})();
