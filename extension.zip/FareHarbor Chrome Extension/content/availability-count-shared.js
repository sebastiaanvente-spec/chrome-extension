(function availabilityCountSharedModule() {
  "use strict";

  function findAvailabilityCount(data) {
    if (!data || typeof data !== "object") {
      return null;
    }
    if (typeof data.availability_count === "number") {
      return data.availability_count;
    }
    if (typeof data.availabilityCount === "number") {
      return data.availabilityCount;
    }
    const stack = [data];
    const seen = new Set();
    while (stack.length) {
      const obj = stack.pop();
      if (!obj || typeof obj !== "object" || seen.has(obj)) {
        continue;
      }
      seen.add(obj);
      for (const [k, v] of Object.entries(obj)) {
        if (
          (k === "availability_count" ||
            k === "availabilityCount" ||
            k === "futureAvailabilitiesCount") &&
          typeof v === "number"
        ) {
          return v;
        }
        if (v && typeof v === "object") {
          stack.push(v);
        }
      }
    }
    return null;
  }

  function normalizeCount(value) {
    if (typeof value !== "number" || !Number.isFinite(value)) {
      return null;
    }
    return value;
  }

  function formatCount(count) {
    return String(count);
  }

  window.FareHarborAvailabilityCount = {
    findAvailabilityCount,
    normalizeCount,
    formatCount
  };
})();
