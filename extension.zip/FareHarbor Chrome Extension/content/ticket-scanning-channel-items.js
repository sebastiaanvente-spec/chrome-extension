console.log("[ticket-scanning-channel-items] script loaded");

(function ticketScanningChannelItemsModule() {
  "use strict";

  const LOG_PREFIX = "[ticket-scanning-channel-items]";
  const COLUMN_ATTR = "data-fh-ticket-scanning-column";
  const ITEM_STATUS_COLUMN_ATTR = "data-fh-item-status-column";
  const ITEM_IDS_ATTR = "data-fh-ticket-scanning-item-ids";
  const HEADER_TEXT = "Ticket Scanning";
  const SETTING_KEY = "showTicketScanningColumn";
  const STYLE_ID = "fh-ticket-scanning-column-style";
  const SCAN_DEBOUNCE_MS = 150;
  const ROUTE_REEVAL_DELAY_MS = 150;
  const ROUTE_POLL_MS = 500;
  const RETRY_INTERVAL_MS = 500;
  const RETRY_MAX_MS = 10000;
  const ITEMS_PAGE_SIZE = 1000;
  const MISSING_TEXT = "—";
  const LOADING_TEXT = "Loading...";
  const UNKNOWN_TEXT = "Unknown";

  const CHANNEL_COMPANY_NUMERIC_RE =
    /^\/[^/]+\/dashboard\/settings\/integrations\/channels\/(\d+)\/?$/;
  const ITEM_HREF_RE = /\/dashboard\/items\/(\d+)/i;
  const ITEM_MAPPINGS_HEADER_RE = /^item\s*mappings$/i;
  const ITEM_STATUS_HEADER_RE = /^item\s*status$/i;

  const REQUIRED_HEADERS = [
    "Name",
    "SKU",
    "External Identifier",
    "Item Mappings",
    "Channel Customer Types",
    "Channel Options",
    "Last changed"
  ];

  const STYLE_TEXT = `
[${COLUMN_ATTR}="true"] .fh-ticket-scanning {
  margin: 0;
  line-height: 1.4;
  font-size: inherit;
}
[${COLUMN_ATTR}="true"] .fh-ticket-scanning--muted {
  color: #8c959f;
}
[${COLUMN_ATTR}="true"] .fh-ticket-scanning--empty {
  min-height: 1.4em;
}
`.trim();

  let observer = null;
  let debounceTimer = null;
  let hrefPollTimer = null;
  let lifecycleEvalTimer = null;
  let retryTimer = null;
  let retryStartedAt = 0;
  let lastTrackedHref = location.href;
  let watchersActive = false;
  let routeWatchersStarted = false;
  let scanInProgress = false;
  let fetchGeneration = 0;
  let featureEnabled = true;

  /** @type {Map<string, string>} */
  const statusCache = new Map();
  /** @type {Map<string, Promise<void>>} */
  const inflightCompanyFetches = new Map();
  /** @type {Set<string>} */
  const companyLookupDone = new Set();
  let lastAppliedState = {
    pageKey: null,
    itemIdSetKey: null,
    populated: false
  };
  /** @type {{ pageKey: string|null, isViator: boolean|null, inflight: Promise<boolean>|null }} */
  let viatorEligibility = {
    pageKey: null,
    isViator: null,
    inflight: null
  };

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function warn(...args) {
    console.warn(LOG_PREFIX, ...args);
  }

  function parseNumericChannelCompanyPageContext(pathname) {
    const normalized = String(pathname || "").replace(/\/+$/, "");
    if (!normalized || /\/items\/\d+/.test(normalized)) {
      return null;
    }

    const numericMatch = normalized.match(CHANNEL_COMPANY_NUMERIC_RE);
    if (!numericMatch) {
      return null;
    }

    const parts = normalized.split("/").filter(Boolean);
    return {
      companyShortname: parts[0],
      channelId: numericMatch[1]
    };
  }

  function buildStatusCacheKey(companyShortname, itemId) {
    return `${companyShortname}|${itemId}`;
  }

  function formatTicketScanningValue(flag) {
    if (flag === true) return "Yes";
    if (flag === false) return "No";
    return UNKNOWN_TEXT;
  }

  function getTicketScanningLabel(item) {
    if (!item || typeof item !== "object") {
      return UNKNOWN_TEXT;
    }
    return formatTicketScanningValue(item.is_scanning_enabled);
  }

  function extractMappedItemIdsFromCell(cell) {
    if (!cell) {
      return [];
    }
    const ids = [];
    const links = cell.querySelectorAll('a[href*="/dashboard/items/"]');
    for (const link of links) {
      const href = link.getAttribute("href") || "";
      const match = href.match(ITEM_HREF_RE);
      if (match) {
        ids.push(match[1]);
      }
    }
    return ids;
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function parsePageContext() {
    return parseNumericChannelCompanyPageContext(location.pathname || "");
  }

  function isUrlEligible() {
    return isFareHarborHost() && !!parsePageContext();
  }

  function buildPageKey(ctx) {
    if (!ctx) {
      return null;
    }
    return `${ctx.companyShortname}|${ctx.channelId}`;
  }

  function buildItemIdSetKey(itemIds) {
    return [...new Set(itemIds)].sort().join("|");
  }

  function clearPageCaches() {
    statusCache.clear();
    inflightCompanyFetches.clear();
    companyLookupDone.clear();
    viatorEligibility = {
      pageKey: null,
      isViator: null,
      inflight: null
    };
    lastAppliedState = {
      pageKey: null,
      itemIdSetKey: null,
      populated: false
    };
  }

  /**
   * Viator-only: reuse MappingCopyButton's reseller-company ota_type detection
   * (same path as Mapping Tools / copy mapping buttons).
   */
  async function resolveIsViatorChannelPage() {
    const ctx = parsePageContext();
    if (!ctx) {
      return false;
    }

    const pageKey = buildPageKey(ctx);
    if (
      viatorEligibility.pageKey === pageKey &&
      typeof viatorEligibility.isViator === "boolean"
    ) {
      return viatorEligibility.isViator;
    }
    if (viatorEligibility.pageKey === pageKey && viatorEligibility.inflight) {
      return viatorEligibility.inflight;
    }

    const promise = (async () => {
      const mapping = window.MappingCopyButton;
      if (
        !mapping?.fetchResellerCompany ||
        !mapping?.parseChannelCompanyListContext
      ) {
        warn("MappingCopyButton not available; Ticket Scanning column skipped");
        return false;
      }

      const listContext = mapping.parseChannelCompanyListContext();
      if (!listContext) {
        return false;
      }

      try {
        const result = await mapping.fetchResellerCompany(listContext);
        return Boolean(
          result?.ok && result.strategy?.affiliateKey === "viator"
        );
      } catch (err) {
        warn("Viator channel detection failed", String(err?.message || err));
        return false;
      }
    })();

    viatorEligibility = { pageKey, isViator: null, inflight: promise };
    try {
      const isViator = await promise;
      if (viatorEligibility.pageKey === pageKey) {
        viatorEligibility = { pageKey, isViator, inflight: null };
      }
      return isViator;
    } catch (err) {
      if (viatorEligibility.pageKey === pageKey) {
        viatorEligibility = { pageKey, isViator: false, inflight: null };
      }
      return false;
    }
  }

  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = STYLE_TEXT;
    (document.head || document.documentElement).appendChild(style);
  }

  function getRowCells(row) {
    return [...row.children].filter(
      (el) => el.tagName === "TD" || el.tagName === "TH"
    );
  }

  function normalizeCellText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function isChannelItemsTable(table) {
    const headerText = table.querySelector("thead")?.innerText || "";
    return REQUIRED_HEADERS.every((header) => headerText.includes(header));
  }

  function findChannelItemsTable(root) {
    const scope = root || document;
    const selectors = [
      'table[ng-if="resellerItems.length"]',
      'table[ng-table="resellerItems"]',
      'table[ng-controller*="ResellerItemsController"]',
      "table.reseller-items-table",
      'table.spreadsheet[ng-if="resellerItems.length"]',
      'table[ng-table*="resellerItems"]'
    ];

    for (const selector of selectors) {
      const table = scope.querySelector(selector);
      if (table && isChannelItemsTable(table)) {
        return table;
      }
    }

    const tables = scope.querySelectorAll("table");
    for (const table of tables) {
      if (!isChannelItemsTable(table)) {
        continue;
      }
      if (table.querySelector('tbody[ng-repeat*="resellerItem"]')) {
        return table;
      }
    }

    return null;
  }

  function getNativeRowCells(row) {
    return getRowCells(row).filter(
      (cell) => cell.getAttribute(COLUMN_ATTR) !== "true"
    );
  }

  function findItemMappingsIndex(cells) {
    return cells.findIndex((cell) =>
      ITEM_MAPPINGS_HEADER_RE.test(normalizeCellText(cell.textContent))
    );
  }

  function findItemStatusIndex(cells) {
    return cells.findIndex((cell) => {
      if (cell.getAttribute(ITEM_STATUS_COLUMN_ATTR) === "true") {
        return true;
      }
      return ITEM_STATUS_HEADER_RE.test(normalizeCellText(cell.textContent));
    });
  }

  function findInsertAnchorCell(cells) {
    const statusIdx = findItemStatusIndex(cells);
    if (statusIdx >= 0) {
      return cells[statusIdx];
    }
    const mappingsIdx = findItemMappingsIndex(cells);
    if (mappingsIdx >= 0) {
      return cells[mappingsIdx];
    }
    return null;
  }

  function isExtensionNode(node) {
    if (!(node instanceof Element)) {
      const parent = node?.parentElement;
      return parent ? isExtensionNode(parent) : false;
    }
    if (node.getAttribute(COLUMN_ATTR) === "true") {
      return true;
    }
    return !!node.closest?.(`[${COLUMN_ATTR}="true"]`);
  }

  function isExtensionMutation(mutation) {
    if (isExtensionNode(mutation.target)) {
      return true;
    }
    for (const node of mutation.addedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    for (const node of mutation.removedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    return false;
  }

  function removeInjectedColumns() {
    document.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
      cell.remove();
    });
  }

  function applyFeatureSetting(enabled, reason) {
    featureEnabled = enabled !== false;
    if (!featureEnabled) {
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }
    evaluateLifecycle(reason || "setting-enabled");
  }

  function initSettingsBinding() {
    const settings = window.FHSettings;
    if (!settings) {
      return;
    }
    settings.get(SETTING_KEY, (value) => {
      applyFeatureSetting(value, "settings-init");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SETTING_KEY]) {
        applyFeatureSetting(changes[SETTING_KEY].newValue, "setting-change");
      }
    });
  }

  function createHeaderCell(referenceCell) {
    const tagName =
      referenceCell?.tagName === "TD" || referenceCell?.tagName === "td"
        ? "td"
        : "th";
    const cell = document.createElement(tagName);
    cell.setAttribute(COLUMN_ATTR, "true");
    cell.textContent = HEADER_TEXT;
    if (referenceCell?.className) {
      cell.className = referenceCell.className;
    }
    return cell;
  }

  function createStatusLine(label, statusKey) {
    // No → leave empty (spacer only when multiple mapped items need alignment)
    if (statusKey === "No") {
      const empty = document.createElement("p");
      empty.className = "fh-ticket-scanning fh-ticket-scanning--empty";
      empty.setAttribute("data-fh-scanning", "No");
      return empty;
    }

    const p = document.createElement("p");
    p.className = "fh-ticket-scanning";

    // Yes → native-style green checkmark (matches item list isScanningEnabled UI)
    if (statusKey === "Yes") {
      const span = document.createElement("span");
      span.className = "fh-green";
      span.textContent = "✓";
      p.appendChild(span);
      return p;
    }

    p.classList.add("fh-ticket-scanning--muted");
    p.textContent = label;
    return p;
  }

  function renderStatusCell(cell, itemIds, companyShortname) {
    cell.replaceChildren();

    if (!itemIds.length) {
      cell.appendChild(createStatusLine(MISSING_TEXT, "Unknown"));
      return;
    }

    for (const itemId of itemIds) {
      const cacheKey = buildStatusCacheKey(companyShortname, itemId);
      if (!statusCache.has(cacheKey)) {
        cell.appendChild(createStatusLine(LOADING_TEXT, "Loading"));
        continue;
      }
      const status = statusCache.get(cacheKey) || UNKNOWN_TEXT;
      cell.appendChild(createStatusLine(status, status));
    }
  }

  function createBodyCell(itemIds, companyShortname) {
    const cell = document.createElement("td");
    cell.setAttribute(COLUMN_ATTR, "true");
    cell.className = "prose prose--compact";
    if (itemIds.length) {
      cell.setAttribute(ITEM_IDS_ATTR, itemIds.join(","));
    }
    renderStatusCell(cell, itemIds, companyShortname);
    return cell;
  }

  function cellHasFinalValue(cell) {
    if (!cell) {
      return false;
    }
    const lines = [...cell.querySelectorAll(".fh-ticket-scanning")];
    if (!lines.length) {
      const text = (cell.textContent || "").trim();
      return text !== LOADING_TEXT && text !== "";
    }
    // Empty "No" spacers are final; only Loading... is incomplete
    return lines.every((line) => {
      if (line.classList.contains("fh-ticket-scanning--empty")) {
        return true;
      }
      const text = (line.textContent || "").trim();
      return text !== LOADING_TEXT && text !== "";
    });
  }

  function findMappingsCellForRow(row) {
    const headerRow = row.closest("table")?.querySelector("thead tr");
    if (!headerRow) {
      return null;
    }
    const headerCells = getNativeRowCells(headerRow);
    const mappingsHeaderIdx = findItemMappingsIndex(headerCells);
    if (mappingsHeaderIdx < 0) {
      return null;
    }
    const rowCells = getNativeRowCells(row);
    return rowCells[mappingsHeaderIdx] || null;
  }

  function normalizeColumn(table, ctx) {
    ensureStyles();
    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return {
        descriptors: [],
        headerInserted: 0,
        cellsInserted: 0,
        cellsRepositioned: 0
      };
    }

    let headerInserted = 0;
    let cellsInserted = 0;
    let cellsRepositioned = 0;
    const descriptors = [];
    const companyShortname = ctx?.companyShortname || "";

    headerRow.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
      cell.remove();
      cellsRepositioned += 1;
    });

    const headerCells = getNativeRowCells(headerRow);
    const anchorHeader = findInsertAnchorCell(headerCells);
    if (!anchorHeader) {
      return { descriptors, headerInserted, cellsInserted, cellsRepositioned };
    }

    const headerCell = createHeaderCell(anchorHeader);
    headerRow.insertBefore(headerCell, anchorHeader.nextElementSibling);
    headerInserted = 1;

    const rows = table.querySelectorAll("tbody tr");
    rows.forEach((row) => {
      row.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
        cell.remove();
        cellsRepositioned += 1;
      });

      const rowCells = getNativeRowCells(row);
      const anchorCell = findInsertAnchorCell(rowCells);
      if (!anchorCell) {
        return;
      }

      const mappingsCell = findMappingsCellForRow(row);
      const itemIds = extractMappedItemIdsFromCell(mappingsCell);
      const cell = createBodyCell(itemIds, companyShortname);
      row.insertBefore(cell, anchorCell.nextElementSibling);
      cellsInserted += 1;

      if (!itemIds.length) {
        return;
      }

      descriptors.push({ itemIds, cell });
    });

    return { descriptors, headerInserted, cellsInserted, cellsRepositioned };
  }

  function rowColumnCorrectlyPlaced(row) {
    const rowCells = getNativeRowCells(row);
    const anchorCell = findInsertAnchorCell(rowCells);
    if (!anchorCell) {
      return false;
    }

    const extensionCell = row.querySelector(`[${COLUMN_ATTR}="true"]`);
    if (!extensionCell) {
      return false;
    }

    return extensionCell.previousElementSibling === anchorCell;
  }

  function tableNeedsRepair(table) {
    if (!table) {
      return false;
    }

    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return true;
    }

    const headerCells = getNativeRowCells(headerRow);
    const anchorHeader = findInsertAnchorCell(headerCells);
    if (!anchorHeader) {
      return true;
    }

    const extensionHeaders = headerRow.querySelectorAll(
      `[${COLUMN_ATTR}="true"]`
    );
    if (extensionHeaders.length !== 1) {
      return true;
    }

    if (extensionHeaders[0].previousElementSibling !== anchorHeader) {
      return true;
    }

    for (const row of table.querySelectorAll("tbody tr")) {
      const extensionCells = row.querySelectorAll(`[${COLUMN_ATTR}="true"]`);
      if (extensionCells.length !== 1) {
        return true;
      }
      if (!rowColumnCorrectlyPlaced(row)) {
        return true;
      }
    }

    return false;
  }

  function collectUniqueItemIds(descriptors) {
    const ids = [];
    const seen = new Set();
    for (const descriptor of descriptors) {
      for (const itemId of descriptor.itemIds) {
        if (!seen.has(itemId)) {
          seen.add(itemId);
          ids.push(itemId);
        }
      }
    }
    return ids;
  }

  function allStatusCellsFinal(table) {
    const cells = [
      ...table.querySelectorAll(`tbody [${COLUMN_ATTR}="true"][${ITEM_IDS_ATTR}]`)
    ];
    if (!cells.length) {
      return false;
    }
    return cells.every(cellHasFinalValue);
  }

  function populateCells(table, companyShortname) {
    table
      .querySelectorAll(`tbody [${COLUMN_ATTR}="true"][${ITEM_IDS_ATTR}]`)
      .forEach((cell) => {
        if (cellHasFinalValue(cell)) {
          return;
        }
        const itemIds = (cell.getAttribute(ITEM_IDS_ATTR) || "")
          .split(",")
          .filter(Boolean);
        renderStatusCell(cell, itemIds, companyShortname);
      });
  }

  function applyCompanyItemsToCache(companyShortname, items) {
    for (const item of items || []) {
      if (item == null || item.pk == null) continue;
      const cacheKey = buildStatusCacheKey(companyShortname, String(item.pk));
      statusCache.set(cacheKey, getTicketScanningLabel(item));
    }
  }

  async function fetchCompanyScanningLookup(companyShortname) {
    if (companyLookupDone.has(companyShortname)) {
      return;
    }

    const inflight = inflightCompanyFetches.get(companyShortname);
    if (inflight) {
      await inflight;
      return;
    }

    const promise = (async () => {
      let page = 0;
      try {
        while (true) {
          const path =
            `/api/v1/companies/${encodeURIComponent(companyShortname)}/items/` +
            `?sort=sortable_index&page=${page}&page-size=${ITEMS_PAGE_SIZE}`;
          const url = new URL(path, window.location.origin).href;
          const resp = await fetch(url, { credentials: "include" });
          if (!resp.ok) {
            log("ticket scanning company items request failed", {
              company: companyShortname,
              page,
              status: resp.status
            });
            break;
          }

          let json;
          try {
            json = await resp.json();
          } catch {
            log("ticket scanning company items non-JSON response", {
              company: companyShortname,
              page
            });
            break;
          }

          const items = json?.items;
          if (!Array.isArray(items)) {
            log("ticket scanning response missing items array", {
              company: companyShortname,
              page
            });
            break;
          }

          applyCompanyItemsToCache(companyShortname, items);

          if (items.length < ITEMS_PAGE_SIZE) {
            break;
          }
          page += 1;
        }
      } catch (err) {
        log("ticket scanning company items fetch error", {
          company: companyShortname,
          error: String(err?.message || err)
        });
      } finally {
        companyLookupDone.add(companyShortname);
      }
    })();

    inflightCompanyFetches.set(companyShortname, promise);
    try {
      await promise;
    } finally {
      if (inflightCompanyFetches.get(companyShortname) === promise) {
        inflightCompanyFetches.delete(companyShortname);
      }
    }
  }

  async function resolveStatuses(ctx, itemIds, onItemResolved) {
    const idsToFetch = itemIds.filter(
      (id) => !statusCache.has(buildStatusCacheKey(ctx.companyShortname, id))
    );

    if (!idsToFetch.length && companyLookupDone.has(ctx.companyShortname)) {
      return;
    }

    log("fetching ticket scanning statuses", {
      company: ctx.companyShortname,
      channelId: ctx.channelId,
      itemCount: itemIds.length
    });

    await fetchCompanyScanningLookup(ctx.companyShortname);

    for (const itemId of itemIds) {
      const cacheKey = buildStatusCacheKey(ctx.companyShortname, itemId);
      if (!statusCache.has(cacheKey)) {
        statusCache.set(cacheKey, UNKNOWN_TEXT);
      }
    }

    if (typeof onItemResolved === "function") {
      onItemResolved();
    }
  }

  function shouldFullySkipScan(ctx, descriptors, table) {
    if (!ctx || !descriptors.length || !table) {
      return false;
    }

    if (tableNeedsRepair(table)) {
      return false;
    }

    if (!allStatusCellsFinal(table)) {
      return false;
    }

    const pageKey = buildPageKey(ctx);
    const itemIdSetKey = buildItemIdSetKey(collectUniqueItemIds(descriptors));

    if (
      lastAppliedState.pageKey === pageKey &&
      lastAppliedState.itemIdSetKey === itemIdSetKey &&
      lastAppliedState.populated
    ) {
      return true;
    }

    return collectUniqueItemIds(descriptors).every((id) =>
      statusCache.has(buildStatusCacheKey(ctx.companyShortname, id))
    );
  }

  function descriptorsNeedFetch(ctx, descriptors) {
    if (!ctx || !descriptors.length) {
      return false;
    }
    return collectUniqueItemIds(descriptors).some(
      (id) => !statusCache.has(buildStatusCacheKey(ctx.companyShortname, id))
    );
  }

  async function scanTable(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return false;
    }

    const isViator = await resolveIsViatorChannelPage();
    if (!isViator) {
      removeInjectedColumns();
      return false;
    }

    const table = findChannelItemsTable(document);
    if (!table) {
      return false;
    }

    if (scanInProgress) {
      return false;
    }

    scanInProgress = true;
    const generation = ++fetchGeneration;
    let didWork = false;

    try {
      const ctx = parsePageContext();
      const normalizeResult = normalizeColumn(table, ctx);
      const { descriptors, headerInserted, cellsInserted, cellsRepositioned } =
        normalizeResult;

      if (headerInserted > 0 || cellsInserted > 0 || cellsRepositioned > 0) {
        log("Ticket Scanning column normalized", {
          reason,
          rowCount: descriptors.length,
          headerInserted,
          cellsInserted,
          cellsRepositioned
        });
      }

      didWork =
        headerInserted > 0 || cellsInserted > 0 || cellsRepositioned > 0;

      if (!ctx) {
        return didWork;
      }

      if (!descriptors.length) {
        lastAppliedState = {
          pageKey: buildPageKey(ctx),
          itemIdSetKey: "",
          populated: true
        };
        stopRetryLoop();
        return didWork;
      }

      const uniqueItemIds = collectUniqueItemIds(descriptors);

      if (shouldFullySkipScan(ctx, descriptors, table)) {
        populateCells(table, ctx.companyShortname);
        return didWork;
      }

      populateCells(table, ctx.companyShortname);

      if (!descriptorsNeedFetch(ctx, descriptors)) {
        lastAppliedState = {
          pageKey: buildPageKey(ctx),
          itemIdSetKey: buildItemIdSetKey(uniqueItemIds),
          populated: allStatusCellsFinal(table)
        };
        if (lastAppliedState.populated) {
          stopRetryLoop();
        }
        return didWork;
      }

      await resolveStatuses(ctx, uniqueItemIds, () => {
        if (generation !== fetchGeneration) {
          return;
        }
        populateCells(table, ctx.companyShortname);
      });
      if (generation !== fetchGeneration) {
        return didWork;
      }

      populateCells(table, ctx.companyShortname);
      lastAppliedState = {
        pageKey: buildPageKey(ctx),
        itemIdSetKey: buildItemIdSetKey(uniqueItemIds),
        populated: allStatusCellsFinal(table)
      };

      if (lastAppliedState.populated) {
        stopRetryLoop();
      }

      return didWork;
    } finally {
      scanInProgress = false;
    }
  }

  function scheduleScan(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }
    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      scanTable(reason || "debounced-scan");
    }, SCAN_DEBOUNCE_MS);
  }

  function stopRetryLoop() {
    if (retryTimer) {
      clearInterval(retryTimer);
      retryTimer = null;
    }
    retryStartedAt = 0;
  }

  function startRetryLoop(reason) {
    if (!isUrlEligible()) {
      stopRetryLoop();
      return;
    }

    if (!retryTimer) {
      retryStartedAt = Date.now();
      retryTimer = setInterval(async () => {
        const elapsed = Date.now() - retryStartedAt;
        const found = await scanTable("retry-loop");
        if (found) {
          stopRetryLoop();
          return;
        }
        if (elapsed >= RETRY_MAX_MS) {
          stopRetryLoop();
        }
      }, RETRY_INTERVAL_MS);
    }

    scheduleScan(reason || "retry-schedule");
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    stopRetryLoop();
    clearPageCaches();
    fetchGeneration += 1;
    scanInProgress = false;
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  async function evaluateLifecycle(reason) {
    if (!featureEnabled) {
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }

    if (!isUrlEligible()) {
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }

    const isViator = await resolveIsViatorChannelPage();
    if (!isViator) {
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }

    if (!watchersActive) {
      log("eligible Viator page detected", { reason, href: location.href });
      startObserver();
      watchersActive = true;
    }

    startRetryLoop(reason || "lifecycle");
  }

  function onRouteChange(reason) {
    const nextHref = location.href;
    if (nextHref !== lastTrackedHref) {
      clearPageCaches();
      fetchGeneration += 1;
    }
    lastTrackedHref = nextHref;
    scheduleLifecycleEval(reason || "route-change");
  }

  function startRouteWatchers() {
    if (routeWatchersStarted) {
      return;
    }
    routeWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", () => onRouteChange("popstate"));
    window.addEventListener("hashchange", () => onRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        onRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        onRouteChange("replaceState");
        return result;
      };
    } catch (err) {
      log("history hook unavailable:", err);
    }

    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        onRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  function startObserver() {
    if (observer) {
      return;
    }

    observer = new MutationObserver((mutations) => {
      if (!isUrlEligible()) {
        return;
      }
      if (mutations.length > 0 && mutations.every(isExtensionMutation)) {
        return;
      }
      scheduleScan("mutation-observer");
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }

  function init() {
    if (!isFareHarborHost()) {
      return;
    }

    initSettingsBinding();
    startRouteWatchers();
    evaluateLifecycle("init");

    if (document.readyState === "loading") {
      document.addEventListener(
        "DOMContentLoaded",
        () => evaluateLifecycle("dom-content-loaded"),
        { once: true }
      );
    }
  }

  // Exported for unit-test mirroring / debugging
  window.FareHarborTicketScanningColumn = {
    formatTicketScanningValue,
    getTicketScanningLabel,
    extractMappedItemIdsFromCell,
    buildStatusCacheKey,
    parseNumericChannelCompanyPageContext,
    findInsertAnchorCell,
    resolveIsViatorChannelPage
  };

  init();
})();
