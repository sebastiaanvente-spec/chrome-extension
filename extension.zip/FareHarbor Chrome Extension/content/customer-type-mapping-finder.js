console.log("[customer-type-mapping-finder] customer-type-mapping-finder.js loaded");

(function initializeCustomerTypeMappingFinder() {
  "use strict";

  if (!window.FareHarborUtils) {
    setTimeout(initializeCustomerTypeMappingFinder, 10);
    return;
  }

  const utils = window.FareHarborUtils;
  const LOG_PREFIX = "[customer-type-mapping-finder]";
  const DEV_MODE_STORAGE_KEY = FareHarborDeveloperAuth.DEV_MODE_STORAGE_KEY;
  const CONCURRENCY_LIMIT = 5;
  const CUSTOMER_TYPES_PATH_RE =
    /^\/[^/]+\/dashboard\/items\/[^/]+\/prices\/customer-types\/?$/;
  const PROTOTYPE_URI_RE = /\/(?:customer-prototypes|CustomerPrototype)\/(\d+)\//i;
  const USED_BY_CHANNELS_RE = /Used by channels/i;
  const INJECTED_ATTR = "data-fhx-mapping-finder";
  const SETTING_KEY = "showFindExactMappings";
  const EXACT_MAPPINGS_BUTTON_ID = "fh-exact-mappings-button";
  const SAVE_EDIT_SELECTOR = 'button[data-test-id="save-customer-type-update-button"]';
  const NAME_INPUT_SELECTOR = 'input[name="name"]';
  const ROUTE_REEVAL_DELAY_MS = 150;
  const ROUTE_POLL_MS = 500;
  const INSERTION_RETRY_MS = 500;
  const MAX_INSERTION_RETRIES = 120;

  let devModeEnabled = false;
  let featureEnabled = true;
  let observer = null;
  let debounceTimer = null;
  let hrefPollTimer = null;
  let lifecycleEvalTimer = null;
  let insertionRetryTimer = null;
  let insertionRetryAttempts = 0;
  let lastTrackedHref = location.href;
  let watchersActive = false;
  let routeWatchersStarted = false;

  function devLog(...args) {
    if (devModeEnabled) {
      console.log(LOG_PREFIX, ...args);
    }
  }

  function isDevModeEnabledAsync() {
    return FareHarborDeveloperAuth.isDevModeActiveAsync();
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function normalizeCustomerTypeName(name) {
    return (name || "").split("\n")[0].trim();
  }

  async function fareHarborApiFetch(path, apiOrigin) {
    const origin = apiOrigin || window.location.origin;
    const url = path.startsWith("/api/v1")
      ? `${origin}${path}`
      : `${origin}/api/v1${path}`;

    try {
      const response = await fetch(url, {
        method: "GET",
        credentials: "include",
        headers: { Accept: "application/json" }
      });

      if (!response.ok) {
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `API request failed with status ${response.status}`,
          url
        };
      }

      try {
        const data = await response.json();
        return { ok: true, status: response.status, data, error: null, url };
      } catch (err) {
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `Response is not valid JSON: ${err.message}`,
          url
        };
      }
    } catch (err) {
      return {
        ok: false,
        status: null,
        data: null,
        error: `Fetch failed: ${err.message}`,
        url
      };
    }
  }

  function parseCustomerPrototypePageContext() {
    if (!location.hostname.includes("fareharbor")) {
      return null;
    }

    const normalized = (location.pathname || "").replace(/\/+$/, "");
    if (!CUSTOMER_TYPES_PATH_RE.test(normalized)) {
      return null;
    }

    const parts = normalized.split("/").filter(Boolean);
    const dashIdx = parts.indexOf("dashboard");
    if (dashIdx < 1 || parts[dashIdx + 1] !== "items" || !parts[dashIdx + 2]) {
      return null;
    }

    return {
      shortname: parts[0],
      itemId: parts[dashIdx + 2],
      apiOrigin: window.location.origin
    };
  }

  function isElementVisible(el) {
    if (!el || !(el instanceof Element)) {
      return false;
    }
    if (el.closest("[hidden]")) {
      return false;
    }
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") {
      return false;
    }
    return el.getClientRects().length > 0;
  }

  function getScopeFromElement(el) {
    if (!window.angular || !el) {
      return null;
    }
    try {
      const ngEl = window.angular.element(el);
      return (
        (ngEl.scope && ngEl.scope()) ||
        (ngEl.isolatedScope && ngEl.isolatedScope()) ||
        null
      );
    } catch {
      return null;
    }
  }

  function walkScopeChain(scope) {
    const chain = [];
    let current = scope;
    let depth = 0;
    while (current && depth < 30) {
      chain.push(current);
      current = current.$parent;
      depth += 1;
    }
    return chain;
  }

  function extractPrototypeIdFromAngularScope(block) {
    const anchor =
      block.querySelector(NAME_INPUT_SELECTOR) ||
      block.querySelector(SAVE_EDIT_SELECTOR) ||
      block;
    const scope = getScopeFromElement(anchor);
    if (!scope) {
      return null;
    }

    const keys = [
      "customerPrototype",
      "customer_prototype",
      "prototype",
      "editableCustomerPrototype",
      "editable_customer_prototype"
    ];

    for (const scopeLevel of walkScopeChain(scope)) {
      for (const key of keys) {
        const value = scopeLevel[key];
        const pk = value?.pk ?? value?.id ?? null;
        if (pk != null) {
          return { prototypeId: String(pk), source: "angular-scope" };
        }
      }
    }

    return null;
  }

  function getExpandedEditorBlocks() {
    const editors = [];
    const seen = new Set();

    document.querySelectorAll(SAVE_EDIT_SELECTOR).forEach((saveBtn) => {
      if (!isElementVisible(saveBtn)) {
        return;
      }

      const editorBlock =
        saveBtn.closest('form, [ng-controller*="CustomerPrototype"], .edit-form, .modal') ||
        saveBtn.closest(utils.SELECTORS.CUSTOMER_TYPE_BLOCKS) ||
        saveBtn.parentElement;

      if (!editorBlock || seen.has(editorBlock)) {
        return;
      }

      seen.add(editorBlock);
      editors.push(editorBlock);
    });

    return editors;
  }

  function findUsedByChannelsWarning(editorBlock) {
    const matches = [];

    editorBlock.querySelectorAll("*").forEach((el) => {
      if (!isElementVisible(el)) {
        return;
      }
      const text = (el.textContent || "").trim();
      if (!USED_BY_CHANNELS_RE.test(text)) {
        return;
      }
      matches.push(el);
    });

    if (!matches.length) {
      return null;
    }

    const leafMatches = matches.filter(
      (el) => !matches.some((other) => other !== el && el.contains(other))
    );

    return leafMatches[0] || matches[0];
  }

  function resolutionLog(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function getInputLabel(editorBlock, input) {
    const id = input.id;
    if (id) {
      const label = editorBlock.querySelector(`label[for="${CSS.escape(id)}"]`);
      if (label) {
        return label.textContent.trim();
      }
    }
    const parentLabel = input.closest("label");
    if (parentLabel) {
      return parentLabel.textContent.trim();
    }
    return "";
  }

  function collectEditorInputs(editorBlock) {
    return [...editorBlock.querySelectorAll("input, textarea, select")].map((el) => ({
      name: el.name || "",
      id: el.id || "",
      type: el.type || el.tagName.toLowerCase(),
      value: el.value ?? el.textContent ?? "",
      label: getInputLabel(editorBlock, el)
    }));
  }

  function collectRelevantEditorAttributes(editorBlock) {
    const keywordRe = /customer-prototypes|customer_type|customerType|prototype/i;
    const results = [];

    editorBlock.querySelectorAll("*").forEach((el) => {
      for (const attr of el.attributes || []) {
        if (
          keywordRe.test(attr.name) ||
          keywordRe.test(attr.value) ||
          /\d{4,}/.test(attr.value)
        ) {
          results.push({
            tag: el.tagName.toLowerCase(),
            attr: attr.name,
            value: String(attr.value).slice(0, 240)
          });
        }
      }
    });

    return results.slice(0, 80);
  }

  function parseCustomerTypeFromEditor(editorBlock) {
    const text = (editorBlock.textContent || "").replace(/\s+/g, " ");
    const pkMatch = text.match(/Customer type:\s*.+?\(#(\d+)\)/i);
    const nameMatch = text.match(/Customer type:\s*(.+?)\s*\(#\d+\)/i);
    return {
      customerTypeName: nameMatch ? nameMatch[1].trim() : "",
      customerTypePk: pkMatch ? String(pkMatch[1]) : null
    };
  }

  function getEditorSku(editorBlock) {
    const skuInput = editorBlock.querySelector('input[name="name"]');
    if (skuInput?.value?.trim()) {
      return skuInput.value.trim();
    }

    const displayInput = editorBlock.querySelector(
      'input[name="displayName"], input[name="display_name"]'
    );
    if (displayInput?.value?.trim()) {
      return displayInput.value.trim();
    }

    return "";
  }

  function getPrototypeCustomerTypePk(prototype) {
    const customerType = prototype?.customer_type ?? prototype?.customerType ?? {};
    return customerType?.pk != null ? String(customerType.pk) : null;
  }

  function valuesEqual(a, b) {
    if (!a || !b) {
      return false;
    }
    return normalizeCustomerTypeName(a) === normalizeCustomerTypeName(b);
  }

  function summarizePrototype(prototype) {
    return {
      pk: prototype?.pk ?? null,
      name: prototype?.name ?? null,
      display_name: prototype?.display_name ?? prototype?.displayName ?? null,
      customer_type_pk: getPrototypeCustomerTypePk(prototype)
    };
  }

  function rankPrototypeCandidates(prototypes, context) {
    return prototypes
      .map((prototype) => {
        let score = 0;
        const reasons = [];
        if (context.prototypeId && String(prototype.pk) === String(context.prototypeId)) {
          score += 100;
          reasons.push("dom_pk");
        }
        if (context.sku && valuesEqual(prototype.display_name || prototype.displayName, context.sku)) {
          score += 20;
          reasons.push("display_name===sku");
        }
        if (context.sku && valuesEqual(prototype.name, context.sku)) {
          score += 20;
          reasons.push("name===sku");
        }
        if (
          context.customerTypePk &&
          getPrototypeCustomerTypePk(prototype) === String(context.customerTypePk)
        ) {
          score += 10;
          reasons.push("customer_type_pk");
        }
        if (context.customerTypeName) {
          const type = prototype.customer_type ?? prototype.customerType ?? {};
          const typeNames = [type.singular, type.plural, type.name].filter(Boolean);
          if (typeNames.some((name) => valuesEqual(name, context.customerTypeName))) {
            score += 5;
            reasons.push("customer_type_name");
          }
        }
        return { ...summarizePrototype(prototype), score, reasons };
      })
      .filter((candidate) => candidate.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 8);
  }

  function buildEditorResolutionContext(editorBlock, pageContext, idResult) {
    const header = parseCustomerTypeFromEditor(editorBlock);
    return {
      pageContext,
      sku: getEditorSku(editorBlock),
      customerTypeName: header.customerTypeName,
      customerTypePk: header.customerTypePk,
      prototypeId: idResult?.prototypeId ?? null,
      prototypeIdSource: idResult?.source ?? null,
      editorTextPreview: (editorBlock.textContent || "").replace(/\s+/g, " ").trim().slice(0, 500),
      inputs: collectEditorInputs(editorBlock),
      relevantAttributes: collectRelevantEditorAttributes(editorBlock)
    };
  }

  async function fetchCustomerPrototypesList(pageContext) {
    const listPath =
      `/companies/${encodeURIComponent(pageContext.shortname)}` +
      `/items/${encodeURIComponent(pageContext.itemId)}` +
      `/customer-prototypes/?include-is-inactive=yes`;
    const listResult = await fareHarborApiFetch(listPath, pageContext.apiOrigin);
    if (!listResult.ok) {
      return { ok: false, prototypes: [], error: listResult.error, url: listResult.url };
    }
    const prototypes =
      listResult.data?.customer_prototypes ?? listResult.data?.customerPrototypes ?? [];
    return { ok: true, prototypes, error: null, url: listResult.url };
  }

  function logPrototypeResolutionDiagnostics(phase, editorBlock, pageContext, extra = {}) {
    const idResult = extractPrototypeIdFromBlock(editorBlock);
    const context = buildEditorResolutionContext(editorBlock, pageContext, idResult);
    resolutionLog(`Prototype resolution diagnostics (${phase})`, {
      pageContext,
      editorTextPreview: context.editorTextPreview,
      inputs: context.inputs,
      relevantAttributes: context.relevantAttributes,
      detectedSku: context.sku,
      detectedCustomerTypeName: context.customerTypeName,
      detectedCustomerTypePk: context.customerTypePk,
      detectedPrototypeId: context.prototypeId,
      detectedPrototypeIdSource: context.prototypeIdSource,
      ...extra
    });
    return context;
  }

  function filterPrototypesByCustomerTypePk(prototypes, customerTypePk) {
    if (!customerTypePk) {
      return [];
    }
    return prototypes.filter(
      (prototype) => getPrototypeCustomerTypePk(prototype) === String(customerTypePk)
    );
  }

  function filterVisiblePrototypes(prototypes) {
    return prototypes.filter(
      (prototype) => prototype?.is_archived !== true && prototype?.is_hidden !== true
    );
  }

  function matchByCustomerTypePkHeader(prototypes, context) {
    const typeMatches = filterPrototypesByCustomerTypePk(prototypes, context.customerTypePk);
    if (typeMatches.length === 0) {
      return null;
    }
    if (typeMatches.length === 1) {
      return { ok: true, match: typeMatches[0], source: "customer_type_pk_header" };
    }

    const visibleMatches = filterVisiblePrototypes(typeMatches);
    if (visibleMatches.length === 1) {
      return { ok: true, match: visibleMatches[0], source: "customer_type_pk_header_visible" };
    }

    return {
      ok: false,
      ambiguous: true,
      strategy: "customer_type_pk_header",
      matches: visibleMatches.length > 1 ? visibleMatches : typeMatches
    };
  }

  function matchPrototypesFromList(prototypes, context) {
    if (context.prototypeId) {
      const domMatches = prototypes.filter(
        (prototype) => String(prototype.pk) === String(context.prototypeId)
      );
      if (domMatches.length === 1) {
        return { ok: true, match: domMatches[0], source: "dom-pk" };
      }
      if (domMatches.length > 1) {
        return {
          ok: false,
          ambiguous: true,
          strategy: "dom-pk",
          matches: domMatches
        };
      }
    }

    if (context.sku) {
      const displayMatches = prototypes.filter((prototype) =>
        valuesEqual(prototype.display_name || prototype.displayName, context.sku)
      );
      if (displayMatches.length === 1) {
        return { ok: true, match: displayMatches[0], source: "display_name===sku" };
      }
      if (displayMatches.length > 1) {
        return {
          ok: false,
          ambiguous: true,
          strategy: "display_name===sku",
          matches: displayMatches
        };
      }

      const nameMatches = prototypes.filter((prototype) =>
        valuesEqual(prototype.name, context.sku)
      );
      if (nameMatches.length === 1) {
        return { ok: true, match: nameMatches[0], source: "name===sku" };
      }
      if (nameMatches.length > 1) {
        return {
          ok: false,
          ambiguous: true,
          strategy: "name===sku",
          matches: nameMatches
        };
      }
    }

    if (context.customerTypePk && context.sku) {
      const typeFiltered = filterPrototypesByCustomerTypePk(prototypes, context.customerTypePk);
      const skuMatches = typeFiltered.filter((prototype) => {
        const names = [prototype.name, prototype.display_name, prototype.displayName].filter(Boolean);
        return names.some((name) => valuesEqual(name, context.sku));
      });
      if (skuMatches.length === 1) {
        return { ok: true, match: skuMatches[0], source: "customer_type_pk+sku" };
      }
      if (skuMatches.length > 1) {
        return {
          ok: false,
          ambiguous: true,
          strategy: "customer_type_pk+sku",
          matches: skuMatches
        };
      }
    }

    if (context.customerTypePk) {
      const headerMatch = matchByCustomerTypePkHeader(prototypes, context);
      if (headerMatch) {
        return headerMatch;
      }
    }

    if (context.sku || context.customerTypeName) {
      const visibleName = context.sku || context.customerTypeName;
      const nameMatches = findExactNameMatches(prototypes, visibleName);
      if (nameMatches.length === 1) {
        return { ok: true, match: nameMatches[0], source: "visible-name" };
      }
      if (nameMatches.length > 1) {
        return {
          ok: false,
          ambiguous: true,
          strategy: "visible-name",
          matches: nameMatches
        };
      }
    }

    return { ok: false, ambiguous: false, matches: [] };
  }

  function formatPrototypeCandidateList(matches) {
    return matches
      .map((prototype) => {
        const summary = summarizePrototype(prototype);
        return `${summary.pk}: ${summary.display_name || summary.name || "Untitled"}`;
      })
      .join("; ");
  }

  function buildResolutionFailureMessage(context, prototypes, matchResult, rankedCandidates) {
    if (matchResult?.ambiguous) {
      return {
        error:
          "Could not resolve customer prototype because multiple API prototypes match this editor.",
        details: formatPrototypeCandidateList(matchResult.matches || [])
      };
    }

    const skuPart = context.sku
      ? `Detected SKU: "${context.sku}". `
      : "No SKU detected. ";
    const customerTypeName = context.customerTypeName || "";
    const customerTypePk = context.customerTypePk || "";
    const candidateText = rankedCandidates.length
      ? ` Top candidates: ${rankedCandidates
          .map((candidate) => `${candidate.pk} (${candidate.display_name || candidate.name})`)
          .join(", ")}.`
      : "";

    return {
      error: `Could not resolve customer prototype. ${skuPart}Detected customer type: "${customerTypeName}" #${customerTypePk}. API returned ${prototypes.length} prototypes.${candidateText}`,
      details: rankedCandidates.length
        ? rankedCandidates.map((candidate) => JSON.stringify(candidate)).join("\n")
        : ""
    };
  }

  function extractIdsFromString(value, source, candidates) {
    if (!value || typeof value !== "string") {
      return;
    }

    let match;
    const re = new RegExp(PROTOTYPE_URI_RE.source, "gi");
    while ((match = re.exec(value)) !== null) {
      candidates.push({ id: match[1], source });
    }
  }

  function extractPrototypeIdFromBlock(block) {
    if (!block) {
      return { ok: false, error: "Missing customer type block." };
    }

    const candidates = [];

    block.querySelectorAll("form[action]").forEach((form) => {
      extractIdsFromString(form.getAttribute("action") || "", "dom-form-action", candidates);
    });

    block.querySelectorAll("a[href], [ng-href], [data-href]").forEach((el) => {
      const href =
        el.getAttribute("href") ||
        el.getAttribute("ng-href") ||
        el.getAttribute("data-href") ||
        "";
      extractIdsFromString(href, "dom-href", candidates);
    });

    block.querySelectorAll('[data-test-id$="-prototype-indicator"]').forEach((el) => {
      const testId = el.getAttribute("data-test-id") || "";
      const prefix = testId.replace(/-prototype-indicator$/i, "");
      if (/^\d+$/.test(prefix)) {
        candidates.push({ id: prefix, source: "dom-prototype-indicator" });
      }
      extractIdsFromString(testId, "dom-prototype-indicator", candidates);
    });

    const attrNames = ["data-test-id", "id", "name", "ng-init", "ng-click", "ng-submit", "action"];
    block.querySelectorAll("*").forEach((el) => {
      for (const attr of attrNames) {
        extractIdsFromString(el.getAttribute(attr), `dom-${attr}`, candidates);
      }
      if (el.attributes) {
        for (const attr of el.attributes) {
          if (attr.name.startsWith("data-")) {
            extractIdsFromString(attr.value, `dom-${attr.name}`, candidates);
          }
        }
      }
    });

    const uniqueIds = [...new Set(candidates.map((c) => String(c.id)))];
    if (uniqueIds.length > 1) {
      return {
        ok: false,
        error: `Ambiguous customer prototype IDs in block (${uniqueIds.join(", ")}).`,
        ambiguousIds: uniqueIds
      };
    }

    if (uniqueIds.length === 1) {
      const match = candidates.find((c) => String(c.id) === uniqueIds[0]);
      return {
        ok: true,
        prototypeId: uniqueIds[0],
        source: match?.source || "dom"
      };
    }

    return { ok: true, prototypeId: null, source: null };
  }

  function buildTargetFromPrototype(prototype, pageContext, resolutionSource) {
    const customerType = prototype?.customer_type || prototype?.customerType || {};
    return {
      shortname: pageContext.shortname,
      itemId: String(pageContext.itemId),
      apiOrigin: pageContext.apiOrigin,
      customerPrototype: prototype,
      targetCustomerPrototypePk: String(prototype.pk),
      targetCustomerTypePk:
        customerType.pk != null ? String(customerType.pk) : null,
      displayName:
        prototype.display_name || prototype.displayName || prototype.name || "",
      singular: customerType.singular || customerType.name || "",
      plural: customerType.plural || "",
      mappingCount:
        prototype.reseller_customer_type_mapping_count ??
        prototype.resellerCustomerTypeMappingCount ??
        null,
      resolutionSource
    };
  }

  function getReportedMappingCount(target) {
    const value =
      target?.customerPrototype?.reseller_customer_type_mapping_count ??
      target?.customerPrototype?.resellerCustomerTypeMappingCount ??
      target?.mappingCount;
    if (value == null || value === "") {
      return null;
    }
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }

  function buildMappingCountComparison(target, exactFound) {
    const reported = getReportedMappingCount(target);
    if (reported == null) {
      return null;
    }
    const found = exactFound ?? 0;
    const missing = Math.max(0, reported - found);
    const comparison = { reported, found, missing };
    devLog("Mapping count comparison:", comparison);
    return comparison;
  }

  function formatCrossDashboardMappingWarning(missing) {
    if (!missing || missing <= 0) {
      return "";
    }
    if (missing === 1) {
      return "⚠ 1 additional channel mapping exists in another dashboard and is not shown here.";
    }
    return `⚠ ${missing} additional channel mappings exist in another dashboard and are not shown here.`;
  }

  function renderMappingCountWarning(comparison) {
    if (!comparison || comparison.missing <= 0) {
      return "";
    }
    return (
      `<div class="fhx-mapping-finder-cross-dashboard-warning">` +
      `${escapeHtml(formatCrossDashboardMappingWarning(comparison.missing))}` +
      `</div>`
    );
  }

  async function fetchCustomerPrototypeById(pageContext, prototypeId) {
    const path =
      `/companies/${encodeURIComponent(pageContext.shortname)}` +
      `/items/${encodeURIComponent(pageContext.itemId)}` +
      `/customer-prototypes/${encodeURIComponent(prototypeId)}/`;
    const result = await fareHarborApiFetch(path, pageContext.apiOrigin);
    if (!result.ok) {
      return {
        ok: false,
        error: `Could not load customer prototype ${prototypeId} for this item.`,
        details: result.error
      };
    }

    const prototype = result.data?.customer_prototype ?? result.data?.customerPrototype;
    if (!prototype || prototype.pk == null) {
      return {
        ok: false,
        error: `Could not load customer prototype ${prototypeId} for this item.`,
        details: "Response missing customer_prototype"
      };
    }

    const itemPk =
      prototype.item?.pk ??
      prototype.item_id ??
      prototype.itemId ??
      null;
    if (itemPk != null && String(itemPk) !== String(pageContext.itemId)) {
      return {
        ok: false,
        error: `Could not load customer prototype ${prototypeId} for this item.`,
        details: `Prototype belongs to item ${itemPk}`
      };
    }

    return {
      ok: true,
      target: buildTargetFromPrototype(prototype, pageContext, "api-detail")
    };
  }

  function findExactNameMatches(prototypes, displayName) {
    const target = normalizeCustomerTypeName(displayName);
    if (!target) {
      return [];
    }
    return prototypes.filter((prototype) => {
      const names = [prototype?.name, prototype?.display_name, prototype?.displayName]
        .filter(Boolean)
        .map(normalizeCustomerTypeName);
      return names.some((name) => name === target);
    });
  }

  async function resolvePrototypeForEditor(editorBlock, pageContext) {
    const idResult = extractPrototypeIdFromBlock(editorBlock);
    if (!idResult.ok) {
      logPrototypeResolutionDiagnostics("id-extraction-failed", editorBlock, pageContext, idResult);
      return { ok: false, error: idResult.error, ambiguousIds: idResult.ambiguousIds };
    }

    let context = logPrototypeResolutionDiagnostics("click-start", editorBlock, pageContext, {
      idExtraction: idResult
    });

    let prototypeId = idResult.prototypeId;
    let resolutionSource = idResult.source;

    if (!prototypeId) {
      const scopeResult = extractPrototypeIdFromAngularScope(editorBlock);
      if (scopeResult) {
        prototypeId = scopeResult.prototypeId;
        resolutionSource = scopeResult.source;
        context = {
          ...context,
          prototypeId,
          prototypeIdSource: resolutionSource
        };
        resolutionLog("Resolved prototype ID from Angular scope", scopeResult);
      }
    } else {
      resolutionLog("Resolved prototype ID from DOM", idResult);
    }

    if (prototypeId) {
      const fetched = await fetchCustomerPrototypeById(pageContext, prototypeId);
      if (!fetched.ok) {
        logPrototypeResolutionDiagnostics("fetch-by-id-failed", editorBlock, pageContext, {
          prototypeId,
          fetchError: fetched
        });
        return fetched;
      }
      fetched.target.resolutionSource = resolutionSource;
      resolutionLog("Prototype resolved by ID", {
        prototypePk: fetched.target.targetCustomerPrototypePk,
        source: resolutionSource
      });
      return fetched;
    }

    const listResult = await fetchCustomerPrototypesList(pageContext);
    if (!listResult.ok) {
      logPrototypeResolutionDiagnostics("prototype-list-failed", editorBlock, pageContext, {
        apiError: listResult.error,
        apiUrl: listResult.url
      });
      return {
        ok: false,
        error: "Could not resolve customer prototype for this editor.",
        details: listResult.error
      };
    }

    const prototypes = listResult.prototypes;
    const rankedCandidates = rankPrototypeCandidates(prototypes, context);
    logPrototypeResolutionDiagnostics("api-list-loaded", editorBlock, pageContext, {
      apiPrototypeCount: prototypes.length,
      topCandidates: rankedCandidates
    });

    const matchResult = matchPrototypesFromList(prototypes, context);
    if (matchResult.ok) {
      resolutionLog("Prototype resolved from API list", {
        prototypePk: matchResult.match.pk,
        source: matchResult.source
      });
      const fetched = await fetchCustomerPrototypeById(pageContext, matchResult.match.pk);
      if (!fetched.ok) {
        return fetched;
      }
      fetched.target.resolutionSource = matchResult.source;
      return fetched;
    }

    const failure = buildResolutionFailureMessage(
      context,
      prototypes,
      matchResult,
      rankedCandidates
    );
    logPrototypeResolutionDiagnostics("resolution-failed", editorBlock, pageContext, {
      apiPrototypeCount: prototypes.length,
      topCandidates: rankedCandidates,
      matchResult,
      failure
    });

    return {
      ok: false,
      error: failure.error,
      details: failure.details,
      ambiguousMatches: matchResult.matches?.map((prototype) => prototype.pk) ?? []
    };
  }

  async function resolvePrototypeForBlock(block, pageContext) {
    return resolvePrototypeForEditor(block, pageContext);
  }

  async function mapWithConcurrency(items, concurrency, fn, shouldCancel) {
    const results = new Array(items.length);
    let nextIndex = 0;

    async function worker() {
      while (nextIndex < items.length) {
        if (shouldCancel && shouldCancel()) {
          return;
        }
        const index = nextIndex;
        nextIndex += 1;
        results[index] = await fn(items[index], index);
      }
    }

    const workers = Array.from(
      { length: Math.min(concurrency, Math.max(items.length, 1)) },
      () => worker()
    );
    await Promise.all(workers);
    return results;
  }

  function getArrayField(data, snakeKey, camelKey) {
    const value = data?.[snakeKey] ?? data?.[camelKey];
    return Array.isArray(value) ? value : null;
  }

  function buildResellerItemApiBase(pageContext, resellerCompanyId, resellerItemId) {
    return (
      `/companies/${encodeURIComponent(pageContext.shortname)}` +
      `/reseller-companies/${encodeURIComponent(resellerCompanyId)}` +
      `/reseller-items/${encodeURIComponent(resellerItemId)}`
    );
  }

  function buildMappingDashboardUrl(pageContext, resellerCompanyId, resellerItemId, resellerCustomerTypeId) {
    return (
      `${pageContext.apiOrigin}/${encodeURIComponent(pageContext.shortname)}` +
      `/dashboard/settings/integrations/channels/${encodeURIComponent(resellerCompanyId)}` +
      `/items/${encodeURIComponent(resellerItemId)}` +
      `/customer-types/${encodeURIComponent(resellerCustomerTypeId)}/`
    );
  }

  function formatResellerItemName(result) {
    const ri = result.resellerItem || result.reseller_item;
    return ri?.name || ri?.unicode || ri?.short_name || "";
  }

  function formatResellerCustomerTypeName(result) {
    const rct = result.resellerCustomerType || result.reseller_customer_type;
    return rct?.name || rct?.unicode || rct?.short_name || "";
  }

  function getResellerCompanyFrom(mapping) {
    const mappingItem = mapping?.reseller_item ?? mapping?.resellerItem;
    if (mappingItem) {
      const company = mappingItem.reseller_company ?? mappingItem.resellerCompany;
      if (company) {
        return company;
      }
    }

    const mappingRct = mapping?.reseller_customer_type ?? mapping?.resellerCustomerType;
    const rctItem = mappingRct?.reseller_item ?? mappingRct?.resellerItem;
    if (rctItem) {
      return rctItem.reseller_company ?? rctItem.resellerCompany ?? null;
    }

    return null;
  }

  function logNormalizedMappingRowDebug(normalizedResult) {
    devLog("normalized mapping row debug", {
      mappingPk: normalizedResult.mappingPk,
      resellerCompany: normalizedResult.resellerCompany,
      resellerItem: normalizedResult.resellerItem,
      resellerCustomerType: normalizedResult.resellerCustomerType,
      customerPrototype: normalizedResult.customerPrototype
    });
  }

  function normalizeMappingEntry(mapping, ctx) {
    const customerPrototype =
      mapping?.customer_prototype ?? mapping?.customerPrototype ?? {};
    const customerType =
      customerPrototype?.customer_type ?? customerPrototype?.customerType ?? {};
    const resellerCustomerType =
      ctx.resellerCustomerType ||
      mapping?.reseller_customer_type ||
      mapping?.resellerCustomerType ||
      {};
    const resellerItem =
      ctx.resellerItem ||
      mapping?.reseller_item ||
      mapping?.resellerItem ||
      {};
    const resellerCompany = ctx.resellerCompany || getResellerCompanyFrom(mapping) || {};

    const resellerCompanyPk =
      resellerCompany?.pk != null
        ? String(resellerCompany.pk)
        : ctx.resellerCompanyId != null
          ? String(ctx.resellerCompanyId)
          : null;

    const normalizedResult = {
      mappingPk: mapping?.pk,
      mapping,
      customerPrototype,
      customerPrototypePk:
        customerPrototype?.pk != null ? String(customerPrototype.pk) : null,
      customerPrototypeDisplayName:
        customerPrototype?.display_name ||
        customerPrototype?.displayName ||
        customerPrototype?.name ||
        "",
      customerTypePk: customerType?.pk != null ? String(customerType.pk) : null,
      resellerCustomerType,
      resellerCustomerTypePk:
        resellerCustomerType?.pk != null
          ? String(resellerCustomerType.pk)
          : ctx.resellerCustomerTypeId != null
            ? String(ctx.resellerCustomerTypeId)
            : null,
      resellerItem,
      resellerItemPk:
        resellerItem?.pk != null
          ? String(resellerItem.pk)
          : ctx.resellerItemId != null
            ? String(ctx.resellerItemId)
            : null,
      resellerCompany,
      resellerCompanyPk,
      resellerCompanyName: resellerCompany?.name || "",
      resellerCompanyShortName: resellerCompany?.short_name || "",
      otaType: resellerCompany?.ota_type || resellerCompany?.otaType || "",
      openMappingUrl: buildMappingDashboardUrl(
        ctx.pageContext,
        resellerCompany?.pk ?? ctx.resellerCompanyId,
        resellerItem?.pk ?? ctx.resellerItemId,
        resellerCustomerType?.pk ?? ctx.resellerCustomerTypeId
      )
    };

    return normalizedResult;
  }

  function logExactMappingResultDebug(result) {
    devLog("Exact mapping result debug", {
      mappingPk: result.mappingPk || result.mapping?.pk,
      resultType: result.type || result.sourceType,
      resellerCompany: result.resellerCompany,
      resellerItem: result.resellerItem,
      resellerCustomerType: result.resellerCustomerType,
      resellerCompanyShortName: result.resellerCompany?.short_name ?? null,
      raw: result
    });
    devLog("resellerCompany fields debug", {
      mappingPk: result.mappingPk || result.mapping?.pk,
      keys: Object.keys(result.resellerCompany || {}),
      resellerCompany: result.resellerCompany
    });
    devLog("resellerCustomerType fields debug", {
      mappingPk: result.mappingPk || result.mapping?.pk,
      keys: Object.keys(result.resellerCustomerType || {}),
      resellerCustomerType: result.resellerCustomerType
    });
  }

  function formatChannelGroupLabelFromResellerCompany(resellerCompany) {
    if (!resellerCompany) {
      return "Channel";
    }

    const name = resellerCompany.name || resellerCompany.unicode || "";
    const channelLabel =
      resellerCompany.short_name ||
      resellerCompany.display_name ||
      resellerCompany.label ||
      "";

    const parts = [];
    if (name) {
      parts.push(name);
    }
    if (channelLabel && channelLabel !== name) {
      parts.push(channelLabel);
    }

    if (parts.length) {
      return parts.join(" · ");
    }

    const otaType = resellerCompany.ota_type || resellerCompany.otaType || "";
    if (otaType) {
      return otaType.charAt(0).toUpperCase() + otaType.slice(1);
    }

    return "Channel";
  }

  function resolveResellerCompanyFromResult(result) {
    return (
      result.resellerCompany ||
      result.reseller_company ||
      result.resellerItem?.reseller_company ||
      result.reseller_item?.reseller_company ||
      result.resellerCustomerType?.reseller_item?.reseller_company ||
      result.reseller_customer_type?.reseller_item?.reseller_company ||
      null
    );
  }

  function formatChannelGroupLabel(result) {
    return formatChannelGroupLabelFromResellerCompany(resolveResellerCompanyFromResult(result));
  }

  async function findCustomerTypeMappings(target, options = {}) {
    const onProgress = options.onProgress || (() => {});
    const shouldCancel = options.shouldCancel || (() => false);
    const cache = options.cache || {};
    const failures = [];
    const exactMatches = [];
    const broaderMatches = [];
    const stats = {
      resellerCompaniesScanned: 0,
      resellerItemsScanned: 0,
      itemMappingsMatched: 0,
      resellerCustomerTypesChecked: 0,
      mappingRequests: 0
    };

    const pageContext = {
      shortname: target.shortname,
      itemId: target.itemId,
      apiOrigin: target.apiOrigin
    };

    async function cachedFetch(key, fetcher) {
      if (cache[key] !== undefined) {
        return cache[key];
      }
      const result = await fetcher();
      cache[key] = result;
      return result;
    }

    function recordFailure(url, error) {
      failures.push({ url, error });
      devLog("Endpoint failure:", url, error);
    }

    onProgress("Scanning reseller companies…");
    const companiesUrl = `/companies/${encodeURIComponent(pageContext.shortname)}/reseller-companies/`;
    const companiesResult = await cachedFetch(`companies:${pageContext.shortname}`, () =>
      fareHarborApiFetch(companiesUrl, pageContext.apiOrigin)
    );
    if (shouldCancel()) {
      return { cancelled: true, exactMatches, broaderMatches, failures, stats };
    }
    if (!companiesResult.ok) {
      recordFailure(companiesResult.url, companiesResult.error);
      return { cancelled: false, exactMatches, broaderMatches, failures, stats, fatalError: companiesResult.error };
    }

    const companies =
      getArrayField(companiesResult.data, "reseller_companies", "resellerCompanies") || [];
    stats.resellerCompaniesScanned = companies.length;
    devLog("Reseller companies scanned:", companies.length);

    const matchedResellerItems = [];

    await mapWithConcurrency(
      companies,
      CONCURRENCY_LIMIT,
      async (company) => {
        if (shouldCancel()) {
          return;
        }
        const resellerCompanyId = company?.pk;
        if (resellerCompanyId == null) {
          return;
        }

        const itemsUrl =
          `/companies/${encodeURIComponent(pageContext.shortname)}` +
          `/reseller-companies/${encodeURIComponent(resellerCompanyId)}/reseller-items/`;
        const itemsResult = await cachedFetch(`items:${resellerCompanyId}`, () =>
          fareHarborApiFetch(itemsUrl, pageContext.apiOrigin)
        );
        if (!itemsResult.ok) {
          recordFailure(itemsResult.url, itemsResult.error);
          return;
        }

        const items = getArrayField(itemsResult.data, "reseller_items", "resellerItems") || [];
        stats.resellerItemsScanned += items.length;

        await mapWithConcurrency(
          items,
          CONCURRENCY_LIMIT,
          async (resellerItem) => {
            if (shouldCancel()) {
              return;
            }
            const resellerItemId = resellerItem?.pk;
            if (resellerItemId == null) {
              return;
            }

            const mappingsUrl =
              `${buildResellerItemApiBase(pageContext, resellerCompanyId, resellerItemId)}` +
              `/reseller-item-mappings/`;
            const mappingsResult = await cachedFetch(
              `item-mappings:${resellerCompanyId}:${resellerItemId}`,
              () => fareHarborApiFetch(mappingsUrl, pageContext.apiOrigin)
            );
            if (!mappingsResult.ok) {
              recordFailure(mappingsResult.url, mappingsResult.error);
              return;
            }

            const mappings =
              getArrayField(
                mappingsResult.data,
                "reseller_item_mappings",
                "resellerItemMappings"
              ) || [];
            const mapsToCurrentItem = mappings.some((mapping) => {
              const itemPk = mapping?.item?.pk ?? mapping?.item_id ?? mapping?.itemId;
              return itemPk != null && String(itemPk) === String(pageContext.itemId);
            });
            if (!mapsToCurrentItem) {
              return;
            }

            stats.itemMappingsMatched += 1;
            matchedResellerItems.push({
              resellerCompanyId: String(resellerCompanyId),
              resellerCompany: company,
              resellerItemId: String(resellerItemId),
              resellerItem
            });
          },
          shouldCancel
        );
      },
      shouldCancel
    );

    if (shouldCancel()) {
      return { cancelled: true, exactMatches, broaderMatches, failures, stats };
    }

    devLog("Matched reseller items:", matchedResellerItems.length, matchedResellerItems);

    let processedItems = 0;
    await mapWithConcurrency(
      matchedResellerItems,
      CONCURRENCY_LIMIT,
      async (entry) => {
        if (shouldCancel()) {
          return;
        }
        processedItems += 1;
        onProgress(`Scanning reseller items (${processedItems}/${matchedResellerItems.length})…`);

        const typesUrl =
          `${buildResellerItemApiBase(pageContext, entry.resellerCompanyId, entry.resellerItemId)}` +
          `/reseller-customer-types/`;
        const typesResult = await cachedFetch(
          `customer-types:${entry.resellerCompanyId}:${entry.resellerItemId}`,
          () => fareHarborApiFetch(typesUrl, pageContext.apiOrigin)
        );
        if (!typesResult.ok) {
          recordFailure(typesResult.url, typesResult.error);
          return;
        }

        const types =
          getArrayField(typesResult.data, "reseller_customer_types", "resellerCustomerTypes") ||
          [];

        await mapWithConcurrency(
          types,
          CONCURRENCY_LIMIT,
          async (resellerCustomerType) => {
            if (shouldCancel()) {
              return;
            }
            const resellerCustomerTypeId = resellerCustomerType?.pk;
            if (resellerCustomerTypeId == null) {
              return;
            }
            stats.resellerCustomerTypesChecked += 1;
            onProgress("Checking customer type mappings…");

            const mappingUrl =
              `${buildResellerItemApiBase(pageContext, entry.resellerCompanyId, entry.resellerItemId)}` +
              `/reseller-customer-types/${encodeURIComponent(resellerCustomerTypeId)}` +
              `/reseller-customer-type-mappings/`;
            const mappingResult = await cachedFetch(
              `type-mappings:${entry.resellerCompanyId}:${entry.resellerItemId}:${resellerCustomerTypeId}`,
              () => fareHarborApiFetch(mappingUrl, pageContext.apiOrigin)
            );
            stats.mappingRequests += 1;
            if (!mappingResult.ok) {
              recordFailure(mappingResult.url, mappingResult.error);
              return;
            }

            const mappings =
              getArrayField(
                mappingResult.data,
                "reseller_customer_type_mappings",
                "resellerCustomerTypeMappings"
              ) || [];

            for (const mapping of mappings) {
              const normalized = normalizeMappingEntry(mapping, {
                pageContext,
                resellerCompanyId: entry.resellerCompanyId,
                resellerCompany: entry.resellerCompany,
                resellerItemId: entry.resellerItemId,
                resellerItem: entry.resellerItem,
                resellerCustomerTypeId: String(resellerCustomerTypeId),
                resellerCustomerType
              });

              if (normalized.customerPrototypePk === target.targetCustomerPrototypePk) {
                logNormalizedMappingRowDebug(normalized);
                logExactMappingResultDebug(normalized);
                exactMatches.push(normalized);
              } else if (
                target.targetCustomerTypePk &&
                normalized.customerTypePk === target.targetCustomerTypePk
              ) {
                logNormalizedMappingRowDebug(normalized);
                broaderMatches.push(normalized);
              }
            }
          },
          shouldCancel
        );
      },
      shouldCancel
    );

    devLog("Scan complete:", {
      exact: exactMatches.length,
      broader: broaderMatches.length,
      failures: failures.length,
      stats
    });

    return {
      cancelled: shouldCancel(),
      exactMatches,
      broaderMatches,
      failures,
      stats,
      target
    };
  }

  function groupMatchesByChannel(matches) {
    const groups = new Map();
    for (const match of matches) {
      const key = match.resellerCompanyPk || "unknown";
      if (!groups.has(key)) {
        groups.set(key, {
          resellerCompanyPk: match.resellerCompanyPk,
          matches: []
        });
      }
      groups.get(key).matches.push(match);
    }
    return [...groups.values()];
  }

  function getChannelGroupLabel(group) {
    const representative = group.matches?.[0];
    if (!representative) {
      return "Channel";
    }
    return formatChannelGroupLabel(representative);
  }

  function formatExactMatchSummary(count, inCurrentDashboardOnly) {
    const locationLabel = count === 1 ? "location" : "locations";
    const dashboardSuffix = inCurrentDashboardOnly ? " in this dashboard" : "";
    return `Mapped in ${count} channel ${locationLabel}${dashboardSuffix}.`;
  }

  function renderMappingGroupList(matches, subdued) {
    if (!matches.length) {
      return "";
    }

    const mappingClass = subdued
      ? "fhx-mapping-finder-mapping fhx-mapping-finder-mapping--subdued"
      : "fhx-mapping-finder-mapping";

    const items = matches
      .map((match) => {
        const itemName = formatResellerItemName(match) || match.resellerItemPk || "—";
        const customerTypeName =
          formatResellerCustomerTypeName(match) || match.resellerCustomerTypePk || "—";

        return (
          `<div class="${mappingClass}">` +
          `<div class="fhx-mapping-finder-mapping-item">${escapeHtml(itemName)}</div>` +
          `<div class="fhx-mapping-finder-mapping-type">${escapeHtml(customerTypeName)}</div>` +
          `<a class="fhx-mapping-finder-link" href="${escapeHtml(match.openMappingUrl)}" target="_blank" rel="noopener noreferrer">Open mapping</a>` +
          `</div>`
        );
      })
      .join("");

    return `<div class="fhx-mapping-finder-mapping-list">${items}</div>`;
  }

  function renderCustomerTypeMappingResults(panelEl, result) {
    if (!panelEl) {
      return;
    }

    if (result.phase === "progress") {
      panelEl.innerHTML =
        `<div class="fhx-mapping-finder-panel-header">` +
        `<span class="fhx-mapping-finder-title">Channel mappings</span>` +
        `<button type="button" class="fhx-mapping-finder-close" data-action="cancel" title="Cancel">×</button>` +
        `</div>` +
        `<div class="fhx-mapping-finder-progress">${escapeHtml(result.message || "Working…")}</div>`;
      return;
    }

    if (result.phase === "error") {
      panelEl.innerHTML =
        `<div class="fhx-mapping-finder-panel-header">` +
        `<span class="fhx-mapping-finder-title">Channel mappings</span>` +
        `<button type="button" class="fhx-mapping-finder-close" data-action="close" title="Close">×</button>` +
        `</div>` +
        `<div class="fhx-mapping-finder-error">${escapeHtml(result.error || "Something went wrong.")}</div>`;
      if (result.details) {
        panelEl.innerHTML += `<div class="fhx-mapping-finder-footnote">${escapeHtml(result.details)}</div>`;
      }
      return;
    }

    if (result.cancelled) {
      panelEl.innerHTML =
        `<div class="fhx-mapping-finder-panel-header">` +
        `<span class="fhx-mapping-finder-title">Channel mappings</span>` +
        `<button type="button" class="fhx-mapping-finder-close" data-action="close" title="Close">×</button>` +
        `</div>` +
        `<div class="fhx-mapping-finder-progress">Scan cancelled.</div>`;
      return;
    }

    const exactMatches = result.exactMatches || [];
    const broaderMatches = result.broaderMatches || [];
    const failures = result.failures || [];
    const target = result.target || {};
    const mappingCountComparison = buildMappingCountComparison(target, exactMatches.length);

    const mappingCountWarning = renderMappingCountWarning(mappingCountComparison);

    let body = "";

    if (exactMatches.length > 0) {
      exactMatches.forEach((match) => logExactMappingResultDebug(match));
      const inCurrentDashboardOnly =
        mappingCountComparison && mappingCountComparison.reported > mappingCountComparison.found;
      body += `<div class="fhx-mapping-finder-summary">${escapeHtml(formatExactMatchSummary(exactMatches.length, inCurrentDashboardOnly))}</div>`;
      body += mappingCountWarning;
      for (const group of groupMatchesByChannel(exactMatches)) {
        const channelLabel = getChannelGroupLabel(group);
        devLog("Exact mapping group label debug", {
          resellerCompanyPk: group.resellerCompanyPk,
          label: channelLabel,
          representative: group.matches?.[0]
        });
        body +=
          `<div class="fhx-mapping-finder-group">` +
          `<div class="fhx-mapping-finder-group-title">${escapeHtml(channelLabel)}</div>` +
          renderMappingGroupList(group.matches, false) +
          `</div>`;
      }
    } else if (broaderMatches.length > 0) {
      body +=
        `<div class="fhx-mapping-finder-warning">No exact customer prototype mapping found, but the same FareHarbor customer type is mapped elsewhere.</div>`;
      body += mappingCountWarning;
      for (const group of groupMatchesByChannel(broaderMatches)) {
        const channelLabel = getChannelGroupLabel(group);
        body +=
          `<div class="fhx-mapping-finder-group">` +
          `<div class="fhx-mapping-finder-group-title">${escapeHtml(channelLabel)}</div>` +
          renderMappingGroupList(group.matches, true) +
          `</div>`;
      }
    } else {
      body += `<div class="fhx-mapping-finder-empty">No channel mappings found for this customer prototype in the current dashboard.</div>`;
      body += mappingCountWarning;
    }

    if (failures.length > 0) {
      if (devModeEnabled) {
        const failureLines = failures
          .map((f) => `${f.url}: ${f.error}`)
          .map(escapeHtml)
          .join("<br>");
        body += `<div class="fhx-mapping-finder-dev"><strong>Endpoint failures (${failures.length})</strong><br>${failureLines}</div>`;
      } else {
        body += `<div class="fhx-mapping-finder-footnote">${failures.length} endpoint request(s) failed during scan.</div>`;
      }
    }

    panelEl.innerHTML =
      `<div class="fhx-mapping-finder-panel-header">` +
      `<span class="fhx-mapping-finder-title">Channel mappings</span>` +
      `<button type="button" class="fhx-mapping-finder-close" data-action="close" title="Close">×</button>` +
      `</div>` +
      body;
  }

  function injectStyles() {
    if (document.getElementById("fhx-mapping-finder-styles")) {
      return;
    }
    const style = document.createElement("style");
    style.id = "fhx-mapping-finder-styles";
    style.textContent = `
      .fhx-mapping-finder-wrap {
        margin: 6px 0 10px;
      }
      .fhx-mapping-finder-inline {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
      }
      .fhx-mapping-finder-btn {
        appearance: none;
        -webkit-appearance: none;
        display: inline-flex;
        align-items: center;
        margin: 0;
        padding: 0;
        background: none;
        border: none;
        border-radius: 0;
        font-size: 13px;
        font-weight: 400;
        color: #6b8ca3;
        cursor: pointer;
        line-height: 1.4;
        white-space: nowrap;
        font-family: inherit;
        box-shadow: none;
      }
      .fhx-mapping-finder-btn:hover:not(:disabled) {
        color: #4d6272;
        text-decoration: underline;
      }
      .fhx-mapping-finder-btn:disabled {
        opacity: 0.6;
        cursor: default;
      }
      .fhx-mapping-finder-panel {
        margin-top: 8px;
        max-width: 520px;
        border: 1px solid #d7dee6;
        background: #fafbfc;
        border-radius: 4px;
        padding: 10px 12px;
        font-size: 12px;
        color: #243746;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
      }
      .fhx-mapping-finder-panel-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        margin-bottom: 8px;
      }
      .fhx-mapping-finder-title {
        font-weight: 600;
        font-size: 12px;
      }
      .fhx-mapping-finder-close {
        appearance: none;
        border: none;
        background: transparent;
        color: #6b7c8a;
        font-size: 16px;
        line-height: 1;
        cursor: pointer;
        padding: 0 2px;
      }
      .fhx-mapping-finder-progress,
      .fhx-mapping-finder-empty,
      .fhx-mapping-finder-footnote {
        color: #4d6272;
      }
      .fhx-mapping-finder-error,
      .fhx-mapping-finder-warning {
        color: #8a4b12;
        background: #fff7ed;
        border: 1px solid #f0d2a6;
        border-radius: 4px;
        padding: 8px;
      }
      .fhx-mapping-finder-cross-dashboard-warning {
        margin: 6px 0 12px;
        padding: 8px 10px;
        border: 1px solid #e0b45c;
        background: #fff8e8;
        color: #7a4d00;
        font-size: 11px;
        font-weight: 600;
        line-height: 1.4;
        border-radius: 4px;
      }
      .fhx-mapping-finder-summary {
        margin-bottom: 8px;
      }
      .fhx-mapping-finder-group {
        margin-top: 14px;
      }
      .fhx-mapping-finder-group:first-of-type {
        margin-top: 10px;
      }
      .fhx-mapping-finder-group-title {
        font-weight: 600;
        font-size: 12px;
        margin-bottom: 6px;
        color: #1f3342;
      }
      .fhx-mapping-finder-mapping-list {
        padding-left: 10px;
        border-left: 2px solid #e3e9ef;
      }
      .fhx-mapping-finder-mapping {
        padding: 0 0 8px 0;
      }
      .fhx-mapping-finder-mapping:not(:last-child) {
        margin-bottom: 6px;
        border-bottom: 1px solid #eef2f6;
      }
      .fhx-mapping-finder-mapping-item {
        font-size: 11px;
        font-weight: 400;
        line-height: 1.35;
        color: #243746;
      }
      .fhx-mapping-finder-mapping-item::before {
        content: "• ";
        color: #6b7c8a;
      }
      .fhx-mapping-finder-mapping-type {
        font-size: 10px;
        line-height: 1.3;
        color: #6b7c8a;
        margin-top: 1px;
        padding-left: 10px;
      }
      .fhx-mapping-finder-mapping .fhx-mapping-finder-link {
        display: inline-block;
        font-size: 10px;
        margin-top: 3px;
        padding-left: 10px;
      }
      .fhx-mapping-finder-mapping--subdued .fhx-mapping-finder-mapping-item,
      .fhx-mapping-finder-mapping--subdued .fhx-mapping-finder-mapping-type {
        color: #6b7c8a;
      }
      .fhx-mapping-finder-link {
        color: #2f6fed;
        text-decoration: none;
      }
      .fhx-mapping-finder-link:hover {
        text-decoration: underline;
      }
      .fhx-mapping-finder-dev {
        margin-top: 8px;
        font-size: 11px;
        color: #5c6b78;
        word-break: break-word;
      }
    `;
    document.documentElement.appendChild(style);
  }

  function applyFeatureSetting(enabled, reason) {
    featureEnabled = enabled !== false;
    if (!featureEnabled) {
      stopObserver();
      stopInsertionRetry();
      if (debounceTimer) {
        clearTimeout(debounceTimer);
        debounceTimer = null;
      }
      removeAllInjectedUi();
      watchersActive = false;
      return;
    }
    evaluateLifecycle(reason || "setting-enabled");
  }

  function initSettingsBinding() {
    const settings = window.FHSettings;
    if (!settings) {
      return;
    }
    settings.get(SETTING_KEY, (value) => {
      applyFeatureSetting(value, "settings-init");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SETTING_KEY]) {
        applyFeatureSetting(changes[SETTING_KEY].newValue, "setting-change");
      }
    });
  }

  function cleanupStaleInjections() {
    document.querySelectorAll(".fhx-mapping-finder-wrap").forEach((wrap) => {
      const warningEl = wrap.previousElementSibling;
      const editorBlock =
        wrap.closest('form, [ng-controller*="CustomerPrototype"], .edit-form, .modal') ||
        wrap.closest(utils.SELECTORS.CUSTOMER_TYPE_BLOCKS);
      const saveBtn = editorBlock?.querySelector(SAVE_EDIT_SELECTOR);
      const warningOk =
        warningEl &&
        USED_BY_CHANNELS_RE.test(warningEl.textContent || "") &&
        isElementVisible(warningEl);
      const editorOpen = saveBtn && isElementVisible(saveBtn);

      if (!editorOpen || !warningOk) {
        wrap.remove();
      }
    });

    utils.$$(utils.SELECTORS.CUSTOMER_TYPE_BLOCKS).forEach((block) => {
      block.removeAttribute(INJECTED_ATTR);
      const hasOpenEditor = block.querySelector(SAVE_EDIT_SELECTOR) && isElementVisible(block.querySelector(SAVE_EDIT_SELECTOR));
      if (hasOpenEditor) {
        return;
      }
      block.querySelectorAll(".fhx-mapping-finder-wrap").forEach((wrap) => wrap.remove());
    });
  }

  function ensureEditorUi(warningEl, editorBlock) {
    const existingButton = editorBlock.querySelector(`#${EXACT_MAPPINGS_BUTTON_ID}`);
    if (existingButton) {
      return existingButton.closest(".fhx-mapping-finder-wrap");
    }

    const existing = warningEl.nextElementSibling;
    if (
      existing &&
      existing.classList.contains("fhx-mapping-finder-wrap") &&
      existing.getAttribute(INJECTED_ATTR) === "1"
    ) {
      return existing;
    }

    editorBlock.querySelectorAll(".fhx-mapping-finder-wrap").forEach((wrap) => {
      if (wrap.previousElementSibling !== warningEl) {
        wrap.remove();
      }
    });

    const wrap = document.createElement("div");
    wrap.className = "fhx-mapping-finder-wrap";
    wrap.setAttribute(INJECTED_ATTR, "1");
    wrap.innerHTML =
      `<div class="fhx-mapping-finder-inline">` +
      `<button type="button" id="${EXACT_MAPPINGS_BUTTON_ID}" class="fhx-mapping-finder-btn">Find exact mappings</button>` +
      `</div>` +
      `<div class="fhx-mapping-finder-panel" hidden></div>`;

    warningEl.insertAdjacentElement("afterend", wrap);
    wireEditorUi(editorBlock, wrap);
    devLog("button inserted", { href: location.href });
    return wrap;
  }

  function wireEditorUi(editorBlock, wrap) {
    const button = wrap.querySelector(".fhx-mapping-finder-btn");
    const panel = wrap.querySelector(".fhx-mapping-finder-panel");
    let cancelled = false;
    let running = false;

    function setPanelVisible(visible) {
      if (!panel) {
        return;
      }
      if (visible) {
        panel.removeAttribute("hidden");
      } else {
        panel.setAttribute("hidden", "hidden");
      }
    }

    panel.addEventListener("click", (event) => {
      const action = event.target?.getAttribute?.("data-action");
      if (action === "close") {
        setPanelVisible(false);
      }
      if (action === "cancel") {
        cancelled = true;
      }
    });

    button.addEventListener("click", async () => {
      if (running) {
        return;
      }

      const pageContext = parseCustomerPrototypePageContext();
      if (!pageContext) {
        return;
      }

      running = true;
      cancelled = false;
      button.disabled = true;
      setPanelVisible(true);
      renderCustomerTypeMappingResults(panel, {
        phase: "progress",
        message: "Fetching customer prototype…"
      });

      devLog("Page context:", pageContext);

      try {
        const resolved = await resolvePrototypeForEditor(editorBlock, pageContext);
        if (!resolved.ok) {
          renderCustomerTypeMappingResults(panel, {
            phase: "error",
            error: resolved.error,
            details:
              resolved.details ||
              (resolved.ambiguousMatches?.length
                ? `Candidate PKs: ${resolved.ambiguousMatches.join(", ")}`
                : "")
          });
          return;
        }

        devLog("Target prototype:", {
          prototypePk: resolved.target.targetCustomerPrototypePk,
          customerTypePk: resolved.target.targetCustomerTypePk,
          displayName: resolved.target.displayName,
          resolutionSource: resolved.target.resolutionSource
        });

        const scanResult = await findCustomerTypeMappings(resolved.target, {
          onProgress(message) {
            renderCustomerTypeMappingResults(panel, { phase: "progress", message });
          },
          shouldCancel() {
            return cancelled;
          },
          cache: {}
        });

        renderCustomerTypeMappingResults(panel, {
          phase: "results",
          ...scanResult
        });
      } catch (err) {
        renderCustomerTypeMappingResults(panel, {
          phase: "error",
          error: err?.message || String(err)
        });
      } finally {
        running = false;
        button.disabled = false;
      }
    });
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function isTargetPageContext() {
    return !!parseCustomerPrototypePageContext();
  }

  function removeAllInjectedUi() {
    document.querySelectorAll(".fhx-mapping-finder-wrap").forEach((wrap) => wrap.remove());
    document.querySelectorAll(`[${INJECTED_ATTR}]`).forEach((el) => {
      el.removeAttribute(INJECTED_ATTR);
    });
  }

  function scanAndInjectButtons() {
    const pageContext = parseCustomerPrototypePageContext();
    if (!pageContext) {
      return false;
    }

    injectStyles();
    cleanupStaleInjections();

    const editorBlocks = getExpandedEditorBlocks();
    devLog("Injection scan:", {
      expandedEditorBlocks: editorBlocks.length
    });

    let injectedCount = 0;

    for (const editorBlock of editorBlocks) {
      const warningEl = findUsedByChannelsWarning(editorBlock);
      if (!warningEl) {
        devLog("Skipped editor block: no visible 'Used by channels' warning");
        continue;
      }

      devLog("Found 'Used by channels' warning in expanded editor");
      const hadButton = !!editorBlock.querySelector(`#${EXACT_MAPPINGS_BUTTON_ID}`);
      ensureEditorUi(warningEl, editorBlock);
      if (!hadButton && editorBlock.querySelector(`#${EXACT_MAPPINGS_BUTTON_ID}`)) {
        injectedCount += 1;
      }
    }

    devLog("Injection scan complete:", {
      expandedEditorBlocks: editorBlocks.length,
      injectedUiCount: injectedCount
    });

    return injectedCount > 0 || editorBlocks.length === 0;
  }

  function scheduleScan() {
    if (!featureEnabled) {
      return;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }
    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      scanAndInjectButtons();
    }, 200);
  }

  function stopInsertionRetry() {
    if (insertionRetryTimer) {
      clearTimeout(insertionRetryTimer);
      insertionRetryTimer = null;
    }
    insertionRetryAttempts = 0;
  }

  function scheduleInsertionRetry(reason) {
    if (!featureEnabled || !isTargetPageContext()) {
      stopInsertionRetry();
      return;
    }

    if (insertionRetryTimer) {
      return;
    }

    insertionRetryAttempts = 0;

    const runAttempt = () => {
      if (!isTargetPageContext()) {
        stopInsertionRetry();
        return;
      }

      insertionRetryAttempts += 1;
      devLog("insertion pass scheduled", { reason, attempt: insertionRetryAttempts });
      scanAndInjectButtons();

      const editorBlocks = getExpandedEditorBlocks();
      if (editorBlocks.length === 0) {
        stopInsertionRetry();
        return;
      }

      const hasReadyTarget = editorBlocks.some((editorBlock) =>
        findUsedByChannelsWarning(editorBlock)
      );
      const allInjected =
        editorBlocks.length > 0 &&
        editorBlocks.every((editorBlock) =>
          editorBlock.querySelector(`#${EXACT_MAPPINGS_BUTTON_ID}`)
        );

      if (hasReadyTarget && allInjected) {
        stopInsertionRetry();
        return;
      }

      if (insertionRetryAttempts >= MAX_INSERTION_RETRIES) {
        devLog("insertion retry max attempts reached", { reason });
        stopInsertionRetry();
        return;
      }

      insertionRetryTimer = setTimeout(() => {
        insertionRetryTimer = null;
        runAttempt();
      }, INSERTION_RETRY_MS);
    };

    runAttempt();
  }

  function scheduleInsertionPass(reason) {
    scheduleScan();
    scheduleInsertionRetry(reason);
  }

  function startObserver() {
    if (observer) {
      return;
    }
    observer = new MutationObserver(() => {
      if (isTargetPageContext()) {
        scheduleScan();
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  function evaluateLifecycle(reason) {
    if (!featureEnabled) {
      stopObserver();
      stopInsertionRetry();
      removeAllInjectedUi();
      watchersActive = false;
      return;
    }

    if (!isFareHarborHost()) {
      if (watchersActive) {
        devLog("observer stopped", { reason, href: location.href });
      }
      stopObserver();
      stopInsertionRetry();
      removeAllInjectedUi();
      watchersActive = false;
      return;
    }

    if (isTargetPageContext()) {
      if (!watchersActive) {
        devLog("eligible page detected", { reason, href: location.href });
        startObserver();
        devLog("observer started", { reason });
        watchersActive = true;
      }
      scheduleInsertionPass(reason);
      return;
    }

    if (watchersActive) {
      devLog("observer stopped", { reason, href: location.href });
    }
    stopObserver();
    stopInsertionRetry();
    removeAllInjectedUi();
    watchersActive = false;
  }

  function handleRouteChange(reason) {
    lastTrackedHref = location.href;
    stopInsertionRetry();
    scheduleLifecycleEval(reason || "route-change");
  }

  function startRouteWatchers() {
    if (routeWatchersStarted) {
      return;
    }
    routeWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", () => handleRouteChange("popstate"));
    window.addEventListener("hashchange", () => handleRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        handleRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        handleRouteChange("replaceState");
        return result;
      };
    } catch (err) {
      console.warn(LOG_PREFIX, "history hook unavailable:", err);
    }

    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        handleRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  async function init() {
    devModeEnabled = await isDevModeEnabledAsync();
    initSettingsBinding();
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes[DEV_MODE_STORAGE_KEY]) {
          void isDevModeEnabledAsync().then((active) => {
            devModeEnabled = active;
          });
        }
      });
    } catch {
      // ignore
    }

    const boot = () => {
      if (isFareHarborHost()) {
        startRouteWatchers();
      }
      evaluateLifecycle("dom-content-loaded");
    };

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", boot, { once: true });
    } else {
      boot();
    }
  }

  window.CustomerTypeMappingFinder = {
    fareHarborApiFetch,
    parseCustomerPrototypePageContext,
    extractPrototypeIdFromBlock,
    extractPrototypeIdFromAngularScope,
    resolvePrototypeForEditor,
    resolvePrototypeForBlock,
    findCustomerTypeMappings,
    renderCustomerTypeMappingResults,
    mapWithConcurrency,
    formatChannelGroupLabel,
    formatChannelGroupLabelFromResellerCompany,
    formatResellerItemName,
    formatResellerCustomerTypeName,
    getExpandedEditorBlocks,
    findUsedByChannelsWarning
  };

  init();
  console.log("[customer-type-mapping-finder] Module initialized successfully");
})();
