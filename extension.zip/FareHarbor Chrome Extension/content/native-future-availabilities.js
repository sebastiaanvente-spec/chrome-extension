console.log("[native-future-availabilities] script loaded");

(function nativeFutureAvailabilitiesModule() {
  "use strict";

  const LOG_PREFIX = "[native-future-availabilities]";
  const SETTING_KEY = "autoEnableNativeFutureAvailabilities";
  const CHECKBOX_SELECTOR = 'input[ng-model="options.showFutureAvailabilities"]';
  const DISPLAY_OPTIONS_BUTTON_SELECTOR =
    'button.tb-btn--flyout[ng-toggle="resellerItemsDisplayOptions"]';
  const ROUTE_REEVAL_DELAY_MS = 150;
  const ROUTE_POLL_MS = 500;
  const RETRY_INTERVAL_MS = 500;
  const RETRY_MAX_MS = 10000;

  // Channel Items listing lives at /channels/{channelId}/ (not /items/{itemId}/).
  const CHANNEL_ITEMS_LISTING_RE =
    /^\/[^/]+\/dashboard\/settings\/integrations\/channels\/(\d+)(?:\/items)?\/?$/;

  let hrefPollTimer = null;
  let lifecycleEvalTimer = null;
  let retryTimer = null;
  let retryStartedAt = 0;
  let lastTrackedHref = location.href;
  let routeWatchersStarted = false;
  let featureEnabled = true;
  /** @type {string | null} page key we opened the Display options flyout for */
  let openedFlyoutPageKey = null;
  /** @type {string | null} page key we already clicked the checkbox for */
  let clickedPageKey = null;
  /** @type {string | null} page key where checkbox was confirmed checked */
  let confirmedPageKey = null;

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function parseChannelItemsListingPageContext(pathname) {
    const normalized = String(pathname || "").replace(/\/+$/, "");
    if (!normalized || /\/items\/\d+/.test(normalized)) {
      return null;
    }

    const match = normalized.match(CHANNEL_ITEMS_LISTING_RE);
    if (!match) {
      return null;
    }

    const parts = normalized.split("/").filter(Boolean);
    return {
      companyShortname: parts[0],
      channelId: match[1]
    };
  }

  function parsePageContext() {
    return parseChannelItemsListingPageContext(location.pathname || "");
  }

  function isUrlEligible() {
    return isFareHarborHost() && !!parsePageContext();
  }

  function buildPageKey(ctx) {
    if (!ctx) {
      return null;
    }
    return `${ctx.companyShortname}|${ctx.channelId}`;
  }

  function findFutureAvailabilitiesCheckbox(root) {
    const scope = root || document;
    return scope.querySelector(CHECKBOX_SELECTOR);
  }

  function findDisplayOptionsButton(root) {
    const scope = root || document;
    const byToggle = scope.querySelector(DISPLAY_OPTIONS_BUTTON_SELECTOR);
    if (byToggle) {
      return byToggle;
    }

    const buttons = scope.querySelectorAll("button.tb-btn--flyout");
    for (const button of buttons) {
      const tip = button.getAttribute("ng-tip") || "";
      const label = button.textContent || "";
      if (/display\s*options/i.test(tip) || /display\s*options/i.test(label)) {
        return button;
      }
    }
    return null;
  }

  function isFlyoutExpanded(button) {
    return !!button && button.getAttribute("aria-expanded") === "true";
  }

  /**
   * Pure decision helper for the enable flow.
   * @returns {"wait"|"done"|"open-flyout"|"click"|"already-clicked"|"close-flyout"}
   */
  function resolveFutureAvailabilitiesAction(checkbox, pageKey, state) {
    const flyoutExpanded = !!state?.flyoutExpanded;
    const openedFlyout = state?.openedFlyoutPageKey === pageKey;
    const alreadyClicked = state?.clickedPageKey === pageKey;

    if (checkbox && checkbox.checked) {
      if (openedFlyout && flyoutExpanded) {
        return "close-flyout";
      }
      return "done";
    }

    if (!state?.displayOptionsButton) {
      return "wait";
    }

    if (!checkbox || !flyoutExpanded) {
      if (openedFlyout && flyoutExpanded && !checkbox) {
        return "wait";
      }
      if (openedFlyout && !flyoutExpanded && !checkbox) {
        // We already tried opening; wait for Angular, or retry open once more via click path.
        return "open-flyout";
      }
      return "open-flyout";
    }

    // Flyout open, checkbox present, unchecked
    if (alreadyClicked) {
      return "already-clicked";
    }
    return "click";
  }

  function closeDisplayOptionsFlyout(button, pageKey, reason) {
    if (!button || !isFlyoutExpanded(button)) {
      return;
    }
    if (openedFlyoutPageKey !== pageKey) {
      return;
    }
    log("closing Display options flyout", { reason, pageKey });
    button.click();
  }

  function applyFeatureSetting(enabled, reason) {
    featureEnabled = enabled !== false;
    if (!featureEnabled) {
      stopRetryLoop();
      resetPageState();
      log("feature disabled", { reason });
      return;
    }
    evaluateLifecycle(reason || "setting-enabled");
  }

  function initSettingsBinding() {
    const settings = window.FHSettings;
    if (!settings) {
      return;
    }
    settings.get(SETTING_KEY, (value) => {
      applyFeatureSetting(value, "settings-init");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SETTING_KEY]) {
        applyFeatureSetting(changes[SETTING_KEY].newValue, "setting-change");
      }
    });
  }

  function ensureNativeFutureAvailabilities(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return false;
    }

    const ctx = parsePageContext();
    const pageKey = buildPageKey(ctx);
    if (confirmedPageKey === pageKey) {
      return true;
    }

    const displayOptionsButton = findDisplayOptionsButton(document);
    const checkbox = findFutureAvailabilitiesCheckbox(document);
    const flyoutExpanded = isFlyoutExpanded(displayOptionsButton);
    const action = resolveFutureAvailabilitiesAction(checkbox, pageKey, {
      displayOptionsButton,
      flyoutExpanded,
      openedFlyoutPageKey,
      clickedPageKey
    });

    if (action === "wait" || action === "already-clicked") {
      return false;
    }

    if (action === "done") {
      confirmedPageKey = pageKey;
      log("native Show future availabilities already enabled", {
        reason,
        pageKey
      });
      return true;
    }

    if (action === "close-flyout") {
      closeDisplayOptionsFlyout(displayOptionsButton, pageKey, reason);
      confirmedPageKey = pageKey;
      log("native Show future availabilities enabled", { reason, pageKey });
      return !isFlyoutExpanded(displayOptionsButton);
    }

    if (action === "open-flyout") {
      if (!displayOptionsButton) {
        return false;
      }
      if (!isFlyoutExpanded(displayOptionsButton)) {
        openedFlyoutPageKey = pageKey;
        log("opening Display options flyout", { reason, pageKey });
        displayOptionsButton.click();
      } else {
        openedFlyoutPageKey = pageKey;
      }
      return false;
    }

    // action === "click"
    openedFlyoutPageKey = pageKey;
    clickedPageKey = pageKey;
    log("enabling native Show future availabilities", { reason, pageKey });
    checkbox.click();

    if (checkbox.checked) {
      closeDisplayOptionsFlyout(displayOptionsButton, pageKey, reason);
      if (!isFlyoutExpanded(displayOptionsButton) || openedFlyoutPageKey !== pageKey) {
        confirmedPageKey = pageKey;
        return true;
      }
    }
    return false;
  }

  function resetPageState() {
    openedFlyoutPageKey = null;
    clickedPageKey = null;
    confirmedPageKey = null;
  }

  function stopRetryLoop() {
    if (retryTimer) {
      clearInterval(retryTimer);
      retryTimer = null;
    }
    retryStartedAt = 0;
  }

  function startRetryLoop(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      stopRetryLoop();
      return;
    }

    if (!retryTimer) {
      retryStartedAt = Date.now();
      retryTimer = setInterval(() => {
        const done = ensureNativeFutureAvailabilities("retry-loop");
        if (done) {
          stopRetryLoop();
          return;
        }
        if (Date.now() - retryStartedAt >= RETRY_MAX_MS) {
          stopRetryLoop();
        }
      }, RETRY_INTERVAL_MS);
    }

    ensureNativeFutureAvailabilities(reason || "retry-schedule");
  }

  function evaluateLifecycle(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      stopRetryLoop();
      return;
    }

    startRetryLoop(reason || "lifecycle");
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  function onRouteChange(reason) {
    const nextHref = location.href;
    if (nextHref !== lastTrackedHref) {
      resetPageState();
      stopRetryLoop();
    }
    lastTrackedHref = nextHref;
    scheduleLifecycleEval(reason || "route-change");
  }

  function startRouteWatchers() {
    if (routeWatchersStarted) {
      return;
    }
    routeWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", () => onRouteChange("popstate"));
    window.addEventListener("hashchange", () => onRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        onRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        onRouteChange("replaceState");
        return result;
      };
    } catch (err) {
      log("history hook unavailable:", err);
    }

    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        onRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  function init() {
    if (!isFareHarborHost()) {
      return;
    }

    initSettingsBinding();
    startRouteWatchers();
    evaluateLifecycle("init");

    if (document.readyState === "loading") {
      document.addEventListener(
        "DOMContentLoaded",
        () => evaluateLifecycle("dom-content-loaded"),
        { once: true }
      );
    }
  }

  window.FareHarborNativeFutureAvailabilities = {
    parseChannelItemsListingPageContext,
    resolveFutureAvailabilitiesAction,
    CHECKBOX_SELECTOR,
    DISPLAY_OPTIONS_BUTTON_SELECTOR,
    SETTING_KEY
  };

  init();
})();
