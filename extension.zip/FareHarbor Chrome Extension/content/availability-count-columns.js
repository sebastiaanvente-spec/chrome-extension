console.log("[availability-count-columns] script loaded");

(function availabilityCountColumnsModule() {
  "use strict";

  const LOG_PREFIX = "[availability-count-columns]";
  const shared = window.FareHarborAvailabilityCount;
  if (!shared) {
    console.error(LOG_PREFIX, "FareHarborAvailabilityCount not loaded");
    return;
  }
  const { findAvailabilityCount, normalizeCount, formatCount } = shared;

  const COLUMN_ATTR = "data-fh-availability-count-column";
  const EXTERNAL_ID_ATTR = "data-fh-external-id";
  const DOM_SCOPE_SELECTOR = ".settings-wrap-narrow";
  const ITEM_MAPPING_PATH_RE =
    /\/dashboard\/settings\/integrations\/channels\/\d+\/items\/\d+\/?$/;
  const PAGE_CONTEXT_RE =
    /\/([^/]+)\/dashboard\/settings\/integrations\/channels\/(\d+)\/items\/(\d+)/;
  const ROW_LINK_RE =
    /\/settings\/integrations\/channels\/(\d+)\/items\/(\d+)\/(customer-types|options)\/(\d+)\/?/;
  const RCT_EXTERNAL_ID_RE = /\brct\S+/i;
  const RO_EXTERNAL_ID_RE = /\bro\S+/i;
  const SCAN_DEBOUNCE_MS = 150;
  const ROUTE_REEVAL_DELAY_MS = 150;
  const ROUTE_POLL_MS = 500;
  const RETRY_INTERVAL_MS = 500;
  const RETRY_MAX_MS = 10000;
  const MISSING_COUNT_TEXT = "—";
  const LOADING_TEXT = "Loading...";
  const ERROR_TEXT = "Error";

  const CUSTOMER_TYPES_TABLE_SELECTOR =
    'table[data-test-id="test-reseller-customer-types-table"]';
  const OPTIONS_CTRL_SELECTOR =
    'div[ng-controller="dashboard.settings.reseller.ResellerOptionsCtrl"]';
  const LAYOUT_STYLE_ID = "fh-availability-layout-style";
  const LAYOUT_CLASS = "fh-availability-columns";
  const SETTINGS_WINDOW_SELECTOR = ".settings-window";
  const LAYOUT_STYLE_TEXT = `.settings-window.${LAYOUT_CLASS} {
  --settings-wrap-width-narrow: 750px;
}`;
  const NAME_SORT_APPLIED_ATTR = "data-fh-default-name-sort-applied";
  const SORT_DIRECTION_ATTR = "data-fh-availability-sort-direction";
  const TABLE_SORT_TYPE_ATTR = "data-fh-availability-sort-type";
  const ORIGINAL_ROW_ORDER_ATTR = "data-fh-original-row-order";
  const AVAILABILITY_HEADER_UNSORTED = "Future availabilities ↕";
  const AVAILABILITY_HEADER_DESC = "Future availabilities ↓";
  const AVAILABILITY_HEADER_ASC = "Future availabilities ↑";
  const SETTING_KEY = "showFutureAvailabilitiesColumn";

  let observer = null;
  let debounceTimer = null;
  let hrefPollTimer = null;
  let lifecycleEvalTimer = null;
  let retryTimer = null;
  let retryStartedAt = 0;
  let lastTrackedHref = location.href;
  let watchersActive = false;
  let routeWatchersStarted = false;
  let scanInProgress = false;
  let fetchGeneration = 0;
  let availabilitySortInProgress = false;
  let featureEnabled = true;

  /** @type {Map<string, { externalIdSetKey: string, counts: object }>} */
  const pageCountsCache = new Map();
  /** @type {Map<string, { externalIdSetKey: string, promise: Promise<object> }>} */
  const inflightCountsByPageKey = new Map();
  let lastAppliedState = {
    pageKey: null,
    externalIdSetKey: null,
    populated: false
  };
  const nameSortSkipLogged = new Set();
  /** @type {WeakMap<HTMLTableElement, (event: MouseEvent) => void>} */
  const tableSortClickHandlers = new WeakMap();

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function parseAvailabilitySortValue(text) {
    const trimmed = (text || "").trim();
    if (
      trimmed === LOADING_TEXT ||
      trimmed === ERROR_TEXT ||
      trimmed === MISSING_COUNT_TEXT ||
      trimmed === ""
    ) {
      return null;
    }
    const numeric = Number(trimmed.replace(/,/g, ""));
    return Number.isFinite(numeric) ? numeric : null;
  }

  function removeInjectedColumns() {
    document.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
      cell.remove();
    });
  }

  function applyFeatureSetting(enabled, reason) {
    featureEnabled = enabled !== false;
    if (!featureEnabled) {
      removeLayoutWidening();
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }
    evaluateLifecycle(reason || "setting-enabled");
  }

  function initSettingsBinding() {
    const settings = window.FHSettings;
    if (!settings) {
      return;
    }
    settings.get(SETTING_KEY, (value) => {
      applyFeatureSetting(value, "settings-init");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SETTING_KEY]) {
        applyFeatureSetting(changes[SETTING_KEY].newValue, "setting-change");
      }
    });
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function isItemMappingPath() {
    return ITEM_MAPPING_PATH_RE.test(location.pathname || "");
  }

  function parsePageContext() {
    const match = (location.pathname || "").match(PAGE_CONTEXT_RE);
    if (!match) {
      return null;
    }
    return {
      companyShortname: match[1],
      channelId: match[2],
      resellerItemId: match[3]
    };
  }

  function getDomScope() {
    return document.querySelector(DOM_SCOPE_SELECTOR);
  }

  function isUrlEligible() {
    return isFareHarborHost() && isItemMappingPath();
  }

  function isPageEligible() {
    return isUrlEligible() && !!getDomScope();
  }

  function ensureLayoutStyle() {
    if (document.getElementById(LAYOUT_STYLE_ID)) {
      return;
    }
    const style = document.createElement("style");
    style.id = LAYOUT_STYLE_ID;
    style.textContent = LAYOUT_STYLE_TEXT;
    (document.head || document.documentElement).appendChild(style);
  }

  function applyLayoutWidening() {
    ensureLayoutStyle();
    document.querySelectorAll(SETTINGS_WINDOW_SELECTOR).forEach((el) => {
      el.classList.add(LAYOUT_CLASS);
    });
  }

  function removeLayoutWidening() {
    document
      .querySelectorAll(`${SETTINGS_WINDOW_SELECTOR}.${LAYOUT_CLASS}`)
      .forEach((el) => {
        el.classList.remove(LAYOUT_CLASS);
      });
  }

  function syncLayoutWidening() {
    if (isUrlEligible()) {
      applyLayoutWidening();
      return;
    }
    removeLayoutWidening();
  }

  function buildPageKey(ctx) {
    if (!ctx) {
      return null;
    }
    return `${ctx.companyShortname}|${ctx.channelId}|${ctx.resellerItemId}`;
  }

  function buildExternalIdSetKey(descriptors) {
    return descriptors
      .map((d) => `${d.kind}:${d.externalId}`)
      .sort()
      .join("|");
  }

  function clearPageCaches() {
    pageCountsCache.clear();
    inflightCountsByPageKey.clear();
    nameSortSkipLogged.clear();
    lastAppliedState = {
      pageKey: null,
      externalIdSetKey: null,
      populated: false
    };
  }

  function cellHasPopulatedState(cell) {
    const text = (cell.textContent || "").trim();
    if (text === ERROR_TEXT || text === MISSING_COUNT_TEXT) {
      return true;
    }
    return parseAvailabilitySortValue(text) !== null;
  }

  function cellNeedsPopulation(cell) {
    if (!cell?.getAttribute(EXTERNAL_ID_ATTR)) {
      return false;
    }
    return !cellHasPopulatedState(cell);
  }

  function tableNeedsCountCells(table) {
    if (!table) {
      return false;
    }
    const headerRow = table.querySelector("thead tr");
    if (headerRow && !headerRow.querySelector(`[${COLUMN_ATTR}="true"]`)) {
      return true;
    }
    for (const row of table.querySelectorAll("tbody tr")) {
      if (!row.lastElementChild) {
        continue;
      }
      const cell = row.querySelector(`[${COLUMN_ATTR}="true"]`);
      if (!cell || cellNeedsPopulation(cell)) {
        return true;
      }
    }
    return false;
  }

  function tablesNeedRepair(customerTypesTable, optionsTable) {
    return (
      tableNeedsCountCells(customerTypesTable) ||
      tableNeedsCountCells(optionsTable)
    );
  }

  function allCountCellsFinal(tables) {
    const cells = [];
    for (const table of tables) {
      if (!table) {
        continue;
      }
      cells.push(
        ...table.querySelectorAll(
          `tbody [${COLUMN_ATTR}="true"][${EXTERNAL_ID_ATTR}]`
        )
      );
    }
    if (!cells.length) {
      return false;
    }
    return cells.every(cellHasPopulatedState);
  }

  function tablesHaveCellsNeedingPopulation(tables) {
    for (const table of tables) {
      if (!table) {
        continue;
      }
      for (const cell of table.querySelectorAll(
        `tbody [${COLUMN_ATTR}="true"][${EXTERNAL_ID_ATTR}]`
      )) {
        if (cellNeedsPopulation(cell)) {
          return true;
        }
      }
    }
    return false;
  }

  function getCountsMapForKind(counts, kind) {
    return kind === "customer-types" ? counts.customerTypes : counts.options;
  }

  function descriptorHasCachedCount(counts, descriptor) {
    const countMap = getCountsMapForKind(counts, descriptor.kind);
    if (typeof countMap[descriptor.externalId] === "number") {
      return true;
    }
    const status = counts.rowStatus[descriptor.externalId];
    return status === "missing" || status === "error";
  }

  function getCachedCountsForPage(ctx) {
    if (!ctx) {
      return null;
    }
    return pageCountsCache.get(buildPageKey(ctx))?.counts || null;
  }

  function isExtensionNode(node) {
    if (!(node instanceof Element)) {
      const parent = node?.parentElement;
      return parent ? isExtensionNode(parent) : false;
    }
    if (node.getAttribute(COLUMN_ATTR) === "true") {
      return true;
    }
    return !!node.closest?.(`[${COLUMN_ATTR}="true"]`);
  }

  function isExtensionMutation(mutation) {
    if (availabilitySortInProgress) {
      return true;
    }
    for (const node of mutation.addedNodes) {
      if (node instanceof Element) {
        const row = node.matches?.("tr")
          ? node
          : node.querySelector?.("tbody tr, tr");
        if (row && !isExtensionNode(row)) {
          return false;
        }
      }
    }
    if (isExtensionNode(mutation.target)) {
      return true;
    }
    for (const node of mutation.addedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    for (const node of mutation.removedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    return false;
  }

  function buildResellerApiBase(ctx) {
    return (
      `/api/v1/companies/${ctx.companyShortname}` +
      `/reseller-companies/${ctx.channelId}` +
      `/reseller-items/${ctx.resellerItemId}`
    );
  }

  function candidateApiUrls(ctx, row) {
    const base = buildResellerApiBase(ctx);
    if (row.kind === "customer-types") {
      return [`${base}/reseller-customer-types/${row.id}/?availability_count=yes`];
    }
    return [`${base}/reseller-options/${row.id}/?availability_count=yes`];
  }

  async function fetchAvailabilityCountForRow(ctx, row) {
    const errors = [];
    for (const path of candidateApiUrls(ctx, row)) {
      const url = new URL(path, window.location.origin).href;
      try {
        const resp = await fetch(url, { credentials: "include" });
        const text = await resp.text();
        if (!resp.ok) {
          errors.push(`${resp.status} ${path}`);
          log("endpoint fetch failed", {
            externalId: row.externalId,
            kind: row.kind,
            url,
            status: resp.status
          });
          continue;
        }

        let json;
        try {
          json = JSON.parse(text);
        } catch {
          errors.push(`Non-JSON ${path}`);
          log("endpoint returned non-JSON", {
            externalId: row.externalId,
            kind: row.kind,
            url
          });
          continue;
        }

        const count = normalizeCount(findAvailabilityCount(json));
        if (count !== null) {
          return { ok: true, count, url, response: json, error: null };
        }

        errors.push(`No count ${path}`);
        return {
          ok: true,
          count: null,
          url,
          response: json,
          error: "no availability count in response"
        };
      } catch (err) {
        const message = String(err?.message || err);
        errors.push(`${message} ${path}`);
        log("endpoint fetch error", {
          externalId: row.externalId,
          kind: row.kind,
          url,
          error: message
        });
      }
    }

    return {
      ok: false,
      count: null,
      url: null,
      response: null,
      error: errors.join(" | ") || "fetch failed"
    };
  }

  function emptyCountResults() {
    return {
      customerTypes: {},
      options: {},
      rowStatus: {},
      fetchAttempted: false
    };
  }

  function mergeCountResults(base, addition) {
    return {
      customerTypes: { ...base.customerTypes, ...addition.customerTypes },
      options: { ...base.options, ...addition.options },
      rowStatus: { ...base.rowStatus, ...addition.rowStatus },
      fetchAttempted: base.fetchAttempted || addition.fetchAttempted
    };
  }

  async function fetchCountsForRows(ctx, rows) {
    const customerTypes = {};
    const options = {};
    const rowStatus = {};

    const results = await Promise.all(
      rows.map(async (row) => {
        if (!row.id) {
          return {
            row,
            result: { ok: false, count: null, error: "missing API id from edit link" }
          };
        }
        const result = await fetchAvailabilityCountForRow(ctx, row);
        return { row, result };
      })
    );

    for (const { row, result } of results) {
      if (result.ok && typeof result.count === "number") {
        rowStatus[row.externalId] = "ok";
        if (row.kind === "customer-types") {
          customerTypes[row.externalId] = result.count;
        } else if (row.kind === "options") {
          options[row.externalId] = result.count;
        }
        continue;
      }

      if (result.ok && result.count === null) {
        rowStatus[row.externalId] = "missing";
        continue;
      }

      rowStatus[row.externalId] = "error";
    }

    return { customerTypes, options, rowStatus, fetchAttempted: rows.length > 0 };
  }

  async function resolveCounts(ctx, descriptors) {
    if (!ctx || !descriptors.length) {
      return emptyCountResults();
    }

    const pageKey = buildPageKey(ctx);
    const externalIdSetKey = buildExternalIdSetKey(descriptors);
    const cached = pageCountsCache.get(pageKey);

    if (cached && cached.externalIdSetKey === externalIdSetKey) {
      return cached.counts;
    }

    const inflight = inflightCountsByPageKey.get(pageKey);
    if (inflight && inflight.externalIdSetKey === externalIdSetKey) {
      return inflight.promise;
    }

    let rowsToFetch = descriptors;
    let baseCounts = emptyCountResults();

    if (cached) {
      const previousIds = new Set(cached.externalIdSetKey.split("|").filter(Boolean));
      const newRows = descriptors.filter(
        (d) => !previousIds.has(`${d.kind}:${d.externalId}`)
      );
      if (!newRows.length) {
        return cached.counts;
      }
      rowsToFetch = newRows;
      baseCounts = cached.counts;
    }

    const fetchPromise = (async () => {
      log("fetching availability counts", {
        company: ctx.companyShortname,
        channelId: ctx.channelId,
        resellerItemId: ctx.resellerItemId,
        rowCount: rowsToFetch.length,
        externalIdSetKey
      });

      const fetched = await fetchCountsForRows(ctx, rowsToFetch);
      const merged = mergeCountResults(baseCounts, fetched);

      pageCountsCache.set(pageKey, {
        externalIdSetKey,
        counts: merged
      });

      log("normalized count map", {
        customerTypes: merged.customerTypes,
        options: merged.options
      });

      return merged;
    })();

    inflightCountsByPageKey.set(pageKey, { externalIdSetKey, promise: fetchPromise });

    try {
      return await fetchPromise;
    } finally {
      const current = inflightCountsByPageKey.get(pageKey);
      if (current?.promise === fetchPromise) {
        inflightCountsByPageKey.delete(pageKey);
      }
    }
  }

  async function getFutureAvailabilityCounts(ctx, rows) {
    if (!ctx) {
      log("cannot fetch counts: missing page context from URL");
      return emptyCountResults();
    }
    return resolveCounts(ctx, rows);
  }

  // --- DOM helpers ---

  function normalizeCellText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function extractExternalId(text, kind) {
    const trimmed = normalizeCellText(text);
    const re = kind === "customer-types" ? RCT_EXTERNAL_ID_RE : RO_EXTERNAL_ID_RE;
    const match = trimmed.match(re);
    return match ? match[0] : "";
  }

  function getRowCells(row) {
    return [...row.children].filter(
      (el) => el.tagName === "TD" || el.tagName === "TH"
    );
  }

  function extractExternalIdFromRow(row, kind) {
    const cells = getRowCells(row);
    const externalColumnText = cells[2]?.textContent || "";
    if (extractExternalId(externalColumnText, kind)) {
      return extractExternalId(externalColumnText, kind);
    }
    for (const cell of cells) {
      const found = extractExternalId(cell.textContent || "", kind);
      if (found) {
        return found;
      }
    }
    return "";
  }

  function normalizeInsertedColumn(table) {
    const headerCell = table.querySelector(`thead tr [${COLUMN_ATTR}="true"]`);
    const bodyCells = [...table.querySelectorAll(`tbody tr [${COLUMN_ATTR}="true"]`)];

    if (bodyCells.length > 0 && !headerCell) {
      bodyCells.forEach((cell) => cell.remove());
    }
  }

  function createHeaderCell(referenceCell) {
    const tagName =
      referenceCell?.tagName === "TD" || referenceCell?.tagName === "td"
        ? "td"
        : "th";
    const cell = document.createElement(tagName);
    cell.setAttribute(COLUMN_ATTR, "true");
    cell.textContent = AVAILABILITY_HEADER_UNSORTED;
    cell.style.cursor = "pointer";
    cell.style.userSelect = "none";
    return cell;
  }

  function createBodyCell() {
    const cell = document.createElement("td");
    cell.setAttribute(COLUMN_ATTR, "true");
    cell.style.textAlign = "right";
    cell.textContent = LOADING_TEXT;
    return cell;
  }

  function ensureHeaderColumn(table) {
    normalizeInsertedColumn(table);

    const headerRow =
      table.querySelector("thead tr") ||
      table.querySelector("thead > tr") ||
      null;
    const lastChild = headerRow?.lastElementChild || null;

    if (!headerRow) {
      return { inserted: false, alreadyPresent: false, reason: "no-header-row" };
    }

    const existingHeader = headerRow.querySelector(`[${COLUMN_ATTR}="true"]`);
    if (existingHeader) {
      existingHeader.style.cursor = "pointer";
      existingHeader.style.userSelect = "none";
      return { inserted: false, alreadyPresent: true, headerCell: existingHeader };
    }

    if (!lastChild) {
      return { inserted: false, alreadyPresent: false, reason: "no-last-child" };
    }

    const headerCell = createHeaderCell(lastChild);
    headerRow.insertBefore(headerCell, lastChild);
    return { inserted: true, alreadyPresent: false, headerCell };
  }

  function ensureBodyColumns(table, kind) {
    normalizeInsertedColumn(table);

    const descriptors = [];
    let insertedCells = 0;
    let repositionedCells = 0;
    const rows = table.querySelectorAll("tbody tr");

    rows.forEach((row) => {
      const rowCells = getRowCells(row);
      const lastChild = row.lastElementChild;
      const externalId = extractExternalIdFromRow(row, kind);

      if (!lastChild) {
        return;
      }

      let cell = row.querySelector(`[${COLUMN_ATTR}="true"]`);

      if (!cell) {
        cell = createBodyCell();
        row.insertBefore(cell, lastChild);
        insertedCells += 1;
      } else if (cell === lastChild) {
        const editCell = rowCells[rowCells.length - 1];
        if (editCell && editCell !== cell) {
          row.insertBefore(cell, editCell);
          repositionedCells += 1;
        }
      }

      if (externalId) {
        const previousExternalId = cell.getAttribute(EXTERNAL_ID_ATTR);
        cell.setAttribute(EXTERNAL_ID_ATTR, externalId);
        if (
          previousExternalId !== externalId ||
          (cellNeedsPopulation(cell) && cell.textContent.trim() !== LOADING_TEXT)
        ) {
          cell.textContent = LOADING_TEXT;
        }
        descriptors.push({
          kind,
          id: extractApiIdFromRow(row, kind),
          externalId
        });
      } else {
        cell.removeAttribute(EXTERNAL_ID_ATTR);
      }
    });

    return { descriptors, insertedCells, repositionedCells };
  }

  function extractApiIdFromRow(row, kind) {
    const linkSelector =
      kind === "customer-types"
        ? 'a[href*="/customer-types/"]'
        : 'a[href*="/options/"]';
    for (const link of row.querySelectorAll(linkSelector)) {
      const href = link.getAttribute("href") || link.href || "";
      const match = href.match(ROW_LINK_RE);
      if (match && match[3] === kind) {
        return match[4];
      }
    }
    return null;
  }

  function findCustomerTypesTable(scope) {
    return scope.querySelector(CUSTOMER_TYPES_TABLE_SELECTOR);
  }

  function findOptionsTable(scope) {
    const wrapper = scope.querySelector(OPTIONS_CTRL_SELECTOR);
    if (!wrapper) {
      return null;
    }
    return wrapper.querySelector("table.spreadsheet");
  }

  function findNameSortHeader(table) {
    return (
      Array.from(table.querySelectorAll("thead td")).find(
        (td) => td.textContent.trim() === "Name"
      ) || null
    );
  }

  function applyDefaultNameSort(table, logLabel) {
    if (!table || table.getAttribute(NAME_SORT_APPLIED_ATTR) === "true") {
      return false;
    }

    const nameHeader = findNameSortHeader(table);
    if (!nameHeader) {
      if (!nameSortSkipLogged.has(logLabel)) {
        nameSortSkipLogged.add(logLabel);
        log("default Name sort skipped, Name header not found", { table: logLabel });
      }
      return false;
    }

    table.setAttribute(NAME_SORT_APPLIED_ATTR, "true");
    nameHeader.click();
    log("Default Name sort applied", { table: logLabel });
    return true;
  }

  function getAvailabilitySortValueFromTbody(tbody) {
    const cell = tbody.querySelector(`[${COLUMN_ATTR}="true"]`);
    if (!cell) {
      return null;
    }
    return parseAvailabilitySortValue(cell.textContent);
  }

  function compareAvailabilityTbodies(a, b, direction) {
    const aValue = getAvailabilitySortValueFromTbody(a);
    const bValue = getAvailabilitySortValueFromTbody(b);

    if (aValue === null && bValue === null) {
      return 0;
    }
    if (aValue === null) {
      return 1;
    }
    if (bValue === null) {
      return -1;
    }
    if (direction === "asc") {
      return aValue - bValue;
    }
    return bValue - aValue;
  }

  function getAvailabilityHeaderCell(table) {
    return table.querySelector(`thead [${COLUMN_ATTR}="true"]`);
  }

  function updateAvailabilitySortHeaderLabel(table) {
    const header = getAvailabilityHeaderCell(table);
    if (!header) {
      return;
    }
    const direction = table.getAttribute(SORT_DIRECTION_ATTR);
    if (direction === "asc") {
      header.textContent = AVAILABILITY_HEADER_ASC;
      return;
    }
    if (direction === "desc") {
      header.textContent = AVAILABILITY_HEADER_DESC;
      return;
    }
    header.textContent = AVAILABILITY_HEADER_UNSORTED;
  }

  function getNextAvailabilitySortDirection(table) {
    const current = table.getAttribute(SORT_DIRECTION_ATTR);
    if (current !== "asc" && current !== "desc") {
      return "desc";
    }
    return current === "desc" ? "asc" : "desc";
  }

  function captureOriginalRowOrder(table) {
    Array.from(table.querySelectorAll("tbody")).forEach((tbody, index) => {
      tbody.setAttribute(ORIGINAL_ROW_ORDER_ATTR, String(index));
    });
  }

  function restoreOriginalRowOrder(table, tableType) {
    const direction = table.getAttribute(SORT_DIRECTION_ATTR);
    if (direction !== "asc" && direction !== "desc") {
      return false;
    }

    const tbodies = Array.from(table.querySelectorAll("tbody"));
    if (!tbodies.length) {
      return false;
    }

    if (!tbodies.some((tbody) => tbody.hasAttribute(ORIGINAL_ROW_ORDER_ATTR))) {
      return false;
    }

    availabilitySortInProgress = true;
    try {
      const restoredTbodies = [...tbodies].sort((a, b) => {
        const aOrder = Number(a.getAttribute(ORIGINAL_ROW_ORDER_ATTR) || 0);
        const bOrder = Number(b.getAttribute(ORIGINAL_ROW_ORDER_ATTR) || 0);
        return aOrder - bOrder;
      });
      restoredTbodies.forEach((tbody) => {
        table.appendChild(tbody);
      });
      table.removeAttribute(SORT_DIRECTION_ATTR);
      updateAvailabilitySortHeaderLabel(table);
      return true;
    } finally {
      setTimeout(() => {
        availabilitySortInProgress = false;
      }, 0);
    }
  }

  function applyAvailabilitySort(table, tableType, direction) {
    const tbodies = Array.from(table.querySelectorAll("tbody"));
    if (!tbodies.length) {
      log("Sort skipped", { tableType, reason: "no rows" });
      return false;
    }

    const hasSortCells = tbodies.some((tbody) =>
      tbody.querySelector(`[${COLUMN_ATTR}="true"]`)
    );
    if (!hasSortCells) {
      log("Sort skipped", { tableType, reason: "no cells" });
      return false;
    }

    availabilitySortInProgress = true;
    try {
      const sortedTbodies = [...tbodies].sort((a, b) =>
        compareAvailabilityTbodies(a, b, direction)
      );
      sortedTbodies.forEach((tbody) => {
        table.appendChild(tbody);
      });
      table.setAttribute(SORT_DIRECTION_ATTR, direction);
      updateAvailabilitySortHeaderLabel(table);
      log("Availability sort applied", {
        tableType,
        direction,
        rowCount: sortedTbodies.length
      });
      return true;
    } finally {
      setTimeout(() => {
        availabilitySortInProgress = false;
      }, 0);
    }
  }

  function handleTableSortClick(event, table, tableType) {
    const availabilityHeader = event.target.closest(
      `thead [${COLUMN_ATTR}="true"]`
    );
    if (availabilityHeader && table.contains(availabilityHeader)) {
      event.preventDefault();
      event.stopPropagation();
      log("Availability header clicked", { tableType });
      if (!table.hasAttribute(SORT_DIRECTION_ATTR)) {
        captureOriginalRowOrder(table);
      }
      const direction = getNextAvailabilitySortDirection(table);
      applyAvailabilitySort(table, tableType, direction);
      return;
    }

    const nativeHeader = getNativeSortHeaderFromEvent(event, table);
    if (!nativeHeader) {
      return;
    }

    const headerText = nativeHeader.textContent.replace(/\s+/g, " ").trim();
    log("Native header clicked, restoring row order", { tableType, headerText });
    restoreOriginalRowOrder(table, tableType);
  }

  function getNativeSortHeaderFromEvent(event, table) {
    const ngHeader = event.target.closest("thead td.ng-table-header");
    if (ngHeader && table.contains(ngHeader)) {
      return ngHeader;
    }
    const headerCell = event.target.closest("thead td, thead th");
    if (!headerCell || !table.contains(headerCell)) {
      return null;
    }
    if (headerCell.getAttribute(COLUMN_ATTR) === "true") {
      return null;
    }
    return headerCell;
  }

  function refreshTableReference(scope, kind) {
    if (kind === "customer-types") {
      return findCustomerTypesTable(scope);
    }
    if (kind === "options") {
      return findOptionsTable(scope);
    }
    return null;
  }

  function attachAvailabilitySortHandlers(table, tableType) {
    if (!table?.isConnected) {
      return null;
    }

    const header = getAvailabilityHeaderCell(table);
    if (!header) {
      return null;
    }

    header.style.cursor = "pointer";
    header.style.userSelect = "none";
    updateAvailabilitySortHeaderLabel(table);
    table.setAttribute(TABLE_SORT_TYPE_ATTR, tableType);

    if (tableSortClickHandlers.has(table)) {
      return table;
    }

    const handler = (event) => {
      const activeTableType =
        table.getAttribute(TABLE_SORT_TYPE_ATTR) || tableType;
      handleTableSortClick(event, table, activeTableType);
    };
    table.addEventListener("click", handler, true);
    tableSortClickHandlers.set(table, handler);
    log("Availability sort handlers attached", { tableType });
    return table;
  }

  function ensureSortHandlersAttached(scope, kind, tableType) {
    const table = refreshTableReference(scope, kind);
    if (!table) {
      return null;
    }
    return attachAvailabilitySortHandlers(table, tableType);
  }

  function populateCellFromCounts(
    cell,
    externalId,
    kind,
    counts,
    tableType,
    source
  ) {
    if (!cellNeedsPopulation(cell)) {
      return false;
    }

    const countMap = getCountsMapForKind(counts, kind);
    const status = counts.rowStatus[externalId];
    const count = countMap[externalId];
    let value = null;

    if (typeof count === "number") {
      value = formatCount(count);
      cell.textContent = value;
    } else if (status === "missing") {
      value = MISSING_COUNT_TEXT;
      cell.textContent = value;
    } else if (status === "error") {
      value = ERROR_TEXT;
      cell.textContent = value;
    } else {
      return false;
    }

    log("repopulated repaired availability cell", {
      tableType,
      externalId,
      value,
      source
    });
    return true;
  }

  function repopulateRepairedCellsFromCache(table, kind, tableType, counts, cells) {
    if (!table || !counts || !cells?.length) {
      return { repopulatedCells: 0, unresolvedCells: 0 };
    }

    let repopulatedCells = 0;
    let unresolvedCells = 0;

    for (const cell of cells) {
      const externalId = cell.getAttribute(EXTERNAL_ID_ATTR);
      if (!externalId || !cellNeedsPopulation(cell)) {
        continue;
      }

      if (
        populateCellFromCounts(
          cell,
          externalId,
          kind,
          counts,
          tableType,
          "cache"
        )
      ) {
        repopulatedCells += 1;
      } else {
        unresolvedCells += 1;
      }
    }

    return { repopulatedCells, unresolvedCells };
  }

  function repairTableColumn(table, kind, tableType, counts) {
    const headerResult = ensureHeaderColumn(table);
    const bodyResult = ensureBodyColumns(table, kind);
    const repairedCells = [];

    if (bodyResult.insertedCells > 0 || bodyResult.repositionedCells > 0) {
      table.querySelectorAll(`tbody tr [${COLUMN_ATTR}="true"]`).forEach((cell) => {
        if (cellNeedsPopulation(cell)) {
          repairedCells.push(cell);
        }
      });
    }

    let repopulateSummary = { repopulatedCells: 0, unresolvedCells: 0 };
    if (repairedCells.length && counts) {
      repopulateSummary = repopulateRepairedCellsFromCache(
        table,
        kind,
        tableType,
        counts,
        repairedCells
      );
    }

    return {
      headerResult,
      bodyResult,
      repaired:
        headerResult.inserted ||
        bodyResult.insertedCells > 0 ||
        bodyResult.repositionedCells > 0,
      repopulateSummary
    };
  }

  function populateTableCounts(table, countsByExternalId, rowStatus, kind, tableType, source) {
    let populatedCells = 0;
    let errorCells = 0;
    let missingCells = 0;
    let skippedCells = 0;

    table.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
      if (cell.closest("thead")) {
        return;
      }

      const externalId = cell.getAttribute(EXTERNAL_ID_ATTR);
      if (!externalId) {
        return;
      }

      if (cellHasPopulatedState(cell)) {
        skippedCells += 1;
        return;
      }

      const status = rowStatus[externalId];
      const count = countsByExternalId[externalId];

      if (typeof count === "number") {
        cell.textContent = formatCount(count);
        populatedCells += 1;
        if (source) {
          log("repopulated repaired availability cell", {
            tableType,
            externalId,
            value: cell.textContent,
            source
          });
        }
        return;
      }

      if (status === "missing") {
        cell.textContent = MISSING_COUNT_TEXT;
        missingCells += 1;
        if (source) {
          log("repopulated repaired availability cell", {
            tableType,
            externalId,
            value: cell.textContent,
            source
          });
        }
        return;
      }

      if (status === "error") {
        cell.textContent = ERROR_TEXT;
        errorCells += 1;
        if (source) {
          log("repopulated repaired availability cell", {
            tableType,
            externalId,
            value: cell.textContent,
            source
          });
        }
      }
    });

    return { populatedCells, errorCells, missingCells, skippedCells };
  }

  function markTableCellsError(table) {
    table.querySelectorAll(`tbody [${COLUMN_ATTR}="true"]`).forEach((cell) => {
      if (!cell.getAttribute(EXTERNAL_ID_ATTR)) {
        return;
      }
      if (cell.textContent === LOADING_TEXT) {
        cell.textContent = ERROR_TEXT;
      }
    });
  }

  function prepareTable(table, kind, label, ctx) {
    if (!table) {
      return null;
    }

    const cachedCounts = getCachedCountsForPage(ctx);
    const repairResult = repairTableColumn(table, kind, label, cachedCounts);
    const { headerResult, bodyResult, repaired, repopulateSummary } = repairResult;

    if (repaired) {
      log(`column repaired in ${label}`, {
        headerInserted: headerResult.inserted,
        bodyCellsInserted: bodyResult.insertedCells,
        bodyCellsRepositioned: bodyResult.repositionedCells,
        rowCount: bodyResult.descriptors.length,
        repopulatedFromCache: repopulateSummary.repopulatedCells,
        unresolvedAfterCache: repopulateSummary.unresolvedCells
      });
    }

    attachAvailabilitySortHandlers(table, label);

    return {
      table,
      descriptors: bodyResult.descriptors,
      repaired,
      unresolvedAfterCache: repopulateSummary.unresolvedCells,
      headerResult,
      bodyResult
    };
  }

  function shouldFullySkipScan(ctx, descriptors, tables) {
    if (!ctx || !descriptors.length) {
      return false;
    }

    const pageKey = buildPageKey(ctx);
    const externalIdSetKey = buildExternalIdSetKey(descriptors);

    if (tablesNeedRepair(tables[0], tables[1])) {
      return false;
    }

    if (tablesHaveCellsNeedingPopulation(tables)) {
      return false;
    }

    if (
      lastAppliedState.pageKey === pageKey &&
      lastAppliedState.externalIdSetKey === externalIdSetKey &&
      lastAppliedState.populated
    ) {
      return true;
    }

    const cached = pageCountsCache.get(pageKey);
    return !!(cached && cached.externalIdSetKey === externalIdSetKey);
  }

  function repopulateTablesFromCache(
    customerTypesPrepared,
    optionsPrepared,
    counts,
    source
  ) {
    const populateSummary = {
      populatedCells: 0,
      errorCells: 0,
      missingCells: 0,
      skippedCells: 0
    };

    if (customerTypesPrepared?.table) {
      const result = populateTableCounts(
        customerTypesPrepared.table,
        counts.customerTypes,
        counts.rowStatus,
        "customer-types",
        "customer types",
        source
      );
      populateSummary.populatedCells += result.populatedCells;
      populateSummary.errorCells += result.errorCells;
      populateSummary.missingCells += result.missingCells;
      populateSummary.skippedCells += result.skippedCells;
    }
    if (optionsPrepared?.table) {
      const result = populateTableCounts(
        optionsPrepared.table,
        counts.options,
        counts.rowStatus,
        "options",
        "channel options",
        source
      );
      populateSummary.populatedCells += result.populatedCells;
      populateSummary.errorCells += result.errorCells;
      populateSummary.missingCells += result.missingCells;
      populateSummary.skippedCells += result.skippedCells;
    }

    return populateSummary;
  }

  function populateFromResolvedCounts(
    customerTypesPrepared,
    optionsPrepared,
    counts,
    tables,
    ctx,
    allDescriptors,
    source
  ) {
    const populateSummary = {
      populatedCells: 0,
      errorCells: 0,
      missingCells: 0,
      skippedCells: 0
    };

    if (customerTypesPrepared?.table) {
      const result = populateTableCounts(
        customerTypesPrepared.table,
        counts.customerTypes,
        counts.rowStatus,
        "customer-types",
        "customer types",
        source
      );
      populateSummary.populatedCells += result.populatedCells;
      populateSummary.errorCells += result.errorCells;
      populateSummary.missingCells += result.missingCells;
      populateSummary.skippedCells += result.skippedCells;
    }
    if (optionsPrepared?.table) {
      const result = populateTableCounts(
        optionsPrepared.table,
        counts.options,
        counts.rowStatus,
        "options",
        "channel options",
        source
      );
      populateSummary.populatedCells += result.populatedCells;
      populateSummary.errorCells += result.errorCells;
      populateSummary.missingCells += result.missingCells;
      populateSummary.skippedCells += result.skippedCells;
    }

    if (ctx && allDescriptors.length) {
      lastAppliedState = {
        pageKey: buildPageKey(ctx),
        externalIdSetKey: buildExternalIdSetKey(allDescriptors),
        populated: allCountCellsFinal(tables)
      };
    }

    if (
      populateSummary.populatedCells > 0 ||
      populateSummary.errorCells > 0 ||
      populateSummary.missingCells > 0
    ) {
      log("counts populated", populateSummary);
    }

    if (lastAppliedState.populated) {
      stopRetryLoop();
    }

    return populateSummary;
  }

  function descriptorsNeedFetch(ctx, descriptors, tables) {
    if (!ctx || !descriptors.length) {
      return false;
    }

    const pageKey = buildPageKey(ctx);
    const externalIdSetKey = buildExternalIdSetKey(descriptors);
    const cached = pageCountsCache.get(pageKey);

    if (tables && tablesHaveCellsNeedingPopulation(tables)) {
      if (!cached) {
        return true;
      }
      const unresolved = descriptors.filter(
        (descriptor) => !descriptorHasCachedCount(cached.counts, descriptor)
      );
      if (unresolved.length) {
        return true;
      }
    }

    if (cached && cached.externalIdSetKey === externalIdSetKey) {
      return descriptors.some(
        (descriptor) => !descriptorHasCachedCount(cached.counts, descriptor)
      );
    }

    if (inflightCountsByPageKey.has(pageKey)) {
      return true;
    }

    if (cached) {
      const previousIds = new Set(cached.externalIdSetKey.split("|").filter(Boolean));
      return descriptors.some((d) => !previousIds.has(`${d.kind}:${d.externalId}`));
    }

    return true;
  }

  async function scanTables(reason) {
    if (!featureEnabled || availabilitySortInProgress) {
      return false;
    }

    const urlEligible = isUrlEligible();
    if (!urlEligible) {
      return false;
    }

    syncLayoutWidening();

    const scope = getDomScope();
    if (!scope) {
      return false;
    }

    if (scanInProgress) {
      return false;
    }

    const customerTypesTable = findCustomerTypesTable(scope);
    const optionsTable = findOptionsTable(scope);

    if (!customerTypesTable && !optionsTable) {
      return false;
    }

    scanInProgress = true;
    const generation = ++fetchGeneration;
    let didWork = false;
    let customerTypesPrepared = null;
    let optionsPrepared = null;

    try {
      const ctx = parsePageContext();

      customerTypesPrepared = customerTypesTable
        ? prepareTable(
            customerTypesTable,
            "customer-types",
            "customer types",
            ctx
          )
        : null;
      optionsPrepared = optionsTable
        ? prepareTable(optionsTable, "options", "channel options", ctx)
        : null;

      if (customerTypesPrepared?.table) {
        applyDefaultNameSort(customerTypesPrepared.table, "customer types");
        const liveCustomerTypesTable = ensureSortHandlersAttached(
          scope,
          "customer-types",
          "customer types"
        );
        if (liveCustomerTypesTable) {
          customerTypesPrepared.table = liveCustomerTypesTable;
        }
      }
      if (optionsPrepared?.table) {
        applyDefaultNameSort(optionsPrepared.table, "channel options");
        const liveOptionsTable = ensureSortHandlersAttached(
          scope,
          "options",
          "channel options"
        );
        if (liveOptionsTable) {
          optionsPrepared.table = liveOptionsTable;
        }
      }

      didWork = !!(
        customerTypesPrepared?.repaired ||
        optionsPrepared?.repaired ||
        customerTypesPrepared ||
        optionsPrepared
      );

      const allDescriptors = [
        ...(customerTypesPrepared?.descriptors || []),
        ...(optionsPrepared?.descriptors || [])
      ];

      const tables = [
        customerTypesPrepared?.table || customerTypesTable,
        optionsPrepared?.table || optionsTable
      ];

      const cachedCounts = getCachedCountsForPage(ctx);
      if (cachedCounts && tablesHaveCellsNeedingPopulation(tables)) {
        repopulateTablesFromCache(
          customerTypesPrepared,
          optionsPrepared,
          cachedCounts,
          "cache"
        );
      }

      if (shouldFullySkipScan(ctx, allDescriptors, tables)) {
        if (cachedCounts) {
          repopulateTablesFromCache(
            customerTypesPrepared,
            optionsPrepared,
            cachedCounts,
            "cache"
          );
        }
        return true;
      }

      let counts = emptyCountResults();
      let populationSource = null;

      if (!ctx) {
        log("counts fetch skipped: could not parse company/channel/resellerItemId from URL");
        if (customerTypesPrepared?.table) {
          markTableCellsError(customerTypesPrepared.table);
        }
        if (optionsPrepared?.table) {
          markTableCellsError(optionsPrepared.table);
        }
      } else if (!allDescriptors.length) {
        return didWork;
      } else if (descriptorsNeedFetch(ctx, allDescriptors, tables)) {
        log("refreshing availability counts", {
          reason,
          externalIdSetKey: buildExternalIdSetKey(allDescriptors),
          unresolvedAfterRepair:
            (customerTypesPrepared?.unresolvedAfterCache || 0) +
            (optionsPrepared?.unresolvedAfterCache || 0),
          cellsStillNeedPopulation: tablesHaveCellsNeedingPopulation(tables)
        });
        counts = await getFutureAvailabilityCounts(ctx, allDescriptors);
        populationSource = "fetch";
      } else {
        counts =
          pageCountsCache.get(buildPageKey(ctx))?.counts || emptyCountResults();
      }

      if (generation !== fetchGeneration) {
        return didWork;
      }

      if (populationSource === "fetch") {
        populateFromResolvedCounts(
          customerTypesPrepared,
          optionsPrepared,
          counts,
          tables,
          ctx,
          allDescriptors,
          "fetch"
        );
      } else {
        populateFromResolvedCounts(
          customerTypesPrepared,
          optionsPrepared,
          counts,
          tables,
          ctx,
          allDescriptors,
          null
        );
      }

      if (
        ctx &&
        tablesHaveCellsNeedingPopulation(tables) &&
        ((customerTypesPrepared?.unresolvedAfterCache || 0) +
          (optionsPrepared?.unresolvedAfterCache || 0) >
          0 ||
          descriptorsNeedFetch(ctx, allDescriptors, tables))
      ) {
        log("scheduling refresh for unresolved repaired cells", {
          reason,
          externalIdSetKey: buildExternalIdSetKey(allDescriptors)
        });
        scheduleScan("unresolved-repaired-cells");
      }

      ensureSortHandlersAttached(scope, "customer-types", "customer types");
      ensureSortHandlersAttached(scope, "options", "channel options");
    } catch (err) {
      log("scanTables failed:", err);
      if (customerTypesPrepared?.table) {
        markTableCellsError(customerTypesPrepared.table);
      }
      if (optionsPrepared?.table) {
        markTableCellsError(optionsPrepared.table);
      }
    } finally {
      scanInProgress = false;
    }

    return didWork;
  }

  function scheduleScan(reason) {
    if (!featureEnabled || availabilitySortInProgress) {
      return;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }
    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      scanTables(reason || "debounced-scan");
    }, SCAN_DEBOUNCE_MS);
  }

  function stopRetryLoop() {
    if (retryTimer) {
      clearInterval(retryTimer);
      retryTimer = null;
    }
    retryStartedAt = 0;
  }

  function startRetryLoop(reason) {
    if (!isUrlEligible()) {
      stopRetryLoop();
      return;
    }

    if (!retryTimer) {
      retryStartedAt = Date.now();
      log("retry loop started", { reason, maxMs: RETRY_MAX_MS });
      retryTimer = setInterval(async () => {
        const elapsed = Date.now() - retryStartedAt;
        const found = await scanTables("retry-loop");
        if (found) {
          log("retry loop succeeded, stopping", { elapsedMs: elapsed });
          stopRetryLoop();
          return;
        }
        if (elapsed >= RETRY_MAX_MS) {
          log("retry loop timed out", { elapsedMs: elapsed });
          stopRetryLoop();
        }
      }, RETRY_INTERVAL_MS);
    }

    scheduleScan(reason || "retry-schedule");
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    stopRetryLoop();
    clearPageCaches();
    fetchGeneration += 1;
    scanInProgress = false;
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  function evaluateLifecycle(reason) {
    if (!featureEnabled) {
      removeLayoutWidening();
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }

    if (!isFareHarborHost()) {
      removeLayoutWidening();
      stopObserver();
      watchersActive = false;
      return;
    }

    if (!isUrlEligible()) {
      removeLayoutWidening();
      stopObserver();
      watchersActive = false;
      return;
    }

    applyLayoutWidening();

    if (!watchersActive) {
      log("eligible page detected", { reason, href: location.href });
      startObserver();
      watchersActive = true;
    }

    startRetryLoop(reason || "lifecycle");
  }

  function onRouteChange(reason) {
    const nextHref = location.href;
    if (nextHref !== lastTrackedHref) {
      clearPageCaches();
      fetchGeneration += 1;
    }
    lastTrackedHref = nextHref;
    scheduleLifecycleEval(reason || "route-change");
  }

  function startRouteWatchers() {
    if (routeWatchersStarted) {
      return;
    }
    routeWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", () => onRouteChange("popstate"));
    window.addEventListener("hashchange", () => onRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        onRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        onRouteChange("replaceState");
        return result;
      };
    } catch (err) {
      log("history hook unavailable:", err);
    }

    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        onRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  function startObserver() {
    if (observer) {
      return;
    }

    observer = new MutationObserver((mutations) => {
      if (!isUrlEligible()) {
        return;
      }
      if (mutations.length > 0 && mutations.every(isExtensionMutation)) {
        return;
      }
      scheduleScan("mutation-observer");
    });

    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function init() {
    log("module initialized", { href: location.href });

    ensureLayoutStyle();
    initSettingsBinding();
    startRouteWatchers();
    evaluateLifecycle("init");

    if (document.readyState === "loading") {
      document.addEventListener(
        "DOMContentLoaded",
        () => evaluateLifecycle("dom-content-loaded"),
        { once: true }
      );
    }
  }

  init();
})();
