(function resourceUseBookingCreatedModule() {
  "use strict";

  const LOG_PREFIX = "[resource-use-created-at]";
  const RESOURCE_USE_DATE_PATH_RE =
    /^\/([^/]+)\/dashboard\/settings\/resources\/(\d+)\/uses\/date\/(\d{4}-\d{2}-\d{2})\/?$/;
  const CONTACT_BOOKING_PATH_RE = /\/contacts\/([^/]+)\/bookings\/([^/]+)\/?/i;

  const DISPLAY_MODES = {
    LOCAL: "local",
    GETYOURGUIDE: "getyourguide",
    VIATOR: "viator"
  };
  const STORAGE_KEY = "resourceCreatedAtDisplayMode";
  const SETTING_KEY = "showResourceUseCreatedAtColumn";
  const GETYOURGUIDE_OFFSET_MINUTES = 120;

  const HEADER_ATTR = "data-fh-resource-created-header";
  const CELL_ATTR = "data-fh-resource-created-cell";
  const BOOKING_UUID_ATTR = "data-fh-booking-uuid";
  const CONTROLS_ATTR = "data-fh-resource-created-controls";
  const LAYOUT_ATTR = "data-fh-resource-use-created-layout";
  const LAYOUT_CONTAINER_SELECTOR =
    '[ng-navigation-prefix="urls.dashboard.settings.resources.resource.uses.day"]';
  const STYLE_ID = "fh-resource-use-created-at-style";
  const SORT_DIRECTION_ATTR = "data-fh-created-sort-direction";
  const CREATED_AT_RAW_ATTR = "data-fh-created-at-raw";
  const CREATED_AT_EPOCH_ATTR = "data-fh-created-at-epoch";
  const ORIGINAL_ORDER_ATTR = "data-fh-created-original-order";
  const SORT_DIRECTIONS = {
    NONE: "none",
    OLDEST: "oldest",
    NEWEST: "newest"
  };
  const SORT_APPLY_DEBOUNCE_MS = 150;
  const SORT_ARROWS = {
    [SORT_DIRECTIONS.NONE]: " ↕",
    [SORT_DIRECTIONS.OLDEST]: " ↑",
    [SORT_DIRECTIONS.NEWEST]: " ↓"
  };

  const SCAN_DEBOUNCE_MS = 150;
  const ROUTE_REEVAL_DELAY_MS = 150;
  const ROUTE_POLL_MS = 500;
  const RETRY_INTERVAL_MS = 500;
  const RETRY_MAX_MS = 10000;
  const FETCH_CONCURRENCY = 5;

  const LOADING_TEXT = "…";
  const MISSING_TEXT = "—";

  const HEADER_LABELS = {
    [DISPLAY_MODES.LOCAL]: "Created at (Local)",
    [DISPLAY_MODES.GETYOURGUIDE]: "Created at (GetYourGuide)",
    [DISPLAY_MODES.VIATOR]: "Created at (Viator / UTC)"
  };

  /** @type {Map<string, Promise<object|null>>} */
  const contactRequestCache = new Map();
  /** @type {Map<string, string|null|undefined>} */
  const bookingCreatedAtCache = new Map();

  let displayMode = DISPLAY_MODES.LOCAL;
  let observer = null;
  let observerTarget = null;
  let debounceTimer = null;
  let hrefPollTimer = null;
  let lifecycleEvalTimer = null;
  let retryTimer = null;
  let retryStartedAt = 0;
  let lastTrackedHref = location.href;
  let watchersActive = false;
  let routeWatchersStarted = false;
  let scanInProgress = false;
  let lastPageKey = null;
  let currentPageContext = null;
  let createdAtSortDirection = SORT_DIRECTIONS.NONE;
  let isApplyingSort = false;
  let sortApplyTimer = null;
  let sortApplyTable = null;
  let featureEnabled = true;
  const tableSortClickHandlers = new WeakMap();

  console.log(LOG_PREFIX, "module loaded");

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function warn(...args) {
    console.warn(LOG_PREFIX, ...args);
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function parsePageContext() {
    const match = (location.pathname || "").match(RESOURCE_USE_DATE_PATH_RE);
    if (!match) {
      return null;
    }
    return {
      companyShortname: match[1],
      resourceId: match[2],
      selectedDate: match[3]
    };
  }

  function isUrlEligible() {
    return isFareHarborHost() && !!parsePageContext();
  }

  function buildPageKey(ctx) {
    if (!ctx) {
      return null;
    }
    return `${ctx.companyShortname}|${ctx.resourceId}|${ctx.selectedDate}`;
  }

  function resetSortState() {
    createdAtSortDirection = SORT_DIRECTIONS.NONE;
    if (sortApplyTimer) {
      clearTimeout(sortApplyTimer);
      sortApplyTimer = null;
    }
    sortApplyTable = null;
  }

  function removeInjectedColumns() {
    const table = findResourceUseTable(document);
    if (table && createdAtSortDirection !== SORT_DIRECTIONS.NONE) {
      isApplyingSort = true;
      try {
        for (const tbody of table.querySelectorAll("tbody")) {
          sortBookingRowsInBody(tbody, SORT_DIRECTIONS.NONE);
        }
      } finally {
        setTimeout(() => {
          isApplyingSort = false;
        }, 0);
      }
    }

    document.querySelectorAll(`[${HEADER_ATTR}="true"]`).forEach((cell) => {
      cell.remove();
    });
    document.querySelectorAll(`[${CELL_ATTR}="true"]`).forEach((cell) => {
      cell.remove();
    });
    document.querySelectorAll(`[${ORIGINAL_ORDER_ATTR}]`).forEach((row) => {
      row.removeAttribute(ORIGINAL_ORDER_ATTR);
    });
    removeControls();
    resetSortState();
  }

  function applyFeatureSetting(enabled, reason) {
    featureEnabled = enabled !== false;
    if (!featureEnabled) {
      stopFeature();
      return;
    }
    evaluateLifecycle(reason || "setting-enabled");
  }

  function initSettingsBinding() {
    const settings = window.FHSettings;
    if (!settings) {
      return;
    }
    settings.get(SETTING_KEY, (value) => {
      applyFeatureSetting(value, "settings-init");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SETTING_KEY]) {
        applyFeatureSetting(changes[SETTING_KEY].newValue, "setting-change");
      }
    });
  }

  function clearPageCaches() {
    contactRequestCache.clear();
    bookingCreatedAtCache.clear();
    lastPageKey = null;
    currentPageContext = null;
    resetSortState();
  }

  function isValidDisplayMode(mode) {
    return (
      mode === DISPLAY_MODES.LOCAL ||
      mode === DISPLAY_MODES.GETYOURGUIDE ||
      mode === DISPLAY_MODES.VIATOR
    );
  }

  function loadDisplayMode() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get({ [STORAGE_KEY]: DISPLAY_MODES.LOCAL }, (result) => {
          const stored = result[STORAGE_KEY];
          displayMode = isValidDisplayMode(stored) ? stored : DISPLAY_MODES.LOCAL;
          resolve(displayMode);
        });
      } catch {
        displayMode = DISPLAY_MODES.LOCAL;
        resolve(displayMode);
      }
    });
  }

  function saveDisplayMode(mode) {
    try {
      chrome.storage.local.set({ [STORAGE_KEY]: mode });
    } catch {
      // ignore
    }
  }

  function cssEscape(value) {
    if (typeof CSS !== "undefined" && typeof CSS.escape === "function") {
      return CSS.escape(String(value));
    }
    return String(value).replace(/["\\]/g, "\\$&");
  }

  function normalizeIsoOffset(value) {
    return String(value || "").replace(/([+-]\d{2})(\d{2})$/, "$1:$2");
  }

  function parseTimestamp(rawTimestamp) {
    if (!rawTimestamp) {
      return null;
    }
    const date = new Date(normalizeIsoOffset(rawTimestamp));
    if (Number.isNaN(date.getTime())) {
      return null;
    }
    return date;
  }

  function createFixedOffsetDisplayDate(date, offsetMinutes) {
    return new Date(date.getTime() + offsetMinutes * 60 * 1000);
  }

  function getDateTimeFormatOptions(mode) {
    return {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
      ...(mode === DISPLAY_MODES.VIATOR ? { timeZone: "UTC" } : {})
    };
  }

  function formatCreatedAt(rawTimestamp, mode) {
    const date = parseTimestamp(rawTimestamp);
    if (!date) {
      return null;
    }

    if (mode === DISPLAY_MODES.GETYOURGUIDE) {
      const shifted = createFixedOffsetDisplayDate(date, GETYOURGUIDE_OFFSET_MINUTES);
      return new Intl.DateTimeFormat(undefined, getDateTimeFormatOptions(DISPLAY_MODES.VIATOR)).format(
        shifted
      );
    }

    return new Intl.DateTimeFormat(undefined, getDateTimeFormatOptions(mode)).format(date);
  }

  function getHeaderLabelText() {
    const base = HEADER_LABELS[displayMode] || HEADER_LABELS[DISPLAY_MODES.LOCAL];
    return base + (SORT_ARROWS[createdAtSortDirection] || SORT_ARROWS[SORT_DIRECTIONS.NONE]);
  }

  function getNextSortDirection(current) {
    if (current === SORT_DIRECTIONS.NONE) {
      return SORT_DIRECTIONS.OLDEST;
    }
    if (current === SORT_DIRECTIONS.OLDEST) {
      return SORT_DIRECTIONS.NEWEST;
    }
    return SORT_DIRECTIONS.NONE;
  }

  function syncSortDirectionOnHeaders() {
    document.querySelectorAll(`[${HEADER_ATTR}="true"]`).forEach((cell) => {
      cell.setAttribute(SORT_DIRECTION_ATTR, createdAtSortDirection);
    });
  }

  function isBookingRow(row) {
    return !!row.querySelector(`:scope > [${CELL_ATTR}="true"]`);
  }

  function getBookingRows(tbody) {
    return [...tbody.children].filter(
      (row) => row.tagName === "TR" && isBookingRow(row)
    );
  }

  function getEpochFromRow(row) {
    const cell = row.querySelector(`:scope > [${CELL_ATTR}="true"]`);
    if (!cell) {
      return NaN;
    }
    return Number(cell.getAttribute(CREATED_AT_EPOCH_ATTR));
  }

  function getOriginalOrder(row) {
    return Number(row.getAttribute(ORIGINAL_ORDER_ATTR) || 0);
  }

  function assignOriginalOrderInTbody(tbody) {
    let nextOrder = 0;
    for (const row of tbody.children) {
      if (row.tagName === "TR" && isBookingRow(row) && row.hasAttribute(ORIGINAL_ORDER_ATTR)) {
        const order = Number(row.getAttribute(ORIGINAL_ORDER_ATTR) || 0);
        if (order >= nextOrder) {
          nextOrder = order + 1;
        }
      }
    }

    for (const row of tbody.children) {
      if (row.tagName !== "TR" || !isBookingRow(row)) {
        continue;
      }
      if (!row.hasAttribute(ORIGINAL_ORDER_ATTR)) {
        row.setAttribute(ORIGINAL_ORDER_ATTR, String(nextOrder));
        nextOrder += 1;
      }
    }
  }

  function assignOriginalOrderInTable(table) {
    if (!table) {
      return;
    }
    table.querySelectorAll("tbody").forEach(assignOriginalOrderInTbody);
  }

  function compareBookingRows(a, b, direction) {
    if (direction === SORT_DIRECTIONS.NONE) {
      return getOriginalOrder(a) - getOriginalOrder(b);
    }

    const aEpoch = getEpochFromRow(a);
    const bEpoch = getEpochFromRow(b);
    const aValid = Number.isFinite(aEpoch);
    const bValid = Number.isFinite(bEpoch);

    if (aValid && !bValid) {
      return -1;
    }
    if (!aValid && bValid) {
      return 1;
    }
    if (!aValid && !bValid) {
      return getOriginalOrder(a) - getOriginalOrder(b);
    }
    if (aEpoch === bEpoch) {
      return getOriginalOrder(a) - getOriginalOrder(b);
    }
    return direction === SORT_DIRECTIONS.OLDEST
      ? aEpoch - bEpoch
      : bEpoch - aEpoch;
  }

  function sortBookingRowsInBody(tbody, direction) {
    const rows = getBookingRows(tbody);
    if (rows.length < 2) {
      return;
    }

    rows.sort((a, b) => compareBookingRows(a, b, direction));
    rows.forEach((row) => tbody.appendChild(row));
  }

  function applyCreatedAtSortToTable(table) {
    if (!table) {
      return;
    }

    const tbodies = table.querySelectorAll("tbody");
    if (!tbodies.length) {
      return;
    }

    isApplyingSort = true;
    try {
      for (const tbody of tbodies) {
        sortBookingRowsInBody(tbody, createdAtSortDirection);
      }
      log("sort applied", {
        direction: createdAtSortDirection,
        tbodyCount: tbodies.length
      });
    } finally {
      setTimeout(() => {
        isApplyingSort = false;
      }, 0);
    }
  }

  function cycleCreatedAtSort(table) {
    createdAtSortDirection = getNextSortDirection(createdAtSortDirection);
    syncSortDirectionOnHeaders();
    updateAllHeaders();
    applyCreatedAtSortToTable(table);
  }

  function attachCreatedAtSortHandlers(table) {
    if (!table || tableSortClickHandlers.has(table)) {
      return;
    }

    const handler = (event) => {
      const header = event.target.closest(`[${HEADER_ATTR}="true"]`);
      if (!header || !table.contains(header)) {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      cycleCreatedAtSort(table);
    };

    table.addEventListener("click", handler, true);
    tableSortClickHandlers.set(table, handler);
  }

  function scheduleSortApply(table) {
    sortApplyTable = table;
    if (sortApplyTimer) {
      clearTimeout(sortApplyTimer);
    }
    sortApplyTimer = setTimeout(() => {
      sortApplyTimer = null;
      const targetTable = sortApplyTable || findResourceUseTable(document);
      sortApplyTable = null;
      if (!targetTable || !isUrlEligible()) {
        return;
      }
      if (createdAtSortDirection !== SORT_DIRECTIONS.NONE) {
        applyCreatedAtSortToTable(targetTable);
      }
    }, SORT_APPLY_DEBOUNCE_MS);
  }

  function reapplySortIfActive() {
    if (createdAtSortDirection === SORT_DIRECTIONS.NONE) {
      return;
    }
    const table = findResourceUseTable(document);
    if (table) {
      applyCreatedAtSortToTable(table);
    }
  }

  function isExtensionNode(node) {
    if (!(node instanceof Element)) {
      const parent = node?.parentElement;
      return parent ? isExtensionNode(parent) : false;
    }
    if (node.getAttribute(HEADER_ATTR) === "true") {
      return true;
    }
    if (node.getAttribute(CELL_ATTR) === "true") {
      return true;
    }
    if (node.getAttribute(CONTROLS_ATTR) === "true") {
      return true;
    }
    return !!node.closest?.(`[${CONTROLS_ATTR}="true"], [${HEADER_ATTR}="true"], [${CELL_ATTR}="true"]`);
  }

  function isExtensionMutation(mutation) {
    if (isApplyingSort) {
      return true;
    }
    if (isExtensionNode(mutation.target)) {
      return true;
    }
    for (const node of mutation.addedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    for (const node of mutation.removedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    return false;
  }

  function parseBookingLinkFromHref(hrefText) {
    if (!hrefText) {
      return null;
    }

    const candidates = [String(hrefText).trim()];

    try {
      const parsed = new URL(hrefText, window.location.origin);
      candidates.push(parsed.pathname + parsed.search);
      const overlay = parsed.searchParams.get("overlay");
      if (overlay) {
        candidates.push(decodeURIComponent(overlay));
      }
    } catch {
      // ignore malformed URLs
    }

    for (const candidate of candidates) {
      const match = String(candidate).match(CONTACT_BOOKING_PATH_RE);
      if (!match) {
        continue;
      }
      return {
        contactId: decodeURIComponent(match[1]),
        bookingUuid: decodeURIComponent(match[2])
      };
    }

    return null;
  }

  function extractBookingIdentityFromRow(row) {
    const links = row.querySelectorAll("a[href]");
    for (const link of links) {
      const parsed = parseBookingLinkFromHref(link.getAttribute("href") || link.href);
      if (!parsed) {
        continue;
      }
      const bookingNumber = (link.textContent || "")
        .trim()
        .replace(/^#/, "");
      return {
        contactId: parsed.contactId,
        bookingUuid: parsed.bookingUuid,
        bookingNumber
      };
    }
    return null;
  }

  function isGroupHeadingRow(row) {
    const cells = [...row.children].filter(
      (el) => el.tagName === "TD" || el.tagName === "TH"
    );
    if (cells.length !== 1) {
      return false;
    }
    const colspan = Number(cells[0].getAttribute("colspan") || "0");
    return colspan >= 2;
  }

  function isHeaderRow(row) {
    return (
      row.classList.contains("ss-header-shade") &&
      row.classList.contains("as-thead")
    );
  }

  function isResourceUseTable(table) {
    if (!table) {
      return false;
    }
    if (table.getAttribute("ng-table") === "resourceUses") {
      return true;
    }
    const headerRows = table.querySelectorAll("tr.ss-header-shade.as-thead");
    for (const row of headerRows) {
      const cells = [...row.children].filter((el) => el.tagName === "TD" || el.tagName === "TH");
      if (cells.some((cell) => (cell.textContent || "").trim() === "Booking ID")) {
        return true;
      }
    }
    return false;
  }

  function findResourceUseTable(root) {
    const scope = root || document;
    const direct = scope.querySelector('table[ng-table="resourceUses"]');
    if (direct && isResourceUseTable(direct)) {
      return direct;
    }
    for (const table of scope.querySelectorAll("table.spreadsheet")) {
      if (isResourceUseTable(table)) {
        return table;
      }
    }
    return null;
  }

  function findObserverContainer(table) {
    if (!table) {
      return null;
    }
    return (
      table.closest('div[ng-controller*="Resource"]') ||
      table.closest(".settings-window") ||
      table.parentElement ||
      table
    );
  }

  function findControlsAnchor(table) {
    if (!table) {
      return null;
    }

    const container =
      table.closest('div[ng-controller*="Resource"]') ||
      table.closest(".settings-window") ||
      table.parentElement;

    if (!container) {
      return table;
    }

    const toolbars = container.querySelectorAll(".toolbar");
    for (const toolbar of toolbars) {
      if ((toolbar.textContent || "").includes("Group by")) {
        return toolbar;
      }
    }

    if (toolbars.length > 0) {
      return toolbars[0];
    }

    return table;
  }

  function findLayoutContainer() {
    return document.querySelector(LAYOUT_CONTAINER_SELECTOR);
  }

  function ensureLayoutMarker() {
    const layoutContainer = findLayoutContainer();
    if (!layoutContainer) {
      return null;
    }
    layoutContainer.setAttribute(LAYOUT_ATTR, "true");
    return layoutContainer;
  }

  function removeLayoutMarker() {
    document.querySelectorAll(`[${LAYOUT_ATTR}="true"]`).forEach((el) => {
      el.removeAttribute(LAYOUT_ATTR);
    });
  }

  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
[${CONTROLS_ATTR}="true"] {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  margin: 0 0 0.75rem 0;
  font-size: 13px;
  line-height: 1.4;
}
[${CONTROLS_ATTR}="true"] label {
  margin: 0;
  white-space: nowrap;
}
[${CONTROLS_ATTR}="true"] select {
  font-size: 13px;
  max-width: 100%;
}
[${HEADER_ATTR}="true"],
[${CELL_ATTR}="true"] {
  white-space: nowrap;
}
[${HEADER_ATTR}="true"] {
  cursor: pointer;
  user-select: none;
}
[ng-navigation-prefix="urls.dashboard.settings.resources.resource.uses.day"][${LAYOUT_ATTR}="true"] {
  width: min(calc(100% + 120px), calc(100vw - 32px));
  max-width: calc(100vw - 32px);
}`;
    (document.head || document.documentElement).appendChild(style);
  }

  function ensureControls(table) {
    ensureStyles();

    const existing = document.querySelector(`[${CONTROLS_ATTR}="true"]`);
    if (existing) {
      const select = existing.querySelector("select");
      if (select && select.value !== displayMode) {
        select.value = displayMode;
      }
      return existing;
    }

    const anchor = findControlsAnchor(table);
    if (!anchor) {
      return null;
    }

    const controls = document.createElement("div");
    controls.setAttribute(CONTROLS_ATTR, "true");

    const label = document.createElement("label");
    label.textContent = "Created time:";

    const select = document.createElement("select");
    select.innerHTML = `
<option value="${DISPLAY_MODES.LOCAL}">Local</option>
<option value="${DISPLAY_MODES.GETYOURGUIDE}">GetYourGuide (+02:00)</option>
<option value="${DISPLAY_MODES.VIATOR}">Viator (UTC)</option>`;
    select.value = displayMode;
    select.addEventListener("change", () => {
      const nextMode = select.value;
      if (!isValidDisplayMode(nextMode) || nextMode === displayMode) {
        return;
      }
      displayMode = nextMode;
      saveDisplayMode(displayMode);
      log("display mode changed", displayMode);
      updateAllHeaders();
      rerenderAllCells();
      reapplySortIfActive();
    });

    controls.appendChild(label);
    controls.appendChild(select);

    if (anchor === table) {
      anchor.parentElement?.insertBefore(controls, anchor);
    } else {
      anchor.insertAdjacentElement("afterend", controls);
    }

    return controls;
  }

  function removeControls() {
    document.querySelectorAll(`[${CONTROLS_ATTR}="true"]`).forEach((el) => {
      el.remove();
    });
  }

  function updateAllHeaders() {
    const label = getHeaderLabelText();
    document.querySelectorAll(`[${HEADER_ATTR}="true"]`).forEach((cell) => {
      cell.textContent = label;
      cell.setAttribute(SORT_DIRECTION_ATTR, createdAtSortDirection);
    });
  }

  function ensureHeaderCell(row) {
    let cell = row.querySelector(`:scope > [${HEADER_ATTR}="true"]`);
    if (!cell) {
      cell = document.createElement("td");
      cell.setAttribute(HEADER_ATTR, "true");
      row.appendChild(cell);
    }
    cell.textContent = getHeaderLabelText();
    cell.setAttribute(SORT_DIRECTION_ATTR, createdAtSortDirection);
    return cell;
  }

  function clearCellSortMetadata(cell) {
    cell.removeAttribute(CREATED_AT_RAW_ATTR);
    cell.removeAttribute(CREATED_AT_EPOCH_ATTR);
  }

  function setCellSortMetadata(cell, raw) {
    const date = parseTimestamp(raw);
    if (!date) {
      clearCellSortMetadata(cell);
      return;
    }
    cell.setAttribute(CREATED_AT_RAW_ATTR, raw);
    cell.setAttribute(CREATED_AT_EPOCH_ATTR, String(date.getTime()));
  }

  function renderCellContent(cell, bookingUuid) {
    if (!bookingCreatedAtCache.has(bookingUuid)) {
      cell.textContent = LOADING_TEXT;
      cell.removeAttribute("title");
      clearCellSortMetadata(cell);
      return;
    }

    const raw = bookingCreatedAtCache.get(bookingUuid);
    if (raw == null) {
      cell.textContent = MISSING_TEXT;
      cell.removeAttribute("title");
      clearCellSortMetadata(cell);
      return;
    }

    const formatted = formatCreatedAt(raw, displayMode);
    if (!formatted) {
      cell.textContent = MISSING_TEXT;
      cell.removeAttribute("title");
      clearCellSortMetadata(cell);
      return;
    }

    cell.textContent = formatted;
    cell.title = raw;
    setCellSortMetadata(cell, raw);
  }

  function renderCellsForBookingUuid(bookingUuid) {
    if (!isUrlEligible()) {
      return;
    }
    const cells = document.querySelectorAll(
      `[${CELL_ATTR}="true"][${BOOKING_UUID_ATTR}="${cssEscape(bookingUuid)}"]`
    );
    cells.forEach((cell) => {
      renderCellContent(cell, bookingUuid);
    });
  }

  function rerenderAllCells() {
    const seen = new Set();
    document.querySelectorAll(`[${CELL_ATTR}="true"][${BOOKING_UUID_ATTR}]`).forEach((cell) => {
      const bookingUuid = cell.getAttribute(BOOKING_UUID_ATTR);
      if (bookingUuid) {
        seen.add(bookingUuid);
      }
    });
    for (const bookingUuid of seen) {
      renderCellsForBookingUuid(bookingUuid);
    }
  }

  function ensureBookingCell(row, bookingUuid) {
    let cell = row.querySelector(
      `:scope > [${CELL_ATTR}="true"][${BOOKING_UUID_ATTR}="${cssEscape(bookingUuid)}"]`
    );
    if (!cell) {
      cell = document.createElement("td");
      cell.setAttribute(CELL_ATTR, "true");
      cell.setAttribute(BOOKING_UUID_ATTR, bookingUuid);
      row.appendChild(cell);
    }
    renderCellContent(cell, bookingUuid);
    return cell;
  }

  function buildContactApiUrl(ctx, contactId) {
    return `/api/v1/companies/${encodeURIComponent(ctx.companyShortname)}/contacts/${encodeURIComponent(contactId)}/`;
  }

  async function fetchContact(ctx, contactId) {
    if (!ctx || !contactId) {
      return null;
    }

    if (contactRequestCache.has(contactId)) {
      return contactRequestCache.get(contactId);
    }

    const promise = (async () => {
      const url = new URL(buildContactApiUrl(ctx, contactId), window.location.origin).href;
      try {
        const resp = await fetch(url, {
          credentials: "same-origin",
          headers: { Accept: "application/json" }
        });

        if (!resp.ok) {
          warn("contact fetch failed", { contactId, status: resp.status });
          return null;
        }

        let json;
        try {
          json = await resp.json();
        } catch {
          warn("contact fetch non-JSON response", { contactId });
          return null;
        }

        const contact = json?.contact;
        if (!contact) {
          warn("contact missing in response", { contactId });
          return null;
        }

        const bookings = contact.stand_alone_bookings;
        if (Array.isArray(bookings)) {
          for (const booking of bookings) {
            const uuid = booking?.uuid;
            if (!uuid) {
              continue;
            }
            if (!bookingCreatedAtCache.has(uuid)) {
              bookingCreatedAtCache.set(uuid, booking.created_at ?? null);
            }
          }
        }

        return contact;
      } catch (err) {
        warn("contact fetch error", { contactId, error: String(err?.message || err) });
        return null;
      }
    })();

    contactRequestCache.set(contactId, promise);
    return promise;
  }

  async function fetchContactsInBatches(ctx, contactIds) {
    const ids = [...contactIds];
    for (let i = 0; i < ids.length; i += FETCH_CONCURRENCY) {
      if (!isUrlEligible()) {
        return;
      }
      const batch = ids.slice(i, i + FETCH_CONCURRENCY);
      await Promise.all(batch.map((contactId) => fetchContact(ctx, contactId)));
    }
  }

  function syncPageContext() {
    const ctx = parsePageContext();
    const pageKey = buildPageKey(ctx);
    if (pageKey !== lastPageKey) {
      if (lastPageKey !== null) {
        contactRequestCache.clear();
        bookingCreatedAtCache.clear();
        resetSortState();
      }
      lastPageKey = pageKey;
      currentPageContext = ctx;
      if (ctx) {
        log("matching route detected", ctx);
      }
    }
    return ctx;
  }

  async function scanResourceUseTable(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return false;
    }
    if (scanInProgress) {
      return false;
    }

    scanInProgress = true;
    try {
      const ctx = syncPageContext();
      if (!ctx) {
        return false;
      }

      ensureStyles();
      ensureLayoutMarker();

      const table = findResourceUseTable(document);
      if (!table) {
        return false;
      }

      ensureControls(table);
      updateObserverTarget(table);

      const bookingRows = [];
      const contactIds = new Set();
      const bookingUuids = new Set();

      for (const row of table.querySelectorAll("tbody tr")) {
        if (isGroupHeadingRow(row)) {
          continue;
        }
        if (isHeaderRow(row)) {
          ensureHeaderCell(row);
          continue;
        }

        const identity = extractBookingIdentityFromRow(row);
        if (!identity) {
          continue;
        }

        ensureBookingCell(row, identity.bookingUuid);
        bookingRows.push(identity);
        bookingUuids.add(identity.bookingUuid);
        if (!contactRequestCache.has(identity.contactId)) {
          contactIds.add(identity.contactId);
        }
      }

      if (bookingRows.length > 0 || contactIds.size > 0) {
        log("scan complete", {
          reason,
          bookingRows: bookingRows.length,
          uniqueBookings: bookingUuids.size,
          uniqueContacts: contactIds.size
        });
      }

      if (contactIds.size > 0) {
        await fetchContactsInBatches(ctx, contactIds);
      }

      for (const bookingUuid of bookingUuids) {
        if (!bookingCreatedAtCache.has(bookingUuid)) {
          bookingCreatedAtCache.set(bookingUuid, null);
        }
        renderCellsForBookingUuid(bookingUuid);
      }

      assignOriginalOrderInTable(table);
      attachCreatedAtSortHandlers(table);
      updateAllHeaders();
      if (createdAtSortDirection !== SORT_DIRECTIONS.NONE) {
        if (contactIds.size > 0) {
          scheduleSortApply(table);
        } else {
          applyCreatedAtSortToTable(table);
        }
      }

      return true;
    } finally {
      scanInProgress = false;
    }
  }

  function scheduleScan(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }
    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      scanResourceUseTable(reason || "debounced-scan");
    }, SCAN_DEBOUNCE_MS);
  }

  function stopRetryLoop() {
    if (retryTimer) {
      clearInterval(retryTimer);
      retryTimer = null;
    }
    retryStartedAt = 0;
  }

  function startRetryLoop(reason) {
    if (!isUrlEligible()) {
      stopRetryLoop();
      return;
    }

    if (!retryTimer) {
      retryStartedAt = Date.now();
      retryTimer = setInterval(async () => {
        const elapsed = Date.now() - retryStartedAt;
        const found = await scanResourceUseTable("retry-loop");
        if (found) {
          stopRetryLoop();
          return;
        }
        if (elapsed >= RETRY_MAX_MS) {
          stopRetryLoop();
        }
      }, RETRY_INTERVAL_MS);
    }

    scheduleScan(reason || "retry-schedule");
  }

  function updateObserverTarget(table) {
    const container = findObserverContainer(table);
    if (!container || container === observerTarget) {
      return;
    }

    if (observer) {
      observer.disconnect();
      observer = null;
    }

    observerTarget = container;
    observer = new MutationObserver((mutations) => {
      if (!isUrlEligible()) {
        return;
      }
      if (mutations.length > 0 && mutations.every(isExtensionMutation)) {
        return;
      }
      scheduleScan("mutation-observer");
    });
    observer.observe(observerTarget, { childList: true, subtree: true });
  }

  function stopFeature() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    observerTarget = null;
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    if (sortApplyTimer) {
      clearTimeout(sortApplyTimer);
      sortApplyTimer = null;
    }
    sortApplyTable = null;
    stopRetryLoop();
    removeLayoutMarker();
    removeInjectedColumns();
    contactRequestCache.clear();
    bookingCreatedAtCache.clear();
    lastPageKey = null;
    currentPageContext = null;
    scanInProgress = false;
    watchersActive = false;
    isApplyingSort = false;
  }

  function startObserver() {
    if (observer) {
      return;
    }

    const table = findResourceUseTable(document);
    const target = findObserverContainer(table) || document.documentElement;
    observerTarget = target;

    observer = new MutationObserver((mutations) => {
      if (!isUrlEligible()) {
        return;
      }
      if (mutations.length > 0 && mutations.every(isExtensionMutation)) {
        return;
      }
      scheduleScan("mutation-observer");
    });

    observer.observe(observerTarget, { childList: true, subtree: true });
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  function evaluateLifecycle(reason) {
    if (!featureEnabled) {
      return;
    }
    if (!isUrlEligible()) {
      stopFeature();
      return;
    }

    if (!watchersActive) {
      log("eligible page detected", { reason, href: location.href });
      startObserver();
      watchersActive = true;
    }

    startRetryLoop(reason || "lifecycle");
  }

  function onRouteChange(reason) {
    const nextHref = location.href;
    const prevCtx = currentPageContext || parsePageContext();
    const prevKey = buildPageKey(prevCtx);

    lastTrackedHref = nextHref;

    const nextCtx = parsePageContext();
    const nextKey = buildPageKey(nextCtx);

    if (prevKey !== nextKey) {
      contactRequestCache.clear();
      bookingCreatedAtCache.clear();
      resetSortState();
      lastPageKey = nextKey;
      currentPageContext = nextCtx;
    }

    if (!nextCtx) {
      stopFeature();
      return;
    }

    scheduleLifecycleEval(reason || "route-change");
  }

  function startRouteWatchers() {
    if (routeWatchersStarted) {
      return;
    }
    routeWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", () => onRouteChange("popstate"));
    window.addEventListener("hashchange", () => onRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        onRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        onRouteChange("replaceState");
        return result;
      };
    } catch (err) {
      warn("history hook unavailable:", err);
    }

    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        onRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  async function init() {
    if (!isFareHarborHost()) {
      return;
    }

    await loadDisplayMode();

    initSettingsBinding();

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes[STORAGE_KEY]) {
        return;
      }
      const nextMode = changes[STORAGE_KEY].newValue;
      if (!isValidDisplayMode(nextMode) || nextMode === displayMode) {
        return;
      }
      displayMode = nextMode;
      const select = document.querySelector(`[${CONTROLS_ATTR}="true"] select`);
      if (select) {
        select.value = displayMode;
      }
      updateAllHeaders();
      rerenderAllCells();
      reapplySortIfActive();
    });

    startRouteWatchers();
    evaluateLifecycle("init");

    if (document.readyState === "loading") {
      document.addEventListener(
        "DOMContentLoaded",
        () => evaluateLifecycle("dom-content-loaded"),
        { once: true }
      );
    }
  }

  init();
})();
