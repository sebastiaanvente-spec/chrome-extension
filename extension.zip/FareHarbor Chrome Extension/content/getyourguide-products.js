console.log("[getyourguide-products] getyourguide-products.js loaded");

// Token captured from page-context script (Bearer value only, no "Bearer " prefix)
let gygCachedToken = null;

// Listen for token from page-context script
function initGYGTokenListener() {
  if (window.__gygTokenListenerInit) return;
  window.__gygTokenListenerInit = true;
  window.addEventListener("message", function (event) {
    if (event.source !== window || !event.data || event.data.type !== "GYG_TOKEN" || !event.data.token) return;
    if (event.origin !== window.location.origin) return;
    gygCachedToken = event.data.token;
    console.log("[getyourguide-products] GYG Bearer token captured from page");
  });
}

function sendGYGBackgroundMessage(message) {
  return new Promise(function (resolve, reject) {
    chrome.runtime.sendMessage(message, function (response) {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(response || {});
    });
  });
}

function installGYGTokenCaptureViaBackground() {
  if (window.__gygTokenCaptureRequested) return;
  window.__gygTokenCaptureRequested = true;
  sendGYGBackgroundMessage({ type: "gygInstallTokenCapture" }).catch(function (err) {
    console.warn("[getyourguide-products] Token capture install failed:", err && err.message ? err.message : err);
  });
}

// Run listener and request MAIN-world token capture from background as soon as this script loads
if (typeof window !== "undefined" && window.location.href.indexOf("supplier.getyourguide.com") !== -1) {
  initGYGTokenListener();
  installGYGTokenCaptureViaBackground();
}

function injectGYGTokenCaptureScript() {
  installGYGTokenCaptureViaBackground();
}

function triggerPageGraphQLRequestForTokenCapture() {
  sendGYGBackgroundMessage({ type: "gygTriggerGraphQLForToken" }).catch(function (err) {
    console.warn("[getyourguide-products] Token trigger request failed:", err && err.message ? err.message : err);
  });
}

function requestTokenFromPageContext() {
  sendGYGBackgroundMessage({ type: "gygReadBearerToken" }).then(function (response) {
    if (response && response.ok && response.token) {
      gygCachedToken = response.token;
    }
  }).catch(function (err) {
    console.warn("[getyourguide-products] Read bearer token failed:", err && err.message ? err.message : err);
  });
}

// Run one GraphQL request in MAIN world via background executeScript.
// Returns Promise<{ ok, status, statusText, rawText }>.
function fetchGraphQLViaPage(endpoint, body, supplierId) {
  var requestId = "gyg-" + Date.now() + "-" + Math.random().toString(36).slice(2);
  console.log("[getyourguide-products] GraphQL request via background:", requestId);

  return new Promise(function (resolve, reject) {
    var done = false;
    var safetyTimer = setTimeout(function () {
      if (done) return;
      done = true;
      reject(new Error("GraphQL request timed out"));
    }, 55000);

    sendGYGBackgroundMessage({
      type: "gygGraphQLRequest",
      requestId: requestId,
      endpoint: endpoint,
      body: body,
      supplierId: supplierId || "",
      pageToken: gygCachedToken || ""
    }).then(function (response) {
      if (done) return;
      done = true;
      clearTimeout(safetyTimer);

      if (!response || response.requestId !== requestId) {
        reject(new Error("GraphQL response mismatch for request " + requestId));
        return;
      }
      if (response.error && response.status === 0) {
        reject(new Error(response.error));
        return;
      }
      resolve({
        ok: Boolean(response.ok),
        status: typeof response.status === "number" ? response.status : 0,
        statusText: response.statusText || "",
        rawText: response.rawText || "",
        error: response.error || ""
      });
    }).catch(function (err) {
      if (done) return;
      done = true;
      clearTimeout(safetyTimer);
      reject(err);
    });
  });
}

// Get supplier id: cookie supplier_id first, else from cached token payload, else null
function getSupplierIdFromPage() {
  try {
    const cookie = document.cookie;
    const match = cookie.match(/\bsupplier_id=(\d+)/);
    if (match) return match[1];
  } catch (_) {}
  if (gygCachedToken) {
    try {
      const payload = JSON.parse(atob(gygCachedToken.split(".")[1]));
      if (typeof payload.supplier_id === "number") return String(payload.supplier_id);
    } catch (_) {}
  }
  return null;
}

// Wait for utilities to be available and initialize module
(function initializeGetYourGuideProducts() {
  initGYGTokenListener();
  injectGYGTokenCaptureScript();

  // GraphQL query for activity option search (matches supplier-portal UI).
  const GYG_ACTIVITY_OPTION_SEARCH_QUERY = (
    "fragment OptionSetupCompletenessFields on OptionCompletenessValue {\n  option_title\n  option_code\n  time_unit\n  option_description\n  skip_the_line_type\n  wheelchair_accessible_flag\n  time_type\n  time_value\n  private_flag\n  group_size_max\n  languages_live_guide\n  languages_audio_guide\n  languages_booklet\n  time_valid_from\n  __typename\n}\n\n" +
    "fragment MeetingPointCompletenessFields on OptionCompletenessValue {\n  activity_starting_place\n  pick_up_type\n  pick_up_confirmation_time\n  pick_up_locations\n  pick_up_areas\n  pick_up_description\n  pick_up_minutes_before\n  pick_up_transportation_types\n  drop_off_type\n  drop_off_location\n  drop_off_transportation_types\n  meeting_point_location\n  meeting_point_description\n  meeting_point_transportation_types\n  meeting_point_minutes_before\n  __typename\n}\n\n" +
    "fragment OptionsDetailsSearchInfo on ActivityOption {\n  id\n  status\n  blockingReason\n  supplierOptionCode\n  private\n  nextAvailableDate\n  maxAvailabilityDate\n  bookingEngine\n  inventoryConfiguration {\n    cutOffTimeInSeconds\n    newTicketSource\n    availabilityType\n    usesPricingOverApi\n    __typename\n  }\n  connectivitySettings {\n    externalProductId\n    __typename\n  }\n  sourceText {\n    title\n    description\n    __typename\n  }\n  timezone\n  cutOffConfiguration {\n    cutOffTimeInSeconds\n    optionHasCutOffOverrideInTimeSlot\n    __typename\n  }\n  duration {\n    unit\n    value\n    __typename\n  }\n  __typename\n}\n\n" +
    "fragment CutOffCompletenessFields on OptionCompletenessValue {\n  cut_off_time\n  __typename\n}\n\n" +
    "query CatalogActivityOption_ActivityOptionDetailsSearch($input: SearchInput) {\n  activityOptionSearch(input: $input) {\n    items {\n      ...OptionsDetailsSearchInfo\n      completeness {\n        ...OptionSetupCompletenessFields\n        ...MeetingPointCompletenessFields\n        ...CutOffCompletenessFields\n        __typename\n      }\n      __typename\n    }\n    pagination {\n      limit\n      offset\n      totalItems\n      __typename\n    }\n    __typename\n  }\n}"
  );

  const GYG_APOLLO_CLIENT_VERSION = "v47840";

  function buildGYGActivitySearchFilters(tourId) {
    return [
      { field: "activity.id", values: [String(tourId)] },
      { field: "status", values: ["active"] }
    ];
  }

  /**
   * Tries to get the Bearer token and supplier id from the page's storage (same origin).
   * Returns { token, supplierId } or { token: null, supplierId: null } if not found.
   */
  function getGYGAuthFromPage() {
    let token = null;
    let supplierId = null;
    function useToken(s) {
      if (!s || !s.startsWith("eyJ") || s.length < 100) return false;
      token = s;
      try {
        const payload = JSON.parse(atob(s.split(".")[1]));
        if (typeof payload.supplier_id === "number") supplierId = payload.supplier_id;
      } catch (_) {}
      return true;
    }
    function tryVal(val) {
      if (!val || typeof val !== "string") return false;
      if (useToken(val)) return true;
      const jwtMatch = val.match(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/);
      return jwtMatch ? useToken(jwtMatch[0]) : false;
    }
    try {
      const commonKeys = ["authToken", "token", "access_token", "id_token", "auth_token", "gyg_token", "supplier_token"];
      for (const key of commonKeys) {
        const val = localStorage.getItem(key) || sessionStorage.getItem(key);
        if (tryVal(val)) return { token, supplierId };
      }
      for (let i = 0; i < localStorage.length; i++) {
        const val = localStorage.getItem(localStorage.key(i));
        if (tryVal(val)) return { token, supplierId };
      }
      for (let i = 0; i < sessionStorage.length; i++) {
        const val = sessionStorage.getItem(sessionStorage.key(i));
        if (tryVal(val)) return { token, supplierId };
      }
    } catch (e) {
      console.warn("[getyourguide-products] Could not read auth from storage:", e);
    }
    return { token, supplierId };
  }

  function getTokenForGraphQL() {
    const fromCache = gygCachedToken;
    if (fromCache) return fromCache;
    const fromPage = getGYGAuthFromPage();
    return fromPage.token || null;
  }

  // When we have no token, try to get it from page context (window.__gygBearerToken) and optionally trigger a page request
  function ensureTokenFromPageContext() {
    requestTokenFromPageContext();
    return new Promise(function (resolve) {
      setTimeout(function () {
        resolve(getTokenForGraphQL());
      }, 400);
    });
  }

  // Extract Product ID from the page
  function getProductId() {
    const productIdElement = Array.from(document.querySelectorAll('span.product-head__item-key')).find(
      span => span.textContent.includes('Product Id:')
    );
    
    if (productIdElement) {
      const parentDiv = productIdElement.closest('div');
      if (parentDiv) {
        const text = parentDiv.textContent.trim();
        const match = text.match(/Product Id:\s*(\d+)/);
        if (match) {
          return match[1];
        }
      }
    }
    return null;
  }

  // Extract data from current page
  function scrapeCurrentPage(productId) {
    const result = [];
    
    console.log("[getyourguide-products] Scraping current page...");
    
    // Find all option-details elements
    const allOptionDetailsElements = document.querySelectorAll('div.option-details');
    console.log(`[getyourguide-products] Found ${allOptionDetailsElements.length} option-details elements on current page`);
    
    if (allOptionDetailsElements.length === 0) {
      return result; // Return empty array, not null
    }
    
    // Filter out nested option-details (if a parent is also an option-details, skip the child)
    const optionDetailsElements = Array.from(allOptionDetailsElements).filter(element => {
      let parent = element.parentElement;
      while (parent) {
        if (parent.classList.contains('option-details')) {
          return false; // This is a nested option-details, skip it
        }
        parent = parent.parentElement;
      }
      return true; // This is a top-level option-details
    });
    
    console.log(`[getyourguide-products] Filtered to ${optionDetailsElements.length} top-level option-details elements`);
    
    // Extract data from each option-details element
    optionDetailsElements.forEach((optionElement, index) => {
      let optionId = '';
      let optionName = '';
      let externalProductId = '';
      
      // Helper function to find value for a given title
      function findValueForTitle(titleText) {
        // Find all title elements
        const titles = optionElement.querySelectorAll('div.option-details-title');
        for (const title of titles) {
          if (title.textContent.trim() === titleText) {
            // Find the next value element (could be next sibling or next in DOM order)
            let nextElement = title.nextElementSibling;
            while (nextElement) {
              if (nextElement.classList.contains('option-details-value')) {
                return nextElement.textContent.trim();
              }
              nextElement = nextElement.nextElementSibling;
            }
            // If not found as sibling, try finding all values and matching by index
            const allTitles = Array.from(optionElement.querySelectorAll('div.option-details-title'));
            const allValues = Array.from(optionElement.querySelectorAll('div.option-details-value'));
            const titleIndex = allTitles.indexOf(title);
            if (titleIndex >= 0 && titleIndex < allValues.length) {
              return allValues[titleIndex].textContent.trim();
            }
          }
        }
        return '';
      }
      
      // Extract Option ID
      optionId = findValueForTitle('Option ID');
      
      // Extract Option name (Title)
      optionName = findValueForTitle('Title');
      
      // Extract External Product ID (try both possible label variations)
      externalProductId = findValueForTitle('External product ID') || findValueForTitle('External Product ID');
      
      // Extract Status
      let status = findValueForTitle('Status');
      // Status might be in a nested span with class "p-tag-label", so try to extract that if found
      if (status) {
        // Check if there's a span with class "p-tag-label" in the status value element
        const statusTitle = Array.from(optionElement.querySelectorAll('div.option-details-title')).find(
          title => title.textContent.trim() === 'Status'
        );
        if (statusTitle) {
          let nextElement = statusTitle.nextElementSibling;
          while (nextElement) {
            if (nextElement.classList.contains('option-details-value')) {
              const tagLabel = nextElement.querySelector('span.p-tag-label');
              if (tagLabel) {
                status = tagLabel.textContent.trim();
              }
              break;
            }
            nextElement = nextElement.nextElementSibling;
          }
        }
      }
      
      // Only add if we have at least Option ID
      if (optionId) {
        result.push({
          productId: productId,
          optionId: optionId,
          optionName: optionName || '',
          externalProductId: externalProductId || '',
          status: status || ''
        });
        console.log(`[getyourguide-products] Extracted option: Product ID=${productId}, Option ID=${optionId}, Option Name=${optionName}, External Product ID=${externalProductId}, Status=${status}`);
      } else {
        console.warn(`[getyourguide-products] Skipped option ${index + 1} - missing Option ID`);
      }
    });
    
    console.log(`[getyourguide-products] Successfully extracted ${result.length} options from current page`);
    return result;
  }

  // Check if pagination exists (exclude history datatable pagination)
  function hasPagination() {
    const paginators = document.querySelectorAll('.p-paginator-content');
    
    // Find paginator that is NOT inside a datatable (history table)
    for (const paginator of paginators) {
      // Check if this paginator is inside a datatable element
      const datatable = paginator.closest('.p-datatable');
      if (!datatable) {
        // This paginator is not inside a datatable, so it's the one we want
        console.log("[getyourguide-products] Found pagination (not in history datatable)");
        return true;
      }
    }
    
    return false;
  }

  // Get all page numbers from paginator (exclude history datatable pagination)
  function getAllPageNumbers() {
    const paginators = document.querySelectorAll('.p-paginator-content');
    let targetPaginator = null;
    
    // Find the paginator that is NOT inside a datatable
    for (const paginator of paginators) {
      const datatable = paginator.closest('.p-datatable');
      if (!datatable) {
        targetPaginator = paginator;
        break;
      }
    }
    
    if (!targetPaginator) {
      console.warn("[getyourguide-products] No valid paginator found (all are in datatables)");
      return [];
    }
    
    const pageButtons = targetPaginator.querySelectorAll('.p-paginator-page');
    const pageNumbers = [];
    
    pageButtons.forEach(button => {
      const pageNum = parseInt(button.textContent.trim());
      if (!isNaN(pageNum)) {
        pageNumbers.push(pageNum);
      }
    });
    
    // Sort and remove duplicates
    return [...new Set(pageNumbers)].sort((a, b) => a - b);
  }

  // Click a specific page number (exclude history datatable pagination)
  function clickPage(pageNumber) {
    const paginators = document.querySelectorAll('.p-paginator-content');
    let targetPaginator = null;
    
    // Find the paginator that is NOT inside a datatable
    for (const paginator of paginators) {
      const datatable = paginator.closest('.p-datatable');
      if (!datatable) {
        targetPaginator = paginator;
        break;
      }
    }
    
    if (!targetPaginator) {
      console.warn("[getyourguide-products] No valid paginator found for clicking");
      return false;
    }
    
    const pageButtons = targetPaginator.querySelectorAll('.p-paginator-page');
    for (const button of pageButtons) {
      const buttonPageNum = parseInt(button.textContent.trim());
      if (buttonPageNum === pageNumber) {
        console.log(`[getyourguide-products] Clicking page ${pageNumber}...`);
        button.click();
        return true;
      }
    }
    return false;
  }

  // Wait for page content to load
  function waitForPageLoad() {
    return new Promise((resolve) => {
      // Wait for the page to finish loading/updating
      setTimeout(() => {
        console.log("[getyourguide-products] Page load wait completed");
        resolve();
      }, 2000); // Wait 2 seconds for page transition
    });
  }

  // Main scraping function with pagination support
  async function scrapeGetYourGuideProducts() {
    const allResults = [];
    
    console.log("[getyourguide-products] Scraping GetYourGuide products...");
    
    // Get Product ID (should be same across all pages)
    const productId = getProductId();
    if (!productId) {
      console.warn("[getyourguide-products] Product ID not found");
      return null;
    }
    
    console.log(`[getyourguide-products] Found Product ID: ${productId}`);
    
    // Track seen Option IDs across all pages to prevent duplicates
    const seenOptionIds = new Set();
    
    // Check if pagination exists
    if (hasPagination()) {
      console.log("[getyourguide-products] Pagination detected, will scrape all pages");
      
      const pageNumbers = getAllPageNumbers();
      console.log(`[getyourguide-products] Found ${pageNumbers.length} pages: ${pageNumbers.join(', ')}`);
      
      // Scrape each page
      for (let i = 0; i < pageNumbers.length; i++) {
        const pageNum = pageNumbers[i];
        console.log(`[getyourguide-products] Processing page ${pageNum} (${i + 1}/${pageNumbers.length})...`);
        
        // Click the page if it's not the first page (we're already on first page)
        if (i > 0) {
          if (!clickPage(pageNum)) {
            console.warn(`[getyourguide-products] Failed to click page ${pageNum}`);
            continue;
          }
          await waitForPageLoad();
        }
        
        // Scrape current page
        const pageResults = scrapeCurrentPage(productId);
        
        // Filter out duplicates and add to all results
        pageResults.forEach(item => {
          if (!seenOptionIds.has(item.optionId)) {
            seenOptionIds.add(item.optionId);
            allResults.push(item);
          } else {
            console.warn(`[getyourguide-products] Skipped duplicate Option ID=${item.optionId} on page ${pageNum}`);
          }
        });
        
        console.log(`[getyourguide-products] Page ${pageNum} complete: ${pageResults.length} options extracted, ${allResults.length} total unique options so far`);
      }
    } else {
      console.log("[getyourguide-products] No pagination detected, scraping single page");
      // No pagination, just scrape current page
      const pageResults = scrapeCurrentPage(productId);
      
      // Filter out duplicates using seenOptionIds
      pageResults.forEach(item => {
        if (!seenOptionIds.has(item.optionId)) {
          seenOptionIds.add(item.optionId);
          allResults.push(item);
        } else {
          console.warn(`[getyourguide-products] Skipped duplicate Option ID=${item.optionId} on single page`);
        }
      });
    }
    
    console.log(`[getyourguide-products] Successfully extracted ${allResults.length} total unique options`);
    return allResults;
  }
  
  /**
   * Fetches all GetYourGuide activity options via GraphQL with offset pagination.
   * @param {string} endpoint - GraphQL endpoint URL (e.g. origin + '/graphql')
   * @param {string} query - Full GraphQL document for CatalogActivityOption_ActivityOptionDetailsSearch
   * @param {object} baseInput - Variables.input base object (filters); limit and offset are overridden
   * @returns {Promise<Array<object>>} Flattened array of all option objects (ActivityOption)
   */
  async function doOneGraphQLRequest(endpoint, query, input, token, supplierId, retryOn401) {
    const requestBody = {
      operationName: "CatalogActivityOption_ActivityOptionDetailsSearch",
      query: query,
      variables: { input: input }
    };
    const body = JSON.stringify(requestBody);

    const activityFilter = toArr(input && input.filters).find(function (f) {
      return f && String(f.field).toLowerCase() === "activity.id";
    });
    const tourId = activityFilter && toArr(activityFilter.values)[0] != null
      ? String(toArr(activityFilter.values)[0])
      : "";

    console.log("[getyourguide-products] GraphQL variables", JSON.stringify(requestBody.variables, null, 2));
    console.log("[getyourguide-products] GraphQL request check", {
      operationName: requestBody.operationName,
      queryLength: requestBody.query.length,
      tourId: tourId,
      filters: requestBody.variables.input.filters,
      hasSupplierIdHeader: supplierId != null && String(supplierId).length > 0
    });

    const isGYG = window.location.href.indexOf("supplier.getyourguide.com") !== -1;
    if (isGYG) {
      let bridgeResponse = await fetchGraphQLViaPage(endpoint, body, supplierId != null ? String(supplierId) : "");
      if (bridgeResponse.status === 401 && retryOn401) {
        await new Promise(resolve => setTimeout(resolve, 1500));
        bridgeResponse = await fetchGraphQLViaPage(endpoint, body, supplierId != null ? String(supplierId) : "");
      }
      return bridgeResponse;
    }

    const headers = {
      "content-type": "application/json",
      "authorization": "Bearer " + token
    };
    if (supplierId != null) headers["x-gyg-supplier-id"] = String(supplierId);
    headers["apollographql-client-name"] = "supplier-portal";
    headers["apollographql-client-version"] = GYG_APOLLO_CLIENT_VERSION;

    let response = await fetch(endpoint, {
      method: "POST",
      credentials: "include",
      headers,
      body
    });

    if (response.status === 401 && retryOn401) {
      triggerPageGraphQLRequestForTokenCapture();
      await new Promise(r => setTimeout(r, 1200));
      requestTokenFromPageContext();
      await new Promise(r => setTimeout(r, 500));
      const newToken = getTokenForGraphQL();
      if (newToken) {
        headers["authorization"] = "Bearer " + newToken;
        response = await fetch(endpoint, { method: "POST", credentials: "include", headers, body });
      }
    }

    const rawText = await response.text();
    return {
      ok: response.ok,
      status: response.status,
      statusText: response.statusText || "",
      rawText: rawText || ""
    };
  }

  function toStr(v) { return v == null ? "" : String(v); }
  function toArr(v) { return Array.isArray(v) ? v : []; }
  function toObj(v) { return v && typeof v === "object" ? v : {}; }

  async function fetchAllGYGOptionsV2(endpoint, query, baseInput) {
    const LIMIT = Math.min(50, (baseInput && baseInput.limit) || 50);
    const mapById = new Map();
    let offset = 0;
    let totalItems = null;
    const filters = (baseInput && baseInput.filters) ? baseInput.filters : [];

    const usePageContext = window.location.href.indexOf("supplier.getyourguide.com") !== -1;
    let token = null;
    if (!usePageContext) {
      token = getTokenForGraphQL();
      if (!token) token = await ensureTokenFromPageContext();
      if (!token) {
        triggerPageGraphQLRequestForTokenCapture();
        await new Promise(r => setTimeout(r, 1500));
        requestTokenFromPageContext();
        await new Promise(r => setTimeout(r, 500));
        token = getTokenForGraphQL();
      }
      if (!token) {
        throw new Error("No auth token captured. Please refresh this page, use the site normally (e.g. open a product), then try the button again.");
      }
    }
    let supplierId = getSupplierIdFromPage();
    if (supplierId == null) {
      const fromPage = getGYGAuthFromPage();
      if (fromPage.supplierId != null) supplierId = String(fromPage.supplierId);
    }

    while (totalItems === null || offset < totalItems) {
      const input = { ...baseInput, filters, limit: LIMIT, offset };
      const bridgeResponse = await doOneGraphQLRequest(endpoint, query, input, token, supplierId, true);
      token = getTokenForGraphQL() || token;

      if (bridgeResponse.status === 401) {
        throw new Error("Session expired or not authenticated. Refresh this page, use the site once (e.g. click a product), then try again.");
      }
      if (!bridgeResponse.ok) {
        throw new Error(
          bridgeResponse.error ||
          ("GetYourGuide GraphQL request failed with HTTP " + bridgeResponse.status + ": " +
          (bridgeResponse.rawText || bridgeResponse.statusText || "Unknown error"))
        );
      }

      let json;
      try {
        json = JSON.parse(bridgeResponse.rawText);
      } catch (error) {
        throw new Error(
          "GetYourGuide returned invalid JSON: " + (bridgeResponse.rawText ? bridgeResponse.rawText.slice(0, 500) : "")
        );
      }

      if (json.errors && Array.isArray(json.errors) && json.errors.length > 0) {
        throw new Error(
          "GetYourGuide GraphQL error: " + json.errors
            .map(function (error) { return error && error.message ? error.message : String(error); })
            .join("; ")
        );
      }

      const search = json.data && json.data.activityOptionSearch;
      if (!search) {
        break;
      }

      const items = toArr(search.items);
      items.forEach(item => {
        const id = item != null && item.id != null ? String(item.id) : null;
        if (id != null) mapById.set(id, item);
      });

      const pagination = search.pagination || null;
      if (pagination) {
        totalItems = pagination.totalItems;
        const respOffset = pagination.offset;
        const respLimit = pagination.limit;
        const nextOffset = (respOffset != null ? respOffset : offset) + (respLimit != null ? respLimit : LIMIT);
        if (nextOffset === offset) throw new Error("Pagination not advancing");
        if (totalItems != null && nextOffset >= totalItems) break;
        offset = nextOffset;
      } else {
        break;
      }

      await new Promise(r => setTimeout(r, 400 + Math.random() * 200));
    }

    console.log("[getyourguide-products] Total items fetched:", mapById.size);
    return Array.from(mapById.values());
  }

  /**
   * Maps raw API ActivityOption to the shape used by TSV/copy (productId, optionId, optionName, externalProductId, status).
   * Null-safe using toStr/toArr/toObj and optional chaining.
   */
  function mapActivityOptionToRow(option, productIdFallback) {
    const o = toObj(option);
    const productId = toStr(o.activityId) || toStr(productIdFallback);
    const sourceText = toObj(o.sourceText);
    const connectivitySettings = toObj(o.connectivitySettings);
    const title = toStr(sourceText.title) || toStr(o.title) || toStr(o.name);
    let externalId = toStr(connectivitySettings.externalProductId) || toStr(o.externalId) || toStr(o.externalProductId);
    if (String(externalId).trim().toUpperCase() === "GYG_MANAGED") externalId = "";
    return {
      productId,
      optionId: toStr(o.id),
      optionName: title,
      externalProductId: externalId,
      status: toStr(o.status)
    };
  }

  /**
   * Map one raw item to row with try/catch. Returns { row, error }.
   */
  function mapItemSafe(item, productIdFallback) {
    try {
      return { row: mapActivityOptionToRow(item, productIdFallback), error: null };
    } catch (err) {
      return { row: null, error: (err && err.message) ? err.message : String(err) };
    }
  }

  /**
   * Fetches all activity options for one tour (status-agnostic). Deduplicates by id, builds mappedById and errorsById.
   * @param {string} tourId - Activity/tour id to filter by
   * @param {number} limit - Page size (default 50)
   * @returns {Promise<{items: Array<object>, mappedById: object, errorsById: object}>}
   */
  async function fetchAllActivityOptions(tourId, limit = 50) {
    const endpoint = window.location.origin + "/graphql";
    const baseInput = {
      filters: buildGYGActivitySearchFilters(tourId)
    };
    const rawItems = await fetchAllGYGOptionsV2(endpoint, GYG_ACTIVITY_OPTION_SEARCH_QUERY, { ...baseInput, limit });
    const mappedById = {};
    const errorsById = {};
    rawItems.forEach(item => {
      const id = item != null && item.id != null ? String(item.id) : "";
      const { row, error } = mapItemSafe(item, tourId);
      mappedById[id] = row;
      if (error) errorsById[id] = error;
    });
    return { items: rawItems, mappedById, errorsById };
  }

  /**
   * Build rows for TSV from { items, mappedById, errorsById }. Uses raw list (never filtered). Includes status; failed mappings get mappingError.
   */
  function buildRowsFromResult(result, productIdFallback) {
    const items = toArr(result && result.items);
    const mappedById = toObj(result && result.mappedById);
    const errorsById = toObj(result && result.errorsById);
    const rows = [];
    items.forEach(item => {
      if (toStr(item && item.status).toUpperCase() === "REMOVED") return;
      const id = item != null && item.id != null ? String(item.id) : "";
      const mapped = mappedById[id];
      if (mapped) {
        rows.push({ ...mapped, mappingError: "" });
      } else {
        rows.push({
          productId: toStr(productIdFallback),
          optionId: id,
          optionName: "",
          externalProductId: "",
          status: toStr(item && item.status),
          mappingError: toStr(errorsById[id])
        });
      }
    });
    return rows;
  }

  // Format data as TSV for Google Sheets (tab-separated values). Includes Status and optional Mapping error column.
  function formatAsTSV(data, includeHeaderRow = false) {
    if (!data || data.length === 0) {
      return '';
    }
    const hasErrors = data.some(row => row.mappingError);
    const tsvLines = [];
    if (includeHeaderRow) {
      const headers = ['Product ID', 'Option ID', 'Option name', 'External Product ID', 'Status'];
      if (hasErrors) headers.push('Mapping error');
      tsvLines.push(headers.join('\t'));
    }
    data.forEach(item => {
      const row = [
        escapeTsvField(item.productId),
        escapeTsvField(item.optionId),
        escapeTsvField(item.optionName),
        escapeTsvField(item.externalProductId),
        escapeTsvField(item.status)
      ];
      if (hasErrors) row.push(escapeTsvField(item.mappingError || ""));
      tsvLines.push(row.join('\t'));
    });
    return tsvLines.join('\n');
  }
  
  function escapeTsvField(field) {
    if (!field) return '';
    
    // Convert to string and trim
    const str = String(field).trim();
    
    // For TSV, replace tabs, newlines, and carriage returns with spaces
    return str.replace(/[\t\n\r]/g, ' ');
  }

  // Find all product rows on the products list page
  function findAllProductTourIds() {
    const productRows = document.querySelectorAll('[data-testid^="product-table-row-"]');
    const tourIds = [];
    
    productRows.forEach(row => {
      // Find the link to the product details page
      const link = row.querySelector('a[href*="/products/details?tour_id="]');
      if (link) {
        const href = link.getAttribute('href');
        const match = href.match(/tour_id=(\d+)/);
        if (match) {
          tourIds.push(match[1]);
        }
      }
    });
    
    console.log(`[getyourguide-products] Found ${tourIds.length} product tour IDs: ${tourIds.join(', ')}`);
    return tourIds;
  }

  // Check if next page button exists and is clickable (look in datatable paginator)
  function hasNextPage() {
    // Look for paginator within datatable paginator container
    const paginatorContainer = document.querySelector('.p-datatable-paginator-bottom');
    if (!paginatorContainer) {
      console.log("[getyourguide-products] No datatable paginator container found");
      return false;
    }
    
    // Alternative approach: check if there are more page numbers visible
    const pageButtons = paginatorContainer.querySelectorAll('.p-paginator-page');
    const selectedPageButton = paginatorContainer.querySelector('.p-paginator-page-selected');
    
    if (pageButtons.length > 0 && selectedPageButton) {
      const selectedPageNum = parseInt(selectedPageButton.textContent.trim());
      const maxPageNum = Math.max(...Array.from(pageButtons).map(btn => parseInt(btn.textContent.trim())));
      
      console.log(`[getyourguide-products] Current page: ${selectedPageNum}, Max visible page: ${maxPageNum}`);
      
      // If we're on the last visible page, check if next button exists and is not disabled
      if (selectedPageNum >= maxPageNum) {
        const nextButton = paginatorContainer.querySelector('.p-paginator-next');
        if (nextButton) {
          const isDisabled = nextButton.disabled || 
                           nextButton.hasAttribute('disabled') || 
                           nextButton.classList.contains('p-disabled');
          console.log(`[getyourguide-products] On last visible page, next button disabled: ${isDisabled}`);
          return !isDisabled;
        }
        return false;
      } else {
        // We're not on the last visible page, so there's definitely a next page
        console.log(`[getyourguide-products] Not on last visible page, next page available`);
        return true;
      }
    }
    
    // Fallback: check next button directly
    const nextButton = paginatorContainer.querySelector('.p-paginator-next');
    if (!nextButton) {
      console.log("[getyourguide-products] No next page button found in paginator");
      return false;
    }
    
    // Check if button is disabled - check multiple ways
    const hasDisabledAttr = nextButton.hasAttribute('disabled');
    const hasDisabledProp = nextButton.disabled === true;
    const hasDisabledClass = nextButton.classList.contains('p-disabled');
    
    const isDisabled = hasDisabledAttr || hasDisabledProp || hasDisabledClass;
    
    console.log(`[getyourguide-products] Next page button found:`);
    console.log(`  - hasAttribute('disabled'): ${hasDisabledAttr}`);
    console.log(`  - disabled property: ${hasDisabledProp}`);
    console.log(`  - has class 'p-disabled': ${hasDisabledClass}`);
    console.log(`  - Final isDisabled: ${isDisabled}, isClickable: ${!isDisabled}`);
    
    return !isDisabled;
  }

  // Click next page button
  function clickNextPage() {
    // Look for paginator within datatable paginator container
    const paginatorContainer = document.querySelector('.p-datatable-paginator-bottom');
    if (!paginatorContainer) {
      console.warn("[getyourguide-products] No datatable paginator container found");
      return false;
    }
    
    const nextButton = paginatorContainer.querySelector('.p-paginator-next');
    if (!nextButton) {
      console.warn("[getyourguide-products] No next page button found in paginator");
      return false;
    }
    
    console.log("[getyourguide-products] Clicking next page button...");
    nextButton.click();
    return true;
  }

  // Wait for page to load after clicking next
  function waitForPageLoad() {
    return new Promise((resolve) => {
      // Wait for the page to finish loading/updating
      setTimeout(() => {
        console.log("[getyourguide-products] Page load wait completed");
        resolve();
      }, 2000); // Wait 2 seconds for page transition
    });
  }

  // Scrape all products from the products list page with pagination support
  async function scrapeAllGetYourGuideProducts(includeHeaderRow = false) {
    const allResults = [];
    const seenOptionIds = new Set();
    let currentPage = 1;
    
    console.log("[getyourguide-products] Starting to scrape all products with pagination...");
    
    // Wait a bit for page to fully load before starting
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Loop through all pages
    while (true) {
      console.log(`[getyourguide-products] Processing page ${currentPage}...`);
      
      // Check for next page BEFORE scraping (button state might change after scraping)
      const hasNext = hasNextPage();
      console.log(`[getyourguide-products] Has next page: ${hasNext}`);
      
      // Find all product tour IDs on current page
      const tourIds = findAllProductTourIds();
      
      if (tourIds.length === 0) {
        if (currentPage === 1) {
          return { success: false, error: "No products found on this page. Make sure you're on a products list page." };
        }
        // No products on this page, but we've already processed at least one page
        console.log(`[getyourguide-products] No products found on page ${currentPage}, stopping`);
        break;
      }
      
      console.log(`[getyourguide-products] Found ${tourIds.length} products on page ${currentPage}`);
      
      // Scrape all products from current page
      try {
        const pageResults = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage({
            action: "scrapeAllGetYourGuideProducts",
            tourIds: tourIds,
            includeHeaderRow: false // Don't include headers for individual pages
          }, (response) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
              return;
            }
            
            if (response && response.success) {
              resolve(response.data || []);
            } else {
              resolve([]); // Return empty array if scraping failed, don't fail completely
            }
          });
        });
        
        // Filter out duplicates and add to results
        pageResults.forEach(item => {
          if (!seenOptionIds.has(item.optionId)) {
            seenOptionIds.add(item.optionId);
            allResults.push(item);
          }
        });
        
        console.log(`[getyourguide-products] Page ${currentPage} complete: ${pageResults.length} options extracted, ${allResults.length} total unique options so far`);
      } catch (error) {
        console.error(`[getyourguide-products] Error scraping page ${currentPage}:`, error);
        // Continue to next page even if this one failed
      }
      
      // Check again if there's a next page (after scraping)
      const hasNextAfterScrape = hasNextPage();
      console.log(`[getyourguide-products] Has next page after scrape: ${hasNextAfterScrape}`);
      
      if (hasNextAfterScrape) {
        console.log(`[getyourguide-products] Next page available, clicking...`);
        if (clickNextPage()) {
          await waitForPageLoad();
          currentPage++;
        } else {
          console.log(`[getyourguide-products] Failed to click next page, stopping`);
          break;
        }
      } else {
        console.log(`[getyourguide-products] No more pages available, stopping`);
        break;
      }
    }
    
    console.log(`[getyourguide-products] Successfully extracted ${allResults.length} total unique options from ${currentPage} page(s)`);
    
    if (allResults.length === 0) {
      return { success: false, error: "No product data could be extracted from any products." };
    }
    
    const tsvData = formatAsTSV(allResults, includeHeaderRow);
    
    return {
      success: true,
      data: allResults,
      tsvData: tsvData,
      count: allResults.length,
      pageCount: currentPage
    };
  }

  // Message handling for GetYourGuide Products actions
  function handleMessage(req, sender, sendResponse) {
    console.log("[getyourguide-products] Message received:", req);

    if (req.action === "runGetYourGuideProductsExtract") {
      // Handle async scraping with pagination
      scrapeGetYourGuideProducts()
        .then(data => {
          if (!data || data.length === 0) {
            sendResponse({ 
              success: false, 
              error: "No GetYourGuide products found on this page. Make sure you're on a product page with options." 
            });
            return;
          }
          
          const includeHeaderRow = req.includeHeaderRow || false;
          const tsvData = formatAsTSV(data, includeHeaderRow);
          
          sendResponse({ 
            success: true, 
            data: data,
            tsvData: tsvData,
            count: data.length
          });
        })
        .catch(error => {
          console.error("[getyourguide-products] Error during scraping:", error);
          sendResponse({ 
            success: false, 
            error: "An error occurred while scraping GetYourGuide products: " + error.message 
          });
        });
      
      return true; // Indicates we will send response asynchronously
    }

    if (req.action === "runGetYourGuideProductsExtractAll") {
      // Handle async scraping of all products
      scrapeAllGetYourGuideProducts(req.includeHeaderRow || false)
        .then(result => {
          sendResponse(result);
        })
        .catch(error => {
          console.error("[getyourguide-products] Error during all products scraping:", error);
          sendResponse({ 
            success: false, 
            error: "An error occurred while scraping all GetYourGuide products: " + error.message 
          });
        });
      
      return true; // Indicates we will send response asynchronously
    }

    if (req.action === "runGetYourGuideProductsExtractV2") {
      (async () => {
        try {
          const productId = getProductId();
          if (!productId) {
            sendResponse({ success: false, error: "Product ID not found. Make sure you're on a GetYourGuide product details page." });
            return;
          }
          const filters = buildGYGActivitySearchFilters(productId);
          let result = null;
          try {
            const bg = await new Promise(resolve => chrome.runtime.sendMessage({ type: "startFetchAllOptions", payload: { limit: 50, filters, productIdFallback: productId } }, resolve));
            if (bg && bg.ok && bg.results && Array.isArray(bg.results.items)) {
              result = { items: bg.results.items, mappedById: bg.results.mappedById || {}, errorsById: bg.results.errorsById || {} };
              console.log("[getyourguide-products] V2 extract via background:", result.items.length, "options");
            }
          } catch (_) {}
          if (!result || result.items.length === 0) {
            result = await fetchAllActivityOptions(productId, 50);
          }
          const rows = buildRowsFromResult(result, productId);
          if (rows.length === 0) {
            sendResponse({ success: false, error: "No options returned from API for this product." });
            return;
          }
          const includeHeaderRow = req.includeHeaderRow !== false;
          const tsvData = formatAsTSV(rows, includeHeaderRow);
          sendResponse({ success: true, data: rows, tsvData, count: rows.length });
        } catch (error) {
          console.error("[getyourguide-products] V2 extract error:", error);
          sendResponse({ success: false, error: "GetYourGuide API: " + (error.message || String(error)) });
        }
      })();
      return true;
    }

    if (req.action === "runGetYourGuideProductsExtractAllV2") {
      (async () => {
        try {
          const tourIds = findAllProductTourIds();
          if (!tourIds || tourIds.length === 0) {
            sendResponse({ success: false, error: "No products found on this page. Make sure you're on a GetYourGuide products list page." });
            return;
          }
          const itemsById = new Map();
          const mappedById = {};
          const errorsById = {};
          for (let i = 0; i < tourIds.length; i++) {
            const activityId = tourIds[i];
            const filters = buildGYGActivitySearchFilters(activityId);
            let res = null;
            try {
              const bg = await new Promise(resolve => chrome.runtime.sendMessage({ type: "startFetchAllOptions", payload: { limit: 50, filters, productIdFallback: activityId } }, resolve));
              if (bg && bg.ok && bg.results && Array.isArray(bg.results.items)) {
                res = { items: bg.results.items, mappedById: bg.results.mappedById || {}, errorsById: bg.results.errorsById || {} };
              }
            } catch (_) {}
            if (!res || res.items.length === 0) {
              res = await fetchAllActivityOptions(activityId, 50);
            }
            toArr(res.items).forEach(item => {
              const id = item != null && item.id != null ? String(item.id) : null;
              if (id != null && !itemsById.has(id)) itemsById.set(id, item);
            });
            Object.assign(mappedById, res.mappedById || {});
            Object.assign(errorsById, res.errorsById || {});
            if (i < tourIds.length - 1) {
              await new Promise(r => setTimeout(r, 400 + Math.random() * 200));
            }
          }
          const finalResult = { items: Array.from(itemsById.values()), mappedById, errorsById };
          const rows = buildRowsFromResult(finalResult);
          if (rows.length === 0) {
            sendResponse({ success: false, error: "No product data could be extracted from the API." });
            return;
          }
          const includeHeaderRow = req.includeHeaderRow !== false;
          const tsvData = formatAsTSV(rows, includeHeaderRow);
          sendResponse({ success: true, data: rows, tsvData, count: rows.length, productCount: tourIds.length });
        } catch (error) {
          console.error("[getyourguide-products] V2 extract all error:", error);
          sendResponse({ success: false, error: "GetYourGuide API: " + (error.message || String(error)) });
        }
      })();
      return true;
    }

    return false; // Not handled by this module
  }

  // Export the module
  window.GetYourGuideProducts = {
    handleMessage,
    scrapeGetYourGuideProducts,
    formatAsTSV,
    fetchAllGYGOptionsV2,
    fetchAllActivityOptions
  };

  console.log("[getyourguide-products] Module initialized successfully");

})(); // End of initialization function

