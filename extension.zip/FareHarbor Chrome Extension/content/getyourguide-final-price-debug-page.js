/**
 * Page-world script: Angular pricing scope inspection + pricing-related network capture.
 * Loaded via script src from the content script (MAIN world).
 */
(function initGetYourGuideFinalPriceDebugPage() {
  if (window.__fhGygFinalPriceDebugPageLoaded) return;
  window.__fhGygFinalPriceDebugPageLoaded = true;

  var LOG_PREFIX = "[getyourguide-final-price-debug]";
  var MSG_TYPE = "FH_GYG_FINAL_PRICE_DEBUG";
  var CMD_TYPE = "FH_GYG_FINAL_PRICE_DEBUG_CMD";
  var PRICING_URL_RE = /cost|preview|pricing|tax|total|gross/i;
  var KEYWORD_RE =
    /costPreview|cost_preview|final|total|gross|computed|taxes|ratesByType|offsetsByType|priceComponents|cost/i;
  var MAX_NETWORK_CAPTURES = 80;
  var MAX_KEYWORD_HITS = 60;

  var state = {
    networkCaptures: [],
    pricingForEditingResponses: [],
    rowOpenCaptures: [],
    inspectedRows: {}
  };

  window.__FH_GYG_FINAL_PRICE_DEBUG__ = state;

  function pageLog() {
    var args = [LOG_PREFIX].concat(Array.prototype.slice.call(arguments));
    console.log.apply(console, args);
  }

  function postToContent(event, payload) {
    try {
      window.postMessage(
        {
          source: "fh-gyg-final-price-debug-page",
          type: MSG_TYPE,
          event: event,
          payload: payload || null,
          timestamp: new Date().toISOString()
        },
        window.location.origin
      );
    } catch (e) {
      pageLog("postToContent failed", e && e.message);
    }
  }

  function safeSerialize(value, depth) {
    depth = depth || 0;
    if (depth > 6) return "[max-depth]";
    if (value === null || value === undefined) return value;
    var t = typeof value;
    if (t === "function") return "[function " + (value.name || "anonymous") + "]";
    if (t !== "object") return value;
    if (Array.isArray(value)) {
      return value.slice(0, 20).map(function (item) {
        return safeSerialize(item, depth + 1);
      });
    }
    var out = {};
    var keys = Object.keys(value);
    for (var i = 0; i < keys.length && i < 40; i++) {
      var key = keys[i];
      if (key.charAt(0) === "$" && key.charAt(1) === "$") continue;
      try {
        out[key] = safeSerialize(value[key], depth + 1);
      } catch (e) {
        out[key] = "[unserializable]";
      }
    }
    if (keys.length > 40) out["..."] = "[" + (keys.length - 40) + " more keys]";
    return out;
  }

  function isPricingPageUrl() {
    var href = window.location.href;
    var path = window.location.pathname || "";
    return (
      /\/total-sheets\/\d+\/pricing/i.test(path) ||
      /\/companies\/[^/]+\/total-sheets\/\d+\/pricing/i.test(path) ||
      /pricing-for-editing/i.test(href) ||
      /overlay=.*pricing/i.test(href)
    );
  }

  function isPricingPageDom() {
    return !!(
      document.querySelector('[data-test-id="edit-adult-pricing-button"]') ||
      document.querySelector('[data-test-id*="pricing-button"]') ||
      document.querySelector(".pricing-editor") ||
      document.querySelector("[ng-pricing-editor]")
    );
  }

  function isPricingContextActive() {
    return isPricingPageUrl() || isPricingPageDom();
  }

  function getScopeFromElement(el) {
    if (!window.angular || !el) return null;
    try {
      var ngEl = window.angular.element(el);
      return (
        (ngEl.scope && ngEl.scope()) ||
        (ngEl.isolatedScope && ngEl.isolatedScope()) ||
        null
      );
    } catch (e) {
      return null;
    }
  }

  function walkScopeChain(scope) {
    var chain = [];
    var current = scope;
    var depth = 0;
    while (current && depth < 30) {
      chain.push(current);
      current = current.$parent;
      depth += 1;
    }
    return chain;
  }

  function findOnScopeChain(scope, key) {
    var chain = walkScopeChain(scope);
    for (var i = 0; i < chain.length; i++) {
      var s = chain[i];
      if (Object.prototype.hasOwnProperty.call(s, key) && s[key] != null) {
        return { scope: s, value: s[key], path: "$scope." + key };
      }
    }
    return null;
  }

  function resolvePricingEditorCtrl(scope) {
    var names = ["pricingEditorCtrl", "pricingEditor", "costPreviewCtrl"];
    for (var i = 0; i < names.length; i++) {
      var hit = findOnScopeChain(scope, names[i]);
      if (hit) {
        return {
          controllerName: names[i],
          scope: hit.scope,
          ctrl: hit.value,
          path: hit.path
        };
      }
    }

    var chain = walkScopeChain(scope);
    for (var j = 0; j < chain.length; j++) {
      var s = chain[j];
      if (s.$ctrl && typeof s.$ctrl === "object") {
        if (s.$ctrl.effectivePricing || typeof s.$ctrl.costPreview === "function") {
          return {
            controllerName: "$ctrl",
            scope: s,
            ctrl: s.$ctrl,
            path: "$scope.$ctrl"
          };
        }
      }
    }
    return null;
  }

  function parseDisplayedPrice(text) {
    if (!text) return null;
    var m = String(text).match(/\$?\s*([\d,]+\.\d{2})/);
    return m ? parseFloat(m[1].replace(/,/g, "")) : null;
  }

  function findRowElement(buttonEl) {
    return (
      buttonEl.closest("tr") ||
      buttonEl.closest('[ng-repeat*="pricing"]') ||
      buttonEl.closest(".spreadsheet-row") ||
      buttonEl.parentElement
    );
  }

  function findFinalPriceInRow(rowEl) {
    if (!rowEl) return null;

    var table = rowEl.closest("table");
    if (table) {
      var headers = Array.prototype.slice.call(table.querySelectorAll("th"));
      var finalIdx = -1;
      for (var i = 0; i < headers.length; i++) {
        if (/final\s*price/i.test(headers[i].textContent || "")) {
          finalIdx = i;
          break;
        }
      }
      if (finalIdx >= 0) {
        var cells = rowEl.querySelectorAll("td");
        if (cells[finalIdx]) {
          return {
            value: parseDisplayedPrice(cells[finalIdx].textContent),
            rawText: (cells[finalIdx].textContent || "").trim(),
            path: "table row td[" + finalIdx + "] (Final Price column)"
          };
        }
      }
    }

    var selectors = [
      '[data-test-id*="final-price"]',
      ".final-price",
      "[ng-effective-price]",
      "span.the-price",
      ".price-cell .the-price",
      '[title="Final Price"]',
      '[title="Price"]'
    ];
    for (var s = 0; s < selectors.length; s++) {
      var el = rowEl.querySelector(selectors[s]);
      if (el) {
        return {
          value: parseDisplayedPrice(el.textContent),
          rawText: (el.textContent || "").trim(),
          path: selectors[s]
        };
      }
    }
    return null;
  }

  function extractBasePriceFromRow(effectivePricing) {
    if (!effectivePricing) return null;
    var price = effectivePricing.price || {};
    var offset = effectivePricing.price_offset != null
      ? effectivePricing.price_offset
      : effectivePricing.priceOffset != null
        ? effectivePricing.priceOffset
        : price.offset;
    var rate = effectivePricing.price_rate != null
      ? effectivePricing.price_rate
      : effectivePricing.priceRate != null
        ? effectivePricing.priceRate
        : price.rate;

    if (offset != null && Number(offset) !== 0) {
      return { value: Number(offset) / 100, source: "price_offset/100", raw: offset };
    }
    if (rate != null && Number(rate) !== 0) {
      return { value: Number(rate), source: "price_rate", raw: rate };
    }
    if (offset === 0) {
      return { value: 0, source: "price_offset=0", raw: 0 };
    }
    return null;
  }

  function findFinalPriceInObject(obj, path, hits, depth, seen) {
    if (!obj || depth > 5 || typeof obj !== "object") return;
    if (seen.has(obj)) return;
    seen.add(obj);

    if (Array.isArray(obj)) {
      for (var i = 0; i < obj.length && i < 30; i++) {
        findFinalPriceInObject(obj[i], path + "[" + i + "]", hits, depth + 1, seen);
      }
      return;
    }

    var keys = Object.keys(obj);
    for (var k = 0; k < keys.length; k++) {
      var key = keys[k];
      var val = obj[key];
      var childPath = path ? path + "." + key : key;

      if (typeof val === "number" && val > 1 && val < 100000) {
        if (/price|cost|total|gross|final|amount/i.test(key)) {
          hits.push({ path: childPath, key: key, value: val });
        }
      } else if (typeof val === "string" && /\d+\.\d{2}/.test(val)) {
        if (/price|cost|total|gross|final|amount/i.test(key)) {
          hits.push({ path: childPath, key: key, value: val });
        }
      }

      if (val && typeof val === "object" && depth < 4) {
        findFinalPriceInObject(val, childPath, hits, depth + 1, seen);
      }
    }
  }

  function tryCostPreview(ctrl, effectivePricing) {
    if (!ctrl) {
      return { called: false, error: "controller missing" };
    }
    if (typeof ctrl.costPreview !== "function") {
      return { called: false, error: "costPreview is not a function on controller" };
    }
    try {
      var result = ctrl.costPreview(effectivePricing);
      return { called: true, result: safeSerialize(result), rawResult: result };
    } catch (e) {
      return { called: true, error: e && e.message ? e.message : String(e) };
    }
  }

  function collectScopeKeywordHits(scope) {
    var hits = [];
    var seen = new WeakSet();

    function inspectObject(obj, basePath, depth) {
      if (!obj || depth > 4 || typeof obj !== "object") return;
      if (seen.has(obj)) return;
      seen.add(obj);

      var keys = Object.keys(obj);
      for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        if (key.indexOf("$") === 0) continue;
        var val = obj[key];
        if (KEYWORD_RE.test(key)) {
          hits.push({
            path: basePath + "." + key,
            key: key,
            value: safeSerialize(val)
          });
        }
        if (val && typeof val === "object" && hits.length < MAX_KEYWORD_HITS) {
          inspectObject(val, basePath + "." + key, depth + 1);
        }
      }
    }

    var chain = walkScopeChain(scope);
    for (var s = 0; s < chain.length; s++) {
      inspectObject(chain[s], "scope#" + (chain[s].$id || s), 0);
    }
    return hits.slice(0, MAX_KEYWORD_HITS);
  }

  function inspectPricingRow(buttonEl, options) {
    options = options || {};
    var testId = buttonEl.getAttribute("data-test-id") || options.testId || "unknown";
    var rowEl = findRowElement(buttonEl);
    var scope = getScopeFromElement(buttonEl);
    var ctrlHit = scope ? resolvePricingEditorCtrl(scope) : null;
    var ctrl = ctrlHit ? ctrlHit.ctrl : null;
    var effectivePricing = ctrl && ctrl.effectivePricing ? ctrl.effectivePricing : null;

    if (!effectivePricing && scope) {
      var epHit = findOnScopeChain(scope, "effectivePricing");
      if (epHit) effectivePricing = epHit.value;
    }

    var basePrice = extractBasePriceFromRow(effectivePricing);
    var finalDom = findFinalPriceInRow(rowEl);
    var costPreviewResult = tryCostPreview(ctrl, effectivePricing);
    var keywordHits = scope ? collectScopeKeywordHits(scope) : [];

    var candidateFinalPrices = [];
    if (costPreviewResult.called && costPreviewResult.rawResult) {
      findFinalPriceInObject(
        costPreviewResult.rawResult,
        "costPreview()",
        candidateFinalPrices,
        0,
        new WeakSet()
      );
    }
    if (effectivePricing) {
      findFinalPriceInObject(
        effectivePricing,
        "effectivePricing",
        candidateFinalPrices,
        0,
        new WeakSet()
      );
    }
    if (ctrl) {
      findFinalPriceInObject(ctrl, ctrlHit.path, candidateFinalPrices, 0, new WeakSet());
    }

    var report = {
      testId: testId,
      rowLabel: options.label || testId,
      controllerPath: ctrlHit ? ctrlHit.path : null,
      controllerName: ctrlHit ? ctrlHit.controllerName : null,
      basePrice: basePrice,
      finalUiPrice: finalDom,
      effectivePricing: safeSerialize(effectivePricing),
      costPreview: costPreviewResult.called
        ? {
            result: costPreviewResult.result,
            error: costPreviewResult.error || null
          }
        : { skipped: true, reason: costPreviewResult.error },
      keywordHits: keywordHits,
      candidateFinalPrices: candidateFinalPrices.slice(0, 25),
      scopeFound: !!scope
    };

    state.inspectedRows[testId] = report;
    pageLog("row inspection", report.rowLabel, report);
    postToContent("row-inspection", report);
    return report;
  }

  function inspectAllPricingRows() {
    var buttons = document.querySelectorAll('[data-test-id*="pricing-button"]');
    var reports = [];
    for (var i = 0; i < buttons.length; i++) {
      var btn = buttons[i];
      reports.push(
        inspectPricingRow(btn, {
          testId: btn.getAttribute("data-test-id"),
          label: btn.getAttribute("data-test-id")
        })
      );
    }
    return reports;
  }

  function matchEffectivePricingRowByName(rows, name) {
    if (!Array.isArray(rows)) return null;
    var target = String(name || "").toLowerCase();
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      var proto =
        row.customer_prototype ||
        row.customerPrototype ||
        row.for_object ||
        row.forObject ||
        {};
      var type = row.customer_type || row.customerType || {};
      var labels = [
        proto.display_name,
        proto.displayName,
        proto.name,
        type.singular,
        type.plural,
        type.name
      ];
      for (var j = 0; j < labels.length; j++) {
        if (labels[j] && String(labels[j]).toLowerCase().indexOf(target) !== -1) {
          return row;
        }
      }
    }
    return null;
  }

  function recordPricingForEditingResponse(url, bodyText) {
    var parsed;
    try {
      parsed = JSON.parse(bodyText);
    } catch (e) {
      pageLog("pricing-for-editing response parse failed", e && e.message);
      return;
    }

    var rows = parsed.effective_pricings || parsed.effectivePricings || [];
    var entry = {
      url: url,
      capturedAt: new Date().toISOString(),
      rowCount: rows.length,
      fullResponse: parsed,
      adultRow: matchEffectivePricingRowByName(rows, "adult"),
      allRows: rows
    };
    state.pricingForEditingResponses.push(entry);
    if (state.pricingForEditingResponses.length > 10) {
      state.pricingForEditingResponses.shift();
    }

    pageLog("pricing-for-editing captured", {
      url: url,
      rowCount: rows.length,
      adultRow: entry.adultRow ? safeSerialize(entry.adultRow) : null
    });
    postToContent("pricing-for-editing", {
      url: url,
      rowCount: rows.length,
      adultRow: entry.adultRow ? safeSerialize(entry.adultRow) : null,
      adultBasePrice: entry.adultRow ? extractBasePriceFromRow(entry.adultRow) : null
    });
  }

  function recordNetworkCapture(meta) {
    if (!meta || !meta.url) return;
    state.networkCaptures.push(meta);
    if (state.networkCaptures.length > MAX_NETWORK_CAPTURES) {
      state.networkCaptures.shift();
    }
    pageLog("network", meta.trigger || "passive", meta.method, meta.url, meta);
    postToContent("network", meta);
  }

  function shouldCaptureNetworkUrl(url) {
    return PRICING_URL_RE.test(url || "");
  }

  function captureResponseText(response, url, method, trigger) {
    if (!shouldCaptureNetworkUrl(url) && url.indexOf("pricing-for-editing") === -1) {
      return;
    }
    try {
      var clone = response.clone();
      clone.text().then(function (text) {
        var meta = {
          method: method,
          url: url,
          status: response.status,
          contentType: response.headers && response.headers.get
            ? response.headers.get("content-type")
            : null,
          bodySnippet: text.length > 20000 ? text.slice(0, 20000) + "…[truncated]" : text,
          bodyBytes: text.length,
          trigger: trigger || "passive",
          capturedAt: new Date().toISOString()
        };
        recordNetworkCapture(meta);
        if (url.indexOf("pricing-for-editing") !== -1) {
          recordPricingForEditingResponse(url, text);
        }
      }).catch(function (e) {
        pageLog("response text read failed", url, e && e.message);
      });
    } catch (e) {
      pageLog("response clone failed", url, e && e.message);
    }
  }

  function installNetworkHooks() {
    if (window.__fhGygFinalPriceDebugNetworkHooked) return;
    window.__fhGygFinalPriceDebugNetworkHooked = true;

    var origFetch = window.fetch;
    window.fetch = function (url, options) {
      options = options || {};
      var urlStr = "";
      try {
        urlStr = new URL(typeof url === "string" ? url : url.url || "", window.location.href).href;
      } catch (e) {
        urlStr = String(url || "");
      }
      var method = (options.method || "GET").toUpperCase();
      return origFetch.apply(this, arguments).then(function (response) {
        if (isPricingContextActive()) {
          captureResponseText(response, urlStr, method, "fetch");
        }
        return response;
      });
    };

    var origOpen = XMLHttpRequest.prototype.open;
    var origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (method, url) {
      this.__fhGygDebugMethod = method;
      this.__fhGygDebugUrl = url;
      return origOpen.apply(this, arguments);
    };
    XMLHttpRequest.prototype.send = function () {
      var xhr = this;
      if (isPricingContextActive()) {
        xhr.addEventListener("load", function () {
          var urlStr = "";
          try {
            urlStr = new URL(xhr.__fhGygDebugUrl || "", window.location.href).href;
          } catch (e) {
            urlStr = String(xhr.__fhGygDebugUrl || "");
          }
          if (!shouldCaptureNetworkUrl(urlStr) && urlStr.indexOf("pricing-for-editing") === -1) {
            return;
          }
          var text = xhr.responseText || "";
          var meta = {
            method: (xhr.__fhGygDebugMethod || "GET").toUpperCase(),
            url: urlStr,
            status: xhr.status,
            contentType: xhr.getResponseHeader && xhr.getResponseHeader("content-type"),
            bodySnippet: text.length > 20000 ? text.slice(0, 20000) + "…[truncated]" : text,
            bodyBytes: text.length,
            trigger: "xhr",
            capturedAt: new Date().toISOString()
          };
          recordNetworkCapture(meta);
          if (urlStr.indexOf("pricing-for-editing") !== -1) {
            recordPricingForEditingResponse(urlStr, text);
          }
        });
      }
      return origSend.apply(this, arguments);
    };

    pageLog("network hooks installed");
  }

  function onPricingButtonClick(event) {
    var btn = event.target && event.target.closest
      ? event.target.closest('[data-test-id*="pricing-button"]')
      : null;
    if (!btn) return;

    var testId = btn.getAttribute("data-test-id") || "unknown";
    pageLog("pricing row opened/edited", testId);
    state.rowOpenCaptures.push({
      testId: testId,
      openedAt: new Date().toISOString()
    });

    setTimeout(function () {
      inspectPricingRow(btn, { testId: testId, label: testId, trigger: "row-open" });
    }, 400);
    setTimeout(function () {
      inspectPricingRow(btn, { testId: testId, label: testId, trigger: "row-open-delayed" });
    }, 1200);
  }

  function buildReportAppendix() {
    var lines = [
      "",
      "## GetYourGuide Final Price Debug (temporary)",
      "",
      "**Page URL:** " + window.location.href,
      "**Generated:** " + new Date().toISOString(),
      ""
    ];

    var adultInspection =
      state.inspectedRows["edit-adult-pricing-button"] ||
      state.inspectedRows[Object.keys(state.inspectedRows)[0]] ||
      null;

    if (adultInspection) {
      lines.push("### Adult row scope inspection");
      lines.push("- **test-id:** " + adultInspection.testId);
      lines.push("- **controller path:** " + (adultInspection.controllerPath || "not found"));
      lines.push(
        "- **base price:** " +
          (adultInspection.basePrice
            ? adultInspection.basePrice.value + " (from " + adultInspection.basePrice.source + ")"
            : "not found")
      );
      lines.push(
        "- **final UI price:** " +
          (adultInspection.finalUiPrice
            ? adultInspection.finalUiPrice.value +
              " (DOM: " +
              adultInspection.finalUiPrice.path +
              ")"
            : "not found in DOM")
      );
      if (adultInspection.costPreview && !adultInspection.costPreview.skipped) {
        lines.push("- **costPreview result:**");
        lines.push("```json");
        lines.push(JSON.stringify(adultInspection.costPreview, null, 2));
        lines.push("```");
      }
      lines.push("");
    }

    if (state.pricingForEditingResponses.length > 0) {
      var latest = state.pricingForEditingResponses[state.pricingForEditingResponses.length - 1];
      lines.push("### pricing-for-editing (unredacted)");
      lines.push("- **URL:** " + latest.url);
      lines.push("- **effective_pricing rows:** " + latest.rowCount);
      if (latest.adultRow) {
        lines.push("- **Adult effective_pricing row (full):**");
        lines.push("```json");
        lines.push(JSON.stringify(latest.adultRow, null, 2));
        lines.push("```");
      } else {
        lines.push("- **Adult row:** not matched by name in effective_pricings");
      }
      lines.push("");
    }

    var pricingNetwork = state.networkCaptures.filter(function (c) {
      return shouldCaptureNetworkUrl(c.url);
    });
    if (pricingNetwork.length > 0) {
      lines.push("### Pricing-related network captures (" + pricingNetwork.length + ")");
      pricingNetwork.slice(-15).forEach(function (capture, index) {
        lines.push(
          "#### Capture " +
            (index + 1) +
            ": " +
            capture.method +
            " " +
            capture.url
        );
        lines.push("- **status:** " + capture.status);
        lines.push("- **trigger:** " + (capture.trigger || "passive"));
        if (capture.bodySnippet) {
          lines.push("```json");
          lines.push(capture.bodySnippet);
          lines.push("```");
        }
        lines.push("");
      });
    }

    return lines.join("\n");
  }

  function handleCommand(data) {
    if (!data || data.type !== CMD_TYPE) return;
    if (data.action === "inspect-all") {
      inspectAllPricingRows();
      return;
    }
    if (data.action === "inspect-row") {
      var selector = data.testId
        ? '[data-test-id="' + data.testId + '"]'
        : '[data-test-id="edit-adult-pricing-button"]';
      var btn = document.querySelector(selector);
      if (btn) {
        inspectPricingRow(btn, { testId: data.testId || "edit-adult-pricing-button" });
      } else {
        pageLog("inspect-row: button not found", selector);
      }
      return;
    }
    if (data.action === "get-report-appendix") {
      postToContent("report-appendix", { appendix: buildReportAppendix() });
    }
  }

  function start() {
    if (!isPricingContextActive()) {
      pageLog("waiting for pricing page context");
      return false;
    }

    installNetworkHooks();
    document.addEventListener("click", onPricingButtonClick, true);

    var runScan = function () {
      inspectAllPricingRows();
      var adultBtn = document.querySelector('[data-test-id="edit-adult-pricing-button"]');
      if (adultBtn) {
        inspectPricingRow(adultBtn, {
          testId: "edit-adult-pricing-button",
          label: "Adult"
        });
      }
    };

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", function () {
        setTimeout(runScan, 500);
      });
    } else {
      setTimeout(runScan, 500);
    }

    pageLog("started on pricing page", window.location.href);
    postToContent("started", { href: window.location.href });
    return true;
  }

  window.addEventListener("message", function (event) {
    if (event.source !== window || event.origin !== window.location.origin) return;
    handleCommand(event.data);
  });

  window.__FH_GYG_FINAL_PRICE_DEBUG_PAGE__ = {
    inspectPricingRow: inspectPricingRow,
    inspectAllPricingRows: inspectAllPricingRows,
    buildReportAppendix: buildReportAppendix,
    getState: function () {
      return state;
    }
  };

  if (!start()) {
    var attempts = 0;
    var timer = setInterval(function () {
      attempts += 1;
      if (start() || attempts > 120) {
        clearInterval(timer);
      }
    }, 500);
  }
})();
