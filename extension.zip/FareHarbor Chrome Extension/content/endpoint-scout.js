console.log("[endpoint-scout] endpoint-scout.js loaded");

(function initializeEndpointScout() {
  const ENABLE_ENDPOINT_SCOUT = true;
  const ENABLE_ENDPOINT_SCHEMA_CAPTURE = true;
  const ENABLE_ENDPOINT_SCHEMA_REFETCH = true;
  const ENABLE_ENDPOINT_SCOUT_REDACTION_DEBUG = false;
  const DEV_MODE_STORAGE_KEY = FareHarborDeveloperAuth.DEV_MODE_STORAGE_KEY;
  const REDACTION_MODE = "minimal"; // 'strict' | 'minimal'
  const MAX_SCHEMA_REFETCH_PER_REPORT = 10;
  const SCHEMA_REFETCH_TIMEOUT_MS = 5000;
  const ENDPOINT_SCOUT_MSG_TYPE = "FH_ENDPOINT_SCOUT";
  const ENDPOINT_SCOUT_MSG_SOURCE = "fh-endpoint-scout-v1";
  const ENDPOINT_SCOUT_SELF_TEST_SOURCE = "fareharbor-automator-endpoint-scout";
  const GATE_TIMEOUT_MS = 5000;
  const GATE_POLL_MS = 100;
  const SPA_URL_POLL_MS = 500;
  const MAX_EXAMPLE_URLS = 3;
  const MAX_JSON_PARSE_BYTES = 15 * 1024 * 1024;
  const MAX_SAMPLE_RESPONSE_SIZE = 250000;
  const MAX_SHAPE_DEPTH_STRICT = 2;
  const MAX_SHAPE_DEPTH_MINIMAL = 4;
  const MAX_SHAPE_KEYS = 50;
  const MAX_SAMPLE_ARRAY_ITEMS = 5;
  const MAX_SAMPLE_OBJECT_DEPTH = 6;
  const MAX_SAMPLE_KEYS = 60;
  const MAX_SAMPLE_BYTES = MAX_SAMPLE_RESPONSE_SIZE;
  const MAX_SCHEMA_EXAMPLES_PER_GROUP = 3;

  const PRIORITY_ENDPOINT_PATH_PATTERNS = [
    /\/bookings\//i,
    /customers-with-seats/i,
    /\/customers\//i,
    /\/contacts\//i,
    /customer-prototypes/i,
    /customer-type-rates/i,
    /availabilities\/[^/]+\/bookings/i,
    /resource.*requirements/i,
    /\/requirements\//i,
  ];

  const METHOD_PRIORITY = { POST: 0, PATCH: 1, PUT: 2, DELETE: 3, GET: 4 };

  // Keep in sync with endpoint-scout-page.js
  const ALWAYS_SENSITIVE_KEY_FRAGMENTS = [
    "token",
    "auth",
    "password",
    "secret",
    "cookie",
    "csrf",
    "email",
    "phone",
    "address",
    "payment",
    "card",
    "api_key",
    "credential",
  ];

  const CONFIG_SAFE_KEY_NAMES = new Set([
    "customer_prototypes",
    "customer_prototype",
    "customer_types",
    "customer_type",
    "customer_type_rates",
    "customer_type_prices",
    "customer_type_pricing",
    "customer_type_assignments",
    "reseller_customer_types",
    "reseller_customer_type",
    "reseller_customer_types_external_identifiers",
    "unmapped_reseller_customer_type_pks",
    "reseller_items",
    "reseller_item",
    "reseller_options",
    "reseller_option",
    "reseller_item_mappings",
    "reseller_company_mappings",
    "reseller_options_external_identifiers",
    "external_identifier",
  ]);

  const EXACT_SENSITIVE_KEYS = new Set([
    "customer",
    "customers",
    "guest",
    "guests",
    "contact",
    "contacts",
    "email",
    "phone",
    "address",
    "payment",
    "card",
    "token",
    "auth",
    "cookie",
    "csrf",
    "secret",
    "password",
    "api_key",
    "viator_api_key",
    "bookingcom_api_key",
    "supplier_secret",
    "credential",
  ]);

  const CONFIG_SAFE_ENDPOINT_TAGS = new Set([
    "PRICING",
    "RESOURCES",
    "CUSTOMER_TYPES",
    "ITEMS",
    "SETTINGS",
  ]);

  const CONFIG_SAFE_FIELD_NAMES = new Set(["name", "title", "label", "display_name"]);

  const MINIMAL_SAFE_KEY_NAMES = new Set([
    ...CONFIG_SAFE_KEY_NAMES,
    "booking",
    "bookings",
    "availability",
    "availabilities",
    "customer",
    "customers",
    "contact",
    "contacts",
    "guest",
    "guests",
    "item",
    "resource",
    "resources",
    "requirements",
    "customer_breakdown",
    "customer_breakdown_short",
    "customer_count",
    "customers_with_seat_assignments",
    "customers_with_seats",
    "pk",
    "id",
    "uuid",
    "uri",
    "name",
    "display_name",
    "customer_type",
    "customer_prototype",
    "customer_prototype_id",
    "customer_type_id",
  ]);

  const MINIMAL_EXACT_SENSITIVE_KEYS = new Set([
    "email",
    "phone",
    "address",
    "payment",
    "card",
    "token",
    "auth",
    "cookie",
    "csrf",
    "secret",
    "password",
    "api_key",
    "viator_api_key",
    "bookingcom_api_key",
    "supplier_secret",
    "credential",
    "card_brand",
    "last4",
    "expiry",
    "exp_month",
    "exp_year",
  ]);

  const MINIMAL_SENSITIVE_KEY_FRAGMENTS = [
    "token",
    "auth",
    "password",
    "secret",
    "cookie",
    "csrf",
    "payment",
    "card",
    "api_key",
    "credential",
  ];

  const ALWAYS_REDACT_VALUE_KEYS = new Set([
    "password",
    "secret",
    "token",
    "csrf",
    "cookie",
    "auth",
    "api_key",
    "viator_api_key",
    "bookingcom_api_key",
    "supplier_secret",
    "credential",
  ]);

  const EMAIL_VALUE_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const PHONE_VALUE_RE = /^[\d\s()+\-.]{7,}$/;

  const NOISE_ENDPOINT_PATTERNS = [
    /sentry/i,
    /favicon\.ico/i,
    /\/partials\//i,
    /\/realtime\//i,
    /feature_flag/i,
    /persistence/i,
    /opencx/i,
    /envelope/i,
    /telemetry/i,
    /analytics/i,
  ];

  const REFETCH_BLOCKED_PATH_PATTERNS = [
    /\/duplicate\//i,
    /\/delete\//i,
    /\/archive\//i,
    /\/restore\//i,
    /\/cancel\//i,
    /\/submit\//i,
    /\/send\//i,
    /\/email\//i,
    /\/charge\//i,
    /\/refund\//i,
    /\/payment\//i,
    /\/realtime\//i,
    /sentry/i,
    /feature_flag/i,
    /persistence/i,
    ...NOISE_ENDPOINT_PATTERNS,
  ];

  const IMPORTANT_ENDPOINT_PATTERNS = [
    /\/api\//i,
    /customer-prototypes/i,
    /total-sheets/i,
    /total-schedules/i,
    /pricing-for-editing/i,
    /cost[-_]?preview/i,
    /\/cost\//i,
    /\/preview\//i,
    /\/gross/i,
    /\/tax/i,
    /\/resources\//i,
    /availabilities/i,
    /\/bookings\//i,
    /custom-fields/i,
    /tax-types/i,
    /\/items\//i,
    /activities/i,
  ];

  const PRICING_PAGE_PATH_RE =
    /\/total-sheets\/\d+\/pricing|pricing-for-editing|overlay=.*pricing/i;

  const COMPANY_STATIC_SEGMENTS = new Set(["v1", "api"]);
  const UUID_SEGMENT_RE =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

  let scoutActive = false;
  let earlyPassiveActive = false;
  let gateFailed = false;
  let endpointGroups = new Map();
  let earlyObservationBuffer = [];
  let seenPerformanceEntries = new Set();
  let lastTrackedHref = location.href;
  let spaWatchersStarted = false;
  let pageInjected = false;
  let messageListenerAttached = false;
  let patchHealth = {
    fetchPatchActive: false,
    xhrPatchActive: false,
    schemaModeActive: false,
  };
  let schemaSelfTestReceived = false;
  let earlyPatchInstalledAt = null;
  let developerGateResolvedAt = null;
  let capturesBeforeGate = 0;
  let capturesAfterGate = 0;
  let earlyBufferedCapturesPromoted = 0;
  let schemaRefetchAttempted = 0;
  let schemaRefetchSucceeded = 0;
  let schemaRefetchFailed = 0;
  let schemaSampleRefetchAttempted = 0;
  let schemaSampleRefetchSucceeded = 0;
  let schemaSampleRefetchFailed = 0;
  let devModeEnabled = false;

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function canActivateEndpointScout() {
    return devModeEnabled;
  }

  async function refreshDevModeState(callback) {
    devModeEnabled = await FareHarborDeveloperAuth.isDevModeActiveAsync();
    if (callback) callback();
  }

  function tryActivateEndpointScout() {
    if (canActivateEndpointScout() && !scoutActive) {
      initEndpointScout();
    }
  }

  function isScoutEnabled() {
    return ENABLE_ENDPOINT_SCOUT && scoutActive;
  }

  function isPassiveCaptureActive() {
    return (
      ENABLE_ENDPOINT_SCOUT &&
      earlyPassiveActive &&
      !scoutActive &&
      !gateFailed &&
      isFareHarborHost()
    );
  }

  function canCaptureObservations() {
    return isScoutEnabled() || isPassiveCaptureActive();
  }

  function isSchemaCaptureEnabled() {
    return (
      ENABLE_ENDPOINT_SCOUT &&
      ENABLE_ENDPOINT_SCHEMA_CAPTURE &&
      canCaptureObservations()
    );
  }

  function isSchemaEnabledForPageInject() {
    return ENABLE_ENDPOINT_SCOUT && ENABLE_ENDPOINT_SCHEMA_CAPTURE;
  }

  function isSchemaRefetchEnabled() {
    return (
      ENABLE_ENDPOINT_SCOUT &&
      ENABLE_ENDPOINT_SCHEMA_CAPTURE &&
      ENABLE_ENDPOINT_SCHEMA_REFETCH &&
      isScoutEnabled()
    );
  }

  function schemaLog(...args) {
    console.log("[endpoint-scout][schema]", ...args);
  }

  function schemaDebugLog(...args) {
    if (!ENABLE_ENDPOINT_SCOUT_REDACTION_DEBUG) return;
    console.log("[endpoint-scout][schema-debug]", ...args);
  }

  function contentLog(...args) {
    console.log("[endpoint-scout][content]", ...args);
  }

  function contentSchemaLog(...args) {
    console.log("[endpoint-scout][content][schema]", ...args);
  }

  function redactionLog(keyPath, key) {
    if (!ENABLE_ENDPOINT_SCOUT_REDACTION_DEBUG) return;
    console.log("[endpoint-scout][redaction] redacted key", keyPath || key);
  }

  function childKeyPath(parentPath, key) {
    return parentPath ? `${parentPath}.${key}` : key;
  }

  function isMinimalRedactionMode() {
    return REDACTION_MODE === "minimal";
  }

  function getMaxShapeDepth() {
    return isMinimalRedactionMode() ? MAX_SHAPE_DEPTH_MINIMAL : MAX_SHAPE_DEPTH_STRICT;
  }

  function isMinimalAddressKey(lower) {
    return (
      lower === "street" ||
      lower === "billing_address" ||
      lower === "shipping_address" ||
      lower.startsWith("address_line")
    );
  }

  function isSensitiveKey(key, endpointTag = "UNKNOWN") {
    if (!key) return false;
    const lower = String(key).toLowerCase();

    if (isMinimalRedactionMode()) {
      if (MINIMAL_SAFE_KEY_NAMES.has(lower)) return false;
      if (MINIMAL_EXACT_SENSITIVE_KEYS.has(lower)) return true;
      if (isMinimalAddressKey(lower)) return true;
      if (MINIMAL_SENSITIVE_KEY_FRAGMENTS.some((fragment) => lower.includes(fragment))) {
        return true;
      }
      return false;
    }

    if (CONFIG_SAFE_KEY_NAMES.has(lower)) return false;
    if (CONFIG_SAFE_ENDPOINT_TAGS.has(endpointTag) && CONFIG_SAFE_FIELD_NAMES.has(lower)) {
      return false;
    }
    if (EXACT_SENSITIVE_KEYS.has(lower)) return true;
    if (ALWAYS_SENSITIVE_KEY_FRAGMENTS.some((fragment) => lower.includes(fragment))) {
      return true;
    }
    return false;
  }

  function isSensitiveValue(key, value) {
    if (!isMinimalRedactionMode() || typeof value !== "string") return false;
    const lower = String(key).toLowerCase();
    const trimmed = value.trim();
    if (!trimmed) return false;
    if (lower === "email" || lower.endsWith("_email")) return EMAIL_VALUE_RE.test(trimmed);
    if (lower === "phone" || lower.includes("phone")) return PHONE_VALUE_RE.test(trimmed);
    if (lower === "address" || isMinimalAddressKey(lower)) return trimmed.length > 0;
    return false;
  }

  function shouldRedactWholeValue(key) {
    if (!key) return false;
    return ALWAYS_REDACT_VALUE_KEYS.has(String(key).toLowerCase());
  }

  function shouldRedactField(key, value, endpointTag = "UNKNOWN") {
    if (shouldRedactWholeValue(key)) return true;
    if (isSensitiveKey(key, endpointTag)) {
      const t = typeof value;
      if (value === null || t === "string" || t === "number" || t === "boolean") return true;
      if (isMinimalRedactionMode() && (t === "object" || Array.isArray(value))) return false;
      return true;
    }
    return isSensitiveValue(key, value);
  }

  function firstArrayElement(arr) {
    if (!arr.length) return undefined;
    for (let i = 0; i < arr.length; i++) {
      const item = arr[i];
      if (item !== null && typeof item === "object" && !Array.isArray(item)) {
        return item;
      }
    }
    return arr[0];
  }

  function isPriorityEndpointContext(pathOrUrl) {
    const text = String(pathOrUrl || "").toLowerCase();
    return PRIORITY_ENDPOINT_PATH_PATTERNS.some((pattern) => pattern.test(text));
  }

  function getArraySampleLimit(endpointTag, keyPath, urlHint) {
    if (
      isPriorityEndpointContext(urlHint) ||
      isPriorityEndpointContext(keyPath) ||
      endpointTag === "BOOKINGS" ||
      endpointTag === "AVAILABILITY" ||
      endpointTag === "CUSTOMER_TYPES"
    ) {
      return MAX_SAMPLE_ARRAY_ITEMS;
    }
    return MAX_SAMPLE_ARRAY_ITEMS;
  }

  function arraySampleElements(arr, maxItems = MAX_SAMPLE_ARRAY_ITEMS) {
    const items = [];
    for (let i = 0; i < arr.length && items.length < maxItems; i++) {
      items.push(arr[i]);
    }
    return items;
  }

  function buildArrayShape(value, depth, endpointTag, keyPath, urlHint) {
    const limit = getArraySampleLimit(endpointTag, keyPath, urlHint);
    const samples = arraySampleElements(value, limit);
    const items = samples.map((item, index) =>
      buildShape(
        item,
        depth + 1,
        endpointTag,
        keyPath ? `${keyPath}.items[${index}]` : `items[${index}]`,
        urlHint
      )
    );
    const result = { __array__: true, length: value.length, items };
    if (value.length > samples.length) {
      result.__truncated__ = true;
      result.__original_length__ = value.length;
    }
    return result;
  }

  function buildArraySample(value, depth, endpointTag, keyPath, urlHint) {
    const limit = getArraySampleLimit(endpointTag, keyPath, urlHint);
    const samples = arraySampleElements(value, limit);
    const items = samples.map((item, index) =>
      buildSample(
        item,
        depth + 1,
        endpointTag,
        keyPath ? `${keyPath}[${index}]` : `[${index}]`,
        "",
        urlHint
      )
    );
    if (value.length > samples.length) {
      return {
        __truncated__: true,
        __original_length__: value.length,
        items,
      };
    }
    return items;
  }

  function primitiveType(value) {
    if (value === null) return "null";
    const t = typeof value;
    if (t === "string" || t === "number" || t === "boolean") return t;
    if (t === "undefined") return "undefined";
    return "unknown";
  }

  function redactedTypeLabel(value) {
    return `[REDACTED:${primitiveType(value)}]`;
  }

  function redactedSampleValue(value) {
    return `[REDACTED:${primitiveType(value)}]`;
  }

  function buildShape(value, depth = 0, endpointTag = "UNKNOWN", keyPath = "", urlHint = "") {
    if (value === null) return "null";
    const t = typeof value;
    if (t === "string" || t === "number" || t === "boolean") return t;
    if (t === "undefined") return "undefined";

    if (Array.isArray(value)) {
      return buildArrayShape(value, depth, endpointTag, keyPath, urlHint);
    }

    if (t === "object") {
      if (depth > getMaxShapeDepth()) return "object";
      const shape = {};
      const keys = Object.keys(value);
      const limit = Math.min(keys.length, MAX_SHAPE_KEYS);
      for (let i = 0; i < limit; i++) {
        const key = keys[i];
        const childPath = childKeyPath(keyPath, key);
        const childValue = value[key];
        if (shouldRedactField(key, childValue, endpointTag)) {
          redactionLog(childPath, key);
          shape[key] = redactedTypeLabel(childValue);
        } else {
          shape[key] = buildShape(childValue, depth + 1, endpointTag, childPath, urlHint);
        }
      }
      if (keys.length > limit) {
        shape.__truncated__ = true;
        shape.__original_key_count__ = keys.length;
      }
      return shape;
    }

    return "unknown";
  }

  function buildSample(
    value,
    depth = 0,
    endpointTag = "UNKNOWN",
    keyPath = "",
    key = "",
    urlHint = ""
  ) {
    if (!isMinimalRedactionMode()) return null;
    if (value === null) return null;
    const t = typeof value;
    if (t === "string" || t === "number" || t === "boolean") {
      if (shouldRedactField(key, value, endpointTag)) {
        redactionLog(keyPath, key);
        return redactedSampleValue(value);
      }
      return value;
    }
    if (t === "undefined") return undefined;

    if (Array.isArray(value)) {
      return buildArraySample(value, depth, endpointTag, keyPath, urlHint);
    }

    if (t === "object") {
      if (depth > MAX_SAMPLE_OBJECT_DEPTH) {
        return { __truncated__: true, __depth_limited__: true };
      }
      const sample = {};
      const keys = Object.keys(value);
      const limit = Math.min(keys.length, MAX_SAMPLE_KEYS);
      for (let i = 0; i < limit; i++) {
        const childKey = keys[i];
        const childPath = childKeyPath(keyPath, childKey);
        const childValue = value[childKey];
        if (shouldRedactField(childKey, childValue, endpointTag)) {
          redactionLog(childPath, childKey);
          sample[childKey] = redactedSampleValue(childValue);
        } else {
          sample[childKey] = buildSample(
            childValue,
            depth + 1,
            endpointTag,
            childPath,
            childKey,
            urlHint
          );
        }
      }
      if (keys.length > limit) {
        sample.__truncated__ = true;
        sample.__original_key_count__ = keys.length;
      }
      return sample;
    }

    return redactedSampleValue(value);
  }

  function truncateSampleForReport(sample) {
    if (sample == null) return sample;
    const serialized = JSON.stringify(sample);
    if (serialized.length <= MAX_SAMPLE_BYTES) return sample;
    return {
      _note: "truncated for report size",
      _originalBytes: serialized.length,
    };
  }

  function sampleFromParsedJson(parsed, endpointTag = "UNKNOWN", urlHint = "") {
    if (!isMinimalRedactionMode() || parsed == null) return null;
    const sample = buildSample(parsed, 0, endpointTag, "", "", urlHint);
    if (sample == null || (typeof sample === "object" && Object.keys(sample).length === 0)) {
      return null;
    }
    return sample;
  }

  function getEndpointTagFromUrl(urlString) {
    try {
      const path = new URL(urlString, location.origin).pathname.toLowerCase();
      return getEndpointTag(path);
    } catch {
      return "UNKNOWN";
    }
  }

  function parseJsonSafe(text) {
    let trimmed = text.trim();
    if (!trimmed) return null;
    if (trimmed.charAt(0) === "{" || trimmed.charAt(0) === "[") {
      return JSON.parse(trimmed);
    }
    const xssiMatch = trimmed.match(/^\)\]\}',?\s*([\s\S]*)$/);
    if (xssiMatch) {
      trimmed = xssiMatch[1].trim();
    }
    return JSON.parse(trimmed);
  }

  function shapeFromJsonText(text, logContext = null, endpointTag = "UNKNOWN") {
    const result = shapeFromJsonTextWithReason(text, endpointTag);
    if (logContext && result.shape) schemaLog("JSON parse success", logContext, result.shape);
    if (logContext && !result.shape) {
      schemaLog("JSON parse failure", logContext, result.reason);
    }
    return result.shape;
  }

  function shapeFromJsonTextWithReason(text, endpointTag = "UNKNOWN", urlHint = "") {
    if (!text || typeof text !== "string") {
      return {
        shape: null,
        sample: null,
        reason: "refetch-parse-failed",
        truncatedLargeResponse: false,
        responseBytes: 0,
      };
    }
    const responseBytes = text.length;
    const truncatedLargeResponse = responseBytes > MAX_SAMPLE_RESPONSE_SIZE;
    if (responseBytes > MAX_JSON_PARSE_BYTES) {
      return {
        shape: null,
        sample: null,
        reason: "refetch-body-too-large",
        truncatedLargeResponse: false,
        responseBytes,
      };
    }
    try {
      const trimmed = text.trim();
      if (!trimmed) {
        return {
          shape: null,
          sample: null,
          reason: "refetch-parse-failed",
          truncatedLargeResponse: false,
          responseBytes,
        };
      }
      const parsed = parseJsonSafe(text);
      const shape = buildShape(parsed, 0, endpointTag, "", urlHint);
      if (!shape || isEmptyShape(shape)) {
        return {
          shape: null,
          sample: null,
          reason: "refetch-parse-failed",
          truncatedLargeResponse: false,
          responseBytes,
        };
      }
      const sample = sampleFromParsedJson(parsed, endpointTag, urlHint);
      return { shape, sample, reason: null, truncatedLargeResponse, responseBytes };
    } catch {
      return {
        shape: null,
        sample: null,
        reason: "refetch-parse-failed",
        truncatedLargeResponse: false,
        responseBytes,
      };
    }
  }

  function isPlainObject(value) {
    if (!value || typeof value !== "object") return false;
    const proto = Object.getPrototypeOf(value);
    return proto === Object.prototype || proto === null;
  }

  function isJsonContentType(contentType) {
    return Boolean(contentType && String(contentType).toLowerCase().includes("json"));
  }

  function shapeFromRequestBody(body, requestContentType, endpointTag = "UNKNOWN") {
    if (body == null) return null;

    try {
      if (typeof body === "string") {
        if (isJsonContentType(requestContentType)) {
          return shapeFromJsonText(body, null, endpointTag);
        }
        try {
          return shapeFromJsonText(body, null, endpointTag);
        } catch {
          return null;
        }
      }

      if (typeof URLSearchParams !== "undefined" && body instanceof URLSearchParams) {
        const shape = {};
        body.forEach((_value, key) => {
          if (!key) return;
          shape[key] = isSensitiveKey(key, endpointTag) ? "[REDACTED:string]" : "string";
        });
        return Object.keys(shape).length ? shape : null;
      }

      if (typeof FormData !== "undefined" && body instanceof FormData) {
        const shape = {};
        body.forEach((_value, key) => {
          if (!key) return;
          shape[key] = isSensitiveKey(key, endpointTag)
            ? "[REDACTED:form-data-field]"
            : "form-data-field";
        });
        return Object.keys(shape).length ? shape : null;
      }

      if (isPlainObject(body)) {
        return buildShape(body, 0, endpointTag);
      }
    } catch {
      return null;
    }

    return null;
  }

  function isEmptyShape(shape) {
    if (shape == null) return true;
    if (typeof shape !== "object") return false;
    return Object.keys(shape).length === 0;
  }

  function mergeSchemaExample(list, shape, label, max = MAX_SCHEMA_EXAMPLES_PER_GROUP) {
    if (!isSchemaCaptureEnabled() || isEmptyShape(shape)) return false;
    const serialized = JSON.stringify(shape);
    if (list.some((existing) => JSON.stringify(existing) === serialized)) return false;
    if (list.length < max) {
      list.push(shape);
      schemaLog(`stored ${label} shape`, { count: list.length, shape });
      return true;
    }
    return false;
  }

  function isLiveCaptureSource(captureSource) {
    return captureSource === "fetch" || captureSource === "xhr";
  }

  function addUniqueSource(group, captureSource) {
    if (!captureSource) return;
    if (!group.sources.includes(captureSource)) {
      group.sources.push(captureSource);
    }
  }

  function addSchemaMissingReason(group, reason) {
    if (!reason) return;
    if (!group.schemaMissingReasons.includes(reason)) {
      group.schemaMissingReasons.push(reason);
    }
  }

  function finalizeGroupCaptureMetadata(group) {
    const liveSources = group.sources.filter(isLiveCaptureSource);
    if (
      group.sources.length > 0 &&
      liveSources.length === 0 &&
      !groupHasSchemaData(group)
    ) {
      addSchemaMissingReason(group, "performance-only");
    } else {
      group.schemaMissingReasons = group.schemaMissingReasons.filter(
        (reason) => reason !== "performance-only"
      );
    }
    group.schemaMissingReasons.sort();
  }

  function formatYesNo(value) {
    return value ? "yes" : "no";
  }

  function groupHasSchemaData(group) {
    return (
      (group.requestShapes && group.requestShapes.length > 0) ||
      (group.responseShapes && group.responseShapes.length > 0)
    );
  }

  function toIsoTimestamp(value, { isPerformanceEntry = false, entry = null } = {}) {
    if (isPerformanceEntry && entry != null && typeof performance.timeOrigin === "number") {
      return new Date(performance.timeOrigin + entry.startTime).toISOString();
    }
    if (typeof value === "string" && value.length > 0 && !Number.isNaN(Date.parse(value))) {
      return new Date(value).toISOString();
    }
    if (typeof value === "number" && value > 1e12) {
      return new Date(value).toISOString();
    }
    return new Date().toISOString();
  }

  function isIdSegment(segment) {
    if (!segment) return false;
    if (/^\d+$/.test(segment)) return true;
    return UUID_SEGMENT_RE.test(segment);
  }

  function normalizePathForReport(pathname) {
    if (!pathname) return "/";
    const segments = pathname.split("/");
    const normalized = [];

    for (let i = 0; i < segments.length; i++) {
      const segment = segments[i];
      if (!segment) {
        normalized.push(segment);
        continue;
      }

      const prev = segments[i - 1];
      if (prev === "companies") {
        if (
          !COMPANY_STATIC_SEGMENTS.has(segment.toLowerCase()) &&
          !isIdSegment(segment)
        ) {
          normalized.push("{company}");
          continue;
        }
      }

      if (isIdSegment(segment)) {
        normalized.push("{id}");
        continue;
      }

      normalized.push(segment);
    }

    return normalized.join("/");
  }

  function getEndpointTag(normalizedPath) {
    const path = (normalizedPath || "").toLowerCase();
    if (path.includes("customer-prototypes")) return "CUSTOMER_TYPES";
    if (
      path.includes("total-sheets") ||
      path.includes("total-schedules") ||
      path.includes("pricing-for-editing")
    ) {
      return "PRICING";
    }
    if (path.includes("/resources/")) return "RESOURCES";
    if (path.includes("availabilities")) return "AVAILABILITY";
    if (path.includes("/bookings/")) return "BOOKINGS";
    if (path.includes("custom-fields") || path.includes("tax-types")) return "SETTINGS";
    if (path.includes("/items/") || path.includes("activities")) return "ITEMS";
    return "UNKNOWN";
  }

  function getEndpointMatchText(group) {
    return [group.normalizedPath, ...(group.exampleUrls || [])].join(" ");
  }

  function isPricingPageContext() {
    if (PRICING_PAGE_PATH_RE.test(location.href)) return true;
    try {
      return Boolean(document.querySelector('[data-test-id*="pricing-button"]'));
    } catch {
      return false;
    }
  }

  const PRICING_PAGE_ENDPOINT_PATTERNS = [
    /cost/i,
    /preview/i,
    /pricing/i,
    /tax/i,
    /total/i,
    /gross/i,
  ];

  function categorizeEndpoint(group) {
    const text = getEndpointMatchText(group);
    if (NOISE_ENDPOINT_PATTERNS.some((pattern) => pattern.test(text))) {
      return "noise";
    }
    if (IMPORTANT_ENDPOINT_PATTERNS.some((pattern) => pattern.test(text))) {
      return "important";
    }
    if (
      isPricingPageContext() &&
      PRICING_PAGE_ENDPOINT_PATTERNS.some((pattern) => pattern.test(text))
    ) {
      return "important";
    }
    if (/\/api\//i.test(text)) {
      return "important";
    }
    return "noise";
  }

  function resetEndpointStore() {
    endpointGroups = new Map();
    seenPerformanceEntries = new Set();
    console.log("[endpoint-scout] store reset:", location.href);
  }

  function clearPassiveCaptureState() {
    earlyObservationBuffer = [];
    seenPerformanceEntries = new Set();
    schemaDebugLog("passive capture state cleared", location.href);
  }

  function onDeveloperGateFailed() {
    gateFailed = true;
    earlyPassiveActive = false;
    clearPassiveCaptureState();
    endpointGroups = new Map();
    schemaDebugLog("developer gate failed, capture disabled");
  }

  function bufferEarlyObservation(meta) {
    if (!isPassiveCaptureActive() || !meta) return;
    earlyObservationBuffer.push(meta);
    capturesBeforeGate += 1;
    schemaDebugLog("buffered early observation", meta.captureSource, meta.url || "");
  }

  function promoteEarlyBuffer() {
    const pending = earlyObservationBuffer.slice();
    earlyObservationBuffer = [];
    earlyBufferedCapturesPromoted = pending.length;
    for (const meta of pending) {
      recordObservation(meta, { isPromotion: true });
    }
    schemaDebugLog("early buffer promoted", earlyBufferedCapturesPromoted);
  }

  function onSpaNavigation() {
    if (!canCaptureObservations()) return;
    const href = location.href;
    if (href !== lastTrackedHref) {
      lastTrackedHref = href;
      if (scoutActive) {
        resetEndpointStore();
      } else {
        clearPassiveCaptureState();
      }
    }
  }

  function startSpaWatchers() {
    if (spaWatchersStarted) return;
    spaWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", onSpaNavigation);
    window.addEventListener("hashchange", onSpaNavigation);

    const origPushState = history.pushState;
    const origReplaceState = history.replaceState;

    history.pushState = function (...args) {
      const result = origPushState.apply(this, args);
      onSpaNavigation();
      return result;
    };

    history.replaceState = function (...args) {
      const result = origReplaceState.apply(this, args);
      onSpaNavigation();
      return result;
    };

    setInterval(() => {
      onSpaNavigation();
    }, SPA_URL_POLL_MS);
  }

  function shouldRecordUrl(urlString) {
    try {
      const url = new URL(urlString, location.origin);
      if (url.origin === location.origin) return true;
      return url.pathname.includes("/api/") || url.href.includes("/api/");
    } catch {
      return false;
    }
  }

  function getQueryParamNames(urlString) {
    try {
      const url = new URL(urlString, location.origin);
      const names = [];
      url.searchParams.forEach((_value, key) => {
        if (key && !names.includes(key)) names.push(key);
      });
      return names.sort();
    } catch {
      return [];
    }
  }

  function groupKey(method, normalizedPath, queryNames) {
    const queryPart = queryNames.length ? `?${queryNames.join(",")}` : "";
    return `${(method || "GET").toUpperCase()}|${normalizedPath}|${queryPart}`;
  }

  function recordObservation(meta, options = {}) {
    if (!meta) return;

    if (!scoutActive && isPassiveCaptureActive()) {
      bufferEarlyObservation(meta);
      return;
    }

    if (!isScoutEnabled()) return;

    if (!options.isPromotion) {
      capturesAfterGate += 1;
    }

    const captureSource =
      meta.captureSource || (meta._performanceEntry ? "performance" : null);
    const hasShape = Boolean(meta.requestShape || meta.responseShape);
    if (!meta.url) {
      if (hasShape) schemaDebugLog("grouping failed", "missing url");
      return;
    }
    if (!shouldRecordUrl(meta.url)) {
      if (hasShape) schemaDebugLog("grouping failed", "url filtered", meta.url);
      return;
    }

    let parsed;
    try {
      parsed = new URL(meta.url, location.origin);
    } catch {
      if (hasShape) schemaDebugLog("grouping failed", "invalid url", meta.url);
      return;
    }

    const method = (meta.method || "GET").toUpperCase();
    const normalizedPath = normalizePathForReport(parsed.pathname);
    const queryNames = getQueryParamNames(meta.url);
    const key = groupKey(method, normalizedPath, queryNames);
    const isoTimestamp = toIsoTimestamp(meta.timestamp, {
      isPerformanceEntry: Boolean(meta._performanceEntry),
      entry: meta._performanceEntry || null,
    });

    let group = endpointGroups.get(key);
    if (group && !group.responseSamples) {
      group.responseSamples = [];
    }
    if (!group) {
      group = {
        method,
        pathname: parsed.pathname,
        normalizedPath,
        queryNames,
        tag: getEndpointTag(normalizedPath),
        count: 0,
        exampleUrls: [],
        requestShapes: [],
        responseShapes: [],
        responseSamples: [],
        sources: [],
        liveCaptureCount: 0,
        performanceOnlyCount: 0,
        schemaCaptureCount: 0,
        schemaMissingReasons: [],
        responseSchemaSource: null,
        lastRequestContentType: null,
        lastStatus: null,
        lastContentType: null,
        lastTimestamp: null,
        pageUrl: location.href,
      };
      endpointGroups.set(key, group);
    }

    group.count += 1;
    group.lastStatus = meta.status != null ? meta.status : group.lastStatus;
    group.lastContentType = meta.contentType || group.lastContentType;
    group.lastTimestamp = isoTimestamp;
    group.pageUrl = location.href;
    group.tag = getEndpointTag(group.normalizedPath);

    if (captureSource) {
      addUniqueSource(group, captureSource);
      if (captureSource === "performance") {
        group.performanceOnlyCount += 1;
      } else if (isLiveCaptureSource(captureSource)) {
        group.liveCaptureCount += 1;
      }
    }

    let schemaStoredThisObservation = false;

    if (isSchemaCaptureEnabled() && captureSource !== "performance") {
      if (meta.requestContentType) {
        group.lastRequestContentType = meta.requestContentType;
      }
      if (meta.requestShape) {
        if (mergeSchemaExample(group.requestShapes, meta.requestShape, "request")) {
          schemaStoredThisObservation = true;
          schemaDebugLog("schema stored into endpoint group", key, "request", meta.url);
        }
      }
      if (meta.responseShape) {
        if (mergeSchemaExample(group.responseShapes, meta.responseShape, "response")) {
          schemaStoredThisObservation = true;
          schemaDebugLog("schema stored into endpoint group", key, "response", meta.url);
        }
      }
      if (meta.responseSample) {
        if (
          mergeSchemaExample(group.responseSamples, meta.responseSample, "response-sample")
        ) {
          schemaDebugLog("sample stored into endpoint group", key, "response", meta.url);
        }
      }
      if (meta.truncatedLargeResponse && (meta.responseShape || meta.responseSample)) {
        applyTruncatedLargeResponseMetadata(
          group,
          true,
          meta.responseBytes != null ? meta.responseBytes : null
        );
      }

      if (
        isLiveCaptureSource(captureSource) &&
        !schemaStoredThisObservation &&
        !hasShape &&
        meta.schemaMissingReason
      ) {
        addSchemaMissingReason(group, meta.schemaMissingReason);
        schemaDebugLog(
          "schema missing reason recorded",
          key,
          meta.schemaMissingReason,
          meta.url
        );
      }
    }

    if (schemaStoredThisObservation) {
      group.schemaCaptureCount += 1;
    }

    finalizeGroupCaptureMetadata(group);

    const fullUrl = parsed.href;
    if (!group.exampleUrls.includes(fullUrl)) {
      if (group.exampleUrls.length < MAX_EXAMPLE_URLS) {
        group.exampleUrls.push(fullUrl);
      }
    }
  }

  function isValidBridgeMessage(event) {
    if (event.source !== window) return false;
    if (event.origin !== window.location.origin) return false;
    const data = event.data;
    if (!data || typeof data !== "object") return false;
    if (data.type !== ENDPOINT_SCOUT_MSG_TYPE) return false;
    if (
      data.source !== ENDPOINT_SCOUT_MSG_SOURCE &&
      data.source !== ENDPOINT_SCOUT_SELF_TEST_SOURCE
    ) {
      return false;
    }
    return true;
  }

  function onBridgeMessage(event) {
    if (gateFailed || !isValidBridgeMessage(event)) return;
    if (!canCaptureObservations()) return;

    const data = event.data;
    const eventKind = data.eventKind || "observation";
    contentLog("message received", eventKind, data.url || "");

    if (eventKind === "patch-health") {
      patchHealth = {
        fetchPatchActive: data.fetchPatchActive === true,
        xhrPatchActive: data.xhrPatchActive === true,
        schemaModeActive: data.schemaModeActive === true,
      };
      schemaDebugLog("patch-health received", patchHealth);
      return;
    }

    if (eventKind === "schema-self-test") {
      schemaSelfTestReceived = true;
      schemaLog("self-test received");
      schemaDebugLog("schema self-test received");
      return;
    }

    try {
      if (scoutActive) {
        recordObservation(data);
      } else if (isPassiveCaptureActive()) {
        bufferEarlyObservation(data);
      }
    } catch (err) {
      console.warn("[endpoint-scout] failed to record observation:", err);
    }
  }

  function mergePerformanceEntries() {
    if (!isScoutEnabled()) return;
    try {
      const entries = performance.getEntriesByType("resource");
      for (const entry of entries) {
        if (!entry.name) continue;
        const perfKey = `${entry.initiatorType || ""}|${entry.name}`;
        if (seenPerformanceEntries.has(perfKey)) continue;
        seenPerformanceEntries.add(perfKey);
        const initiator = entry.initiatorType || "";
        if (
          initiator !== "fetch" &&
          initiator !== "xmlhttprequest" &&
          initiator !== "other"
        ) {
          continue;
        }
        recordObservation({
          captureSource: "performance",
          method: "GET",
          url: entry.name,
          status: null,
          contentType: entry.contentType || null,
          timestamp: toIsoTimestamp(null, { isPerformanceEntry: true, entry }),
          _performanceEntry: entry,
        });
      }
    } catch (err) {
      console.warn("[endpoint-scout] performance entries scan failed:", err);
    }
  }

  function injectPageNetworkCapture() {
    if (pageInjected || gateFailed) return true;

    const parent = document.documentElement || document.head || document.body;
    if (!parent) {
      return false;
    }

    const boot = document.createElement("script");
    boot.textContent = [
      `window.__FH_ENDPOINT_SCOUT_SCHEMA_ENABLED__ = ${isSchemaEnabledForPageInject() ? "true" : "false"};`,
      `window.__FH_ENDPOINT_SCOUT_REDACTION_MODE__ = ${JSON.stringify(REDACTION_MODE)};`,
    ].join("\n");

    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("content/endpoint-scout-page.js");
    script.onload = () => {
      script.remove();
      contentLog("page script loaded");
    };
    script.onerror = () => {
      console.warn("[endpoint-scout] page script load failed");
      pageInjected = false;
    };

    try {
      parent.appendChild(boot);
      boot.remove();
      parent.appendChild(script);
      pageInjected = true;
      if (!earlyPatchInstalledAt) {
        earlyPatchInstalledAt = new Date().toISOString();
      }
      schemaDebugLog("page script injection requested", earlyPatchInstalledAt);
      contentLog("page script injection requested");
      return true;
    } catch (err) {
      console.warn("[endpoint-scout] page inject failed:", err);
      pageInjected = false;
      return false;
    }
  }

  function scheduleEarlyPageInject() {
    if (pageInjected || gateFailed) return;
    if (injectPageNetworkCapture()) return;
    setTimeout(scheduleEarlyPageInject, 0);
  }

  function startEarlyPassiveCapture() {
    if (!ENABLE_ENDPOINT_SCOUT || !isFareHarborHost() || earlyPassiveActive) return;
    earlyPassiveActive = true;
    attachMessageListener();
    startSpaWatchers();
    scheduleEarlyPageInject();
    schemaDebugLog("early passive capture started", new Date().toISOString());
  }

  function attachMessageListener() {
    if (messageListenerAttached) return;
    messageListenerAttached = true;
    window.addEventListener("message", onBridgeMessage);
  }

  function getRefetchMatchText(group, url) {
    return [group.normalizedPath, url || "", ...(group.exampleUrls || [])].join(" ");
  }

  function isRefetchBlockedUrl(group, url) {
    const text = getRefetchMatchText(group, url);
    return REFETCH_BLOCKED_PATH_PATTERNS.some((pattern) => pattern.test(text));
  }

  function pickRefetchExampleUrl(group) {
    for (const url of group.exampleUrls || []) {
      try {
        const parsed = new URL(url, location.origin);
        if (parsed.origin === location.origin && !isRefetchBlockedUrl(group, parsed.href)) {
          return parsed.href;
        }
      } catch {
        continue;
      }
    }
    return null;
  }

  const SAMPLE_APPEND_ITEMS_PATH_RE = /\/api\/v1\/companies\/[^/]+\/items\/?$/i;

  function isItemsCollectionEndpointPath(pathname) {
    return SAMPLE_APPEND_ITEMS_PATH_RE.test(pathname || "");
  }

  function isSafeForSampledRefetchUrl(group, parsedUrl) {
    if (!group || group.method !== "GET") return false;
    if (!parsedUrl || parsedUrl.origin !== location.origin) return false;
    if (!parsedUrl.pathname.toLowerCase().includes("/api/")) return false;
    if (categorizeEndpoint(group) === "noise") return false;
    if (isRefetchBlockedUrl(group, parsedUrl.href)) return false;
    return true;
  }

  function shrinkUrlSearchParamsForSample(params) {
    let changed = false;
    if (params.has("page-size")) {
      params.set("page-size", "1");
      changed = true;
    }
    if (params.has("page_size")) {
      params.set("page_size", "1");
      changed = true;
    }
    if (params.has("limit")) {
      params.set("limit", "1");
      changed = true;
    }
    return changed;
  }

  function getSampleRefetchUrl(originalUrl, group) {
    let parsed;
    let normalizedOriginal;
    try {
      parsed = new URL(originalUrl, location.origin);
      normalizedOriginal = parsed.href;
    } catch {
      return null;
    }

    if (!isSafeForSampledRefetchUrl(group, parsed)) return null;

    const params = new URLSearchParams(parsed.searchParams);
    let changed = shrinkUrlSearchParamsForSample(params);

    if (!changed && isItemsCollectionEndpointPath(parsed.pathname)) {
      if (!params.has("page-size")) {
        params.set("page-size", "1");
        changed = true;
      }
      if (!params.has("page")) {
        params.set("page", "0");
        changed = true;
      }
    }

    if (!changed) return null;

    parsed.search = params.toString();
    const sampleUrl = parsed.href;
    return sampleUrl === normalizedOriginal ? null : sampleUrl;
  }

  function mapSampledRefetchFailureReason(reason) {
    if (reason === "refetch-body-too-large") return "refetch-sampled-body-too-large";
    if (reason === "refetch-non-json") return "refetch-sampled-non-json";
    if (reason === "refetch-parse-failed") return "refetch-sampled-parse-failed";
    return "refetch-sampled-failed";
  }

  function expectsJsonForRefetch(group) {
    if (isJsonContentType(group.lastContentType)) return true;
    return (group.normalizedPath || "").toLowerCase().includes("/api/");
  }

  function isEligibleForSchemaRefetch(group) {
    if (!group || group.method !== "GET") return false;
    if (group.responseShapes && group.responseShapes.length > 0) return false;
    if (
      group.responseSchemaSource === "refetch" ||
      group.responseSchemaSource === "refetch-sampled" ||
      group.responseSchemaSource === "truncated-large-response"
    ) {
      return false;
    }
    if (!group.exampleUrls || group.exampleUrls.length === 0) return false;
    if (categorizeEndpoint(group) === "noise") return false;
    if (!expectsJsonForRefetch(group)) return false;
    const url = pickRefetchExampleUrl(group);
    if (!url) return false;
    if (isRefetchBlockedUrl(group, url)) return false;
    return true;
  }

  function sortRefetchCandidates(groups) {
    return groups.slice().sort((a, b) => {
      const aApi = a.normalizedPath.toLowerCase().includes("/api/") ? 1 : 0;
      const bApi = b.normalizedPath.toLowerCase().includes("/api/") ? 1 : 0;
      if (bApi !== aApi) return bApi - aApi;
      if (b.count !== a.count) return b.count - a.count;
      return a.normalizedPath.localeCompare(b.normalizedPath);
    });
  }

  function applyTruncatedLargeResponseMetadata(group, truncatedLargeResponse, responseBytes) {
    if (!truncatedLargeResponse) return;
    group.responseSchemaSource = "truncated-large-response";
    if (responseBytes != null) group.responseOriginalBytes = responseBytes;
  }

  function applyRefetchSuccess(group, result) {
    addUniqueSource(group, "refetch");
    group.responseSchemaSource = result.truncatedLargeResponse
      ? "truncated-large-response"
      : "refetch";
    if (result.responseBytes != null) group.responseOriginalBytes = result.responseBytes;
    if (mergeSchemaExample(group.responseShapes, result.shape, "response")) {
      group.schemaCaptureCount += 1;
    }
    if (result.sample) {
      mergeSchemaExample(group.responseSamples, result.sample, "response-sample");
    }
    if (result.status != null) group.lastStatus = result.status;
    if (result.contentType) group.lastContentType = result.contentType;
    finalizeGroupCaptureMetadata(group);
    schemaDebugLog("refetch succeeded", group.normalizedPath, result.contentType);
  }

  function applyRefetchFailure(group, reason) {
    if (reason) addSchemaMissingReason(group, reason);
    schemaDebugLog("refetch failed", group.normalizedPath, reason);
  }

  function applyRefetchSampledSuccess(group, result) {
    addUniqueSource(group, "refetch-sampled");
    group.responseSchemaSource = result.truncatedLargeResponse
      ? "truncated-large-response"
      : "refetch-sampled";
    group.schemaSampleRefetchUrl = result.sampleUrl || null;
    if (result.responseBytes != null) group.responseOriginalBytes = result.responseBytes;
    if (mergeSchemaExample(group.responseShapes, result.shape, "response")) {
      group.schemaCaptureCount += 1;
    }
    if (result.sample) {
      mergeSchemaExample(group.responseSamples, result.sample, "response-sample");
    }
    if (result.status != null) group.lastStatus = result.status;
    if (result.contentType) group.lastContentType = result.contentType;
    group.schemaMissingReasons = (group.schemaMissingReasons || []).filter(
      (reason) => reason !== "refetch-body-too-large"
    );
    finalizeGroupCaptureMetadata(group);
    schemaDebugLog("refetch sampled succeeded", group.normalizedPath, result.sampleUrl);
  }

  function applyRefetchSampledFailure(group, normalReason, sampleReason) {
    if (normalReason) addSchemaMissingReason(group, normalReason);
    if (sampleReason) addSchemaMissingReason(group, sampleReason);
    schemaDebugLog("refetch sampled failed", group.normalizedPath, normalReason, sampleReason);
  }

  async function fetchSchemaShapeFromUrl(url) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), SCHEMA_REFETCH_TIMEOUT_MS);

    try {
      const res = await fetch(url, {
        method: "GET",
        credentials: "include",
        signal: controller.signal,
      });

      if (!res.ok) {
        return { ok: false, reason: "refetch-failed" };
      }

      const contentType = res.headers.get("content-type") || res.headers.get("Content-Type");
      if (!isJsonContentType(contentType)) {
        return { ok: false, reason: "refetch-non-json" };
      }

      const text = await res.text();
      const endpointTag = getEndpointTagFromUrl(url);
      const parsed = shapeFromJsonTextWithReason(text, endpointTag, url);
      if (!parsed.shape) {
        return { ok: false, reason: parsed.reason || "refetch-parse-failed" };
      }

      return {
        ok: true,
        shape: parsed.shape,
        sample: parsed.sample || null,
        truncatedLargeResponse: Boolean(parsed.truncatedLargeResponse),
        responseBytes: parsed.responseBytes || text.length,
        status: res.status,
        contentType,
      };
    } catch (err) {
      if (err && err.name === "AbortError") {
        return { ok: false, reason: "refetch-timeout" };
      }
      return { ok: false, reason: "refetch-failed" };
    } finally {
      clearTimeout(timeoutId);
    }
  }

  async function refetchSchemaForGroup(group) {
    const url = pickRefetchExampleUrl(group);
    if (!url) {
      return { ok: false, reason: "refetch-failed", sampleAttempted: false };
    }

    schemaDebugLog("refetch start", url);
    const normal = await fetchSchemaShapeFromUrl(url);
    if (normal.ok) {
      return { ok: true, sampled: false, sampleAttempted: false, ...normal };
    }

    if (normal.reason !== "refetch-body-too-large") {
      return {
        ok: false,
        sampled: false,
        sampleAttempted: false,
        reason: normal.reason || "refetch-failed",
      };
    }

    const sampleUrl = getSampleRefetchUrl(url, group);
    if (!sampleUrl) {
      return {
        ok: false,
        sampled: false,
        sampleAttempted: false,
        reason: "refetch-body-too-large",
      };
    }

    schemaDebugLog("refetch sampled start", sampleUrl);
    const sampled = await fetchSchemaShapeFromUrl(sampleUrl);
    if (sampled.ok) {
      return {
        ok: true,
        sampled: true,
        sampleAttempted: true,
        sampleUrl,
        ...sampled,
      };
    }

    return {
      ok: false,
      sampled: false,
      sampleAttempted: true,
      reason: mapSampledRefetchFailureReason(sampled.reason || "refetch-failed"),
      normalReason: "refetch-body-too-large",
      sampleReason: mapSampledRefetchFailureReason(sampled.reason || "refetch-failed"),
    };
  }

  async function enrichEndpointSchemasViaRefetch(groups) {
    schemaRefetchAttempted = 0;
    schemaRefetchSucceeded = 0;
    schemaRefetchFailed = 0;
    schemaSampleRefetchAttempted = 0;
    schemaSampleRefetchSucceeded = 0;
    schemaSampleRefetchFailed = 0;

    if (!isSchemaRefetchEnabled()) {
      schemaDebugLog("schema refetch skipped, not enabled");
      return;
    }

    const candidates = sortRefetchCandidates(groups.filter(isEligibleForSchemaRefetch)).slice(
      0,
      MAX_SCHEMA_REFETCH_PER_REPORT
    );

    schemaDebugLog("schema refetch candidates", candidates.length);

    for (const group of candidates) {
      const url = pickRefetchExampleUrl(group);
      if (!url) {
        continue;
      }

      schemaRefetchAttempted += 1;
      const result = await refetchSchemaForGroup(group);

      if (result.ok && !result.sampled) {
        applyRefetchSuccess(group, result);
        schemaRefetchSucceeded += 1;
        continue;
      }

      if (result.ok && result.sampled) {
        schemaRefetchFailed += 1;
        schemaSampleRefetchAttempted += 1;
        schemaSampleRefetchSucceeded += 1;
        applyRefetchSampledSuccess(group, result);
        continue;
      }

      schemaRefetchFailed += 1;

      if (result.sampleAttempted) {
        schemaSampleRefetchAttempted += 1;
        schemaSampleRefetchFailed += 1;
        applyRefetchSampledFailure(group, result.normalReason, result.sampleReason || result.reason);
      } else {
        applyRefetchFailure(group, result.reason);
      }
    }

    schemaDebugLog("schema refetch complete", {
      attempted: schemaRefetchAttempted,
      succeeded: schemaRefetchSucceeded,
      failed: schemaRefetchFailed,
      sampleAttempted: schemaSampleRefetchAttempted,
      sampleSucceeded: schemaSampleRefetchSucceeded,
      sampleFailed: schemaSampleRefetchFailed,
    });
  }

  function getMethodPriority(method) {
    return METHOD_PRIORITY[method] ?? 5;
  }

  function sortEndpointGroups(groups) {
    return groups.sort((a, b) => {
      const aHasSchema = groupHasSchemaData(a) ? 1 : 0;
      const bHasSchema = groupHasSchemaData(b) ? 1 : 0;
      if (bHasSchema !== aHasSchema) return bHasSchema - aHasSchema;

      const liveDiff = (b.liveCaptureCount || 0) - (a.liveCaptureCount || 0);
      if (liveDiff !== 0) return liveDiff;

      const methodDiff = getMethodPriority(a.method) - getMethodPriority(b.method);
      if (methodDiff !== 0) return methodDiff;
      if (b.count !== a.count) return b.count - a.count;
      const pathCmp = a.normalizedPath.localeCompare(b.normalizedPath);
      if (pathCmp !== 0) return pathCmp;
      return a.method.localeCompare(b.method);
    });
  }

  function formatGroupHeading(group) {
    const queryPart =
      group.queryNames.length > 0 ? `?${group.queryNames.join(",")}` : "";
    const tagPrefix =
      group.tag && group.tag !== "UNKNOWN" ? `[${group.tag}] ` : "";
    return `### ${tagPrefix}${group.method} ${group.normalizedPath}${queryPart}`;
  }

  function appendSchemaSections(lines, group) {
    if (group.requestShapes && group.requestShapes.length > 0) {
      group.requestShapes.forEach((shape, index) => {
        const label =
          group.requestShapes.length > 1 ? ` (Example ${index + 1})` : "";
        lines.push(`**Request shape${label}:**`);
        lines.push("```json");
        lines.push(JSON.stringify(shape, null, 2));
        lines.push("```");
        lines.push("");
      });
    }

    if (group.responseShapes && group.responseShapes.length > 0) {
      group.responseShapes.forEach((shape, index) => {
        const label =
          group.responseShapes.length > 1 ? ` (Example ${index + 1})` : "";
        lines.push(`**Response shape${label}:**`);
        lines.push("```json");
        lines.push(JSON.stringify(shape, null, 2));
        lines.push("```");
        lines.push("");
      });
    }

    if (
      isMinimalRedactionMode() &&
      group.responseSamples &&
      group.responseSamples.length > 0
    ) {
      group.responseSamples.forEach((sample, index) => {
        const label =
          group.responseSamples.length > 1 ? ` (Example ${index + 1})` : "";
        lines.push(`**Sample response${label}:**`);
        lines.push("```json");
        lines.push(JSON.stringify(truncateSampleForReport(sample), null, 2));
        lines.push("```");
        lines.push("");
      });
    }
  }

  function formatSourcesList(group) {
    const order = ["fetch", "xhr", "performance", "refetch", "refetch-sampled"];
    const sources = group.sources || [];
    const sorted = order.filter((s) => sources.includes(s));
    return sorted.length ? sorted.join(", ") : "unknown";
  }

  function formatSchemaMissingLine(group) {
    const reasons = [...(group.schemaMissingReasons || [])].sort();
    return reasons.length ? reasons.join(" / ") : "unknown";
  }

  function appendGroupLines(lines, group) {
    lines.push(formatGroupHeading(group));
    lines.push(`- **Count:** ${group.count}`);
    lines.push(`- **Sources:** ${formatSourcesList(group)}`);
    lines.push(`- **Live captures:** ${group.liveCaptureCount || 0}`);
    lines.push(`- **Schema captures:** ${group.schemaCaptureCount || 0}`);
    if (
      group.responseSchemaSource === "refetch" &&
      group.responseShapes &&
      group.responseShapes.length > 0
    ) {
      lines.push("- **Schema source:** refetch");
    }
    if (
      group.responseSchemaSource === "refetch-sampled" &&
      group.responseShapes &&
      group.responseShapes.length > 0
    ) {
      lines.push("- **Schema source:** refetch-sampled");
      if (group.schemaSampleRefetchUrl) {
        lines.push(`- **Sample URL:** ${group.schemaSampleRefetchUrl}`);
      }
    }
    if (
      group.responseSchemaSource === "truncated-large-response" &&
      group.responseShapes &&
      group.responseShapes.length > 0
    ) {
      lines.push("- **Schema source:** truncated-large-response");
      if (group.responseOriginalBytes != null) {
        lines.push(`- **Original response bytes:** ${group.responseOriginalBytes}`);
      }
    }
    if (!groupHasSchemaData(group)) {
      lines.push(`- **Schema missing:** ${formatSchemaMissingLine(group)}`);
    }
    if (group.lastStatus != null) {
      lines.push(`- **Last status:** ${group.lastStatus}`);
    }
    if (group.lastContentType) {
      lines.push(`- **Last content-type:** ${group.lastContentType}`);
    }
    if (group.lastRequestContentType) {
      lines.push(`- **Request content-type:** ${group.lastRequestContentType}`);
    }
    if (group.lastTimestamp) {
      lines.push(`- **Last seen:** ${group.lastTimestamp}`);
    }
    if (group.exampleUrls.length) {
      lines.push("- **Example URLs:**");
      for (const url of group.exampleUrls) {
        lines.push(`  - ${url}`);
      }
    }
    appendSchemaSections(lines, group);
    if (!groupHasSchemaData(group)) {
      lines.push("");
    }
  }

  async function buildReport(options = {}) {
    const devModeActive = await FareHarborDeveloperAuth.isDevModeActiveAsync();
    if (!devModeActive) {
      FareHarborDeveloperAuth.logUnavailable('endpoint report blocked: DEV mode is not available');
      throw new Error('Endpoint report requires authorized DEV mode');
    }

    const includeNoise = options.includeNoise === true;
    const enrichSchemas = options.enrichSchemas !== false;
    mergePerformanceEntries();

    const allGroups = Array.from(endpointGroups.values());
    let importantGroups = sortEndpointGroups(
      allGroups.filter((group) => categorizeEndpoint(group) === "important")
    );
    const noiseGroups = sortEndpointGroups(
      allGroups.filter((group) => categorizeEndpoint(group) === "noise")
    );

    if (enrichSchemas && isSchemaRefetchEnabled()) {
      await enrichEndpointSchemasViaRefetch(importantGroups);
      importantGroups = sortEndpointGroups(importantGroups);
    }

    const importantWithSchema = importantGroups.filter(groupHasSchemaData).length;

    const onPricingPage = isPricingPageContext();

    const lines = [
      "# FareHarbor Endpoint Scout Report",
      "",
      `**Page URL:** ${location.href}`,
      `**Generated:** ${new Date().toISOString()}`,
      `**DEV mode:** ${devModeEnabled ? "enabled" : "disabled"}`,
      `**Pricing page context:** ${onPricingPage ? "yes (cost/preview/tax/total/gross URLs prioritized)" : "no"}`,
      "",
      "## Summary",
      `- **Redaction mode:** ${REDACTION_MODE}`,
      `- **Total endpoint groups:** ${allGroups.length}`,
      `- **Important endpoint groups:** ${importantGroups.length}`,
      `- **Endpoint groups with schema data:** ${importantWithSchema}`,
      `- **Hidden noise endpoint groups:** ${noiseGroups.length}${includeNoise ? "" : " (use includeNoise=true to show)"}`,
      `- **Early patch installed:** ${formatYesNo(Boolean(earlyPatchInstalledAt))}`,
      `- **Patch installed at:** ${earlyPatchInstalledAt || "n/a"}`,
      `- **DEV mode gate resolved at:** ${developerGateResolvedAt || "n/a"}`,
      `- **Captures before gate:** ${capturesBeforeGate}`,
      `- **Captures after gate:** ${capturesAfterGate}`,
      `- **Early buffered captures promoted:** ${earlyBufferedCapturesPromoted}`,
      `- **Fetch patch active:** ${formatYesNo(patchHealth.fetchPatchActive)}`,
      `- **XHR patch active:** ${formatYesNo(patchHealth.xhrPatchActive)}`,
      `- **Schema mode active:** ${formatYesNo(isSchemaCaptureEnabled() && patchHealth.schemaModeActive)}`,
      `- **Page script injected:** ${formatYesNo(pageInjected)}`,
      `- **Schema self-test received:** ${formatYesNo(schemaSelfTestReceived)}`,
      `- **Schema refetch active:** ${formatYesNo(isSchemaRefetchEnabled())}`,
      `- **Schema refetch attempted:** ${schemaRefetchAttempted}`,
      `- **Schema refetch succeeded:** ${schemaRefetchSucceeded}`,
      `- **Schema refetch failed:** ${schemaRefetchFailed}`,
      `- **Schema sampled refetch attempted:** ${schemaSampleRefetchAttempted}`,
      `- **Schema sampled refetch succeeded:** ${schemaSampleRefetchSucceeded}`,
      `- **Schema sampled refetch failed:** ${schemaSampleRefetchFailed}`,
      "",
    ];

    if (!includeNoise && noiseGroups.length > 0) {
      lines.push(
        `_${noiseGroups.length} noise endpoint group(s) hidden._`,
        ""
      );
    }

    if (allGroups.length === 0) {
      lines.push(
        "_No endpoints captured on this page yet. Interact with the dashboard and try again._"
      );
      return lines.join("\n");
    }

    lines.push("## Important Endpoints", "");
    if (importantGroups.length === 0) {
      lines.push("_No important endpoints captured yet._", "");
    } else {
      for (const group of importantGroups) {
        appendGroupLines(lines, group);
      }
    }

    if (includeNoise) {
      lines.push("## Noise Endpoints", "");
      lines.push(
        "_These endpoints are hidden by default because they are usually infrastructure noise._",
        ""
      );
      if (noiseGroups.length === 0) {
        lines.push("_No noise endpoints captured._", "");
      } else {
        for (const group of noiseGroups) {
          appendGroupLines(lines, group);
        }
      }
    }

    return lines.join("\n");
  }

  function initEndpointScout() {
    if (scoutActive) return;
    scoutActive = true;
    developerGateResolvedAt = new Date().toISOString();
    attachMessageListener();
    if (!pageInjected) {
      scheduleEarlyPageInject();
    }
    promoteEarlyBuffer();
    mergePerformanceEntries();
    if (!spaWatchersStarted) {
      startSpaWatchers();
    }
    console.log("[endpoint-scout] initialized (DEV mode active)");
    schemaDebugLog("developer gate passed", developerGateResolvedAt);

    function testShapeExtraction() {
      const sample = {
        name: "Adult",
        minimumPartySize: 1,
        maximumPartySize: 1,
        nested: { id: 99, label: "x" },
        total_sheets: [
          { pk: 123, name: "Viator", archived: false },
          { pk: 456, name: "GYG", archived: true },
        ],
        customer_prototypes: [
          {
            pk: 123,
            name: "Adult",
            minimum_party_size: null,
            maximum_party_size: null,
            is_inactive: false,
          },
        ],
      };
      const shape = buildShape(sample, 0, "PRICING");
      schemaLog("testShapeExtraction result", shape);
      return shape;
    }

    function testRedactionRules() {
      const customerExpectSensitive = REDACTION_MODE === "strict";
      const cases = [
        { key: "customer_prototypes", expectSensitive: false },
        { key: "customer_types", expectSensitive: false },
        { key: "reseller_customer_types", expectSensitive: false },
        { key: "email", expectSensitive: true },
        { key: "phone", expectSensitive: true },
        { key: "payment", expectSensitive: true },
        { key: "viator_api_key", expectSensitive: true },
        { key: "customer", expectSensitive: customerExpectSensitive },
      ];
      const results = cases.map(({ key, expectSensitive }) => {
        const sensitive = isSensitiveKey(key);
        const pass = sensitive === expectSensitive;
        return { key, expectSensitive, sensitive, pass };
      });
      const keyTestsOk = results.every((r) => r.pass);

      const prototypeSample = {
        customer_prototypes: [
          {
            pk: 123,
            name: "Adult",
            minimum_party_size: null,
            maximum_party_size: null,
            is_inactive: false,
          },
        ],
      };
      const protoShape = buildShape(prototypeSample, 0, "CUSTOMER_TYPES").customer_prototypes;
      const prototypesAllowed =
        protoShape &&
        typeof protoShape === "object" &&
        protoShape.__array__ === true &&
        !JSON.stringify(protoShape).includes("REDACTED");

      const contactSample = {
        contact: { pk: 99, name: "Jane", email: "jane@example.com" },
      };
      const contactShape = buildShape(contactSample, 0, "BOOKINGS").contact;
      const contactAllowed =
        REDACTION_MODE === "strict"
          ? JSON.stringify(contactShape).includes("REDACTED")
          : contactShape &&
            contactShape.pk === "number" &&
            contactShape.email === "[REDACTED:string]";

      const bookingSample = {
        customers: [{ pk: 1, customer_type: 3, customer_prototype: 12 }],
      };
      const customersShape = buildShape(bookingSample, 0, "BOOKINGS").customers;
      const customersAllowed =
        REDACTION_MODE === "strict"
          ? JSON.stringify(customersShape).includes("REDACTED")
          : customersShape &&
            customersShape.__array__ === true &&
            !JSON.stringify(customersShape).includes("REDACTED:unknown");

      const ok = keyTestsOk && prototypesAllowed && contactAllowed && customersAllowed;
      schemaLog("testRedactionRules", {
        ok,
        mode: REDACTION_MODE,
        results,
        prototypesAllowed,
        contactAllowed,
        customersAllowed,
      });
      return {
        ok,
        mode: REDACTION_MODE,
        results,
        prototypesAllowed,
        contactAllowed,
        customersAllowed,
      };
    }

    function testSampleRedaction() {
      const sample = {
        pk: 48291,
        customer_type: 3,
        customer_prototype: 12,
        contact: { name: "Jane", email: "jane@example.com", phone: "555-123-4567" },
      };
      const result = buildSample(sample, 0, "BOOKINGS", "", "", "");
      const ok =
        result &&
        result.pk === 48291 &&
        result.customer_type === 3 &&
        result.customer_prototype === 12 &&
        result.contact &&
        result.contact.name === "Jane" &&
        String(result.contact.email).includes("REDACTED") &&
        String(result.contact.phone).includes("REDACTED");
      schemaLog("testSampleRedaction", { ok, result });
      return { ok, result };
    }

    function testLargeResponseSampling() {
      const bookings = [];
      for (let i = 0; i < 47; i++) {
        bookings.push({
          pk: 1000 + i,
          customer_type: 3,
          customer_prototype: 12 + (i % 3),
          contact: { name: `Guest ${i}`, email: `guest${i}@example.com` },
        });
      }
      const payload = { bookings };
      const url = "/api/v1/companies/foo/items/1/availabilities/2/bookings/";
      const shape = buildShape(payload, 0, "BOOKINGS", "", url);
      const sample = buildSample(payload, 0, "BOOKINGS", "", "", url);
      const bookingsShape = shape.bookings;
      const shapeOk =
        bookingsShape &&
        bookingsShape.__array__ === true &&
        bookingsShape.__truncated__ === true &&
        bookingsShape.__original_length__ === 47 &&
        bookingsShape.items &&
        bookingsShape.items.length === MAX_SAMPLE_ARRAY_ITEMS;

      const sampleBookings = sample.bookings;
      const sampleOk =
        sampleBookings &&
        sampleBookings.__truncated__ === true &&
        sampleBookings.__original_length__ === 47 &&
        sampleBookings.items &&
        sampleBookings.items.length === MAX_SAMPLE_ARRAY_ITEMS &&
        sampleBookings.items[0].pk === 1000 &&
        sampleBookings.items[0].customer_prototype != null &&
        !JSON.stringify(sampleBookings).includes("[TRUNCATED:array]");

      const largeBookings = [];
      for (let i = 0; i < 5000; i++) {
        largeBookings.push({
          pk: i,
          customer_type: 3,
          customer_prototype: 12,
          note: `booking-record-${i}-with-extra-padding-for-size`,
        });
      }
      const largeText = JSON.stringify({ bookings: largeBookings });
      const parsed = shapeFromJsonTextWithReason(largeText, "BOOKINGS", url);
      const parseOk =
        parsed.shape != null &&
        parsed.sample != null &&
        parsed.reason == null &&
        parsed.truncatedLargeResponse === true;

      const ok = shapeOk && sampleOk && parseOk;
      schemaLog("testLargeResponseSampling", { ok, shapeOk, sampleOk, parseOk });
      return { ok, shapeOk, sampleOk, parseOk, bookingsShape, sampleBookings };
    }

    window.EndpointScout = {
      isEnabled: () => isScoutEnabled(),
      getReport: (options) => buildReport(options || {}),
      handleMessage,
      testShapeExtraction,
      testRedactionRules,
      testSampleRedaction,
      testLargeResponseSampling,
    };

    document.dispatchEvent(new CustomEvent("endpoint-scout-enabled"));
  }

  function handleMessage(req, _sender, sendResponse) {
    if (req.action === "getEndpointScoutStatus") {
      sendResponse({
        status: "ok",
        enabled: isScoutEnabled(),
        developerUser: null,
      });
      return true;
    }

    if (req.action === "getEndpointScoutReport") {
      if (!isScoutEnabled()) {
        sendResponse({ status: "error", error: "Endpoint Scout not available" });
        return true;
      }
      (async () => {
        try {
          const report = await buildReport({
            includeNoise: req.includeNoise === true,
            enrichSchemas: req.enrichSchemas !== false,
          });
          sendResponse({ status: "ok", report });
        } catch (err) {
          sendResponse({
            status: "error",
            error: err && err.message ? err.message : String(err),
          });
        }
      })();
      return true;
    }

    sendResponse({ status: "error", error: `Unknown Endpoint Scout action: ${req.action}` });
    return true;
  }

  if (typeof document !== "undefined") {
    if (ENABLE_ENDPOINT_SCOUT && isFareHarborHost()) {
      refreshDevModeState(() => {
        tryActivateEndpointScout();
      });
      try {
        chrome.storage.onChanged.addListener((changes, areaName) => {
          if (areaName !== "local" || !changes[DEV_MODE_STORAGE_KEY]) return;
          devModeEnabled = !!changes[DEV_MODE_STORAGE_KEY].newValue;
          if (devModeEnabled) {
            gateFailed = false;
            tryActivateEndpointScout();
          }
        });
      } catch {
        // ignore
      }
    }
  }
})();
