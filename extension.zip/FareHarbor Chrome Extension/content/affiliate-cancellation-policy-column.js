(function affiliateCancellationPolicyColumnModule() {
  "use strict";

  const affiliateApi = window.FareHarborAffiliateApi;
  if (!affiliateApi) {
    return;
  }

  const { fetchAffiliateDetail, resolveAffiliateCancellationPolicy } = affiliateApi;
  const columnOrder = window.FareHarborAffiliateTableColumnOrder;
  if (!columnOrder) {
    return;
  }

  const LOG_PREFIX = "[affiliate-cancellation-policy-column]";
  const DEV_MODE_STORAGE_KEY = FareHarborDeveloperAuth.DEV_MODE_STORAGE_KEY;
  const COLUMN_KEY = "affiliate-cancellation-policy";
  const COLUMN_ATTR = "data-fh-ext-column";
  const COLUMN_SELECTOR = `[${COLUMN_ATTR}="${COLUMN_KEY}"]`;
  const ENDPOINT_COLUMN_SELECTOR =
    '[data-fh-ext-column="affiliate-company-endpoint-call"]';
  const AFFILIATE_ID_ATTR = "data-fh-affiliate-id";
  const BODY_CELL_CLASS = "fh-ext-affiliate-cancellation-policy-cell";
  const SUBTLE_TEXT_CLASS = "fh-ext-subtle-text";
  const HEADER_TEXT = "Cancellation Policy";
  const SETTING_KEY = "showAffiliateCancellationPolicyColumn";
  const INSERT_BEFORE_COLUMN_KEY = "permissionsGroup";
  const COLUMN_WIDTH_PX = 150;
  const REQUIRED_COLUMN_KEYS = [
    "affiliateName",
    "invoicePricing",
    INSERT_BEFORE_COLUMN_KEY,
    "actions"
  ];
  const AFFILIATES_PATH_RE =
    /^\/([^/]+)\/dashboard\/settings\/network\/affiliates\/?/;
  const EDIT_AFFILIATE_HREF_RE = /\/affiliates\/edit\/(\d+)\/?/;
  const SCAN_DEBOUNCE_MS = 150;
  const ROUTE_REEVAL_DELAY_MS = 150;
  const ROUTE_POLL_MS = 500;
  const RETRY_INTERVAL_MS = 500;
  const RETRY_MAX_MS = 10000;
  const FETCH_CONCURRENCY = 5;
  const LOADING_TEXT = "Loading…";
  const MISSING_TEXT = "-";
  const LAYOUT_STYLE_ID = "fh-affiliate-cancellation-layout-style";
  const LAYOUT_CLASS = "fh-affiliate-cancellation-columns";
  const SETTINGS_WINDOW_SELECTOR = ".settings-window";
  const LAYOUT_STYLE_TEXT = `.settings-window.${LAYOUT_CLASS} {
  --settings-wrap-width-narrow: 900px;
}
.${SUBTLE_TEXT_CLASS} {
  opacity: 0.6;
}
td${COLUMN_SELECTOR} .fh-table-cell {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
td${COLUMN_SELECTOR} .fh-table-cell a.fh-link.fh-link--primary {
  color: var(--fh-color-text-link, var(--fh-color-link-primary, #006edb));
  text-decoration: none;
}
td${COLUMN_SELECTOR} .fh-table-cell a.fh-link.fh-link--primary:hover {
  color: var(--fh-color-text-link-hover, var(--fh-color-text-link, #005bb5));
  text-decoration: underline;
}
td${COLUMN_SELECTOR} .fh-table-cell a.fh-link.fh-link--primary:visited {
  color: var(--fh-color-text-link-visited, var(--fh-color-text-link, #006edb));
}
td${COLUMN_SELECTOR} .fh-text.${SUBTLE_TEXT_CLASS} {
  opacity: 0.6;
}
th${COLUMN_SELECTOR} .fh-text.fh-text--bold {
  font-weight: var(--fh-font-weight-bold, 600) !important;
}
${COLUMN_SELECTOR} {
  width: ${COLUMN_WIDTH_PX}px;
  min-width: ${COLUMN_WIDTH_PX}px;
  max-width: ${COLUMN_WIDTH_PX}px;
}`;

  let devModeEnabled = false;
  let observer = null;
  let debounceTimer = null;
  let hrefPollTimer = null;
  let lifecycleEvalTimer = null;
  let retryTimer = null;
  let retryStartedAt = 0;
  let lastTrackedHref = location.href;
  let watchersActive = false;
  let routeWatchersStarted = false;
  let scanInProgress = false;
  let fetchGeneration = 0;
  let featureEnabled = true;
  let startupMigrationDone = false;
  let policyDebugLogged = false;
  let policyRenderDebugLogged = false;

  /** @type {Map<string, { affiliateIdSetKey: string, byAffiliateId: Map<string, { status: string, policy: object | null }> }>} */
  const pagePoliciesCache = new Map();
  let lastAppliedState = {
    pageKey: null,
    affiliateIdSetKey: null,
    populated: false
  };

  function devLog(...args) {
    if (devModeEnabled) {
      console.log(LOG_PREFIX, ...args);
    }
  }

  function isDevModeEnabledAsync() {
    return FareHarborDeveloperAuth.isDevModeActiveAsync();
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function parsePageContext() {
    const match = (location.pathname || "").match(AFFILIATES_PATH_RE);
    if (!match) {
      return null;
    }
    return {
      companyShortname: match[1],
      pathname: location.pathname || "",
      search: location.search || ""
    };
  }

  function isUrlEligible() {
    return isFareHarborHost() && !!parsePageContext();
  }

  function buildPageKey(ctx) {
    if (!ctx) {
      return null;
    }
    return `${ctx.companyShortname}|${ctx.pathname}${ctx.search}`;
  }

  function buildAffiliateIdSetKey(affiliateIds) {
    return [...affiliateIds].sort().join("|");
  }

  function clearPageCaches() {
    pagePoliciesCache.clear();
    lastAppliedState = {
      pageKey: null,
      affiliateIdSetKey: null,
      populated: false
    };
  }

  function getRowCells(row) {
    return [...row.children].filter(
      (el) => el.tagName === "TD" || el.tagName === "TH"
    );
  }

  function getNativeRowCells(row) {
    return columnOrder.getNativeRowCells(row);
  }

  function isExtensionNode(node) {
    if (!(node instanceof Element)) {
      const parent = node?.parentElement;
      return parent ? isExtensionNode(parent) : false;
    }
    if (node.getAttribute(COLUMN_ATTR) === COLUMN_KEY) {
      return true;
    }
    if (node.getAttribute(COLUMN_ATTR) === "affiliate-company-endpoint-call") {
      return true;
    }
    if (node.classList?.contains(BODY_CELL_CLASS)) {
      return true;
    }
    return (
      !!node.closest?.(COLUMN_SELECTOR) ||
      !!node.closest?.(ENDPOINT_COLUMN_SELECTOR)
    );
  }

  function isExtensionMutation(mutation) {
    if (isExtensionNode(mutation.target)) {
      return true;
    }
    for (const node of mutation.addedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    for (const node of mutation.removedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    return false;
  }

  function removeInjectedColumns(root) {
    const scope = root || document;
    scope.querySelectorAll(COLUMN_SELECTOR).forEach((cell) => {
      cell.remove();
    });
  }

  function restoreTableWidth(table) {
    if (!table) {
      return;
    }
    const originalWidth = table.getAttribute("data-fh-ext-original-width");
    if (originalWidth) {
      table.style.width = `${originalWidth}px`;
      table.removeAttribute("data-fh-ext-original-width");
      table.removeAttribute("data-fh-ext-width-expanded");
    }
  }

  function expandTableWidth(table) {
    if (!table || table.getAttribute("data-fh-ext-width-expanded") === "true") {
      return;
    }

    const styleWidth = table.style.width || "";
    const match = styleWidth.match(/(\d+(?:\.\d+)?)\s*px/i);
    if (!match) {
      return;
    }

    const currentWidth = Number(match[1]);
    if (!Number.isFinite(currentWidth)) {
      return;
    }

    if (!table.hasAttribute("data-fh-ext-original-width")) {
      table.setAttribute("data-fh-ext-original-width", String(Math.round(currentWidth)));
    }

    table.style.width = `${Math.round(currentWidth + COLUMN_WIDTH_PX)}px`;
    table.setAttribute("data-fh-ext-width-expanded", "true");
  }

  function cleanupMigrationArtifacts(table) {
    const permissionsHeader = table.querySelector(
      `th[data-column-key="${INSERT_BEFORE_COLUMN_KEY}"]`
    );
    if (!permissionsHeader) {
      return;
    }

    const headerInner = permissionsHeader.querySelector(":scope > .fh-table-cell");
    if (!headerInner) {
      return;
    }

    headerInner.querySelectorAll("span, p").forEach((el) => {
      if (
        el.closest(COLUMN_SELECTOR) ||
        el.getAttribute(COLUMN_ATTR) === COLUMN_KEY
      ) {
        return;
      }
      if ((el.textContent || "").trim() === HEADER_TEXT) {
        el.remove();
      }
    });
  }

  function cleanupBrokenInjection(table) {
    if (!table) {
      return;
    }

    table.querySelectorAll(COLUMN_SELECTOR).forEach((cell) => {
      cell.remove();
    });
    cleanupMigrationArtifacts(table);
    restoreTableWidth(table);
  }

  function prepareTableForInjection(table) {
    table.querySelectorAll(COLUMN_SELECTOR).forEach((cell) => {
      cell.remove();
    });
    cleanupMigrationArtifacts(table);
  }

  function ensureLayoutStyle() {
    if (document.getElementById(LAYOUT_STYLE_ID)) {
      return;
    }
    const style = document.createElement("style");
    style.id = LAYOUT_STYLE_ID;
    style.textContent = LAYOUT_STYLE_TEXT;
    (document.head || document.documentElement).appendChild(style);
  }

  function applyLayoutWidening() {
    ensureLayoutStyle();
    document.querySelectorAll(SETTINGS_WINDOW_SELECTOR).forEach((el) => {
      el.classList.add(LAYOUT_CLASS);
    });
  }

  function removeLayoutWidening() {
    document
      .querySelectorAll(`${SETTINGS_WINDOW_SELECTOR}.${LAYOUT_CLASS}`)
      .forEach((el) => {
        el.classList.remove(LAYOUT_CLASS);
      });
  }

  function syncLayoutWidening() {
    if (featureEnabled && isUrlEligible()) {
      applyLayoutWidening();
      return;
    }
    removeLayoutWidening();
  }

  function applyFeatureSetting(enabled, reason) {
    featureEnabled = enabled !== false;
    if (!featureEnabled) {
      removeLayoutWidening();
      stopObserver();
      const table = findAffiliatesTable(document);
      if (table) {
        cleanupBrokenInjection(table);
      } else {
        removeInjectedColumns();
      }
      watchersActive = false;
      return;
    }
    evaluateLifecycle(reason || "setting-enabled");
  }

  function initSettingsBinding() {
    const settings = window.FHSettings;
    if (!settings) {
      return;
    }
    settings.get(SETTING_KEY, (value) => {
      applyFeatureSetting(value, "settings-init");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SETTING_KEY]) {
        applyFeatureSetting(changes[SETTING_KEY].newValue, "setting-change");
      }
    });
  }

  function getColumnKeyIndexMap(headerRow) {
    const nativeCells = getNativeRowCells(headerRow);
    const map = new Map();
    nativeCells.forEach((cell, index) => {
      const key = cell.getAttribute("data-column-key");
      if (key) {
        map.set(key, index);
      }
    });
    return { nativeCells, map };
  }

  function findNativeCellByColumnKey(row, columnKey) {
    const direct = row.querySelector(
      `:scope > th[data-column-key="${columnKey}"], :scope > td[data-column-key="${columnKey}"]`
    );
    if (direct && !columnOrder.isExtensionColumnCell(direct)) {
      return direct;
    }

    const nativeCells = getNativeRowCells(row);
    const index = nativeCells.findIndex(
      (cell) => cell.getAttribute("data-column-key") === columnKey
    );
    if (index >= 0) {
      return nativeCells[index];
    }

    const headerRow = row.closest("table")?.querySelector("thead tr");
    if (!headerRow) {
      return null;
    }

    const headerNativeCells = getNativeRowCells(headerRow);
    const headerIndex = headerNativeCells.findIndex(
      (cell) => cell.getAttribute("data-column-key") === columnKey
    );
    if (headerIndex < 0) {
      return null;
    }

    return nativeCells[headerIndex] || null;
  }

  function removeDuplicateExtensionCells(row) {
    const cells = [...row.querySelectorAll(`:scope > ${COLUMN_SELECTOR}`)];
    for (let i = 1; i < cells.length; i += 1) {
      cells[i].remove();
    }
  }

  function getPermissionsGroupColumnIndex(table) {
    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return null;
    }
    const nativeHeaderCells = getNativeRowCells(headerRow);
    const index = nativeHeaderCells.findIndex(
      (cell) => cell.getAttribute("data-column-key") === INSERT_BEFORE_COLUMN_KEY
    );
    return index >= 0 ? index : null;
  }

  function isAffiliatesTable(table) {
    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return false;
    }
    const { map } = getColumnKeyIndexMap(headerRow);
    return REQUIRED_COLUMN_KEYS.every((key) => map.has(key));
  }

  function findAffiliatesTable(root) {
    const scope = root || document;
    const tables = scope.querySelectorAll("table");
    for (const table of tables) {
      if (isAffiliatesTable(table)) {
        return table;
      }
    }
    return null;
  }

  function extractAffiliateIdFromRow(row) {
    const rowId = row.getAttribute("data-row-id");
    if (rowId) {
      return rowId;
    }

    const tbody = row.closest("tbody[data-id]");
    if (tbody) {
      const tbodyId = tbody.getAttribute("data-id");
      if (tbodyId) {
        return tbodyId;
      }
    }

    const editLink = row.querySelector('a[data-test-id^="edit-affiliate-"]');
    if (editLink) {
      const href = editLink.getAttribute("href") || editLink.href || "";
      const match = href.match(EDIT_AFFILIATE_HREF_RE);
      if (match) {
        return match[1];
      }
    }

    return null;
  }

  function getCellContentElement(cell) {
    let inner = cell.querySelector(":scope > .fh-table-cell");
    if (!inner) {
      inner = document.createElement("div");
      inner.className = "fh-table-cell";
      cell.appendChild(inner);
    }
    return inner;
  }

  function clearCellContent(cell) {
    const inner = getCellContentElement(cell);
    inner.textContent = "";
    inner.replaceChildren();
    return inner;
  }

  function getReferenceTableLink(cell) {
    const table = cell?.closest("table");
    if (!table) {
      return null;
    }

    return (
      table.querySelector(
        'a.fh-link--primary[href*="/dashboard/settings/permissions/groups/"]'
      ) ||
      table.querySelector(
        'a.fh-link--primary[href*="/dashboard/settings/pricing/"]'
      ) ||
      table.querySelector("tbody a.fh-link--primary")
    );
  }

  function applyNativeLinkAppearance(link, referenceLink) {
    link.className = "fh-link fh-link--primary fh-link--md fh-link--standalone";
    link.setAttribute("size", "md");

    if (!referenceLink) {
      return;
    }

    link.className = referenceLink.className;
    const refSize = referenceLink.getAttribute("size");
    if (refSize) {
      link.setAttribute("size", refSize);
    } else {
      link.setAttribute("size", "md");
    }

    const computed = window.getComputedStyle(referenceLink);
    link.style.color = computed.color;
    link.style.textDecoration = computed.textDecoration;
    link.style.fontWeight = computed.fontWeight;
    link.style.fontSize = computed.fontSize;
    link.style.lineHeight = computed.lineHeight;
  }

  function setSubtleCellText(cell, text) {
    const inner = clearCellContent(cell);
    const span = document.createElement("span");
    span.className = `fh-text fh-text--body-md fh-text--regular ${SUBTLE_TEXT_CLASS}`;
    span.textContent = text;
    inner.appendChild(span);
    cell.classList.remove(SUBTLE_TEXT_CLASS);
    cell.removeAttribute("title");
  }

  function renderPolicyNameLink(cell, inner, policy) {
    const link = document.createElement("a");
    link.href = policy.cancellationPolicyUrl;
    link.textContent = policy.displayText;
    if (policy.titleText) {
      link.setAttribute("title", policy.titleText);
    }

    applyNativeLinkAppearance(link, getReferenceTableLink(cell));
    inner.appendChild(link);
    return link;
  }

  function renderPolicyNameText(inner, policy) {
    const span = document.createElement("span");
    span.className = "fh-text fh-text--body-md fh-text--regular";
    span.textContent = policy.displayText;
    inner.appendChild(span);
    if (policy.linkUnavailableTitle) {
      span.setAttribute("title", policy.linkUnavailableTitle);
    } else if (
      policy.titleText &&
      policy.titleText.length > policy.displayText.length
    ) {
      span.setAttribute("title", policy.titleText);
    }
  }

  function applyPolicyToCell(cell, policyResult) {
    cell.classList.remove(SUBTLE_TEXT_CLASS);
    cell.removeAttribute("title");

    if (!policyResult) {
      setSubtleCellText(cell, LOADING_TEXT);
      return;
    }

    if (policyResult.status === "loading") {
      setSubtleCellText(cell, LOADING_TEXT);
      return;
    }

    if (policyResult.status === "error") {
      setSubtleCellText(cell, MISSING_TEXT);
      return;
    }

    const policy = policyResult.policy;
    if (!policy?.displayText) {
      setSubtleCellText(cell, MISSING_TEXT);
      return;
    }

    const inner = clearCellContent(cell);
    if (policy.cancellationPolicyUrl) {
      const link = renderPolicyNameLink(cell, inner, policy);
      if (!policyRenderDebugLogged) {
        policyRenderDebugLogged = true;
        devLog("Cancellation policy cell rendered", {
          affiliateId: cell.getAttribute(AFFILIATE_ID_ATTR),
          renderedAsLink: true,
          href: link.getAttribute("href")
        });
      }
      return;
    }

    renderPolicyNameText(inner, policy);
  }

  function getReferenceHeaderCell(headerRow) {
    return (
      headerRow.querySelector(`th[data-column-key="${INSERT_BEFORE_COLUMN_KEY}"]`) ||
      headerRow.querySelector('th[data-column-key="invoicePricing"]') ||
      headerRow.querySelector("th.fh-dynamic-table-cell-header")
    );
  }

  function copyNativeHeaderTypography(targetText, referenceText) {
    if (!targetText || !referenceText) {
      return;
    }

    targetText.className = referenceText.className;
    const computed = window.getComputedStyle(referenceText);
    targetText.style.fontWeight = computed.fontWeight;
    targetText.style.fontFamily = computed.fontFamily;
    targetText.style.fontSize = computed.fontSize;
    targetText.style.lineHeight = computed.lineHeight;
    targetText.style.letterSpacing = computed.letterSpacing;
  }

  function applyNativeHeaderShell(headerCell, referenceHeader) {
    if (!referenceHeader) {
      headerCell.className =
        "fh-table-cell--start fh-table-cell-header fh-dynamic-table-cell-header";
      return;
    }

    headerCell.className = referenceHeader.className
      .replace(/\bfh-table-cell-header--sortable\b/g, "")
      .trim();
    headerCell.removeAttribute("tabindex");
    headerCell.removeAttribute("aria-sort");
    headerCell.removeAttribute("aria-labelledby");
    headerCell.removeAttribute("data-column-name");
    headerCell.removeAttribute("data-column-key");
  }

  function refreshHeaderLabel(headerCell, referenceHeader) {
    const headerLabel = headerCell.querySelector(
      ":scope > .fh-table-cell .fh-text"
    );
    if (!headerLabel) {
      return;
    }

    headerLabel.textContent = HEADER_TEXT;
    const refText = referenceHeader?.querySelector(
      ":scope > .fh-table-cell .fh-text"
    );
    if (refText) {
      copyNativeHeaderTypography(headerLabel, refText);
      return;
    }

    headerLabel.className = "fh-text fh-text--body-md fh-text--bold";
    headerLabel.style.fontWeight = "600";
  }

  function createHeaderCell(referenceHeader) {
    const cell = document.createElement("th");
    cell.setAttribute(COLUMN_ATTR, COLUMN_KEY);
    applyNativeHeaderShell(cell, referenceHeader);
    cell.setAttribute("role", "columnheader");
    cell.setAttribute("scope", "col");
    cell.style.width = `${COLUMN_WIDTH_PX}px`;

    const inner = document.createElement("div");
    inner.className = "fh-table-cell";

    const span = document.createElement("span");
    span.textContent = HEADER_TEXT;
    const refText = referenceHeader?.querySelector(
      ":scope > .fh-table-cell .fh-text"
    );
    if (refText) {
      copyNativeHeaderTypography(span, refText);
    } else {
      span.className = "fh-text fh-text--body-md fh-text--bold";
      span.style.fontWeight = "600";
    }

    inner.appendChild(span);
    cell.appendChild(inner);
    return cell;
  }

  function createBodyCell() {
    const cell = document.createElement("td");
    cell.setAttribute(COLUMN_ATTR, COLUMN_KEY);
    cell.classList.add(BODY_CELL_CLASS, "fh-table-cell--start");
    cell.style.width = `${COLUMN_WIDTH_PX}px`;

    const inner = document.createElement("div");
    inner.className = "fh-table-cell";
    const span = document.createElement("span");
    span.className = `fh-text fh-text--body-md fh-text--regular ${SUBTLE_TEXT_CLASS}`;
    span.textContent = LOADING_TEXT;
    inner.appendChild(span);
    cell.appendChild(inner);
    return cell;
  }

  function ensureHeaderColumn(headerRow) {
    let headerCell = headerRow.querySelector(`:scope > ${COLUMN_SELECTOR}`);
    const referenceHeader = getReferenceHeaderCell(headerRow);
    const permissionsHeader = columnOrder.findNativePermissionsHeader(headerRow);

    if (!permissionsHeader) {
      if (headerCell) {
        headerCell.remove();
      }
      return { inserted: false, repositioned: false };
    }

    if (!headerCell) {
      headerCell = createHeaderCell(referenceHeader);
      headerRow.insertBefore(headerCell, permissionsHeader);
      return { inserted: true, repositioned: false };
    }

    if (headerCell.tagName !== "TH") {
      const replacement = createHeaderCell(referenceHeader);
      headerCell.replaceWith(replacement);
      headerCell = replacement;
      headerRow.insertBefore(headerCell, permissionsHeader);
      return { inserted: true, repositioned: true };
    }

    applyNativeHeaderShell(headerCell, referenceHeader);
    refreshHeaderLabel(headerCell, referenceHeader);
    headerCell.style.width = `${COLUMN_WIDTH_PX}px`;

    return { inserted: false, repositioned: false };
  }

  function ensureBodyCell(row, affiliateId, byAffiliateId) {
    let cell = row.querySelector(`:scope > ${COLUMN_SELECTOR}`);
    let inserted = false;
    const permissionsCell = columnOrder.findNativePermissionsCell(row);

    if (!permissionsCell) {
      if (cell) {
        cell.remove();
      }
      return { inserted: false, repositioned: false, cell: null };
    }

    if (!cell) {
      cell = createBodyCell();
      row.insertBefore(cell, permissionsCell);
      inserted = true;
    } else if (cell.tagName !== "TD") {
      const replacement = createBodyCell();
      cell.replaceWith(replacement);
      cell = replacement;
      row.insertBefore(cell, permissionsCell);
      inserted = true;
    }

    cell.style.width = `${COLUMN_WIDTH_PX}px`;

    if (affiliateId) {
      const previousId = cell.getAttribute(AFFILIATE_ID_ATTR);
      if (previousId && previousId !== affiliateId) {
        setSubtleCellText(cell, LOADING_TEXT);
      }
      cell.setAttribute(AFFILIATE_ID_ATTR, affiliateId);
    } else {
      cell.removeAttribute(AFFILIATE_ID_ATTR);
    }

    const entry = affiliateId ? byAffiliateId?.get(affiliateId) : null;
    if (!affiliateId) {
      setSubtleCellText(cell, MISSING_TEXT);
    } else if (!entry) {
      setSubtleCellText(cell, LOADING_TEXT);
    } else {
      applyPolicyToCell(cell, entry);
    }

    return { inserted, repositioned: false, cell };
  }

  function tableNeedsRepair(table) {
    if (!table) {
      return true;
    }

    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return true;
    }

    const permissionsHeader = columnOrder.findNativePermissionsHeader(headerRow);
    if (!permissionsHeader) {
      return true;
    }

    const extensionHeaders = headerRow.querySelectorAll(`:scope > ${COLUMN_SELECTOR}`);
    if (extensionHeaders.length !== 1) {
      return true;
    }

    if (!columnOrder.rowExtensionOrderCorrect(headerRow, permissionsHeader)) {
      return true;
    }

    for (const row of table.querySelectorAll("tbody tr")) {
      const permissionsCell = columnOrder.findNativePermissionsCell(row, headerRow);
      if (!permissionsCell) {
        return true;
      }

      const extensionCells = row.querySelectorAll(`:scope > ${COLUMN_SELECTOR}`);
      if (extensionCells.length !== 1) {
        return true;
      }

      if (!columnOrder.rowExtensionOrderCorrect(row, permissionsCell)) {
        return true;
      }
    }

    return false;
  }

  function cellHasFinalValue(cell) {
    const text = (cell.textContent || "").trim();
    return text !== LOADING_TEXT && text !== "";
  }

  function normalizeColumn(table, ctx) {
    const headerRow = table.querySelector("thead tr");
    if (headerRow) {
      removeDuplicateExtensionCells(headerRow);
    }
    table.querySelectorAll("tbody tr").forEach(removeDuplicateExtensionCells);
    expandTableWidth(table);

    if (!headerRow) {
      return {
        descriptors: [],
        headerInserted: 0,
        cellsInserted: 0,
        cellsRepositioned: 0
      };
    }

    const permissionsHeader = columnOrder.findNativePermissionsHeader(headerRow);
    if (!permissionsHeader) {
      return {
        descriptors: [],
        headerInserted: 0,
        cellsInserted: 0,
        cellsRepositioned: 0
      };
    }

    const pageKey = ctx ? buildPageKey(ctx) : null;
    const byAffiliateId = pageKey
      ? pagePoliciesCache.get(pageKey)?.byAffiliateId
      : null;

    let headerInserted = 0;
    let cellsInserted = 0;
    let cellsRepositioned = 0;
    const descriptors = [];

    const headerResult = ensureHeaderColumn(headerRow);
    if (headerResult.inserted) {
      headerInserted = 1;
    }

    const rows = table.querySelectorAll("tbody tr");
    rows.forEach((row) => {
      const affiliateId = extractAffiliateIdFromRow(row);
      const bodyResult = ensureBodyCell(row, affiliateId, byAffiliateId);
      if (bodyResult.inserted) {
        cellsInserted += 1;
      }

      if (!bodyResult.cell) {
        return;
      }

      if (affiliateId) {
        descriptors.push({ affiliateId, cell: bodyResult.cell });
      } else {
        setSubtleCellText(bodyResult.cell, MISSING_TEXT);
      }
    });

    const orderResult = columnOrder.ensureAffiliateExtensionColumnOrder(table);
    if (orderResult.repositioned) {
      cellsRepositioned += 1;
    }

    return {
      descriptors,
      headerInserted,
      cellsInserted,
      cellsRepositioned
    };
  }

  function allPolicyCellsFinal(table) {
    const cells = [
      ...table.querySelectorAll(`tbody ${COLUMN_SELECTOR}[${AFFILIATE_ID_ATTR}]`)
    ];
    if (!cells.length) {
      return false;
    }
    return cells.every(cellHasFinalValue);
  }

  function populateCells(table, byAffiliateId) {
    table
      .querySelectorAll(`tbody ${COLUMN_SELECTOR}[${AFFILIATE_ID_ATTR}]`)
      .forEach((cell) => {
        const row = cell.closest("tr");
        const expectedAffiliateId = row
          ? extractAffiliateIdFromRow(row)
          : null;
        const cellAffiliateId = cell.getAttribute(AFFILIATE_ID_ATTR);

        if (
          expectedAffiliateId &&
          cellAffiliateId &&
          expectedAffiliateId !== cellAffiliateId
        ) {
          cell.setAttribute(AFFILIATE_ID_ATTR, expectedAffiliateId);
          setSubtleCellText(cell, LOADING_TEXT);
        }

        const affiliateId =
          expectedAffiliateId || cell.getAttribute(AFFILIATE_ID_ATTR);
        if (
          cellHasFinalValue(cell) &&
          affiliateId === cell.getAttribute(AFFILIATE_ID_ATTR)
        ) {
          const entry = byAffiliateId.get(affiliateId);
          if (entry && entry.status !== "loading") {
            return;
          }
        }

        const entry = byAffiliateId.get(affiliateId);
        if (!entry) {
          return;
        }

        applyPolicyToCell(cell, entry);
      });
  }

  async function fetchPoliciesWithConcurrency(shortname, affiliateIds, generation) {
    const byAffiliateId = new Map();

    for (const id of affiliateIds) {
      byAffiliateId.set(id, { status: "loading", policy: null });
    }

    for (let i = 0; i < affiliateIds.length; i += FETCH_CONCURRENCY) {
      if (generation !== fetchGeneration) {
        return byAffiliateId;
      }

      const batch = affiliateIds.slice(i, i + FETCH_CONCURRENCY);
      await Promise.all(
        batch.map(async (affiliateId) => {
          const result = await fetchAffiliateDetail(shortname, affiliateId);
          if (generation !== fetchGeneration) {
            return;
          }

          if (!result.ok || !result.detail) {
            byAffiliateId.set(affiliateId, { status: "error", policy: null });
            return;
          }

          const resolvedPolicy = await resolveAffiliateCancellationPolicy(
            shortname,
            result.detail
          );

          if (!resolvedPolicy.displayText) {
            byAffiliateId.set(affiliateId, { status: "missing", policy: null });
            if (!policyDebugLogged) {
              policyDebugLogged = true;
              devLog("Cancellation policy resolution sample", {
                affiliateId,
                selectedRaw: resolvedPolicy.debug?.raw ?? null,
                resolvedPolicyId: resolvedPolicy.cancellationPolicyId,
                resolvedPolicyName: resolvedPolicy.cancellationPolicyName,
                resolvedUrl: resolvedPolicy.cancellationPolicyUrl,
                urlUnresolvedReason: resolvedPolicy.debug?.urlUnresolvedReason
              });
            }
            return;
          }

          if (!policyDebugLogged) {
            policyDebugLogged = true;
            devLog("Cancellation policy resolution sample", {
              affiliateId,
              selectedRaw: resolvedPolicy.debug?.raw ?? null,
              resolvedPolicyId: resolvedPolicy.cancellationPolicyId,
              resolvedPolicyName: resolvedPolicy.cancellationPolicyName,
              resolvedUrl: resolvedPolicy.cancellationPolicyUrl,
              urlUnresolvedReason: resolvedPolicy.debug?.urlUnresolvedReason
            });
            if (!resolvedPolicy.cancellationPolicyUrl) {
              devLog("Cancellation policy URL unresolved", {
                affiliateId,
                reason: resolvedPolicy.debug?.urlUnresolvedReason
              });
            }
          }

          byAffiliateId.set(affiliateId, {
            status: "ok",
            policy: resolvedPolicy
          });
        })
      );
    }

    return byAffiliateId;
  }

  async function resolvePolicies(ctx, affiliateIds) {
    const pageKey = buildPageKey(ctx);
    const affiliateIdSetKey = buildAffiliateIdSetKey(affiliateIds);
    const cached = pagePoliciesCache.get(pageKey);

    if (cached && cached.affiliateIdSetKey === affiliateIdSetKey) {
      return cached.byAffiliateId;
    }

    let byAffiliateId = cached?.byAffiliateId || new Map();
    const idsToFetch = affiliateIds.filter((id) => {
      const entry = byAffiliateId.get(id);
      return !entry || entry.status === "loading";
    });

    if (idsToFetch.length) {
      devLog("fetching affiliate cancellation policies", {
        company: ctx.companyShortname,
        rowCount: idsToFetch.length
      });

      const generation = fetchGeneration;
      const fetched = await fetchPoliciesWithConcurrency(
        ctx.companyShortname,
        idsToFetch,
        generation
      );

      if (generation === fetchGeneration) {
        for (const [id, entry] of fetched.entries()) {
          byAffiliateId.set(id, entry);
        }
      }
    }

    byAffiliateId = new Map(byAffiliateId);
    pagePoliciesCache.set(pageKey, { affiliateIdSetKey, byAffiliateId });
    return byAffiliateId;
  }

  function shouldFullySkipScan(ctx, descriptors, table) {
    if (!ctx || !descriptors.length || !table) {
      return false;
    }

    if (tableNeedsRepair(table)) {
      return false;
    }

    if (!allPolicyCellsFinal(table)) {
      return false;
    }

    const pageKey = buildPageKey(ctx);
    const affiliateIdSetKey = buildAffiliateIdSetKey(
      descriptors.map((d) => d.affiliateId)
    );

    if (
      lastAppliedState.pageKey === pageKey &&
      lastAppliedState.affiliateIdSetKey === affiliateIdSetKey &&
      lastAppliedState.populated
    ) {
      return true;
    }

    const cached = pagePoliciesCache.get(pageKey);
    return !!(cached && cached.affiliateIdSetKey === affiliateIdSetKey);
  }

  function descriptorsNeedFetch(ctx, descriptors) {
    if (!ctx || !descriptors.length) {
      return false;
    }

    const pageKey = buildPageKey(ctx);
    const affiliateIdSetKey = buildAffiliateIdSetKey(
      descriptors.map((d) => d.affiliateId)
    );
    const cached = pagePoliciesCache.get(pageKey);

    if (cached && cached.affiliateIdSetKey === affiliateIdSetKey) {
      return false;
    }

    if (cached) {
      return descriptors.some((d) => {
        const entry = cached.byAffiliateId.get(d.affiliateId);
        return !entry || entry.status === "loading";
      });
    }

    return true;
  }

  async function scanTable(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return false;
    }

    const table = findAffiliatesTable(document);
    if (!table) {
      return false;
    }

    if (scanInProgress) {
      return false;
    }

    scanInProgress = true;
    const generation = ++fetchGeneration;
    let didWork = false;

    try {
      syncLayoutWidening();

      if (!startupMigrationDone) {
        cleanupBrokenInjection(table);
        startupMigrationDone = true;
      }

      const ctx = parsePageContext();
      const normalizeResult = normalizeColumn(table, ctx);
      const {
        descriptors,
        headerInserted,
        cellsInserted,
        cellsRepositioned
      } = normalizeResult;

      devLog("Affiliates column normalized", {
        reason,
        rowCount: descriptors.length,
        headerInserted,
        cellsInserted,
        cellsRepositioned,
        permissionsColumnIndex: getPermissionsGroupColumnIndex(table)
      });

      didWork =
        headerInserted > 0 || cellsInserted > 0 || cellsRepositioned > 0;

      if (!ctx || !descriptors.length) {
        return didWork;
      }

      if (shouldFullySkipScan(ctx, descriptors, table)) {
        const cached = pagePoliciesCache.get(buildPageKey(ctx));
        if (cached) {
          populateCells(table, cached.byAffiliateId);
        }
        return didWork;
      }

      const cached = pagePoliciesCache.get(buildPageKey(ctx));
      if (cached) {
        populateCells(table, cached.byAffiliateId);
      }

      const affiliateIds = descriptors.map((d) => d.affiliateId);

      if (!descriptorsNeedFetch(ctx, descriptors)) {
        lastAppliedState = {
          pageKey: buildPageKey(ctx),
          affiliateIdSetKey: buildAffiliateIdSetKey(affiliateIds),
          populated: allPolicyCellsFinal(table)
        };
        if (lastAppliedState.populated) {
          stopRetryLoop();
        }
        return didWork;
      }

      const byAffiliateId = await resolvePolicies(ctx, affiliateIds);
      if (generation !== fetchGeneration) {
        return didWork;
      }

      populateCells(table, byAffiliateId);
      lastAppliedState = {
        pageKey: buildPageKey(ctx),
        affiliateIdSetKey: buildAffiliateIdSetKey(affiliateIds),
        populated: allPolicyCellsFinal(table)
      };

      if (lastAppliedState.populated) {
        stopRetryLoop();
      }

      return didWork;
    } finally {
      scanInProgress = false;
    }
  }

  function scheduleScan(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }
    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      scanTable(reason || "debounced-scan");
    }, SCAN_DEBOUNCE_MS);
  }

  function stopRetryLoop() {
    if (retryTimer) {
      clearInterval(retryTimer);
      retryTimer = null;
    }
    retryStartedAt = 0;
  }

  function startRetryLoop(reason) {
    if (!isUrlEligible()) {
      stopRetryLoop();
      return;
    }

    if (!retryTimer) {
      retryStartedAt = Date.now();
      retryTimer = setInterval(async () => {
        const elapsed = Date.now() - retryStartedAt;
        const found = await scanTable("retry-loop");
        if (found) {
          stopRetryLoop();
          return;
        }
        if (elapsed >= RETRY_MAX_MS) {
          stopRetryLoop();
        }
      }, RETRY_INTERVAL_MS);
    }

    scheduleScan(reason || "retry-schedule");
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    stopRetryLoop();
    clearPageCaches();
    fetchGeneration += 1;
    scanInProgress = false;
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  function evaluateLifecycle(reason) {
    if (!featureEnabled) {
      stopObserver();
      const table = findAffiliatesTable(document);
      if (table) {
        cleanupBrokenInjection(table);
      } else {
        removeInjectedColumns();
      }
      removeLayoutWidening();
      watchersActive = false;
      return;
    }

    if (!isUrlEligible()) {
      stopObserver();
      removeLayoutWidening();
      watchersActive = false;
      return;
    }

    syncLayoutWidening();

    if (!watchersActive) {
      devLog("eligible page detected", { reason, href: location.href });
      startObserver();
      watchersActive = true;
    }

    startRetryLoop(reason || "lifecycle");
  }

  function onRouteChange(reason) {
    const nextHref = location.href;
    if (nextHref !== lastTrackedHref) {
      clearPageCaches();
      fetchGeneration += 1;
      startupMigrationDone = false;
      policyDebugLogged = false;
      policyRenderDebugLogged = false;
    }
    lastTrackedHref = nextHref;
    scheduleLifecycleEval(reason || "route-change");
  }

  function startRouteWatchers() {
    if (routeWatchersStarted) {
      return;
    }
    routeWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", () => onRouteChange("popstate"));
    window.addEventListener("hashchange", () => onRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        onRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        onRouteChange("replaceState");
        return result;
      };
    } catch (err) {
      devLog("history hook unavailable:", err);
    }

    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        onRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  function startObserver() {
    if (observer) {
      return;
    }

    observer = new MutationObserver((mutations) => {
      if (!isUrlEligible()) {
        return;
      }
      if (mutations.length > 0 && mutations.every(isExtensionMutation)) {
        return;
      }
      scheduleScan("mutation-observer");
    });

    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  async function init() {
    if (!isFareHarborHost()) {
      return;
    }

    devModeEnabled = await isDevModeEnabledAsync();
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[DEV_MODE_STORAGE_KEY]) {
        void isDevModeEnabledAsync().then((active) => {
          devModeEnabled = active;
        });
      }
    });

    initSettingsBinding();
    startRouteWatchers();
    evaluateLifecycle("init");

    if (document.readyState === "loading") {
      document.addEventListener(
        "DOMContentLoaded",
        () => evaluateLifecycle("dom-content-loaded"),
        { once: true }
      );
    }
  }

  init();
})();
