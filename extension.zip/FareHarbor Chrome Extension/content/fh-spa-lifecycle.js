(function initializeFareHarborSpaLifecycle() {
  "use strict";

  if (window.FareHarborSpaLifecycle) {
    return;
  }

  const ROUTE_POLL_MS = 500;
  /** @type {Set<(reason: string) => void>} */
  const listeners = new Set();
  let hooksInstalled = false;
  let polling = false;
  let lastTrackedHref = location.href;
  let hrefPollTimer = null;

  function notify(reason) {
    if (listeners.size === 0) {
      return;
    }
    listeners.forEach((listener) => {
      try {
        listener(reason);
      } catch (err) {
        console.warn("[fh-spa-lifecycle] listener error:", err);
      }
    });
  }

  function onRouteChange(reason) {
    lastTrackedHref = location.href;
    notify(reason || "route-change");
  }

  function installHooks() {
    if (hooksInstalled) {
      return;
    }
    hooksInstalled = true;

    window.addEventListener("popstate", () => onRouteChange("popstate"));
    window.addEventListener("hashchange", () => onRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        onRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        onRouteChange("replaceState");
        return result;
      };
    } catch (_) {
      // History hooks unavailable; href poll remains as fallback.
    }
  }

  function startPolling() {
    if (polling) {
      return;
    }
    polling = true;
    lastTrackedHref = location.href;
    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        onRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  function stopPolling() {
    if (!polling) {
      return;
    }
    polling = false;
    if (hrefPollTimer) {
      clearInterval(hrefPollTimer);
      hrefPollTimer = null;
    }
  }

  /**
   * Subscribe to SPA URL / history changes. Starts shared watchers on first
   * subscriber. Returns an unsubscribe function.
   * @param {(reason: string) => void} listener
   * @returns {() => void}
   */
  function subscribe(listener) {
    if (typeof listener !== "function") {
      return () => {};
    }
    listeners.add(listener);
    installHooks();
    startPolling();
    return () => {
      listeners.delete(listener);
      if (listeners.size === 0) {
        stopPolling();
      }
    };
  }

  function getListenerCount() {
    return listeners.size;
  }

  window.FareHarborSpaLifecycle = {
    subscribe,
    getListenerCount,
    ROUTE_POLL_MS
  };
})();
