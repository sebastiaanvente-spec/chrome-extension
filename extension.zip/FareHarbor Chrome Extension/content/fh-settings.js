(function initializeFhSettings() {
  "use strict";

  const DEFAULT_SETTINGS = {
    showFutureAvailabilitiesColumn: true,
    showCopyMappingDataButtons: true,
    showFindExactMappings: true,
    showAffiliateCancellationPolicyColumn: true,
    showAffiliateCompanyEndpointCallColumn: true,
    showAffiliateApiCredentials: true,
    showResourceUseCreatedAtColumn: true
  };

  function getAll(callback) {
    chrome.storage.local.get(DEFAULT_SETTINGS, callback);
  }

  function get(key, callback) {
    chrome.storage.local.get(DEFAULT_SETTINGS, (result) => {
      callback(result[key]);
    });
  }

  function getAllAsync() {
    return new Promise((resolve) => {
      chrome.storage.local.get(DEFAULT_SETTINGS, resolve);
    });
  }

  function getAsync(key) {
    return getAllAsync().then((settings) => settings[key]);
  }

  window.FHSettings = {
    defaults: DEFAULT_SETTINGS,
    getAll,
    get,
    getAllAsync,
    getAsync
  };
})();
