(function initializeFhSettings() {
  "use strict";

  const DEFAULT_SETTINGS = {
    showFutureAvailabilitiesColumn: true,
    autoEnableNativeFutureAvailabilities: false,
    showItemStatusColumn: true,
    showTicketScanningColumn: true,
    showCopyMappingDataButtons: true,
    showMappingToolsPanel: true,
    showFindExactMappings: true,
    showFindCustomerTypeDependencies: false,
    showAffiliateCompanyEndpointCallColumn: false,
    showAffiliateApiCredentials: true,
    showResourceUseCreatedAtColumn: true
  };

  function getAll(callback) {
    chrome.storage.local.get(DEFAULT_SETTINGS, callback);
  }

  function get(key, callback) {
    chrome.storage.local.get(DEFAULT_SETTINGS, (result) => {
      callback(result[key]);
    });
  }

  function getAllAsync() {
    return new Promise((resolve) => {
      chrome.storage.local.get(DEFAULT_SETTINGS, resolve);
    });
  }

  function getAsync(key) {
    return getAllAsync().then((settings) => settings[key]);
  }

  window.FHSettings = {
    defaults: DEFAULT_SETTINGS,
    getAll,
    get,
    getAllAsync,
    getAsync
  };
})();
