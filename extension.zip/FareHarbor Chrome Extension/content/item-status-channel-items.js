console.log("[item-status-channel-items] script loaded");

(function itemStatusChannelItemsModule() {
  "use strict";

  const LOG_PREFIX = "[item-status-channel-items]";
  const COLUMN_ATTR = "data-fh-item-status-column";
  const ITEM_IDS_ATTR = "data-fh-mapped-item-ids";
  const HEADER_TEXT = "Item Status";
  const SETTING_KEY = "showItemStatusColumn";
  const STYLE_ID = "fh-item-status-column-style";
  const SCAN_DEBOUNCE_MS = 150;
  const ROUTE_REEVAL_DELAY_MS = 150;
  const ROUTE_POLL_MS = 500;
  const RETRY_INTERVAL_MS = 500;
  const RETRY_MAX_MS = 10000;
  const MAX_CONCURRENCY = 5;
  const MISSING_TEXT = "—";
  const LOADING_TEXT = "Loading...";
  const UNKNOWN_TEXT = "Unknown";

  const CHANNEL_COMPANY_NUMERIC_RE =
    /^\/[^/]+\/dashboard\/settings\/integrations\/channels\/(\d+)\/?$/;
  const ITEM_HREF_RE = /\/dashboard\/items\/(\d+)/i;
  const ITEM_MAPPINGS_HEADER_RE = /^item\s*mappings$/i;

  const REQUIRED_HEADERS = [
    "Name",
    "SKU",
    "External Identifier",
    "Item Mappings",
    "Channel Customer Types",
    "Channel Options",
    "Last changed"
  ];

  // Match FareHarbor's native bookability badges (badge-green / badge-error).
  const STATUS_BADGE_CLASS = {
    On: "badge badge-green",
    Off: "badge badge-error",
    Archived: "badge badge-error"
  };

  // Global so Mapping Tools (and other callers) can reuse createStatusLine styling.
  const STYLE_TEXT = `
.fh-item-status {
  margin: 0;
  line-height: 1.4;
  font-size: inherit;
}
.fh-item-status--muted {
  color: #8c959f;
}
`.trim();

  let observer = null;
  let debounceTimer = null;
  let hrefPollTimer = null;
  let lifecycleEvalTimer = null;
  let retryTimer = null;
  let retryStartedAt = 0;
  let lastTrackedHref = location.href;
  let watchersActive = false;
  let routeWatchersStarted = false;
  let scanInProgress = false;
  let fetchGeneration = 0;
  let featureEnabled = true;

  /** @type {Map<string, string>} */
  const statusCache = new Map();
  /** @type {Map<string, Promise<string>>} */
  const inflightFetches = new Map();
  let lastAppliedState = {
    pageKey: null,
    itemIdSetKey: null,
    populated: false
  };

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function parseNumericChannelCompanyPageContext(pathname) {
    const normalized = String(pathname || "").replace(/\/+$/, "");
    if (!normalized || /\/items\/\d+/.test(normalized)) {
      return null;
    }

    const numericMatch = normalized.match(CHANNEL_COMPANY_NUMERIC_RE);
    if (!numericMatch) {
      return null;
    }

    const parts = normalized.split("/").filter(Boolean);
    return {
      companyShortname: parts[0],
      channelId: numericMatch[1]
    };
  }

  function buildStatusCacheKey(companyShortname, itemId) {
    return `${companyShortname}|${itemId}`;
  }

  function getItemStatus(item) {
    if (!item || typeof item !== "object") {
      return UNKNOWN_TEXT;
    }
    if (item.is_archived === true) {
      return "Archived";
    }
    if (item.is_archived !== false) {
      return UNKNOWN_TEXT;
    }
    if (item.is_private === true) {
      return "Off";
    }
    if (item.is_private === false) {
      return "On";
    }
    return UNKNOWN_TEXT;
  }

  function extractMappedItemIdsFromCell(cell) {
    if (!cell) {
      return [];
    }
    const ids = [];
    const links = cell.querySelectorAll('a[href*="/dashboard/items/"]');
    for (const link of links) {
      const href = link.getAttribute("href") || "";
      const match = href.match(ITEM_HREF_RE);
      if (match) {
        ids.push(match[1]);
      }
    }
    return ids;
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function parsePageContext() {
    return parseNumericChannelCompanyPageContext(location.pathname || "");
  }

  function isUrlEligible() {
    return isFareHarborHost() && !!parsePageContext();
  }

  function buildPageKey(ctx) {
    if (!ctx) {
      return null;
    }
    return `${ctx.companyShortname}|${ctx.channelId}`;
  }

  function buildItemIdSetKey(itemIds) {
    return [...new Set(itemIds)].sort().join("|");
  }

  function clearPageCaches() {
    statusCache.clear();
    inflightFetches.clear();
    lastAppliedState = {
      pageKey: null,
      itemIdSetKey: null,
      populated: false
    };
  }

  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = STYLE_TEXT;
    (document.head || document.documentElement).appendChild(style);
  }

  function getRowCells(row) {
    return [...row.children].filter(
      (el) => el.tagName === "TD" || el.tagName === "TH"
    );
  }

  function normalizeCellText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function isChannelItemsTable(table) {
    const headerText = table.querySelector("thead")?.innerText || "";
    return REQUIRED_HEADERS.every((header) => headerText.includes(header));
  }

  function findChannelItemsTable(root) {
    const scope = root || document;
    const selectors = [
      'table[ng-if="resellerItems.length"]',
      'table[ng-table="resellerItems"]',
      'table[ng-controller*="ResellerItemsController"]',
      "table.reseller-items-table",
      'table.spreadsheet[ng-if="resellerItems.length"]',
      'table[ng-table*="resellerItems"]'
    ];

    for (const selector of selectors) {
      const table = scope.querySelector(selector);
      if (table && isChannelItemsTable(table)) {
        return table;
      }
    }

    const tables = scope.querySelectorAll("table");
    for (const table of tables) {
      if (!isChannelItemsTable(table)) {
        continue;
      }
      if (table.querySelector('tbody[ng-repeat*="resellerItem"]')) {
        return table;
      }
    }

    return null;
  }

  /**
   * True for any extension-injected Channel Items column cell
   * (Item Status, Ticket Scanning, Google Location, …).
   */
  function isAnyExtensionColumnCell(el) {
    if (!(el instanceof Element)) {
      return false;
    }
    for (const attr of el.getAttributeNames()) {
      if (
        attr.startsWith("data-fh-") &&
        attr.endsWith("-column") &&
        el.getAttribute(attr) === "true"
      ) {
        return true;
      }
    }
    return false;
  }

  // Keep sibling extension columns (e.g. Google Location) so index/placement
  // math stays aligned with the live DOM; only omit this module's own cells.
  function getNativeRowCells(row) {
    return getRowCells(row).filter(
      (cell) => cell.getAttribute(COLUMN_ATTR) !== "true"
    );
  }

  function findItemMappingsIndex(cells) {
    return cells.findIndex((cell) =>
      ITEM_MAPPINGS_HEADER_RE.test(normalizeCellText(cell.textContent))
    );
  }

  function isExtensionNode(node) {
    if (!(node instanceof Element)) {
      const parent = node?.parentElement;
      return parent ? isExtensionNode(parent) : false;
    }
    if (isAnyExtensionColumnCell(node)) {
      return true;
    }
    let parent = node.parentElement;
    while (parent) {
      if (isAnyExtensionColumnCell(parent)) {
        return true;
      }
      parent = parent.parentElement;
    }
    return false;
  }

  function isExtensionMutation(mutation) {
    if (isExtensionNode(mutation.target)) {
      return true;
    }
    for (const node of mutation.addedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    for (const node of mutation.removedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    return false;
  }

  function removeInjectedColumns() {
    document.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
      cell.remove();
    });
  }

  function applyFeatureSetting(enabled, reason) {
    featureEnabled = enabled !== false;
    if (!featureEnabled) {
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }
    evaluateLifecycle(reason || "setting-enabled");
  }

  function initSettingsBinding() {
    const settings = window.FHSettings;
    if (!settings) {
      return;
    }
    settings.get(SETTING_KEY, (value) => {
      applyFeatureSetting(value, "settings-init");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SETTING_KEY]) {
        applyFeatureSetting(changes[SETTING_KEY].newValue, "setting-change");
      }
    });
  }

  function createHeaderCell(referenceCell) {
    const tagName =
      referenceCell?.tagName === "TD" || referenceCell?.tagName === "td"
        ? "td"
        : "th";
    const cell = document.createElement(tagName);
    cell.setAttribute(COLUMN_ATTR, "true");
    cell.textContent = HEADER_TEXT;
    if (referenceCell?.className) {
      cell.className = referenceCell.className;
    }
    return cell;
  }

  function createStatusLine(label, statusKey) {
    const p = document.createElement("p");
    p.className = "fh-item-status";
    const badgeClass = STATUS_BADGE_CLASS[statusKey];
    if (badgeClass) {
      const badge = document.createElement("span");
      badge.className = badgeClass;
      badge.textContent = label;
      p.appendChild(badge);
      return p;
    }
    p.classList.add("fh-item-status--muted");
    p.textContent = label;
    return p;
  }

  function renderStatusCell(cell, itemIds, companyShortname) {
    cell.replaceChildren();

    if (!itemIds.length) {
      cell.appendChild(createStatusLine(MISSING_TEXT, "Unknown"));
      return;
    }

    for (const itemId of itemIds) {
      const cacheKey = buildStatusCacheKey(companyShortname, itemId);
      if (!statusCache.has(cacheKey)) {
        cell.appendChild(createStatusLine(LOADING_TEXT, "Loading"));
        continue;
      }
      const status = statusCache.get(cacheKey) || UNKNOWN_TEXT;
      cell.appendChild(createStatusLine(status, status));
    }
  }

  function createBodyCell(itemIds, companyShortname) {
    const cell = document.createElement("td");
    cell.setAttribute(COLUMN_ATTR, "true");
    cell.className = "prose prose--compact";
    if (itemIds.length) {
      cell.setAttribute(ITEM_IDS_ATTR, itemIds.join(","));
    }
    renderStatusCell(cell, itemIds, companyShortname);
    return cell;
  }

  function cellHasFinalValue(cell) {
    if (!cell) {
      return false;
    }
    const lines = [...cell.querySelectorAll(".fh-item-status")];
    if (!lines.length) {
      const text = (cell.textContent || "").trim();
      return text !== LOADING_TEXT && text !== "";
    }
    return lines.every((line) => {
      const text = (line.textContent || "").trim();
      return text !== LOADING_TEXT && text !== "";
    });
  }

  /**
   * Reuse existing injected cells when placement is already correct.
   * Refreshes mapped item ids from the Item Mappings cell without DOM churn.
   */
  function collectExistingDescriptors(table, ctx) {
    ensureStyles();
    const descriptors = [];
    const companyShortname = ctx?.companyShortname || "";
    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return descriptors;
    }

    const nativeHeaderCells = getNativeRowCells(headerRow);
    const mappingsHeaderIdx = findItemMappingsIndex(nativeHeaderCells);
    if (mappingsHeaderIdx < 0) {
      return descriptors;
    }

    table.querySelectorAll("tbody tr").forEach((row) => {
      const cell = row.querySelector(`[${COLUMN_ATTR}="true"]`);
      if (!cell) {
        return;
      }
      const nativeRowCells = getNativeRowCells(row);
      const mappingsCell = nativeRowCells[mappingsHeaderIdx];
      const itemIds = extractMappedItemIdsFromCell(mappingsCell);
      if (itemIds.length) {
        cell.setAttribute(ITEM_IDS_ATTR, itemIds.join(","));
      } else {
        cell.removeAttribute(ITEM_IDS_ATTR);
      }
      renderStatusCell(cell, itemIds, companyShortname);
      if (itemIds.length) {
        descriptors.push({ itemIds, cell });
      }
    });

    return descriptors;
  }

  function normalizeColumn(table, ctx) {
    ensureStyles();
    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return {
        descriptors: [],
        headerInserted: 0,
        cellsInserted: 0,
        cellsRepositioned: 0
      };
    }

    let headerInserted = 0;
    let cellsInserted = 0;
    let cellsRepositioned = 0;
    const descriptors = [];
    const companyShortname = ctx?.companyShortname || "";

    headerRow.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
      cell.remove();
      cellsRepositioned += 1;
    });

    const nativeHeaderCells = getNativeRowCells(headerRow);
    const mappingsHeaderIdx = findItemMappingsIndex(nativeHeaderCells);
    if (mappingsHeaderIdx < 0) {
      return { descriptors, headerInserted, cellsInserted, cellsRepositioned };
    }

    const mappingsHeader = nativeHeaderCells[mappingsHeaderIdx];
    const headerCell = createHeaderCell(mappingsHeader);
    headerRow.insertBefore(headerCell, mappingsHeader.nextElementSibling);
    headerInserted = 1;

    const rows = table.querySelectorAll("tbody tr");
    rows.forEach((row) => {
      row.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
        cell.remove();
        cellsRepositioned += 1;
      });

      const nativeRowCells = getNativeRowCells(row);
      const mappingsCell = nativeRowCells[mappingsHeaderIdx];
      if (!mappingsCell) {
        return;
      }

      const itemIds = extractMappedItemIdsFromCell(mappingsCell);
      const cell = createBodyCell(itemIds, companyShortname);
      row.insertBefore(cell, mappingsCell.nextElementSibling);
      cellsInserted += 1;

      if (!itemIds.length) {
        return;
      }

      descriptors.push({ itemIds, cell });
    });

    return { descriptors, headerInserted, cellsInserted, cellsRepositioned };
  }

  function rowColumnCorrectlyPlaced(row, mappingsHeaderIdx) {
    const nativeRowCells = getNativeRowCells(row);
    const mappingsCell = nativeRowCells[mappingsHeaderIdx];
    if (!mappingsCell) {
      return false;
    }

    const extensionCell = row.querySelector(`[${COLUMN_ATTR}="true"]`);
    if (!extensionCell) {
      return false;
    }

    return extensionCell.previousElementSibling === mappingsCell;
  }

  function tableNeedsRepair(table) {
    if (!table) {
      return false;
    }

    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return true;
    }

    const nativeHeaderCells = getNativeRowCells(headerRow);
    const mappingsHeaderIdx = findItemMappingsIndex(nativeHeaderCells);
    if (mappingsHeaderIdx < 0) {
      return true;
    }

    const extensionHeaders = headerRow.querySelectorAll(
      `[${COLUMN_ATTR}="true"]`
    );
    if (extensionHeaders.length !== 1) {
      return true;
    }

    const mappingsHeader = nativeHeaderCells[mappingsHeaderIdx];
    if (extensionHeaders[0].previousElementSibling !== mappingsHeader) {
      return true;
    }

    for (const row of table.querySelectorAll("tbody tr")) {
      const extensionCells = row.querySelectorAll(`[${COLUMN_ATTR}="true"]`);
      if (extensionCells.length !== 1) {
        return true;
      }
      if (!rowColumnCorrectlyPlaced(row, mappingsHeaderIdx)) {
        return true;
      }
    }

    return false;
  }

  function collectUniqueItemIds(descriptors) {
    const ids = [];
    const seen = new Set();
    for (const descriptor of descriptors) {
      for (const itemId of descriptor.itemIds) {
        if (!seen.has(itemId)) {
          seen.add(itemId);
          ids.push(itemId);
        }
      }
    }
    return ids;
  }

  function allStatusCellsFinal(table) {
    const cells = [
      ...table.querySelectorAll(`tbody [${COLUMN_ATTR}="true"][${ITEM_IDS_ATTR}]`)
    ];
    if (!cells.length) {
      return false;
    }
    return cells.every(cellHasFinalValue);
  }

  function populateCells(table, companyShortname) {
    table
      .querySelectorAll(`tbody [${COLUMN_ATTR}="true"][${ITEM_IDS_ATTR}]`)
      .forEach((cell) => {
        if (cellHasFinalValue(cell)) {
          return;
        }
        const itemIds = (cell.getAttribute(ITEM_IDS_ATTR) || "")
          .split(",")
          .filter(Boolean);
        renderStatusCell(cell, itemIds, companyShortname);
      });
  }

  async function fetchItemStatus(companyShortname, itemId) {
    const cacheKey = buildStatusCacheKey(companyShortname, itemId);
    if (statusCache.has(cacheKey)) {
      return statusCache.get(cacheKey);
    }

    const inflight = inflightFetches.get(cacheKey);
    if (inflight) {
      return inflight;
    }

    const promise = (async () => {
      const path = `/api/v1/companies/${encodeURIComponent(companyShortname)}/items/${encodeURIComponent(itemId)}/`;
      const url = new URL(path, window.location.origin).href;
      try {
        const resp = await fetch(url, { credentials: "include" });
        if (!resp.ok) {
          log("item status request failed", {
            itemId,
            status: resp.status
          });
          return UNKNOWN_TEXT;
        }

        let json;
        try {
          json = await resp.json();
        } catch {
          log("item status non-JSON response", { itemId });
          return UNKNOWN_TEXT;
        }

        const item = json?.item ?? null;
        return getItemStatus(item);
      } catch (err) {
        log("item status fetch error", {
          itemId,
          error: String(err?.message || err)
        });
        return UNKNOWN_TEXT;
      }
    })();

    inflightFetches.set(cacheKey, promise);
    try {
      const status = await promise;
      statusCache.set(cacheKey, status);
      return status;
    } finally {
      if (inflightFetches.get(cacheKey) === promise) {
        inflightFetches.delete(cacheKey);
      }
    }
  }

  async function mapWithConcurrency(items, concurrency, fn) {
    if (!items.length) {
      return [];
    }
    const results = new Array(items.length);
    let nextIndex = 0;

    async function worker() {
      while (nextIndex < items.length) {
        const index = nextIndex;
        nextIndex += 1;
        results[index] = await fn(items[index], index);
      }
    }

    const workers = Array.from(
      { length: Math.min(concurrency, items.length) },
      () => worker()
    );
    await Promise.all(workers);
    return results;
  }

  async function resolveStatuses(ctx, itemIds, onItemResolved) {
    const idsToFetch = itemIds.filter(
      (id) => !statusCache.has(buildStatusCacheKey(ctx.companyShortname, id))
    );

    if (!idsToFetch.length) {
      return;
    }

    log("fetching item statuses", {
      company: ctx.companyShortname,
      channelId: ctx.channelId,
      itemCount: idsToFetch.length
    });

    await mapWithConcurrency(idsToFetch, MAX_CONCURRENCY, async (itemId) => {
      await fetchItemStatus(ctx.companyShortname, itemId);
      if (typeof onItemResolved === "function") {
        onItemResolved(itemId);
      }
    });
  }

  function shouldFullySkipScan(ctx, descriptors, table) {
    if (!ctx || !descriptors.length || !table) {
      return false;
    }

    if (tableNeedsRepair(table)) {
      return false;
    }

    if (!allStatusCellsFinal(table)) {
      return false;
    }

    const pageKey = buildPageKey(ctx);
    const itemIdSetKey = buildItemIdSetKey(collectUniqueItemIds(descriptors));

    if (
      lastAppliedState.pageKey === pageKey &&
      lastAppliedState.itemIdSetKey === itemIdSetKey &&
      lastAppliedState.populated
    ) {
      return true;
    }

    return collectUniqueItemIds(descriptors).every((id) =>
      statusCache.has(buildStatusCacheKey(ctx.companyShortname, id))
    );
  }

  function descriptorsNeedFetch(ctx, descriptors) {
    if (!ctx || !descriptors.length) {
      return false;
    }
    return collectUniqueItemIds(descriptors).some(
      (id) => !statusCache.has(buildStatusCacheKey(ctx.companyShortname, id))
    );
  }

  async function scanTable(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return false;
    }

    const table = findChannelItemsTable(document);
    if (!table) {
      return false;
    }

    if (scanInProgress) {
      return false;
    }

    scanInProgress = true;
    const generation = ++fetchGeneration;
    let didWork = false;

    try {
      const ctx = parsePageContext();
      const needsRepair = tableNeedsRepair(table);
      const normalizeResult = needsRepair
        ? normalizeColumn(table, ctx)
        : {
            descriptors: collectExistingDescriptors(table, ctx),
            headerInserted: 0,
            cellsInserted: 0,
            cellsRepositioned: 0
          };
      const { descriptors, headerInserted, cellsInserted, cellsRepositioned } =
        normalizeResult;

      if (headerInserted > 0 || cellsInserted > 0 || cellsRepositioned > 0) {
        log("Item Status column normalized", {
          reason,
          rowCount: descriptors.length,
          headerInserted,
          cellsInserted,
          cellsRepositioned
        });
      }

      didWork =
        headerInserted > 0 || cellsInserted > 0 || cellsRepositioned > 0;

      if (!ctx) {
        return didWork;
      }

      if (!descriptors.length) {
        lastAppliedState = {
          pageKey: buildPageKey(ctx),
          itemIdSetKey: "",
          populated: true
        };
        stopRetryLoop();
        return didWork;
      }

      const uniqueItemIds = collectUniqueItemIds(descriptors);

      if (shouldFullySkipScan(ctx, descriptors, table)) {
        populateCells(table, ctx.companyShortname);
        return didWork;
      }

      populateCells(table, ctx.companyShortname);

      if (!descriptorsNeedFetch(ctx, descriptors)) {
        lastAppliedState = {
          pageKey: buildPageKey(ctx),
          itemIdSetKey: buildItemIdSetKey(uniqueItemIds),
          populated: allStatusCellsFinal(table)
        };
        if (lastAppliedState.populated) {
          stopRetryLoop();
        }
        return didWork;
      }

      await resolveStatuses(ctx, uniqueItemIds, () => {
        if (generation !== fetchGeneration) {
          return;
        }
        populateCells(table, ctx.companyShortname);
      });
      if (generation !== fetchGeneration) {
        return didWork;
      }

      populateCells(table, ctx.companyShortname);
      lastAppliedState = {
        pageKey: buildPageKey(ctx),
        itemIdSetKey: buildItemIdSetKey(uniqueItemIds),
        populated: allStatusCellsFinal(table)
      };

      if (lastAppliedState.populated) {
        stopRetryLoop();
      }

      return didWork;
    } finally {
      scanInProgress = false;
    }
  }

  function scheduleScan(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }
    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      scanTable(reason || "debounced-scan");
    }, SCAN_DEBOUNCE_MS);
  }

  function stopRetryLoop() {
    if (retryTimer) {
      clearInterval(retryTimer);
      retryTimer = null;
    }
    retryStartedAt = 0;
  }

  function startRetryLoop(reason) {
    if (!isUrlEligible()) {
      stopRetryLoop();
      return;
    }

    if (!retryTimer) {
      retryStartedAt = Date.now();
      retryTimer = setInterval(async () => {
        const elapsed = Date.now() - retryStartedAt;
        const found = await scanTable("retry-loop");
        if (found) {
          stopRetryLoop();
          return;
        }
        if (elapsed >= RETRY_MAX_MS) {
          stopRetryLoop();
        }
      }, RETRY_INTERVAL_MS);
    }

    scheduleScan(reason || "retry-schedule");
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    stopRetryLoop();
    clearPageCaches();
    fetchGeneration += 1;
    scanInProgress = false;
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  function evaluateLifecycle(reason) {
    if (!featureEnabled) {
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }

    if (!isUrlEligible()) {
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }

    if (!watchersActive) {
      log("eligible page detected", { reason, href: location.href });
      startObserver();
      watchersActive = true;
    }

    startRetryLoop(reason || "lifecycle");
  }

  function onRouteChange(reason) {
    const nextHref = location.href;
    if (nextHref !== lastTrackedHref) {
      clearPageCaches();
      fetchGeneration += 1;
    }
    lastTrackedHref = nextHref;
    scheduleLifecycleEval(reason || "route-change");
  }

  function startRouteWatchers() {
    if (routeWatchersStarted) {
      return;
    }
    routeWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", () => onRouteChange("popstate"));
    window.addEventListener("hashchange", () => onRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        onRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        onRouteChange("replaceState");
        return result;
      };
    } catch (err) {
      log("history hook unavailable:", err);
    }

    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        onRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  function startObserver() {
    if (observer) {
      return;
    }

    observer = new MutationObserver((mutations) => {
      if (!isUrlEligible()) {
        return;
      }
      if (mutations.length > 0 && mutations.every(isExtensionMutation)) {
        return;
      }
      scheduleScan("mutation-observer");
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }

  function init() {
    if (!isFareHarborHost()) {
      return;
    }

    initSettingsBinding();
    startRouteWatchers();
    evaluateLifecycle("init");

    if (document.readyState === "loading") {
      document.addEventListener(
        "DOMContentLoaded",
        () => evaluateLifecycle("dom-content-loaded"),
        { once: true }
      );
    }
  }

  // Exported for Mapping Tools reuse, unit-test mirroring, and debugging.
  window.FareHarborItemStatusColumn = {
    getItemStatus,
    extractMappedItemIdsFromCell,
    buildStatusCacheKey,
    parseNumericChannelCompanyPageContext,
    fetchItemStatus,
    createStatusLine,
    ensureStyles,
    MISSING_TEXT,
    LOADING_TEXT,
    UNKNOWN_TEXT
  };

  init();
})();
