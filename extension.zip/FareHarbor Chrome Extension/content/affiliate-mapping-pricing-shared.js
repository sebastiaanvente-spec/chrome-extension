console.log("[affiliate-mapping-pricing] affiliate-mapping-pricing-shared.js loaded");

(function initializeAffiliateMappingPricingShared() {
  "use strict";

  const LOG_PREFIX = "[affiliate-mapping-pricing]";
  const CONCURRENCY_LIMIT = 4;

  const INTEGRATION_MATCH_TOKENS = {
    viator: ["viator"]
  };

  const CUSTOMER_TYPE_PRIORITY_ORDER = [
    "Adult",
    "Child",
    "Youth",
    "Infant",
    "Senior",
    "Student",
    "EU Citizen",
    "EU Citizen Student",
    "Military",
    "Group"
  ];

  const RESELLER_CHANNEL_ITEM_PATH_RE = /\/integrations\/channels\/(\d+)\/items\/(\d+)/;
  const LEGACY_RESELLER_ITEM_PATH_RE = /\/reseller-companies\/(\d+)\/reseller-items\/(\d+)/;

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function isBlankValue(value) {
    return value === null || value === undefined || value === "";
  }

  function toNumberOrNull(value) {
    if (isBlankValue(value)) return null;
    const num = Number(value);
    return Number.isNaN(num) ? null : num;
  }

  function normalizeName(value) {
    if (typeof value !== "string") return null;
    const trimmed = value.trim();
    return trimmed !== "" ? trimmed : null;
  }

  function normalizeAffiliateShortnameForMatch(value) {
    if (typeof value !== "string") return null;
    const trimmed = value.trim().toLowerCase();
    if (!trimmed) return null;
    return trimmed.replace(/[\s\-_]/g, "");
  }

  function getAffiliateCompanyShortnameRaw(affiliate) {
    const ac = affiliate?.affiliate_company ?? affiliate?.affiliateCompany ?? {};
    return typeof ac.shortname === "string" ? ac.shortname.trim() : null;
  }

  function affiliateMatchesIntegrationTokens(affiliate, normalizedTokens) {
    const normalizedShortname = normalizeAffiliateShortnameForMatch(
      getAffiliateCompanyShortnameRaw(affiliate)
    );
    if (!normalizedShortname) return false;
    return normalizedTokens.some((token) => normalizedShortname.includes(token));
  }

  function isExactAffiliateTokenMatch(affiliate, normalizedTokens) {
    const normalizedShortname = normalizeAffiliateShortnameForMatch(
      getAffiliateCompanyShortnameRaw(affiliate)
    );
    if (!normalizedShortname) return false;
    return normalizedTokens.some((token) => normalizedShortname === token);
  }

  function dedupePreservingOrder(values) {
    const seen = new Set();
    const result = [];
    for (const value of values || []) {
      if (value === null || value === undefined) continue;
      const key = String(value);
      if (seen.has(key)) continue;
      seen.add(key);
      result.push(value);
    }
    return result;
  }

  function reorderCustomerTypeNames(customerTypes) {
    if (!customerTypes || customerTypes.length === 0) return customerTypes;
    const priorityOrderLower = CUSTOMER_TYPE_PRIORITY_ORDER.map((type) => type.toLowerCase());
    const knownTypes = [];
    const unknownTypes = [];

    customerTypes.forEach((customerType) => {
      const lowerCaseType = String(customerType).toLowerCase();
      const priorityIndex = priorityOrderLower.indexOf(lowerCaseType);
      if (priorityIndex !== -1) {
        knownTypes.push({ original: customerType, priority: priorityIndex });
      } else {
        unknownTypes.push(customerType);
      }
    });

    knownTypes.sort((a, b) => a.priority - b.priority);
    unknownTypes.sort((a, b) => String(a).toLowerCase().localeCompare(String(b).toLowerCase()));
    return [...knownTypes.map((item) => item.original), ...unknownTypes];
  }

  function reorderMappedCustomerTypes(mappedCustomerTypes) {
    if (!mappedCustomerTypes || mappedCustomerTypes.length === 0) return mappedCustomerTypes;
    const names = mappedCustomerTypes.map((entry) => entry.displayName || entry.name).filter(Boolean);
    const reorderedNames = reorderCustomerTypeNames(names);
    const byName = new Map();
    mappedCustomerTypes.forEach((entry) => {
      const name = entry.displayName || entry.name;
      if (name && !byName.has(name)) {
        byName.set(name, entry);
      }
    });
    return reorderedNames.map((name) => byName.get(name)).filter(Boolean);
  }

  function dedupeMappedCustomerTypesById(mappedTypes) {
    const seen = new Set();
    const result = [];
    for (const entry of mappedTypes || []) {
      const key =
        entry.customerTypePk != null
          ? `type:${entry.customerTypePk}`
          : entry.customerPrototypePk != null
            ? `proto:${entry.customerPrototypePk}`
            : `name:${entry.name || entry.displayName || ""}`;
      if (seen.has(key)) continue;
      seen.add(key);
      result.push(entry);
    }
    return reorderMappedCustomerTypes(result);
  }

  function escapeTsvField(field) {
    if (field === null || field === undefined) return "";
    const str = String(field).trim();
    return str.replace(/[\t\n\r]/g, " ");
  }

  function escapeHtmlText(text) {
    if (text === null || text === undefined) return "";
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function serializeTsvTable(rows) {
    if (!Array.isArray(rows) || rows.length === 0) return "";
    const expectedColumnCount = rows[0].length;
    const invalidRows = rows.filter((row) => row.length !== expectedColumnCount);
    if (invalidRows.length > 0) {
      throw new Error(
        `TSV row width mismatch: expected ${expectedColumnCount} columns in every row`
      );
    }
    return rows.map((row) => row.map(escapeTsvField).join("\t")).join("\n");
  }

  async function apiGetJson(url) {
    try {
      const response = await fetch(url, {
        method: "GET",
        credentials: "include",
        headers: { Accept: "application/json" }
      });
      if (!response.ok) {
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `API request failed with status ${response.status}`
        };
      }
      try {
        const data = await response.json();
        return { ok: true, status: response.status, data, error: null };
      } catch (err) {
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `Response is not valid JSON: ${err.message}`
        };
      }
    } catch (err) {
      return { ok: false, status: null, data: null, error: `Fetch failed: ${err.message}` };
    }
  }

  async function fetchCompanyData(company) {
    const url = `/api/v1/companies/${encodeURIComponent(company)}/`;
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, company: null, error: result.error };
    }
    const companyData = result.data?.company ?? result.data ?? null;
    if (!companyData || typeof companyData !== "object") {
      return { ok: false, company: null, error: "Response missing company object" };
    }
    return { ok: true, company: companyData, error: null };
  }

  function getProcessorCurrency(companyData) {
    if (!companyData || typeof companyData !== "object") return null;
    const currency = companyData.processor_currency ?? companyData.processorCurrency ?? null;
    if (isBlankValue(currency)) return null;
    return String(currency).toLowerCase().trim();
  }

  function formatCurrencyAmount(amount, processorCurrency) {
    if (isBlankValue(amount)) return "unknown";
    const num = Number(amount);
    if (Number.isNaN(num)) return "unknown";
    const formatted = num.toFixed(2);
    if (isBlankValue(processorCurrency)) return formatted;
    const currency = String(processorCurrency).toLowerCase().trim();
    if (currency === "eur") return `€${formatted}`;
    if (currency === "usd") return `$${formatted}`;
    if (currency) return `${currency.toUpperCase()} ${formatted}`;
    return formatted;
  }

  function normalizeUniqueSortedPrices(values) {
    const numericValues = [];
    for (const value of values || []) {
      if (isBlankValue(value)) continue;
      const num = toNumberOrNull(value);
      if (num === null) continue;
      numericValues.push(num);
    }
    if (numericValues.length === 0) return [];
    const unique = [...new Set(numericValues)];
    unique.sort((a, b) => a - b);
    return unique;
  }

  function formatAggregatedPriceDisplay(prices, processorCurrency) {
    const uniqueSorted = normalizeUniqueSortedPrices(prices);
    if (uniqueSorted.length === 0) return "unknown";
    if (uniqueSorted.length === 1) {
      return formatCurrencyAmount(uniqueSorted[0], processorCurrency);
    }
    return uniqueSorted.map((price) => formatCurrencyAmount(price, processorCurrency)).join(" / ");
  }

  function getTotalPricingResolution() {
    return window.FareHarborTotalPricingResolution ?? null;
  }

  function getPricingObjectPk(pricingObject) {
    const resolver = getTotalPricingResolution();
    if (resolver?.getPricingObjectPk) {
      return resolver.getPricingObjectPk(pricingObject);
    }
    if (!pricingObject || typeof pricingObject !== "object") return null;
    if (pricingObject.pk !== null && pricingObject.pk !== undefined) return pricingObject.pk;
    const uri = String(pricingObject.uri ?? "");
    const sheetMatch = uri.match(/total-sheets\/(\d+)/i);
    if (sheetMatch) return sheetMatch[1];
    const scheduleMatch = uri.match(/total-schedules\/(\d+)/i);
    if (scheduleMatch) return scheduleMatch[1];
    return null;
  }

  function getPricingObjectType(pricingObject) {
    const resolver = getTotalPricingResolution();
    if (resolver?.getPricingObjectType) {
      return resolver.getPricingObjectType(pricingObject);
    }
    if (!pricingObject || typeof pricingObject !== "object") return null;
    const cls = String(pricingObject.cls ?? "").trim();
    if (cls === "TotalSheet" || cls === "total_sheet" || cls === "Total Sheet") return "sheet";
    if (cls === "TotalSchedule" || cls === "total_schedule" || cls === "Total Schedule") {
      return "schedule";
    }
    const uri = String(pricingObject.uri ?? "");
    if (uri.includes("/total-sheets/")) return "sheet";
    if (uri.includes("/total-schedules/")) return "schedule";
    return null;
  }

  function getPricingObjectDisplayName(pricingObject) {
    if (!pricingObject) return "unknown";
    return (
      pricingObject.display_name ??
      pricingObject.displayName ??
      pricingObject.name ??
      pricingObject.unicode ??
      (getPricingObjectPk(pricingObject) != null
        ? `${getPricingObjectType(pricingObject) === "schedule" ? "Schedule" : "Sheet"} ${getPricingObjectPk(pricingObject)}`
        : "unknown")
    );
  }

  function isAssignedPricingObject(pricingObject) {
    if (!pricingObject || typeof pricingObject !== "object") return false;
    return getPricingObjectPk(pricingObject) != null || Boolean(pricingObject.uri);
  }

  function resolveAssignedPricing(affiliateListRow, affiliationDetail) {
    const candidates = [
      {
        source: "totalPricingObject",
        obj: affiliateListRow?.totalPricingObject ?? affiliateListRow?.total_pricing_object ?? null
      },
      {
        source: "default_total_sheet",
        obj: affiliationDetail?.default_total_sheet ?? affiliationDetail?.defaultTotalSheet ?? null
      },
      {
        source: "default_total_schedule",
        obj: affiliationDetail?.default_total_schedule ?? affiliationDetail?.defaultTotalSchedule ?? null
      }
    ];

    for (const candidate of candidates) {
      if (!isAssignedPricingObject(candidate.obj)) continue;
      const type = getPricingObjectType(candidate.obj);
      const pk = getPricingObjectPk(candidate.obj);
      return {
        pricingObject: candidate.obj,
        type,
        pk,
        source: candidate.source,
        displayName: getPricingObjectDisplayName(candidate.obj)
      };
    }
    return null;
  }

  async function fetchAllNetworkAffiliates(company) {
    try {
      const allResults = [];
      let page = 1;
      let totalPages = 1;

      while (page <= totalPages) {
        const url =
          `/api-affiliations-v2/companies/${encodeURIComponent(company)}/affiliates/` +
          `?page=${page}&page_size=50`;
        const result = await apiGetJson(url);
        if (!result.ok) {
          return { ok: false, affiliates: null, error: result.error };
        }
        const data = result.data;
        if (!data || typeof data !== "object") {
          return { ok: false, affiliates: null, error: "Affiliates API response is not a valid object" };
        }
        if (page === 1) {
          const reportedTotalPages = Number(data.total_pages);
          totalPages =
            Number.isFinite(reportedTotalPages) && reportedTotalPages >= 1 ? reportedTotalPages : 1;
        }
        const pageResults = data.results;
        if (!Array.isArray(pageResults)) {
          return { ok: false, affiliates: null, error: "Affiliates API response missing results array" };
        }
        allResults.push(...pageResults);
        page += 1;
      }
      return { ok: true, affiliates: allResults, error: null };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      return { ok: false, affiliates: null, error: message };
    }
  }

  async function fetchAffiliateDetail(company, affiliationPk) {
    const url = `/api/v1/companies/${encodeURIComponent(company)}/affiliates/${encodeURIComponent(affiliationPk)}/`;
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, detail: null, error: result.error };
    }
    const detail = result.data?.affiliation ?? null;
    if (!detail || typeof detail !== "object") {
      return { ok: false, detail: null, error: "Affiliate detail response missing affiliation object" };
    }
    return { ok: true, detail, error: null };
  }

  function findAffiliateByIntegration(affiliates, integrationKey) {
    const tokens = INTEGRATION_MATCH_TOKENS[integrationKey];
    if (!Array.isArray(tokens) || tokens.length === 0) return null;
    const normalizedTokens = tokens
      .map((token) => normalizeAffiliateShortnameForMatch(token))
      .filter((token) => token !== null);
    const matches = (affiliates || []).filter((affiliate) =>
      affiliateMatchesIntegrationTokens(affiliate, normalizedTokens)
    );
    if (matches.length === 0) return null;
    const exactMatches = matches.filter((affiliate) =>
      isExactAffiliateTokenMatch(affiliate, normalizedTokens)
    );
    const selectedPool = exactMatches.length > 0 ? exactMatches : matches;
    return selectedPool[0] || null;
  }

  async function findAffiliateAffiliation(company, integrationKey) {
    const listResult = await fetchAllNetworkAffiliates(company);
    if (!listResult.ok) {
      return {
        ok: false,
        affiliation: null,
        affiliateListRow: null,
        assignedPricing: null,
        error: listResult.error
      };
    }

    const affiliateListRow = findAffiliateByIntegration(listResult.affiliates, integrationKey);
    if (!affiliateListRow) {
      return {
        ok: false,
        affiliation: null,
        affiliateListRow: null,
        assignedPricing: null,
        error: `No ${integrationKey} affiliation found`
      };
    }

    const affiliationPk = affiliateListRow?.pk ?? null;
    if (affiliationPk === null || affiliationPk === undefined) {
      return {
        ok: false,
        affiliation: null,
        affiliateListRow,
        assignedPricing: null,
        error: "Affiliate list row is missing pk"
      };
    }

    const detailResult = await fetchAffiliateDetail(company, affiliationPk);
    if (!detailResult.ok) {
      return {
        ok: false,
        affiliation: null,
        affiliateListRow,
        assignedPricing: null,
        error: detailResult.error
      };
    }

    const assignedPricing = resolveAssignedPricing(affiliateListRow, detailResult.detail);
    return {
      ok: true,
      affiliation: detailResult.detail,
      affiliateListRow,
      assignedPricing,
      error: null
    };
  }

  function extractTotalSheetsFromSchedule(schedule) {
    const resolver = getTotalPricingResolution();
    if (resolver?.extractTotalSheetsFromSchedule) {
      return resolver.extractTotalSheetsFromSchedule(schedule);
    }
    return [];
  }

  async function fetchTotalScheduleDetail(company, schedulePk) {
    const url =
      `/api/v1/companies/${encodeURIComponent(company)}/total-schedules/${encodeURIComponent(schedulePk)}/`;
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, schedule: null, error: result.error };
    }
    const schedule = result.data?.total_schedule ?? result.data?.schedule ?? result.data ?? null;
    if (!schedule || typeof schedule !== "object") {
      return { ok: false, schedule: null, error: "Response missing total schedule object" };
    }
    return { ok: true, schedule, error: null };
  }

  async function resolveTotalScheduleWithSheets(company, schedulePk) {
    const detailResult = await fetchTotalScheduleDetail(company, schedulePk);
    let schedule = detailResult.ok ? detailResult.schedule : null;
    if (schedule) {
      const sheets = extractTotalSheetsFromSchedule(schedule);
      if (sheets.length > 0) {
        return { ok: true, schedule, sheets, error: null };
      }
    }
    return {
      ok: false,
      schedule,
      sheets: [],
      error: detailResult.error || "No total sheets found in schedule"
    };
  }

  async function fetchPricingForEditing(company, totalSheetPk, itemId) {
    const url =
      `/api/v1/companies/${encodeURIComponent(company)}/total-sheets/${encodeURIComponent(totalSheetPk)}` +
      `/pricing-for-editing/Item/${encodeURIComponent(itemId)}/`;
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, pricing: null, error: result.error };
    }
    return { ok: true, pricing: result.data, error: null };
  }

  async function resolveAffiliatePriceSheets(company, assignedPricing) {
    if (!assignedPricing) {
      return { ok: false, sheets: [], error: "No assigned pricing" };
    }

    if (assignedPricing.type === "sheet") {
      if (assignedPricing.pk == null) {
        return { ok: false, sheets: [], error: "Assigned sheet missing pk" };
      }
      return {
        ok: true,
        sheets: [
          {
            pk: String(assignedPricing.pk),
            name: assignedPricing.displayName || getPricingObjectDisplayName(assignedPricing.pricingObject)
          }
        ],
        error: null
      };
    }

    if (assignedPricing.type === "schedule") {
      if (assignedPricing.pk == null) {
        return { ok: false, sheets: [], error: "Assigned schedule missing pk" };
      }
      const scheduleResult = await resolveTotalScheduleWithSheets(company, assignedPricing.pk);
      if (!scheduleResult.ok || scheduleResult.sheets.length === 0) {
        return {
          ok: false,
          sheets: [],
          error: scheduleResult.error || "Could not resolve schedule sheets"
        };
      }
      return {
        ok: true,
        sheets: scheduleResult.sheets.map((sheet) => ({
          pk: String(sheet.pk),
          name: sheet.name || getPricingObjectDisplayName(sheet.sheet)
        })),
        error: null
      };
    }

    return { ok: false, sheets: [], error: "Unknown assigned pricing type" };
  }

  function buildDisambiguatedSheetHeaders(sheets) {
    const labelCounts = new Map();
    for (const sheet of sheets || []) {
      const base = escapeTsvField(sheet.name || `Sheet ${sheet.pk}`);
      labelCounts.set(base, (labelCounts.get(base) || 0) + 1);
    }

    return (sheets || []).map((sheet) => {
      const base = escapeTsvField(sheet.name || `Sheet ${sheet.pk}`);
      if ((labelCounts.get(base) || 0) > 1) {
        return `${base} [${sheet.pk}]`;
      }
      return base;
    });
  }

  function parseCompanyShortnameFromPathname(pathname) {
    const parts = String(pathname || "").split("/").filter(Boolean);
    return parts[0] || null;
  }

  function matchResellerIdsFromText(text) {
    if (!text) return null;
    const value = String(text);
    const channelMatch = value.match(RESELLER_CHANNEL_ITEM_PATH_RE);
    if (channelMatch) {
      return { resellerCompanyId: channelMatch[1], resellerItemId: channelMatch[2] };
    }
    const legacyMatch = value.match(LEGACY_RESELLER_ITEM_PATH_RE);
    if (legacyMatch) {
      return { resellerCompanyId: legacyMatch[1], resellerItemId: legacyMatch[2] };
    }
    return null;
  }

  function parseResellerItemContextFromUrl(url) {
    const raw = String(url || "").trim();
    if (!raw) return null;
    let pathname = raw;
    try {
      if (/^https?:\/\//i.test(raw)) {
        pathname = new URL(raw).pathname;
      } else {
        pathname = raw.split("?")[0].split("#")[0];
      }
    } catch {
      pathname = raw.split("?")[0].split("#")[0];
    }
    const ids = matchResellerIdsFromText(pathname);
    if (!ids) return null;
    return {
      company: parseCompanyShortnameFromPathname(pathname),
      resellerCompanyId: ids.resellerCompanyId,
      resellerItemId: ids.resellerItemId
    };
  }

  function extractResellerContextFromScrapedRows(scrapedRows) {
    for (const row of scrapedRows || []) {
      if (row?.resellerCompanyId != null && row?.resellerItemId != null) {
        return {
          company: row.company || null,
          resellerCompanyId: String(row.resellerCompanyId),
          resellerItemId: String(row.resellerItemId),
          resellerItemUrl: row.resellerItemUrl || null
        };
      }
      const candidates = [row?.resellerItemUrl, row?.itemLabelHTML, row?.itemHref];
      for (const candidate of candidates) {
        if (!candidate) continue;
        const parsed = parseResellerItemContextFromUrl(String(candidate));
        if (parsed?.resellerCompanyId && parsed?.resellerItemId) {
          return {
            company: parsed.company,
            resellerCompanyId: parsed.resellerCompanyId,
            resellerItemId: parsed.resellerItemId,
            resellerItemUrl: String(candidate)
          };
        }
      }
    }
    return null;
  }

  function parseCompanyShortnameFromPage() {
    const parts = (window.location.pathname || "").split("/").filter(Boolean);
    return parts[0] || null;
  }

  function resolveCompanyFromRows(scrapedRows) {
    for (const row of scrapedRows || []) {
      if (row?.company) return row.company;
    }
    const context = extractResellerContextFromScrapedRows(scrapedRows);
    if (context?.company) return context.company;
    return parseCompanyShortnameFromPage();
  }

  function buildResellerItemApiBase(company, resellerCompanyId, resellerItemId) {
    return (
      `/api/v1/companies/${encodeURIComponent(company)}` +
      `/reseller-companies/${encodeURIComponent(resellerCompanyId)}` +
      `/reseller-items/${encodeURIComponent(resellerItemId)}`
    );
  }

  async function resolveResellerItemContext(company, itemId, scrapedRows, pageUrl) {
    for (const row of scrapedRows || []) {
      const rowItemId = row.itemId;
      if (itemId && rowItemId && String(rowItemId) !== String(itemId)) continue;
      if (row?.resellerCompanyId != null && row?.resellerItemId != null) {
        return {
          ok: true,
          company: row.company || company,
          resellerCompanyId: String(row.resellerCompanyId),
          resellerItemId: String(row.resellerItemId)
        };
      }
    }

    const fromRows = extractResellerContextFromScrapedRows(scrapedRows);
    if (fromRows?.resellerCompanyId && fromRows?.resellerItemId) {
      return {
        ok: true,
        company: fromRows.company || company,
        resellerCompanyId: fromRows.resellerCompanyId,
        resellerItemId: fromRows.resellerItemId
      };
    }

    const fromUrl = parseResellerItemContextFromUrl(pageUrl || window.location.href);
    if (fromUrl?.resellerCompanyId && fromUrl?.resellerItemId) {
      return {
        ok: true,
        company: fromUrl.company || company,
        resellerCompanyId: fromUrl.resellerCompanyId,
        resellerItemId: fromUrl.resellerItemId
      };
    }

    return { ok: false, error: "Could not resolve reseller item context" };
  }

  function extractRctExternalId(value) {
    if (value == null) return null;
    const text = String(value).trim();
    if (/^rct\S+/i.test(text)) return text;
    const match = text.match(/\brct\S+/i);
    return match ? match[0] : null;
  }

  function normalizeResellerExternalId(value) {
    const extracted = extractRctExternalId(value);
    return extracted ? extracted.toLowerCase() : null;
  }

  function getResellerCustomerTypeExternalId(resellerCustomerType) {
    if (!resellerCustomerType || typeof resellerCustomerType !== "object") return null;
    const scalarCandidates = [
      resellerCustomerType.external_identifier,
      resellerCustomerType.externalIdentifier,
      resellerCustomerType.unicode,
      resellerCustomerType.short_name,
      resellerCustomerType.shortName
    ];
    for (const candidate of scalarCandidates) {
      const extracted = extractRctExternalId(candidate);
      if (extracted) return extracted;
    }
    return null;
  }

  function getResellerCustomerTypeChannelName(resellerCustomerType) {
    if (!resellerCustomerType || typeof resellerCustomerType !== "object") return null;
    return (
      resellerCustomerType.name ??
      resellerCustomerType.display_name ??
      resellerCustomerType.displayName ??
      null
    );
  }

  function getFareHarborCustomerTypeNameFromMapping(mapping) {
    const prototype = mapping?.customer_prototype ?? mapping?.customerPrototype ?? {};
    const customerType = prototype?.customer_type ?? prototype?.customerType ?? {};
    return (
      prototype?.display_name ??
      prototype?.displayName ??
      prototype?.name ??
      customerType?.singular ??
      customerType?.name ??
      customerType?.display_name ??
      customerType?.displayName ??
      null
    );
  }

  function appendLookupEntry(map, key, value) {
    if (!key) return;
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(value);
  }

  function buildResellerCustomerTypeLookup(entries) {
    const byExternalId = new Map();
    const byResellerCustomerTypePk = new Map();
    const byChannelName = new Map();

    for (const entry of entries || []) {
      const { resellerCustomerType, mapping } = entry;
      const prototype = mapping?.customer_prototype ?? mapping?.customerPrototype ?? {};
      const customerType = prototype?.customer_type ?? prototype?.customerType ?? {};
      const resolved = {
        customerPrototypePk: prototype?.pk ?? null,
        customerTypePk: customerType?.pk ?? null,
        fareHarborDisplayName: getFareHarborCustomerTypeNameFromMapping(mapping),
        resellerCustomerTypePk: resellerCustomerType?.pk ?? null,
        channelDisplayName: getResellerCustomerTypeChannelName(resellerCustomerType),
        externalId: getResellerCustomerTypeExternalId(resellerCustomerType)
      };

      if (resolved.externalId) {
        const key = normalizeResellerExternalId(resolved.externalId);
        if (key) appendLookupEntry(byExternalId, key, resolved);
      }
      if (resolved.resellerCustomerTypePk != null) {
        appendLookupEntry(byResellerCustomerTypePk, String(resolved.resellerCustomerTypePk), resolved);
      }
      const channelName = normalizeName(resolved.channelDisplayName);
      if (channelName) appendLookupEntry(byChannelName, channelName, resolved);
    }

    return { byExternalId, byResellerCustomerTypePk, byChannelName, entries: entries || [] };
  }

  async function fetchResellerCustomerTypeMappingsForItem(
    company,
    itemId,
    scrapedRows,
    pageUrl,
    mappingCache
  ) {
    const context = await resolveResellerItemContext(company, itemId, scrapedRows, pageUrl);
    if (!context.ok) {
      return { ok: false, lookup: null, error: context.error, context: null };
    }

    const apiCompany = context.company || company;
    const cacheKey = `${apiCompany}:${context.resellerCompanyId}:${context.resellerItemId}`;
    if (mappingCache?.has(cacheKey)) {
      return mappingCache.get(cacheKey);
    }

    const base = buildResellerItemApiBase(
      apiCompany,
      context.resellerCompanyId,
      context.resellerItemId
    );
    const typesUrl = `${base}/reseller-customer-types/`;
    const typesResult = await apiGetJson(typesUrl);
    if (!typesResult.ok) {
      const failure = { ok: false, lookup: null, error: typesResult.error, context };
      mappingCache?.set(cacheKey, failure);
      return failure;
    }

    const types =
      typesResult.data?.reseller_customer_types ?? typesResult.data?.resellerCustomerTypes ?? [];
    if (!Array.isArray(types)) {
      const failure = {
        ok: false,
        lookup: null,
        error: "Response missing reseller_customer_types array",
        context
      };
      mappingCache?.set(cacheKey, failure);
      return failure;
    }

    const entries = [];
    await Promise.all(
      types.map(async (resellerCustomerType) => {
        const resellerCustomerTypeId = resellerCustomerType?.pk;
        if (resellerCustomerTypeId == null) return;
        const mappingUrl =
          `${base}/reseller-customer-types/${encodeURIComponent(resellerCustomerTypeId)}` +
          `/reseller-customer-type-mappings/`;
        const mappingResult = await apiGetJson(mappingUrl);
        if (!mappingResult.ok) return;
        const mappings =
          mappingResult.data?.reseller_customer_type_mappings ??
          mappingResult.data?.resellerCustomerTypeMappings ??
          [];
        if (!Array.isArray(mappings) || mappings.length === 0) return;
        for (const mapping of mappings) {
          entries.push({ resellerCustomerType, mapping });
        }
      })
    );

    const lookup = buildResellerCustomerTypeLookup(entries);
    const result = { ok: true, lookup, error: null, context, mappingCount: entries.length };
    mappingCache?.set(cacheKey, result);
    return result;
  }

  async function fetchCustomerPrototypes(company, itemId) {
    const url =
      `/api/v1/companies/${encodeURIComponent(company)}/items/${encodeURIComponent(itemId)}` +
      `/customer-prototypes/?include-is-inactive=yes`;
    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, prototypes: null, error: result.error };
    }
    const prototypes = result.data?.customer_prototypes ?? result.data?.customerPrototypes;
    if (!Array.isArray(prototypes)) {
      return { ok: false, prototypes: null, error: "Response missing customer_prototypes array" };
    }
    return { ok: true, prototypes, error: null };
  }

  function getPrototypeCustomerType(prototype) {
    return prototype?.customer_type ?? prototype?.customerType ?? {};
  }

  function findPrototypeByPk(prototypes, pk) {
    if (pk == null) return null;
    for (const prototype of prototypes || []) {
      if (String(prototype?.pk) === String(pk)) return prototype;
    }
    return null;
  }

  function findPrototypeByCustomerTypePk(prototypes, customerTypePk) {
    if (customerTypePk == null) return null;
    for (const prototype of prototypes || []) {
      const customerType = getPrototypeCustomerType(prototype);
      if (String(customerType?.pk) === String(customerTypePk)) return prototype;
    }
    return null;
  }

  function findPrototypeByMappedName(prototypes, displayName) {
    const target = normalizeName(displayName);
    if (!target) return null;
    for (const prototype of prototypes || []) {
      const candidates = [prototype?.display_name, prototype?.displayName, prototype?.name];
      for (const candidate of candidates) {
        if (normalizeName(candidate) === target) return prototype;
      }
    }
    return null;
  }

  function resolveMappingEntriesForChannelCustomerType(mapped, lookup) {
    if (!lookup) return [];
    const asList = (value) => (Array.isArray(value) ? value : value ? [value] : []);
    const externalKey = normalizeResellerExternalId(mapped?.externalId);
    if (externalKey && lookup.byExternalId.has(externalKey)) {
      return asList(lookup.byExternalId.get(externalKey));
    }
    if (mapped?.resellerCustomerTypePk != null) {
      const key = String(mapped.resellerCustomerTypePk);
      if (lookup.byResellerCustomerTypePk.has(key)) {
        return asList(lookup.byResellerCustomerTypePk.get(key));
      }
    }
    const channelName = normalizeName(mapped?.displayName);
    if (channelName && lookup.byChannelName.has(channelName)) {
      return asList(lookup.byChannelName.get(channelName));
    }
    return [];
  }

  function buildMappedCustomerTypeFromEntry(entry, prototypes) {
    if (!entry) return null;
    let prototype = null;
    if (entry.customerPrototypePk != null) {
      prototype = findPrototypeByPk(prototypes, entry.customerPrototypePk);
    }
    if (!prototype && entry.customerTypePk != null) {
      prototype = findPrototypeByCustomerTypePk(prototypes, entry.customerTypePk);
    }
    const name =
      entry.fareHarborDisplayName ??
      prototype?.display_name ??
      prototype?.displayName ??
      prototype?.name ??
      null;
    return {
      name,
      displayName: name,
      customerPrototypePk: entry.customerPrototypePk ?? prototype?.pk ?? null,
      customerTypePk: entry.customerTypePk ?? getPrototypeCustomerType(prototype || {})?.pk ?? null,
      prototype
    };
  }

  function resolvePrototypeForChannelCustomerType(mapped, prototypes, lookup) {
    const result = { mappedCustomerTypes: [] };
    const mappingEntries = resolveMappingEntriesForChannelCustomerType(mapped, lookup);

    for (const entry of mappingEntries) {
      const built = buildMappedCustomerTypeFromEntry(entry, prototypes);
      if (built) result.mappedCustomerTypes.push(built);
    }

    if (result.mappedCustomerTypes.length === 0) {
      const prototype = findPrototypeByMappedName(prototypes, mapped?.displayName);
      if (prototype) {
        const name =
          prototype?.display_name ?? prototype?.displayName ?? prototype?.name ?? mapped?.displayName;
        result.mappedCustomerTypes.push({
          name,
          displayName: name,
          customerPrototypePk: prototype?.pk ?? null,
          customerTypePk: getPrototypeCustomerType(prototype)?.pk ?? null,
          prototype
        });
      }
    }

    return result;
  }

  function getEffectivePricings(pricingData) {
    const rows = pricingData?.effective_pricings ?? pricingData?.effectivePricings;
    return Array.isArray(rows) ? rows : [];
  }

  function getPricingRowPrototype(row) {
    return row?.customer_prototype ?? row?.customerPrototype ?? row?.for_object ?? row?.forObject ?? null;
  }

  function getPricingRowCustomerType(row) {
    return row?.customer_type ?? row?.customerType ?? getPrototypeCustomerType(getPricingRowPrototype(row) || {});
  }

  function identifiersMatch(a, b) {
    if (a === null || a === undefined || b === null || b === undefined) return false;
    return String(a) === String(b);
  }

  function urisMatch(a, b) {
    if (!a || !b) return false;
    return String(a) === String(b);
  }

  function matchPricingRow(prototype, pricingRows) {
    if (!prototype) return { row: null, method: null };
    const protoPk = prototype?.pk;
    const protoUri = prototype?.uri;
    const customerType = getPrototypeCustomerType(prototype);
    const typePk = customerType?.pk;
    const typeUri = customerType?.uri;
    const displayName = normalizeName(prototype?.display_name ?? prototype?.displayName ?? prototype?.name);
    const name = normalizeName(prototype?.name);

    for (const row of pricingRows) {
      const rowProto = getPricingRowPrototype(row);
      if (rowProto && identifiersMatch(rowProto.pk, protoPk)) {
        return { row, method: "customer_prototype.pk" };
      }
    }
    for (const row of pricingRows) {
      const rowProto = getPricingRowPrototype(row);
      if (rowProto && urisMatch(rowProto.uri, protoUri)) {
        return { row, method: "customer_prototype.uri" };
      }
    }
    for (const row of pricingRows) {
      const rowType = getPricingRowCustomerType(row);
      if (identifiersMatch(rowType?.pk, typePk)) {
        return { row, method: "customer_type.pk" };
      }
    }
    for (const row of pricingRows) {
      const rowType = getPricingRowCustomerType(row);
      if (urisMatch(rowType?.uri, typeUri)) {
        return { row, method: "customer_type.uri" };
      }
    }
    for (const row of pricingRows) {
      const rowProto = getPricingRowPrototype(row);
      const rowNames = [rowProto?.display_name, rowProto?.displayName, rowProto?.name];
      for (const rowName of rowNames) {
        const normalized = normalizeName(rowName);
        if (normalized && (normalized === displayName || normalized === name)) {
          return { row, method: "display_name/name" };
        }
      }
    }
    return { row: null, method: null };
  }

  function formatPriceAmount(value) {
    const num = toNumberOrNull(value);
    if (num === null) return null;
    return num.toFixed(2);
  }

  function extractBasePriceFromRow(row) {
    if (!row) return null;
    const price = row?.price ?? {};
    const modifierKind = price.modifier_kind ?? price.modifierKind ?? null;
    const offset = toNumberOrNull(row?.price_offset ?? row?.priceOffset ?? price?.offset);
    const rate = toNumberOrNull(row?.price_rate ?? row?.priceRate ?? price?.rate);
    if (modifierKind === "offset" && offset !== null) return offset / 100;
    if (offset !== null && offset !== 0) return offset / 100;
    if (rate !== null && rate !== 0) return rate;
    if (offset === 0) return 0;
    return null;
  }

  function getPriceTaxInclusion(row) {
    const price = row?.price ?? {};
    return price.tax_inclusion ?? price.taxInclusion ?? row?.tax_inclusion ?? row?.taxInclusion ?? null;
  }

  function taxesAreIncluded(taxInclusion) {
    if (!taxInclusion) return false;
    const normalized = String(taxInclusion).toLowerCase().trim();
    if (normalized === "not-included" || normalized === "not_included") return false;
    if (normalized === "included" || normalized.includes("included")) return true;
    return false;
  }

  function normalizePercentageTaxRate(rate) {
    const num = toNumberOrNull(rate);
    if (num === null) return null;
    if (num > 0 && num < 1) return num;
    if (num > 1) return num / 100;
    return null;
  }

  function sumTaxRatesFromRow(row) {
    const taxes = row?.taxes ?? {};
    const ratesByType = taxes.ratesByType ?? taxes.rates_by_type ?? {};
    let totalRate = 0;
    for (const rawRate of Object.values(ratesByType)) {
      const normalizedRate = normalizePercentageTaxRate(rawRate);
      if (normalizedRate !== null) totalRate += normalizedRate;
    }
    return totalRate;
  }

  function sumTaxOffsetsFromRow(row) {
    const taxes = row?.taxes ?? {};
    const offsetsByType = taxes.offsetsByType ?? taxes.offsets_by_type ?? {};
    let totalOffset = 0;
    for (const rawOffset of Object.values(offsetsByType)) {
      const num = toNumberOrNull(rawOffset);
      if (num !== null) totalOffset += num / 100;
    }
    return totalOffset;
  }

  function calculateFinalPrice(row) {
    const base = extractBasePriceFromRow(row);
    if (base === null) {
      return { basePrice: null, finalPrice: null, warning: "Could not extract base price" };
    }
    const baseFormatted = formatPriceAmount(base);
    const taxInclusion = getPriceTaxInclusion(row);
    if (taxesAreIncluded(taxInclusion)) {
      return { basePrice: baseFormatted, finalPrice: baseFormatted, warning: null };
    }
    const taxRateUsed = sumTaxRatesFromRow(row);
    const taxOffsetUsed = sumTaxOffsetsFromRow(row);
    if (taxRateUsed <= 0 && taxOffsetUsed <= 0) {
      return { basePrice: baseFormatted, finalPrice: baseFormatted, warning: null };
    }
    let amount = base;
    if (taxRateUsed > 0) amount = base * (1 + taxRateUsed);
    if (taxOffsetUsed > 0) amount += taxOffsetUsed;
    return {
      basePrice: baseFormatted,
      finalPrice: formatPriceAmount(amount),
      warning: null
    };
  }

  function formatCustomerTypePricesCell(mappedTypes, pricesByTypeKey, processorCurrency) {
    const parts = [];
    for (const mappedType of mappedTypes || []) {
      const name = mappedType.name || mappedType.displayName || "Unknown";
      const key =
        mappedType.customerTypePk != null
          ? `type:${mappedType.customerTypePk}`
          : mappedType.customerPrototypePk != null
            ? `proto:${mappedType.customerPrototypePk}`
            : `name:${name}`;
      const priceValues = pricesByTypeKey?.[key];
      let priceLabel = "unknown";
      if (Array.isArray(priceValues) && priceValues.length > 0) {
        priceLabel = formatAggregatedPriceDisplay(priceValues, processorCurrency);
      } else if (!isBlankValue(priceValues)) {
        priceLabel = formatCurrencyAmount(priceValues, processorCurrency);
      }
      parts.push(`${name}: ${priceLabel}`);
    }
    return dedupePreservingOrder(parts).join("; ");
  }

  function formatCustomerTypePricesHtmlCell(mappedTypes, pricesByTypeKey, processorCurrency) {
    const lines = [];
    for (const mappedType of mappedTypes || []) {
      const name = escapeHtmlText(mappedType.name || mappedType.displayName || "Unknown");
      const key =
        mappedType.customerTypePk != null
          ? `type:${mappedType.customerTypePk}`
          : mappedType.customerPrototypePk != null
            ? `proto:${mappedType.customerPrototypePk}`
            : `name:${mappedType.name || mappedType.displayName || ""}`;
      const priceValues = pricesByTypeKey?.[key];
      let priceLabel = "unknown";
      if (Array.isArray(priceValues) && priceValues.length > 0) {
        priceLabel = formatAggregatedPriceDisplay(priceValues, processorCurrency);
      } else if (!isBlankValue(priceValues)) {
        priceLabel = formatCurrencyAmount(priceValues, processorCurrency);
      }
      lines.push(`<strong>${name}:</strong> ${escapeHtmlText(priceLabel)}`);
    }
    return lines.join("<br>");
  }

  function getMappedTypeKey(mappedType) {
    if (mappedType.customerTypePk != null) return `type:${mappedType.customerTypePk}`;
    if (mappedType.customerPrototypePk != null) return `proto:${mappedType.customerPrototypePk}`;
    return `name:${mappedType.name || mappedType.displayName || ""}`;
  }

  function collectPricesForMappedTypes(mappedTypes, pricingRows, processorCurrency) {
    const pricesByTypeKey = {};
    for (const mappedType of mappedTypes || []) {
      const prototype = mappedType.prototype;
      if (!prototype) continue;
      const { row } = matchPricingRow(prototype, pricingRows);
      if (!row) continue;
      const priceResult = calculateFinalPrice(row);
      if (priceResult.finalPrice === null) continue;
      const key = getMappedTypeKey(mappedType);
      if (!pricesByTypeKey[key]) pricesByTypeKey[key] = [];
      pricesByTypeKey[key].push(Number(priceResult.finalPrice));
    }
    for (const key of Object.keys(pricesByTypeKey)) {
      pricesByTypeKey[key] = dedupePreservingOrder(pricesByTypeKey[key]);
    }
    return pricesByTypeKey;
  }

  async function runWithConcurrencyLimit(tasks, limit, worker) {
    const results = new Array(tasks.length);
    let nextIndex = 0;

    async function runWorker() {
      while (nextIndex < tasks.length) {
        const currentIndex = nextIndex;
        nextIndex += 1;
        results[currentIndex] = await worker(tasks[currentIndex], currentIndex);
      }
    }

    const workerCount = Math.min(limit, tasks.length || 0);
    if (workerCount === 0) return results;
    await Promise.all(Array.from({ length: workerCount }, () => runWorker()));
    return results;
  }

  window.FareHarborAffiliateMappingPricing = {
    CONCURRENCY_LIMIT,
    INTEGRATION_MATCH_TOKENS,
    findAffiliateAffiliation,
    resolveAffiliatePriceSheets,
    resolveAssignedPricing,
    fetchPricingForEditing,
    getEffectivePricings,
    fetchResellerCustomerTypeMappingsForItem,
    fetchCustomerPrototypes,
    resolvePrototypeForChannelCustomerType,
    resolveCompanyFromRows,
    dedupeMappedCustomerTypesById,
    reorderMappedCustomerTypes,
    buildDisambiguatedSheetHeaders,
    formatCustomerTypePricesCell,
    formatCustomerTypePricesHtmlCell,
    collectPricesForMappedTypes,
    getMappedTypeKey,
    matchPricingRow,
    calculateFinalPrice,
    formatCurrencyAmount,
    formatAggregatedPriceDisplay,
    escapeTsvField,
    escapeHtmlText,
    serializeTsvTable,
    runWithConcurrencyLimit,
    dedupePreservingOrder,
    getProcessorCurrency,
    fetchCompanyData,
    __test__: {
      dedupePreservingOrder,
      reorderMappedCustomerTypes,
      dedupeMappedCustomerTypesById,
      buildDisambiguatedSheetHeaders,
      formatCustomerTypePricesCell,
      serializeTsvTable,
      escapeTsvField,
      matchPricingRow,
      calculateFinalPrice,
      formatCurrencyAmount,
      formatAggregatedPriceDisplay,
      resolveAssignedPricing,
      getPricingObjectPk,
      getPricingObjectType
    }
  };

  log("Module initialized successfully");
})();
