(function initializeMappingToolsPanel() {
  "use strict";

  const DEBUG = false;
  const LOG_PREFIX = "[mapping-tools-panel]";
  const SETTING_KEY = "showMappingToolsPanel";
  const PANEL_ID = "fhx-mapping-tools-panel";
  const PANEL_ATTR = "data-fhx-mapping-tools-panel";
  const LAYOUT_HOST_ATTR = "data-fhx-mtp-layout-host";
  const LAYOUT_HOST_CLASS = "fhx-mtp-layout";
  const LAYOUT_STACKED_CLASS = "fhx-mtp-layout--stacked";
  const NATIVE_MARK_ATTR = "data-fhx-mtp-native";
  const WIDEN_CLASS = "fhx-mtp-widen";
  const STYLE_ID = "fhx-mapping-tools-panel-styles-v4";
  const SETTINGS_WINDOW_SELECTOR = ".settings-window";
  const SETTINGS_WRAP_SELECTOR = ".settings-wrap-narrow";
  const RESELLER_ITEM_MAPPINGS_CTRL_SELECTOR =
    'div[ng-controller="dashboard.settings.reseller.ResellerItemMappingsCtrl"]';
  const ITEM_MAPPINGS_HEADING_RE = /^Item Mappings$/i;
  const CHANNEL_ITEM_PAGE_RE =
    /\/dashboard\/settings\/integrations\/channels\/(\d+)\/items\/(\d+)\/?$/;
  const SCAN_DEBOUNCE_MS = 200;
  const ROUTE_REEVAL_DELAY_MS = 150;
  /** Stack when the layout host cannot fit native column + panel comfortably. */
  const STACK_BREAKPOINT_PX = 900;
  const AVAILABILITY_LAYOUT_CLASS = "fh-availability-columns";

  /**
   * @typedef {{
   *   displayName: string,
   *   hasCopyOneItem: boolean,
   *   emptyMessage?: string
   * }} OtaPanelConfig
   * @type {Record<string, OtaPanelConfig>}
   */
  const OTA_TOOL_REGISTRY = {
    getyourguide: {
      displayName: "GetYourGuide",
      hasCopyOneItem: true
    },
    expedia: {
      displayName: "Expedia",
      hasCopyOneItem: true
    },
    viator: {
      displayName: "Viator",
      hasCopyOneItem: false,
      emptyMessage:
        "Copy 1 Item is not available for Viator. Use the popup for the complete mapping file."
    },
    bookingcom: {
      displayName: "Booking.com",
      hasCopyOneItem: false,
      emptyMessage: "Copy 1 Item is not available for this channel yet."
    },
    google: {
      displayName: "Google",
      hasCopyOneItem: false,
      emptyMessage: "Copy 1 Item is not available for this channel yet."
    },
    airbnb: {
      displayName: "Airbnb",
      hasCopyOneItem: false,
      emptyMessage: "Copy 1 Item is not available for this channel yet."
    }
  };

  const GYG_INCLUDE_PRICES_STORAGE_KEY = "gygMappingIncludePrices";
  const GYG_INCLUDE_CAPACITY_STORAGE_KEY = "gygMappingIncludeCapacitySettings";
  const GYG_USE_CHANNEL_NAME_STORAGE_KEY = "gygMappingUseChannelName";
  const GYG_USE_TSV_FORMAT_STORAGE_KEY = "gygMappingUseTSVFormat";
  const GYG_INCLUDE_HEADER_ROW_STORAGE_KEY = "gygMappingIncludeHeaderRow";
  const DASHBOARD_ITEM_PATH_RE = /\/([^/]+)\/dashboard\/items\/(\d+)/;

  let featureEnabled = true;
  let settingsBound = false;
  let spaUnsubscribe = null;
  let startTimesUnsubscribe = null;
  let observer = null;
  let observeRoot = null;
  let debounceTimer = null;
  let lifecycleEvalTimer = null;
  let watchersActive = false;
  let ensureGeneration = 0;
  let copyInProgress = false;
  let copyGeneration = 0;
  /** @type {ResizeObserver|null} */
  let layoutResizeObserver = null;
  /** @type {Element|null} */
  let layoutResizeHost = null;
  /** @type {string|null} */
  let lastContextKey = null;
  /** @type {string|null} */
  let lastPageKey = null;
  /** @type {string|null} */
  let activeAffiliateKey = null;
  /** @type {string|null} companyShortname:itemId the panel is tracking for scan UI */
  let panelScanTargetKey = null;
  /** @type {string|null} */
  let selectedConnectedItemKey = null;
  /** @type {ReturnType<typeof collectConnectedFareHarborItems>} */
  let connectedItemsCache = [];

  /**
   * GetYourGuide Copy 1 Item options. Defaults match popup/overlay:
   * useChannelName false = Item name; useTSVFormat false = Zendesk;
   * includeHeaderRow false = No header.
   */
  const gygOptions = {
    useChannelName: false,
    useTSVFormat: false,
    includeHeaderRow: false,
    includePrices: false,
    includeCapacitySettings: false,
    optionsLoaded: false
  };
  let gygStorageListenerBound = false;

  function log(...args) {
    if (DEBUG) {
      console.log(LOG_PREFIX, ...args);
    }
  }

  function warn(...args) {
    console.warn(LOG_PREFIX, ...args);
  }

  function normalizeVisibleText(text) {
    return String(text || "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function parseChannelItemPageContext() {
    const api = window.MappingCopyButton;
    if (api?.parseChannelItemPageContext) {
      return api.parseChannelItemPageContext();
    }

    if (!isFareHarborHost()) {
      return null;
    }
    const pathname = (location.pathname || "").replace(/\/+$/, "");
    const match = pathname.match(CHANNEL_ITEM_PAGE_RE);
    if (!match) {
      return null;
    }
    const parts = pathname.split("/").filter(Boolean);
    return {
      shortname: parts[0],
      companyPk: match[1],
      resellerItemId: match[2],
      apiOrigin: window.location.origin
    };
  }

  function isChannelItemMappingPath() {
    return !!parseChannelItemPageContext();
  }

  function findItemMappingsResellerSection() {
    const fromApi = window.MappingCopyButton?.findItemMappingsSection?.();
    if (fromApi instanceof Element) {
      const ctrl =
        fromApi.closest(RESELLER_ITEM_MAPPINGS_CTRL_SELECTOR) ||
        (fromApi.matches(RESELLER_ITEM_MAPPINGS_CTRL_SELECTOR) ? fromApi : null);
      if (ctrl) {
        return ctrl;
      }
    }

    const ctrl = document.querySelector(RESELLER_ITEM_MAPPINGS_CTRL_SELECTOR);
    if (!ctrl) {
      return null;
    }

    const header = ctrl.querySelector(".reseller-header");
    const heading = header?.querySelector("h2");
    if (
      !heading ||
      !ITEM_MAPPINGS_HEADING_RE.test(normalizeVisibleText(heading.textContent))
    ) {
      return null;
    }

    return ctrl;
  }

  function isPageEligible() {
    if (!isFareHarborHost() || !featureEnabled) {
      return false;
    }
    if (!isChannelItemMappingPath()) {
      return false;
    }
    return !!findItemMappingsResellerSection();
  }

  function isExtensionNode(node) {
    if (!node) {
      return false;
    }
    if (node.nodeType === Node.TEXT_NODE) {
      return isExtensionNode(node.parentElement);
    }
    if (!(node instanceof Element)) {
      return false;
    }
    if (node.id === STYLE_ID || node.id === PANEL_ID) {
      return true;
    }
    if (
      node.hasAttribute(PANEL_ATTR) ||
      node.hasAttribute(LAYOUT_HOST_ATTR) ||
      node.hasAttribute(NATIVE_MARK_ATTR) ||
      node.classList?.contains(LAYOUT_HOST_CLASS) ||
      node.classList?.contains(WIDEN_CLASS)
    ) {
      return true;
    }
    return !!node.closest?.(`[${PANEL_ATTR}], #${PANEL_ID}`);
  }

  function isExtensionMutation(mutation) {
    if (isExtensionNode(mutation.target)) {
      return true;
    }
    for (const node of mutation.addedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    for (const node of mutation.removedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    return false;
  }

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      /* Side-by-side: natives keep normal document flow (independent vertical
         spacing). Panel is absolutely positioned in a reserved right gutter so
         its height cannot stretch a shared grid row. */
      .${LAYOUT_HOST_CLASS} {
        position: relative;
        box-sizing: border-box;
        padding-right: calc(min(340px, 36%) + 20px);
      }
      .${LAYOUT_HOST_CLASS} > [${PANEL_ATTR}] {
        position: absolute;
        top: 0;
        right: 0;
        box-sizing: border-box;
        width: min(340px, 36%);
        min-width: 260px;
        max-width: 340px;
        margin: 0;
      }
      /* Stacked: return panel to normal flow below all native sections. */
      .${LAYOUT_HOST_CLASS}.${LAYOUT_STACKED_CLASS} {
        display: flex;
        flex-direction: column;
        padding-right: 0;
      }
      .${LAYOUT_HOST_CLASS}.${LAYOUT_STACKED_CLASS} > :not([${PANEL_ATTR}]) {
        order: 1;
      }
      .${LAYOUT_HOST_CLASS}.${LAYOUT_STACKED_CLASS} > [${PANEL_ATTR}] {
        position: static;
        width: auto;
        min-width: 0;
        max-width: none;
        order: 2;
        margin-top: 12px;
        margin-bottom: 12px;
      }
      /* Widen only while the panel is active. More-specific rule coexists with
         Future Availabilities (.fh-availability-columns → 750px) without fighting
         equal-specificity last-wins overrides. */
      .settings-window.${WIDEN_CLASS} {
        --settings-wrap-width-narrow: min(1100px, calc(100vw - 48px));
      }
      .settings-window.${WIDEN_CLASS}.${AVAILABILITY_LAYOUT_CLASS} {
        --settings-wrap-width-narrow: min(1200px, calc(100vw - 48px));
      }
      .fhx-mapping-tools-panel {
        box-sizing: border-box;
        margin: 0 0 16px;
        padding: 16px 18px;
        border: 1px solid #d7dee6;
        border-radius: 4px;
        background: #fafbfc;
        color: #243746;
        font-size: 13px;
        line-height: 1.45;
      }
      .fhx-mapping-tools-panel__header {
        margin: 0 0 6px;
      }
      .fhx-mapping-tools-panel__title {
        margin: 0;
        font-size: 16px;
        font-weight: 600;
        color: #243746;
        line-height: 1.3;
      }
      .fhx-mapping-tools-panel__description {
        margin: 0 0 12px;
        font-size: 13px;
        color: #5c6b78;
      }
      .fhx-mapping-tools-panel__channel {
        margin: 0 0 12px;
        font-size: 12px;
        font-weight: 600;
        color: #3d4f5f;
      }
      .fhx-mapping-tools-panel__channel-label {
        font-weight: 500;
        color: #5c6b78;
      }
      .fhx-mapping-tools-panel__section-label {
        margin: 0 0 8px;
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 0.02em;
        text-transform: uppercase;
        color: #8c959f;
      }
      .fhx-mapping-tools-panel__empty {
        margin: 0;
        font-size: 13px;
        color: #5c6b78;
      }
      .fhx-mapping-tools-panel__options {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin: 0 0 12px;
      }
      .fhx-mapping-tools-panel__check {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        margin: 0;
        font-size: 12px;
        color: #3d4f5f;
        cursor: pointer;
      }
      .fhx-mapping-tools-panel__check input {
        margin: 2px 0 0;
        flex: 0 0 auto;
      }
      .fhx-mapping-tools-panel__options-divider {
        margin: 4px 0 2px;
        border: 0;
        border-top: 1px solid #e6ebf0;
      }
      .fhx-mtp-seg {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .fhx-mtp-seg__label {
        font-size: 12px;
        font-weight: 600;
        color: #5c6b78;
      }
      .fhx-mtp-seg__control {
        display: flex;
        width: 100%;
        box-sizing: border-box;
        border: 1px solid #c5ced6;
        border-radius: 4px;
        overflow: hidden;
        background: #fff;
      }
      .fhx-mtp-seg__btn {
        appearance: none;
        -webkit-appearance: none;
        flex: 1 1 0;
        min-width: 0;
        margin: 0;
        padding: 6px 8px;
        border: 0;
        border-right: 1px solid #c5ced6;
        background: #f7f9fb;
        color: #5c6b78;
        font: inherit;
        font-size: 12px;
        font-weight: 500;
        line-height: 1.3;
        cursor: pointer;
        text-align: center;
      }
      .fhx-mtp-seg__btn:last-child {
        border-right: 0;
      }
      .fhx-mtp-seg__btn:hover:not([aria-checked="true"]) {
        background: #eef3f7;
        color: #3d4f5f;
      }
      .fhx-mtp-seg__btn[aria-checked="true"] {
        background: #6b8ca3;
        color: #fff;
        font-weight: 600;
      }
      .fhx-mtp-seg__btn:focus-visible {
        outline: 2px solid #5f7f99;
        outline-offset: -2px;
        z-index: 1;
      }
      .fhx-mapping-tools-panel__actions {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 6px;
      }
      .fhx-mapping-tools-panel__btn {
        appearance: none;
        border: none;
        background: none;
        padding: 0;
        color: #6b8ca3;
        font: inherit;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        text-align: left;
      }
      .fhx-mapping-tools-panel__btn:hover:not(:disabled) {
        text-decoration: underline;
        color: #5f7f99;
      }
      .fhx-mapping-tools-panel__btn:disabled {
        opacity: 0.55;
        cursor: default;
        text-decoration: none;
      }
      .fhx-mapping-tools-panel__icon-actions {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 8px 12px;
        margin: 0 0 8px;
      }
      .fhx-mapping-tools-panel__icon-btn {
        appearance: none;
        -webkit-appearance: none;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: transparent;
        border: 0;
        padding: 0;
        margin: 0;
        color: #5f7f99;
        font-size: 13px;
        font-weight: 600;
        line-height: 1.4;
        cursor: pointer;
        font-family: inherit;
        box-shadow: none;
        white-space: nowrap;
      }
      .fhx-mapping-tools-panel__icon-btn svg {
        width: 15px;
        height: 15px;
        flex-shrink: 0;
        color: inherit;
      }
      .fhx-mapping-tools-panel__icon-btn:hover:not(:disabled) {
        color: #315f7c;
      }
      .fhx-mapping-tools-panel__icon-btn:hover:not(:disabled) .fhx-mapping-tools-panel__icon-btn-label {
        text-decoration: underline;
      }
      .fhx-mapping-tools-panel__icon-btn:disabled {
        opacity: 0.6;
        cursor: default;
      }
      .fhx-mapping-tools-panel__icon-sep {
        color: #9aa8b3;
        user-select: none;
      }
      .fhx-mapping-tools-panel__status {
        min-height: 1.2em;
        font-size: 12px;
        color: #5c6b78;
      }
      .fhx-mapping-tools-panel__status.is-success {
        color: #24553a;
      }
      .fhx-mapping-tools-panel__status.is-error {
        color: #8a4b12;
      }
      .fhx-mapping-tools-panel__hint {
        margin: 10px 0 0;
        font-size: 11px;
        color: #8c959f;
      }
      .fhx-mapping-tools-panel__divider {
        margin: 16px 0 12px;
        border: 0;
        border-top: 1px solid #e6ebf0;
      }
      .fhx-mapping-tools-panel__connected {
        margin: 0 0 10px;
        font-size: 12px;
        color: #3d4f5f;
        word-break: break-word;
      }
      .fhx-mapping-tools-panel__connected-label {
        display: block;
        margin-bottom: 4px;
        font-weight: 500;
        color: #5c6b78;
      }
      .fhx-mapping-tools-panel__select {
        box-sizing: border-box;
        width: 100%;
        max-width: 100%;
        margin: 0 0 10px;
        padding: 5px 8px;
        border: 1px solid #c5ced6;
        border-radius: 4px;
        background: #fff;
        color: #243746;
        font: inherit;
        font-size: 12px;
      }
      .fhx-mapping-tools-panel__scan-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 10px 14px;
        margin-bottom: 6px;
      }
      .fhx-mapping-tools-panel__results {
        margin: 8px 0 0;
        padding: 8px 10px;
        border: 1px solid #e6ebf0;
        border-radius: 4px;
        background: #fff;
        font-size: 12px;
        color: #3d4f5f;
        white-space: pre-wrap;
        word-break: break-word;
        max-height: 160px;
        overflow: auto;
      }
      .fhx-mapping-tools-panel__results:empty {
        display: none;
      }
    `;
    document.documentElement.appendChild(style);
  }

  function applyWidenClass(enabled) {
    const windows = document.querySelectorAll(SETTINGS_WINDOW_SELECTOR);
    windows.forEach((el) => {
      if (enabled) {
        el.classList.add(WIDEN_CLASS);
      } else {
        el.classList.remove(WIDEN_CLASS);
      }
    });
  }

  function syncHostMinHeight(host) {
    if (!(host instanceof Element)) {
      return;
    }
    if (host.classList.contains(LAYOUT_STACKED_CLASS)) {
      host.style.minHeight = "";
      return;
    }
    const panel = host.querySelector(`[${PANEL_ATTR}]`);
    if (!(panel instanceof HTMLElement)) {
      host.style.minHeight = "";
      return;
    }
    // Absolute panel does not contribute to host height; grow the host only when
    // needed so the panel does not overflow onto content below the host.
    host.style.minHeight = "";
    const hostHeight = host.offsetHeight;
    const panelHeight = panel.offsetHeight;
    if (panelHeight > hostHeight) {
      host.style.minHeight = `${panelHeight}px`;
    }
  }

  function updateStackedState(host) {
    if (!(host instanceof Element)) {
      return;
    }
    const width = host.getBoundingClientRect().width;
    const shouldStack = !width || width < STACK_BREAKPOINT_PX;
    host.classList.toggle(LAYOUT_STACKED_CLASS, shouldStack);
    syncHostMinHeight(host);
  }

  function bindLayoutResize(host) {
    if (!(host instanceof Element)) {
      return;
    }
    if (typeof ResizeObserver === "undefined") {
      updateStackedState(host);
      return;
    }
    if (layoutResizeHost === host && layoutResizeObserver) {
      updateStackedState(host);
      const panel = host.querySelector(`[${PANEL_ATTR}]`);
      if (panel) {
        layoutResizeObserver.observe(panel);
      }
      return;
    }
    if (layoutResizeObserver) {
      layoutResizeObserver.disconnect();
    }
    layoutResizeHost = host;
    layoutResizeObserver = new ResizeObserver(() => {
      updateStackedState(host);
    });
    layoutResizeObserver.observe(host);
    const panel = host.querySelector(`[${PANEL_ATTR}]`);
    if (panel) {
      layoutResizeObserver.observe(panel);
    }
    updateStackedState(host);
  }

  function unbindLayoutResize() {
    if (layoutResizeObserver) {
      layoutResizeObserver.disconnect();
      layoutResizeObserver = null;
    }
    layoutResizeHost = null;
  }

  function clearLayoutMarks() {
    unbindLayoutResize();
    document.querySelectorAll(`[${LAYOUT_HOST_ATTR}]`).forEach((host) => {
      host.classList.remove(LAYOUT_HOST_CLASS);
      host.classList.remove(LAYOUT_STACKED_CLASS);
      host.removeAttribute(LAYOUT_HOST_ATTR);
      host.style.minHeight = "";
    });
    document.querySelectorAll(`[${NATIVE_MARK_ATTR}]`).forEach((el) => {
      el.removeAttribute(NATIVE_MARK_ATTR);
    });
    applyWidenClass(false);
  }

  function disconnectStartTimesSubscription() {
    if (startTimesUnsubscribe) {
      startTimesUnsubscribe();
      startTimesUnsubscribe = null;
    }
  }

  function removePanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) {
      existing.remove();
    }
    clearLayoutMarks();
    disconnectStartTimesSubscription();
    lastContextKey = null;
    lastPageKey = null;
    activeAffiliateKey = null;
    panelScanTargetKey = null;
    selectedConnectedItemKey = null;
    connectedItemsCache = [];
    copyInProgress = false;
    copyGeneration += 1;
  }

  function connectedItemKey(item) {
    if (!item) {
      return null;
    }
    return `${item.companyShortname}:${item.itemId}`;
  }

  /**
   * Resolve connected FareHarbor Dashboard items from Item Mappings links.
   * Uses /{shortname}/dashboard/items/{itemId}/ — not the channel item URL id.
   */
  function collectConnectedFareHarborItems() {
    const items = [];
    const seen = new Set();

    const linkApi = window.ItemMappingLinkCopy;
    let sections = linkApi?.findItemMappingsSections?.() || [];
    if (!sections.length) {
      const fallback = findItemMappingsResellerSection();
      if (fallback) {
        sections = [fallback];
      }
    }

    for (const section of sections) {
      const links = linkApi?.collectItemMappingLinks?.(section) || [];
      if (!links.length) {
        section.querySelectorAll("a.block-list-content[href]").forEach((anchor) => {
          const href = anchor.href;
          const text = normalizeVisibleText(anchor.textContent);
          if (href && text) {
            links.push({ href, text });
          }
        });
      }

      for (const link of links) {
        let pathname = "";
        try {
          pathname = new URL(link.href, window.location.origin).pathname;
        } catch (_) {
          continue;
        }
        const match = pathname.match(DASHBOARD_ITEM_PATH_RE);
        if (!match) {
          continue;
        }
        const companyShortname = match[1];
        const itemId = match[2];
        const key = `${companyShortname}:${itemId}`;
        if (seen.has(key)) {
          continue;
        }
        seen.add(key);
        items.push({
          companyShortname,
          itemId,
          name: link.text,
          href: link.href
        });
      }
    }

    return items;
  }

  function formatConnectedItemLabel(item) {
    if (!item) {
      return "";
    }
    const name = item.name || `Item ${item.itemId}`;
    return `${name} (FH item ${item.itemId})`;
  }

  function getSelectedConnectedItem() {
    if (!connectedItemsCache.length) {
      return null;
    }
    if (selectedConnectedItemKey) {
      const match = connectedItemsCache.find(
        (item) => connectedItemKey(item) === selectedConnectedItemKey
      );
      if (match) {
        return match;
      }
    }
    return connectedItemsCache[0];
  }

  function snapshotMatchesPanelTarget(snapshot) {
    if (!snapshot || !panelScanTargetKey) {
      return false;
    }
    const key = `${snapshot.companyShortname || ""}:${snapshot.itemId || ""}`;
    return key === panelScanTargetKey;
  }

  function buildPanelShell() {
    const panel = document.createElement("aside");
    panel.id = PANEL_ID;
    panel.className = "fhx-mapping-tools-panel reseller-section";
    panel.setAttribute(PANEL_ATTR, "true");
    panel.setAttribute("aria-label", "Mapping Tools");

    const header = document.createElement("div");
    header.className = "fhx-mapping-tools-panel__header";

    const title = document.createElement("h2");
    title.className = "fhx-mapping-tools-panel__title";
    title.textContent = "Mapping Tools";
    header.appendChild(title);

    const description = document.createElement("p");
    description.className = "fhx-mapping-tools-panel__description";
    description.textContent = "Additional tools for managing channel mappings";

    const channel = document.createElement("p");
    channel.className = "fhx-mapping-tools-panel__channel";
    channel.setAttribute("data-fhx-mtp-channel", "true");

    const body = document.createElement("div");
    body.className = "fhx-mapping-tools-panel__body";
    body.setAttribute("data-fhx-mtp-body", "true");

    panel.appendChild(header);
    panel.appendChild(description);
    panel.appendChild(channel);
    panel.appendChild(body);
    return panel;
  }

  function setChannelLabel(channelEl, displayName) {
    channelEl.textContent = "";
    const label = document.createElement("span");
    label.className = "fhx-mapping-tools-panel__channel-label";
    label.textContent = "Channel: ";
    channelEl.appendChild(label);
    channelEl.appendChild(document.createTextNode(displayName || "Unknown"));
  }

  function setStatus(statusEl, message, type) {
    if (!statusEl) {
      return;
    }
    statusEl.textContent = message || "";
    statusEl.classList.remove("is-success", "is-error");
    if (type === "success") {
      statusEl.classList.add("is-success");
    } else if (type === "error") {
      statusEl.classList.add("is-error");
    }
  }

  function createCheckbox(id, labelText, checked, onChange) {
    const label = document.createElement("label");
    label.className = "fhx-mapping-tools-panel__check";
    label.setAttribute("for", id);

    const input = document.createElement("input");
    input.type = "checkbox";
    input.id = id;
    input.checked = !!checked;
    input.addEventListener("change", () => onChange(!!input.checked));

    const text = document.createElement("span");
    text.textContent = labelText;

    label.appendChild(input);
    label.appendChild(text);
    return label;
  }

  /**
   * @param {string} label
   * @param {string} key storage/option key marker
   * @param {Array<{ value: boolean, label: string }>} choices
   * @param {boolean} selectedValue
   * @param {(value: boolean) => void} onChange
   */
  function createSegmentedControl(label, key, choices, selectedValue, onChange) {
    const wrap = document.createElement("div");
    wrap.className = "fhx-mtp-seg";
    wrap.setAttribute("data-fhx-mtp-gyg-seg", key);

    const labelEl = document.createElement("div");
    labelEl.className = "fhx-mtp-seg__label";
    labelEl.id = `fhx-mtp-gyg-seg-label-${key}`;
    labelEl.textContent = label;

    const control = document.createElement("div");
    control.className = "fhx-mtp-seg__control";
    control.setAttribute("role", "radiogroup");
    control.setAttribute("aria-labelledby", labelEl.id);

    for (const choice of choices) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "fhx-mtp-seg__btn";
      btn.setAttribute("role", "radio");
      btn.setAttribute("data-value", choice.value ? "true" : "false");
      btn.setAttribute(
        "aria-checked",
        choice.value === !!selectedValue ? "true" : "false"
      );
      btn.textContent = choice.label;
      btn.addEventListener("click", () => {
        const next = !!choice.value;
        const currentlySelected =
          wrap.querySelector('.fhx-mtp-seg__btn[aria-checked="true"]')?.getAttribute(
            "data-value"
          ) === "true";
        syncSegmentedControl(wrap, next);
        if (currentlySelected === next) {
          return;
        }
        onChange(next);
      });
      control.appendChild(btn);
    }

    wrap.appendChild(labelEl);
    wrap.appendChild(control);
    return wrap;
  }

  function syncSegmentedControl(wrap, selectedValue) {
    if (!(wrap instanceof Element)) {
      return;
    }
    wrap.querySelectorAll(".fhx-mtp-seg__btn").forEach((btn) => {
      const isSelected = btn.getAttribute("data-value") === String(!!selectedValue);
      btn.setAttribute("aria-checked", isSelected ? "true" : "false");
    });
  }

  function persistGygOptions() {
    try {
      chrome.storage.local.set({
        [GYG_INCLUDE_PRICES_STORAGE_KEY]: !!gygOptions.includePrices,
        [GYG_INCLUDE_CAPACITY_STORAGE_KEY]: !!gygOptions.includeCapacitySettings,
        [GYG_USE_CHANNEL_NAME_STORAGE_KEY]: !!gygOptions.useChannelName,
        [GYG_USE_TSV_FORMAT_STORAGE_KEY]: !!gygOptions.useTSVFormat,
        [GYG_INCLUDE_HEADER_ROW_STORAGE_KEY]: !!gygOptions.includeHeaderRow
      });
    } catch (err) {
      warn("Failed to persist GYG copy options:", err);
    }
  }

  function applyGygOptionsToPanelUi() {
    const panel = document.getElementById(PANEL_ID);
    if (!panel) {
      return;
    }

    const prices = panel.querySelector("#fhx-mtp-gyg-prices");
    if (prices) {
      prices.checked = !!gygOptions.includePrices;
    }
    const capacity = panel.querySelector("#fhx-mtp-gyg-capacity");
    if (capacity) {
      capacity.checked = !!gygOptions.includeCapacitySettings;
    }

    const nameSeg = panel.querySelector('[data-fhx-mtp-gyg-seg="useChannelName"]');
    syncSegmentedControl(nameSeg, gygOptions.useChannelName);
    const formatSeg = panel.querySelector('[data-fhx-mtp-gyg-seg="useTSVFormat"]');
    syncSegmentedControl(formatSeg, gygOptions.useTSVFormat);
    const headerSeg = panel.querySelector('[data-fhx-mtp-gyg-seg="includeHeaderRow"]');
    syncSegmentedControl(headerSeg, gygOptions.includeHeaderRow);
  }

  function loadGygOptions(callback) {
    if (gygOptions.optionsLoaded) {
      callback();
      return;
    }
    try {
      chrome.storage.local.get(
        {
          [GYG_INCLUDE_PRICES_STORAGE_KEY]: false,
          [GYG_INCLUDE_CAPACITY_STORAGE_KEY]: false,
          [GYG_USE_CHANNEL_NAME_STORAGE_KEY]: false,
          [GYG_USE_TSV_FORMAT_STORAGE_KEY]: false,
          [GYG_INCLUDE_HEADER_ROW_STORAGE_KEY]: false
        },
        (result) => {
          gygOptions.includePrices = !!result[GYG_INCLUDE_PRICES_STORAGE_KEY];
          gygOptions.includeCapacitySettings =
            !!result[GYG_INCLUDE_CAPACITY_STORAGE_KEY];
          gygOptions.useChannelName = !!result[GYG_USE_CHANNEL_NAME_STORAGE_KEY];
          gygOptions.useTSVFormat = !!result[GYG_USE_TSV_FORMAT_STORAGE_KEY];
          gygOptions.includeHeaderRow = !!result[GYG_INCLUDE_HEADER_ROW_STORAGE_KEY];
          gygOptions.optionsLoaded = true;
          callback();
        }
      );
    } catch (err) {
      warn("Failed to load GYG copy options:", err);
      gygOptions.optionsLoaded = true;
      callback();
    }
  }

  function bindGygStorageListener() {
    if (gygStorageListenerBound) {
      return;
    }
    gygStorageListenerBound = true;
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") {
        return;
      }
      let changed = false;
      if (Object.prototype.hasOwnProperty.call(changes, GYG_INCLUDE_PRICES_STORAGE_KEY)) {
        gygOptions.includePrices = !!changes[GYG_INCLUDE_PRICES_STORAGE_KEY].newValue;
        changed = true;
      }
      if (Object.prototype.hasOwnProperty.call(changes, GYG_INCLUDE_CAPACITY_STORAGE_KEY)) {
        gygOptions.includeCapacitySettings =
          !!changes[GYG_INCLUDE_CAPACITY_STORAGE_KEY].newValue;
        changed = true;
      }
      if (Object.prototype.hasOwnProperty.call(changes, GYG_USE_CHANNEL_NAME_STORAGE_KEY)) {
        gygOptions.useChannelName = !!changes[GYG_USE_CHANNEL_NAME_STORAGE_KEY].newValue;
        changed = true;
      }
      if (Object.prototype.hasOwnProperty.call(changes, GYG_USE_TSV_FORMAT_STORAGE_KEY)) {
        gygOptions.useTSVFormat = !!changes[GYG_USE_TSV_FORMAT_STORAGE_KEY].newValue;
        changed = true;
      }
      if (Object.prototype.hasOwnProperty.call(changes, GYG_INCLUDE_HEADER_ROW_STORAGE_KEY)) {
        gygOptions.includeHeaderRow =
          !!changes[GYG_INCLUDE_HEADER_ROW_STORAGE_KEY].newValue;
        changed = true;
      }
      if (changed) {
        gygOptions.optionsLoaded = true;
        applyGygOptionsToPanelUi();
      }
    });
  }

  function getCurrentPageContextKey() {
    return contextKeyFromPage(parseChannelItemPageContext(), activeAffiliateKey || "");
  }

  async function runCopyOneItem(affiliateKey, button, statusEl) {
    if (copyInProgress) {
      return;
    }
    if (!affiliateKey || affiliateKey !== activeAffiliateKey) {
      setStatus(statusEl, "Channel changed. Refresh and try again.", "error");
      return;
    }

    const startedKey = getCurrentPageContextKey();
    const generation = ++copyGeneration;
    copyInProgress = true;
    if (button) {
      button.disabled = true;
    }
    setStatus(statusEl, "Copying…", null);

    try {
      let outputText = "";
      let successMessage = "Copied item data.";

      if (affiliateKey === "expedia") {
        if (!window.ExpediaMapping?.runSingleItemMappingCopy) {
          throw new Error("Expedia mapping module not ready. Reload the page.");
        }
        const result = window.ExpediaMapping.runSingleItemMappingCopy();
        if (!result?.success || !result.outputText) {
          throw new Error(result?.error || "No item mapping data found.");
        }
        outputText = result.outputText;
      } else if (affiliateKey === "getyourguide") {
        if (!window.FareHarborResellerItems?.runSingleItemMappingCopy) {
          throw new Error("GetYourGuide mapping module not ready. Reload the page.");
        }
        const result = await window.FareHarborResellerItems.runSingleItemMappingCopy({
          useChannelName: gygOptions.useChannelName,
          includeHeaderRow: gygOptions.includeHeaderRow,
          includePrices: gygOptions.includePrices,
          includeCapacitySettings: gygOptions.includeCapacitySettings
        });
        if (!result?.success) {
          throw new Error(result?.error || "No item mapping data found.");
        }
        outputText = gygOptions.useTSVFormat ? result.tsvData : result.htmlData;
        if (!outputText) {
          throw new Error("No item mapping data found.");
        }
        successMessage = gygOptions.useTSVFormat
          ? "Copied item data (sheets)."
          : "Copied item data (Zendesk).";
      } else {
        throw new Error("Copy 1 Item is not available for this channel.");
      }

      if (
        generation !== copyGeneration ||
        startedKey !== getCurrentPageContextKey() ||
        affiliateKey !== activeAffiliateKey
      ) {
        return;
      }

      await navigator.clipboard.writeText(outputText);
      setStatus(statusEl, successMessage, "success");
    } catch (err) {
      if (
        generation !== copyGeneration ||
        startedKey !== getCurrentPageContextKey()
      ) {
        return;
      }
      warn("Copy 1 Item failed:", err);
      setStatus(statusEl, err?.message || "Copy failed.", "error");
    } finally {
      if (generation === copyGeneration) {
        copyInProgress = false;
        if (button && document.body.contains(button)) {
          button.disabled = false;
        }
      }
    }
  }

  function updateStartTimesPanelUi(ui, snapshot) {
    if (!ui || activeAffiliateKey !== "expedia") {
      return;
    }
    if (snapshot && !snapshotMatchesPanelTarget(snapshot)) {
      return;
    }

    const api = window.FindAllStartTimes;
    const state = snapshot || (panelScanTargetKey ? api?.getState?.() : null);
    const status = state?.status || "idle";
    const uniqueCount = (state?.uniqueStartTimes || []).length;
    const monthsCompleted = state?.monthsCompleted || 0;
    const monthsTotal = state?.monthsTotal || 0;

    if (ui.findBtn) {
      ui.findBtn.disabled = status === "running" || !getSelectedConnectedItem();
      ui.findBtn.textContent =
        status === "running" && snapshotMatchesPanelTarget(state)
          ? "Scanning…"
          : "Find Start Times";
    }
    if (ui.cancelBtn) {
      const showCancel =
        status === "running" && snapshotMatchesPanelTarget(state);
      ui.cancelBtn.hidden = !showCancel;
      ui.cancelBtn.disabled = !showCancel;
    }
    if (ui.copyBtn) {
      const showCopy =
        uniqueCount > 0 && snapshotMatchesPanelTarget(state) && status !== "running";
      ui.copyBtn.hidden = !showCopy;
      ui.copyBtn.disabled = !showCopy;
    }

    if (!ui.statusEl) {
      return;
    }

    if (!state || !snapshotMatchesPanelTarget(state)) {
      return;
    }

    if (status === "running") {
      setStatus(
        ui.statusEl,
        `Scanning… ${monthsCompleted}/${monthsTotal} months · ${uniqueCount} start time${uniqueCount === 1 ? "" : "s"} so far`,
        null
      );
    } else if (status === "complete") {
      setStatus(
        ui.statusEl,
        uniqueCount === 0
          ? "Scan complete. No start times found in the date range."
          : `Scan complete. ${uniqueCount} unique start time${uniqueCount === 1 ? "" : "s"}.`,
        uniqueCount === 0 ? null : "success"
      );
    } else if (status === "partial") {
      setStatus(
        ui.statusEl,
        `Partial scan. ${uniqueCount} start time${uniqueCount === 1 ? "" : "s"} · ${state.failedMonths?.length || 0} failed month(s).`,
        "error"
      );
    } else if (status === "cancelled") {
      setStatus(
        ui.statusEl,
        `Scan cancelled. ${uniqueCount} start time${uniqueCount === 1 ? "" : "s"} retrieved so far.`,
        null
      );
    }

    if (ui.resultsEl) {
      if (uniqueCount > 0 && snapshotMatchesPanelTarget(state)) {
        ui.resultsEl.textContent = (state.uniqueStartTimes || []).join("\n");
      } else if (status === "complete" && uniqueCount === 0) {
        ui.resultsEl.textContent = "";
      } else if (status === "idle") {
        ui.resultsEl.textContent = "";
      }
    }
  }

  function bindStartTimesSubscription(ui) {
    disconnectStartTimesSubscription();
    const api = window.FindAllStartTimes;
    if (!api?.subscribe) {
      return;
    }
    startTimesUnsubscribe = api.subscribe((snapshot) => {
      updateStartTimesPanelUi(ui, snapshot);
    });
    const current = api.getState?.();
    if (current && snapshotMatchesPanelTarget(current)) {
      updateStartTimesPanelUi(ui, current);
    }
  }

  async function startPanelStartTimesScan(ui) {
    const api = window.FindAllStartTimes;
    if (!api?.startScan) {
      setStatus(ui.statusEl, "Start time scanner is not ready. Reload the page.", "error");
      return;
    }

    const item = getSelectedConnectedItem();
    if (!item) {
      setStatus(ui.statusEl, "No connected FareHarbor item to scan.", "error");
      return;
    }

    const currentState = api.getState?.();
    if (currentState?.status === "running") {
      setStatus(
        ui.statusEl,
        "A scan is already running. Wait for it to finish or cancel it in the overlay.",
        "error"
      );
      return;
    }

    const targetKey = connectedItemKey(item);
    panelScanTargetKey = targetKey;
    if (ui.resultsEl) {
      ui.resultsEl.textContent = "";
    }
    setStatus(ui.statusEl, "Starting scan…", null);
    if (ui.findBtn) {
      ui.findBtn.disabled = true;
      ui.findBtn.textContent = "Starting…";
    }

    try {
      const result = await api.startScan({
        companyShortname: item.companyShortname,
        itemId: item.itemId
      });

      if (!result?.ok) {
        panelScanTargetKey = null;
        setStatus(ui.statusEl, result?.error || "Could not start scan.", "error");
        if (ui.findBtn) {
          ui.findBtn.disabled = !getSelectedConnectedItem();
          ui.findBtn.textContent = "Find Start Times";
        }
        return;
      }

      updateStartTimesPanelUi(ui, result.state || api.getState());
    } catch (err) {
      panelScanTargetKey = null;
      warn("Start times scan failed to start:", err);
      setStatus(ui.statusEl, err?.message || "Could not start scan.", "error");
      if (ui.findBtn) {
        ui.findBtn.disabled = !getSelectedConnectedItem();
        ui.findBtn.textContent = "Find Start Times";
      }
    }
  }

  function renderExpediaStartTimesSection(bodyEl) {
    connectedItemsCache = collectConnectedFareHarborItems();
    if (
      selectedConnectedItemKey &&
      !connectedItemsCache.some((item) => connectedItemKey(item) === selectedConnectedItemKey)
    ) {
      selectedConnectedItemKey = null;
    }
    if (!selectedConnectedItemKey && connectedItemsCache.length) {
      selectedConnectedItemKey = connectedItemKey(connectedItemsCache[0]);
    }

    const divider = document.createElement("hr");
    divider.className = "fhx-mapping-tools-panel__divider";
    bodyEl.appendChild(divider);

    const sectionLabel = document.createElement("div");
    sectionLabel.className = "fhx-mapping-tools-panel__section-label";
    sectionLabel.textContent = "Start Time Scanner";
    bodyEl.appendChild(sectionLabel);

    const connectedWrap = document.createElement("div");
    connectedWrap.className = "fhx-mapping-tools-panel__connected";

    const connectedLabel = document.createElement("span");
    connectedLabel.className = "fhx-mapping-tools-panel__connected-label";
    connectedLabel.textContent = "Connected FareHarbor item";
    connectedWrap.appendChild(connectedLabel);

    /** @type {{ findBtn: HTMLButtonElement|null, cancelBtn: HTMLButtonElement|null, copyBtn: HTMLButtonElement|null, statusEl: HTMLElement|null, resultsEl: HTMLElement|null }} */
    const ui = {
      findBtn: null,
      cancelBtn: null,
      copyBtn: null,
      statusEl: null,
      resultsEl: null
    };

    if (!connectedItemsCache.length) {
      const empty = document.createElement("p");
      empty.className = "fhx-mapping-tools-panel__empty";
      empty.textContent =
        "No connected FareHarbor items found in Item Mappings. Link a dashboard item before scanning start times.";
      connectedWrap.appendChild(empty);
      bodyEl.appendChild(connectedWrap);
      return;
    }

    if (connectedItemsCache.length === 1) {
      const single = document.createElement("div");
      single.textContent = formatConnectedItemLabel(connectedItemsCache[0]);
      connectedWrap.appendChild(single);
    } else {
      const hint = document.createElement("p");
      hint.className = "fhx-mapping-tools-panel__hint";
      hint.style.margin = "0 0 6px";
      hint.textContent = `${connectedItemsCache.length} items mapped — choose which FareHarbor item to scan (scanner supports one item at a time).`;
      connectedWrap.appendChild(hint);

      const select = document.createElement("select");
      select.className = "fhx-mapping-tools-panel__select";
      select.setAttribute("aria-label", "Connected FareHarbor item");
      for (const item of connectedItemsCache) {
        const option = document.createElement("option");
        option.value = connectedItemKey(item);
        option.textContent = formatConnectedItemLabel(item);
        if (option.value === selectedConnectedItemKey) {
          option.selected = true;
        }
        select.appendChild(option);
      }
      select.addEventListener("change", () => {
        selectedConnectedItemKey = select.value;
        if (ui.findBtn) {
          const running = window.FindAllStartTimes?.getState?.()?.status === "running";
          ui.findBtn.disabled = running;
        }
        // Results/status stay attributed to panelScanTargetKey only; switching
        // selection does not relabel an in-flight scan for a different item.
        const state = window.FindAllStartTimes?.getState?.();
        if (state && snapshotMatchesPanelTarget(state)) {
          updateStartTimesPanelUi(ui, state);
        } else if (ui.resultsEl) {
          ui.resultsEl.textContent = "";
          setStatus(ui.statusEl, "", null);
        }
      });
      connectedWrap.appendChild(select);
    }

    bodyEl.appendChild(connectedWrap);

    const scanActions = document.createElement("div");
    scanActions.className = "fhx-mapping-tools-panel__scan-actions";

    const findBtn = document.createElement("button");
    findBtn.type = "button";
    findBtn.className = "fhx-mapping-tools-panel__btn";
    findBtn.textContent = "Find Start Times";
    ui.findBtn = findBtn;

    const cancelBtn = document.createElement("button");
    cancelBtn.type = "button";
    cancelBtn.className = "fhx-mapping-tools-panel__btn";
    cancelBtn.textContent = "Cancel Scan";
    cancelBtn.hidden = true;
    ui.cancelBtn = cancelBtn;

    const copyBtn = document.createElement("button");
    copyBtn.type = "button";
    copyBtn.className = "fhx-mapping-tools-panel__btn";
    copyBtn.textContent = "Copy Start Times";
    copyBtn.hidden = true;
    ui.copyBtn = copyBtn;

    scanActions.appendChild(findBtn);
    scanActions.appendChild(cancelBtn);
    scanActions.appendChild(copyBtn);
    bodyEl.appendChild(scanActions);

    const statusEl = document.createElement("div");
    statusEl.className = "fhx-mapping-tools-panel__status";
    statusEl.setAttribute("data-fhx-mtp-start-times-status", "true");
    ui.statusEl = statusEl;
    bodyEl.appendChild(statusEl);

    const resultsEl = document.createElement("pre");
    resultsEl.className = "fhx-mapping-tools-panel__results";
    resultsEl.setAttribute("data-fhx-mtp-start-times-results", "true");
    ui.resultsEl = resultsEl;
    bodyEl.appendChild(resultsEl);

    const rangeHint = document.createElement("p");
    rangeHint.className = "fhx-mapping-tools-panel__hint";
    rangeHint.textContent =
      "Uses the same scanner as the popup (today through Dec 31 next year).";
    bodyEl.appendChild(rangeHint);

    findBtn.addEventListener("click", () => {
      startPanelStartTimesScan(ui);
    });

    cancelBtn.addEventListener("click", () => {
      const api = window.FindAllStartTimes;
      if (!api?.cancelScan) {
        return;
      }
      const state = api.getState?.();
      if (!snapshotMatchesPanelTarget(state)) {
        setStatus(statusEl, "No panel-owned scan is running.", "error");
        return;
      }
      const result = api.cancelScan();
      if (!result?.ok) {
        setStatus(statusEl, result?.error || "Could not cancel scan.", "error");
        return;
      }
      updateStartTimesPanelUi(ui, result.state || api.getState());
    });

    copyBtn.addEventListener("click", async () => {
      const api = window.FindAllStartTimes;
      const state = api?.getState?.();
      if (!api || !snapshotMatchesPanelTarget(state)) {
        setStatus(statusEl, "No start times available for the current item.", "error");
        return;
      }
      try {
        await navigator.clipboard.writeText(api.buildCopyStartTimesText(state));
        setStatus(statusEl, "Start times copied.", "success");
      } catch (err) {
        setStatus(statusEl, err?.message || "Copy failed.", "error");
      }
    });

    bindStartTimesSubscription(ui);

    // If a matching scan is already in progress/complete for this selection, show it.
    const existing = window.FindAllStartTimes?.getState?.();
    const selected = getSelectedConnectedItem();
    if (
      existing &&
      selected &&
      `${existing.companyShortname}:${existing.itemId}` === connectedItemKey(selected)
    ) {
      panelScanTargetKey = connectedItemKey(selected);
      updateStartTimesPanelUi(ui, existing);
    }
  }

  function createPanelIconButton(label, iconCreator) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "fhx-mapping-tools-panel__icon-btn";

    if (typeof iconCreator === "function") {
      button.appendChild(iconCreator());
    }

    const labelEl = document.createElement("span");
    labelEl.className = "fhx-mapping-tools-panel__icon-btn-label";
    labelEl.textContent = label;
    button.appendChild(labelEl);
    return button;
  }

  function setIconButtonLabel(button, label) {
    const labelEl = button?.querySelector(".fhx-mapping-tools-panel__icon-btn-label");
    if (labelEl) {
      labelEl.textContent = label;
      return;
    }
    if (button) {
      button.textContent = label;
    }
  }

  async function runCopyMappedLinks(button, statusEl) {
    const api = window.ItemMappingLinkCopy;
    if (!api?.copyMappedItemLinks) {
      setStatus(statusEl, "Copy link is not ready. Reload the page.", "error");
      return;
    }

    button.disabled = true;
    setStatus(statusEl, "Copying…", null);

    try {
      const result = await api.copyMappedItemLinks();
      if (!result?.success) {
        setStatus(statusEl, result?.error || "Copy failed.", "error");
        setIconButtonLabel(button, "Copy failed");
        return;
      }
      setStatus(
        statusEl,
        result.count === 1 ? "Copied link." : `Copied ${result.count} links.`,
        "success"
      );
      setIconButtonLabel(button, "Copied!");
    } catch (err) {
      warn("Copy mapped links failed:", err);
      setStatus(statusEl, err?.message || "Copy failed.", "error");
      setIconButtonLabel(button, "Copy failed");
    } finally {
      button.disabled = false;
      setTimeout(() => {
        if (!button.isConnected) {
          return;
        }
        const sections = api.findItemMappingsSections?.() || [];
        let count = 0;
        for (const section of sections) {
          count += api.collectItemMappingLinks?.(section)?.length || 0;
        }
        setIconButtonLabel(
          button,
          api.getButtonLabel?.(count) || (count === 1 ? "Copy link" : "Copy links")
        );
      }, 2000);
    }
  }

  function getCopyItemDataLabel(displayName) {
    return `Copy ${displayName || "Channel"} Item Data`;
  }

  /**
   * Shared Item Mappings actions previously injected under the native section.
   * @returns {{ statusEl: HTMLElement, itemDataBtn: HTMLButtonElement|null }}
   */
  function renderSharedMappingActions(bodyEl, state, options = {}) {
    const includeItemData = options.includeItemData !== false;
    window.ItemMappingLinkCopy?.injectActionStyles?.();

    const sectionLabel = document.createElement("div");
    sectionLabel.className = "fhx-mapping-tools-panel__section-label";
    sectionLabel.textContent = "Item mappings";
    bodyEl.appendChild(sectionLabel);

    const actions = document.createElement("div");
    actions.className = "fhx-mapping-tools-panel__icon-actions";

    const linkApi = window.ItemMappingLinkCopy;
    let linkCount = 0;
    for (const section of linkApi?.findItemMappingsSections?.() || []) {
      linkCount += linkApi.collectItemMappingLinks?.(section)?.length || 0;
    }
    const linkLabel =
      linkApi?.getButtonLabel?.(linkCount) ||
      (linkCount === 1 ? "Copy link" : "Copy links");

    const linkBtn = createPanelIconButton(
      linkLabel,
      () => linkApi?.createLinkIcon?.() || document.createTextNode("")
    );
    actions.appendChild(linkBtn);

    let itemDataBtn = null;
    if (includeItemData && state.hasCopyOneItem) {
      const sep = document.createElement("span");
      sep.className = "fhx-mapping-tools-panel__icon-sep";
      sep.setAttribute("aria-hidden", "true");
      sep.textContent = "·";
      actions.appendChild(sep);

      itemDataBtn = createPanelIconButton(
        getCopyItemDataLabel(state.displayName),
        () =>
          linkApi?.createClipboardIcon?.() ||
          document.createTextNode("")
      );
      actions.appendChild(itemDataBtn);
    }

    bodyEl.appendChild(actions);

    const statusEl = document.createElement("div");
    statusEl.className = "fhx-mapping-tools-panel__status";
    statusEl.setAttribute("data-fhx-mtp-status", "true");
    bodyEl.appendChild(statusEl);

    linkBtn.addEventListener("click", () => {
      runCopyMappedLinks(linkBtn, statusEl);
    });

    if (itemDataBtn && state.affiliateKey) {
      itemDataBtn.addEventListener("click", () => {
        runCopyOneItem(state.affiliateKey, itemDataBtn, statusEl);
      });
    }

    return { statusEl, itemDataBtn };
  }

  function renderExpediaControls(bodyEl, state) {
    renderSharedMappingActions(bodyEl, state);
    renderExpediaStartTimesSection(bodyEl);
  }

  function renderGygControls(bodyEl, state) {
    // Copy link first; item-data button sits after options so enrichment toggles apply.
    const { statusEl } = renderSharedMappingActions(bodyEl, state, {
      includeItemData: false
    });

    const optionsLabel = document.createElement("div");
    optionsLabel.className = "fhx-mapping-tools-panel__section-label";
    optionsLabel.textContent = "Copy options";
    bodyEl.appendChild(optionsLabel);

    const options = document.createElement("div");
    options.className = "fhx-mapping-tools-panel__options";

    options.appendChild(
      createCheckbox(
        "fhx-mtp-gyg-prices",
        "Include prices (slower)",
        gygOptions.includePrices,
        (checked) => {
          gygOptions.includePrices = checked;
          persistGygOptions();
        }
      )
    );
    options.appendChild(
      createCheckbox(
        "fhx-mtp-gyg-capacity",
        "Include capacity settings (slower)",
        gygOptions.includeCapacitySettings,
        (checked) => {
          gygOptions.includeCapacitySettings = checked;
          persistGygOptions();
        }
      )
    );

    const capacityHint = document.createElement("p");
    capacityHint.className = "fhx-mapping-tools-panel__hint";
    capacityHint.style.margin = "0 0 2px";
    capacityHint.textContent =
      "⚠️ For complex price sheets or capacity rules, double-check enriched values. ⚠️";
    options.appendChild(capacityHint);

    const divider = document.createElement("hr");
    divider.className = "fhx-mapping-tools-panel__options-divider";
    options.appendChild(divider);

    options.appendChild(
      createSegmentedControl(
        "Item name",
        "useChannelName",
        [
          { value: false, label: "Item name" },
          { value: true, label: "Channel name" }
        ],
        gygOptions.useChannelName,
        (value) => {
          gygOptions.useChannelName = value;
          persistGygOptions();
        }
      )
    );
    options.appendChild(
      createSegmentedControl(
        "Output format",
        "useTSVFormat",
        [
          { value: false, label: "Zendesk" },
          { value: true, label: "Sheets" }
        ],
        gygOptions.useTSVFormat,
        (value) => {
          gygOptions.useTSVFormat = value;
          persistGygOptions();
        }
      )
    );
    options.appendChild(
      createSegmentedControl(
        "Header row",
        "includeHeaderRow",
        [
          { value: false, label: "No header" },
          { value: true, label: "Include header" }
        ],
        gygOptions.includeHeaderRow,
        (value) => {
          gygOptions.includeHeaderRow = value;
          persistGygOptions();
        }
      )
    );

    bodyEl.appendChild(options);

    const itemActions = document.createElement("div");
    itemActions.className = "fhx-mapping-tools-panel__icon-actions";
    const itemDataBtn = createPanelIconButton(
      getCopyItemDataLabel(state.displayName),
      () => window.ItemMappingLinkCopy?.createClipboardIcon?.() || document.createTextNode("")
    );
    itemActions.appendChild(itemDataBtn);
    bodyEl.appendChild(itemActions);

    itemDataBtn.addEventListener("click", () => {
      runCopyOneItem("getyourguide", itemDataBtn, statusEl);
    });

    // Status after the item-data action for enrichment progress.
    bodyEl.appendChild(statusEl);
  }

  function renderPanelContent(panel, state) {
    const channelEl = panel.querySelector("[data-fhx-mtp-channel]");
    const bodyEl = panel.querySelector("[data-fhx-mtp-body]");
    if (!channelEl || !bodyEl) {
      return;
    }

    disconnectStartTimesSubscription();
    channelEl.textContent = "";
    bodyEl.textContent = "";
    activeAffiliateKey = state.affiliateKey || null;
    copyInProgress = false;
    copyGeneration += 1;
    if (state.affiliateKey !== "expedia") {
      panelScanTargetKey = null;
      selectedConnectedItemKey = null;
      connectedItemsCache = [];
    }

    if (state.status === "loading") {
      setChannelLabel(channelEl, "Detecting…");
      const empty = document.createElement("p");
      empty.className = "fhx-mapping-tools-panel__empty";
      empty.textContent = "Resolving channel tools…";
      bodyEl.appendChild(empty);
      return;
    }

    if (state.status === "error" || state.status === "unknown") {
      setChannelLabel(channelEl, state.displayName || "Unknown");
      renderSharedMappingActions(bodyEl, {
        ...state,
        hasCopyOneItem: false
      });
      const empty = document.createElement("p");
      empty.className = "fhx-mapping-tools-panel__empty";
      empty.textContent =
        state.message || "No mapping tools are available for this channel.";
      bodyEl.appendChild(empty);
      return;
    }

    setChannelLabel(channelEl, state.displayName);

    if (state.affiliateKey === "getyourguide" && state.hasCopyOneItem) {
      // Prefetch may already have loaded options, in which case the callback runs
      // synchronously — only show the loading placeholder when still waiting.
      let optionsReady = false;
      loadGygOptions(() => {
        optionsReady = true;
        if (activeAffiliateKey !== "getyourguide") {
          return;
        }
        bodyEl.textContent = "";
        setChannelLabel(channelEl, state.displayName);
        renderGygControls(bodyEl, state);
      });
      if (!optionsReady) {
        const loading = document.createElement("p");
        loading.className = "fhx-mapping-tools-panel__empty";
        loading.textContent = "Loading options…";
        bodyEl.appendChild(loading);
      }
      return;
    }

    if (state.affiliateKey === "expedia" && state.hasCopyOneItem) {
      renderExpediaControls(bodyEl, state);
      return;
    }

    renderSharedMappingActions(bodyEl, state);
    if (state.emptyMessage) {
      const empty = document.createElement("p");
      empty.className = "fhx-mapping-tools-panel__empty";
      empty.textContent = state.emptyMessage;
      bodyEl.appendChild(empty);
    }
  }

  function ensureLayout(mappingsSection, panel) {
    const host = mappingsSection.parentElement;
    if (!host) {
      return false;
    }

    injectStyles();

    if (!host.hasAttribute(LAYOUT_HOST_ATTR)) {
      host.setAttribute(LAYOUT_HOST_ATTR, "true");
      host.classList.add(LAYOUT_HOST_CLASS);
    }

    mappingsSection.setAttribute(NATIVE_MARK_ATTR, "true");

    if (panel.parentElement !== host || mappingsSection.nextElementSibling !== panel) {
      mappingsSection.insertAdjacentElement("afterend", panel);
    }

    bindLayoutResize(host);
    applyWidenClass(true);
    return true;
  }

  function contextKeyFromPage(pageContext, affiliateKey) {
    if (!pageContext) {
      return null;
    }
    return [
      pageContext.shortname || "",
      pageContext.companyPk || "",
      pageContext.resellerItemId || "",
      affiliateKey || ""
    ].join(":");
  }

  async function resolveOtaState(pageContext, generation) {
    const api = window.MappingCopyButton;
    if (!api?.fetchResellerCompany) {
      return {
        status: "error",
        displayName: "Unknown",
        message: "Channel detection is not ready yet.",
        affiliateKey: null
      };
    }

    try {
      const result = await api.fetchResellerCompany(pageContext);
      if (generation !== ensureGeneration) {
        return null;
      }
      if (!result?.ok) {
        return {
          status: "error",
          displayName: "Unknown",
          message: result?.error || "Could not determine the channel.",
          affiliateKey: null
        };
      }

      const affiliateKey = result.strategy?.affiliateKey || null;
      const registryEntry = affiliateKey ? OTA_TOOL_REGISTRY[affiliateKey] : null;
      const displayName =
        registryEntry?.displayName ||
        result.strategy?.displayName ||
        affiliateKey ||
        "Unknown";

      if (!registryEntry) {
        return {
          status: "unknown",
          displayName,
          affiliateKey,
          message: "No mapping tools are registered for this channel yet."
        };
      }

      return {
        status: "ready",
        displayName,
        affiliateKey,
        hasCopyOneItem: !!registryEntry.hasCopyOneItem,
        emptyMessage: registryEntry.emptyMessage || null
      };
    } catch (err) {
      warn("OTA resolve failed:", err);
      if (generation !== ensureGeneration) {
        return null;
      }
      return {
        status: "error",
        displayName: "Unknown",
        message: "Could not determine the channel.",
        affiliateKey: null
      };
    }
  }

  async function ensurePanel(reason) {
    if (!featureEnabled || !isFareHarborHost()) {
      removePanel();
      return;
    }

    const pageContext = parseChannelItemPageContext();
    if (!pageContext) {
      removePanel();
      return;
    }

    const mappingsSection = findItemMappingsResellerSection();
    if (!mappingsSection) {
      // Path matches but Angular content not ready — wait for observer.
      log("mappings section not ready", { reason });
      return;
    }

    injectStyles();

    let panel = document.getElementById(PANEL_ID);
    const created = !panel;
    if (!panel) {
      panel = buildPanelShell();
    }

    if (!ensureLayout(mappingsSection, panel)) {
      if (created) {
        panel.remove();
      }
      return;
    }

    const generation = ++ensureGeneration;
    const pageKey = contextKeyFromPage(pageContext, "");
    if (created || pageKey !== lastPageKey) {
      panelScanTargetKey = null;
      selectedConnectedItemKey = null;
      connectedItemsCache = [];
      renderPanelContent(panel, { status: "loading" });
      lastPageKey = pageKey;
      lastContextKey = null;
    }

    const otaState = await resolveOtaState(pageContext, generation);
    if (!otaState || generation !== ensureGeneration) {
      return;
    }

    // Panel may have been removed while resolving.
    if (!document.getElementById(PANEL_ID) || !isPageEligible()) {
      removePanel();
      return;
    }

    const nextKey = contextKeyFromPage(
      pageContext,
      otaState.affiliateKey || otaState.status
    );
    if (nextKey !== lastContextKey) {
      renderPanelContent(panel, otaState);
      lastContextKey = nextKey;
      log("panel updated", {
        reason,
        affiliateKey: otaState.affiliateKey,
        status: otaState.status
      });
    }
  }

  function scheduleEnsure(reason) {
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }
    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      ensurePanel(reason || "scan").catch((err) => {
        warn("ensurePanel failed:", err);
      });
    }, SCAN_DEBOUNCE_MS);
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    observeRoot = null;
  }

  function startObserver() {
    const preferredRoot =
      document.querySelector(SETTINGS_WRAP_SELECTOR) ||
      document.querySelector(SETTINGS_WINDOW_SELECTOR) ||
      document.documentElement;

    if (observer && observeRoot === preferredRoot) {
      return;
    }

    stopObserver();
    observeRoot = preferredRoot;
    observer = new MutationObserver((mutations) => {
      if (!featureEnabled || !isChannelItemMappingPath()) {
        return;
      }
      if (mutations.length > 0 && mutations.every(isExtensionMutation)) {
        return;
      }
      scheduleEnsure("mutation");
    });
    observer.observe(observeRoot, { childList: true, subtree: true });
    log("observer started", { root: observeRoot === document.documentElement ? "document" : "scoped" });
  }

  function evaluateLifecycle(reason) {
    if (!featureEnabled) {
      stopObserver();
      removePanel();
      watchersActive = false;
      return;
    }

    if (!isFareHarborHost()) {
      stopObserver();
      removePanel();
      watchersActive = false;
      return;
    }

    if (isChannelItemMappingPath()) {
      if (!watchersActive) {
        log("eligible path detected", { reason, href: location.href });
        watchersActive = true;
      }
      startObserver();
      scheduleEnsure(reason || "lifecycle");
      return;
    }

    if (watchersActive) {
      log("left mapping item page", { reason, href: location.href });
    }
    stopObserver();
    removePanel();
    watchersActive = false;
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  function applyFeatureSetting(enabled, reason) {
    const next = enabled !== false;
    if (featureEnabled === next && reason !== "settings-init") {
      return;
    }
    featureEnabled = next;
    log("feature setting applied", { enabled: featureEnabled, reason });
    if (!featureEnabled) {
      stopObserver();
      removePanel();
      watchersActive = false;
      return;
    }
    evaluateLifecycle(reason || "setting-change");
  }

  function initSettingsBinding() {
    if (settingsBound) {
      return;
    }
    const settings = window.FHSettings;
    if (!settings) {
      return;
    }
    settingsBound = true;
    settings.get(SETTING_KEY, (value) => {
      applyFeatureSetting(value, "settings-init");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SETTING_KEY]) {
        applyFeatureSetting(changes[SETTING_KEY].newValue, "setting-change");
      }
    });
  }

  function bindSpaLifecycle() {
    if (spaUnsubscribe || !window.FareHarborSpaLifecycle?.subscribe) {
      return;
    }
    spaUnsubscribe = window.FareHarborSpaLifecycle.subscribe((reason) => {
      lastContextKey = null;
      lastPageKey = null;
      scheduleLifecycleEval(reason);
    });
  }

  function init() {
    initSettingsBinding();
    bindSpaLifecycle();
    bindGygStorageListener();
    // Prefetch so recreation after navigation does not flash defaults.
    loadGygOptions(() => {});

    const boot = () => {
      evaluateLifecycle("dom-content-loaded");
      scheduleLifecycleEval("body-ready");
    };

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", boot, { once: true });
    } else {
      boot();
    }
  }

  window.MappingToolsPanel = {
    SETTING_KEY,
    OTA_TOOL_REGISTRY,
    CHANNEL_ITEM_PAGE_RE,
    parseChannelItemPageContext,
    isPageEligible,
    findItemMappingsResellerSection
  };

  init();
  log("Module initialized");
})();
