(function initializeFareHarborTotalPricingResolution() {
  "use strict";

  function getPricingObjectPk(pricingObject) {
    if (!pricingObject || typeof pricingObject !== "object") return null;
    if (pricingObject.pk !== null && pricingObject.pk !== undefined) {
      return pricingObject.pk;
    }
    const uri = String(pricingObject.uri ?? "");
    const sheetMatch = uri.match(/total-sheets\/(\d+)/i);
    if (sheetMatch) return sheetMatch[1];
    const scheduleMatch = uri.match(/total-schedules\/(\d+)/i);
    if (scheduleMatch) return scheduleMatch[1];
    return null;
  }

  function getPricingObjectType(pricingObject) {
    if (!pricingObject || typeof pricingObject !== "object") return null;
    const cls = String(pricingObject.cls ?? "").trim();
    if (cls === "TotalSheet" || cls === "total_sheet" || cls === "Total Sheet") {
      return "sheet";
    }
    if (cls === "TotalSchedule" || cls === "total_schedule" || cls === "Total Schedule") {
      return "schedule";
    }
    const uri = String(pricingObject.uri ?? "");
    if (uri.includes("/total-sheets/")) return "sheet";
    if (uri.includes("/total-schedules/")) return "schedule";
    return null;
  }

  function getTotalScheduleEntries(schedule) {
    if (!schedule || typeof schedule !== "object") {
      return [];
    }

    const candidateCollections = [
      schedule.entries,
      schedule.schedule_entries,
      schedule.total_schedule_entries
    ];

    for (const collection of candidateCollections) {
      if (Array.isArray(collection)) {
        return collection;
      }
      if (collection && Array.isArray(collection.items)) {
        return collection.items;
      }
    }

    return [];
  }

  function getSheetFromScheduleEntry(entry) {
    if (!entry || typeof entry !== "object") return null;
    return entry.sheet ?? entry.total_sheet ?? entry.totalSheet ?? null;
  }

  function getSheetDisplayName(sheet, pk) {
    if (!sheet || typeof sheet !== "object") {
      return pk != null ? `Sheet ${pk}` : "unknown";
    }
    return (
      sheet.display_name ??
      sheet.displayName ??
      sheet.name ??
      sheet.unicode ??
      (pk != null ? `Sheet ${pk}` : "unknown")
    );
  }

  function extractTotalSheetsFromSchedule(schedule) {
    const sheets = [];
    const seen = new Set();

    for (const entry of getTotalScheduleEntries(schedule)) {
      const sheet = getSheetFromScheduleEntry(entry);
      const pk = getPricingObjectPk(sheet);
      if (pk === null || pk === undefined) continue;
      const key = String(pk);
      if (seen.has(key)) continue;
      seen.add(key);
      sheets.push({
        pk,
        name: getSheetDisplayName(sheet, pk),
        sheet
      });
    }

    return sheets;
  }

  window.FareHarborTotalPricingResolution = {
    getPricingObjectPk,
    getPricingObjectType,
    getTotalScheduleEntries,
    getSheetFromScheduleEntry,
    getSheetDisplayName,
    extractTotalSheetsFromSchedule
  };
})();
