console.log("[duplicate-customer-types] duplicate-customer-types.js loaded");

// Wait for utilities to be available and initialize module
(function initializeDuplicateCustomerTypes() {
  // Wait for FareHarborUtils to be available
  if (!window.FareHarborUtils) {
    setTimeout(initializeDuplicateCustomerTypes, 10);
    return;
  }
  
  // Now utilities are available, set up the module
  const utils = window.FareHarborUtils;
  const LOG_PREFIX = "[duplicate-customer-types]";

  class DuplicateApiWorkflowError extends Error {
    constructor(message, { completedCount, totalCount, isPartialFailure }) {
      super(message);
      this.name = "DuplicateApiWorkflowError";
      this.completedCount = completedCount;
      this.totalCount = totalCount;
      this.isPartialFailure = isPartialFailure;
    }
  }

  function getCustomerTypeBlocks() {
    return utils.$$(utils.SELECTORS.CUSTOMER_TYPE_BLOCKS);
  }

  function getCurrentCompanyAndItemFromUrl() {
    const parts = (window.location.pathname || "").split("/").filter(Boolean);
    const dashIdx = parts.indexOf("dashboard");
    if (dashIdx < 1 || parts[dashIdx + 1] !== "items" || !parts[dashIdx + 2]) {
      return null;
    }
    return {
      company: parts[0],
      itemId: parts[dashIdx + 2],
      apiBase: window.location.origin
    };
  }

  function getCookie(name) {
    return (
      document.cookie
        .split("; ")
        .find((row) => row.startsWith(`${name}=`))
        ?.split("=")
        .slice(1)
        .join("=") || ""
    );
  }

  function getCsrfToken() {
    return (
      getCookie("csrftoken") ||
      getCookie("csrf_token") ||
      getCookie("CSRF-TOKEN") ||
      ""
    );
  }

  let csrfWriteLogEmitted = false;

  async function fhApiFetch(path, options = {}, apiBase) {
    const url = `${apiBase}/api/v1${path}`;
    const method = (options.method || "GET").toUpperCase();
    const unsafeMethods = new Set(["POST", "PUT", "PATCH", "DELETE"]);
    const headers = { Accept: "application/json" };

    if (options.body !== undefined) {
      headers["Content-Type"] = "application/json;charset=utf-8";
    }

    if (unsafeMethods.has(method)) {
      const token = getCsrfToken();
      if (!token) {
        console.warn(LOG_PREFIX, "CSRF token missing; using DOM fallback");
        throw new Error("CSRF token not found; cannot use API write workflow");
      }
      if (!csrfWriteLogEmitted) {
        console.log(LOG_PREFIX, "CSRF token found for API write workflow");
        csrfWriteLogEmitted = true;
      }
      headers["X-CSRFToken"] = token;
      headers["X-Requested-With"] = "XMLHttpRequest";
    }

    const response = await fetch(url, {
      method,
      credentials: "include",
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined
    });

    const text = await response.text();
    let data = null;
    if (text) {
      try {
        data = JSON.parse(text);
      } catch (parseErr) {
        if (!response.ok) {
          console.error(LOG_PREFIX, "API response not JSON:", text);
          throw new Error(`API ${response.status}: ${text}`);
        }
      }
    }

    if (!response.ok) {
      console.error(LOG_PREFIX, "API error body:", data || text);
      const detail =
        data && typeof data === "object"
          ? JSON.stringify(data)
          : text || response.statusText;
      throw new Error(`API ${response.status}: ${detail}`);
    }

    return data;
  }

  async function fetchCustomerPrototypes(company, itemId, apiBase) {
    const data = await fhApiFetch(
      `/companies/${encodeURIComponent(company)}/items/${encodeURIComponent(itemId)}/customer-prototypes/?include-is-inactive=yes`,
      {},
      apiBase
    );
    return data?.customer_prototypes || [];
  }

  async function fetchPricingForEditing(company, totalSheetId, itemId, apiBase) {
    const data = await fhApiFetch(
      `/companies/${encodeURIComponent(company)}/total-sheets/${encodeURIComponent(totalSheetId)}/pricing-for-editing/Item/${encodeURIComponent(itemId)}/`,
      {},
      apiBase
    );
    return data?.effective_pricings || [];
  }

  function buildCustomerPrototypeUpdatePayload(prototype, patch) {
    const payload = {
      cls: prototype.cls,
      uri: prototype.uri,
      pk: prototype.pk,
      name: prototype.name,
      note: prototype.note,
      display_name: prototype.display_name,
      is_exclusive: prototype.is_exclusive,
      is_price_preview_base: prototype.is_price_preview_base,
      is_hidden: prototype.is_hidden,
      is_archived: prototype.is_archived,
      capacity: prototype.capacity,
      minimum_party_size: prototype.minimum_party_size,
      maximum_party_size: prototype.maximum_party_size,
      minimum_age: prototype.minimum_age,
      maximum_age: prototype.maximum_age,
      minimum_group_size: prototype.minimum_group_size,
      maximum_group_size: prototype.maximum_group_size,
      unicode: prototype.unicode,
      is_inactive: prototype.is_inactive,
      settings: prototype.settings
    };
    return Object.assign(payload, patch);
  }

  async function updateCustomerPrototype(company, itemId, prototype, patch, apiBase) {
    const path = `/companies/${encodeURIComponent(company)}/items/${encodeURIComponent(itemId)}/customer-prototypes/${encodeURIComponent(prototype.pk)}/`;
    const merged = Object.assign({}, prototype, patch);
    try {
      const data = await fhApiFetch(path, { method: "PUT", body: merged }, apiBase);
      return data?.customer_prototype || merged;
    } catch (firstErr) {
      console.warn(LOG_PREFIX, "Full PUT failed, retrying normalized payload:", firstErr.message);
      const normalized = buildCustomerPrototypeUpdatePayload(prototype, patch);
      const data = await fhApiFetch(path, { method: "PUT", body: normalized }, apiBase);
      return data?.customer_prototype || normalized;
    }
  }

  async function duplicateCustomerPrototype(company, itemId, basePrototype, apiBase) {
    const data = await fhApiFetch(
      `/companies/${encodeURIComponent(company)}/items/${encodeURIComponent(itemId)}/customer-prototypes/${encodeURIComponent(basePrototype.pk)}/duplicate/`,
      {
        method: "POST",
        body: {
          item: itemId,
          customer_type: basePrototype.customer_type.pk
        }
      },
      apiBase
    );
    return data?.customer_prototype;
  }

  function getDomCustomerTypeNames() {
    const names = [];
    getCustomerTypeBlocks().forEach((block) => {
      const nameSpan = utils.$(utils.SELECTORS.CUSTOMER_TYPE_NAME, block);
      if (nameSpan) {
        const name = nameSpan.textContent.trim();
        if (name) names.push(name);
      }
    });
    return names;
  }

  function normalizeCustomerTypeName(name) {
    return (name || "").split("\n")[0].trim();
  }

  function prototypeMatchesName(prototype, targetName) {
    const cleanTarget = normalizeCustomerTypeName(targetName);
    const candidates = [prototype?.name, prototype?.display_name].filter(Boolean);
    for (const candidate of candidates) {
      const clean = normalizeCustomerTypeName(candidate);
      if (clean === cleanTarget) return true;
      if (clean.startsWith(cleanTarget) || cleanTarget.startsWith(clean)) return true;
    }
    return false;
  }

  function findPrototypeByName(prototypes, targetName) {
    if (!targetName) return null;
    return prototypes.find((p) => prototypeMatchesName(p, targetName)) || null;
  }

  function findPrototypeByBaseIndex(prototypes, baseIndex) {
    const domNames = getDomCustomerTypeNames();
    const selectedName = domNames[baseIndex];
    let prototype = selectedName ? findPrototypeByName(prototypes, selectedName) : null;
    if (!prototype && prototypes[baseIndex]) {
      prototype = prototypes[baseIndex];
    }
    if (prototype) {
      console.log(
        LOG_PREFIX,
        "Base prototype:",
        prototype.name || prototype.display_name,
        "pk:",
        prototype.pk,
        "customer_type.pk:",
        prototype.customer_type?.pk
      );
    }
    return prototype;
  }

  function extractTotalSheetIdsFromText(text) {
    const ids = [];
    if (!text) return ids;
    const re = /total-sheets\/(\d+)/g;
    let match;
    while ((match = re.exec(text)) !== null) {
      ids.push(match[1]);
    }
    return ids;
  }

  function escapeRegExp(str) {
    return String(str).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function getTotalSheetIdFromPerformanceEntries(company, itemId) {
    const companyPath = `/api/v1/companies/${company}/total-sheets/`;
    const itemPath = `/pricing-for-editing/Item/${itemId}/`;
    const idPattern = new RegExp(
      `/api/v1/companies/${escapeRegExp(company)}/total-sheets/(\\d+)/pricing-for-editing/Item/${escapeRegExp(itemId)}/`
    );

    const ids = new Set();
    for (const entry of performance.getEntriesByType("resource")) {
      const name = entry.name || "";
      if (!name.includes(companyPath) || !name.includes(itemPath)) {
        continue;
      }
      const match = name.match(idPattern);
      if (match) {
        ids.add(match[1]);
      }
    }

    if (ids.size === 1) {
      const sheetId = Number([...ids][0]);
      console.log(
        LOG_PREFIX,
        `Active total sheet for pricing: ${sheetId} (source: performance-pricing-for-editing)`
      );
      return { sheetId, source: "performance-pricing-for-editing" };
    }
    if (ids.size > 1) {
      console.warn(
        LOG_PREFIX,
        "Ambiguous total sheet IDs from performance entries:",
        [...ids]
      );
    }
    return null;
  }

  function getConfidentActiveTotalSheetId(company, itemId) {
    const activeIds = new Set();
    const selectors = [
      "a.active",
      "a.selected",
      "li.active a",
      "li.selected a",
      '[aria-selected="true"]',
      "option[selected]"
    ];
    const seen = new Set();
    for (const selector of selectors) {
      for (const el of document.querySelectorAll(selector)) {
        if (seen.has(el)) continue;
        seen.add(el);
        const href = el.getAttribute("href") || el.getAttribute("ng-href") || "";
        const dataHref = el.getAttribute("data-href") || "";
        for (const id of extractTotalSheetIdsFromText(href + " " + dataHref)) {
          activeIds.add(id);
        }
      }
    }

    if (activeIds.size === 1) {
      const sheetId = [...activeIds][0];
      console.log(LOG_PREFIX, `Active total sheet for pricing: ${sheetId} (source: dom)`);
      return { sheetId, source: "dom" };
    }
    if (activeIds.size > 1) {
      console.warn(LOG_PREFIX, "Ambiguous active total sheet IDs in DOM:", [...activeIds]);
      return null;
    }

    const urlText = (window.location.pathname || "") + (window.location.hash || "");
    const urlIds = [...new Set(extractTotalSheetIdsFromText(urlText))];
    if (urlIds.length === 1) {
      console.log(LOG_PREFIX, `Active total sheet for pricing: ${urlIds[0]} (source: url)`);
      return { sheetId: urlIds[0], source: "url" };
    }
    if (urlIds.length > 1) {
      console.warn(LOG_PREFIX, "Ambiguous total sheet IDs in URL:", urlIds);
    }

    if (company && itemId) {
      const fromPerformance = getTotalSheetIdFromPerformanceEntries(company, itemId);
      if (fromPerformance) {
        return fromPerformance;
      }
    }

    return null;
  }

  // Customer Type specific click helpers
  function clickEditCustomerTypeButton() {
    return utils.clickButton(utils.SELECTORS.EDIT_CUSTOMER_TYPE_BTN);
  }

  function clickDuplicateCustomerTypeButton() {
    return utils.clickButton(utils.SELECTORS.DUPLICATE_CUSTOMER_TYPE_BTN);
  }

  function clickConfirmDuplicateButton() {
    return utils.clickButton(utils.SELECTORS.CONFIRM_DUPLICATE_BTN);
  }

  function clickSaveEditForm() {
    return utils.clickButton(utils.SELECTORS.SAVE_EDIT_BTN);
  }

  // Price-related functions (scoped to edit form context)
  function clickPriceSpan() {
    // Look for price span within the edit form context
    const nameInput = utils.$(utils.SELECTORS.NAME_INPUT);
    if (nameInput) {
      const form = nameInput.closest('form, .modal, .edit-form, [ng-controller]');
      if (form) {
        const priceSpan = utils.$(utils.SELECTORS.PRICE_SPAN, form);
        if (priceSpan) {
          priceSpan.click();
          return true;
        }
      }
    }
    
    // Fallback: look for any price span that's visible and clickable
    const priceSpans = utils.$$(utils.SELECTORS.PRICE_SPAN);
    for (const span of priceSpans) {
      if (span.offsetParent !== null) {
        span.click();
        return true;
      }
    }
    
    return false;
  }

  function clickPriceSaveButton() {
    const nameInput = utils.$(utils.SELECTORS.NAME_INPUT);
    if (nameInput) {
      const form = nameInput.closest('form, .modal, .edit-form, [ng-controller]');
      if (form) {
        const saveBtn = utils.$(utils.SELECTORS.PRICE_SAVE_BTN, form);
        if (saveBtn) {
          saveBtn.click();
          return true;
        }
      }
    }
    
    return utils.clickButton(utils.SELECTORS.PRICE_SAVE_BTN);
  }

  function selectChangeFromDropdown() {
    // Look for the specific select element for price type
    const selectElement = utils.$(utils.SELECTORS.PRICE_DROPDOWN_SELECT);
    if (selectElement) {
      selectElement.value = 'string:change';
      selectElement.dispatchEvent(new Event('change', { bubbles: true }));
      selectElement.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    }
    
    // Fallback method: Look for the Change option directly
    const changeOption = utils.$(utils.SELECTORS.PRICE_CHANGE_OPTION);
    if (changeOption) {
      changeOption.selected = true;
      const parentSelect = changeOption.closest('select');
      if (parentSelect) {
        parentSelect.value = changeOption.value;
        parentSelect.dispatchEvent(new Event('change', { bubbles: true }));
        parentSelect.dispatchEvent(new Event('input', { bubbles: true }));
      }
      return true;
    }
    
    // Final fallback: Look for any elements with "Change" text
    const allOptions = utils.$$('option, select, [ng-model]');
    
    for (const element of allOptions) {
      const text = element.textContent.trim().toLowerCase();
      const value = element.value || '';
      const label = element.getAttribute('label') || '';
      
      if (text === 'change' || value.includes('change') || label.toLowerCase() === 'change') {
        if (element.tagName === 'OPTION') {
          element.selected = true;
          const parentSelect = element.closest('select');
          if (parentSelect) {
            parentSelect.value = element.value;
            parentSelect.dispatchEvent(new Event('change', { bubbles: true }));
            parentSelect.dispatchEvent(new Event('input', { bubbles: true }));
          }
        } else if (element.tagName === 'SELECT') {
          element.value = value;
          element.dispatchEvent(new Event('change', { bubbles: true }));
          element.dispatchEvent(new Event('input', { bubbles: true }));
        }
        return true;
      }
    }
    
    console.warn('Could not find "Change" option in dropdown');
    return false;
  }

  function setPriceInput(price) {
    // Look for price input in edit form context first
    const nameInput = utils.$(utils.SELECTORS.NAME_INPUT);
    let priceInput = null;
    
    if (nameInput) {
      const form = nameInput.closest('form, .modal, .edit-form, [ng-controller]');
      if (form) {
        priceInput = utils.$(utils.SELECTORS.PRICE_OFFSET_INPUT, form);
      }
    }
    
    // Fallback to global search
    if (!priceInput) {
      priceInput = utils.$(utils.SELECTORS.PRICE_OFFSET_INPUT);
    }
    
    if (!priceInput) {
      return false;
    }
    
    return utils.setInputValue(priceInput, formatPrice(price));
  }

  function formatPrice(price) {
    // Ensure the price has max 2 decimal places and uses dot as separator
    const roundedPrice = Math.round(price * 100) / 100;
    return roundedPrice.toFixed(2);
  }

  // Wait for pricing elements to be fully loaded in a customer type block
  // Returns the price element found, or throws if not found within timeout
  async function waitForPriceElementsInBlock(block, timeout = 5000) {
    return utils.createPollingPromise(() => {
      // Look for the specific price cell with title="Price" - this is what we need to click
      const priceCell = utils.$('[title="Price"]', block);
      if (priceCell && priceCell.offsetParent !== null) {
        return priceCell; // Return the actual element we found
      }
      
      // Alternative: look for data-test-id containing "pricing" (the price button)
      const pricingButton = utils.$('[data-test-id*="pricing-button"]', block);
      if (pricingButton && pricingButton.offsetParent !== null) {
        return pricingButton;
      }
      
      // Check for .td.price element
      const tdPrice = utils.$('.td.price', block);
      if (tdPrice && tdPrice.offsetParent !== null) {
        return tdPrice;
      }
      
      // Not found yet - return false to keep polling
      return false;
    }, timeout, 200);
  }

  function calculateDividedPriceDisplay(basePrice, divisionIndex) {
    return Math.round((basePrice / divisionIndex) * 100) / 100;
  }

  function toMinorUnits(amount) {
    return Math.round(amount * 100);
  }

  function calculateDividedPrice(basePrice, divisionIndex) {
    return calculateDividedPriceDisplay(basePrice, divisionIndex);
  }

  function formatPricingPayloadSummary(payload) {
    if (!payload) return "";
    return (
      `offset=${payload.offset}, rate=${payload.rate}, price_type=${payload.price_type}, ` +
      `sheet_rate_type=${payload.sheet_rate_type}, visibility=${payload.visibility}`
    );
  }

  function buildPricingPayloadFromEffectivePricing(_row, dividedPriceDisplay) {
    const offsetMinor = toMinorUnits(dividedPriceDisplay);

    // This payload intentionally mirrors FareHarbor's own pricing form request. Some values differ
    // from the pricing-for-editing response:
    // - sheet_rate is 100 in the form payload, although pricing-for-editing shows sheet_rate 1
    // - is_taxable is an empty string for inherited taxability
    // - is_recalculate_tax is false
    // - is_tax_pass_through is true
    const payload = {
      sheet_rate_type: "inherit",
      sheet_rate: 100,
      price_type: "change",
      offset: offsetMinor,
      modifier_kind: "offset",
      modifier_type: "adjust",
      rate: 0,
      is_taxable: "",
      tax_inclusion: "included",
      custom_tax: "no",
      tax_types: {},
      is_tax_pass_through: true,
      visibility: "inherit",
      is_required: false,
      is_hidden_when_booking: false,
      is_hidden_on_receipts: false,
      is_recalculate_tax: false
    };

    console.log(LOG_PREFIX, "Pricing payload mode: fareharbor-dom-compatible");
    return payload;
  }

  function findPricingRowForPrototype(effectivePricings, customerPrototypeId) {
    const idStr = String(customerPrototypeId);
    for (const row of effectivePricings) {
      if (row?.for_object?.pk != null && String(row.for_object.pk) === idStr) {
        return row;
      }
      const uri = row?.for_object?.uri || "";
      if (uri.includes(`/CustomerPrototype/${idStr}/`)) {
        return row;
      }
    }
    return null;
  }

  function parseApiErrorBodyFromMessage(message) {
    const match = /API \d{3}: (.+)/s.exec(message || "");
    if (!match) return null;
    try {
      return JSON.parse(match[1]);
    } catch {
      return null;
    }
  }

  async function putCustomerPrototypePricingPayload(
    company,
    totalSheetId,
    customerPrototypeId,
    payload,
    apiBase
  ) {
    const path = `/companies/${encodeURIComponent(company)}/total-sheets/${encodeURIComponent(totalSheetId)}/pricing/CustomerPrototype/${encodeURIComponent(customerPrototypeId)}/`;
    try {
      await fhApiFetch(path, { method: "PUT", body: payload }, apiBase);
      return { ok: true };
    } catch (err) {
      return { ok: false, error: err.message, apiBody: parseApiErrorBodyFromMessage(err.message) };
    }
  }

  async function updateCustomerPrototypePrice(
    company,
    totalSheetId,
    itemId,
    customerPrototypeId,
    dividedPriceDisplay,
    basePrototypeId,
    apiBase
  ) {
    let row = null;
    const maxAttempts = 3;

    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      const effectivePricings = await fetchPricingForEditing(company, totalSheetId, itemId, apiBase);
      row = findPricingRowForPrototype(effectivePricings, customerPrototypeId);
      if (row) break;
      if (attempt < maxAttempts - 1) {
        await utils.wait(400);
      }
    }

    if (!row && basePrototypeId != null) {
      const effectivePricings = await fetchPricingForEditing(company, totalSheetId, itemId, apiBase);
      const baseRow = findPricingRowForPrototype(effectivePricings, basePrototypeId);
      if (baseRow) {
        console.warn(
          LOG_PREFIX,
          "Using base prototype pricing row as template for prototype",
          customerPrototypeId
        );
        row = baseRow;
      }
    }

    if (!row) {
      return { ok: false, error: `No pricing row found for customer prototype ${customerPrototypeId}` };
    }

    const payload = buildPricingPayloadFromEffectivePricing(row, dividedPriceDisplay);

    const result = await putCustomerPrototypePricingPayload(
      company,
      totalSheetId,
      customerPrototypeId,
      payload,
      apiBase
    );

    if (result.ok) {
      return {
        ok: true,
        offsetMinor: payload.offset,
        rate: payload.rate
      };
    }

    console.error(
      LOG_PREFIX,
      "Pricing PUT failed:",
      formatPricingPayloadSummary(payload),
      result.error
    );
    if (result.apiBody) {
      console.error(LOG_PREFIX, "Pricing PUT response body:", JSON.stringify(result.apiBody, null, 2));
    }
    return { ok: false, error: result.error };
  }

  function logPriceFailuresSummary(priceFailures) {
    if (!priceFailures.length) return;
    const lines = priceFailures.map(
      (f) =>
        `  - "${f.duplicateName}" (prototype ${f.prototypeId}): intended ${formatPrice(f.intendedPrice)} — ${f.error}`
    );
    console.warn(
      `${LOG_PREFIX} Price update failures (${priceFailures.length}):\n${lines.join("\n")}`
    );
  }

  function getDomCustomerTypesList() {
    const list = [];
    getCustomerTypeBlocks().forEach((block, i) => {
      const nameSpan = block.querySelector('[data-test-id="customer-type-name"] span');
      if (!nameSpan) return;
      const name = nameSpan.textContent.trim();
      if (name) list.push({ domIndex: i, name });
    });
    return list;
  }

  async function buildCustomerTypesList() {
    const domList = getDomCustomerTypesList();

    if (domList.length === 0) {
      const ctx = getCurrentCompanyAndItemFromUrl();
      if (!ctx) return domList;
      try {
        const prototypes = await fetchCustomerPrototypes(ctx.company, ctx.itemId, ctx.apiBase);
        return prototypes.map((p, index) => ({
          domIndex: index,
          name: p.name || p.display_name || "Untitled",
          prototypeId: p.pk,
          customerTypeId: p.customer_type?.pk
        }));
      } catch (err) {
        console.warn(LOG_PREFIX, "API customer types fallback failed:", err.message);
        return domList;
      }
    }

    const ctx = getCurrentCompanyAndItemFromUrl();
    if (!ctx) return domList;

    try {
      const prototypes = await fetchCustomerPrototypes(ctx.company, ctx.itemId, ctx.apiBase);
      return domList.map((entry) => {
        const matched = findPrototypeByName(prototypes, entry.name);
        if (!matched) {
          console.warn(LOG_PREFIX, "No API prototype match for DOM name:", entry.name);
          return entry;
        }
        return {
          domIndex: entry.domIndex,
          name: entry.name,
          prototypeId: matched.pk,
          customerTypeId: matched.customer_type?.pk
        };
      });
    } catch (err) {
      console.warn(LOG_PREFIX, "API enrich failed, returning DOM-only list:", err.message);
      return domList;
    }
  }

  async function resolveBasenameForRunDuplicate() {
    const ctx = getCurrentCompanyAndItemFromUrl();
    if (ctx) {
      try {
        const prototypes = await fetchCustomerPrototypes(ctx.company, ctx.itemId, ctx.apiBase);
        const prototype = findPrototypeByBaseIndex(prototypes, 0);
        if (prototype) {
          return prototype.name || prototype.display_name || "Untitled";
        }
      } catch (err) {
        console.warn(LOG_PREFIX, "resolveBasenameForRunDuplicate API failed:", err.message);
      }
    }
    const domNames = getDomCustomerTypeNames();
    if (domNames[0]) return domNames[0];
    return "Untitled";
  }

  // Find customer type block by name with flexible matching
  async function findCustomerTypeByName(targetName) {
    return utils.createPollingPromise(() => {
      const blocks = getCustomerTypeBlocks();
      
      for (const block of blocks) {
        const nameSpan = utils.$(utils.SELECTORS.CUSTOMER_TYPE_NAME, block);
        if (nameSpan) {
          const blockName = nameSpan.textContent.trim();
          
          // Flexible matching - handle names with extra content
          // Extract just the main name part before any parentheses or extra content
          const cleanBlockName = blockName.split('\n')[0].trim();
          const cleanTargetName = targetName.trim();
          
          // Try exact match first
          if (cleanBlockName === cleanTargetName) {
            console.log(`Found customer type block: "${targetName}"`);
            return block;
          }
          
          // Try startsWith match (in case of formatting differences)
          if (cleanBlockName.startsWith(cleanTargetName)) {
            return block;
          }
          
          // Try contains match as fallback
          if (blockName.includes(cleanTargetName)) {
            return block;
          }
        }
      }
      return null;
    }, utils.TIMEOUTS.EDIT_FORM, 200);
  }

  // Check if we need to navigate to a different area for pricing
  // NOTE: Be very careful not to click on customer type price cells - only navigation tabs!
  async function checkForPricingArea() {
    // Only look for actual navigation tabs/links - NOT price cells in customer type blocks
    const pricingTabs = utils.$$('a[href*="pricing"], ul.tabs a, .nav-tabs a');
    
    // Filter to only actual tab navigation elements (not price cells)
    const actualTabs = pricingTabs.filter(tab => {
      if (tab.tagName !== 'A') return false;
      if (!tab.href && !tab.closest('ul.tabs, .nav-tabs')) return false;
      if (tab.closest('[ng-controller*="CustomerPrototype"]')) return false;
      return true;
    });
    
    // Try clicking a pricing tab if found
    for (const tab of actualTabs) {
      const text = tab.textContent.toLowerCase();
      if (text.includes('pricing') || text.includes('prices')) {
        console.log("Clicking pricing navigation tab...");
        tab.click();
        await utils.wait(500);
        return true;
      }
    }
    
    return false;
  }

  // Set price for customer type within a specific block context
  async function setPriceForCustomerTypeInBlock(block, basePrice, divisionIndex) {
    const dividedPrice = calculateDividedPrice(basePrice, divisionIndex);
    console.log(`Setting price: $${formatPrice(dividedPrice)} (base: $${basePrice}, division: ${divisionIndex})`);
    
    try {
      // Wait for and get the price element - this polls until found or times out
      const priceElement = await waitForPriceElementsInBlock(block);
      
      if (!priceElement) {
        throw new Error("No price element found in customer type block");
      }
      
      // Click the price element
      priceElement.click();
      
      // Wait for dropdown to appear and continue with normal pricing workflow
      await waitForPriceDropdown();
      
      if (!selectChangeFromDropdown()) {
        throw new Error("Failed to select 'Change' from dropdown");
      }
      
      await waitForPriceInput();
      
      if (!setPriceInput(dividedPrice)) {
        throw new Error("Failed to set price input");
      }
      
      await waitForPriceSaveButton();
      
      if (!clickPriceSaveButton()) {
        throw new Error("Failed to click price save button");
      }
      
      // Brief wait for save to process
      await utils.wait(300);
      
      return true;
      
    } catch (error) {
      console.error("Error setting price:", error.message);
      // Only show debug info on error
      debugPriceElementsInBlock(block);
      throw error;
    }
  }

  // Debug function for price elements within a specific block
  function debugPriceElementsInBlock(block) {
    console.log("=== DEBUGGING PRICE ELEMENTS IN BLOCK ===");
    
    if (!block) {
      console.log("No block provided for debugging");
      return;
    }
    
    // Log block structure
    console.log(`Block classes: "${block.className}"`);
    console.log(`Block inner HTML length: ${block.innerHTML.length}`);
    
    // Look for price areas within the block
    const priceAreas = utils.$$(utils.SELECTORS.PRICE_AREAS, block);
    console.log(`Price areas in block: ${priceAreas.length}`);
    priceAreas.forEach((area, i) => {
      console.log(`  Price Area ${i}: classes="${area.className}", visible=${area.offsetParent !== null}`);
    });
    
    // Log all potentially relevant elements in the block
    const priceSpans = utils.$$(utils.SELECTORS.PRICE_SPAN, block);
    console.log(`Price spans in block: ${priceSpans.length}`);
    priceSpans.forEach((span, i) => {
      console.log(`  Block Span ${i}: classes="${span.className}", text="${span.textContent.trim()}", visible=${span.offsetParent !== null}`);
    });
    
    // Look for any clickable elements that might be price-related
    const clickableElements = utils.$$('[ng-click], [data-test-id*="edit"], .td.price, .price-cell', block);
    console.log(`Clickable price-related elements in block: ${clickableElements.length}`);
    clickableElements.forEach((elem, i) => {
      console.log(`  Clickable ${i}: tag="${elem.tagName}", classes="${elem.className}", text="${elem.textContent.trim().substring(0, 50)}", title="${elem.title || ''}", testId="${elem.getAttribute('data-test-id') || ''}"`);
    });
    
    // Look for dropdown/select elements
    const selectElements = utils.$$('select, .price-col-inner', block);
    console.log(`Select/dropdown elements in block: ${selectElements.length}`);
    selectElements.forEach((elem, i) => {
      console.log(`  Select ${i}: tag="${elem.tagName}", classes="${elem.className}", visible=${elem.offsetParent !== null}`);
      if (elem.tagName === 'SELECT') {
        const options = elem.querySelectorAll('option');
        console.log(`    Options: ${options.length}`);
        options.forEach((option, j) => {
          console.log(`      Option ${j}: value="${option.value}", text="${option.textContent.trim()}", selected=${option.selected}`);
        });
      }
    });
    
    const priceInputs = utils.$$(utils.SELECTORS.PRICE_OFFSET_INPUT, block);
    console.log(`Price inputs in block: ${priceInputs.length}`);
    priceInputs.forEach((input, i) => {
      console.log(`  Block Input ${i}: name="${input.name}", id="${input.id}", visible=${input.offsetParent !== null}`);
    });
    
    const saveButtons = utils.$$(utils.SELECTORS.PRICE_SAVE_BTN, block);
    console.log(`Save buttons in block: ${saveButtons.length}`);
    saveButtons.forEach((btn, i) => {
      console.log(`  Block Button ${i}: classes="${btn.className}", text="${btn.textContent.trim()}", disabled=${btn.disabled}`);
    });
    
    console.log("=== END BLOCK DEBUGGING ===");
  }

  // Debug function to log available elements
  function debugPriceElements() {
    console.log("=== DEBUGGING PRICE ELEMENTS ===");
    
    // Check if we're in an edit form
    const nameInput = utils.$(utils.SELECTORS.NAME_INPUT);
    console.log("Name input found:", !!nameInput);
    
    if (nameInput) {
      const form = nameInput.closest('form, .modal, .edit-form, [ng-controller]');
      console.log("Edit form container found:", !!form);
      
      if (form) {
        // Log all potentially relevant elements in the form
        const priceSpans = utils.$$(utils.SELECTORS.PRICE_SPAN, form);
        console.log(`Price spans in form: ${priceSpans.length}`);
        priceSpans.forEach((span, i) => {
          console.log(`  Span ${i}: classes="${span.className}", text="${span.textContent.trim()}", visible=${span.offsetParent !== null}`);
        });
        
        const priceInputs = utils.$$(utils.SELECTORS.PRICE_OFFSET_INPUT, form);
        console.log(`Price inputs in form: ${priceInputs.length}`);
        priceInputs.forEach((input, i) => {
          console.log(`  Input ${i}: name="${input.name}", id="${input.id}", visible=${input.offsetParent !== null}`);
        });
        
        const saveButtons = utils.$$(utils.SELECTORS.PRICE_SAVE_BTN, form);
        console.log(`Save buttons in form: ${saveButtons.length}`);
        saveButtons.forEach((btn, i) => {
          console.log(`  Button ${i}: classes="${btn.className}", text="${btn.textContent.trim()}", disabled=${btn.disabled}`);
        });
      }
    }
    
    // Also check globally
    const globalPriceSpans = utils.$$(utils.SELECTORS.PRICE_SPAN);
    console.log(`Global price spans: ${globalPriceSpans.length}`);
    
    const globalPriceInputs = utils.$$(utils.SELECTORS.PRICE_OFFSET_INPUT);
    console.log(`Global price inputs: ${globalPriceInputs.length}`);
    
    // Check for global dropdown/select elements
    const globalSelects = utils.$$(utils.SELECTORS.PRICE_DROPDOWN_SELECT);
    console.log(`Global price dropdown selects: ${globalSelects.length}`);
    globalSelects.forEach((select, i) => {
      console.log(`  Global Select ${i}: classes="${select.className}", ng-model="${select.getAttribute('ng-model') || ''}", visible=${select.offsetParent !== null}`);
      const options = select.querySelectorAll('option');
      console.log(`    Options: ${options.length}`);
      options.forEach((option, j) => {
        console.log(`      Option ${j}: value="${option.value}", text="${option.textContent.trim()}", selected=${option.selected}`);
      });
    });
    
    const globalChangeOptions = utils.$$(utils.SELECTORS.PRICE_CHANGE_OPTION);
    console.log(`Global "Change" options: ${globalChangeOptions.length}`);
    globalChangeOptions.forEach((option, i) => {
      console.log(`  Change Option ${i}: value="${option.value}", text="${option.textContent.trim()}", visible=${option.offsetParent !== null}`);
    });
    
    console.log("=== END DEBUGGING ===");
  }

  // Main pricing workflow function
  async function setPriceForCustomerType(basePrice, divisionIndex) {
    console.log(`Starting price setting workflow - base price: ${basePrice}, division: ${divisionIndex}`);
    
    try {
      // Calculate the divided price
      const dividedPrice = calculateDividedPrice(basePrice, divisionIndex);
      console.log(`Calculated divided price: ${dividedPrice}`);
      
      // Debug available elements first
      debugPriceElements();
      
      // Give some time for the edit form to fully load
      await utils.wait(500);
      
      // Step 1: Click on the price span
      console.log("Attempting to click price span...");
      if (!clickPriceSpan()) {
        console.log("Failed to click price span, debugging again...");
        debugPriceElements();
        throw new Error("Failed to click price span");
      }
      console.log("Clicked price span, waiting for dropdown...");
      
      // Step 2: Wait for dropdown and select "Change"
      await waitForPriceDropdown();
      console.log("Dropdown appeared, selecting 'Change'...");
      
      if (!selectChangeFromDropdown()) {
        throw new Error("Failed to select 'Change' from dropdown");
      }
      console.log("Selected 'Change', waiting for input field...");
      
      // Step 3: Wait for input field and enter price
      await waitForPriceInput();
      console.log("Input field appeared, setting price...");
      
      if (!setPriceInput(dividedPrice)) {
        throw new Error("Failed to set price input");
      }
      console.log(`Price input set to: ${formatPrice(dividedPrice)}`);
      
      // Step 4: Wait for save button and click it
      await waitForPriceSaveButton();
      console.log("Save button available, clicking...");
      
      if (!clickPriceSaveButton()) {
        throw new Error("Failed to click price save button");
      }
      console.log("Price save button clicked");
      
      // Give a moment for the save to process
      await utils.wait(1000);
      
      console.log("Price setting workflow completed successfully");
      return true;
      
    } catch (error) {
      console.error("Error in price setting workflow:", error);
      console.log("Final debug of elements after error:");
      debugPriceElements();
      throw error;
    }
  }

  // Renaming logic
  function renameEditInput(newName) {
    const input = utils.$(utils.SELECTORS.NAME_INPUT);
    if (!input) {
      console.warn("Rename input not found.");
      return false;
    }
    
    const result = utils.setInputValue(input, newName);
    
    // Check if the value was truncated
    if (input.value !== newName) {
      console.warn(`Value truncated! Expected: "${newName}", Got: "${input.value}"`);
    }
    
    return result;
  }

  // Waiting functions specific to duplication
  function waitForConfirmButton(timeout = utils.TIMEOUTS.CONFIRM_BUTTON) {
    return utils.createPollingPromise(() => utils.$(utils.SELECTORS.CONFIRM_DUPLICATE_BTN), timeout);
  }

  function waitForEditForm(timeout = utils.TIMEOUTS.EDIT_FORM) {
    return utils.createPollingPromise(() => utils.$(utils.SELECTORS.NAME_INPUT), timeout);
  }

  function waitForDuplicateButton(timeout = utils.TIMEOUTS.CONFIRM_BUTTON) {
    return utils.createPollingPromise(() => utils.$(utils.SELECTORS.DUPLICATE_CUSTOMER_TYPE_BTN), timeout);
  }

  function waitForEditButtonInteractive(block, timeout = utils.TIMEOUTS.BUTTON_INTERACTIVE) {
    return utils.createPollingPromise(() => {
      const btn = utils.$(utils.SELECTORS.EDIT_CUSTOMER_TYPE_BTN, block);
      return btn && !btn.disabled && !btn.classList.contains('disabled');
    }, timeout);
  }

  function waitForFormClosure(timeout = utils.TIMEOUTS.CLEAN_STATE) {
    return utils.createPollingPromise(() => {
      return !utils.$(utils.SELECTORS.NAME_INPUT);
    }, timeout);
  }

  function waitForDuplicateCompletion(previousBlockCount, timeout = utils.TIMEOUTS.RENAMED_CUSTOMER_TYPE) {
    return utils.createPollingPromise(() => {
      const currentBlocks = getCustomerTypeBlocks();
      // Duplicate is complete when we have more blocks than before
      return currentBlocks.length > previousBlockCount ? currentBlocks : null;
    }, timeout, 200);
  }

  function waitForSaveCompletion(expectedName, timeout = utils.TIMEOUTS.SAVE_COMPLETION) {
    let formWasOpen = true; // Track if form was initially open
    
    return utils.createPollingPromise(() => {
      // Primary method: Look for a block with the expected name
      const blocks = getCustomerTypeBlocks();
      
      const foundBlock = blocks.find(block => {
        const nameSpan = utils.$(utils.SELECTORS.CUSTOMER_TYPE_NAME, block);
        if (nameSpan) {
          const currentName = nameSpan.textContent.trim();
          return currentName === expectedName;
        }
        return false;
      });
      
      if (foundBlock) {
        return foundBlock;
      }
      
      // Fallback method: If form was open and now closed, consider save complete
      const formStillOpen = utils.$(utils.SELECTORS.NAME_INPUT);
      if (formWasOpen && !formStillOpen) {
        return true; // Consider this a successful save
      }
      
      // Update our tracking of form state
      if (formStillOpen) {
        formWasOpen = true;
      }
      
      return null;
    }, timeout, utils.TIMEOUTS.POLLING_INTERVAL);
  }

  // Alternative save completion method with more generous timeout
  // Returns true only if form is confirmed closed
  async function waitForSaveCompletionRobust(expectedName) {
    try {
      await waitForSaveCompletion(expectedName, utils.TIMEOUTS.SAVE_COMPLETION);
      return true;
    } catch (error) {
      // Fallback: Try to ensure form is actually closed
      console.log("Primary save detection failed, attempting to close form...");
      
      // Check if form is still open
      if (utils.$(utils.SELECTORS.NAME_INPUT)) {
        // Try clicking save button again
        const saveBtn = utils.$(utils.SELECTORS.SAVE_EDIT_BTN);
        if (saveBtn && !saveBtn.disabled) {
          console.log("Retrying save button click...");
          saveBtn.click();
          await utils.wait(300);
        }
        
        // Try clicking cancel if form is still open
        if (utils.$(utils.SELECTORS.NAME_INPUT)) {
          const cancelBtn = utils.$('button[data-test-id="cancel-customer-type-update-button"]');
          if (cancelBtn) {
            console.log("Form still open, clicking cancel...");
            cancelBtn.click();
            await utils.wait(300);
          }
        }
        
        // Final escape key attempt
        if (utils.$(utils.SELECTORS.NAME_INPUT)) {
          document.body.dispatchEvent(new KeyboardEvent('keydown', { 
            key: 'Escape', code: 'Escape', keyCode: 27, which: 27,
            bubbles: true, cancelable: true 
          }));
          await utils.wait(300);
        }
      }
      
      // Wait for form to close
      try {
        await waitForFormClosure(utils.TIMEOUTS.CLEAN_STATE);
        return true;
      } catch (formError) {
        // Form is STILL open - this is a real problem
        console.warn("Could not close form after save");
        throw new Error("Form failed to close after save");
      }
    }
  }

  function waitForCleanState(timeout = utils.TIMEOUTS.CLEAN_STATE) {
    return utils.createPollingPromise(() => {
      // Clean state: no forms open, no duplicate buttons visible, no loading states
      const hasForm = utils.$(utils.SELECTORS.NAME_INPUT);
      const hasDuplicateBtn = utils.$(utils.SELECTORS.DUPLICATE_CUSTOMER_TYPE_BTN);
      const hasConfirmBtn = utils.$(utils.SELECTORS.CONFIRM_DUPLICATE_BTN);
      
      // Clean state is when there's no form, no duplicate button, and no confirm button visible
      return !hasForm && !hasDuplicateBtn && !hasConfirmBtn;
    }, timeout);
  }

  // Price-related waiting functions (scoped to edit form context)
  function waitForPriceDropdown(timeout = utils.TIMEOUTS.EDIT_FORM) {
    return utils.createPollingPromise(() => {
      // Method 1: Look for the specific select element
      const selectElement = utils.$(utils.SELECTORS.PRICE_DROPDOWN_SELECT);
      if (selectElement && selectElement.offsetParent !== null) {
        return true;
      }
      
      // Method 2: Look for the Change option specifically
      const changeOption = utils.$(utils.SELECTORS.PRICE_CHANGE_OPTION);
      if (changeOption && changeOption.offsetParent !== null) {
        return true;
      }
      
      // Method 3: Look for any select with the expected options
      const allSelects = utils.$$('select');
      for (const select of allSelects) {
        if (select.offsetParent !== null) {
          const options = select.querySelectorAll('option');
          const hasExpectedOptions = Array.from(options).some(option => 
            option.textContent.toLowerCase().includes('change') || 
            option.textContent.toLowerCase().includes('inherit') || 
            option.textContent.toLowerCase().includes('components')
          );
          
          if (hasExpectedOptions) {
            return true;
          }
        }
      }
      
      return false;
    }, timeout);
  }

  function waitForPriceInput(timeout = utils.TIMEOUTS.EDIT_FORM) {
    return utils.createPollingPromise(() => {
      // Look in edit form context first
      const nameInput = utils.$(utils.SELECTORS.NAME_INPUT);
      if (nameInput) {
        const form = nameInput.closest('form, .modal, .edit-form, [ng-controller]');
        if (form) {
          const input = utils.$(utils.SELECTORS.PRICE_OFFSET_INPUT, form);
          if (input) return input;
        }
      }
      
      // Fallback to global search
      return utils.$(utils.SELECTORS.PRICE_OFFSET_INPUT) || false;
    }, timeout);
  }

  function waitForPriceSaveButton(timeout = utils.TIMEOUTS.EDIT_FORM) {
    return utils.createPollingPromise(() => {
      // Look in edit form context first
      const nameInput = utils.$(utils.SELECTORS.NAME_INPUT);
      if (nameInput) {
        const form = nameInput.closest('form, .modal, .edit-form, [ng-controller]');
        if (form) {
          const button = utils.$(utils.SELECTORS.PRICE_SAVE_BTN, form);
          if (button && !button.disabled) return button;
        }
      }
      
      // Fallback to global search
      const button = utils.$(utils.SELECTORS.PRICE_SAVE_BTN);
      return (button && !button.disabled) ? button : false;
    }, timeout);
  }

  function clickEditLink(blockElement) {
    return utils.clickButton(utils.SELECTORS.EDIT_CUSTOMER_TYPE_BTN, blockElement);
  }

  function waitForRenamedCustomerType(previousNames, timeout = utils.TIMEOUTS.RENAMED_CUSTOMER_TYPE) {
    return utils.createPollingPromise(() => {
      const blocks = getCustomerTypeBlocks();
      
      for (const block of blocks) {
        const nameSpan = utils.$(utils.SELECTORS.PROTOTYPE_INDICATOR, block);
        if (!nameSpan) continue;

        const name = nameSpan.textContent.trim();
        if (!previousNames.has(name)) {
          return block;
        }
      }
      return null;
    }, timeout, 200);
  }

  function setPartySizeFields(value) {
    const minInput = utils.$(utils.SELECTORS.MIN_PARTY_SIZE_INPUT);
    const maxInput = utils.$(utils.SELECTORS.MAX_PARTY_SIZE_INPUT);

    const minSuccess = utils.setInputValue(minInput, value);
    const maxSuccess = utils.setInputValue(maxInput, value);
    
    return minSuccess && maxSuccess;
  }

  async function runMultipleDuplicatesApi(count, basename, baseIndex = 0, price = null) {
    console.log(LOG_PREFIX, "Using API duplicate workflow");

    const ctx = getCurrentCompanyAndItemFromUrl();
    if (!ctx) {
      throw new DuplicateApiWorkflowError("Could not parse company/item from URL", {
        completedCount: 0,
        totalCount: count,
        isPartialFailure: false
      });
    }

    const { company, itemId, apiBase } = ctx;
    const prototypes = await fetchCustomerPrototypes(company, itemId, apiBase);
    if (!prototypes.length) {
      throw new DuplicateApiWorkflowError("No customer prototypes returned from API", {
        completedCount: 0,
        totalCount: count,
        isPartialFailure: false
      });
    }

    const basePrototype = findPrototypeByBaseIndex(prototypes, baseIndex);
    if (!basePrototype) {
      throw new DuplicateApiWorkflowError(`Base prototype not found at index ${baseIndex}`, {
        completedCount: 0,
        totalCount: count,
        isPartialFailure: false
      });
    }

    const priceEnabled = price !== null && price > 0;
    let totalSheetId = null;
    if (priceEnabled) {
      const sheetResult = getConfidentActiveTotalSheetId(company, itemId);
      if (!sheetResult) {
        throw new DuplicateApiWorkflowError(
          "Active total sheet could not be resolved confidently for API pricing (DOM/URL/performance). Use DOM fallback or select a pricing sheet tab.",
          { completedCount: 0, totalCount: count, isPartialFailure: false }
        );
      }
      totalSheetId = sheetResult.sheetId;
    }

    const pad = (num) => String(num).padStart(2, "0");
    let completedCount = 0;
    const priceFailures = [];

    for (let i = 0; i < count; i++) {
      const divisionIndex = i + 1;
      const newName = `${basename} ${pad(divisionIndex)}-${pad(divisionIndex)}`;

      try {
        const duplicate = await duplicateCustomerPrototype(company, itemId, basePrototype, apiBase);
        if (!duplicate?.pk) {
          throw new Error("Duplicate API response missing customer_prototype.pk");
        }

        const updated = await updateCustomerPrototype(
          company,
          itemId,
          duplicate,
          {
            name: newName,
            display_name: newName,
            minimum_party_size: divisionIndex,
            maximum_party_size: divisionIndex
          },
          apiBase
        );

        console.log(
          LOG_PREFIX,
          `[${i + 1}/${count}] Created pk ${updated.pk}, renamed to "${newName}", min/max party ${divisionIndex}`
        );

        completedCount += 1;

        if (priceEnabled) {
          const dividedPriceDisplay = calculateDividedPriceDisplay(price, divisionIndex);
          const priceResult = await updateCustomerPrototypePrice(
            company,
            totalSheetId,
            itemId,
            updated.pk,
            dividedPriceDisplay,
            basePrototype.pk,
            apiBase
          );
          if (priceResult.ok) {
            console.log(
              LOG_PREFIX,
              `[${i + 1}/${count}] Price set to ${formatPrice(dividedPriceDisplay)} ` +
                `(offset minor units: ${priceResult.offsetMinor})`
            );
          } else {
            console.error(LOG_PREFIX, `[${i + 1}/${count}] Price setting failed:`, priceResult.error);
            priceFailures.push({
              duplicateName: newName,
              prototypeId: updated.pk,
              intendedPrice: dividedPriceDisplay,
              error: priceResult.error
            });
          }
        }
      } catch (err) {
        if (completedCount > 0) {
          throw new DuplicateApiWorkflowError(
            `API duplicate workflow failed after ${completedCount} of ${count} duplicates. Not falling back to DOM to avoid duplicate duplicates. Original: ${err.message}`,
            { completedCount, totalCount: count, isPartialFailure: true }
          );
        }
        throw new DuplicateApiWorkflowError(err.message, {
          completedCount: 0,
          totalCount: count,
          isPartialFailure: false
        });
      }
    }

    logPriceFailuresSummary(priceFailures);
  }

  function refreshAfterApiDuplicateSuccess() {
    try {
      window.dispatchEvent(new CustomEvent("fh-customer-prototypes-updated"));
    } catch (eventErr) {
      console.warn(LOG_PREFIX, "Could not dispatch refresh event:", eventErr.message);
    }
    setTimeout(() => window.location.reload(), 50);
  }

  async function runMultipleDuplicates(count, basename, baseIndex = 0, price = null) {
    try {
      await runMultipleDuplicatesApi(count, basename, baseIndex, price);
      refreshAfterApiDuplicateSuccess();
    } catch (err) {
      const completed =
        err instanceof DuplicateApiWorkflowError ? err.completedCount : 0;
      if (completed > 0) throw err;
      console.warn(LOG_PREFIX, "API setup failed, using DOM fallback:", err.message);
      await runMultipleDuplicatesDomFallback(count, basename, baseIndex, price);
    }
  }

  // DOM fallback duplication workflow
  async function runMultipleDuplicatesDomFallback(count, basename, baseIndex = 0, price = null) {
    console.log(LOG_PREFIX, "Using DOM duplicate fallback workflow");
    const pad = num => String(num).padStart(2, '0');

    const baseBlock = getCustomerTypeBlocks()[baseIndex];
    if (!baseBlock) {
      console.error("Selected base block not found");
      return;
    }

    const baseName = baseBlock.querySelector('[data-test-id="customer-type-name"] span')?.textContent.trim();
    console.log(`Starting ${count} duplicates of: "${baseName}"`);
    
    const editBtn = baseBlock.querySelector('button[data-test-id="edit-customer-type-button"]');
    if (!editBtn) {
      console.error("Edit button not found in selected block");
      return;
    }

    for (let i = 0; i < count; i++) {
      console.log(`[${i + 1}/${count}] Starting...`);
      
      try {
        // Step 0: Ensure clean state
        await waitForCleanState(5000);
        
        // Re-find the base block for each iteration
        const currentBlocks = getCustomerTypeBlocks();
        const currentBaseBlock = currentBlocks[baseIndex];
        
        if (!currentBaseBlock) {
          throw new Error(`Base block not found at index ${baseIndex}`);
        }

        const currentEditBtn = utils.$(utils.SELECTORS.EDIT_CUSTOMER_TYPE_BTN, currentBaseBlock);
        if (!currentEditBtn) {
          throw new Error("Edit button not found in base block");
        }

        // Get current state before starting duplication
        const existingNames = new Set();
        const initialBlockCount = currentBlocks.length;
        currentBlocks.forEach(block => {
          const nameSpan = utils.$(utils.SELECTORS.CUSTOMER_TYPE_NAME, block);
          if (nameSpan) existingNames.add(nameSpan.textContent.trim());
        });

        // Step 1: Open original customer type
        console.log(`  Step 1: Opening original for duplication`);
        currentEditBtn.click();
        await waitForDuplicateButton();

        // Step 2: Duplicate
        console.log(`  Step 2: Duplicating`);
        if (!clickDuplicateCustomerTypeButton()) {
          throw new Error("Failed to click duplicate button");
        }
        await waitForConfirmButton();
        if (!clickConfirmDuplicateButton()) {
          throw new Error("Failed to click confirm button");
        }
        await waitForDuplicateCompletion(initialBlockCount);

        // Step 3: Find and open the duplicate
        console.log(`  Step 3: Opening duplicate for editing`);
        const newBlock = await waitForRenamedCustomerType(existingNames);
        await waitForEditButtonInteractive(newBlock);
        if (!clickEditLink(newBlock)) {
          throw new Error("Failed to click edit link on new block");
        }
        await waitForEditForm();

        // Step 4: Rename
        const newName = `${basename} ${pad(i + 1)}-${pad(i + 1)}`;
        console.log(`  Step 4: Renaming to "${newName}"`);
        if (!renameEditInput(newName)) {
          throw new Error("Failed to rename input");
        }

        // Step 5: Set party size
        console.log(`  Step 5: Setting party size`);
        setPartySizeFields(pad(i + 1));

        // Step 6: Save
        console.log(`  Step 6: Saving`);
        if (!clickSaveEditForm()) {
          throw new Error("Failed to click save button");
        }
        await waitForSaveCompletionRobust(newName);
        
        // Brief settle time after form closure
        await utils.wait(300);

        // Step 7: Set price (if provided)
        if (price !== null && price > 0) {
          console.log(`  Step 7: Setting price`);
          try {
            // Ensure no forms are open before trying to set price
            const formStillOpen = utils.$(utils.SELECTORS.NAME_INPUT);
            if (formStillOpen) {
              console.warn("  Form still open, skipping price setting");
            } else {
              // findCustomerTypeByName already verifies the block name matches
              const savedBlock = await findCustomerTypeByName(newName);
              if (savedBlock) {
                await setPriceForCustomerTypeInBlock(savedBlock, price, i + 1);
              } else {
                console.warn("  Could not find saved block for pricing");
              }
            }
          } catch (priceError) {
            console.error(`  Price setting failed:`, priceError.message);
          }
        }
        
        console.log(`  ✓ Completed duplicate ${i + 1}`);
        
      } catch (error) {
        console.error(`Error in duplicate ${i + 1}:`, error.message);
        
        // Aggressive recovery to ensure clean state for next iteration
        console.log("Attempting recovery...");
        
        // Keep trying to close forms until we succeed or give up
        for (let attempt = 0; attempt < 3; attempt++) {
          // Check if there's any form/dialog open
          const hasForm = utils.$(utils.SELECTORS.NAME_INPUT);
          const hasDuplicateBtn = utils.$(utils.SELECTORS.DUPLICATE_CUSTOMER_TYPE_BTN);
          const hasConfirmBtn = utils.$(utils.SELECTORS.CONFIRM_DUPLICATE_BTN);
          
          if (!hasForm && !hasDuplicateBtn && !hasConfirmBtn) {
            console.log("Clean state achieved");
            break;
          }
          
          console.log(`Recovery attempt ${attempt + 1}/3`);
          
          // Try cancel button first (most reliable)
          const cancelButton = utils.$('button[data-test-id="cancel-customer-type-update-button"], button.btn-secondary--light, button[title*="cancel" i]');
          if (cancelButton && cancelButton.offsetParent !== null) {
            cancelButton.click();
            await utils.wait(400);
            continue;
          }
          
          // Try escape key
          document.body.dispatchEvent(new KeyboardEvent('keydown', { 
            key: 'Escape', code: 'Escape', keyCode: 27, which: 27,
            bubbles: true, cancelable: true 
          }));
          await utils.wait(300);
          
          // Try clicking outside/backdrop
          const backdrop = utils.$('.modal-backdrop, .overlay, .dialog-backdrop, .modal-overlay');
          if (backdrop && backdrop.offsetParent !== null) {
            backdrop.click();
            await utils.wait(300);
          }
          
          // If confirm button is visible, we might be in duplicate confirm state - click cancel there
          if (hasConfirmBtn) {
            const cancelDuplicateBtn = utils.$('button[data-test-id="cancel-duplicate-customer-type-button"]');
            if (cancelDuplicateBtn) {
              cancelDuplicateBtn.click();
              await utils.wait(300);
            }
          }
        }
        
        // Brief wait to let UI settle
        await utils.wait(500);
      }
    }
    
    console.log(`Completed ${count} duplicates`);
  }

  // Message handling for duplicate-related actions
  function handleMessage(req, sender, sendResponse) {
    console.log("[duplicate-customer-types] Message received:", req);

    if (req.action === "getCustomerTypes") {
      (async () => {
        try {
          const list = await buildCustomerTypesList();
          console.log(LOG_PREFIX, `Found ${list.length} customer types`);
          sendResponse({ customerTypes: list });
        } catch (err) {
          console.warn(LOG_PREFIX, "getCustomerTypes failed:", err.message);
          sendResponse({ customerTypes: getDomCustomerTypesList() });
        }
      })();
      return true;
    }

    if (req.action === "runDuplicate") {
      (async () => {
        try {
          const basename = await resolveBasenameForRunDuplicate();
          await runMultipleDuplicates(1, basename, 0, null);
          sendResponse({ status: "done" });
        } catch (err) {
          console.error(LOG_PREFIX, "runDuplicate error:", err.message);
          sendResponse({ status: "error", error: err.message });
        }
      })();

      return true;
    }

    if (req.action === "runMultipleDuplicates") {
      (async () => {
        try {
          await runMultipleDuplicates(req.count, req.basename, req.baseIndex, req.price);
          sendResponse({ status: "done" });
        } catch (err) {
          console.error("runMultipleDuplicates error:", err.message);
          sendResponse({ status: "error", error: err.message });
        }
      })();

      return true;
    }

    return false; // Not handled by this module
  }

  // Export the module
  window.DuplicateCustomerTypes = {
    handleMessage,
    runMultipleDuplicates,
    getCustomerTypeBlocks
  };

  console.log("[duplicate-customer-types] Module initialized successfully");

})(); // End of initialization function