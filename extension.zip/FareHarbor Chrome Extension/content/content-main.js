console.log("[content-main] content-main.js loaded");

// Constants
const SELECTORS = {
  EDIT_CUSTOMER_TYPE_BTN: 'button[data-test-id="edit-customer-type-button"]',
  DUPLICATE_CUSTOMER_TYPE_BTN: 'button[data-test-id="duplicate-customer-type-button"]',
  CONFIRM_DUPLICATE_BTN: 'button[data-test-id="submit-duplicate-customer-type-button"]',
  SAVE_EDIT_BTN: 'button[data-test-id="save-customer-type-update-button"]',
  NAME_INPUT: 'input[name="name"]',
  MIN_PARTY_SIZE_INPUT: 'input[name="minimumPartySize"]',
  MAX_PARTY_SIZE_INPUT: 'input[name="maximumPartySize"]',
  CUSTOMER_TYPE_BLOCKS: 'div[ng-controller="dashboard.items.item.CustomerPrototypeEditableCtrl"]',
  CUSTOMER_TYPE_NAME: '[data-test-id="customer-type-name"] span',
  PROTOTYPE_INDICATOR: '[data-test-id$="-prototype-indicator"]',
  SPREADSHEET_TABLE: 'table.spreadsheet',
  TABS_LINK: 'ul.tabs a[href*="/items/"]',
  // Price-related selectors
  PRICE_SPAN: 'span.the-price.closed.ng-scope, span[ng-effective-price], .price-cell .the-price, [data-test-id*="price"], [title*="Price"]',
  PRICE_DROPDOWN_SELECT: 'select[ng-model*="priceType"], select[ng-model*="editableLine.priceType"]',
  PRICE_CHANGE_OPTION: 'option[value="string:change"], option[label="Change"]',
  PRICE_OFFSET_INPUT: 'input[name="offset"], input[id="id_offset"], input[ng-model*="offset"]',
  PRICE_SAVE_BTN: 'button.btn-tiny.btn-green[data-test-id="save-visibility-option-button"], button[type="submit"].btn-tiny.btn-green',
  // Additional price-related selectors for discovery
  PRICE_AREAS: '.price-form, .pricing-editor, [ng-pricing-editor], .option-sheet, .td.price, .price-col-inner',
  CUSTOMER_TYPE_PRICE_AREA: '[data-test-id*="pricing"], [data-test-id*="price"]'
};

const TIMEOUTS = {
  DEFAULT_WAIT: 500,
  CONFIRM_BUTTON: 5000,
  EDIT_FORM: 5000,
  RENAMED_CUSTOMER_TYPE: 10000,
  SAVE_COMPLETION: 8000,
  CLEAN_STATE: 3000,
  BUTTON_INTERACTIVE: 4000,
  POLLING_INTERVAL: 150
};

// Inject confirm override script into page context
(function injectScriptFile() {
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('inject.js');
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);
})();

// Utility functions
function $(selector, context = document) {
  return context.querySelector(selector);
}

function $$(selector, context = document) {
  return Array.from(context.querySelectorAll(selector));
}

function setInputValue(input, value) {
  if (!input) return false;
  
  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  nativeSetter.call(input, value);
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  return true;
}

function createPollingPromise(checkFn, timeout, interval = TIMEOUTS.POLLING_INTERVAL) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    let intervalId;
    
    const check = () => {
      const result = checkFn();
      if (result) {
        clearInterval(intervalId);
        resolve(result);
        return;
      }
      
      if (Date.now() - start > timeout) {
        clearInterval(intervalId);
        reject(new Error(`Polling timed out after ${timeout}ms`));
      }
    };
    
    intervalId = setInterval(check, interval);
    check(); // Check immediately
  });
}

// Timing helpers
function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Optimized click helpers
function clickButton(selector, context = document) {
  const btn = $(selector, context);
  if (btn) {
    btn.click();
    return true;
  }
  return false;
}

/** Strip client shortname suffix after FareHarbor item ID, e.g. "Tour (ID: 1) - client" -> "Tour (ID: 1)". */
function trimFareHarborItemDisplayText(itemText) {
  if (!itemText) return '';
  const str = String(itemText).trim();
  const withIdLabel = str.match(/^(.+?\(ID:\s*\d+\))/);
  if (withIdLabel) return withIdLabel[1].trim();
  const withNumericId = str.match(/^(.+?\(\d+\))/);
  if (withNumericId) return withNumericId[1].trim();
  return str;
}

// Make utilities globally available for other modules
window.FareHarborUtils = {
  SELECTORS,
  TIMEOUTS,
  $,
  $$,
  setInputValue,
  createPollingPromise,
  wait,
  clickButton,
  trimFareHarborItemDisplayText
};

// Handle extension messages and route to appropriate modules
function requireActiveDevMode(actionLabel, sendResponse, run) {
  const auth = window.FareHarborDeveloperAuth;
  if (!auth) {
    console.log("[dev-mode] DEV mode unavailable: dev-mode module not loaded");
    sendResponse({
      ok: false,
      status: "error",
      error: "DEV mode authorization unavailable"
    });
    return true;
  }

  auth.requireActiveDevModeAsync(actionLabel).then((allowed) => {
    if (!allowed) {
      sendResponse({
        ok: false,
        status: "error",
        error: "This action requires DEV mode"
      });
      return;
    }
    run();
  });

  return true;
}

// Message listener
chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  console.log("[content-main] Message received, action:", req.action);
  
  // Route duplicate-related messages to the duplicate module
  if (req.action === "getCustomerTypes" || 
      req.action === "runDuplicate" || 
      req.action === "runMultipleDuplicates") {
    
    if (window.DuplicateCustomerTypes) {
      return window.DuplicateCustomerTypes.handleMessage(req, sender, sendResponse);
    } else {
      console.error("DuplicateCustomerTypes module not loaded");
      sendResponse({ status: "error", error: "DuplicateCustomerTypes module not loaded" });
      return true;
    }
  }

  // Route Expedia-related messages to the Expedia module
  if (req.action === "runExtract" || req.action === "runCompleteExtract" || req.action === "runExtractAllRoCodes") {
    if (window.ExpediaMapping) {
      return window.ExpediaMapping.handleMessage(req, sender, sendResponse);
    } else {
      console.error("ExpediaMapping module not loaded");
      sendResponse({ status: "error", error: "ExpediaMapping module not loaded" });
      return true;
    }
  }

  // Route availability audit messages to the AvailabilityAudit module
  if (req.action === "getAvailabilityPageInfo") {
    if (window.AvailabilityAudit) {
      return window.AvailabilityAudit.handleMessage(req, sender, sendResponse);
    }
    console.error("AvailabilityAudit module not loaded");
    sendResponse({ status: "error", error: "AvailabilityAudit module not loaded" });
    return true;
  }

  if (req.action === "runAvailabilityAudit") {
    if (window.AvailabilityAudit?.runAvailabilityAuditApiFirst) {
      window.AvailabilityAudit.runAvailabilityAuditApiFirst(
        req.targetDate,
        req.targetTime,
        req.fetchDetailedInfo || false
      )
        .then((result) => {
          sendResponse(result);
        })
        .catch((err) => {
          console.error("[content-main] API-first capacity check failed:", err);
          sendResponse({
            success: false,
            error: err?.message || String(err)
          });
        });
      return true;
    }
    if (window.AvailabilityAudit) {
      return window.AvailabilityAudit.handleMessage(req, sender, sendResponse);
    }
    console.error("AvailabilityAudit module not loaded");
    sendResponse({ status: "error", error: "AvailabilityAudit module not loaded" });
    return true;
  }

  if (req.action === "runDevCapacityCheckEngine") {
    return requireActiveDevMode("runDevCapacityCheckEngine", sendResponse, () => {
      if (window.AvailabilityAudit?.runDevCapacityCheckEngine) {
        window.AvailabilityAudit.runDevCapacityCheckEngine(req)
          .then((result) => {
            sendResponse({
              status: result?.ok !== false ? "ok" : "error",
              result,
              error: result?.ok !== false ? null : result?.error || "Dev capacity check failed"
            });
          })
          .catch((err) => {
            sendResponse({ status: "error", error: err?.message || String(err) });
          });
        return;
      }
      console.error("AvailabilityAudit dev engine module not loaded");
      sendResponse({ status: "error", error: "AvailabilityAudit dev engine module not loaded" });
    });
  }

  if (req.action === "inspectApiResourceSources") {
    return requireActiveDevMode("inspectApiResourceSources", sendResponse, () => {
      if (window.AvailabilityAudit?.inspectApiResourceSources) {
        window.AvailabilityAudit.inspectApiResourceSources({
          targetTimestamp: req.targetTimestamp ?? null
        })
          .then((result) => {
            sendResponse({
              status: result?.ok ? "ok" : "error",
              result,
              error: result?.ok ? null : result?.error || "API resource source inspection failed"
            });
          })
          .catch((err) => {
            sendResponse({ status: "error", error: err?.message || String(err) });
          });
        return;
      }
      console.error("AvailabilityAudit inspect module not loaded");
      sendResponse({ status: "error", error: "AvailabilityAudit inspect module not loaded" });
    });
  }

  if (req.action === "debugApiCapacityData") {
    return requireActiveDevMode("debugApiCapacityData", sendResponse, () => {
      if (window.AvailabilityAudit?.debugApiCapacityData) {
        window.AvailabilityAudit.debugApiCapacityData({
          targetTimestamp: req.targetTimestamp ?? null
        })
          .then((result) => {
            sendResponse({
              status: result?.ok ? "ok" : "error",
              result,
              error: result?.ok ? null : result?.error || "API capacity fetch failed"
            });
          })
          .catch((err) => {
            sendResponse({ status: "error", error: err?.message || String(err) });
          });
        return;
      }
      console.error("AvailabilityAudit API module not loaded");
      sendResponse({ status: "error", error: "AvailabilityAudit API module not loaded" });
    });
  }

  // Route Activity Listings messages to the ActivityListings module
  if (req.action === "runActivityListingsExtract") {
    if (window.ActivityListings) {
      return window.ActivityListings.handleMessage(req, sender, sendResponse);
    } else {
      console.error("ActivityListings module not loaded");
      sendResponse({ status: "error", error: "ActivityListings module not loaded" });
      return true;
    }
  }

  // Route FareHarbor Reseller Items messages to the FareHarborResellerItems module
  if (
    req.action === "runFareHarborResellerItemsExtract" ||
    req.action === "runFareHarborResellerItemsSingleExtract" ||
    req.action === "runFareHarborResellerItemsExplanationExtract"
  ) {
    if (window.FareHarborResellerItems) {
      return window.FareHarborResellerItems.handleMessage(req, sender, sendResponse);
    } else {
      console.error("FareHarborResellerItems module not loaded");
      sendResponse({ status: "error", error: "FareHarborResellerItems module not loaded" });
      return true;
    }
  }

  // Route Viator Mapping File messages to the ViatorMappingFile module
  if (req.action === "runViatorMappingFileExtract") {
    if (window.ViatorMappingFile) {
      return window.ViatorMappingFile.handleMessage(req, sender, sendResponse);
    } else {
      console.error("ViatorMappingFile module not loaded");
      sendResponse({ status: "error", error: "ViatorMappingFile module not loaded" });
      return true;
    }
  }

  // Route Airbnb Mapping File messages to the AirbnbMappingFile module
  if (req.action === "runAirbnbMappingFileExtract") {
    if (window.AirbnbMappingFile) {
      return window.AirbnbMappingFile.handleMessage(req, sender, sendResponse);
    } else {
      console.error("AirbnbMappingFile module not loaded");
      sendResponse({ status: "error", error: "AirbnbMappingFile module not loaded" });
      return true;
    }
  }

  // Route Google Mapping Data messages to the GoogleMappingData module
  if (req.action === "runGoogleMappingCopy") {
    if (window.GoogleMappingData) {
      return window.GoogleMappingData.handleMessage(req, sender, sendResponse);
    } else {
      console.error("GoogleMappingData module not loaded");
      sendResponse({ success: false, error: "GoogleMappingData module not loaded" });
      return true;
    }
  }

  // Route FareHarbor Jump messages to the FareHarborJump module
  if (req.action === "performFareHarborJump") {
    if (window.FareHarborJump) {
      return window.FareHarborJump.handleMessage(req, sender, sendResponse);
    } else {
      console.error("FareHarborJump module not loaded");
      sendResponse({ status: "error", error: "FareHarborJump module not loaded" });
      return true;
    }
  }

  // Route FareHarbor Items messages to the FareHarborItems module
  if (req.action === "runFareHarborItemsExtract") {
    if (window.FareHarborItems) {
      return window.FareHarborItems.handleMessage(req, sender, sendResponse);
    } else {
      console.error("FareHarborItems module not loaded");
      sendResponse({ status: "error", error: "FareHarborItems module not loaded" });
      return true;
    }
  }

  // Route GetYourGuide Products messages to the GetYourGuideProducts module
  if (req.action === "runGetYourGuideProductsExtract" || req.action === "runGetYourGuideProductsExtractAll" ||
      req.action === "runGetYourGuideProductsExtractV2" || req.action === "runGetYourGuideProductsExtractAllV2") {
    if (window.GetYourGuideProducts) {
      return window.GetYourGuideProducts.handleMessage(req, sender, sendResponse);
    } else {
      console.error("GetYourGuideProducts module not loaded");
      sendResponse({ status: "error", error: "GetYourGuideProducts module not loaded" });
      return true;
    }
  }

  // Route Viator Products messages to the ViatorProducts module
  if (req.action === "runViatorProductsExtract" || req.action === "runViatorProductsExtractAll" || req.action === "getViatorProductCodes") {
    if (window.ViatorProducts) {
      return window.ViatorProducts.handleMessage(req, sender, sendResponse);
    } else {
      console.error("ViatorProducts module not loaded");
      sendResponse({ status: "error", error: "ViatorProducts module not loaded" });
      return true;
    }
  }

  // Route QC Checks messages to the QCChecks module
  if (req.action === "runQCChecks") {
    if (window.QCChecks) {
      return window.QCChecks.handleMessage(req, sender, sendResponse);
    } else {
      console.error("QCChecks module not loaded");
      sendResponse({ status: "error", error: "QCChecks module not loaded" });
      return true;
    }
  }

  // Route Customer Type Pricing Audit messages
  if (req.action === "runCustomerTypePricingAudit") {
    if (window.CustomerTypePricingAudit) {
      return window.CustomerTypePricingAudit.handleMessage(req, sender, sendResponse);
    } else {
      console.error("CustomerTypePricingAudit module not loaded");
      sendResponse({ status: "error", error: "CustomerTypePricingAudit module not loaded" });
      return true;
    }
  }

  // Route Copy Report messages to the CopyReport module
  if (req.action === "runCopyReportExtract") {
    console.log("[content-main] Routing Copy Report message, window.CopyReport:", window.CopyReport);
    if (window.CopyReport && window.CopyReport.handleMessage) {
      const result = window.CopyReport.handleMessage(req, sender, sendResponse);
      console.log("[content-main] CopyReport.handleMessage returned:", result);
      return result;
    } else {
      console.error("[content-main] CopyReport module not loaded or handleMessage missing");
      sendResponse({ status: "error", error: "CopyReport module not loaded" });
      return true;
    }
  }

  if (req.action === "toggleOverlay") {
    if (window.FareHarborOverlay) {
      return window.FareHarborOverlay.handleMessage(req, sender, sendResponse);
    }
    console.error("FareHarborOverlay module not loaded");
    sendResponse({ status: "error", error: "FareHarborOverlay module not loaded" });
    return true;
  }

  if (req.action === "getEndpointScoutReport") {
    return requireActiveDevMode("getEndpointScoutReport", sendResponse, () => {
      if (window.EndpointScout?.handleMessage) {
        window.EndpointScout.handleMessage(req, sender, sendResponse);
        return;
      }
      sendResponse({ status: "error", error: "Endpoint Scout not available" });
    });
  }

  if (req.action === "getEndpointScoutStatus") {
    if (window.EndpointScout?.handleMessage) {
      return window.EndpointScout.handleMessage(req, sender, sendResponse);
    }
    sendResponse({ status: "error", error: "Endpoint Scout not available" });
    return true;
  }

  if (req.action === "loadAffiliateApiCredentialsPopup") {
    return requireActiveDevMode("loadAffiliateApiCredentialsPopup", sendResponse, () => {
      const api = window.FareHarborAffiliateApi;
      if (!api?.lookupAffiliateApiCredentials) {
        sendResponse({
          ok: false,
          error: "Affiliate API module not available"
        });
        return;
      }

      const companyShortname = String(req.companyShortname || "").trim();
      const affiliationPk = String(req.affiliationPk || "").trim();
      if (!companyShortname || !affiliationPk) {
        sendResponse({
          ok: false,
          error: "Missing affiliate page context"
        });
        return;
      }

      api
        .lookupAffiliateApiCredentials(companyShortname, affiliationPk, {
          cachedResellerApps: Array.isArray(req.cachedResellerApps)
            ? req.cachedResellerApps
            : null
        })
        .then((result) => {
          sendResponse(result);
        })
        .catch((err) => {
          sendResponse({
            ok: false,
            error: err?.message || String(err),
            affiliate: { name: null, shortname: null },
            affiliateApiKey: {
              status: "error",
              key: null,
              errorMessage: "Unable to load affiliate API credentials",
              httpStatus: null
            },
            channelApp: {
              status: "error",
              key: null,
              appName: null,
              appPk: null,
              matches: null,
              errorMessage: "Unable to load affiliate API credentials",
              httpStatus: null
            }
          });
        });
    });
  }

  if (req.action === "generateResellerAppCompanyMap") {
    return requireActiveDevMode("generateResellerAppCompanyMap", sendResponse, async () => {
      const generator = window.FareHarborResellerAppMapGenerator;
      const api = window.FareHarborAffiliateApi;
      if (!generator?.generateResellerAppCompanyMap || !api?.apiGetJson) {
        sendResponse({
          ok: false,
          error: "Channel app mapping generator not available"
        });
        return;
      }

      window.__fhResellerAppMapCancelRequested = false;

      try {
        const map = await generator.generateResellerAppCompanyMap({
          apiGetJson: api.apiGetJson.bind(api),
          onProgress(message) {
            try {
              chrome.runtime.sendMessage({
                action: "resellerAppMapGeneratorProgress",
                message
              });
            } catch (err) {
              console.warn(
                "[reseller-app-map-generator]",
                "progress update failed",
                err?.message || String(err)
              );
            }
          },
          isCancelled() {
            return window.__fhResellerAppMapCancelRequested === true;
          }
        });

        sendResponse({ ok: true, map });
      } catch (err) {
        sendResponse({
          ok: false,
          error: err?.message || String(err)
        });
      }
    });
  }

  if (req.action === "cancelResellerAppCompanyMap") {
    return requireActiveDevMode("cancelResellerAppCompanyMap", sendResponse, () => {
      window.__fhResellerAppMapCancelRequested = true;
      sendResponse({ ok: true });
    });
  }

  // Unknown action
  console.warn("Unknown action:", req.action);
  sendResponse({ status: "error", error: `Unknown action: ${req.action}` });
  return true;
});
