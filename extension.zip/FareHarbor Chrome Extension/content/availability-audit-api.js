console.log("[availability-audit-api] availability-audit-api.js loaded");

(function initializeAvailabilityAuditApi() {
  "use strict";

  if (!window.AvailabilityAudit) {
    setTimeout(initializeAvailabilityAuditApi, 10);
    return;
  }

  const LOG_PREFIX = "[availability-audit-api]";
  const CONCURRENCY_LIMIT = 4;
  const BOOKINGS_PAGE_SIZE = 100;

  let loggedBookingKeys = false;
  let loggedResourceUseKeys = false;
  let loggedReapplyTypeHint = false;
  const loggedActivityResponseKeys = new Set();

  function resolveBookingPk(booking) {
    const pk = booking?.pk;
    return pk != null && pk !== "" ? pk : null;
  }

  function getActivityType(activity) {
    if (!activity || typeof activity !== "object") return null;
    if (activity.type != null && activity.type !== "") return String(activity.type);
    if (activity.activity_type != null && activity.activity_type !== "") {
      return String(activity.activity_type);
    }
    return null;
  }

  function getUniqueActivityTypes(activities) {
    if (!Array.isArray(activities)) return [];
    return [...new Set(activities.map(getActivityType).filter(Boolean))];
  }

  function parsePageFromPaginationValue(value) {
    if (value == null || value === "") return null;
    if (typeof value === "number" && Number.isFinite(value)) return value;
    const str = String(value);
    if (/^\d+$/.test(str)) return Number(str);
    try {
      const url = str.startsWith("http") ? new URL(str) : new URL(str, window.location.origin);
      const pageParam = url.searchParams.get("page");
      if (pageParam != null && pageParam !== "") return Number(pageParam);
    } catch (e) {
      return null;
    }
    return null;
  }

  function getNextActivitiesPage(data, currentPage) {
    if (!data || typeof data !== "object") return null;

    const nextPage = parsePageFromPaginationValue(data.next_page);
    if (nextPage != null) return nextPage;

    const nextUrl = data.next;
    if (nextUrl != null && nextUrl !== "") {
      const parsed = parsePageFromPaginationValue(nextUrl);
      if (parsed != null) return parsed;
      return currentPage + 1;
    }

    return null;
  }

  function extractActivitiesFromResponse(data, contextKey, page) {
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.activities)) return data.activities;
    if (Array.isArray(data?.results)) return data.results;

    const logKey = `${contextKey}:${page}`;
    if (!loggedActivityResponseKeys.has(logKey)) {
      loggedActivityResponseKeys.add(logKey);
      warn(
        `Activities response missing array for ${contextKey} page ${page}; keys:`,
        data && typeof data === "object" ? Object.keys(data) : data
      );
    }
    return null;
  }

  function logBookingActivitiesSummary(bookingPk, activities) {
    const uniqueActivityTypes = getUniqueActivityTypes(activities);
    log("Booking activities summary", {
      bookingPk,
      totalActivities: activities.length,
      uniqueActivityTypes
    });

    if (
      !loggedReapplyTypeHint &&
      activities.length > 0 &&
      !uniqueActivityTypes.includes("reapplied-resources")
    ) {
      const similar = uniqueActivityTypes.filter((t) => /reapplied/i.test(t));
      if (similar.length > 0) {
        loggedReapplyTypeHint = true;
        warn(
          "No activity type 'reapplied-resources' found; similar types:",
          similar
        );
      }
    }
  }

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function warn(...args) {
    console.warn(LOG_PREFIX, ...args);
  }

  function error(...args) {
    console.error(LOG_PREFIX, ...args);
  }

  function parseApiDate(isoString) {
    if (!isoString) return null;
    const d = new Date(isoString);
    return Number.isNaN(d.getTime()) ? null : d;
  }

  function parseItemAvailabilityFromOverlay(href) {
    try {
      const u = new URL(href, window.location.origin);
      const overlay = u.searchParams.get("overlay");
      if (!overlay) return null;
      const decoded = decodeURIComponent(overlay);
      const m = decoded.match(/\/items\/(\d+)\/availabilities\/(\d+)/i);
      if (!m) return null;
      return { itemId: m[1], availabilityNumericId: m[2] };
    } catch (e) {
      return null;
    }
  }

  function parseFareHarborApiContextFromPage() {
    const href = window.location.href;
    const pathname = window.location.pathname || "";
    const parts = pathname.split("/").filter(Boolean);
    const company = parts[0] || null;

    const overlayIds = parseItemAvailabilityFromOverlay(href);
    let itemId = overlayIds ? overlayIds.itemId : null;
    let availabilityId = overlayIds ? overlayIds.availabilityNumericId : null;

    if (!itemId) {
      const itemMatch = pathname.match(/\/items\/(\d+)/);
      itemId = itemMatch ? itemMatch[1] : null;
    }

    return {
      company,
      itemId,
      availabilityId,
      pageUrl: href
    };
  }

  async function fhApiFetchJson(path) {
    try {
      const response = await fetch(path, {
        method: "GET",
        credentials: "include",
        headers: { Accept: "application/json" }
      });

      if (!response.ok) {
        warn(`GET ${path} → ${response.status}`);
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `API request failed with status ${response.status}`
        };
      }

      try {
        const data = await response.json();
        log(`GET ${path} → ${response.status}`);
        return { ok: true, status: response.status, data, error: null };
      } catch (err) {
        warn(`GET ${path} → ${response.status} (invalid JSON: ${err.message})`);
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `Response is not valid JSON: ${err.message}`
        };
      }
    } catch (err) {
      warn(`GET ${path} → fetch failed: ${err.message}`);
      return { ok: false, status: null, data: null, error: `Fetch failed: ${err.message}` };
    }
  }

  function buildAvailabilityUrl(company, itemId, availabilityId) {
    return (
      `/api/v1/companies/${encodeURIComponent(company)}/items/${itemId}` +
      `/availabilities/${availabilityId}/?include_custom_field_details=no`
    );
  }

  function buildCustomerPrototypesUrl(company, itemId) {
    return `/api/v1/companies/${encodeURIComponent(company)}/items/${itemId}/customer-prototypes/`;
  }

  async function fetchCustomerPrototypesApi(company, itemId) {
    const url = buildCustomerPrototypesUrl(company, itemId);
    log("Fetching customer prototypes:", url);
    const result = await fhApiFetchJson(url);
    if (!result.ok) {
      return { ok: false, data: null, error: result.error };
    }
    return { ok: true, data: result.data, error: null };
  }

  function buildAvailabilityBookingsUrl(company, itemId, availabilityId, page) {
    const base =
      `/api/v1/companies/${encodeURIComponent(company)}/items/${itemId}` +
      `/availabilities/${availabilityId}/bookings/`;
    if (page == null) return base;
    return `${base}?page=${page}`;
  }

  function buildBookingActivitiesUrl(company, bookingPk, page) {
    return (
      `/api/v1/companies/${encodeURIComponent(company)}/activities/Booking/${bookingPk}/` +
      `?page=${page}`
    );
  }

  function buildAvailabilityActivitiesUrl(company, availabilityId, page) {
    return (
      `/api/v1/companies/${encodeURIComponent(company)}/activities/Availability/${availabilityId}/` +
      `?page=${page}`
    );
  }

  function buildBookingDetailUrl(company, bookingUuid) {
    return `/api/v1/companies/${encodeURIComponent(company)}/bookings/${encodeURIComponent(bookingUuid)}/`;
  }

  async function fetchBookingDetailApi(company, bookingUuid) {
    if (!bookingUuid) {
      return { ok: false, data: null, error: "Booking uuid missing" };
    }
    const url = buildBookingDetailUrl(company, bookingUuid);
    log("Fetching booking detail:", url);
    const result = await fhApiFetchJson(url);
    if (!result.ok) {
      return { ok: false, data: null, error: result.error, status: result.status };
    }
    return { ok: true, data: result.data, error: null, status: result.status };
  }

  function buildBookingResourceUsesUrl(company, bookingUuid) {
    return (
      `/api/v1/companies/${encodeURIComponent(company)}/bookings/${encodeURIComponent(bookingUuid)}/resource-uses/`
    );
  }

  async function fetchBookingResourceUsesApi(company, bookingUuid) {
    if (!bookingUuid) {
      return { ok: false, data: null, error: "Booking uuid missing", status: null };
    }
    const url = buildBookingResourceUsesUrl(company, bookingUuid);
    log("Fetching booking resource uses:", url);
    const result = await fhApiFetchJson(url);
    if (!result.ok) {
      return { ok: false, data: null, error: result.error, status: result.status };
    }
    return { ok: true, data: result.data, error: null, status: result.status };
  }

  function extractBookingsFromResponse(data) {
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.bookings)) return data.bookings;
    if (Array.isArray(data?.results)) return data.results;
    return null;
  }

  async function fetchAvailabilityApi(company, itemId, availabilityId) {
    const url = buildAvailabilityUrl(company, itemId, availabilityId);
    log("Fetching availability:", url);
    const result = await fhApiFetchJson(url);
    if (!result.ok) {
      return { ok: false, data: null, error: result.error };
    }
    return { ok: true, data: result.data, error: null };
  }

  async function fetchAvailabilityBookingsApi(company, itemId, availabilityId) {
    const allBookings = [];
    let page = 1;

    while (true) {
      const url = buildAvailabilityBookingsUrl(company, itemId, availabilityId, page);

      log(`Fetching bookings page ${page}:`, url);
      const result = await fhApiFetchJson(url);
      if (!result.ok) {
        if (page === 1) {
          return { ok: false, bookings: null, error: result.error };
        }
        warn(`Bookings page ${page} failed, returning ${allBookings.length} collected so far`);
        break;
      }

      const bookings = extractBookingsFromResponse(result.data);
      if (!bookings) {
        if (page === 1) {
          return { ok: false, bookings: null, error: "Response missing bookings array" };
        }
        break;
      }

      allBookings.push(...bookings);
      log(`Fetched ${bookings.length} bookings on page ${page} (total: ${allBookings.length})`);

      const nextPage = result.data?.next_page ?? null;
      if (nextPage != null) {
        page = typeof nextPage === "number" ? nextPage : page + 1;
        continue;
      }

      if (page === 1 && bookings.length < BOOKINGS_PAGE_SIZE && !result.data?.next_page) {
        break;
      }

      if (bookings.length < BOOKINGS_PAGE_SIZE) {
        break;
      }

      page += 1;
    }

    return { ok: true, bookings: allBookings, error: null };
  }

  async function fetchBookingActivitiesPage(company, bookingPk, page) {
    const url = buildBookingActivitiesUrl(company, bookingPk, page);
    log(`Fetching activities for booking ${bookingPk}, page ${page}:`, url);
    const result = await fhApiFetchJson(url);
    if (!result.ok) {
      return { ok: false, activities: null, error: result.error, data: null };
    }

    const activities = extractActivitiesFromResponse(result.data, `booking:${bookingPk}`, page);
    if (!activities) {
      return {
        ok: false,
        activities: null,
        error: "Response missing activities array",
        data: result.data
      };
    }

    return { ok: true, activities, error: null, data: result.data };
  }

  async function fetchAvailabilityActivitiesPage(company, availabilityId, page) {
    const url = buildAvailabilityActivitiesUrl(company, availabilityId, page);
    log(`Fetching availability activities for ${availabilityId}, page ${page}:`, url);
    const result = await fhApiFetchJson(url);
    if (!result.ok) {
      return { ok: false, activities: null, error: result.error, data: null };
    }

    const activities = extractActivitiesFromResponse(
      result.data,
      `availability:${availabilityId}`,
      page
    );
    if (!activities) {
      return {
        ok: false,
        activities: null,
        error: "Response missing activities array",
        data: result.data
      };
    }

    return { ok: true, activities, error: null, data: result.data };
  }

  function logAvailabilityActivitiesSummary(company, availabilityId, activities, pagesFetched) {
    const endpointPath =
      `/api/v1/companies/${encodeURIComponent(company)}/activities/Availability/${availabilityId}/`;
    log("Availability activities fetch complete", {
      company,
      availabilityId,
      endpointPath,
      pageCount: pagesFetched,
      totalActivityCount: activities.length
    });
  }

  async function fetchAvailabilityActivitiesApi(company, availabilityId) {
    async function fetchAllPages(startPage) {
      const allActivities = [];
      let page = startPage;
      let pagesFetched = 0;

      while (true) {
        const pageResult = await fetchAvailabilityActivitiesPage(company, availabilityId, page);
        if (!pageResult.ok) {
          if (pagesFetched === 0) {
            return {
              ok: false,
              activities: null,
              error: pageResult.error,
              meta: { pagesFetched: 0, uniqueTypes: [] }
            };
          }
          warn(
            `Availability activities page ${page} for ${availabilityId} failed, returning ${allActivities.length} collected`
          );
          break;
        }

        const activities = pageResult.activities;
        allActivities.push(...activities);
        pagesFetched += 1;
        log(
          `Fetched ${activities.length} availability activities on page ${page} (total: ${allActivities.length})`
        );

        const nextPage = getNextActivitiesPage(pageResult.data, page);
        if (nextPage == null) {
          break;
        }
        page = nextPage;
      }

      const uniqueTypes = getUniqueActivityTypes(allActivities);
      return {
        ok: true,
        activities: allActivities,
        error: null,
        meta: { pagesFetched, uniqueTypes }
      };
    }

    const pageZeroResult = await fetchAllPages(0);
    if (pageZeroResult.ok && pageZeroResult.activities.length > 0) {
      logAvailabilityActivitiesSummary(
        company,
        availabilityId,
        pageZeroResult.activities,
        pageZeroResult.meta.pagesFetched
      );
      return pageZeroResult;
    }

    if (pageZeroResult.ok && pageZeroResult.activities.length === 0) {
      log(`Availability ${availabilityId}: page 0 returned 0 activities, retrying from page 1`);
      const pageOneResult = await fetchAllPages(1);
      if (pageOneResult.ok) {
        logAvailabilityActivitiesSummary(
          company,
          availabilityId,
          pageOneResult.activities,
          pageOneResult.meta.pagesFetched
        );
      }
      return pageOneResult.ok ? pageOneResult : pageZeroResult;
    }

    log(`Availability ${availabilityId}: page 0 failed (${pageZeroResult.error}), retrying from page 1`);
    const pageOneFallback = await fetchAllPages(1);
    if (pageOneFallback.ok) {
      logAvailabilityActivitiesSummary(
        company,
        availabilityId,
        pageOneFallback.activities,
        pageOneFallback.meta.pagesFetched
      );
      return pageOneFallback;
    }

    warn("Availability activities fetch failed", {
      company,
      availabilityId,
      endpointPath: `/api/v1/companies/${encodeURIComponent(company)}/activities/Availability/${availabilityId}/`,
      error: pageZeroResult.error
    });
    return pageZeroResult;
  }

  async function fetchBookingActivitiesApi(company, bookingPk) {
    async function fetchAllPages(startPage) {
      const allActivities = [];
      let page = startPage;
      let pagesFetched = 0;

      while (true) {
        const pageResult = await fetchBookingActivitiesPage(company, bookingPk, page);
        if (!pageResult.ok) {
          if (pagesFetched === 0) {
            return {
              ok: false,
              activities: null,
              error: pageResult.error,
              meta: { pagesFetched: 0, uniqueTypes: [] }
            };
          }
          warn(
            `Activities page ${page} for booking ${bookingPk} failed, returning ${allActivities.length} collected`
          );
          break;
        }

        const activities = pageResult.activities;
        allActivities.push(...activities);
        pagesFetched += 1;
        log(
          `Fetched ${activities.length} activities for booking ${bookingPk} on page ${page} (total: ${allActivities.length})`
        );

        const nextPage = getNextActivitiesPage(pageResult.data, page);
        if (nextPage == null) {
          break;
        }
        page = nextPage;
      }

      const uniqueTypes = getUniqueActivityTypes(allActivities);
      return {
        ok: true,
        activities: allActivities,
        error: null,
        meta: { pagesFetched, uniqueTypes }
      };
    }

    const pageZeroResult = await fetchAllPages(0);
    if (pageZeroResult.ok && pageZeroResult.activities.length > 0) {
      return pageZeroResult;
    }

    if (pageZeroResult.ok && pageZeroResult.activities.length === 0) {
      log(`Booking ${bookingPk}: page 0 returned 0 activities, retrying from page 1`);
      const pageOneResult = await fetchAllPages(1);
      if (pageOneResult.ok && pageOneResult.activities.length > 0) {
        return pageOneResult;
      }
      if (pageOneResult.ok) {
        return pageOneResult;
      }
      return pageZeroResult;
    }

    log(`Booking ${bookingPk}: page 0 failed (${pageZeroResult.error}), retrying from page 1`);
    const pageOneFallback = await fetchAllPages(1);
    if (pageOneFallback.ok) {
      return pageOneFallback;
    }

    return pageZeroResult;
  }

  function findEarliestCancellation(activities) {
    if (!Array.isArray(activities)) return null;

    let earliest = null;
    for (const activity of activities) {
      if (getActivityType(activity) !== "cancelled-booking") continue;
      const createdAt = activity.created_at;
      if (!createdAt) continue;
      if (!earliest || createdAt < earliest) {
        earliest = createdAt;
      }
    }
    return earliest;
  }

  function extractResourceReapplyEvents(activities) {
    if (!Array.isArray(activities)) return [];

    return activities
      .filter((a) => a?.type === "reapplied-resources")
      .map((a) => ({
        createdAt: a.created_at || null,
        originalResourceUses:
          a.context?.original_resource_uses || a.context?.originalResourceUses || [],
        updatedResourceUses:
          a.context?.updated_resource_uses || a.context?.updatedResourceUses || [],
        rawActivity: a
      }));
  }

  /** @deprecated Legacy text pluralization; do not use for capacity checker totals. */
  function normalizeCustomerTypeName(typeName) {
    const name = String(typeName || "").trim();
    if (!name) return "Unknown";
    const lowerName = name.toLowerCase();
    const irregularPlurals = {
      child: "Children",
      children: "Children",
      kid: "Children",
      kids: "Children",
      baby: "Babies",
      babies: "Babies",
      infant: "Infants",
      infants: "Infants",
      youth: "Youth",
      youths: "Youth"
    };
    if (irregularPlurals[lowerName]) return irregularPlurals[lowerName];
    if (lowerName.endsWith("s")) return name.charAt(0).toUpperCase() + name.slice(1);
    return name.charAt(0).toUpperCase() + name.slice(1) + "s";
  }

  function parseCustomerBreakdown(text) {
    if (text == null || text === "") return [];
    if (typeof text !== "string") return [];

    const normalized = text.replace(/\u00a0/g, " ").trim();
    if (!normalized) return [];

    const parts = normalized.split(",").map((part) => part.trim()).filter(Boolean);
    const results = [];
    const quantityPattern = /^(\d+)\s+(.+)$/;

    for (const part of parts) {
      const match = part.match(quantityPattern);
      if (!match) continue;

      const quantity = parseInt(match[1], 10);
      const name = match[2].trim();
      if (!name || !Number.isFinite(quantity) || quantity <= 0) continue;

      results.push({
        name,
        normalizedName: normalizeCustomerTypeName(name),
        quantity
      });
    }

    return results;
  }

  function getCustomerBreakdownText(booking) {
    if (typeof booking?.customer_breakdown === "string" && booking.customer_breakdown.trim()) {
      return booking.customer_breakdown.trim();
    }
    if (
      typeof booking?.customer_breakdown_short === "string" &&
      booking.customer_breakdown_short.trim()
    ) {
      return booking.customer_breakdown_short.trim();
    }
    return null;
  }

  function extractCustomerTypesFromStructuredBreakdown(booking) {
    const types = [];

    if (Array.isArray(booking?.customer_breakdown)) {
      for (const entry of booking.customer_breakdown) {
        const name =
          entry.customer_type?.name ||
          entry.customer_type_name ||
          entry.display_name ||
          entry.name ||
          entry.label ||
          "Unknown";
        const quantity = entry.count ?? entry.quantity ?? entry.number ?? 1;
        types.push({ name: String(name), quantity: Number(quantity) || 0 });
      }
      return types.map((entry) => ({
        name: entry.name,
        normalizedName: normalizeCustomerTypeName(entry.name),
        quantity: entry.quantity
      }));
    }

    if (booking?.customer_breakdown && typeof booking.customer_breakdown === "object") {
      for (const [name, quantity] of Object.entries(booking.customer_breakdown)) {
        types.push({ name: String(name), quantity: Number(quantity) || 0 });
      }
      return types.map((entry) => ({
        name: entry.name,
        normalizedName: normalizeCustomerTypeName(entry.name),
        quantity: entry.quantity
      }));
    }

    if (Array.isArray(booking?.customers)) {
      for (const customer of booking.customers) {
        if (!customer?.customer_type && !customer?.customer_type_name && !customer?.customer_prototype) {
          continue;
        }
        const name =
          customer.customer_type?.name ||
          customer.customer_type_name ||
          customer.customer_prototype?.name ||
          "Unknown";
        types.push({ name: String(name), quantity: 1 });
      }
      return types.map((entry) => ({
        name: entry.name,
        normalizedName: normalizeCustomerTypeName(entry.name),
        quantity: entry.quantity
      }));
    }

    if (Array.isArray(booking?.customer_type_rates)) {
      for (const rate of booking.customer_type_rates) {
        const name =
          rate.customer_type?.name ||
          rate.customer_prototype?.name ||
          rate.display_name ||
          "Unknown";
        const quantity = rate.count ?? rate.quantity ?? 1;
        types.push({ name: String(name), quantity: Number(quantity) || 0 });
      }
      return types.map((entry) => ({
        name: entry.name,
        normalizedName: normalizeCustomerTypeName(entry.name),
        quantity: entry.quantity
      }));
    }

    return [];
  }

  function resolveCustomerTypesFromBooking(booking) {
    const breakdownText = getCustomerBreakdownText(booking);
    const parsedFromText = parseCustomerBreakdown(breakdownText);
    if (parsedFromText.length > 0) {
      return parsedFromText;
    }
    return extractCustomerTypesFromStructuredBreakdown(booking);
  }

  function extractCustomerBreakdownRaw(booking) {
    const text = getCustomerBreakdownText(booking);
    if (text) return text;
    if (booking?.customer_breakdown != null) return booking.customer_breakdown;
    if (Array.isArray(booking?.customer_type_rates)) return booking.customer_type_rates;
    return null;
  }

  function sumCustomerTypes(customerTypes) {
    return customerTypes.reduce((sum, ct) => sum + (ct.quantity || 0), 0);
  }

  function toTimestampMs(value) {
    if (value == null || value === "") return null;
    if (value instanceof Date) {
      const ms = value.getTime();
      return Number.isNaN(ms) ? null : ms;
    }
    const parsed = new Date(value);
    const ms = parsed.getTime();
    return Number.isNaN(ms) ? null : ms;
  }

  function isValidResourceName(name) {
    if (!name || typeof name !== "string") return false;
    const trimmed = name.trim();
    if (!trimmed || trimmed === "Unknown") return false;
    if (/^\d+\.?\d*\s+of\s+/i.test(trimmed)) return false;
    if (/\sUnknown$/i.test(trimmed)) return false;
    return true;
  }

  function getFullBookingPayload(source) {
    if (!source || typeof source !== "object") return null;
    if (source._fullBookingDetail) return source._fullBookingDetail;
    if (source.fullBookingDetail) return source.fullBookingDetail;
    if (source.booking?.customers) return source;
    if (source.rawBooking?._fullBookingDetail) return source.rawBooking._fullBookingDetail;
    return null;
  }

  function resolveRequirementFields(use) {
    const req = use?.resource_requirement;
    if (typeof req === "string") {
      return { uri: req, resource: null };
    }
    if (req && typeof req === "object") {
      return { uri: req.uri ?? null, resource: req.resource ?? null };
    }
    return { uri: null, resource: null };
  }

  function extractPkFromFareHarborUri(uri) {
    if (!uri || typeof uri !== "string") return null;
    const match = uri.match(/\/(\d+)\/?$/);
    return match ? Number(match[1]) : null;
  }

  function buildCustomerPkTypeMap(fullBookingPayload) {
    const map = {};
    const customers = fullBookingPayload?.booking?.customers || [];
    for (const customer of customers) {
      const pk = customer.pk ?? customer.id;
      if (pk == null) continue;
      const name =
        customer.customer_type?.name ||
        customer.customer_type_name ||
        customer.customer_prototype?.name ||
        null;
      if (name) {
        map[pk] = normalizeCustomerTypeName(name);
      }
    }
    return map;
  }

  function resolveCustomerTypeNameFromCustomer(customer, customerPkTypeMap) {
    const pk = customer?.pk ?? customer?.id;
    if (pk != null && customerPkTypeMap?.[pk]) {
      return customerPkTypeMap[pk];
    }
    const name =
      customer?.customer_type?.name ||
      customer?.customer_type_name ||
      customer?.customer_prototype?.name ||
      null;
    return name ? normalizeCustomerTypeName(name) : "Unknown customer type";
  }

  function resolveCustomerTypeNameForResourceUse(use, customer, customerPkTypeMap) {
    if (customer) {
      return resolveCustomerTypeNameFromCustomer(customer, customerPkTypeMap);
    }

    const useCustomer = use?.customer;
    if (useCustomer != null) {
      let pk = null;
      if (typeof useCustomer === "object") {
        pk = useCustomer.pk ?? useCustomer.id ?? null;
      } else if (typeof useCustomer === "string") {
        pk = extractPkFromFareHarborUri(useCustomer);
      }
      if (pk != null && customerPkTypeMap?.[pk]) {
        return customerPkTypeMap[pk];
      }
    }

    return "Unknown customer type";
  }

  function aggregateResourceUsesFromEntries(entries) {
    const resourcesUsed = {};
    const resourcesUsedByCustomerType = {};

    for (const entry of entries || []) {
      const resourceName = entry.resourceName;
      const customerTypeName = entry.customerTypeName || "Unknown customer type";
      const quantity = entry.quantity || 0;
      if (!isValidResourceName(resourceName) || quantity <= 0) continue;

      resourcesUsed[resourceName] = (resourcesUsed[resourceName] || 0) + quantity;

      if (!resourcesUsedByCustomerType[resourceName]) {
        resourcesUsedByCustomerType[resourceName] = { _total: 0 };
      }
      resourcesUsedByCustomerType[resourceName][customerTypeName] =
        (resourcesUsedByCustomerType[resourceName][customerTypeName] || 0) + quantity;
      resourcesUsedByCustomerType[resourceName]._total += quantity;
    }

    return { resourcesUsed, resourcesUsedByCustomerType };
  }

  function buildRequirementUriCacheForHistoricUses(rawUses, fullBookingPayload) {
    const requirementUriToResourceName = {};
    const requirementUriToResourceId = {};

    function addExpandedUseToCache(use) {
      const { uri, resource } = resolveRequirementFields(use);
      if (!uri || !resource?.name || !isValidResourceName(resource.name)) return;
      requirementUriToResourceName[uri] = resource.name;
      if (resource.pk != null && resource.pk !== "") {
        requirementUriToResourceId[uri] = resource.pk;
      }
    }

    const customers = fullBookingPayload?.booking?.customers || [];
    for (const customer of customers) {
      for (const use of customer.resource_uses || []) {
        addExpandedUseToCache(use);
      }
    }

    for (const use of rawUses || []) {
      addExpandedUseToCache(use);
    }

    return { requirementUriToResourceName, requirementUriToResourceId };
  }

  function buildRequirementUriCache(fullBookingPayload) {
    return buildRequirementUriCacheForHistoricUses([], fullBookingPayload);
  }

  function resolveResourceNameFromUse(use, uriCache) {
    const { uri, resource } = resolveRequirementFields(use);

    if (resource?.name && isValidResourceName(resource.name)) {
      return resource.name;
    }

    if (uri && uriCache?.requirementUriToResourceName?.[uri]) {
      return uriCache.requirementUriToResourceName[uri];
    }

    return null;
  }

  function normalizeCustomerLevelResourceUse(use, uriCache, customer, customerPkTypeMap) {
    if (!use || typeof use !== "object") return null;

    const resourceName = resolveResourceNameFromUse(use, uriCache);
    if (!isValidResourceName(resourceName)) return null;

    const customerTypeName = resolveCustomerTypeNameForResourceUse(
      use,
      customer,
      customerPkTypeMap
    );
    const quantity = Number(use.use_count ?? use.count ?? use.quantity ?? 1);
    if (!Number.isFinite(quantity) || quantity <= 0) return null;

    const { uri, resource } = resolveRequirementFields(use);
    const resourceId =
      resource?.pk ??
      (uri ? uriCache?.requirementUriToResourceId?.[uri] : null) ??
      null;

    return {
      resourceId,
      resourceName,
      customerTypeName,
      unicode: resource?.unicode ?? "",
      quantity,
      raw: use
    };
  }

  function extractCustomerLevelResourceEntries(fullBookingPayload, logContext) {
    if (!fullBookingPayload) return [];

    const uriCache = buildRequirementUriCache(fullBookingPayload);
    const customerPkTypeMap = buildCustomerPkTypeMap(fullBookingPayload);
    const customers = fullBookingPayload.booking?.customers || [];
    const entries = [];
    const resourceRows = [];

    for (const customer of customers) {
      for (const use of customer.resource_uses || []) {
        const normalized = normalizeCustomerLevelResourceUse(
          use,
          uriCache,
          customer,
          customerPkTypeMap
        );
        const { uri } = resolveRequirementFields(use);
        if (logContext?.bookingPk != null) {
          resourceRows.push({
            resourceName: normalized?.resourceName ?? resolveResourceNameFromUse(use, uriCache),
            resourceId: normalized?.resourceId ?? null,
            displayName: use?.display_name ?? null,
            normalizedDisplayName: normalized?.customerTypeName ?? null,
            useCount: Number(use?.use_count ?? use?.count ?? use?.quantity ?? 1),
            requirementUri: uri
          });
        }
        if (normalized) entries.push(normalized);
      }
    }

    if (logContext?.bookingPk != null) {
      console.log("[capacity-api] booking resource extraction", {
        bookingPk: logContext.bookingPk,
        resourceRows,
        aggregatedForBooking: aggregateResourceUsesFromEntries(entries)
      });
    }

    return entries;
  }

  function normalizeHistoricResourceUses(rawUses, fullBookingPayload, logContext) {
    if (!Array.isArray(rawUses)) return [];

    const uriCache = buildRequirementUriCacheForHistoricUses(rawUses, fullBookingPayload);
    const customerPkTypeMap = buildCustomerPkTypeMap(fullBookingPayload);
    const entries = [];
    const resolvedRows = [];

    for (const use of rawUses) {
      const { uri, resource } = resolveRequirementFields(use);
      const hadExpandedName = Boolean(resource?.name && isValidResourceName(resource.name));
      const normalized = normalizeCustomerLevelResourceUse(
        use,
        uriCache,
        null,
        customerPkTypeMap
      );
      const wasResolvedFromCache =
        !hadExpandedName &&
        Boolean(uri && uriCache.requirementUriToResourceName[uri] && normalized);

      resolvedRows.push({
        resourceName: normalized?.resourceName ?? resolveResourceNameFromUse(use, uriCache),
        resourceId: normalized?.resourceId ?? null,
        requirementUri: uri,
        displayName: use?.display_name ?? null,
        useCount: Number(use?.use_count ?? use?.count ?? use?.quantity ?? 1),
        wasResolvedFromCache
      });

      if (normalized) {
        entries.push(normalized);
      }
    }

    if (logContext?.selectedResourceStateSource?.includes("reapply")) {
      console.log("[capacity-api] historic reapply resource state", {
        bookingPk: logContext.bookingPk,
        selectedResourceStateSource: logContext.selectedResourceStateSource,
        selectedResourceUseCount: rawUses.length,
        resolvedRows,
        aggregatedForBooking: aggregateResourceUsesFromEntries(entries)
      });
    }

    return entries;
  }

  function normalizeReapplyResourceUses(rawUses, fullBookingPayload, logContext) {
    return normalizeHistoricResourceUses(rawUses, fullBookingPayload, logContext);
  }

  function customerLevelEntriesToResourceUsesAtTimestamp(entries) {
    return (entries || []).map((entry) => ({
      resourceId: entry.resourceId,
      resourceName: entry.resourceName,
      unicode: entry.unicode || "",
      quantity: entry.quantity,
      customerTypeName: entry.customerTypeName,
      raw: entry.raw
    }));
  }

  function extractResourceUsesArray(booking) {
    const fullBooking = getFullBookingPayload(booking);
    return extractCustomerLevelResourceEntries(fullBooking);
  }

  function bookingNeedsDetailFetch(booking) {
    const hasBreakdown = Boolean(getCustomerBreakdownText(booking));
    const hasCustomerResources = extractResourceUsesArray(booking).length > 0;

    if (!booking.uuid) {
      return { needed: true, reason: "missing_booking_uuid" };
    }
    if (!getFullBookingPayload(booking)) {
      return { needed: true, reason: "missing_full_booking_detail" };
    }
    if (!hasBreakdown) {
      return { needed: true, reason: "missing_customer_breakdown" };
    }
    if (!hasCustomerResources) {
      return { needed: true, reason: "missing_customer_level_resource_uses" };
    }
    return { needed: false, reason: null };
  }

  function mergeBookingDetailIntoRaw(booking, detail) {
    const merged = { ...booking };
    const bookingNode = detail?.booking || detail;

    if (bookingNode.customer_breakdown != null) {
      merged.customer_breakdown = bookingNode.customer_breakdown;
    }
    if (bookingNode.customer_breakdown_short != null) {
      merged.customer_breakdown_short = bookingNode.customer_breakdown_short;
    }
    if (bookingNode.customer_count != null) {
      merged.customer_count = bookingNode.customer_count;
    }

    merged._fullBookingDetail = detail;
    return merged;
  }

  function buildBookingResourceAttribution(fullBookingPayload, customerTypes) {
    const entries = extractCustomerLevelResourceEntries(fullBookingPayload);
    const resourceNames = [...new Set(entries.map((entry) => entry.resourceName))];
    return { resourceNames, customerTypes, customerLevelResourceEntries: entries };
  }

  function mapApiBookingsForCustomerTypeAggregation(filteredBookings) {
    return (filteredBookings || []).map((booking) => ({
      customerTypes: (booking.customerTypes || []).map((customerType) => ({
        name: customerType.name,
        quantity: customerType.quantity || 0
      }))
    }));
  }

  function aggregateCustomerTypesUsed(filteredBookings, customerTypeLookup) {
    const aggregateFn = window.AvailabilityAudit?.aggregateCustomerTypeUsage;
    const flattenFn = window.AvailabilityAudit?.flattenCustomerTypesUsedForDisplay;
    if (aggregateFn && flattenFn) {
      const aggregated = aggregateFn(
        mapApiBookingsForCustomerTypeAggregation(filteredBookings),
        customerTypeLookup || null
      );
      return flattenFn(aggregated);
    }

    const customerTypeCounts = {};
    for (const booking of filteredBookings || []) {
      if (!Array.isArray(booking.customerTypes)) continue;
      for (const customerType of booking.customerTypes) {
        const normalizedName =
          customerType.normalizedName || normalizeCustomerTypeName(customerType.name);
        if (!normalizedName || normalizedName === "Unknown") continue;
        const quantity = customerType.quantity || 0;
        if (quantity <= 0) continue;
        customerTypeCounts[normalizedName] =
          (customerTypeCounts[normalizedName] || 0) + quantity;
      }
    }
    return customerTypeCounts;
  }

  function withSnapshotReason(booking, reason) {
    return { ...booking, snapshotReason: reason };
  }

  function sortReapplyEventsByCreatedAt(events) {
    return [...(events || [])].sort((a, b) => {
      const aMs = toTimestampMs(a.createdAt);
      const bMs = toTimestampMs(b.createdAt);
      if (aMs == null && bMs == null) return 0;
      if (aMs == null) return 1;
      if (bMs == null) return -1;
      return aMs - bMs;
    });
  }

  function splitReapplyEventsByTarget(events, targetMs) {
    const reapplyEventsBeforeTarget = [];
    const reapplyEventsAfterTarget = [];

    for (const event of sortReapplyEventsByCreatedAt(events)) {
      const eventMs = toTimestampMs(event.createdAt);
      if (eventMs == null) continue;
      if (eventMs <= targetMs) {
        reapplyEventsBeforeTarget.push(event);
      } else {
        reapplyEventsAfterTarget.push(event);
      }
    }

    return { reapplyEventsBeforeTarget, reapplyEventsAfterTarget };
  }

  function resolveResourceStateAtTarget(booking, targetMs) {
    const fullBooking = getFullBookingPayload(booking);
    const customerPkTypeMap = buildCustomerPkTypeMap(fullBooking);
    const events = sortReapplyEventsByCreatedAt(booking.resourceReapplyEvents);
    const { reapplyEventsBeforeTarget, reapplyEventsAfterTarget } =
      splitReapplyEventsByTarget(events, targetMs);

    let selectedResourceStateSource;
    let resourceUsesAtTimestamp = [];
    const reapplyLogContext = { bookingPk: booking.pk, selectedResourceStateSource: null };

    if (events.length === 0) {
      selectedResourceStateSource = "current_booking_resource_uses_no_reapply_events";
      resourceUsesAtTimestamp = customerLevelEntriesToResourceUsesAtTimestamp(
        extractCustomerLevelResourceEntries(fullBooking)
      );
    } else if (reapplyEventsAfterTarget.length > 0) {
      selectedResourceStateSource =
        reapplyEventsBeforeTarget.length > 0
          ? "reapply_between_events"
          : "reapply_original_before_first_event";
      reapplyLogContext.selectedResourceStateSource = selectedResourceStateSource;
      const reapplyUses = reapplyEventsAfterTarget[0].originalResourceUses || [];
      resourceUsesAtTimestamp = customerLevelEntriesToResourceUsesAtTimestamp(
        normalizeHistoricResourceUses(reapplyUses, fullBooking, reapplyLogContext)
      );
    } else {
      selectedResourceStateSource = "reapply_latest_after_last_event";
      const currentEntries = extractCustomerLevelResourceEntries(fullBooking);
      if (currentEntries.length > 0) {
        resourceUsesAtTimestamp = customerLevelEntriesToResourceUsesAtTimestamp(currentEntries);
      } else {
        reapplyLogContext.selectedResourceStateSource = selectedResourceStateSource;
        const reapplyUses = events[events.length - 1].updatedResourceUses || [];
        resourceUsesAtTimestamp = customerLevelEntriesToResourceUsesAtTimestamp(
          normalizeHistoricResourceUses(reapplyUses, fullBooking, reapplyLogContext)
        );
      }
    }

    if (resourceUsesAtTimestamp.length === 0) {
      selectedResourceStateSource = "missing_resource_uses";
    }

    return {
      reapplyEventsBeforeTarget,
      reapplyEventsAfterTarget,
      selectedResourceStateSource,
      resourceUsesAtTimestamp
    };
  }

  function logFilteredBookingResourceDebug(booking, resourceState) {
    const resourceUses = resourceState.resourceUsesAtTimestamp || [];
    log("Filtered booking resource state:", {
      bookingPk: booking.pk,
      bookingUuid: booking.uuid,
      customerBreakdown: booking.customerBreakdown,
      parsedCustomerTypes: booking.customerTypes,
      resourceReapplyEventCount: booking.resourceReapplyEvents?.length ?? 0,
      selectedResourceStateSource: resourceState.selectedResourceStateSource,
      selectedResourceUseCount: resourceUses.length,
      selectedResourceNames: getUniqueResourceNamesFromUses(resourceUses),
      selectedResourceUses: resourceUses.map((use) => ({
        resourceName: use.resourceName,
        customerTypeName: use.customerTypeName,
        quantity: use.quantity
      }))
    });
  }

  function getUniqueResourceNamesFromUses(resourceUses) {
    return [
      ...new Set(
        (resourceUses || [])
          .map((use) => use.resourceName)
          .filter((name) => name && name !== "Unknown")
      )
    ];
  }

  function getAggregationEntriesForBooking(booking) {
    const needsHistoricReapplyState =
      (booking.reapplyEventsAfterTarget?.length ?? 0) > 0;

    if (!needsHistoricReapplyState && booking.customerLevelResourceEntries?.length > 0) {
      return booking.customerLevelResourceEntries;
    }

    const atTimestamp = booking.resourceUsesAtTimestamp || [];
    if (atTimestamp.length > 0) {
      return atTimestamp.map((use) => ({
        resourceName: use.resourceName,
        customerTypeName: use.customerTypeName,
        quantity: use.quantity,
        resourceId: use.resourceId,
        unicode: use.unicode
      }));
    }

    return booking.customerLevelResourceEntries || [];
  }

  function mergeAggregatedResourceTotals(target, source) {
    for (const [resourceName, count] of Object.entries(source.resourcesUsed || {})) {
      target.resourcesUsed[resourceName] = (target.resourcesUsed[resourceName] || 0) + count;
    }

    for (const [resourceName, breakdown] of Object.entries(source.resourcesUsedByCustomerType || {})) {
      if (!target.resourcesUsedByCustomerType[resourceName]) {
        target.resourcesUsedByCustomerType[resourceName] = { _total: 0 };
      }
      for (const [typeName, qty] of Object.entries(breakdown)) {
        if (typeName === "_total") continue;
        target.resourcesUsedByCustomerType[resourceName][typeName] =
          (target.resourcesUsedByCustomerType[resourceName][typeName] || 0) + qty;
        target.resourcesUsedByCustomerType[resourceName]._total += qty;
      }
    }
  }

  function aggregateResourcesUsedAcrossBookings(filteredBookings) {
    const merged = { resourcesUsed: {}, resourcesUsedByCustomerType: {} };

    for (const booking of filteredBookings || []) {
      const entries = getAggregationEntriesForBooking(booking);
      mergeAggregatedResourceTotals(merged, aggregateResourceUsesFromEntries(entries));
    }

    return merged;
  }

  function passThroughFlatResourcesUsed(resourcesUsed) {
    if (!resourcesUsed || typeof resourcesUsed !== "object") return {};
    const flat = {};

    for (const [resourceName, value] of Object.entries(resourcesUsed)) {
      if (!isValidResourceName(resourceName)) continue;
      if (typeof value === "number" && Number.isFinite(value)) {
        flat[resourceName] = value;
        continue;
      }
      console.warn(
        "[capacity-api] resourcesUsed contains non-numeric value; refusing to rebuild from object",
        { resourceName, value }
      );
    }

    return flat;
  }

  function assertFlatResourcesUsedInvariants(resourcesUsed, label) {
    if (!resourcesUsed || typeof resourcesUsed !== "object") return;

    for (const [resourceName, value] of Object.entries(resourcesUsed)) {
      if (typeof value !== "number" || !Number.isFinite(value)) {
        console.warn(`[capacity-api] invariant violation at ${label}:`, {
          resourceName,
          value,
          expected: "flat numeric total"
        });
      }
    }
  }

  function aggregateResourcesUsedByCustomerType(filteredBookings) {
    const grouped = {};

    for (const booking of filteredBookings || []) {
      for (const use of booking.resourceUsesAtTimestamp || []) {
        const resourceName = use.resourceName;
        if (!isValidResourceName(resourceName)) continue;

        const typeName = use.customerTypeName || "Unknown customer type";
        const qty = use.quantity || 0;
        if (qty <= 0) continue;

        if (!grouped[resourceName]) {
          grouped[resourceName] = { _total: 0 };
        }

        grouped[resourceName][typeName] = (grouped[resourceName][typeName] || 0) + qty;
        grouped[resourceName]._total += qty;
      }
    }

    return grouped;
  }

  function aggregateResourcesUsedAtTimestamp(filteredBookings) {
    const grouped = {};

    for (const booking of filteredBookings || []) {
      for (const use of booking.resourceUsesAtTimestamp || []) {
        const resourceName = use.resourceName;
        if (!isValidResourceName(resourceName)) continue;

        if (!grouped[resourceName]) {
          grouped[resourceName] = {
            resourceId: use.resourceId,
            resourceName,
            unicode: use.unicode || "",
            quantity: 0
          };
        }
        grouped[resourceName].quantity += use.quantity || 0;
      }
    }

    return grouped;
  }

  function aggregateResourcesUsedFlat(filteredBookings) {
    const flat = {};
    for (const booking of filteredBookings || []) {
      for (const use of booking.resourceUsesAtTimestamp || []) {
        const resourceName = use.resourceName;
        if (!isValidResourceName(resourceName)) continue;
        flat[resourceName] = (flat[resourceName] || 0) + (use.quantity || 0);
      }
    }
    return flat;
  }

  function enrichFilteredBookingForSnapshot(booking, targetMs) {
    const resourceState = resolveResourceStateAtTarget(booking, targetMs);
    logFilteredBookingResourceDebug(booking, resourceState);
    return {
      ...withSnapshotReason(booking, "active_at_timestamp"),
      ...resourceState
    };
  }

  const RESERVATION_HOLD_ACTIVITY_TYPES = {
    RESERVED: "reseller-reserved-booking",
    CANCELLED: "reseller-cancelled-reservation"
  };

  function getActivityBookingPk(activity) {
    const pk = activity?.context?.booking_pk;
    return pk != null && pk !== "" ? pk : null;
  }

  function parseHoldDurationMinutes(value) {
    if (value == null || value === "") return null;
    const parsed = Number(value);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
  }

  function sortActivitiesByCreatedAt(activities) {
    return [...(activities || [])].sort((a, b) => {
      const aMs = toTimestampMs(a?.created_at);
      const bMs = toTimestampMs(b?.created_at);
      if (aMs == null && bMs == null) return 0;
      if (aMs == null) return 1;
      if (bMs == null) return -1;
      return aMs - bMs;
    });
  }

  function extractReservationHoldActivities(activities) {
    const reservations = [];
    const cancellations = [];

    for (const activity of activities || []) {
      const type = getActivityType(activity);
      if (type === RESERVATION_HOLD_ACTIVITY_TYPES.RESERVED) {
        reservations.push(activity);
      } else if (type === RESERVATION_HOLD_ACTIVITY_TYPES.CANCELLED) {
        cancellations.push(activity);
      }
    }

    return { reservations, cancellations };
  }

  function parseReservationCustomerBreakdown(text, customerTypeLookup) {
    const parsed = parseCustomerBreakdown(text);
    if (parsed.length === 0) {
      return { customerTypes: [], capacityUsed: 0 };
    }

    const customerTypes = parsed.map((entry) => ({
      name: entry.name,
      quantity: entry.quantity,
      normalizedName: entry.normalizedName
    }));

    return {
      customerTypes,
      capacityUsed: sumCustomerTypes(customerTypes)
    };
  }

  const RESERVATION_HOLD_STATUS = {
    ACTIVE_AT_TIMESTAMP: {
      key: "active_at_timestamp",
      label: "Active at timestamp"
    },
    RELEASED_BEFORE_TIMESTAMP: {
      key: "released_before_timestamp",
      label: "Released before timestamp"
    },
    PLACED_AFTER_TIMESTAMP: {
      key: "placed_after_timestamp",
      label: "Placed after timestamp"
    },
    FULFILLED_AS_BOOKING: {
      key: "fulfilled_as_booking",
      label: "Fulfilled as booking"
    },
    UNRESOLVED: {
      key: "unresolved",
      label: "Unresolved"
    }
  };

  function computeExpectedExpiryAt(reservedAt, holdDurationMinutes) {
    const reservedMs = toTimestampMs(reservedAt);
    if (reservedMs == null || holdDurationMinutes == null) return null;
    return new Date(reservedMs + holdDurationMinutes * 60 * 1000).toISOString();
  }

  function isBookingActiveAtTimestamp(bookings, bookingPk, targetMs) {
    const booking = (bookings || []).find((entry) => {
      const pk = entry?.pk ?? entry?.rawBooking?.pk;
      return pk != null && (pk === bookingPk || String(pk) === String(bookingPk));
    });
    if (!booking) return null;

    const bookedAtMs = toTimestampMs(booking.bookedAt);
    const cancelledAtMs = toTimestampMs(booking.cancelledAt);
    if (bookedAtMs == null || bookedAtMs > targetMs) return false;
    if (cancelledAtMs != null && cancelledAtMs <= targetMs) return false;
    return true;
  }

  function isHoldFulfilled(bookingPk, fulfilledBookingPks) {
    return (
      fulfilledBookingPks.has(bookingPk) || fulfilledBookingPks.has(String(bookingPk))
    );
  }

  function classifyReservationHoldStatusAtTimestamp(hold, targetMs, isFulfilled) {
    if (isFulfilled) {
      return {
        statusAtTimestamp: RESERVATION_HOLD_STATUS.FULFILLED_AS_BOOKING.key,
        statusLabel: RESERVATION_HOLD_STATUS.FULFILLED_AS_BOOKING.label,
        activeAtTimestamp: false
      };
    }

    const reservedMs = toTimestampMs(hold.reservedAt);
    if (reservedMs == null) {
      return {
        statusAtTimestamp: RESERVATION_HOLD_STATUS.UNRESOLVED.key,
        statusLabel: RESERVATION_HOLD_STATUS.UNRESOLVED.label,
        activeAtTimestamp: false
      };
    }

    if (reservedMs > targetMs) {
      return {
        statusAtTimestamp: RESERVATION_HOLD_STATUS.PLACED_AFTER_TIMESTAMP.key,
        statusLabel: RESERVATION_HOLD_STATUS.PLACED_AFTER_TIMESTAMP.label,
        activeAtTimestamp: false
      };
    }

    const releasedMs = toTimestampMs(hold.releasedAt);
    if (releasedMs != null) {
      if (targetMs < releasedMs) {
        return {
          statusAtTimestamp: RESERVATION_HOLD_STATUS.ACTIVE_AT_TIMESTAMP.key,
          statusLabel: RESERVATION_HOLD_STATUS.ACTIVE_AT_TIMESTAMP.label,
          activeAtTimestamp: true
        };
      }
      return {
        statusAtTimestamp: RESERVATION_HOLD_STATUS.RELEASED_BEFORE_TIMESTAMP.key,
        statusLabel: RESERVATION_HOLD_STATUS.RELEASED_BEFORE_TIMESTAMP.label,
        activeAtTimestamp: false
      };
    }

    const holdDurationMinutes = hold.holdDurationMinutes;
    if (holdDurationMinutes != null) {
      const expiryMs = reservedMs + holdDurationMinutes * 60 * 1000;
      if (targetMs < expiryMs) {
        return {
          statusAtTimestamp: RESERVATION_HOLD_STATUS.ACTIVE_AT_TIMESTAMP.key,
          statusLabel: RESERVATION_HOLD_STATUS.ACTIVE_AT_TIMESTAMP.label,
          activeAtTimestamp: true
        };
      }
      return {
        statusAtTimestamp: RESERVATION_HOLD_STATUS.RELEASED_BEFORE_TIMESTAMP.key,
        statusLabel: RESERVATION_HOLD_STATUS.RELEASED_BEFORE_TIMESTAMP.label,
        activeAtTimestamp: false
      };
    }

    return {
      statusAtTimestamp: RESERVATION_HOLD_STATUS.UNRESOLVED.key,
      statusLabel: RESERVATION_HOLD_STATUS.UNRESOLVED.label,
      activeAtTimestamp: false
    };
  }

  function buildAllReservationHolds(reservations, cancellations, bookings, customerTypeLookup, targetMs) {
    const fulfilledBookingPks = buildFulfilledBookingPkSet(bookings);
    const reservationsByPk = {};
    const cancellationsByPk = {};

    for (const reservation of reservations || []) {
      const pk = getActivityBookingPk(reservation);
      if (pk == null) continue;
      if (!reservationsByPk[pk]) reservationsByPk[pk] = [];
      reservationsByPk[pk].push(reservation);
    }

    for (const cancellation of cancellations || []) {
      const pk = getActivityBookingPk(cancellation);
      if (pk == null) continue;
      if (!cancellationsByPk[pk]) cancellationsByPk[pk] = [];
      cancellationsByPk[pk].push(cancellation);
    }

    const reservationHolds = [];
    const unresolvedHolds = [];
    let fulfilledHoldsRecognized = 0;
    const bookingPks = new Set([
      ...Object.keys(reservationsByPk),
      ...Object.keys(cancellationsByPk)
    ]);

    for (const pkKey of bookingPks) {
      const reservationList = sortActivitiesByCreatedAt(reservationsByPk[pkKey] || []);
      const cancellationList = sortActivitiesByCreatedAt(cancellationsByPk[pkKey] || []);

      if (reservationList.length === 0) {
        if (cancellationList.length > 0) {
          warn("Reservation hold timeline: cancellation without reservation", {
            bookingPk: pkKey,
            cancellationCount: cancellationList.length
          });
        }
        continue;
      }

      if (cancellationList.length > reservationList.length) {
        warn("Reservation hold timeline: more cancellations than reservations", {
          bookingPk: pkKey,
          reservationCount: reservationList.length,
          cancellationCount: cancellationList.length
        });
      }

      for (let index = 0; index < reservationList.length; index += 1) {
        const reservation = reservationList[index];
        const cancellation = cancellationList[index] || null;
        const bookingPk = getActivityBookingPk(reservation) ?? pkKey;
        const breakdown = reservation?.context?.customer_breakdown || null;
        const parsed = parseReservationCustomerBreakdown(breakdown, customerTypeLookup);
        const releasedAt = cancellation?.created_at || null;
        const holdDurationMinutes = parseHoldDurationMinutes(
          reservation?.context?.hold_duration_minutes
        );
        const reservedAt = reservation?.created_at || null;
        const isFulfilled = isHoldFulfilled(bookingPk, fulfilledBookingPks);

        if (isFulfilled) {
          fulfilledHoldsRecognized += 1;
        }

        const holdBase = {
          bookingPk,
          otaDisplayName: reservation?.context?.ota_display_name || null,
          customerBreakdown: breakdown,
          reservedAt,
          releasedAt,
          expectedExpiryAt: computeExpectedExpiryAt(reservedAt, holdDurationMinutes),
          holdDurationMinutes,
          customerTypes: parsed.customerTypes,
          capacityUsed: parsed.capacityUsed,
          fulfilledBookingPk: isFulfilled ? bookingPk : null
        };

        if (!isFulfilled && releasedAt == null && holdDurationMinutes == null) {
          unresolvedHolds.push({
            bookingPk,
            reservedAt
          });
        }

        const status = classifyReservationHoldStatusAtTimestamp(holdBase, targetMs, isFulfilled);
        const hold = {
          ...holdBase,
          ...status
        };

        if (isFulfilled) {
          hold.fulfilledBookingActiveAtTimestamp = isBookingActiveAtTimestamp(
            bookings,
            bookingPk,
            targetMs
          );
        }

        reservationHolds.push(hold);
      }
    }

    return {
      reservationHolds,
      matchingStats: {
        fulfilledHoldsRecognized,
        unfinalizedHoldTimelines: reservationHolds.filter((hold) => !hold.fulfilledBookingPk).length,
        unresolvedHolds
      }
    };
  }

  function summarizeHoldStatusBreakdown(reservationHolds) {
    const breakdown = {
      total: reservationHolds.length,
      activeAtTimestamp: 0,
      releasedBeforeTimestamp: 0,
      fulfilledAsBooking: 0,
      placedAfterTimestamp: 0,
      unresolved: 0
    };

    for (const hold of reservationHolds || []) {
      switch (hold.statusAtTimestamp) {
        case RESERVATION_HOLD_STATUS.ACTIVE_AT_TIMESTAMP.key:
          breakdown.activeAtTimestamp += 1;
          break;
        case RESERVATION_HOLD_STATUS.RELEASED_BEFORE_TIMESTAMP.key:
          breakdown.releasedBeforeTimestamp += 1;
          break;
        case RESERVATION_HOLD_STATUS.FULFILLED_AS_BOOKING.key:
          breakdown.fulfilledAsBooking += 1;
          break;
        case RESERVATION_HOLD_STATUS.PLACED_AFTER_TIMESTAMP.key:
          breakdown.placedAfterTimestamp += 1;
          break;
        case RESERVATION_HOLD_STATUS.UNRESOLVED.key:
          breakdown.unresolved += 1;
          break;
        default:
          break;
      }
    }

    return breakdown;
  }

  function getActiveReservationHoldsFromAll(reservationHolds) {
    return (reservationHolds || []).filter((hold) => hold.activeAtTimestamp === true);
  }

  function mergeReservationHoldsIntoCustomerTypeTotals(
    customerTypesUsedDetailed,
    customerTypesUsed,
    activeHolds,
    customerTypeLookup
  ) {
    const resolveFn = window.AvailabilityAudit?.resolveCustomerTypeFromLookup;
    const accumulateFn = window.AvailabilityAudit?.accumulateCustomerTypeEntry;
    const flattenFn = window.AvailabilityAudit?.flattenCustomerTypesUsedForDisplay;

    const hasDetailed =
      customerTypesUsedDetailed && typeof customerTypesUsedDetailed === "object" &&
      Object.keys(customerTypesUsedDetailed).length > 0;

    if (resolveFn && accumulateFn && hasDetailed) {
      const aggregated = { ...customerTypesUsedDetailed };

      for (const hold of activeHolds || []) {
        for (const customerType of hold.customerTypes || []) {
          const { resolved, outputLabel, aggregateKey } = resolveFn(
            customerType.name,
            customerTypeLookup
          );
          accumulateFn(aggregated, aggregateKey, outputLabel, customerType.quantity, resolved);
        }
      }

      return {
        detailed: aggregated,
        flat: flattenFn ? flattenFn(aggregated) : { ...(customerTypesUsed || {}) }
      };
    }

    const flat = { ...(customerTypesUsed || {}) };
    for (const hold of activeHolds || []) {
      for (const customerType of hold.customerTypes || []) {
        const label =
          customerType.normalizedName || normalizeCustomerTypeName(customerType.name);
        if (!label || label === "Unknown") continue;
        const quantity = customerType.quantity || 0;
        if (quantity <= 0) continue;
        flat[label] = (flat[label] || 0) + quantity;
      }
    }

    return {
      detailed: customerTypesUsedDetailed || null,
      flat
    };
  }

  function buildFulfilledBookingPkSet(bookings) {
    const fulfilled = new Set();
    for (const booking of bookings || []) {
      const pk = booking?.pk ?? booking?.rawBooking?.pk;
      if (pk == null || pk === "") continue;
      fulfilled.add(pk);
      fulfilled.add(String(pk));
      const numericPk = Number(pk);
      if (Number.isFinite(numericPk)) {
        fulfilled.add(numericPk);
      }
    }
    return fulfilled;
  }

  function summarizeHeldCustomerTypes(activeHolds, customerTypeLookup) {
    const heldCustomerTypes = {};
    const resolveFn = window.AvailabilityAudit?.resolveCustomerTypeFromLookup;

    for (const hold of activeHolds || []) {
      for (const customerType of hold.customerTypes || []) {
        const quantity = customerType.quantity || 0;
        if (quantity <= 0) continue;

        let label = null;
        if (resolveFn) {
          label = resolveFn(customerType.name, customerTypeLookup).outputLabel;
        } else {
          label = customerType.normalizedName || normalizeCustomerTypeName(customerType.name);
        }
        if (!label) continue;
        heldCustomerTypes[label] = (heldCustomerTypes[label] || 0) + quantity;
      }
    }

    return heldCustomerTypes;
  }

  function logReservationHoldSnapshot(summary) {
    log("Reservation hold snapshot", summary);
  }

  function applyReservationHoldsToCapacitySnapshot(snapshotInputs) {
    const {
      isLiveAudit,
      apiData,
      bookings,
      targetMs,
      targetTimestamp,
      customerTypeLookup,
      customerTypesUsedDetailed,
      customerTypesUsed,
      totalCapacityUsed
    } = snapshotInputs;

    const targetIso =
      targetTimestamp || (targetMs != null ? new Date(targetMs).toISOString() : null);

    let reservationHolds = [];
    let activeReservationHolds = [];
    let reservedCapacityUsed = 0;
    let nextTotalCapacityUsed = totalCapacityUsed;
    let nextCustomerTypesUsedDetailed = customerTypesUsedDetailed;
    let nextCustomerTypesUsed = customerTypesUsed;

    function finishHoldSnapshot(extra) {
      const heldCustomerTypes = summarizeHeldCustomerTypes(
        activeReservationHolds,
        customerTypeLookup
      );
      const statusBreakdown = summarizeHoldStatusBreakdown(reservationHolds);
      logReservationHoldSnapshot({
        targetTimestamp: targetIso,
        reservationEvents: extra?.reservationEvents ?? 0,
        cancellationEvents: extra?.cancellationEvents ?? 0,
        fulfilledHolds: extra?.fulfilledHolds ?? 0,
        unfinalizedHoldTimelines: extra?.unfinalizedHoldTimelines ?? 0,
        unresolvedHolds: extra?.unresolvedHolds ?? [],
        reservationHoldCount: reservationHolds.length,
        activeReservationHolds: activeReservationHolds.length,
        reservedCapacityUsed,
        heldCustomerTypes,
        statusBreakdown,
        ...(extra?.skipReason ? { skipReason: extra.skipReason } : {})
      });

      return {
        reservationHolds,
        reservationHoldCount: reservationHolds.length,
        activeReservationHolds,
        activeReservationHoldCount: activeReservationHolds.length,
        reservedCapacityUsed,
        totalCapacityUsed: nextTotalCapacityUsed,
        customerTypesUsedDetailed: nextCustomerTypesUsedDetailed,
        customerTypesUsed: nextCustomerTypesUsed
      };
    }

    if (isLiveAudit) {
      return finishHoldSnapshot({ skipReason: "live_audit" });
    }

    const availabilityActivities = apiData?.availabilityActivities;
    if (!Array.isArray(availabilityActivities) || availabilityActivities.length === 0) {
      return finishHoldSnapshot({
        skipReason: Array.isArray(availabilityActivities) ? "no_availability_activities" : "missing_availability_activities"
      });
    }

    const { reservations, cancellations } = extractReservationHoldActivities(availabilityActivities);
    log("Reservation hold activities extracted", {
      reservationEvents: reservations.length,
      cancellationEvents: cancellations.length
    });

    const { reservationHolds: allReservationHolds, matchingStats } = buildAllReservationHolds(
      reservations,
      cancellations,
      bookings,
      customerTypeLookup,
      targetMs
    );
    reservationHolds = allReservationHolds;

    log("Reservation hold timeline matching", {
      fulfilledHolds: matchingStats.fulfilledHoldsRecognized,
      unfinalizedHoldTimelines: matchingStats.unfinalizedHoldTimelines,
      unresolvedHolds: matchingStats.unresolvedHolds
    });

    if (matchingStats.unresolvedHolds.length > 0) {
      warn("Unresolved reservation holds (no release event or hold_duration_minutes)", {
        count: matchingStats.unresolvedHolds.length,
        bookingPks: matchingStats.unresolvedHolds.map((hold) => hold.bookingPk)
      });
    }

    activeReservationHolds = getActiveReservationHoldsFromAll(reservationHolds);
    reservedCapacityUsed = activeReservationHolds.reduce(
      (sum, hold) => sum + (Number(hold.capacityUsed) || 0),
      0
    );

    if (activeReservationHolds.length > 0) {
      const merged = mergeReservationHoldsIntoCustomerTypeTotals(
        nextCustomerTypesUsedDetailed,
        nextCustomerTypesUsed,
        activeReservationHolds,
        customerTypeLookup
      );
      nextCustomerTypesUsedDetailed = merged.detailed;
      nextCustomerTypesUsed = merged.flat;
      nextTotalCapacityUsed += reservedCapacityUsed;
    }

    return finishHoldSnapshot({
      reservationEvents: reservations.length,
      cancellationEvents: cancellations.length,
      fulfilledHolds: matchingStats.fulfilledHoldsRecognized,
      unfinalizedHoldTimelines: matchingStats.unfinalizedHoldTimelines,
      unresolvedHolds: matchingStats.unresolvedHolds
    });
  }

  function calculateHistoricCapacityFromApiData(apiData, targetTimestamp, options) {
    const opts = options && typeof options === "object" ? options : {};
    const targetMs = toTimestampMs(targetTimestamp);
    if (targetMs == null) {
      return {
        ok: false,
        error: "Invalid target timestamp",
        targetTimestamp: null,
        filteredBookings: [],
        skippedBookings: [],
        totalCapacityUsed: 0,
        customerTypesUsed: {},
        reservationHolds: [],
        activeReservationHolds: [],
        reservationHoldCount: 0,
        activeReservationHoldCount: 0,
        reservedCapacityUsed: 0
      };
    }

    const bookings = apiData?.bookings || [];
    const filteredBookings = [];
    const skippedBookings = [];
    const targetIso = new Date(targetMs).toISOString();
    const customerTypeLookup = opts.customerTypeLookup || apiData?.customerTypeLookup || null;
    const availabilityDetails = apiData?.availability || null;
    const isLiveAudit =
      opts.isLiveAudit === true ||
      window.AvailabilityAudit?.isCurrentSnapshotAudit?.(new Date(targetMs)) === true;

    for (const booking of bookings) {
      const bookedAtMs = toTimestampMs(booking.bookedAt);
      const cancelledAtMs = toTimestampMs(booking.cancelledAt);

      if (bookedAtMs == null) {
        skippedBookings.push(withSnapshotReason(booking, "booked_after_timestamp"));
        continue;
      }

      if (bookedAtMs > targetMs) {
        skippedBookings.push(withSnapshotReason(booking, "booked_after_timestamp"));
        continue;
      }

      if (cancelledAtMs != null && cancelledAtMs <= targetMs) {
        skippedBookings.push(withSnapshotReason(booking, "cancelled_before_or_at_timestamp"));
        continue;
      }

      filteredBookings.push(enrichFilteredBookingForSnapshot(booking, targetMs));
    }

    let totalCapacityUsed = filteredBookings.reduce(
      (sum, booking) => sum + (Number(booking.customerCount) || 0),
      0
    );
    let customerTypesUsed = {};
    let customerTypesUsedDetailed = null;

    if (
      isLiveAudit &&
      customerTypeLookup &&
      availabilityDetails &&
      window.AvailabilityAudit?.buildCustomerTypesUsedFromAvailability
    ) {
      const fromAvailability = window.AvailabilityAudit.buildCustomerTypesUsedFromAvailability(
        availabilityDetails,
        customerTypeLookup
      );
      customerTypesUsedDetailed = fromAvailability.aggregated;
      customerTypesUsed = fromAvailability.flat;
      if (Number.isFinite(fromAvailability.totalFromApi) && fromAvailability.totalFromApi > 0) {
        totalCapacityUsed = fromAvailability.totalFromApi;
      }
    } else {
      const aggregateFn = window.AvailabilityAudit?.aggregateCustomerTypeUsage;
      const flattenFn = window.AvailabilityAudit?.flattenCustomerTypesUsedForDisplay;
      if (aggregateFn && flattenFn) {
        customerTypesUsedDetailed = aggregateFn(
          mapApiBookingsForCustomerTypeAggregation(filteredBookings),
          customerTypeLookup || null
        );
        customerTypesUsed = flattenFn(customerTypesUsedDetailed);
      } else {
        customerTypesUsed = aggregateCustomerTypesUsed(filteredBookings, customerTypeLookup);
      }
    }

    const holdSnapshot = applyReservationHoldsToCapacitySnapshot({
      isLiveAudit,
      apiData,
      bookings,
      targetMs,
      targetTimestamp: targetIso,
      customerTypeLookup,
      customerTypesUsedDetailed,
      customerTypesUsed,
      totalCapacityUsed
    });
    totalCapacityUsed = holdSnapshot.totalCapacityUsed;
    customerTypesUsed = holdSnapshot.customerTypesUsed;
    customerTypesUsedDetailed = holdSnapshot.customerTypesUsedDetailed;
    const activeReservationHolds = holdSnapshot.activeReservationHolds;
    const reservedCapacityUsed = holdSnapshot.reservedCapacityUsed;
    const reservationHolds = holdSnapshot.reservationHolds;

    const resourcesUsedAtTimestamp = aggregateResourcesUsedAtTimestamp(filteredBookings);
    const aggregatedResources = aggregateResourcesUsedAcrossBookings(filteredBookings);
    const resourcesUsed = aggregatedResources.resourcesUsed;
    const resourcesUsedByCustomerType = aggregatedResources.resourcesUsedByCustomerType;

    console.log("[capacity-api] aggregated resources before result", resourcesUsed);
    assertFlatResourcesUsedInvariants(resourcesUsed, "aggregated resources before result");

    let totalReapplyEventsBeforeTarget = 0;
    let totalReapplyEventsAfterTarget = 0;
    for (const booking of filteredBookings) {
      totalReapplyEventsBeforeTarget += booking.reapplyEventsBeforeTarget?.length || 0;
      totalReapplyEventsAfterTarget += booking.reapplyEventsAfterTarget?.length || 0;
    }

    const snapshot = {
      ok: true,
      targetTimestamp: targetIso,
      filteredBookings,
      skippedBookings,
      totalCapacityUsed,
      customerTypesUsed,
      customerTypesUsedDetailed,
      resourcesUsed,
      resourcesUsedAtTimestamp,
      resourcesUsedByCustomerType,
      totalReapplyEventsBeforeTarget,
      totalReapplyEventsAfterTarget,
      totalBookingsScanned: bookings.length,
      activeAtTimestampCount: filteredBookings.length,
      skippedCount: skippedBookings.length,
      activeReservationHolds: activeReservationHolds ?? [],
      reservationHolds: reservationHolds ?? [],
      reservationHoldCount: holdSnapshot.reservationHoldCount ?? (reservationHolds?.length || 0),
      activeReservationHoldCount:
        holdSnapshot.activeReservationHoldCount ?? (activeReservationHolds?.length || 0),
      reservedCapacityUsed: reservedCapacityUsed ?? 0
    };

    log("Historic capacity snapshot:", snapshot);
    return snapshot;
  }

  function normalizeBookingForHistoricCapacity(booking, activities) {
    if (!loggedBookingKeys && booking && typeof booking === "object") {
      log("Sample booking API keys:", Object.keys(booking));
      loggedBookingKeys = true;
    }

    const fullBookingDetail = getFullBookingPayload(booking);
    const customerTypes = fullBookingDetail?.booking
      ? extractCustomerTypesFromStructuredBreakdown(fullBookingDetail.booking)
      : resolveCustomerTypesFromBooking(booking);
    const resolvedCustomerTypes =
      customerTypes.length > 0 ? customerTypes : resolveCustomerTypesFromBooking(booking);
    const customerBreakdown = extractCustomerBreakdownRaw(booking);
    const customerLevelResourceEntries = extractCustomerLevelResourceEntries(fullBookingDetail, {
      bookingPk: booking.pk
    });
    const resourceAttribution = buildBookingResourceAttribution(fullBookingDetail, resolvedCustomerTypes);

    if (!loggedResourceUseKeys && customerLevelResourceEntries.length > 0) {
      log("Sample customer-level resource_use keys:", Object.keys(customerLevelResourceEntries[0].raw || {}));
      loggedResourceUseKeys = true;
    }

    log("Normalized booking customer debug:", {
      pk: booking.pk,
      uuid: booking.uuid,
      customer_count: booking.customer_count,
      customer_breakdown: customerBreakdown,
      customer_breakdown_short: booking.customer_breakdown_short ?? null,
      parsedCustomerTypes: resolvedCustomerTypes,
      customerLevelResourceEntryCount: customerLevelResourceEntries.length,
      resourceAttribution
    });

    const cancelledAt = findEarliestCancellation(activities);
    const bookedAt = booking.original_created_at || booking.created_at || null;

    let isCurrentlyCancelled = booking.is_cancelled;
    if (isCurrentlyCancelled == null && booking.status != null) {
      isCurrentlyCancelled = String(booking.status).toLowerCase() === "cancelled";
    }
    if (isCurrentlyCancelled == null) {
      isCurrentlyCancelled = !!cancelledAt;
    }

    let isContributing = booking.is_contributing;
    if (isContributing == null) {
      warn(`Booking ${booking.pk} missing is_contributing field`);
    }

    let customerCount = sumCustomerTypes(resolvedCustomerTypes);
    if (customerCount === 0 && booking.customer_count != null && booking.customer_count !== "") {
      customerCount = Number(booking.customer_count) || 0;
    }

    return {
      pk: booking.pk,
      uuid: booking.uuid,
      bookingNumber: booking.display_id || booking.booking_number || booking.pk,
      bookedAt,
      cancelledAt,
      isCurrentlyCancelled,
      isContributing,
      customerCount,
      partySize: customerCount,
      customerBreakdown,
      customerTypes: resolvedCustomerTypes,
      fullBookingDetail,
      customerLevelResourceEntries,
      resourceAttribution,
      resourceReapplyEvents: extractResourceReapplyEvents(activities),
      rawBooking: booking,
      activities: activities || []
    };
  }

  async function mapWithConcurrency(items, concurrency, fn) {
    const results = new Array(items.length);
    let nextIndex = 0;

    async function worker() {
      while (nextIndex < items.length) {
        const index = nextIndex;
        nextIndex += 1;
        results[index] = await fn(items[index], index);
      }
    }

    const workers = Array.from({ length: Math.min(concurrency, items.length) }, () => worker());
    await Promise.all(workers);
    return results;
  }

  function validateContext(context) {
    if (!context.company) {
      return "Could not parse company shortname from URL pathname";
    }
    if (!context.itemId) {
      return "Could not parse itemId from URL — open an item availability page";
    }
    if (!context.availabilityId) {
      return (
        "Could not parse availabilityId from URL — open an availability with " +
        "?overlay=/items/{itemId}/availabilities/{availabilityId}/ in the URL"
      );
    }
    return null;
  }

  async function fetchHistoricCapacityApiData(context) {
    const resolvedContext = context || parseFareHarborApiContextFromPage();
    log("Parsed API context:", resolvedContext);

    const contextError = validateContext(resolvedContext);
    if (contextError) {
      error(contextError);
      return {
        ok: false,
        error: contextError,
        context: resolvedContext,
        availability: null,
        bookings: [],
        errors: []
      };
    }

    const { company, itemId, availabilityId } = resolvedContext;
    const errors = [];

    const availabilityResult = await fetchAvailabilityApi(company, itemId, availabilityId);
    if (!availabilityResult.ok) {
      error("Failed to fetch availability:", availabilityResult.error);
      return {
        ok: false,
        error: availabilityResult.error,
        context: resolvedContext,
        availability: null,
        bookings: [],
        errors
      };
    }

    const prototypesResult = await fetchCustomerPrototypesApi(company, itemId);
    let customerTypeLookup = null;
    let customerPrototypes = [];
    if (prototypesResult.ok) {
      customerPrototypes = prototypesResult.data?.customer_prototypes || [];
      if (window.AvailabilityAudit?.buildCustomerTypeLookup) {
        customerTypeLookup = window.AvailabilityAudit.buildCustomerTypeLookup(
          availabilityResult.data,
          customerPrototypes
        );
      }
    } else {
      warn("Failed to fetch customer prototypes:", prototypesResult.error);
      errors.push({
        stage: "customer_prototypes",
        message: prototypesResult.error
      });
    }

    const bookingsResult = await fetchAvailabilityBookingsApi(company, itemId, availabilityId);
    if (!bookingsResult.ok) {
      error("Failed to fetch bookings:", bookingsResult.error);
      return {
        ok: false,
        error: bookingsResult.error,
        context: resolvedContext,
        availability: availabilityResult.data,
        bookings: [],
        errors
      };
    }

    const rawBookings = bookingsResult.bookings || [];
    log(
      `Fetching full booking detail for ${rawBookings.length} bookings (concurrency: ${CONCURRENCY_LIMIT})`
    );

    const enrichedBookings = await mapWithConcurrency(
      rawBookings,
      CONCURRENCY_LIMIT,
      async (booking) => {
        const bookingUuid = booking.uuid;
        if (!bookingUuid) {
          warn(`Booking pk=${booking.pk} missing uuid, skipping full booking fetch`);
          return booking;
        }

        log(`Fetching full booking detail for pk=${booking.pk}`);
        const detailResult = await fetchBookingDetailApi(company, bookingUuid);
        if (!detailResult.ok) {
          errors.push({
            bookingPk: booking.pk,
            stage: "booking_detail",
            message: detailResult.error
          });
          warn(`Full booking fetch failed for pk=${booking.pk}:`, detailResult.error);
          return booking;
        }

        return mergeBookingDetailIntoRaw(booking, detailResult.data);
      }
    );

    log(`Fetching activities for ${enrichedBookings.length} bookings (concurrency: ${CONCURRENCY_LIMIT})`);

    const [activityResults, availabilityActivitiesResult] = await Promise.all([
      mapWithConcurrency(enrichedBookings, CONCURRENCY_LIMIT, async (booking) => {
        const bookingPk = resolveBookingPk(booking);
        if (bookingPk == null) {
          warn("Booking missing pk, skipping activities fetch. Keys:", Object.keys(booking || {}));
          return { booking, activities: [], error: "Booking missing pk" };
        }

        log("Fetching booking activities", {
          bookingPk: booking.pk,
          bookingUuid: booking.uuid
        });

        const actResult = await fetchBookingActivitiesApi(company, bookingPk);
        if (!actResult.ok) {
          errors.push({
            bookingPk,
            stage: "activities",
            message: actResult.error
          });
          logBookingActivitiesSummary(bookingPk, []);
          return { booking, activities: [], error: actResult.error };
        }

        const activities = actResult.activities || [];
        logBookingActivitiesSummary(bookingPk, activities);
        return { booking, activities, error: null };
      }),
      fetchAvailabilityActivitiesApi(company, availabilityId)
    ]);

    if (!availabilityActivitiesResult.ok) {
      warn("Failed to fetch availability activities:", availabilityActivitiesResult.error);
      errors.push({
        stage: "availability_activities",
        message: availabilityActivitiesResult.error
      });
    }

    const availabilityActivities = availabilityActivitiesResult.ok
      ? availabilityActivitiesResult.activities || []
      : [];

    const bookings = activityResults.map(({ booking, activities }) => {
      const normalized = normalizeBookingForHistoricCapacity(booking, activities);
      log("Normalized booking:", normalized);
      return normalized;
    });

    log(`Normalized ${bookings.length} bookings (${errors.length} partial errors)`);

    return {
      ok: true,
      context: resolvedContext,
      availability: availabilityResult.data,
      customerPrototypes,
      customerTypeLookup,
      bookings,
      availabilityActivities,
      errors,
      fetchedAt: new Date().toISOString()
    };
  }

  async function debugApiCapacityData(options) {
    const opts = options && typeof options === "object" ? options : {};
    const targetTimestamp = opts.targetTimestamp ?? null;

    log("debugApiCapacityData() started", targetTimestamp ? { targetTimestamp } : {});

    const result = await fetchHistoricCapacityApiData();

    if (!result.ok) {
      error("debugApiCapacityData failed:", result.error);
      return result;
    }

    if (targetTimestamp != null && targetTimestamp !== "") {
      result.snapshot = calculateHistoricCapacityFromApiData(result, targetTimestamp, {
        customerTypeLookup: result.customerTypeLookup,
        isLiveAudit: window.AvailabilityAudit?.isCurrentSnapshotAudit?.(
          new Date(targetTimestamp)
        )
      });
      if (!result.snapshot.ok) {
        result.ok = false;
        result.error = result.snapshot.error;
        error("Historic snapshot failed:", result.error);
        return result;
      }
      log("Historic snapshot full result:", result.snapshot);
      console.log(LOG_PREFIX, "Historic snapshot full result:", result.snapshot);
    }

    const tableRows = result.bookings.map((b) => {
      const filtered = result.snapshot?.filteredBookings?.find((fb) => fb.pk === b.pk);
      return {
        pk: b.pk,
        uuid: b.uuid,
        bookedAt: b.bookedAt,
        cancelledAt: b.cancelledAt,
        customerCount: b.customerCount,
        customerBreakdown: JSON.stringify(b.customerBreakdown),
        resourceReapplyCount: b.resourceReapplyEvents.length,
        snapshotReason: result.snapshot
          ? filtered
            ? filtered.snapshotReason
            : result.snapshot.skippedBookings.find((sb) => sb.pk === b.pk)?.snapshotReason || ""
          : "",
        reapplyBeforeTarget: filtered?.reapplyEventsBeforeTarget?.length ?? "",
        reapplyAfterTarget: filtered?.reapplyEventsAfterTarget?.length ?? "",
        resourceStateSource: filtered?.selectedResourceStateSource ?? ""
      };
    });

    log(`Summary: ${tableRows.length} bookings`);
    console.table(tableRows);
    log("Full structured result:", result);
    return result;
  }

  async function runAvailabilityAuditApiExperimental(targetDate, targetTime) {
    log("Experimental API path", { targetDate, targetTime });

    let targetTimestamp = null;
    if (targetDate && targetTime) {
      const targetDateTime = new Date(`${targetDate}T${targetTime}:00`);
      if (Number.isNaN(targetDateTime.getTime())) {
        return {
          ok: false,
          error: `Invalid target date/time: ${targetDate} ${targetTime}`,
          bookings: [],
          errors: []
        };
      }
      targetTimestamp = targetDateTime.toISOString();
    }

    return debugApiCapacityData({ targetTimestamp });
  }

  function normalizeDomAuditMetrics(domResult) {
    if (!domResult || !domResult.success) {
      return null;
    }

    const resourcesUsed = domResult.resourcesUsed || {};
    const hasResources =
      resourcesUsed && typeof resourcesUsed === "object" && Object.keys(resourcesUsed).length > 0;

    return {
      totalBookingsScanned: domResult.originalBookingsCount ?? 0,
      activeAtTimestamp: domResult.filteredBookingsCount ?? 0,
      skippedBookingsCount: domResult.skippedBookingsCount ?? 0,
      totalCapacityUsed: domResult.totalCapacityUsed ?? 0,
      customerTypesUsed: domResult.customerTypesUsed || {},
      resourcesUsed: hasResources ? resourcesUsed : null
    };
  }

  function normalizeApiSnapshotMetrics(apiResult) {
    const snapshot = apiResult?.snapshot;
    if (!snapshot?.ok) return null;

    const resourcesUsed = passThroughFlatResourcesUsed(snapshot?.resourcesUsed);

    return {
      totalBookingsScanned: snapshot.totalBookingsScanned ?? 0,
      activeAtTimestamp: snapshot.activeAtTimestampCount ?? 0,
      skippedBookingsCount: snapshot.skippedCount ?? 0,
      totalCapacityUsed: snapshot.totalCapacityUsed ?? 0,
      customerTypesUsed: snapshot.customerTypesUsed || {},
      resourcesUsed: Object.keys(resourcesUsed).length > 0 ? resourcesUsed : null,
      reservedCapacityUsed: snapshot.reservedCapacityUsed ?? 0
    };
  }

  function stableStringifyObject(obj) {
    if (!obj || typeof obj !== "object") return JSON.stringify(obj);
    const sorted = {};
    for (const key of Object.keys(obj).sort()) {
      sorted[key] = obj[key];
    }
    return JSON.stringify(sorted);
  }

  function compareCapacityEngineMetrics(domMetrics, apiMetrics) {
    if (!domMetrics || !apiMetrics) {
      return {
        allMatch: false,
        mismatches: [{ field: "_error", dom: domMetrics, api: apiMetrics }],
        dom: domMetrics,
        api: apiMetrics
      };
    }

    const scalarFields = [
      "totalBookingsScanned",
      "activeAtTimestamp",
      "skippedBookingsCount",
      "totalCapacityUsed"
    ];
    const mismatches = [];

    for (const field of scalarFields) {
      if (domMetrics[field] !== apiMetrics[field]) {
        mismatches.push({ field, dom: domMetrics[field], api: apiMetrics[field] });
      }
    }

    if (stableStringifyObject(domMetrics.customerTypesUsed) !== stableStringifyObject(apiMetrics.customerTypesUsed)) {
      mismatches.push({
        field: "customerTypesUsed",
        dom: domMetrics.customerTypesUsed,
        api: apiMetrics.customerTypesUsed
      });
    }

    const domHasResources = domMetrics.resourcesUsed && Object.keys(domMetrics.resourcesUsed).length > 0;
    const apiHasResources = apiMetrics.resourcesUsed && Object.keys(apiMetrics.resourcesUsed).length > 0;

    if (domHasResources && apiHasResources) {
      if (stableStringifyObject(domMetrics.resourcesUsed) !== stableStringifyObject(apiMetrics.resourcesUsed)) {
        mismatches.push({
          field: "resourcesUsed",
          dom: domMetrics.resourcesUsed,
          api: apiMetrics.resourcesUsed
        });
      }
    }

    return {
      allMatch: mismatches.length === 0,
      mismatches,
      dom: domMetrics,
      api: apiMetrics,
      resourcesCompareSkipped: !(domHasResources && apiHasResources)
    };
  }

  async function runDevCapacityCheckEngine(options) {
    const opts = options && typeof options === "object" ? options : {};
    const engine = opts.engine || "api";
    const targetDate = opts.targetDate;
    const targetTime = opts.targetTime;
    const targetTimestamp = opts.targetTimestamp ?? null;
    const fetchDetailedInfo = opts.fetchDetailedInfo === true;

    log("runDevCapacityCheckEngine", { engine, targetDate, targetTime, targetTimestamp, fetchDetailedInfo });

    if (engine === "dom") {
      if (!window.AvailabilityAudit?.runAvailabilityAudit) {
        return { ok: false, error: "DOM audit module not available", engine: "dom" };
      }
      const domResult = await window.AvailabilityAudit.runAvailabilityAudit(
        targetDate,
        targetTime,
        fetchDetailedInfo
      );
      const metrics = normalizeDomAuditMetrics(domResult);
      const result = {
        ok: domResult?.success === true,
        engine: "dom",
        domResult,
        metrics,
        error: domResult?.success ? null : domResult?.error || "DOM audit failed"
      };
      console.log(LOG_PREFIX, "Dev capacity check (DOM) full result:", result);
      return result;
    }

    if (engine === "api") {
      const apiResult = await debugApiCapacityData({ targetTimestamp });
      const metrics = normalizeApiSnapshotMetrics(apiResult);
      const result = {
        ok: apiResult?.ok === true,
        engine: "api",
        apiResult,
        metrics,
        error: apiResult?.ok ? null : apiResult?.error || "API audit failed"
      };
      console.log(LOG_PREFIX, "Dev capacity check (API) full result:", result);
      return result;
    }

    if (engine === "both") {
      if (!window.AvailabilityAudit?.runAvailabilityAudit) {
        return { ok: false, error: "DOM audit module not available", engine: "both" };
      }

      const domResult = await window.AvailabilityAudit.runAvailabilityAudit(
        targetDate,
        targetTime,
        fetchDetailedInfo
      );
      const apiResult = await debugApiCapacityData({ targetTimestamp });

      const domMetrics = normalizeDomAuditMetrics(domResult);
      const apiMetrics = normalizeApiSnapshotMetrics(apiResult);
      const comparison = compareCapacityEngineMetrics(domMetrics, apiMetrics);

      const result = {
        ok: domResult?.success === true && apiResult?.ok === true,
        engine: "both",
        domResult,
        apiResult,
        domMetrics,
        apiMetrics,
        comparison,
        error:
          domResult?.success && apiResult?.ok
            ? null
            : [domResult?.error, apiResult?.error].filter(Boolean).join("; ") || "Compare run failed"
      };

      console.log(LOG_PREFIX, "Dev capacity check (compare) full result:", result);
      console.log(LOG_PREFIX, "Dev capacity check comparison:", comparison);
      return result;
    }

    return { ok: false, error: `Unknown engine: ${engine}`, engine };
  }

  function mapApiBookingToDisplayBooking(apiBooking) {
    if (!apiBooking) return null;
    return {
      pk: apiBooking.pk ?? apiBooking.index ?? null,
      bookingNumber: apiBooking.bookingNumber ?? apiBooking.pk,
      partySize: apiBooking.customerCount ?? apiBooking.partySize ?? 0,
      customerTypes: (apiBooking.customerTypes || []).map((ct) => ({
        name: ct.name,
        quantity: ct.quantity || 0
      })),
      resourceUsesAtTimestamp: (apiBooking.resourceUsesAtTimestamp || []).map((use) => ({
        resourceId: use.resourceId ?? null,
        resourceName: use.resourceName,
        quantity: use.quantity || 0
      })),
      isCancelled: apiBooking.isCurrentlyCancelled ?? apiBooking.isCancelled ?? false,
      datetime: apiBooking.bookedAt,
      bookedAt: apiBooking.bookedAt,
      cancelledAt: apiBooking.cancelledAt,
      reason: apiBooking.snapshotReason || apiBooking.reason,
      bookingHref: apiBooking.bookingHref || null,
      hasHref: Boolean(apiBooking.bookingHref),
      index: apiBooking.pk,
      resources: apiBooking.resources ?? null,
      detailedInfo: apiBooking.detailedInfo ?? null
    };
  }

  function logCapacityResultBeforeRender(result) {
    console.log("[capacity-api] result.resourcesUsed before render", result.resourcesUsed);
    assertFlatResourcesUsedInvariants(
      result.resourcesUsed,
      "result.resourcesUsed before render"
    );
  }

  function buildPageContextFromApiContext(apiContext) {
    const ctx = apiContext || parseFareHarborApiContextFromPage();
    let availabilityId = "unknown";
    if (ctx.itemId && ctx.availabilityId) {
      availabilityId = `${ctx.itemId}-${ctx.availabilityId}`;
    } else if (ctx.itemId) {
      availabilityId = String(ctx.itemId);
    }

    let availabilityName = (document.title || "").trim();
    availabilityName = availabilityName.replace(/\s*\|\s*FareHarbor.*$/i, "").trim();
    if (!availabilityName || availabilityName.length < 2) {
      availabilityName =
        ctx.itemId && ctx.availabilityId
          ? `Item ${ctx.itemId} · availability ${ctx.availabilityId}`
          : "Availability";
    }

    return { availabilityId, availabilityName };
  }

  function convertApiSnapshotToAuditSummary(apiResult, targetDate, targetTime, fetchDetailedInfo) {
    const snapshot = apiResult.snapshot;
    const targetDateTime = snapshot.targetTimestamp
      ? new Date(snapshot.targetTimestamp)
      : new Date(`${targetDate}T${targetTime}:00`);

    const filteredBookings = (snapshot.filteredBookings || [])
      .map(mapApiBookingToDisplayBooking)
      .filter(Boolean);
    const skippedBookings = (snapshot.skippedBookings || [])
      .map(mapApiBookingToDisplayBooking)
      .filter(Boolean);

    const resourcesUsed = passThroughFlatResourcesUsed(snapshot.resourcesUsed);
    console.log("[capacity-api] result.resourcesUsed before adapter", resourcesUsed);
    assertFlatResourcesUsedInvariants(resourcesUsed, "result.resourcesUsed before adapter");

    const hasResources = resourcesUsed && Object.keys(resourcesUsed).length > 0;

    const serializeLookup =
      window.AvailabilityAudit?.serializeCustomerTypeLookupForExport;
    const customerTypeLookupEntries = serializeLookup
      ? serializeLookup(apiResult.customerTypeLookup)
      : [];

    return {
      filteredBookings,
      skippedBookings,
      totalCapacityUsed: snapshot.totalCapacityUsed ?? 0,
      resourcesUsed,
      customerTypesUsed: snapshot.customerTypesUsed || {},
      customerTypesUsedDetailed: snapshot.customerTypesUsedDetailed || null,
      customerTypeLookupEntries,
      resourcesUsedByCustomerType: snapshot.resourcesUsedByCustomerType || {},
      targetDateTime,
      originalBookingsCount: snapshot.totalBookingsScanned ?? 0,
      filteredBookingsCount: snapshot.activeAtTimestampCount ?? filteredBookings.length,
      skippedBookingsCount: snapshot.skippedCount ?? skippedBookings.length,
      detailedInfoFetched: hasResources || fetchDetailedInfo === true,
      pageContext: buildPageContextFromApiContext(apiResult.context),
      reservationHolds: snapshot.reservationHolds || [],
      reservationHoldCount: snapshot.reservationHoldCount ?? (snapshot.reservationHolds?.length || 0),
      activeReservationHolds: snapshot.activeReservationHolds || [],
      activeReservationHoldCount:
        snapshot.activeReservationHoldCount ?? (snapshot.activeReservationHolds?.length || 0),
      reservedCapacityUsed: snapshot.reservedCapacityUsed ?? 0
    };
  }

  async function runAvailabilityAuditApiFirst(targetDate, targetTime, fetchDetailedInfo = false) {
    let targetTimestamp = null;
    if (targetDate && targetTime) {
      const targetDateTime = new Date(`${targetDate}T${targetTime}:00`);
      if (Number.isNaN(targetDateTime.getTime())) {
        return {
          success: false,
          error: `Invalid target date/time: ${targetDate} ${targetTime}`,
          engine: "api"
        };
      }
      targetTimestamp = targetDateTime.toISOString();
    }

    let apiError = null;

    try {
      log("runAvailabilityAuditApiFirst: trying API engine", {
        targetDate,
        targetTime,
        targetTimestamp,
        fetchDetailedInfo
      });

      const apiResult = await debugApiCapacityData({ targetTimestamp });
      if (apiResult?.ok === true && apiResult?.snapshot?.ok === true) {
        const auditSummary = convertApiSnapshotToAuditSummary(
          apiResult,
          targetDate,
          targetTime,
          fetchDetailedInfo
        );
        const result = {
          success: true,
          ...auditSummary,
          engine: "api",
          apiSource: true
        };
        logCapacityResultBeforeRender(result);
        log("runAvailabilityAuditApiFirst: API engine succeeded", result);
        return result;
      }

      apiError =
        apiResult?.snapshot?.error ||
        apiResult?.error ||
        "API capacity check failed";
      warn("runAvailabilityAuditApiFirst: API failed, falling back to DOM:", apiError);
    } catch (err) {
      apiError = err?.message || String(err);
      error("runAvailabilityAuditApiFirst: API threw, falling back to DOM:", err);
    }

    if (!window.AvailabilityAudit?.runAvailabilityAudit) {
      return {
        success: false,
        error: apiError
          ? `API failed (${apiError}) and DOM audit module is not available`
          : "DOM audit module is not available",
        engine: "dom",
        apiSource: false,
        fallbackWarning: apiError ? `API failed: ${apiError}` : null
      };
    }

    log("runAvailabilityAuditApiFirst: running DOM fallback");
    const domResult = await window.AvailabilityAudit.runAvailabilityAudit(
      targetDate,
      targetTime,
      fetchDetailedInfo
    );

    if (domResult?.success === true) {
      return {
        ...domResult,
        engine: "dom",
        apiSource: false,
        fallbackWarning: apiError
          ? `API capacity check failed; showing DOM results instead. (${apiError})`
          : null
      };
    }

    return {
      ...domResult,
      success: false,
      engine: "dom",
      apiSource: false,
      fallbackWarning: apiError
        ? `API failed (${apiError}); DOM check also failed.`
        : domResult?.error || null
    };
  }

  const INSPECT_MAX_WALK_DEPTH = 14;

  function findObjectsByCls(root, clsName, maxDepth) {
    const limit = maxDepth ?? INSPECT_MAX_WALK_DEPTH;
    const found = [];
    const seen = new WeakSet();

    function walk(node, depth) {
      if (node == null || depth > limit) return;
      if (typeof node !== "object") return;
      if (seen.has(node)) return;
      seen.add(node);

      if (node.cls === clsName) {
        found.push(node);
      }

      if (Array.isArray(node)) {
        for (const item of node) walk(item, depth + 1);
        return;
      }

      for (const value of Object.values(node)) {
        walk(value, depth + 1);
      }
    }

    walk(root, 0);
    return found;
  }

  function findResourceRelatedKeyPaths(root, maxDepth) {
    const limit = maxDepth ?? INSPECT_MAX_WALK_DEPTH;
    const paths = [];
    const seen = new WeakSet();

    function walk(node, path, depth) {
      if (node == null || depth > limit) return;
      if (typeof node !== "object") return;
      if (seen.has(node)) return;
      seen.add(node);

      if (Array.isArray(node)) {
        node.forEach((item, index) => walk(item, `${path}[${index}]`, depth + 1));
        return;
      }

      for (const [key, value] of Object.entries(node)) {
        const keyPath = path ? `${path}.${key}` : key;
        if (/resource/i.test(key)) {
          paths.push(keyPath);
        }
        walk(value, keyPath, depth + 1);
      }
    }

    walk(root, "", 0);
    return paths;
  }

  function collectResourceNamesFromInspection(resourceUseObjects, resourceObjects) {
    const names = new Set();

    for (const use of resourceUseObjects || []) {
      const name =
        use.resource_requirement?.resource?.name ??
        use.resource?.name ??
        use.name ??
        use.display_name ??
        null;
      if (name) names.add(String(name));
    }

    for (const resource of resourceObjects || []) {
      if (resource?.name) names.add(String(resource.name));
      if (resource?.display_name) names.add(String(resource.display_name));
    }

    return [...names];
  }

  function analyzePayloadForResourceInspection(payload, meta) {
    const sourceLabel = meta?.sourceLabel || "unknown";
    const fetchMeta = meta?.fetch || {};

    if (payload == null) {
      return {
        sourceLabel,
        fetchOk: fetchMeta.ok === true,
        fetchStatus: fetchMeta.status ?? null,
        fetchError: fetchMeta.error ?? null,
        bookingPk: null,
        bookingUuid: null,
        customer_breakdown: null,
        topLevelKeys: [],
        resourceRelatedKeys: [],
        resourceUseObjects: [],
        resourceObjects: [],
        resourceUseCount: 0,
        resourceNames: []
      };
    }

    const resourceUseObjects = findObjectsByCls(payload, "ResourceUse");
    const resourceObjects = findObjectsByCls(payload, "Resource");

    return {
      sourceLabel,
      fetchOk: fetchMeta.ok !== false,
      fetchStatus: fetchMeta.status ?? null,
      fetchError: fetchMeta.error ?? null,
      bookingPk: payload.pk ?? null,
      bookingUuid: payload.uuid ?? null,
      customer_breakdown:
        payload.customer_breakdown ?? payload.customer_breakdown_short ?? null,
      topLevelKeys: Array.isArray(payload) ? ["(root array)"] : Object.keys(payload),
      resourceRelatedKeys: findResourceRelatedKeyPaths(payload),
      resourceUseObjects,
      resourceObjects,
      resourceUseCount: resourceUseObjects.length,
      resourceNames: collectResourceNamesFromInspection(resourceUseObjects, resourceObjects)
    };
  }

  function filterNormalizedBookingsAtTimestamp(normalizedBookings, targetTimestamp) {
    const targetMs = toTimestampMs(targetTimestamp);
    if (targetMs == null) {
      return { ok: false, error: "Invalid target timestamp", filtered: [] };
    }

    const filtered = [];
    for (const booking of normalizedBookings || []) {
      const bookedAtMs = toTimestampMs(booking.bookedAt);
      const cancelledAtMs = toTimestampMs(booking.cancelledAt);

      if (bookedAtMs == null || bookedAtMs > targetMs) continue;
      if (cancelledAtMs != null && cancelledAtMs <= targetMs) continue;

      filtered.push(booking);
    }

    return { ok: true, targetTimestamp: new Date(targetMs).toISOString(), filtered };
  }

  function buildReapplyHistoryForInspection(booking) {
    return (booking.resourceReapplyEvents || []).map((event) => ({
      createdAt: event.createdAt,
      originalResourceUseCount: event.originalResourceUses?.length ?? 0,
      updatedResourceUseCount: event.updatedResourceUses?.length ?? 0,
      originalResourceNames: (event.originalResourceUses || [])
        .map((use) => use.resource_requirement?.resource?.name ?? use.resource?.name ?? null)
        .filter(Boolean),
      updatedResourceNames: (event.updatedResourceUses || [])
        .map((use) => use.resource_requirement?.resource?.name ?? use.resource?.name ?? null)
        .filter(Boolean)
    }));
  }

  function formatResourceInspectionSourceBlock(analysis) {
    const lines = [];
    lines.push(`--- ${analysis.sourceLabel} ---`);
    lines.push(`fetch ok: ${analysis.fetchOk}${analysis.fetchStatus != null ? ` (HTTP ${analysis.fetchStatus})` : ""}`);
    if (analysis.fetchError) lines.push(`fetch error: ${analysis.fetchError}`);
    lines.push(`booking pk: ${analysis.bookingPk ?? "n/a"}`);
    lines.push(`booking uuid: ${analysis.bookingUuid ?? "n/a"}`);
    lines.push(`customer_breakdown: ${JSON.stringify(analysis.customer_breakdown)}`);
    lines.push(`top-level keys: ${analysis.topLevelKeys.join(", ") || "n/a"}`);
    lines.push(`resource-related keys (${analysis.resourceRelatedKeys.length}):`);
    for (const keyPath of analysis.resourceRelatedKeys) {
      lines.push(`  ${keyPath}`);
    }
    lines.push(`ResourceUse count: ${analysis.resourceUseCount}`);
    lines.push(`Resource count (cls=Resource): ${analysis.resourceObjects.length}`);
    lines.push(`resource names found: ${analysis.resourceNames.join(", ") || "n/a"}`);
    if (analysis.resourceUseObjects.length > 0) {
      lines.push("ResourceUse objects:");
      analysis.resourceUseObjects.forEach((use, index) => {
        lines.push(`  [${index}] ${JSON.stringify(use, null, 2).split("\n").join("\n  ")}`);
      });
    }
    if (analysis.resourceObjects.length > 0) {
      lines.push("Resource objects:");
      analysis.resourceObjects.forEach((resource, index) => {
        lines.push(`  [${index}] ${JSON.stringify(resource, null, 2).split("\n").join("\n  ")}`);
      });
    }
    return lines.join("\n");
  }

  function formatResourceInspectionBookingBlock(bookingInspection) {
    const lines = [];
    lines.push(`========== Booking pk=${bookingInspection.bookingPk} uuid=${bookingInspection.bookingUuid} ==========`);
    lines.push(`customer_breakdown (normalized): ${JSON.stringify(bookingInspection.customerBreakdown)}`);
    lines.push(`parsedCustomerTypes: ${JSON.stringify(bookingInspection.parsedCustomerTypes)}`);
    lines.push("");
    lines.push(formatResourceInspectionSourceBlock(bookingInspection.sources.availabilityListEntry));
    lines.push("");
    lines.push(formatResourceInspectionSourceBlock(bookingInspection.sources.fullBooking));
    lines.push("");
    lines.push(formatResourceInspectionSourceBlock(bookingInspection.sources.resourceUsesEndpoint));
    lines.push("");
    lines.push("--- reapply history (activities only, not used for current resource selection) ---");
    if (bookingInspection.reapplyHistoryOnly.length === 0) {
      lines.push("(none)");
    } else {
      bookingInspection.reapplyHistoryOnly.forEach((event, index) => {
        lines.push(`  [${index}] ${JSON.stringify(event)}`);
      });
    }
    return lines.join("\n");
  }

  function formatResourceInspectionSummary(result) {
    if (!result?.ok) {
      return `Error: ${result?.error || "Inspection failed"}`;
    }

    const lines = [];
    lines.push("Dev: Inspect API Resource Sources");
    lines.push(`targetTimestamp: ${result.targetTimestamp}`);
    lines.push(`active bookings inspected: ${result.bookings.length}`);
    lines.push(`Full raw payloads logged to console with prefix ${LOG_PREFIX}`);
    lines.push("");

    for (const bookingInspection of result.bookings) {
      lines.push(formatResourceInspectionBookingBlock(bookingInspection));
      lines.push("");
    }

    return lines.join("\n");
  }

  async function inspectApiResourceSources(options) {
    const opts = options && typeof options === "object" ? options : {};
    const targetTimestamp = opts.targetTimestamp ?? null;

    if (targetTimestamp == null || targetTimestamp === "") {
      return { ok: false, error: "targetTimestamp is required for inspection" };
    }

    log("inspectApiResourceSources() started", { targetTimestamp });

    const resolvedContext = parseFareHarborApiContextFromPage();
    const contextError = validateContext(resolvedContext);
    if (contextError) {
      return { ok: false, error: contextError, context: resolvedContext };
    }

    const { company, itemId, availabilityId } = resolvedContext;

    const bookingsResult = await fetchAvailabilityBookingsApi(company, itemId, availabilityId);
    if (!bookingsResult.ok) {
      return { ok: false, error: bookingsResult.error, context: resolvedContext };
    }

    const rawBookings = bookingsResult.bookings || [];
    const listEntryByPk = new Map();
    for (const booking of rawBookings) {
      if (booking?.pk != null) listEntryByPk.set(booking.pk, booking);
    }

    log(`Inspecting resource sources for ${rawBookings.length} list bookings`);

    const normalizedBookings = await mapWithConcurrency(
      rawBookings,
      CONCURRENCY_LIMIT,
      async (booking) => {
        const bookingPk = resolveBookingPk(booking);
        if (bookingPk == null) {
          return normalizeBookingForHistoricCapacity(booking, []);
        }
        const actResult = await fetchBookingActivitiesApi(company, bookingPk);
        return normalizeBookingForHistoricCapacity(booking, actResult.activities || []);
      }
    );

    const filterResult = filterNormalizedBookingsAtTimestamp(normalizedBookings, targetTimestamp);
    if (!filterResult.ok) {
      return { ok: false, error: filterResult.error, context: resolvedContext };
    }

    const inspections = [];

    for (const booking of filterResult.filtered) {
      const listEntry = listEntryByPk.get(booking.pk) || null;
      const detailResult = await fetchBookingDetailApi(company, booking.uuid);
      const resourceUsesResult = await fetchBookingResourceUsesApi(company, booking.uuid);

      const availabilityListEntryAnalysis = analyzePayloadForResourceInspection(listEntry, {
        sourceLabel: "availability_list_entry",
        fetch: { ok: listEntry != null, status: listEntry ? 200 : null, error: listEntry ? null : "missing list entry" }
      });
      const fullBookingAnalysis = analyzePayloadForResourceInspection(detailResult.data, {
        sourceLabel: "full_booking",
        fetch: detailResult
      });
      const resourceUsesEndpointAnalysis = analyzePayloadForResourceInspection(resourceUsesResult.data, {
        sourceLabel: "resource_uses_endpoint",
        fetch: resourceUsesResult
      });

      const bookingInspection = {
        bookingPk: booking.pk,
        bookingUuid: booking.uuid,
        customerBreakdown: booking.customerBreakdown,
        parsedCustomerTypes: booking.customerTypes,
        reapplyHistoryOnly: buildReapplyHistoryForInspection(booking),
        sources: {
          availabilityListEntry: availabilityListEntryAnalysis,
          fullBooking: fullBookingAnalysis,
          resourceUsesEndpoint: resourceUsesEndpointAnalysis
        }
      };

      console.log(LOG_PREFIX, "RAW availability_list_entry", listEntry);
      console.log(LOG_PREFIX, "RAW full_booking", detailResult.data);
      console.log(LOG_PREFIX, "RAW resource_uses_endpoint", resourceUsesResult.data);
      console.log(LOG_PREFIX, "API resource source inspection booking", bookingInspection);

      inspections.push(bookingInspection);
    }

    const result = {
      ok: true,
      context: resolvedContext,
      targetTimestamp: filterResult.targetTimestamp,
      bookings: inspections,
      summaryText: formatResourceInspectionSummary({
        ok: true,
        targetTimestamp: filterResult.targetTimestamp,
        bookings: inspections
      })
    };

    console.log(LOG_PREFIX, "API resource source inspection complete:", result);
    return result;
  }

  Object.assign(window.AvailabilityAudit, {
    parseFareHarborApiContextFromPage,
    fhApiFetchJson,
    fetchAvailabilityApi,
    fetchAvailabilityBookingsApi,
    fetchAvailabilityActivitiesApi,
    fetchBookingActivitiesApi,
    normalizeBookingForHistoricCapacity,
    calculateHistoricCapacityFromApiData,
    normalizeDomAuditMetrics,
    normalizeApiSnapshotMetrics,
    compareCapacityEngineMetrics,
    runDevCapacityCheckEngine,
    runAvailabilityAuditApiFirst,
    debugApiCapacityData,
    inspectApiResourceSources,
    runAvailabilityAuditApiExperimental,
    reservationHoldTestExports: {
      extractReservationHoldActivities,
      buildAllReservationHolds,
      parseReservationCustomerBreakdown,
      getActiveReservationHoldsFromAll,
      classifyReservationHoldStatusAtTimestamp,
      summarizeHoldStatusBreakdown,
      mergeReservationHoldsIntoCustomerTypeTotals,
      buildFulfilledBookingPkSet,
      parseHoldDurationMinutes,
      toTimestampMs
    }
  });

  log("API module attached to window.AvailabilityAudit");
})();
