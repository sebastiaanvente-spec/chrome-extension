console.log("[fareharbor-reseller-items] fareharbor-reseller-items.js loaded");

// Wait for utilities to be available and initialize module
(function initializeFareHarborResellerItems() {
  // Wait for FareHarborUtils to be available
  if (!window.FareHarborUtils) {
    setTimeout(initializeFareHarborResellerItems, 10);
    return;
  }
  
  // Now utilities are available, set up the module
  const utils = window.FareHarborUtils;
  const trimItemDisplayText = (text) => utils.trimFareHarborItemDisplayText(text);

  const RESELLER_CHANNEL_ITEM_PATH_RE = /\/integrations\/channels\/(\d+)\/items\/(\d+)/;

  function parseCompanyShortnameFromPathname(pathname) {
    const parts = String(pathname || "").split("/").filter(Boolean);
    return parts[0] || null;
  }

  function resolveAbsoluteUrl(href) {
    if (!href) return null;
    const trimmed = String(href).trim();
    if (!trimmed || trimmed.startsWith("{{")) return null;
    if (/^https?:\/\//i.test(trimmed)) return trimmed;
    if (trimmed.startsWith("/")) return `${window.location.origin}${trimmed}`;
    return `${window.location.origin}/${trimmed}`;
  }

  function extractResellerItemContextFromTbody(tbody) {
    const links = tbody.querySelectorAll("a[href], a[ng-href]");
    for (const link of links) {
      const rawHref = link.getAttribute("href") || link.getAttribute("ng-href") || "";
      const match = String(rawHref).match(RESELLER_CHANNEL_ITEM_PATH_RE);
      if (!match) continue;

      const absoluteUrl = resolveAbsoluteUrl(rawHref);
      let company = null;
      const pathnameSource = absoluteUrl || rawHref;
      try {
        company = parseCompanyShortnameFromPathname(
          absoluteUrl ? new URL(absoluteUrl).pathname : pathnameSource.split("?")[0].split("#")[0]
        );
      } catch {
        company = parseCompanyShortnameFromPathname(pathnameSource);
      }

      return {
        company,
        resellerCompanyId: match[1],
        resellerItemId: match[2],
        resellerItemUrl: absoluteUrl || rawHref,
        enrichmentPageUrl: absoluteUrl || rawHref
      };
    }
    return null;
  }

  // Function to extract channel name from h1 element
  function extractChannelName() {
    // Look for the h1 element with the channel name - try multiple selectors
    // First try: specific class that contains 'test-header-reseller-item'
    let h1Element = document.querySelector('h1[class*="test-header-reseller-item"]');
    if (h1Element) {
      return h1Element.textContent.trim();
    }
    
    // Second try: any h1 in the settings window header tabs
    h1Element = document.querySelector('.settings-window-header-tabs h1');
    if (h1Element) {
      return h1Element.textContent.trim();
    }
    
    // Third try: more generic - any h1 in the settings header area
    h1Element = document.querySelector('.settings-window-header h1');
    if (h1Element) {
      return h1Element.textContent.trim();
    }
    
    return null;
  }
  
  // Function to extract ID from item name
  function extractIdFromItemName(itemName) {
    // Try format with "ID:" prefix first (e.g., "Name (ID: 76748)")
    let match = itemName.match(/\(ID:\s*(\d+)\)/);
    if (match) {
      return `(ID: ${match[1]})`;
    }
    
    // Try format without "ID:" prefix (e.g., "Name (76748)")
    match = itemName.match(/\((\d+)\)/);
    if (match) {
      return `(ID: ${match[1]})`;
    }
    
    return '';
  }
  
  // Function to create appropriate item label based on toggle state
  function createItemLabel(originalItemName, useChannelName) {
    if (!useChannelName) {
      return originalItemName;
    }
    
    const channelName = extractChannelName();
    const idPart = extractIdFromItemName(originalItemName);
    
    if (channelName && idPart) {
      return `${channelName} ${idPart}`;
    }
    
    // Fallback to original name if we can't extract channel name
    return originalItemName;
  }
  
  // Function to extract channel name from complete mapping table row
  function extractChannelNameFromTableRow(tbody) {
    const firstCell = tbody.querySelector('td:first-child');
    if (firstCell) {
      return firstCell.textContent.trim();
    }
    return null;
  }
  
  // Function to reorder customer types according to GetYourGuide priority
  function reorderCustomerTypes(customerTypes) {
    if (!customerTypes || customerTypes.length === 0) {
      return customerTypes;
    }
    
    // Define the priority order (case-insensitive)
    const priorityOrder = [
      'Adult',
      'Child', 
      'Youth',
      'Infant',
      'Senior',
      'Student',
      'EU Citizen',
      'EU Citizen Student',
      'Military',
      'Group'
    ];
    
    // Convert priority order to lowercase for case-insensitive comparison
    const priorityOrderLower = priorityOrder.map(type => type.toLowerCase());
    
    // Separate known and unknown customer types
    const knownTypes = [];
    const unknownTypes = [];
    
    customerTypes.forEach(customerType => {
      const lowerCaseType = customerType.toLowerCase();
      const priorityIndex = priorityOrderLower.indexOf(lowerCaseType);
      
      if (priorityIndex !== -1) {
        // Known type - store with its priority index and original case
        knownTypes.push({
          original: customerType,
          priority: priorityIndex
        });
      } else {
        // Unknown type - will be sorted alphabetically
        unknownTypes.push(customerType);
      }
    });
    
    // Sort known types by priority order
    knownTypes.sort((a, b) => a.priority - b.priority);
    
    // Sort unknown types alphabetically (case-insensitive)
    unknownTypes.sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));
    
    // Combine known types (in priority order) + unknown types (alphabetically)
    const reorderedTypes = [
      ...knownTypes.map(item => item.original),
      ...unknownTypes
    ];
    
    console.log(`[fareharbor-reseller-items] Reordered customer types: [${customerTypes.join(', ')}] -> [${reorderedTypes.join(', ')}]`);
    
    return reorderedTypes;
  }

  function reorderMappedCustomerTypes(mappedCustomerTypes) {
    if (!mappedCustomerTypes || mappedCustomerTypes.length === 0) {
      return mappedCustomerTypes;
    }
    const names = mappedCustomerTypes.map((entry) => entry.displayName).filter(Boolean);
    const reorderedNames = reorderCustomerTypes(names);
    const byName = new Map();
    mappedCustomerTypes.forEach((entry) => {
      if (entry.displayName && !byName.has(entry.displayName)) {
        byName.set(entry.displayName, entry);
      }
    });
    return reorderedNames.map((name) => byName.get(name)).filter(Boolean);
  }

  function extractExternalIdFromText(text) {
    const trimmed = String(text || "").trim();
    if (trimmed.startsWith("rct")) {
      return trimmed;
    }
    const match = trimmed.match(/\brct\S+/i);
    return match ? match[0] : "";
  }

  function extractMappedCustomerTypesFromSpans(spans) {
    return Array.from(spans)
      .filter((span) => {
        const textContent = span.textContent.trim();
        return textContent.startsWith("rct");
      })
      .map((span) => ({
        externalId: span.textContent.trim(),
        displayName: (span.getAttribute("ng-tip") || "").trim()
      }))
      .filter((entry) => entry.displayName || entry.externalId);
  }

  function extractMappedCustomerTypesFromTableRow(row) {
    const tds = row.querySelectorAll("td");
    if (!tds.length) {
      return null;
    }

    const displayName = tds[0]?.textContent?.trim() || "";
    let externalId = "";

    for (let i = 1; i < tds.length; i += 1) {
      const cellText = tds[i]?.textContent?.trim() || "";
      const found = extractExternalIdFromText(cellText);
      if (found) {
        externalId = found;
        break;
      }
    }

    if (!externalId) {
      const rctSpan = row.querySelector("span.text-link");
      if (rctSpan) {
        externalId = extractExternalIdFromText(rctSpan.textContent.trim());
      }
    }

    if (!displayName && !externalId) {
      return null;
    }

    return { displayName, externalId };
  }
  
  // Function to create appropriate item label for complete mapping based on toggle state
  function createItemLabelForCompleteMapping(originalItemName, tbody, useChannelName) {
    if (!useChannelName) {
      return originalItemName;
    }
    
    const channelName = extractChannelNameFromTableRow(tbody);
    const idPart = extractIdFromItemName(originalItemName);
    
    if (channelName && idPart) {
      return `${channelName} ${idPart}`;
    }
    
    // Fallback to original name if we can't extract channel name
    return originalItemName;
  }

  // Per-row extraction: given a tbody, returns array of result objects (one per channel option, or one row if none).
  function extractRowData(tbody, index, useChannelName) {
    const rowResults = [];
    try {
      // Extract Element 1: Item label with number and clickable link
      let itemLink = tbody.querySelector('td:nth-child(4) a[aria-label]');
      if (!itemLink) {
        itemLink = tbody.querySelector('td.prose.prose--compact a[ng-tip]');
      }
      if (!itemLink) {
        itemLink = tbody.querySelector('td a[ng-tip]');
      }
      if (!itemLink) {
        itemLink = tbody.querySelector('td a[aria-label]');
      }
      if (!itemLink) {
        itemLink = tbody.querySelector('a[ng-tip]');
      }
      if (!itemLink) {
        itemLink = tbody.querySelector('a[aria-label]');
      }

      let itemLabel = '';
      let itemLinkHTML = '';

      if (itemLink) {
        const ariaLabel = itemLink.getAttribute('aria-label');
        if (ariaLabel) {
          itemLabel = trimItemDisplayText(ariaLabel);
        } else {
          const ngTip = itemLink.getAttribute('ng-tip') || '';
          const textContent = itemLink.textContent.trim();
          itemLabel = textContent ? `${ngTip} (${textContent})` : ngTip;
          itemLabel = trimItemDisplayText(itemLabel);
        }

        const href = itemLink.getAttribute('href') || itemLink.getAttribute('ng-href');
        if (href && href.startsWith('/')) {
          const baseUrl = window.location.origin;
          const absoluteUrl = baseUrl + href;
          const clonedLink = itemLink.cloneNode(true);
          clonedLink.setAttribute('href', absoluteUrl);
          clonedLink.textContent = itemLabel;
          itemLinkHTML = clonedLink.outerHTML;
        } else {
          const clonedLink = itemLink.cloneNode(true);
          clonedLink.textContent = itemLabel;
          itemLinkHTML = clonedLink.outerHTML;
        }
      }

      const finalItemLabel = createItemLabelForCompleteMapping(itemLabel, tbody, useChannelName);

      if (itemLinkHTML) {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = itemLinkHTML;
        const linkElement = tempDiv.querySelector('a');
        if (linkElement) {
          linkElement.textContent = finalItemLabel;
          itemLinkHTML = linkElement.outerHTML;
        }
      }

      // Extract Element 2: Channel option content from <span> (ro codes) in 6th column
      let channelOptionSpans = tbody.querySelectorAll('td:nth-child(6) span.text-link');
      if (channelOptionSpans.length === 0) {
        channelOptionSpans = tbody.querySelectorAll('td:nth-child(6) span.text-link.ng-binding');
      }
      if (channelOptionSpans.length === 0) {
        channelOptionSpans = tbody.querySelectorAll('td span.text-link.ng-binding');
      }
      if (channelOptionSpans.length === 0) {
        channelOptionSpans = tbody.querySelectorAll('td span.text-link');
      }
      if (channelOptionSpans.length === 0) {
        channelOptionSpans = tbody.querySelectorAll('span.text-link.ng-binding');
      }

      const channelOptions = Array.from(channelOptionSpans)
        .map(span => span.textContent.trim())
        .filter(text => text && text.startsWith('ro'));

      // Extract Element 3: Customer type ng-tip from <span> (customer type names) in 5th column
      let customerTypeSpans = tbody.querySelectorAll('td:nth-child(5) span.text-link[ng-tip]');
      if (customerTypeSpans.length === 0) {
        customerTypeSpans = tbody.querySelectorAll('td:nth-child(5) span.text-link.ng-binding[ng-tip]');
      }
      if (customerTypeSpans.length === 0) {
        customerTypeSpans = tbody.querySelectorAll('td span[ng-tip]');
      }
      if (customerTypeSpans.length === 0) {
        customerTypeSpans = tbody.querySelectorAll('span[ng-tip]');
      }

      const mappedCustomerTypes = reorderMappedCustomerTypes(
        extractMappedCustomerTypesFromSpans(customerTypeSpans)
      );
      const customerTypes = mappedCustomerTypes.map((entry) => entry.displayName).filter(Boolean);
      const itemId = extractIdNumber(finalItemLabel);

      const resellerItemContext = extractResellerItemContextFromTbody(tbody);
      if (resellerItemContext) {
        console.log(
          "[fareharbor-reseller-items] Complete mapping row captured reseller item URL/context:",
          resellerItemContext
        );
      }

      const baseRowFields = {
        itemLabel: finalItemLabel,
        itemLabelHTML: itemLinkHTML,
        itemId,
        mappedCustomerTypes,
        ...(resellerItemContext || {})
      };

      if (channelOptions.length > 0) {
        channelOptions.forEach(channelOption => {
          const combinedCustomerTypes = customerTypes.length > 0 ? customerTypes.join('\n') : '';
          rowResults.push({
            channelOption: channelOption,
            customerType: combinedCustomerTypes,
            ...baseRowFields
          });
        });
      } else if (customerTypes.length > 0) {
        const combinedCustomerTypes = customerTypes.join('\n');
        rowResults.push({
          channelOption: '',
          customerType: combinedCustomerTypes,
          ...baseRowFields
        });
      } else {
        rowResults.push({
          channelOption: '',
          customerType: '',
          ...baseRowFields
        });
      }
    } catch (error) {
      console.error(`[fareharbor-reseller-items] Error processing reseller item ${index + 1}:`, error);
    }
    return rowResults;
  }

  // Expand "Channel Options" column if "+ N more" is visible in the 6th column; returns Promise that resolves after delay if clicked.
  function expandOptionsColumnIfNeeded(tbody) {
    const optionsTd = tbody.querySelector('td:nth-child(6)');
    if (!optionsTd) return Promise.resolve();
    const button = optionsTd.querySelector('button.text-link');
    if (!button || !button.textContent.includes('more')) return Promise.resolve();
    if (button.classList.contains('ng-hide')) return Promise.resolve();
    button.click();
    return new Promise(resolve => setTimeout(resolve, 180));
  }

  // FareHarbor reseller items data extraction functions
  function scrapeResellerItems(useChannelName = false) {
    const result = [];
    
    console.log("[fareharbor-reseller-items] Starting to scrape reseller items...");
    
    // Find the reseller items table with multiple fallback selectors
    let resellerTable = null;
    
    // Try multiple selectors to handle different environments
    const tableSelectors = [
      'table.spreadsheet.highlight-rows.white-bg.m-t-0.ng-scope[ng-if="resellerItems.length"]', // Original demo selector
      'table.spreadsheet.highlight-rows.white-bg[ng-if="resellerItems.length"]', // Without m-t-0
      'table.spreadsheet[ng-if="resellerItems.length"]', // More generic
      'table.spreadsheet.highlight-rows', // Even more generic
      'table.spreadsheet', // Most generic
      'table[ng-table="resellerItems"]' // Alternative ng-table attribute
    ];
    
    for (const selector of tableSelectors) {
      resellerTable = document.querySelector(selector);
      if (resellerTable) {
        console.log(`[fareharbor-reseller-items] Found table using selector: "${selector}"`);
        break;
      }
    }
    
    if (!resellerTable) {
      // Debug: Show what tables are available
      console.warn("[fareharbor-reseller-items] No reseller items table found with any selector");
      const allTables = document.querySelectorAll('table');
      console.log(`[fareharbor-reseller-items] Found ${allTables.length} table(s) on page:`);
      allTables.forEach((table, index) => {
        console.log(`[fareharbor-reseller-items] Table ${index + 1}:`, table.className, table.getAttribute('ng-if'), table.getAttribute('ng-table'));
      });
      return null;
    }
    
    console.log("[fareharbor-reseller-items] Found reseller items table");
    
    // Find all tbody elements (each represents one reseller item row)
    let tbodyElements = resellerTable.querySelectorAll('tbody[ng-repeat="resellerItem in $table.collection"]');
    
    // If no tbody elements found with the specific ng-repeat, try more generic selectors
    if (tbodyElements.length === 0) {
      console.log("[fareharbor-reseller-items] No tbody with ng-repeat found, trying alternative selectors...");
      
      // Try other possible tbody selectors
      const tbodySelectors = [
        'tbody[ng-repeat*="resellerItem"]', // Any ng-repeat containing resellerItem
        'tbody[ng-repeat]', // Any tbody with ng-repeat
        'tbody' // Any tbody
      ];
      
      for (const selector of tbodySelectors) {
        tbodyElements = resellerTable.querySelectorAll(selector);
        if (tbodyElements.length > 0) {
          console.log(`[fareharbor-reseller-items] Found ${tbodyElements.length} tbody elements using selector: "${selector}"`);
          break;
        }
      }
    }
    
    if (tbodyElements.length === 0) {
      console.warn("[fareharbor-reseller-items] No tbody elements found in the table");
      // Debug: Show table structure
      console.log("[fareharbor-reseller-items] Table structure:", resellerTable.innerHTML.substring(0, 500) + "...");
      return null;
    }
    
    console.log(`[fareharbor-reseller-items] Found ${tbodyElements.length} reseller items`);
    
    // Process each reseller item (sync path: no expand; only visible options)
    tbodyElements.forEach((tbody, index) => {
      console.log(`[fareharbor-reseller-items] Processing reseller item ${index + 1}...`);
      const rowResults = extractRowData(tbody, index, useChannelName);
      rowResults.forEach(r => result.push(r));
    });
    
    if (result.length === 0) {
      console.warn("[fareharbor-reseller-items] No data extracted. Debug information:");
      console.log("[fareharbor-reseller-items] Current URL:", window.location.href);
      console.log("[fareharbor-reseller-items] Table found:", !!resellerTable);
      console.log("[fareharbor-reseller-items] Tbody elements found:", tbodyElements.length);
    }
    
    console.log(`[fareharbor-reseller-items] Successfully extracted ${result.length} reseller item rows`);
    return result;
  }

  // Async version: expands "+ N more" in options column per row, then extracts (one row per reseller option).
  async function scrapeResellerItemsAsync(useChannelName = false) {
    const result = [];
    console.log("[fareharbor-reseller-items] Starting async scrape (with expand)...");

    const tableSelectors = [
      'table.spreadsheet.highlight-rows.white-bg.m-t-0.ng-scope[ng-if="resellerItems.length"]',
      'table.spreadsheet.highlight-rows.white-bg[ng-if="resellerItems.length"]',
      'table.spreadsheet[ng-if="resellerItems.length"]',
      'table.spreadsheet.highlight-rows',
      'table.spreadsheet',
      'table[ng-table="resellerItems"]'
    ];
    let resellerTable = null;
    for (const selector of tableSelectors) {
      resellerTable = document.querySelector(selector);
      if (resellerTable) break;
    }
    if (!resellerTable) return null;

    let tbodyElements = resellerTable.querySelectorAll('tbody[ng-repeat="resellerItem in $table.collection"]');
    if (tbodyElements.length === 0) {
      const tbodySelectors = ['tbody[ng-repeat*="resellerItem"]', 'tbody[ng-repeat]', 'tbody'];
      for (const sel of tbodySelectors) {
        tbodyElements = resellerTable.querySelectorAll(sel);
        if (tbodyElements.length > 0) break;
      }
    }
    if (tbodyElements.length === 0) return null;

    for (let index = 0; index < tbodyElements.length; index++) {
      const tbody = tbodyElements[index];
      console.log(`[fareharbor-reseller-items] Processing reseller item ${index + 1}/${tbodyElements.length}...`);
      await expandOptionsColumnIfNeeded(tbody);
      const rowResults = extractRowData(tbody, index, useChannelName);
      rowResults.forEach(r => result.push(r));
    }

    console.log(`[fareharbor-reseller-items] Async scrape extracted ${result.length} reseller item rows`);
    return result;
  }

  function scrapeSingleResellerItem(useChannelName = false) {
    console.log("[fareharbor-reseller-items] Starting to scrape single reseller item...");
    
    const result = [];
    
    // Extract item name from Item Mappings section
    // Try multiple selectors to handle different environments
    let itemMappingLink = document.querySelector('.block-list-content.ng-binding');
    if (!itemMappingLink) {
      itemMappingLink = document.querySelector('.block-list-content');
    }
    let itemName = '';
    let itemLinkHTML = '';
    
    if (itemMappingLink) {
      const fullText = itemMappingLink.textContent.trim();
      itemName = trimItemDisplayText(fullText);
      
      // Create absolute URL for the link
      const baseUrl = window.location.origin; // e.g., https://demo.fareharbor.com or https://fareharbor.com
      const absoluteUrl = baseUrl + itemMappingLink.getAttribute('href');
      
      const clonedLink = itemMappingLink.cloneNode(true);
      clonedLink.setAttribute('href', absoluteUrl);
      clonedLink.textContent = itemName; // Set clean text without company suffix
      itemLinkHTML = clonedLink.outerHTML;
      
      console.log(`[fareharbor-reseller-items] Found original item: "${itemName}"`);
    } else {
      console.warn("[fareharbor-reseller-items] Item mapping link not found");
      console.log("[fareharbor-reseller-items] Available elements:");
      console.log("- .block-list-content.ng-binding:", document.querySelector('.block-list-content.ng-binding'));
      console.log("- .block-list-content:", document.querySelector('.block-list-content'));
      console.log("- .block-list:", document.querySelector('.block-list'));
      return null;
    }
    
    // Create the appropriate item label based on toggle state
    const finalItemName = createItemLabel(itemName, useChannelName);
    console.log(`[fareharbor-reseller-items] Final item name: "${finalItemName}"`);
    
    // Update the HTML link to use the final label
    if (itemLinkHTML) {
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = itemLinkHTML;
      const linkElement = tempDiv.querySelector('a');
      if (linkElement) {
        linkElement.textContent = finalItemName;
        itemLinkHTML = linkElement.outerHTML;
      }
    }
    
    // Extract Channel Options from Channel Options table
    const channelOptions = [];
    // Try multiple selectors to handle different environments
    let channelOptionsTable = document.querySelector('table[ng-table="resellerOptions"]');
    if (!channelOptionsTable) {
      // Alternative selector for production
      channelOptionsTable = document.querySelector('table.spreadsheet[ng-if="resellerOptions.length"]');
    }
    
    if (channelOptionsTable) {
      const optionRows = channelOptionsTable.querySelectorAll('tbody tr');
      console.log(`[fareharbor-reseller-items] Found ${optionRows.length} channel option rows`);
      optionRows.forEach((row, index) => {
        const tds = row.querySelectorAll('td');
        console.log(`[fareharbor-reseller-items] Option row ${index + 1} has ${tds.length} columns`);
        if (tds.length >= 3) {
          const externalId = tds[2]?.textContent?.trim() || '';
          
          if (externalId) {
            channelOptions.push(externalId); // Only the code, not the name
            console.log(`[fareharbor-reseller-items] Found channel option: "${externalId}"`);
          }
        }
      });
    } else {
      console.warn("[fareharbor-reseller-items] Channel options table not found");
      console.log("[fareharbor-reseller-items] Available table elements:");
      console.log("- table[ng-table='resellerOptions']:", document.querySelector('table[ng-table="resellerOptions"]'));
      console.log("- table.spreadsheet[ng-if='resellerOptions.length']:", document.querySelector('table.spreadsheet[ng-if="resellerOptions.length"]'));
    }
    
    // Extract Channel Customer Types from Channel Customer Types table
    const customerTypes = [];
    // Try multiple selectors to handle different environments
    let customerTypesTable = document.querySelector('table[data-test-id="test-reseller-customer-types-table"]');
    if (!customerTypesTable) {
      // Alternative selector for production
      customerTypesTable = document.querySelector('table.spreadsheet[ng-table="resellerCustomerTypes"]');
    }
    if (!customerTypesTable) {
      // Even more generic fallback
      customerTypesTable = document.querySelector('table.spreadsheet[ng-if="resellerCustomerTypes.length"]');
    }
    
    const mappedCustomerTypes = [];
    if (customerTypesTable) {
      const customerRows = customerTypesTable.querySelectorAll('tbody tr');
      console.log(`[fareharbor-reseller-items] Found ${customerRows.length} customer type rows`);
      customerRows.forEach((row, index) => {
        const tds = row.querySelectorAll('td');
        console.log(`[fareharbor-reseller-items] Customer type row ${index + 1} has ${tds.length} columns`);
        const mapped = extractMappedCustomerTypesFromTableRow(row);
        if (mapped) {
          mappedCustomerTypes.push(mapped);
          console.log(
            `[fareharbor-reseller-items] Found customer type: "${mapped.displayName}"` +
            (mapped.externalId ? ` (external ID: ${mapped.externalId})` : "")
          );
        }
      });
      
      // Reorder customer types according to GetYourGuide priority
      const reorderedMapped = reorderMappedCustomerTypes(mappedCustomerTypes);
      customerTypes.push(...reorderedMapped.map((entry) => entry.displayName).filter(Boolean));
    } else {
      console.warn("[fareharbor-reseller-items] Customer types table not found");
      console.log("[fareharbor-reseller-items] Available customer type table elements:");
      console.log("- table[data-test-id='test-reseller-customer-types-table']:", document.querySelector('table[data-test-id="test-reseller-customer-types-table"]'));
      console.log("- table.spreadsheet[ng-table='resellerCustomerTypes']:", document.querySelector('table.spreadsheet[ng-table="resellerCustomerTypes"]'));
      console.log("- table.spreadsheet[ng-if='resellerCustomerTypes.length']:", document.querySelector('table.spreadsheet[ng-if="resellerCustomerTypes.length"]'));
    }
    
    const itemId = extractIdNumber(finalItemName);
    const reorderedMappedCustomerTypes = reorderMappedCustomerTypes(mappedCustomerTypes);
    const baseRowFields = {
      itemLabel: finalItemName,
      itemLabelHTML: itemLinkHTML,
      itemId,
      mappedCustomerTypes: reorderedMappedCustomerTypes
    };

    // Build result rows in the same format as the complete mapping
    if (channelOptions.length > 0 && customerTypes.length > 0) {
      // Create a row for each channel option, with all customer types combined
      const combinedCustomerTypes = customerTypes.join('\n');
      channelOptions.forEach(channelOption => {
        result.push({
          channelOption: channelOption,
          customerType: combinedCustomerTypes,
          ...baseRowFields
        });
        console.log(`[fareharbor-reseller-items] Added row: "${channelOption}", "${finalItemName}", "${combinedCustomerTypes.replace(/\n/g, ' | ')}"`);
      });
    } else if (customerTypes.length > 0) {
      // Only customer types, no channel options
      const combinedCustomerTypes = customerTypes.join('\n');
      result.push({
        channelOption: '',
        customerType: combinedCustomerTypes,
        ...baseRowFields
      });
      console.log(`[fareharbor-reseller-items] Added row (no channel options): "", "${finalItemName}", "${combinedCustomerTypes.replace(/\n/g, ' | ')}"`);
    } else if (channelOptions.length > 0) {
      // Only channel options, no customer types
      channelOptions.forEach(channelOption => {
        result.push({
          channelOption: channelOption,
          customerType: '',
          ...baseRowFields
        });
        console.log(`[fareharbor-reseller-items] Added row (no customer types): "${channelOption}", "${finalItemName}", ""`);
      });
    } else {
      // Neither channel options nor customer types
      result.push({
        channelOption: '',
        customerType: '',
        ...baseRowFields
      });
      console.log(`[fareharbor-reseller-items] Added row (no data): "", "${finalItemName}", ""`);
    }
    
    console.log(`[fareharbor-reseller-items] Successfully extracted ${result.length} single item rows`);
    return result;
  }
  
  const GYG_HTML_HEADER_ROW =
    '<tr>\n' +
    '      <th>External Product ID</th>\n' +
    '      <th>FareHarbor Name &amp; Item ID</th>\n' +
    '      <th>Ticket Category</th>\n' +
    '    </tr>\n';

  function formatAsHTML(data, includeHeaderRow = false) {
    if (!data || data.length === 0) {
      return '';
    }
    
    let html = '<table border="1" cellpadding="5" cellspacing="0">\n';
    html += '<tbody>\n';

    if (includeHeaderRow) {
      html += GYG_HTML_HEADER_ROW;
    }
    
    data.forEach(item => {
      html += '<tr>\n';
      // Channel option - make bold
      html += `<td><strong>${escapeHtmlField(item.channelOption)}</strong></td>\n`;
      // Item label - use full HTML element if available, otherwise use escaped text
      const itemLabelContent = item.itemLabelHTML || escapeHtmlField(item.itemLabel);
      html += `<td>${itemLabelContent}</td>\n`;
      // Customer type - with line breaks
      html += `<td>${escapeHtmlField(item.customerType)}</td>\n`;
      html += '</tr>\n';
    });
    
    html += '</tbody>\n';
    html += '</table>';
    
    return html;
  }
  
  function escapeHtmlField(field) {
    if (!field) return '';
    
    // Convert to string and trim
    const str = String(field).trim();
    
    // Escape HTML characters
    const escaped = str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
    
    // Convert newlines to <br> tags for HTML line breaks
    return escaped.replace(/\n/g, '<br>');
  }

  // Function to extract ID number from item name (returns just the number)
  function extractIdNumber(itemName) {
    if (!itemName) return '';
    
    // Try format with "ID:" prefix first (e.g., "Name (ID: 76748)")
    let match = itemName.match(/\(ID:\s*(\d+)\)/);
    if (match) {
      return match[1];
    }
    
    // Try format without "ID:" prefix (e.g., "Name (76748)")
    match = itemName.match(/\((\d+)\)/);
    if (match) {
      return match[1];
    }
    
    return '';
  }

  // Function to extract item name without ID (returns just the name)
  function extractItemName(itemName) {
    if (!itemName) return '';
    
    // Remove ID part from the name
    // Try format with "ID:" prefix first (e.g., "Name (ID: 76748)")
    let cleaned = itemName.replace(/\(ID:\s*\d+\)/g, '').trim();
    
    // Try format without "ID:" prefix (e.g., "Name (76748)")
    if (cleaned === itemName) {
      cleaned = itemName.replace(/\(\d+\)/g, '').trim();
    }
    
    return cleaned;
  }

  // Format data as TSV (tab-separated values)
  function formatAsTSV(data) {
    if (!data || data.length === 0) {
      return '';
    }
    
    const tsvLines = [];
    
    // Add data rows (no headers as per HTML format)
    data.forEach(item => {
      // Extract plain text from itemLabel (remove HTML if present)
      let itemLabelText = item.itemLabel;
      if (item.itemLabelHTML) {
        // Extract text from HTML by creating a temporary element
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = item.itemLabelHTML;
        itemLabelText = tempDiv.textContent || tempDiv.innerText || item.itemLabel;
      }
      
      // Extract ID number and item name separately
      const itemNumber = extractIdNumber(itemLabelText);
      const itemName = extractItemName(itemLabelText);
      
      // Replace newlines in customerType with semicolons for TSV
      const customerTypeText = (item.customerType || '').replace(/\n/g, '; ');
      
      const row = [
        escapeTsvField(item.channelOption || ''),
        escapeTsvField(itemNumber),
        escapeTsvField(itemName),
        escapeTsvField(customerTypeText)
      ];
      tsvLines.push(row.join('\t'));
    });
    
    return tsvLines.join('\n');
  }

  function escapeTsvField(field) {
    if (!field) return '';
    
    // Convert to string and trim
    const str = String(field).trim();
    
    // For TSV, replace tabs, newlines, and carriage returns with spaces
    return str.replace(/[\t\n\r]/g, ' ');
  }

  async function appendEnrichmentToOutput(
    htmlData,
    tsvData,
    scrapedRows,
    mode,
    includeApiEnrichment,
    includeHeaderRow = false
  ) {
    if (!includeApiEnrichment) {
      console.log("[getyourguide-mapping] API enrichment disabled; using DOM-only copy");
      return { htmlData, tsvData, explanationText: "", hasEnrichmentExplanation: false };
    }

    console.log("[getyourguide-mapping] API enrichment enabled");

    if (!window.GetYourGuideMappingEnrichment) {
      console.warn("[fareharbor-reseller-items] GetYourGuideMappingEnrichment module not loaded; copying base mapping only");
      return { htmlData, tsvData, explanationText: "", hasEnrichmentExplanation: false };
    }

    try {
      const enrichment = await window.GetYourGuideMappingEnrichment.enrichCopyOutput({
        scrapedRows,
        mode,
        pageUrl: window.location.href
      });
      const enrichedTable = window.GetYourGuideMappingEnrichment.buildEnrichedCopyTableHtml(
        scrapedRows,
        enrichment.reports || [],
        includeHeaderRow
      );
      const baseHtml = enrichedTable || htmlData;
      return {
        htmlData: baseHtml,
        tsvData,
        explanationText: enrichment.explanationText || "",
        hasEnrichmentExplanation: Boolean(enrichment.hasEnrichmentExplanation)
      };
    } catch (error) {
      console.error("[fareharbor-reseller-items] Enrichment failed; copying base mapping only:", error);
      return { htmlData, tsvData, explanationText: "", hasEnrichmentExplanation: false };
    }
  }

  async function runExplanationCopy(options = {}) {
    const useChannelName = options.useChannelName || false;
    const includeHeaderRow = options.includeHeaderRow || false;
    const includeApiEnrichment = options.includeApiEnrichment === true;

    if (!includeApiEnrichment) {
      return {
        success: false,
        error: "Price and min/max settings must be enabled to copy the detailed explanation."
      };
    }

    const singleData = scrapeSingleResellerItem(useChannelName);
    if (singleData && singleData.length > 0) {
      let htmlData = formatAsHTML(singleData, includeHeaderRow);
      const enriched = await appendEnrichmentToOutput(
        htmlData,
        formatAsTSV(singleData),
        singleData,
        "single",
        true,
        includeHeaderRow
      );
      if (!enriched.explanationText) {
        return {
          success: false,
          error: "No enrichment explanation available for this item."
        };
      }
      return {
        success: true,
        explanationText: enriched.explanationText,
        hasEnrichmentExplanation: Boolean(enriched.hasEnrichmentExplanation),
        count: singleData.length
      };
    }

    const completeResult = await runCompleteMappingCopyHtml({
      useChannelName,
      includeHeaderRow,
      includeApiEnrichment: true
    });
    if (!completeResult.success) {
      return completeResult;
    }
    if (!completeResult.explanationText) {
      return {
        success: false,
        error: "No enrichment explanation available for this mapping."
      };
    }
    return {
      success: true,
      explanationText: completeResult.explanationText,
      hasEnrichmentExplanation: Boolean(completeResult.hasEnrichmentExplanation),
      count: completeResult.count
    };
  }

  // Message handling for FareHarbor Reseller Items actions
  function handleMessage(req, sender, sendResponse) {
    console.log("[fareharbor-reseller-items] Message received:", req);

    if (req.action === "runFareHarborResellerItemsExtract") {
      (async () => {
        try {
          const result = await runCompleteMappingCopyHtml({
            useChannelName: req.useChannelName || false,
            includeHeaderRow: req.includeHeaderRow || false,
            includeApiEnrichment: req.includeApiEnrichment === true
          });
          if (!result.success) {
            sendResponse({
              success: false,
              error: result.error
            });
            return;
          }
          sendResponse({
            success: true,
            data: result.data,
            htmlData: result.htmlData,
            tsvData: result.tsvData,
            explanationText: result.explanationText || "",
            hasEnrichmentExplanation: Boolean(result.hasEnrichmentExplanation),
            count: result.count
          });
        } catch (error) {
          console.error("[fareharbor-reseller-items] Error during scraping:", error);
          sendResponse({
            success: false,
            error: "An error occurred while scraping reseller items: " + error.message
          });
        }
      })();
      return true; // Keep channel open for async sendResponse
    }

    if (req.action === "runFareHarborResellerItemsSingleExtract") {
      (async () => {
        try {
          const useChannelName = req.useChannelName || false;
          const scrapeStart = performance.now();
          const data = scrapeSingleResellerItem(useChannelName);
          console.log(
            "[getyourguide-mapping] DOM scrape duration:",
            `${(performance.now() - scrapeStart).toFixed(1)}ms`
          );

          if (!data || data.length === 0) {
            sendResponse({
              success: false,
              error: "No single item data found on this page. Make sure you're on a GetYourGuide single item configuration page."
            });
            return;
          }

          const includeHeaderRow = req.includeHeaderRow || false;
          const includeApiEnrichment = req.includeApiEnrichment === true;
          let htmlData = formatAsHTML(data, includeHeaderRow);
          let tsvData = formatAsTSV(data);
          const enriched = await appendEnrichmentToOutput(
            htmlData,
            tsvData,
            data,
            "single",
            includeApiEnrichment,
            includeHeaderRow
          );
          htmlData = enriched.htmlData;
          tsvData = enriched.tsvData;

          sendResponse({
            success: true,
            data: data,
            htmlData: htmlData,
            tsvData: tsvData,
            explanationText: enriched.explanationText || "",
            hasEnrichmentExplanation: Boolean(enriched.hasEnrichmentExplanation),
            count: data.length
          });
        } catch (error) {
          console.error("[fareharbor-reseller-items] Error during single item scraping:", error);
          sendResponse({
            success: false,
            error: "An error occurred while scraping single item: " + error.message
          });
        }
      })();
      return true;
    }

    if (req.action === "runFareHarborResellerItemsExplanationExtract") {
      (async () => {
        try {
          const result = await runExplanationCopy({
            useChannelName: req.useChannelName || false,
            includeHeaderRow: req.includeHeaderRow || false,
            includeApiEnrichment: req.includeApiEnrichment === true
          });
          sendResponse(result);
        } catch (error) {
          console.error("[fareharbor-reseller-items] Explanation extract failed:", error);
          sendResponse({
            success: false,
            error: "An error occurred while building the enrichment explanation: " + error.message
          });
        }
      })();
      return true;
    }

    return false; // Not handled by this module
  }

  async function runCompleteMappingCopyHtml(options = {}) {
    const useChannelName = options.useChannelName || false;
    const includeHeaderRow = options.includeHeaderRow || false;
    const includeApiEnrichment = options.includeApiEnrichment === true;

    const scrapeStart = performance.now();
    const data = await scrapeResellerItemsAsync(useChannelName);
    console.log(
      "[getyourguide-mapping] DOM scrape duration:",
      `${(performance.now() - scrapeStart).toFixed(1)}ms`
    );
    if (!data || data.length === 0) {
      return {
        success: false,
        error: "No reseller items found on this page. Make sure you're on the FareHarbor reseller items page."
      };
    }

    let htmlData = formatAsHTML(data, includeHeaderRow);
    let tsvData = formatAsTSV(data);
    const enriched = await appendEnrichmentToOutput(
      htmlData,
      tsvData,
      data,
      "complete",
      includeApiEnrichment,
      includeHeaderRow
    );
    htmlData = enriched.htmlData;
    tsvData = enriched.tsvData;

    return {
      success: true,
      data,
      htmlData,
      tsvData,
      explanationText: enriched.explanationText || "",
      hasEnrichmentExplanation: Boolean(enriched.hasEnrichmentExplanation),
      count: data.length
    };
  }

  async function runSingleItemMappingCopyHtml(options = {}) {
    const useChannelName = options.useChannelName || false;
    const includeHeaderRow = options.includeHeaderRow || false;
    const includeApiEnrichment = options.includeApiEnrichment === true;

    const data = scrapeSingleResellerItem(useChannelName);
    if (!data || data.length === 0) {
      return {
        success: false,
        error: "No item mapping data found."
      };
    }

    let htmlData = formatAsHTML(data, includeHeaderRow);
    const enriched = await appendEnrichmentToOutput(
      htmlData,
      formatAsTSV(data),
      data,
      "single",
      includeApiEnrichment,
      includeHeaderRow
    );
    htmlData = enriched.htmlData;

    return {
      success: true,
      outputText: htmlData,
      explanationText: enriched.explanationText || "",
      hasEnrichmentExplanation: Boolean(enriched.hasEnrichmentExplanation),
      count: data.length
    };
  }

  // Export the module
  window.FareHarborResellerItems = {
    handleMessage,
    scrapeResellerItems,
    scrapeResellerItemsAsync,
    scrapeSingleResellerItem,
    formatAsHTML,
    formatAsTSV,
    runCompleteMappingCopyHtml,
    runSingleItemMappingCopyHtml,
    runExplanationCopy
  };

  console.log("[fareharbor-reseller-items] Module initialized successfully");

})(); // End of initialization function
