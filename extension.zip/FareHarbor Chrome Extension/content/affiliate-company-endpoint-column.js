(function affiliateCompanyEndpointColumnModule() {
  "use strict";

  const affiliateApi = window.FareHarborAffiliateApi;
  if (!affiliateApi) {
    return;
  }

  const { lookupAffiliateApiCredentials } = affiliateApi;
  const columnOrder = window.FareHarborAffiliateTableColumnOrder;
  if (!columnOrder) {
    return;
  }

  const LOG_PREFIX = "[affiliate-company-endpoint-column]";
  const DEV_MODE_STORAGE_KEY = FareHarborDeveloperAuth.DEV_MODE_STORAGE_KEY;
  const COLUMN_KEY = "affiliate-company-endpoint-call";
  const COLUMN_ATTR = "data-fh-ext-column";
  const COLUMN_SELECTOR = `[${COLUMN_ATTR}="${COLUMN_KEY}"]`;
  const CANCELLATION_COLUMN_SELECTOR =
    '[data-fh-ext-column="affiliate-cancellation-policy"]';
  const AFFILIATE_ID_ATTR = "data-fh-affiliate-id";
  const ACTION_ATTR = "data-fh-ext-action";
  const COPY_ACTION = "copy-company-endpoint";
  const BODY_CELL_CLASS = "fh-ext-affiliate-company-endpoint-call-cell";
  const SUBTLE_TEXT_CLASS = "fh-ext-subtle-text";
  const HEADER_TEXT = "Company Endpoint Call";
  const SETTING_KEY = "showAffiliateCompanyEndpointCallColumn";
  const INSERT_BEFORE_COLUMN_KEY = "permissionsGroup";
  const COLUMN_WIDTH_PX = 160;
  const WIDTH_EXPANDED_ATTR = "data-fh-ext-endpoint-column-width-expanded";
  const CANCELLATION_WIDTH_EXPANDED_ATTR = "data-fh-ext-width-expanded";
  const ORIGINAL_WIDTH_ATTR = "data-fh-ext-original-width";
  const REQUIRED_COLUMN_KEYS = [
    "affiliateName",
    "invoicePricing",
    INSERT_BEFORE_COLUMN_KEY,
    "actions"
  ];
  const AFFILIATES_PATH_RE =
    /^\/([^/]+)\/dashboard\/settings\/network\/affiliates\/?$/;
  const EDIT_AFFILIATE_HREF_RE = /\/affiliates\/edit\/(\d+)\/?/;
  const AFFILIATE_COMPANY_LINK_RE = /^\/([^/]+)\/dashboard\/?/;
  const SCAN_DEBOUNCE_MS = 150;
  const ROUTE_REEVAL_DELAY_MS = 150;
  const ROUTE_POLL_MS = 500;
  const RETRY_INTERVAL_MS = 500;
  const RETRY_MAX_MS = 10000;
  const COPY_TEXT = "Copy";
  const RETRY_TEXT = "Retry";
  const LOADING_TEXT = "Loading…";
  const COPIED_TEXT = "Copied";
  const SUCCESS_RESTORE_MS = 1750;
  const ERROR_RESTORE_MS = 3000;
  const LAYOUT_STYLE_ID = "fh-affiliate-company-endpoint-layout-style";
  const LAYOUT_CLASS = "fh-affiliate-cancellation-columns";
  const SETTINGS_WINDOW_SELECTOR = ".settings-window";
  const LAYOUT_STYLE_TEXT = `.settings-window.${LAYOUT_CLASS} {
  --settings-wrap-width-narrow: 900px;
}
.${SUBTLE_TEXT_CLASS} {
  opacity: 0.6;
}
td${COLUMN_SELECTOR} .fh-table-cell {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
td${COLUMN_SELECTOR} .fh-table-cell a.fh-link.fh-link--primary {
  color: var(--fh-color-text-link, var(--fh-color-link-primary, #006edb));
  text-decoration: none;
}
td${COLUMN_SELECTOR} .fh-table-cell a.fh-link.fh-link--primary:hover {
  color: var(--fh-color-text-link-hover, var(--fh-color-text-link, #005bb5));
  text-decoration: underline;
}
td${COLUMN_SELECTOR} .fh-table-cell a.fh-link.fh-link--primary:visited {
  color: var(--fh-color-text-link-visited, var(--fh-color-text-link, #006edb));
}
td${COLUMN_SELECTOR} .fh-text.${SUBTLE_TEXT_CLASS} {
  opacity: 0.6;
}
th${COLUMN_SELECTOR} .fh-text.fh-text--bold {
  font-weight: var(--fh-font-weight-bold, 600) !important;
}
${COLUMN_SELECTOR} {
  width: ${COLUMN_WIDTH_PX}px;
  min-width: ${COLUMN_WIDTH_PX}px;
  max-width: ${COLUMN_WIDTH_PX}px;
}`;

  let devModeEnabled = false;
  let observer = null;
  let debounceTimer = null;
  let hrefPollTimer = null;
  let lifecycleEvalTimer = null;
  let retryTimer = null;
  let retryStartedAt = 0;
  let lastTrackedHref = location.href;
  let watchersActive = false;
  let routeWatchersStarted = false;
  let scanInProgress = false;
  let lookupGeneration = 0;
  let featureEnabled = true;
  let startupMigrationDone = false;
  let clickListenerAttached = false;

  /** @type {Map<string, { affiliateApiKey: string, channelKey: string }>} */
  const credentialsCache = new Map();
  const inFlightKeys = new Set();
  const cellRestoreTimers = new WeakMap();

  function devLog(...args) {
    if (devModeEnabled) {
      console.log(LOG_PREFIX, ...args);
    }
  }

  function safeLog(state, meta = {}) {
    devLog(state, meta);
  }

  function isDevModeEnabledAsync() {
    return FareHarborDeveloperAuth.isDevModeActiveAsync();
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function parsePageContext() {
    const match = (location.pathname || "").match(AFFILIATES_PATH_RE);
    if (!match) {
      return null;
    }
    return {
      companyShortname: match[1],
      pathname: location.pathname || "",
      search: location.search || ""
    };
  }

  function isUrlEligible() {
    return isFareHarborHost() && !!parsePageContext();
  }

  function buildCredentialsCacheKey(dashboardShortname, affiliateId) {
    return `${dashboardShortname}:${affiliateId}`;
  }

  function clearPageCaches() {
    credentialsCache.clear();
    inFlightKeys.clear();
    lookupGeneration += 1;
  }

  function getRowCells(row) {
    return [...row.children].filter(
      (el) => el.tagName === "TD" || el.tagName === "TH"
    );
  }

  function getNativeRowCells(row) {
    return columnOrder.getNativeRowCells(row);
  }

  function isExtensionNode(node) {
    if (!(node instanceof Element)) {
      const parent = node?.parentElement;
      return parent ? isExtensionNode(parent) : false;
    }
    if (node.getAttribute(COLUMN_ATTR) === COLUMN_KEY) {
      return true;
    }
    if (node.getAttribute(COLUMN_ATTR) === "affiliate-cancellation-policy") {
      return true;
    }
    if (node.classList?.contains(BODY_CELL_CLASS)) {
      return true;
    }
    return (
      !!node.closest?.(COLUMN_SELECTOR) ||
      !!node.closest?.(CANCELLATION_COLUMN_SELECTOR)
    );
  }

  function isExtensionMutation(mutation) {
    if (isExtensionNode(mutation.target)) {
      return true;
    }
    for (const node of mutation.addedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    for (const node of mutation.removedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    return false;
  }

  function removeInjectedColumns(root) {
    const scope = root || document;
    scope.querySelectorAll(COLUMN_SELECTOR).forEach((cell) => {
      cell.remove();
    });
  }

  function restoreTableWidth(table) {
    if (!table || table.getAttribute(WIDTH_EXPANDED_ATTR) !== "true") {
      return;
    }

    const styleWidth = table.style.width || "";
    const match = styleWidth.match(/(\d+(?:\.\d+)?)\s*px/i);
    if (match) {
      const currentWidth = Number(match[1]);
      if (Number.isFinite(currentWidth)) {
        const nextWidth = Math.max(0, Math.round(currentWidth - COLUMN_WIDTH_PX));
        table.style.width = `${nextWidth}px`;
      }
    }

    table.removeAttribute(WIDTH_EXPANDED_ATTR);

    if (table.getAttribute(CANCELLATION_WIDTH_EXPANDED_ATTR) !== "true") {
      const originalWidth = table.getAttribute(ORIGINAL_WIDTH_ATTR);
      if (originalWidth) {
        table.style.width = `${originalWidth}px`;
        table.removeAttribute(ORIGINAL_WIDTH_ATTR);
      }
    }
  }

  function expandTableWidth(table) {
    if (!table || table.getAttribute(WIDTH_EXPANDED_ATTR) === "true") {
      return;
    }

    const styleWidth = table.style.width || "";
    const match = styleWidth.match(/(\d+(?:\.\d+)?)\s*px/i);
    if (!match) {
      return;
    }

    const currentWidth = Number(match[1]);
    if (!Number.isFinite(currentWidth)) {
      return;
    }

    if (!table.hasAttribute(ORIGINAL_WIDTH_ATTR)) {
      table.setAttribute(ORIGINAL_WIDTH_ATTR, String(Math.round(currentWidth)));
    }

    table.style.width = `${Math.round(currentWidth + COLUMN_WIDTH_PX)}px`;
    table.setAttribute(WIDTH_EXPANDED_ATTR, "true");
  }

  function cleanupBrokenInjection(table) {
    if (!table) {
      return;
    }

    table.querySelectorAll(COLUMN_SELECTOR).forEach((cell) => {
      cell.remove();
    });
    restoreTableWidth(table);
    safeLog("column removed", { state: "cleanup" });
  }

  function ensureLayoutStyle() {
    if (document.getElementById(LAYOUT_STYLE_ID)) {
      return;
    }
    const style = document.createElement("style");
    style.id = LAYOUT_STYLE_ID;
    style.textContent = LAYOUT_STYLE_TEXT;
    (document.head || document.documentElement).appendChild(style);
  }

  function applyLayoutWidening() {
    ensureLayoutStyle();
    document.querySelectorAll(SETTINGS_WINDOW_SELECTOR).forEach((el) => {
      el.classList.add(LAYOUT_CLASS);
    });
  }

  function removeLayoutWidening() {
    if (document.querySelector(CANCELLATION_COLUMN_SELECTOR)) {
      return;
    }
    document
      .querySelectorAll(`${SETTINGS_WINDOW_SELECTOR}.${LAYOUT_CLASS}`)
      .forEach((el) => {
        el.classList.remove(LAYOUT_CLASS);
      });
  }

  function syncLayoutWidening() {
    if (featureEnabled && isUrlEligible()) {
      applyLayoutWidening();
      return;
    }
    removeLayoutWidening();
  }

  function applyFeatureSetting(enabled, reason) {
    featureEnabled = enabled !== false;
    if (!featureEnabled) {
      removeLayoutWidening();
      stopObserver();
      const table = findAffiliatesTable(document);
      if (table) {
        cleanupBrokenInjection(table);
      } else {
        removeInjectedColumns();
      }
      watchersActive = false;
      return;
    }
    evaluateLifecycle(reason || "setting-enabled");
  }

  function initSettingsBinding() {
    const settings = window.FHSettings;
    if (!settings) {
      return;
    }
    settings.get(SETTING_KEY, (value) => {
      applyFeatureSetting(value, "settings-init");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SETTING_KEY]) {
        applyFeatureSetting(changes[SETTING_KEY].newValue, "setting-change");
      }
    });
  }

  function getColumnKeyIndexMap(headerRow) {
    const nativeCells = getNativeRowCells(headerRow);
    const map = new Map();
    nativeCells.forEach((cell, index) => {
      const key = cell.getAttribute("data-column-key");
      if (key) {
        map.set(key, index);
      }
    });
    return { nativeCells, map };
  }

  function removeDuplicateExtensionCells(row) {
    const cells = [...row.querySelectorAll(`:scope > ${COLUMN_SELECTOR}`)];
    for (let i = 1; i < cells.length; i += 1) {
      cells[i].remove();
    }
  }

  function isAffiliatesTable(table) {
    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return false;
    }
    const { map } = getColumnKeyIndexMap(headerRow);
    return REQUIRED_COLUMN_KEYS.every((key) => map.has(key));
  }

  function findAffiliatesTable(root) {
    const scope = root || document;
    const tables = scope.querySelectorAll("table");
    for (const table of tables) {
      if (isAffiliatesTable(table)) {
        return table;
      }
    }
    return null;
  }

  function extractAffiliateIdFromRow(row) {
    const rowId = row.getAttribute("data-row-id");
    if (rowId) {
      return rowId;
    }

    const tbody = row.closest("tbody[data-id]");
    if (tbody) {
      const tbodyId = tbody.getAttribute("data-id");
      if (tbodyId) {
        return tbodyId;
      }
    }

    const editLink = row.querySelector('a[data-test-id^="edit-affiliate-"]');
    if (editLink) {
      const href = editLink.getAttribute("href") || editLink.href || "";
      const match = href.match(EDIT_AFFILIATE_HREF_RE);
      if (match) {
        return match[1];
      }
    }

    return null;
  }

  function extractAffiliateShortnameFromRow(row) {
    const link = row.querySelector('a[data-test-id^="affiliate-company-link-"]');
    if (!link) {
      return null;
    }

    const href = link.getAttribute("href") || link.href || "";
    let path = href;
    if (href.startsWith("http")) {
      try {
        path = new URL(href).pathname;
      } catch {
        return null;
      }
    }

    const match = path.match(AFFILIATE_COMPANY_LINK_RE);
    return match ? match[1] : null;
  }

  function getCellContentElement(cell) {
    let inner = cell.querySelector(":scope > .fh-table-cell");
    if (!inner) {
      inner = document.createElement("div");
      inner.className = "fh-table-cell";
      cell.appendChild(inner);
    }
    return inner;
  }

  function clearCellContent(cell) {
    const inner = getCellContentElement(cell);
    inner.textContent = "";
    inner.replaceChildren();
    return inner;
  }

  function clearCellRestoreTimer(cell) {
    const timer = cellRestoreTimers.get(cell);
    if (timer) {
      clearTimeout(timer);
      cellRestoreTimers.delete(cell);
    }
  }

  function getReferenceTableLink(cell) {
    const table = cell?.closest("table");
    if (!table) {
      return null;
    }

    return (
      table.querySelector(
        'a.fh-link--primary[href*="/dashboard/settings/permissions/groups/"]'
      ) ||
      table.querySelector(
        'a.fh-link--primary[href*="/dashboard/settings/pricing/"]'
      ) ||
      table.querySelector("tbody a.fh-link--primary")
    );
  }

  function applyNativeLinkAppearance(link, referenceLink) {
    link.className = "fh-link fh-link--primary fh-link--md fh-link--standalone";
    link.setAttribute("size", "md");

    if (!referenceLink) {
      return;
    }

    link.className = referenceLink.className;
    const refSize = referenceLink.getAttribute("size");
    if (refSize) {
      link.setAttribute("size", refSize);
    } else {
      link.setAttribute("size", "md");
    }

    const computed = window.getComputedStyle(referenceLink);
    link.style.color = computed.color;
    link.style.textDecoration = computed.textDecoration;
    link.style.fontWeight = computed.fontWeight;
    link.style.fontSize = computed.fontSize;
    link.style.lineHeight = computed.lineHeight;
  }

  function setSubtleCellText(cell, text) {
    clearCellRestoreTimer(cell);
    const inner = clearCellContent(cell);
    const span = document.createElement("span");
    span.className = `fh-text fh-text--body-md fh-text--regular ${SUBTLE_TEXT_CLASS}`;
    span.textContent = text;
    inner.appendChild(span);
    cell.classList.remove(SUBTLE_TEXT_CLASS);
    cell.removeAttribute("title");
  }

  function renderActionLink(cell, affiliateId, affiliateShortname, label) {
    clearCellRestoreTimer(cell);
    const inner = clearCellContent(cell);
    const link = document.createElement("a");
    link.href = "#";
    link.textContent = label;
    link.setAttribute(ACTION_ATTR, COPY_ACTION);
    link.setAttribute(AFFILIATE_ID_ATTR, affiliateId);
    if (affiliateShortname) {
      link.setAttribute("data-fh-affiliate-shortname", affiliateShortname);
    }
    applyNativeLinkAppearance(link, getReferenceTableLink(cell));
    inner.appendChild(link);
    cell.classList.remove(SUBTLE_TEXT_CLASS);
    cell.removeAttribute("title");
    cell.setAttribute(AFFILIATE_ID_ATTR, affiliateId);
  }

  function scheduleCellRestore(cell, affiliateId, affiliateShortname, delayMs, label) {
    clearCellRestoreTimer(cell);
    const timer = setTimeout(() => {
      cellRestoreTimers.delete(cell);
      const row = cell.closest("tr");
      const currentId = row ? extractAffiliateIdFromRow(row) : null;
      if (currentId && currentId !== affiliateId) {
        return;
      }
      renderActionLink(cell, affiliateId, affiliateShortname, label);
    }, delayMs);
    cellRestoreTimers.set(cell, timer);
  }

  function getReferenceHeaderCell(headerRow) {
    return (
      headerRow.querySelector(`th[data-column-key="${INSERT_BEFORE_COLUMN_KEY}"]`) ||
      headerRow.querySelector('th[data-column-key="invoicePricing"]') ||
      headerRow.querySelector("th.fh-dynamic-table-cell-header")
    );
  }

  function copyNativeHeaderTypography(targetText, referenceText) {
    if (!targetText || !referenceText) {
      return;
    }

    targetText.className = referenceText.className;
    const computed = window.getComputedStyle(referenceText);
    targetText.style.fontWeight = computed.fontWeight;
    targetText.style.fontFamily = computed.fontFamily;
    targetText.style.fontSize = computed.fontSize;
    targetText.style.lineHeight = computed.lineHeight;
    targetText.style.letterSpacing = computed.letterSpacing;
  }

  function applyNativeHeaderShell(headerCell, referenceHeader) {
    if (!referenceHeader) {
      headerCell.className =
        "fh-table-cell--start fh-table-cell-header fh-dynamic-table-cell-header";
      return;
    }

    headerCell.className = referenceHeader.className
      .replace(/\bfh-table-cell-header--sortable\b/g, "")
      .trim();
    headerCell.removeAttribute("tabindex");
    headerCell.removeAttribute("aria-sort");
    headerCell.removeAttribute("aria-labelledby");
    headerCell.removeAttribute("data-column-name");
    headerCell.removeAttribute("data-column-key");
  }

  function refreshHeaderLabel(headerCell, referenceHeader) {
    const headerLabel = headerCell.querySelector(
      ":scope > .fh-table-cell .fh-text, :scope > .fh-table-cell span"
    );
    if (!headerLabel) {
      return;
    }

    headerLabel.textContent = HEADER_TEXT;
    const refText = referenceHeader?.querySelector(
      ":scope > .fh-table-cell .fh-text"
    );
    if (refText) {
      copyNativeHeaderTypography(headerLabel, refText);
      return;
    }

    headerLabel.className = "fh-text fh-text--body-md fh-text--bold";
    headerLabel.style.fontWeight = "600";
  }

  function createHeaderCell(referenceHeader) {
    const cell = document.createElement("th");
    cell.setAttribute(COLUMN_ATTR, COLUMN_KEY);
    applyNativeHeaderShell(cell, referenceHeader);
    cell.setAttribute("role", "columnheader");
    cell.setAttribute("scope", "col");
    cell.style.width = `${COLUMN_WIDTH_PX}px`;

    const inner = document.createElement("div");
    inner.className = "fh-table-cell";

    const span = document.createElement("span");
    span.textContent = HEADER_TEXT;
    const refText = referenceHeader?.querySelector(
      ":scope > .fh-table-cell .fh-text"
    );
    if (refText) {
      copyNativeHeaderTypography(span, refText);
    } else {
      span.className = "fh-text fh-text--body-md fh-text--bold";
      span.style.fontWeight = "600";
    }

    inner.appendChild(span);
    cell.appendChild(inner);
    return cell;
  }

  function createBodyCell() {
    const cell = document.createElement("td");
    cell.setAttribute(COLUMN_ATTR, COLUMN_KEY);
    cell.classList.add(BODY_CELL_CLASS, "fh-table-cell--start");
    cell.style.width = `${COLUMN_WIDTH_PX}px`;

    const inner = document.createElement("div");
    inner.className = "fh-table-cell";
    const span = document.createElement("span");
    span.className = `fh-text fh-text--body-md fh-text--regular ${SUBTLE_TEXT_CLASS}`;
    span.textContent = COPY_TEXT;
    inner.appendChild(span);
    cell.appendChild(inner);
    return cell;
  }

  function ensureHeaderColumn(headerRow) {
    let headerCell = headerRow.querySelector(`:scope > ${COLUMN_SELECTOR}`);
    const referenceHeader = getReferenceHeaderCell(headerRow);
    const permissionsHeader = columnOrder.findNativePermissionsHeader(headerRow);

    if (!permissionsHeader) {
      if (headerCell) {
        headerCell.remove();
      }
      return { inserted: false, repositioned: false };
    }

    if (!headerCell) {
      headerCell = createHeaderCell(referenceHeader);
      headerRow.insertBefore(headerCell, permissionsHeader);
      safeLog("column inserted", { state: "header" });
      return { inserted: true, repositioned: false };
    }

    if (headerCell.tagName !== "TH") {
      const replacement = createHeaderCell(referenceHeader);
      headerCell.replaceWith(replacement);
      headerCell = replacement;
      headerRow.insertBefore(headerCell, permissionsHeader);
      return { inserted: true, repositioned: true };
    }

    applyNativeHeaderShell(headerCell, referenceHeader);
    refreshHeaderLabel(headerCell, referenceHeader);
    headerCell.style.width = `${COLUMN_WIDTH_PX}px`;

    return { inserted: false, repositioned: false };
  }

  function ensureBodyCell(row, affiliateId, affiliateShortname) {
    let cell = row.querySelector(`:scope > ${COLUMN_SELECTOR}`);
    let inserted = false;
    const permissionsCell = columnOrder.findNativePermissionsCell(row);

    if (!permissionsCell) {
      if (cell) {
        cell.remove();
      }
      return { inserted: false, repositioned: false, cell: null };
    }

    if (!cell) {
      cell = createBodyCell();
      row.insertBefore(cell, permissionsCell);
      inserted = true;
    } else if (cell.tagName !== "TD") {
      const replacement = createBodyCell();
      cell.replaceWith(replacement);
      cell = replacement;
      row.insertBefore(cell, permissionsCell);
      inserted = true;
    }

    cell.style.width = `${COLUMN_WIDTH_PX}px`;

    if (affiliateId) {
      const previousId = cell.getAttribute(AFFILIATE_ID_ATTR);
      const currentText = (cell.textContent || "").trim();
      const isActionState =
        currentText === COPY_TEXT ||
        currentText === RETRY_TEXT ||
        currentText === "";
      if (previousId && previousId !== affiliateId) {
        renderActionLink(cell, affiliateId, affiliateShortname, COPY_TEXT);
      } else if (isActionState || !currentText) {
        renderActionLink(cell, affiliateId, affiliateShortname, COPY_TEXT);
      }
      cell.setAttribute(AFFILIATE_ID_ATTR, affiliateId);
    } else {
      cell.removeAttribute(AFFILIATE_ID_ATTR);
      setSubtleCellText(cell, "-");
    }

    return { inserted, repositioned: false, cell };
  }

  function tableNeedsRepair(table) {
    if (!table) {
      return true;
    }

    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return true;
    }

    const permissionsHeader = columnOrder.findNativePermissionsHeader(headerRow);
    if (!permissionsHeader) {
      return true;
    }

    const extensionHeaders = headerRow.querySelectorAll(`:scope > ${COLUMN_SELECTOR}`);
    if (extensionHeaders.length !== 1) {
      return true;
    }

    if (!columnOrder.rowExtensionOrderCorrect(headerRow, permissionsHeader)) {
      return true;
    }

    for (const row of table.querySelectorAll("tbody tr")) {
      const permissionsCell = columnOrder.findNativePermissionsCell(row, headerRow);
      if (!permissionsCell) {
        return true;
      }

      const extensionCells = row.querySelectorAll(`:scope > ${COLUMN_SELECTOR}`);
      if (extensionCells.length !== 1) {
        return true;
      }

      if (!columnOrder.rowExtensionOrderCorrect(row, permissionsCell)) {
        return true;
      }
    }

    return false;
  }

  function normalizeColumn(table) {
    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return {
        headerInserted: 0,
        cellsInserted: 0,
        cellsRepositioned: 0
      };
    }

    const permissionsHeader = columnOrder.findNativePermissionsHeader(headerRow);
    if (!permissionsHeader) {
      return {
        headerInserted: 0,
        cellsInserted: 0,
        cellsRepositioned: 0
      };
    }

    if (!tableNeedsRepair(table)) {
      expandTableWidth(table);
      return {
        headerInserted: 0,
        cellsInserted: 0,
        cellsRepositioned: 0
      };
    }

    expandTableWidth(table);

    let headerInserted = 0;
    let cellsInserted = 0;
    let cellsRepositioned = 0;

    const headerResult = ensureHeaderColumn(headerRow);
    if (headerResult.inserted) {
      headerInserted = 1;
    }

    table.querySelectorAll("tbody tr").forEach((row) => {
      const affiliateId = extractAffiliateIdFromRow(row);
      const affiliateShortname = extractAffiliateShortnameFromRow(row);
      const bodyResult = ensureBodyCell(row, affiliateId, affiliateShortname);
      if (bodyResult.inserted) {
        cellsInserted += 1;
      }
    });

    removeDuplicateExtensionCells(headerRow);
    table.querySelectorAll("tbody tr").forEach(removeDuplicateExtensionCells);

    const orderResult = columnOrder.ensureAffiliateExtensionColumnOrder(table);
    if (orderResult.repositioned) {
      cellsRepositioned += 1;
    }

    return {
      headerInserted,
      cellsInserted,
      cellsRepositioned
    };
  }

  function buildEndpointUrl(dashboardShortname, channelKey, affiliateApiKey) {
    const endpointUrl = new URL(
      `/api/external/v1/companies/${encodeURIComponent(dashboardShortname)}/`,
      "https://fareharbor.com"
    );
    endpointUrl.searchParams.set("api-app", channelKey);
    endpointUrl.searchParams.set("api-user", affiliateApiKey);
    return endpointUrl.toString();
  }

  function getCredentialErrorLabel(result) {
    const apiOk =
      result?.affiliateApiKey?.status === "ok" && !!result?.affiliateApiKey?.key;
    const channelOk =
      result?.channelApp?.status === "resolved" && !!result?.channelApp?.key;
    if (apiOk && channelOk) {
      return null;
    }

    if (!apiOk && channelOk) {
      return "No Affiliate API key";
    }
    if (apiOk && !channelOk) {
      return "No Channel key";
    }

    if (!result?.ok) {
      return "Credentials unavailable";
    }

    const apiStatus = result?.affiliateApiKey?.status;
    const channelStatus = result?.channelApp?.status;
    const apiMissing = apiStatus === "empty" || apiStatus === "error";
    const channelMissing = ["unresolved", "error", "ambiguous", "inactive"].includes(
      channelStatus
    );

    if (apiMissing && channelMissing) {
      if (apiStatus === "empty" && channelStatus === "unresolved") {
        return "Unavailable";
      }
      return "Credentials unavailable";
    }

    if (apiMissing) {
      return "No Affiliate API key";
    }
    if (channelMissing) {
      return "No Channel key";
    }

    return "Credentials unavailable";
  }

  async function copyEndpointForRow(cell, ctx, affiliateId, affiliateShortname) {
    const cacheKey = buildCredentialsCacheKey(ctx.companyShortname, affiliateId);
    if (inFlightKeys.has(cacheKey)) {
      return;
    }

    const generation = lookupGeneration;
    inFlightKeys.add(cacheKey);
    setSubtleCellText(cell, LOADING_TEXT);

    safeLog("resolving row credentials", {
      dashboardShortname: ctx.companyShortname,
      affiliateId,
      affiliateShortname,
      state: "loading"
    });

    try {
      let affiliateApiKey = null;
      let channelKey = null;

      const cached = credentialsCache.get(cacheKey);
      if (cached) {
        affiliateApiKey = cached.affiliateApiKey;
        channelKey = cached.channelKey;
      } else {
        const result = await lookupAffiliateApiCredentials(
          ctx.companyShortname,
          affiliateId
        );

        if (generation !== lookupGeneration) {
          return;
        }

        const errorLabel = getCredentialErrorLabel(result);
        if (errorLabel) {
          safeLog("credential resolution failed", {
            dashboardShortname: ctx.companyShortname,
            affiliateId,
            affiliateShortname,
            state: errorLabel,
            success: false
          });
          setSubtleCellText(cell, errorLabel);
          scheduleCellRestore(
            cell,
            affiliateId,
            affiliateShortname,
            ERROR_RESTORE_MS,
            RETRY_TEXT
          );
          return;
        }

        affiliateApiKey = result.affiliateApiKey.key;
        channelKey = result.channelApp.key;
        credentialsCache.set(cacheKey, { affiliateApiKey, channelKey });

        safeLog("credentials resolved", {
          dashboardShortname: ctx.companyShortname,
          affiliateId,
          affiliateShortname,
          state: "resolved",
          success: true
        });
      }

      const copiedValue = buildEndpointUrl(
        ctx.companyShortname,
        channelKey,
        affiliateApiKey
      );

      try {
        await navigator.clipboard.writeText(copiedValue);
      } catch {
        safeLog("credential resolution failed", {
          dashboardShortname: ctx.companyShortname,
          affiliateId,
          affiliateShortname,
          state: "clipboard-failed",
          success: false
        });
        setSubtleCellText(cell, "Credentials unavailable");
        scheduleCellRestore(
          cell,
          affiliateId,
          affiliateShortname,
          ERROR_RESTORE_MS,
          RETRY_TEXT
        );
        return;
      }

      safeLog("endpoint copied", {
        dashboardShortname: ctx.companyShortname,
        affiliateId,
        affiliateShortname,
        state: "copied",
        success: true
      });

      setSubtleCellText(cell, COPIED_TEXT);
      scheduleCellRestore(
        cell,
        affiliateId,
        affiliateShortname,
        SUCCESS_RESTORE_MS,
        COPY_TEXT
      );
    } finally {
      inFlightKeys.delete(cacheKey);
    }
  }

  function handleDocumentClick(event) {
    if (!featureEnabled || !isUrlEligible()) {
      return;
    }

    const target = event.target.closest(`[${ACTION_ATTR}="${COPY_ACTION}"]`);
    if (!target) {
      return;
    }

    const cell = target.closest(COLUMN_SELECTOR);
    if (!cell) {
      return;
    }

    event.preventDefault();
    event.stopPropagation();

    const ctx = parsePageContext();
    if (!ctx) {
      return;
    }

    const affiliateId = target.getAttribute(AFFILIATE_ID_ATTR);
    const affiliateShortname =
      target.getAttribute("data-fh-affiliate-shortname") || null;

    if (!affiliateId) {
      return;
    }

    const row = cell.closest("tr");
    if (row) {
      const rowAffiliateId = extractAffiliateIdFromRow(row);
      const rowAffiliateShortname = extractAffiliateShortnameFromRow(row);
      if (rowAffiliateId && rowAffiliateId !== affiliateId) {
        return;
      }
      copyEndpointForRow(
        cell,
        ctx,
        rowAffiliateId || affiliateId,
        rowAffiliateShortname || affiliateShortname
      );
      return;
    }

    copyEndpointForRow(cell, ctx, affiliateId, affiliateShortname);
  }

  function attachClickListener() {
    if (clickListenerAttached) {
      return;
    }
    document.addEventListener("click", handleDocumentClick, true);
    clickListenerAttached = true;
  }

  async function scanTable(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return false;
    }

    const table = findAffiliatesTable(document);
    if (!table) {
      return false;
    }

    if (scanInProgress) {
      return false;
    }

    scanInProgress = true;
    let didWork = false;

    try {
      syncLayoutWidening();

      if (!startupMigrationDone) {
        cleanupBrokenInjection(table);
        startupMigrationDone = true;
      }

      const normalizeResult = normalizeColumn(table);
      const { headerInserted, cellsInserted, cellsRepositioned } = normalizeResult;

      if (headerInserted > 0 || cellsInserted > 0 || cellsRepositioned > 0) {
        safeLog("table rerender detected", {
          state: reason || "scan",
          success: true
        });
      }

      didWork =
        headerInserted > 0 || cellsInserted > 0 || cellsRepositioned > 0;

      if (didWork) {
        safeLog("column inserted", {
          state: "normalized",
          success: true
        });
      }

      return didWork;
    } catch (error) {
      console.error("[affiliate-company-endpoint-column] table normalization failed", {
        error: error?.message || String(error)
      });
      return false;
    } finally {
      scanInProgress = false;
    }
  }

  function scheduleScan(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }
    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      scanTable(reason || "debounced-scan");
    }, SCAN_DEBOUNCE_MS);
  }

  function stopRetryLoop() {
    if (retryTimer) {
      clearInterval(retryTimer);
      retryTimer = null;
    }
    retryStartedAt = 0;
  }

  function startRetryLoop(reason) {
    if (!isUrlEligible()) {
      stopRetryLoop();
      return;
    }

    if (!retryTimer) {
      retryStartedAt = Date.now();
      retryTimer = setInterval(async () => {
        const elapsed = Date.now() - retryStartedAt;
        const found = await scanTable("retry-loop");
        if (found) {
          stopRetryLoop();
          return;
        }
        if (elapsed >= RETRY_MAX_MS) {
          stopRetryLoop();
        }
      }, RETRY_INTERVAL_MS);
    }

    scheduleScan(reason || "retry-schedule");
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    stopRetryLoop();
    clearPageCaches();
    scanInProgress = false;
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  function evaluateLifecycle(reason) {
    if (!featureEnabled) {
      stopObserver();
      const table = findAffiliatesTable(document);
      if (table) {
        cleanupBrokenInjection(table);
      } else {
        removeInjectedColumns();
      }
      removeLayoutWidening();
      watchersActive = false;
      return;
    }

    if (!isUrlEligible()) {
      stopObserver();
      removeLayoutWidening();
      watchersActive = false;
      return;
    }

    syncLayoutWidening();
    attachClickListener();

    if (!watchersActive) {
      safeLog("eligible page detected", {
        state: reason || "lifecycle",
        success: true
      });
      startObserver();
      watchersActive = true;
    }

    startRetryLoop(reason || "lifecycle");
  }

  function onRouteChange(reason) {
    const nextHref = location.href;
    if (nextHref !== lastTrackedHref) {
      clearPageCaches();
      startupMigrationDone = false;
    }
    lastTrackedHref = nextHref;
    scheduleLifecycleEval(reason || "route-change");
  }

  function startRouteWatchers() {
    if (routeWatchersStarted) {
      return;
    }
    routeWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", () => onRouteChange("popstate"));
    window.addEventListener("hashchange", () => onRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        onRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        onRouteChange("replaceState");
        return result;
      };
    } catch (err) {
      devLog("history hook unavailable:", err);
    }

    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        onRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  function startObserver() {
    if (observer) {
      return;
    }

    observer = new MutationObserver((mutations) => {
      if (!isUrlEligible()) {
        return;
      }
      if (mutations.length > 0 && mutations.every(isExtensionMutation)) {
        return;
      }
      scheduleScan("mutation-observer");
    });

    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  async function init() {
    if (!isFareHarborHost()) {
      return;
    }

    devModeEnabled = await isDevModeEnabledAsync();
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[DEV_MODE_STORAGE_KEY]) {
        void isDevModeEnabledAsync().then((active) => {
          devModeEnabled = active;
        });
      }
    });

    initSettingsBinding();
    startRouteWatchers();
    evaluateLifecycle("init");

    if (document.readyState === "loading") {
      document.addEventListener(
        "DOMContentLoaded",
        () => evaluateLifecycle("dom-content-loaded"),
        { once: true }
      );
    }
  }

  init();
})();
