console.log("[viator-mapping-pricing] viator-mapping-pricing-enrichment.js loaded");

(function initializeViatorMappingPricingEnrichment() {
  "use strict";

  const LOG_PREFIX = "[viator-mapping]";
  const INTEGRATION_KEY = "viator";

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function warn(...args) {
    console.warn(LOG_PREFIX, ...args);
  }

  function getShared() {
    return window.FareHarborAffiliateMappingPricing ?? null;
  }

  function extractIdNumber(itemName) {
    if (!itemName) return "";
    let match = itemName.match(/\(ID:\s*(\d+)\)/);
    if (match) return match[1];
    match = itemName.match(/\((\d+)\)/);
    if (match) return match[1];
    return "";
  }

  function extractItemName(itemName) {
    if (!itemName) return "";
    let cleaned = itemName.replace(/\(ID:\s*\d+\)/g, "").trim();
    if (cleaned === itemName) {
      cleaned = itemName.replace(/\(\d+\)/g, "").trim();
    }
    return cleaned;
  }

  function getItemLabelText(item) {
    let itemLabelText = item.itemLabel;
    if (item.itemLabelHTML) {
      const tempDiv = document.createElement("div");
      tempDiv.innerHTML = item.itemLabelHTML;
      itemLabelText = tempDiv.textContent || tempDiv.innerText || item.itemLabel;
    }
    return itemLabelText || "";
  }

  function formatTicketCategoryForTsv(item) {
    return (item.customerType || "").replace(/\n/g, "; ");
  }

  function formatTicketCategoryForHtml(item) {
    const shared = getShared();
    const text = item.customerType || "";
    if (shared?.escapeHtmlText) {
      return shared.escapeHtmlText(text).replace(/\n/g, "<br>");
    }
    return text.replace(/\n/g, "<br>");
  }

  function formatMappedTypesForTsv(mappedTypes) {
    return (mappedTypes || [])
      .map((entry) => entry.name || entry.displayName || "")
      .filter(Boolean)
      .join("; ");
  }

  function formatMappedTypesForHtml(mappedTypes) {
    const shared = getShared();
    const names = (mappedTypes || [])
      .map((entry) => entry.name || entry.displayName || "")
      .filter(Boolean);
    if (shared?.escapeHtmlText) {
      return names.map((name) => shared.escapeHtmlText(name)).join("<br>");
    }
    return names.join("<br>");
  }

  function groupRowsByItemId(scrapedRows) {
    const groups = new Map();
    for (const row of scrapedRows || []) {
      const itemId = row.itemId || extractIdNumber(getItemLabelText(row));
      if (!itemId) continue;
      if (!groups.has(String(itemId))) {
        groups.set(String(itemId), []);
      }
      groups.get(String(itemId)).push(row);
    }
    return groups;
  }

  async function resolveRowMappedCustomerTypes(shared, company, itemId, row, caches, pageUrl) {
    const warnings = [];
    const prototypesResult = await shared.fetchCustomerPrototypes(company, itemId);
    if (!prototypesResult.ok) {
      warnings.push({
        kind: "customer-type-mapping",
        itemId,
        resellerItemId: row.resellerItemId || null,
        message: prototypesResult.error
      });
      return { mappedTypes: [], warnings };
    }

    const mappingResult = await shared.fetchResellerCustomerTypeMappingsForItem(
      company,
      itemId,
      [row],
      pageUrl,
      caches.mappingCache
    );

    const lookup = mappingResult.ok ? mappingResult.lookup : null;
    if (!mappingResult.ok) {
      warnings.push({
        kind: "customer-type-mapping",
        itemId,
        resellerItemId: row.resellerItemId || null,
        message: mappingResult.error
      });
    }

    const channelTypes =
      Array.isArray(row.mappedCustomerTypes) && row.mappedCustomerTypes.length > 0
        ? row.mappedCustomerTypes
        : String(row.customerType || "")
            .split("\n")
            .map((displayName) => ({ displayName: displayName.trim(), externalId: "" }))
            .filter((entry) => entry.displayName);

    const collected = [];
    for (const channelType of channelTypes) {
      const resolved = shared.resolvePrototypeForChannelCustomerType(
        channelType,
        prototypesResult.prototypes,
        lookup
      );
      collected.push(...(resolved.mappedCustomerTypes || []));
    }

    const mappedTypes = shared.dedupeMappedCustomerTypesById(collected);
    if (mappedTypes.length === 0 && channelTypes.length > 0) {
      warnings.push({
        kind: "customer-type-mapping",
        itemId,
        resellerItemId: row.resellerItemId || null,
        message: "No mapped FareHarbor customer types resolved"
      });
    }

    return { mappedTypes, warnings };
  }

  async function loadPricingForSheetItem(shared, company, sheetPk, itemId, priceCache) {
    const cacheKey = `${company}:${sheetPk}:${itemId}`;
    if (priceCache.has(cacheKey)) {
      return priceCache.get(cacheKey);
    }

    const result = await shared.fetchPricingForEditing(company, sheetPk, itemId);
    const cached = {
      ok: result.ok,
      pricingRows: result.ok ? shared.getEffectivePricings(result.pricing) : [],
      error: result.error || null
    };
    priceCache.set(cacheKey, cached);
    return cached;
  }

  async function enrichViatorMappingOutput({ scrapedRows, onStatus, pageUrl }) {
    const shared = getShared();
    if (!shared) {
      return {
        ok: false,
        error: "Pricing shared module not loaded. Reload the page."
      };
    }

    const warnings = [];
    let mappingCustomerTypeSuccessCount = 0;
    let priceCellsPopulated = 0;
    let priceScheduleCount = 0;
    let priceSheetCount = 0;

    if (typeof onStatus === "function") {
      onStatus("Loading Viator mappings…");
    }

    const company = shared.resolveCompanyFromRows(scrapedRows);
    if (!company) {
      return { ok: false, error: "Could not determine company shortname from page." };
    }

    if (typeof onStatus === "function") {
      onStatus("Resolving mapped customer types…");
    }

    const companyResult = await shared.fetchCompanyData(company);
    const processorCurrency = companyResult.ok
      ? shared.getProcessorCurrency(companyResult.company)
      : null;

    const affiliationResult = await shared.findAffiliateAffiliation(company, INTEGRATION_KEY);
    let priceSheets = [];
    let sheetHeaders = [];

    if (typeof onStatus === "function") {
      onStatus("Loading Viator price sheets…");
    }

    if (affiliationResult.ok && affiliationResult.assignedPricing) {
      if (affiliationResult.assignedPricing.type === "schedule") {
        priceScheduleCount = 1;
      }
      const sheetsResult = await shared.resolveAffiliatePriceSheets(
        company,
        affiliationResult.assignedPricing
      );
      if (sheetsResult.ok) {
        priceSheets = sheetsResult.sheets;
        priceSheetCount = priceSheets.length;
        sheetHeaders = shared.buildDisambiguatedSheetHeaders(priceSheets);
      } else {
        warnings.push({
          kind: "price-sheets",
          message: sheetsResult.error || "Could not resolve Viator price sheets"
        });
      }
    } else {
      warnings.push({
        kind: "price-sheets",
        message:
          affiliationResult.error ||
          "Copied the Viator mapping file, but no Viator-associated price sheets could be resolved."
      });
    }

    const caches = {
      mappingCache: new Map(),
      itemMappedTypesCache: new Map(),
      priceCache: new Map()
    };

    const itemGroups = groupRowsByItemId(scrapedRows);
    const uniqueItemIds = [...itemGroups.keys()];

    const pricingTasks = [];
    for (const itemId of uniqueItemIds) {
      for (const sheet of priceSheets) {
        pricingTasks.push({ itemId, sheetPk: sheet.pk });
      }
    }

    if (pricingTasks.length > 0 && typeof onStatus === "function") {
      onStatus(`Reading prices 0 of ${pricingTasks.length}…`);
    }

    let pricingCompleted = 0;
    await shared.runWithConcurrencyLimit(
      pricingTasks,
      shared.CONCURRENCY_LIMIT,
      async (task) => {
        await loadPricingForSheetItem(shared, company, task.sheetPk, task.itemId, caches.priceCache);
        pricingCompleted += 1;
        if (typeof onStatus === "function") {
          onStatus(`Reading prices ${pricingCompleted} of ${pricingTasks.length}…`);
        }
      }
    );

    if (typeof onStatus === "function") {
      onStatus("Preparing mapping file…");
    }

    const tsvHeaders = [
      "FareHarbor Item",
      "Viator Product ID",
      "Item Name",
      "Ticket Category",
      "Mapped Customer Types",
      ...sheetHeaders
    ];

    const htmlHeaders = [
      "FareHarbor Item",
      "FareHarbor Name & Item ID",
      "Ticket Category",
      "Mapped Customer Types",
      ...sheetHeaders
    ];

    const tsvRows = [tsvHeaders];
    let html =
      '<table border="1" cellpadding="5" cellspacing="0">\n<thead>\n<tr>\n';
    for (const header of htmlHeaders) {
      html += `<th>${shared.escapeHtmlText(header)}</th>\n`;
    }
    html += "</tr>\n</thead>\n<tbody>\n";

    for (const row of scrapedRows || []) {
      const itemLabelText = getItemLabelText(row);
      const itemId = row.itemId || extractIdNumber(itemLabelText);
      const itemNumber = extractIdNumber(itemLabelText);
      const itemName = extractItemName(itemLabelText);
      const ticketCategoryTsv = formatTicketCategoryForTsv(row);

      const cacheKey = `${itemId}:${row.resellerItemId || ""}:${row.channelOption || ""}`;
      let mappedTypes = [];
      if (caches.itemMappedTypesCache.has(cacheKey)) {
        mappedTypes = caches.itemMappedTypesCache.get(cacheKey);
      } else if (itemId) {
        const resolved = await resolveRowMappedCustomerTypes(
          shared,
          company,
          itemId,
          row,
          caches,
          pageUrl
        );
        mappedTypes = resolved.mappedTypes;
        warnings.push(...resolved.warnings);
        caches.itemMappedTypesCache.set(cacheKey, mappedTypes);
        if (mappedTypes.length > 0) mappingCustomerTypeSuccessCount += 1;
      } else {
        warnings.push({
          kind: "customer-type-mapping",
          itemId: null,
          resellerItemId: row.resellerItemId || null,
          message: "Could not determine item ID for row"
        });
      }

      const mappedTypesTsv = formatMappedTypesForTsv(mappedTypes);
      const priceCells = [];

      for (const sheet of priceSheets) {
        const pricingKey = `${company}:${sheet.pk}:${itemId}`;
        const pricingEntry = caches.priceCache.get(pricingKey);
        if (!pricingEntry || !pricingEntry.ok) {
          if (pricingEntry && !pricingEntry.ok) {
            warnings.push({
              kind: "price-sheet",
              itemId,
              sheetPk: sheet.pk,
              message: pricingEntry.error
            });
          }
          priceCells.push("");
          continue;
        }

        const pricesByTypeKey = shared.collectPricesForMappedTypes(
          mappedTypes,
          pricingEntry.pricingRows,
          processorCurrency
        );
        const cellText = shared.formatCustomerTypePricesCell(
          mappedTypes,
          pricesByTypeKey,
          processorCurrency
        );
        if (cellText) priceCellsPopulated += 1;
        priceCells.push(cellText);
      }

      const tsvRow = [
        row.channelOption || "",
        itemNumber,
        itemName,
        ticketCategoryTsv,
        mappedTypesTsv,
        ...priceCells
      ];
      tsvRows.push(tsvRow);

      html += "<tr>\n";
      html += `<td><strong>${shared.escapeHtmlText(row.channelOption || "")}</strong></td>\n`;
      const itemLabelContent = row.itemLabelHTML || shared.escapeHtmlText(row.itemLabel || "");
      html += `<td>${itemLabelContent}</td>\n`;
      html += `<td>${formatTicketCategoryForHtml(row)}</td>\n`;
      html += `<td>${formatMappedTypesForHtml(mappedTypes)}</td>\n`;

      for (let index = 0; index < priceSheets.length; index += 1) {
        const sheet = priceSheets[index];
        const pricingKey = `${company}:${sheet.pk}:${itemId}`;
        const pricingEntry = caches.priceCache.get(pricingKey);
        let htmlCell = "";
        if (pricingEntry?.ok) {
          const pricesByTypeKey = shared.collectPricesForMappedTypes(
            mappedTypes,
            pricingEntry.pricingRows,
            processorCurrency
          );
          htmlCell = shared.formatCustomerTypePricesHtmlCell(
            mappedTypes,
            pricesByTypeKey,
            processorCurrency
          );
        }
        html += `<td>${htmlCell}</td>\n`;
      }

      html += "</tr>\n";
    }

    html += "</tbody>\n</table>";

    let tsvData;
    try {
      tsvData = shared.serializeTsvTable(tsvRows);
    } catch (error) {
      return {
        ok: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }

    const mappingCount = scrapedRows.length;
    const summaryMessage =
      priceSheetCount > 0
        ? `Copied ${mappingCount} mappings with ${priceSheetCount} price sheets.`
        : `Copied ${mappingCount} mappings, but no Viator-associated price sheets could be resolved.`;

    console.info(LOG_PREFIX, "Price enrichment completed", {
      mappingCount,
      mappingCustomerTypeSuccessCount,
      priceScheduleCount,
      priceSheetCount,
      priceCellsPopulated,
      warningCount: warnings.length
    });

    return {
      ok: true,
      tsvData,
      htmlData: html,
      warnings,
      summaryMessage,
      hasPriceSheetWarning: priceSheetCount === 0
    };
  }

  window.ViatorMappingPricingEnrichment = {
    enrichViatorMappingOutput
  };

  log("Module initialized successfully");
})();
