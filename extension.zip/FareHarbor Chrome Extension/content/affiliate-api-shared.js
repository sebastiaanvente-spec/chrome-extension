(function initializeFareHarborAffiliateApi() {
  "use strict";

  /** @type {Map<string, { ok: boolean, detail: object | null, error: string | null }>} */
  const affiliateDetailCache = new Map();
  /** @type {Map<string, { ok: boolean, detail: object | null, error: string | null, status: number | null }>} */
  const affiliateDetailV2Cache = new Map();
  /** @type {Map<string, { ok: boolean, policies: object[] | null, error: string | null }>} */
  const cancellationPoliciesListCache = new Map();
  /** @type {{ ok: boolean, apps: object[] | null, error: string | null } | null} */
  let resellerAppsCache = null;
  /** @type {Promise<{ ok: boolean, apps: object[] | null, error: string | null }> | null} */
  let resellerAppsInflight = null;
  /** @type {object | null} */
  let resellerAppCompanyMapSessionCache = null;

  function sendRuntimeMessage(message) {
    return new Promise((resolve) => {
      if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
        resolve({
          success: false,
          error: "chrome.runtime.sendMessage is unavailable"
        });
        return;
      }

      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          resolve({
            success: false,
            error: chrome.runtime.lastError.message
          });
          return;
        }
        resolve(response || { success: false, error: "Empty background response" });
      });
    });
  }

  function normalizeMappingDatabaseFromBackground(response) {
    const document =
      response?.document && typeof response.document === "object"
        ? response.document
        : null;
    if (!document) {
      return null;
    }

    return {
      schemaVersion: document.schemaVersion ?? 1,
      generatedAt:
        typeof document.generatedAt === "string" ? document.generatedAt : null,
      mapping:
        document.mapping && typeof document.mapping === "object"
          ? document.mapping
          : {},
      duplicates:
        document.duplicates && typeof document.duplicates === "object"
          ? document.duplicates
          : {},
      inactiveOnly:
        document.inactiveOnly && typeof document.inactiveOnly === "object"
          ? document.inactiveOnly
          : {},
      failedApps: Array.isArray(document.failedApps) ? document.failedApps : [],
      stats: document.stats && typeof document.stats === "object" ? document.stats : {}
    };
  }

  async function loadResellerAppCompanyMap() {
    if (resellerAppCompanyMapSessionCache) {
      return {
        ok: true,
        database: resellerAppCompanyMapSessionCache.database,
        metadata: resellerAppCompanyMapSessionCache.metadata
      };
    }

    const response = await sendRuntimeMessage({
      action: "getResellerAppCompanyMap"
    });

    if (!response?.success) {
      console.warn("[affiliate-api-credentials-popup] channel app map failed", {
        error: response?.error || "Unable to load Channel app mapping"
      });
      return {
        ok: false,
        database: null,
        error: response?.error || "Unable to load Channel app mapping"
      };
    }

    const database = normalizeMappingDatabaseFromBackground(response);
    if (!database) {
      return {
        ok: false,
        database: null,
        error: "Channel app mapping response was invalid"
      };
    }

    console.log("[affiliate-api-credentials-popup] channel app map loaded", {
      source: response.metadata?.source ?? null,
      schemaVersion: database.schemaVersion,
      generatedAt: database.generatedAt,
      mappingCount: Object.keys(database.mapping || {}).length
    });

    resellerAppCompanyMapSessionCache = {
      database,
      metadata: response.metadata || null
    };

    return {
      ok: true,
      database,
      metadata: response.metadata || null
    };
  }

  const CANCELLATION_POLICY_PK_FROM_URI_RE = /cancellation-policies\/(\d+)/i;
  const API_CANCELLATION_POLICY_URI_RE =
    /^\/api\/v1\/companies\/([^/]+)\/cancellation-policies\/(\d+)\/?$/i;
  const DASHBOARD_PATH_RE = /\/dashboard\//i;
  const POLICY_URL_FIELDS = [
    "dashboard_url",
    "url",
    "admin_url",
    "link",
    "href"
  ];
  const LINK_UNAVAILABLE_TITLE = "Policy found, but settings link unavailable";
  const POPUP_LOG_PREFIX = "[affiliate-api-credentials-popup]";
  const AFFILIATE_KEYS_PERMISSION_MESSAGE =
    "Affiliate API key unavailable — insufficient permissions";
  const CHANNEL_APP_PERMISSION_MESSAGE =
    "Channel app key unavailable — insufficient permissions";

  function buildAffiliateDetailV2CacheKey(shortname, affiliationPk) {
    return `v2|${shortname}|${affiliationPk}`;
  }

  function popupLog(message, detail) {
    if (detail !== undefined) {
      console.log(POPUP_LOG_PREFIX, message, detail);
      return;
    }
    console.log(POPUP_LOG_PREFIX, message);
  }

  function isPermissionDeniedStatus(status) {
    return status === 401 || status === 403;
  }

  function permissionMessageForStatus(status, fallbackMessage) {
    if (isPermissionDeniedStatus(status)) {
      return fallbackMessage;
    }
    return null;
  }

  function buildAffiliateDetailCacheKey(shortname, affiliationPk) {
    return `${shortname}|${affiliationPk}`;
  }

  function buildCancellationPoliciesListCacheKey(shortname) {
    return `${shortname}|cancellation-policies-list`;
  }

  async function apiGetJson(url) {
    try {
      const response = await fetch(url, {
        method: "GET",
        credentials: "include",
        headers: { Accept: "application/json" }
      });

      if (!response.ok) {
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `API request failed with status ${response.status}`
        };
      }

      try {
        const data = await response.json();
        return { ok: true, status: response.status, data, error: null };
      } catch (err) {
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `Response is not valid JSON: ${err.message}`
        };
      }
    } catch (err) {
      return {
        ok: false,
        status: null,
        data: null,
        error: `Fetch failed: ${err.message}`
      };
    }
  }

  function parseAffiliateDetailFromResponse(data) {
    if (!data || typeof data !== "object") {
      return null;
    }
    const affiliation = data.affiliation;
    if (!affiliation || typeof affiliation !== "object") {
      return null;
    }
    return affiliation;
  }

  async function fetchAffiliateDetail(shortname, affiliationPk) {
    const cacheKey = buildAffiliateDetailCacheKey(shortname, affiliationPk);
    if (affiliateDetailCache.has(cacheKey)) {
      return affiliateDetailCache.get(cacheKey);
    }

    const url = `/api/v1/companies/${encodeURIComponent(shortname)}/affiliates/${encodeURIComponent(affiliationPk)}/`;
    const result = await apiGetJson(url);

    if (!result.ok) {
      const cached = { ok: false, detail: null, error: result.error };
      affiliateDetailCache.set(cacheKey, cached);
      return cached;
    }

    const detail = parseAffiliateDetailFromResponse(result.data);
    if (!detail) {
      const cached = {
        ok: false,
        detail: null,
        error: "Affiliate detail response is invalid"
      };
      affiliateDetailCache.set(cacheKey, cached);
      return cached;
    }

    const cached = { ok: true, detail, error: null };
    affiliateDetailCache.set(cacheKey, cached);
    return cached;
  }

  async function fetchAffiliateDetailV2(shortname, affiliationPk) {
    const cacheKey = buildAffiliateDetailV2CacheKey(shortname, affiliationPk);
    if (affiliateDetailV2Cache.has(cacheKey)) {
      return affiliateDetailV2Cache.get(cacheKey);
    }

    const url = `/api-affiliations-v2/companies/${encodeURIComponent(shortname)}/affiliates/${encodeURIComponent(affiliationPk)}/`;
    const result = await apiGetJson(url);

    if (!result.ok) {
      const cached = {
        ok: false,
        detail: null,
        error: result.error,
        status: result.status ?? null
      };
      affiliateDetailV2Cache.set(cacheKey, cached);
      return cached;
    }

    const detail = parseAffiliateDetailFromResponse(result.data);
    if (!detail) {
      const cached = {
        ok: false,
        detail: null,
        error: "Affiliate detail response is invalid",
        status: result.status ?? null
      };
      affiliateDetailV2Cache.set(cacheKey, cached);
      return cached;
    }

    const cached = { ok: true, detail, error: null, status: result.status ?? null };
    affiliateDetailV2Cache.set(cacheKey, cached);
    return cached;
  }

  async function fetchCancellationPoliciesList(shortname) {
    const cacheKey = buildCancellationPoliciesListCacheKey(shortname);
    if (cancellationPoliciesListCache.has(cacheKey)) {
      return cancellationPoliciesListCache.get(cacheKey);
    }

    const url = `/api/v1/companies/${encodeURIComponent(shortname)}/cancellation-policies/`;
    const result = await apiGetJson(url);

    if (!result.ok) {
      const cached = { ok: false, policies: null, error: result.error };
      cancellationPoliciesListCache.set(cacheKey, cached);
      return cached;
    }

    const policies = result.data?.cancellation_policies;
    if (!Array.isArray(policies)) {
      const cached = {
        ok: false,
        policies: null,
        error: "Response missing cancellation_policies array"
      };
      cancellationPoliciesListCache.set(cacheKey, cached);
      return cached;
    }

    const cached = { ok: true, policies, error: null };
    cancellationPoliciesListCache.set(cacheKey, cached);
    return cached;
  }

  function getCancellationPolicyPk(policy) {
    if (!policy || typeof policy !== "object") {
      return null;
    }
    if (policy.pk !== null && policy.pk !== undefined) {
      return String(policy.pk);
    }
    const uri = String(policy.uri ?? "");
    const match = uri.match(CANCELLATION_POLICY_PK_FROM_URI_RE);
    return match ? match[1] : null;
  }

  function extractAffiliateCancellationPolicySelection(detail) {
    const raw =
      detail?.cancellation_policy ?? detail?.cancellationPolicy ?? null;
    const explicitId =
      detail?.cancellation_policy_id ?? detail?.cancellationPolicyId ?? null;
    const selectedId =
      getCancellationPolicyPk(raw) ||
      (explicitId !== null && explicitId !== undefined && explicitId !== ""
        ? String(explicitId)
        : null);
    const selectedName =
      typeof raw?.name === "string" && raw.name.trim() !== ""
        ? raw.name.trim()
        : null;

    return { raw, selectedId, selectedName };
  }

  function findCancellationPolicyInList(policies, policyId, policyName) {
    if (!Array.isArray(policies)) {
      return null;
    }

    if (policyId) {
      const byId = policies.find(
        (policy) => String(policy?.pk) === String(policyId)
      );
      if (byId) {
        return byId;
      }
    }

    if (policyName) {
      const normalizedName = policyName.trim().toLowerCase();
      const byName = policies.find((policy) => {
        if (typeof policy?.name !== "string") {
          return false;
        }
        return policy.name.trim().toLowerCase() === normalizedName;
      });
      if (byName) {
        return byName;
      }
    }

    return null;
  }

  function normalizeUrlValue(value) {
    if (value === null || value === undefined) {
      return null;
    }
    const text = String(value).trim();
    return text !== "" ? text : null;
  }

  function toRelativeDashboardPath(value) {
    const text = normalizeUrlValue(value);
    if (!text) {
      return null;
    }

    if (/^https?:\/\//i.test(text)) {
      try {
        const parsed = new URL(text);
        if (!DASHBOARD_PATH_RE.test(parsed.pathname)) {
          return null;
        }
        return `${parsed.pathname}${parsed.search}${parsed.hash}`;
      } catch {
        return null;
      }
    }

    if (!text.startsWith("/")) {
      return null;
    }

    return DASHBOARD_PATH_RE.test(text) ? text : null;
  }

  function pickDashboardUrlFromFields(obj) {
    if (!obj || typeof obj !== "object") {
      return null;
    }

    for (const field of POLICY_URL_FIELDS) {
      const raw = normalizeUrlValue(obj[field]);
      if (!raw) {
        continue;
      }
      if (/\/api\/v1\//i.test(raw)) {
        continue;
      }
      const dashboardPath = toRelativeDashboardPath(raw);
      if (dashboardPath) {
        return dashboardPath;
      }
    }

    return null;
  }

  function buildCancellationPolicyDashboardUrlFromApiUri(apiUri, shortname) {
    const match = String(apiUri || "").match(API_CANCELLATION_POLICY_URI_RE);
    if (!match) {
      return null;
    }

    const companyShortname = shortname || decodeURIComponent(match[1]);
    const policyPk = match[2];
    if (!companyShortname || !policyPk) {
      return null;
    }

    return `/${encodeURIComponent(companyShortname)}/dashboard/settings/cancellation-policies/${encodeURIComponent(policyPk)}/`;
  }

  function buildCancellationPolicyDashboardUrl(shortname, policyPk, policyUri) {
    if (policyUri) {
      const fromApiUri = buildCancellationPolicyDashboardUrlFromApiUri(
        policyUri,
        shortname
      );
      if (fromApiUri) {
        return fromApiUri;
      }
    }

    if (shortname && policyPk) {
      return buildCancellationPolicyDashboardUrlFromApiUri(
        `/api/v1/companies/${encodeURIComponent(shortname)}/cancellation-policies/${encodeURIComponent(policyPk)}/`,
        shortname
      );
    }

    return null;
  }

  function buildNormalizedCancellationPolicyResult({
    cancellationPolicyId,
    cancellationPolicyName,
    cancellationPolicySummary,
    cancellationPolicyUrl,
    urlUnresolvedReason
  }) {
    const titleText = cancellationPolicySummary
      ? `${cancellationPolicyName}\n${cancellationPolicySummary}`
      : cancellationPolicyName;

    return {
      cancellationPolicyId,
      cancellationPolicyName,
      cancellationPolicySummary,
      cancellationPolicyUrl,
      name: cancellationPolicyName,
      displayText: cancellationPolicyName,
      titleText: cancellationPolicyName ? titleText : null,
      linkUnavailableTitle:
        cancellationPolicyUrl || !cancellationPolicyName
          ? null
          : LINK_UNAVAILABLE_TITLE,
      debug: {
        urlUnresolvedReason: cancellationPolicyUrl ? null : urlUnresolvedReason
      }
    };
  }

  async function resolveAffiliateCancellationPolicy(shortname, detail) {
    const selection = extractAffiliateCancellationPolicySelection(detail);
    const { raw, selectedId, selectedName } = selection;

    if (!raw && !selectedId && !selectedName) {
      return buildNormalizedCancellationPolicyResult({
        cancellationPolicyId: null,
        cancellationPolicyName: null,
        cancellationPolicySummary: null,
        cancellationPolicyUrl: null,
        urlUnresolvedReason: "affiliate detail has no cancellation policy selection"
      });
    }

    const listResult = await fetchCancellationPoliciesList(shortname);
    let listPolicy = null;
    let urlUnresolvedReason = null;

    if (!listResult.ok) {
      urlUnresolvedReason = `cancellation policies list fetch failed: ${listResult.error}`;
    } else {
      listPolicy = findCancellationPolicyInList(
        listResult.policies,
        selectedId,
        selectedName
      );
      if (!listPolicy) {
        urlUnresolvedReason = selectedId
          ? `no cancellation policy found in list for id ${selectedId}`
          : `no cancellation policy found in list for name ${selectedName || "(missing)"}`;
      }
    }

    const resolvedPolicy = listPolicy || raw;
    const cancellationPolicyId =
      getCancellationPolicyPk(resolvedPolicy) || selectedId;
    const cancellationPolicyName =
      (typeof resolvedPolicy?.name === "string" && resolvedPolicy.name.trim() !== ""
        ? resolvedPolicy.name.trim()
        : null) || selectedName;
    const cancellationPolicySummary =
      typeof resolvedPolicy?.description === "string" &&
      resolvedPolicy.description.trim() !== ""
        ? resolvedPolicy.description.trim()
        : null;

    if (!cancellationPolicyName) {
      return buildNormalizedCancellationPolicyResult({
        cancellationPolicyId,
        cancellationPolicyName: null,
        cancellationPolicySummary: null,
        cancellationPolicyUrl: null,
        urlUnresolvedReason: "affiliate cancellation policy has no name"
      });
    }

    let cancellationPolicyUrl = pickDashboardUrlFromFields(resolvedPolicy);
    if (!cancellationPolicyUrl) {
      cancellationPolicyUrl = buildCancellationPolicyDashboardUrl(
        shortname,
        cancellationPolicyId,
        resolvedPolicy?.uri
      );
    }

    if (!cancellationPolicyUrl && !urlUnresolvedReason) {
      if (!cancellationPolicyId) {
        urlUnresolvedReason =
          "cancellation policy name found but no policy id could be resolved";
      } else if (!resolvedPolicy?.uri) {
        urlUnresolvedReason =
          "matched cancellation policy is missing uri needed to build settings link";
      } else {
        urlUnresolvedReason =
          "cancellation policy uri did not match the QC cancellation-policies route pattern";
      }
    }

    const result = buildNormalizedCancellationPolicyResult({
      cancellationPolicyId,
      cancellationPolicyName,
      cancellationPolicySummary,
      cancellationPolicyUrl,
      urlUnresolvedReason
    });

    result.debug = {
      ...result.debug,
      raw,
      selectedId,
      selectedName,
      listPolicyPk: listPolicy?.pk ?? null,
      listPolicyUri: listPolicy?.uri ?? null
    };

    return result;
  }

  function normalizeAffiliationCancellationPolicy(detail) {
    const selection = extractAffiliateCancellationPolicySelection(detail);
    if (!selection.selectedName && !selection.selectedId) {
      return buildNormalizedCancellationPolicyResult({
        cancellationPolicyId: null,
        cancellationPolicyName: null,
        cancellationPolicySummary: null,
        cancellationPolicyUrl: null,
        urlUnresolvedReason: null
      });
    }

    return buildNormalizedCancellationPolicyResult({
      cancellationPolicyId: selection.selectedId,
      cancellationPolicyName: selection.selectedName,
      cancellationPolicySummary: null,
      cancellationPolicyUrl: pickDashboardUrlFromFields(selection.raw),
      urlUnresolvedReason: null
    });
  }

  function normalizeAffiliateCompanyName(name) {
    return String(name || "")
      .replace(/\s*-\s*[A-Z]{3}\s*-\s*API\s*$/i, "")
      .replace(/\s*-\s*API\s*$/i, "")
      .trim()
      .toLowerCase();
  }

  function normalizeResellerAppName(name) {
    return String(name || "").trim().toLowerCase();
  }

  function parseAffiliateApiKeyFromUserResponse(data) {
    const user = data?.user ?? data;
    return parseCalendarTokenFromUserRecord(user);
  }

  function parseCalendarTokenFromUserRecord(user) {
    const calendarToken = user?.calendar_token;
    if (typeof calendarToken !== "string" || calendarToken.trim() === "") {
      return null;
    }
    return calendarToken.trim();
  }

  function normalizeComparableName(value) {
    return String(value || "")
      .replace(/\s*-\s*[A-Z]{3}\s*-\s*API\s*$/i, "")
      .replace(/\s*-\s*API\s*$/i, "")
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "");
  }

  function isEligibleApiUser(user) {
    if (!user || typeof user !== "object") {
      return false;
    }
    if (user.is_inactive === true) {
      return false;
    }
    if (user.has_api_keys === false) {
      return false;
    }
    return true;
  }

  function toSafeApiUserCandidateMetadata(user) {
    return {
      username:
        typeof user?.username === "string" && user.username.trim() !== ""
          ? user.username.trim()
          : null,
      name:
        typeof user?.name === "string" && user.name.trim() !== ""
          ? user.name.trim()
          : null,
      hasApiKeys: user?.has_api_keys === true
    };
  }

  function collectApiUsernameCandidates(users) {
    return (Array.isArray(users) ? users : []).filter((user) => {
      const username = String(user?.username || "").toLowerCase();
      return isEligibleApiUser(user) && username.includes("api");
    });
  }

  function candidateMatchesAffiliateBrand(user, affiliateBrand) {
    if (!affiliateBrand) {
      return false;
    }
    const normalizedUsername = normalizeComparableName(user?.username);
    const normalizedName = normalizeComparableName(user?.name);
    return (
      normalizedUsername.includes(affiliateBrand) ||
      normalizedName.includes(affiliateBrand)
    );
  }

  function resolveAffiliateApiUserFromList(users, affiliateCompanyName) {
    const allUsers = Array.isArray(users) ? users : [];
    const affiliateBrand = normalizeComparableName(affiliateCompanyName);

    const exactApiUsers = allUsers.filter((user) => {
      return (
        isEligibleApiUser(user) &&
        String(user?.username || "").toLowerCase() === "api"
      );
    });

    if (exactApiUsers.length === 1) {
      return {
        status: "resolved",
        user: exactApiUsers[0],
        candidates: exactApiUsers.map(toSafeApiUserCandidateMetadata),
        errorMessage: null
      };
    }

    if (exactApiUsers.length > 1) {
      return {
        status: "ambiguous",
        user: null,
        candidates: exactApiUsers.map(toSafeApiUserCandidateMetadata),
        errorMessage: "Multiple API users found"
      };
    }

    const candidates = collectApiUsernameCandidates(allUsers);
    const safeCandidates = candidates.map(toSafeApiUserCandidateMetadata);
    const preferredCandidates = candidates.filter((user) => user.has_api_keys === true);

    if (candidates.length === 0) {
      return {
        status: "not_found",
        user: null,
        candidates: [],
        errorMessage: "API user not found"
      };
    }

    if (preferredCandidates.length === 1) {
      return {
        status: "resolved",
        user: preferredCandidates[0],
        candidates: safeCandidates,
        errorMessage: null
      };
    }

    if (candidates.length === 1) {
      return {
        status: "resolved",
        user: candidates[0],
        candidates: safeCandidates,
        errorMessage: null
      };
    }

    const brandMatches = candidates.filter((user) =>
      candidateMatchesAffiliateBrand(user, affiliateBrand)
    );

    if (brandMatches.length === 1) {
      return {
        status: "resolved",
        user: brandMatches[0],
        candidates: safeCandidates,
        errorMessage: null
      };
    }

    if (brandMatches.length > 1) {
      return {
        status: "ambiguous",
        user: null,
        candidates: safeCandidates,
        errorMessage: "Multiple API users found"
      };
    }

    return {
      status: "ambiguous",
      user: null,
      candidates: safeCandidates,
      errorMessage: "Could not reliably identify the affiliate API user"
    };
  }

  function findApiUserCandidates(users) {
    return collectApiUsernameCandidates(users);
  }

  async function fetchAffiliateApiUserDetail(shortname, username) {
    const url = `/api/v1/companies/${encodeURIComponent(shortname)}/users/${encodeURIComponent(username)}/`;
    return apiGetJson(url);
  }

  async function fetchAffiliateApiUserKey(shortname, user) {
    const username =
      typeof user?.username === "string" && user.username.trim() !== ""
        ? user.username.trim()
        : null;
    if (!username) {
      return null;
    }

    let key = parseCalendarTokenFromUserRecord(user);
    if (!key) {
      popupLog("loading API user detail", { username });
      const detailResult = await fetchAffiliateApiUserDetail(shortname, username);
      if (!detailResult.ok) {
        popupLog("API user detail failed", {
          username,
          status: detailResult.status ?? null,
          error: detailResult.error
        });
        return null;
      }
      key = parseAffiliateApiKeyFromUserResponse(detailResult.data);
    }

    return key;
  }

  async function fetchAffiliateApiKey(affiliateShortname, affiliateCompanyName) {
    const shortname = String(affiliateShortname || "").trim();
    if (!shortname) {
      return {
        ok: false,
        key: null,
        userName: null,
        username: null,
        error: "Missing affiliate shortname",
        status: null,
        resolutionStatus: "error",
        errorMessage: null,
        candidates: null
      };
    }

    popupLog("loading affiliate users", { endpoint: "affiliate-users-list" });
    const listUrl = `/api/v1/companies/${encodeURIComponent(shortname)}/users/?include_integration_data=yes`;
    const listResult = await apiGetJson(listUrl);

    if (!listResult.ok) {
      return {
        ok: false,
        key: null,
        userName: null,
        username: null,
        error: listResult.error,
        status: listResult.status ?? null,
        resolutionStatus: "error",
        errorMessage: null,
        candidates: null
      };
    }

    const users = listResult.data?.users;
    if (!Array.isArray(users)) {
      return {
        ok: false,
        key: null,
        userName: null,
        username: null,
        error: "Response missing users array",
        status: listResult.status ?? null,
        resolutionStatus: "error",
        errorMessage: null,
        candidates: null
      };
    }

    const userResolution = resolveAffiliateApiUserFromList(users, affiliateCompanyName);
    popupLog("API user candidates found", {
      count: userResolution.candidates.length,
      candidates: userResolution.candidates,
      resolutionStatus: userResolution.status
    });

    if (userResolution.status !== "resolved" || !userResolution.user) {
      return {
        ok: true,
        key: null,
        userName: null,
        username: null,
        error: null,
        status: listResult.status ?? null,
        resolutionStatus: userResolution.status,
        errorMessage: userResolution.errorMessage,
        candidates: userResolution.candidates
      };
    }

    const resolvedUser = userResolution.user;
    const key = await fetchAffiliateApiUserKey(shortname, resolvedUser);
    const username =
      typeof resolvedUser?.username === "string" && resolvedUser.username.trim() !== ""
        ? resolvedUser.username.trim()
        : null;
    const userName =
      typeof resolvedUser?.name === "string" && resolvedUser.name.trim() !== ""
        ? resolvedUser.name.trim()
        : null;

    if (!key) {
      return {
        ok: true,
        key: null,
        userName,
        username,
        error: null,
        status: listResult.status ?? null,
        resolutionStatus: "empty",
        errorMessage: "Affiliate API key not found",
        candidates: userResolution.candidates
      };
    }

    return {
      ok: true,
      key,
      userName,
      username,
      error: null,
      status: listResult.status ?? null,
      resolutionStatus: "resolved",
      errorMessage: null,
      candidates: userResolution.candidates
    };
  }

  function mapAppsForResult(matches) {
    return matches.map((app) => ({
      name: app.name ?? "(unnamed)",
      pk: app.pk ?? null
    }));
  }

  function normalizeAffiliateBrand(value) {
    return String(value || "")
      .replace(/\s*-\s*[A-Z]{3}\s*-\s*API\s*$/i, "")
      .replace(/\s*-\s*API\s*$/i, "")
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "");
  }

  function normalizeAppComparable(value) {
    return String(value || "")
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "");
  }

  function resellerAppHasKey(app) {
    return Boolean(app && typeof app.key === "string" && app.key.trim() !== "");
  }

  function toSafeChannelAppMatchMetadata(app) {
    return {
      pk: app?.pk ?? null,
      name: app?.name ?? "(unnamed)",
      shortName: app?.short_name || "",
      isInactive: app?.is_inactive === true
    };
  }

  function logChannelAppResolution(affiliateCompanyName, resolution) {
    console.log("[affiliate-api-credentials-popup] channel app resolution", {
      affiliateCompanyName,
      affiliateBrand: resolution.affiliateBrand ?? null,
      status: resolution.status,
      matchType: resolution.matchType ?? null,
      matches: (resolution.matches || []).map(toSafeChannelAppMatchMetadata)
    });
  }

  function resolveChannelAppAtPrecedence(matches, matchType, affiliateBrand) {
    const withKey = (Array.isArray(matches) ? matches : []).filter(resellerAppHasKey);
    const activeMatches = withKey.filter((app) => app.is_inactive !== true);
    const inactiveMatches = withKey.filter((app) => app.is_inactive === true);

    if (activeMatches.length === 1) {
      const match = activeMatches[0];
      return {
        status: "resolved",
        matchType,
        affiliateBrand,
        key: match.key.trim(),
        appName: match.name ?? null,
        appPk: match.pk ?? null,
        matches: withKey
      };
    }

    if (activeMatches.length > 1) {
      return {
        status: "ambiguous",
        matchType,
        affiliateBrand,
        key: null,
        appName: null,
        appPk: null,
        matches: activeMatches
      };
    }

    if (inactiveMatches.length > 0) {
      const match = inactiveMatches.length === 1 ? inactiveMatches[0] : null;
      return {
        status: inactiveMatches.length === 1 ? "inactive" : "ambiguous",
        matchType,
        affiliateBrand,
        key: null,
        appName: match?.name ?? null,
        appPk: match?.pk ?? null,
        matches: inactiveMatches
      };
    }

    return null;
  }

  function normalizeMappingShortname(shortname) {
    return String(shortname || "").trim().toLowerCase();
  }

  function emptyResellerAppCompanyMap() {
    return {
      schemaVersion: 1,
      generatedAt: null,
      mapping: {},
      duplicates: {},
      inactiveOnly: {},
      failedApps: [],
      stats: {}
    };
  }

  function resolveChannelAppFromStaticMapping({
    affiliateShortname,
    resellerApps,
    database,
    affiliateCompanyName
  }) {
    const normalizedShortname = normalizeMappingShortname(affiliateShortname);
    if (!normalizedShortname || !database) {
      return { status: "not_in_database" };
    }

    console.log("[affiliate-api-credentials-popup] static channel app lookup", {
      affiliateShortname: normalizedShortname,
      hasMapping: Object.prototype.hasOwnProperty.call(
        database.mapping || {},
        normalizedShortname
      ),
      mappedAppPk: database.mapping?.[normalizedShortname] ?? null
    });

    const staticResolution = resolveChannelAppFromStaticMap(
      normalizedShortname,
      database,
      resellerApps
    );
    if (!staticResolution) {
      return { status: "not_in_database" };
    }

    logChannelAppResolution(
      affiliateCompanyName || normalizedShortname,
      staticResolution
    );
    return formatChannelAppResolution(staticResolution);
  }

  function resolveChannelAppFromStaticMap(
    normalizedShortname,
    staticMap,
    resellerApps
  ) {
    if (
      staticMap.duplicates &&
      Object.prototype.hasOwnProperty.call(
        staticMap.duplicates,
        normalizedShortname
      )
    ) {
      const duplicatePks = staticMap.duplicates[normalizedShortname];
      const apps = Array.isArray(resellerApps) ? resellerApps : [];
      const matches = (Array.isArray(duplicatePks) ? duplicatePks : [])
        .map((pk) => apps.find((app) => Number(app.pk) === Number(pk)))
        .filter(Boolean);

      return {
        status: "ambiguous",
        matchType: "static_shortname_mapping",
        affiliateBrand: normalizedShortname,
        errorMessage: "Multiple Channel app relationships found",
        matches
      };
    }

    const mappedPk = staticMap.mapping?.[normalizedShortname];
    if (mappedPk == null) {
      return null;
    }

    const apps = Array.isArray(resellerApps) ? resellerApps : [];
    const app = apps.find(
      (entry) => Number(entry.pk) === Number(mappedPk)
    );
    if (!app) {
      return {
        status: "unresolved",
        matchType: "static_shortname_mapping",
        affiliateBrand: normalizedShortname,
        errorMessage: "Stored Channel app mapping is outdated",
        matches: []
      };
    }

    if (app.is_inactive === true) {
      return {
        status: "inactive",
        matchType: "static_shortname_mapping",
        affiliateBrand: normalizedShortname,
        errorMessage: "Stored Channel app mapping points to an inactive app",
        appName: app.name ?? null,
        appPk: app.pk ?? null,
        matches: []
      };
    }

    if (!resellerAppHasKey(app)) {
      return {
        status: "unresolved",
        matchType: "static_shortname_mapping",
        affiliateBrand: normalizedShortname,
        errorMessage: "Channel app key unavailable",
        appName: app.name ?? null,
        appPk: app.pk ?? null,
        matches: []
      };
    }

    return {
      status: "resolved",
      matchType: "static_shortname_mapping",
      affiliateBrand: normalizedShortname,
      key: app.key.trim(),
      appName: app.name ?? null,
      appPk: app.pk ?? null,
      matches: []
    };
  }

  function resolveChannelAppByName(affiliateCompanyName, resellerApps) {
    const affiliateBrand = normalizeAffiliateBrand(affiliateCompanyName);
    if (!affiliateBrand) {
      const resolution = {
        status: "unresolved",
        matchType: null,
        affiliateBrand: null,
        matches: []
      };
      logChannelAppResolution(affiliateCompanyName, resolution);
      return { status: "unresolved", reason: "missing affiliate company name" };
    }

    const apps = Array.isArray(resellerApps) ? resellerApps : [];

    const exactNameMatches = apps.filter(
      (app) =>
        resellerAppHasKey(app) &&
        normalizeAppComparable(app.name) === affiliateBrand
    );
    let resolution = resolveChannelAppAtPrecedence(
      exactNameMatches,
      "exact_name",
      affiliateBrand
    );
    if (resolution) {
      logChannelAppResolution(affiliateCompanyName, resolution);
      return resolution;
    }

    const exactShortNameMatches = apps.filter(
      (app) =>
        resellerAppHasKey(app) &&
        normalizeAppComparable(app.short_name) === affiliateBrand
    );
    resolution = resolveChannelAppAtPrecedence(
      exactShortNameMatches,
      "exact_short_name",
      affiliateBrand
    );
    if (resolution) {
      logChannelAppResolution(affiliateCompanyName, resolution);
      return resolution;
    }

    if (affiliateBrand.length >= 4) {
      const leadingNameMatches = apps.filter(
        (app) =>
          resellerAppHasKey(app) &&
          normalizeAppComparable(app.name).startsWith(affiliateBrand)
      );
      resolution = resolveChannelAppAtPrecedence(
        leadingNameMatches,
        "leading_name",
        affiliateBrand
      );
      if (resolution) {
        logChannelAppResolution(affiliateCompanyName, resolution);
        return resolution;
      }
    }

    resolution = {
      status: "unresolved",
      matchType: null,
      affiliateBrand,
      matches: []
    };
    logChannelAppResolution(affiliateCompanyName, resolution);
    return resolution;
  }

  function resolveChannelApp(affiliateCompanyName, resellerApps, options = {}) {
    const staticMap =
      options.staticMap && typeof options.staticMap === "object"
        ? options.staticMap
        : null;
    const normalizedShortname = normalizeMappingShortname(
      options.affiliateShortname
    );

    if (staticMap && normalizedShortname) {
      const staticResult = resolveChannelAppFromStaticMapping({
        affiliateShortname: normalizedShortname,
        resellerApps,
        database: staticMap,
        affiliateCompanyName
      });

      if (staticResult.status !== "not_in_database") {
        return staticResult;
      }

      const nameResolution = resolveChannelAppByName(
        affiliateCompanyName,
        resellerApps
      );
      const formatted = formatChannelAppResolution(nameResolution);
      if (formatted.status === "resolved") {
        return { ...formatted, matchType: "name_fallback" };
      }
      if (formatted.status === "unresolved") {
        return {
          ...formatted,
          errorMessage: "Channel app mapping not found"
        };
      }
      return formatted;
    }

    return formatChannelAppResolution(
      resolveChannelAppByName(affiliateCompanyName, resellerApps)
    );
  }

  function formatChannelAppResolution(resolution) {
    if (resolution.status === "resolved") {
      return {
        status: "resolved",
        matchType: resolution.matchType,
        key: resolution.key,
        appName: resolution.appName,
        appPk: resolution.appPk
      };
    }

    if (resolution.status === "inactive") {
      return {
        status: "inactive",
        matchType: resolution.matchType,
        appName: resolution.appName,
        appPk: resolution.appPk,
        errorMessage: resolution.errorMessage || null
      };
    }

    if (resolution.status === "ambiguous") {
      return {
        status: "ambiguous",
        matchType: resolution.matchType,
        matches: mapAppsForResult(resolution.matches),
        errorMessage: resolution.errorMessage || null
      };
    }

    return {
      status: "unresolved",
      errorMessage: resolution.errorMessage || null,
      appName: resolution.appName ?? null,
      appPk: resolution.appPk ?? null
    };
  }

  function resolveChannelAppKey(affiliateCompanyName, resellerApps) {
    return resolveChannelApp(affiliateCompanyName, resellerApps);
  }

  function extractAffiliateCompanyFields(detail) {
    const company = detail?.affiliate_company ?? detail?.affiliateCompany ?? null;
    if (!company || typeof company !== "object") {
      return { shortname: null, name: null, pk: null };
    }
    const shortname =
      typeof company.shortname === "string" && company.shortname.trim() !== ""
        ? company.shortname.trim()
        : null;
    const name =
      typeof company.name === "string" && company.name.trim() !== ""
        ? company.name.trim()
        : null;
    const pk = company.pk ?? null;
    return { shortname, name, pk };
  }

  async function fetchResellerApps(options = {}) {
    if (Array.isArray(options.cachedApps)) {
      return { ok: true, apps: options.cachedApps, error: null, status: null };
    }

    if (resellerAppsCache) {
      return resellerAppsCache;
    }
    if (resellerAppsInflight) {
      return resellerAppsInflight;
    }

    resellerAppsInflight = (async () => {
      const url = "/api/v1/companies/admin/reseller-apps/";
      const result = await apiGetJson(url);

      if (!result.ok) {
        const cached = {
          ok: false,
          apps: null,
          error: result.error,
          status: result.status ?? null
        };
        resellerAppsCache = cached;
        return cached;
      }

      const apps = result.data?.reseller_apps;
      if (!Array.isArray(apps)) {
        const cached = {
          ok: false,
          apps: null,
          error: "Response missing reseller_apps array",
          status: result.status ?? null
        };
        resellerAppsCache = cached;
        return cached;
      }

      const cached = { ok: true, apps, error: null, status: result.status ?? null };
      resellerAppsCache = cached;
      return cached;
    })();

    try {
      return await resellerAppsInflight;
    } finally {
      resellerAppsInflight = null;
    }
  }

  async function lookupAffiliateApiCredentials(companyShortname, affiliationPk, options = {}) {
    const AFFILIATE_DETAIL_ENDPOINT = "api/v1 affiliate detail";
    const AFFILIATE_DETAIL_READ_ERROR =
      "Could not read affiliate details from FareHarbor.";

    popupLog("loading affiliate detail", {
      endpoint: AFFILIATE_DETAIL_ENDPOINT
    });

    const detailResult = await fetchAffiliateDetail(companyShortname, affiliationPk);
    if (!detailResult.ok) {
      popupLog("affiliate detail failed", {
        endpoint: AFFILIATE_DETAIL_ENDPOINT,
        status: detailResult.status ?? null,
        error: detailResult.error
      });
      return {
        ok: false,
        error: detailResult.error || "Unable to load affiliation detail",
        affiliate: { name: null, shortname: null },
        affiliateApiKey: {
          status: "error",
          key: null,
          errorMessage: "Unable to load affiliation detail",
          httpStatus: detailResult.status ?? null
        },
        channelApp: {
          status: "error",
          key: null,
          appName: null,
          appPk: null,
          matches: null,
          errorMessage: "Unable to load affiliation detail",
          httpStatus: detailResult.status ?? null
        }
      };
    }

    const detail = detailResult.detail;
    const affiliateCompany = detail?.affiliate_company ?? detail?.affiliateCompany ?? null;
    const affiliateShortname = affiliateCompany?.shortname ?? null;
    const affiliateCompanyName = affiliateCompany?.name ?? null;

    if (!detail || !affiliateShortname || !affiliateCompanyName) {
      popupLog("affiliate detail invalid", {
        endpoint: AFFILIATE_DETAIL_ENDPOINT,
        status: detailResult.status ?? null,
        error: detailResult.error || "missing affiliate_company fields"
      });
      return {
        ok: false,
        error: AFFILIATE_DETAIL_READ_ERROR,
        affiliate: {
          name: affiliateCompanyName,
          shortname: affiliateShortname
        },
        affiliateApiKey: {
          status: "error",
          key: null,
          errorMessage: AFFILIATE_DETAIL_READ_ERROR,
          httpStatus: detailResult.status ?? null
        },
        channelApp: {
          status: "error",
          key: null,
          appName: null,
          appPk: null,
          matches: null,
          errorMessage: AFFILIATE_DETAIL_READ_ERROR,
          httpStatus: detailResult.status ?? null
        }
      };
    }

    const companyFields = {
      shortname: String(affiliateShortname).trim(),
      name: String(affiliateCompanyName).trim(),
      pk: affiliateCompany?.pk ?? null
    };
    const affiliate = {
      name: companyFields.name,
      shortname: companyFields.shortname
    };

    let affiliateApiKeyResult = {
      status: "error",
      key: null,
      errorMessage: null,
      httpStatus: null
    };

    if (!companyFields.shortname) {
      affiliateApiKeyResult = {
        status: "error",
        key: null,
        errorMessage: AFFILIATE_DETAIL_READ_ERROR,
        httpStatus: null
      };
    } else {
      const apiKeyResult = await fetchAffiliateApiKey(
        companyFields.shortname,
        companyFields.name
      );
      if (!apiKeyResult.ok) {
        popupLog("affiliate users failed", {
          endpoint: "affiliate-users-list",
          status: apiKeyResult.status ?? null,
          error: apiKeyResult.error
        });
        let errorMessage = apiKeyResult.error || "Unable to load affiliate API key";
        if (apiKeyResult.status === 404) {
          errorMessage = "API user not found";
        } else {
          const permissionMessage = permissionMessageForStatus(
            apiKeyResult.status,
            AFFILIATE_KEYS_PERMISSION_MESSAGE
          );
          if (permissionMessage) {
            errorMessage = permissionMessage;
          }
        }
        affiliateApiKeyResult = {
          status: "error",
          key: null,
          errorMessage,
          httpStatus: apiKeyResult.status ?? null
        };
      } else if (apiKeyResult.resolutionStatus === "resolved" && apiKeyResult.key) {
        affiliateApiKeyResult = {
          status: "ok",
          key: apiKeyResult.key,
          errorMessage: null,
          httpStatus: apiKeyResult.status ?? null
        };
      } else if (apiKeyResult.resolutionStatus === "ambiguous") {
        affiliateApiKeyResult = {
          status: "error",
          key: null,
          errorMessage:
            apiKeyResult.errorMessage ||
            "Could not reliably identify the affiliate API user",
          httpStatus: apiKeyResult.status ?? null
        };
      } else if (apiKeyResult.resolutionStatus === "not_found") {
        affiliateApiKeyResult = {
          status: "error",
          key: null,
          errorMessage: apiKeyResult.errorMessage || "API user not found",
          httpStatus: apiKeyResult.status ?? null
        };
      } else {
        affiliateApiKeyResult = {
          status: "empty",
          key: null,
          errorMessage: apiKeyResult.errorMessage || "Affiliate API key not found",
          httpStatus: apiKeyResult.status ?? null
        };
      }
    }

    let channelAppResult = {
      status: "unresolved",
      key: null,
      appName: null,
      appPk: null,
      matches: null,
      errorMessage: "Channel app key not resolved",
      httpStatus: null
    };
    let resellerAppsForPopup = Array.isArray(options.cachedResellerApps)
      ? options.cachedResellerApps
      : null;

    if (!companyFields.name) {
      channelAppResult.errorMessage = "Channel app key not resolved";
    } else {
      popupLog("loading reseller apps", { endpoint: "reseller-apps" });
      const appsResult = await fetchResellerApps({
        cachedApps: options.cachedResellerApps
      });

      if (appsResult.ok && Array.isArray(appsResult.apps)) {
        resellerAppsForPopup = appsResult.apps;
      }

      if (!appsResult.ok) {
        popupLog("reseller apps failed", {
          endpoint: "reseller-apps",
          status: appsResult.status ?? null,
          error: appsResult.error
        });
        channelAppResult = {
          status: "error",
          key: null,
          appName: null,
          appPk: null,
          matches: null,
          errorMessage:
            permissionMessageForStatus(
              appsResult.status,
              CHANNEL_APP_PERMISSION_MESSAGE
            ) || appsResult.error || "Unable to load channel app keys",
          httpStatus: appsResult.status ?? null
        };
      } else {
        const affiliateShortnameForMapping = String(
          affiliateCompany?.shortname || ""
        )
          .trim()
          .toLowerCase();

        const mapLoadResult = await loadResellerAppCompanyMap();
        let resolved = null;

        if (mapLoadResult.ok && mapLoadResult.database) {
          const staticResult = resolveChannelAppFromStaticMapping({
            affiliateShortname: affiliateShortnameForMapping,
            resellerApps: appsResult.apps,
            database: mapLoadResult.database,
            affiliateCompanyName: companyFields.name
          });

          if (staticResult.status !== "not_in_database") {
            resolved = staticResult;
          }
        }

        if (!resolved) {
          const nameResolution = resolveChannelAppByName(
            companyFields.name,
            appsResult.apps
          );
          resolved = formatChannelAppResolution(nameResolution);
          if (resolved.status === "resolved") {
            resolved = { ...resolved, matchType: "name_fallback" };
          } else if (
            resolved.status === "unresolved" &&
            mapLoadResult.ok &&
            affiliateShortnameForMapping
          ) {
            resolved = {
              ...resolved,
              errorMessage: "Channel app mapping not found"
            };
          }
        }

        if (resolved.status === "resolved") {
          channelAppResult = {
            status: "resolved",
            key: resolved.key,
            appName: resolved.appName ?? null,
            appPk: resolved.appPk ?? null,
            matches: null,
            errorMessage: null,
            httpStatus: appsResult.status ?? null
          };
        } else if (resolved.status === "inactive") {
          channelAppResult = {
            status: "inactive",
            key: null,
            appName: resolved.appName ?? null,
            appPk: resolved.appPk ?? null,
            matches: null,
            errorMessage:
              resolved.errorMessage || "Matching channel app is inactive",
            httpStatus: appsResult.status ?? null
          };
        } else if (resolved.status === "ambiguous") {
          channelAppResult = {
            status: "ambiguous",
            key: null,
            appName: null,
            appPk: null,
            matches: resolved.matches ?? null,
            errorMessage:
              resolved.errorMessage || "Multiple matching channel apps found",
            httpStatus: appsResult.status ?? null
          };
        } else {
          channelAppResult = {
            status: "unresolved",
            key: null,
            appName: resolved.appPk != null ? resolved.appName ?? null : null,
            appPk: resolved.appPk ?? null,
            matches: null,
            errorMessage:
              resolved.errorMessage || "Channel app key not resolved",
            httpStatus: appsResult.status ?? null
          };
        }
      }
    }

    popupLog("lookup complete");

    return {
      ok: true,
      affiliate,
      affiliateApiKey: affiliateApiKeyResult,
      channelApp: channelAppResult,
      resellerApps: resellerAppsForPopup
    };
  }

  function clearAffiliateDetailCache() {
    affiliateDetailCache.clear();
    cancellationPoliciesListCache.clear();
  }

  window.FareHarborAffiliateApi = {
    apiGetJson,
    parseAffiliateDetailFromResponse,
    fetchAffiliateDetail,
    fetchAffiliateDetailV2,
    fetchCancellationPoliciesList,
    getCancellationPolicyPk,
    extractAffiliateCancellationPolicySelection,
    findCancellationPolicyInList,
    pickDashboardUrlFromFields,
    buildCancellationPolicyDashboardUrl,
    buildCancellationPolicyDashboardUrlFromApiUri,
    resolveAffiliateCancellationPolicy,
    normalizeAffiliationCancellationPolicy,
    normalizeAffiliateCompanyName,
    normalizeAffiliateBrand,
    normalizeAppComparable,
    normalizeResellerAppName,
    parseAffiliateApiKeyFromUserResponse,
    parseCalendarTokenFromUserRecord,
    normalizeComparableName,
    isEligibleApiUser,
    collectApiUsernameCandidates,
    candidateMatchesAffiliateBrand,
    resolveAffiliateApiUserFromList,
    findApiUserCandidates,
    resolveChannelApp,
    resolveChannelAppKey,
    resolveChannelAppFromStaticMapping,
    normalizeMappingShortname,
    loadResellerAppCompanyMap,
    extractAffiliateCompanyFields,
    fetchAffiliateApiKey,
    fetchResellerApps,
    lookupAffiliateApiCredentials,
    clearAffiliateDetailCache,
    LINK_UNAVAILABLE_TITLE
  };
})();
