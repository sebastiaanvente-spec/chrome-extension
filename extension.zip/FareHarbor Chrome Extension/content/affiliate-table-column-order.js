(function affiliateTableColumnOrderModule() {
  "use strict";

  const COLUMN_ATTR = "data-fh-ext-column";
  const PERMISSIONS_COLUMN_KEY = "permissionsGroup";
  const ENDPOINT_COLUMN_KEY = "affiliate-company-endpoint-call";

  function isExtensionColumnCell(cell) {
    return !!cell?.hasAttribute?.(COLUMN_ATTR);
  }

  function getRowCells(row) {
    return [...row.children].filter(
      (el) => el.tagName === "TD" || el.tagName === "TH"
    );
  }

  function getNativeRowCells(row) {
    return getRowCells(row).filter((cell) => !isExtensionColumnCell(cell));
  }

  function findNativePermissionsHeader(headerRow) {
    if (!headerRow) {
      return null;
    }

    const direct = headerRow.querySelector(
      `:scope > th[data-column-key="${PERMISSIONS_COLUMN_KEY}"]`
    );
    if (direct && !isExtensionColumnCell(direct)) {
      return direct;
    }

    const byName = headerRow.querySelector(
      `:scope > th[data-column-name="${PERMISSIONS_COLUMN_KEY}"]`
    );
    if (byName && !isExtensionColumnCell(byName)) {
      return byName;
    }

    const nativeHeaders = getNativeRowCells(headerRow);
    const nativePermissionsIndex = nativeHeaders.findIndex(
      (cell) =>
        cell.dataset.columnKey === PERMISSIONS_COLUMN_KEY ||
        cell.dataset.columnName === PERMISSIONS_COLUMN_KEY
    );
    return nativePermissionsIndex >= 0 ? nativeHeaders[nativePermissionsIndex] : null;
  }

  function findNativePermissionsCell(row, headerRow) {
    if (!row) {
      return null;
    }

    const tableHeaderRow =
      headerRow || row.closest("table")?.querySelector("thead tr");

    const link = row.querySelector('a[data-test-id^="permissions-group-link-"]');
    if (link) {
      const fromLink = link.closest("td");
      if (
        fromLink &&
        fromLink.parentElement === row &&
        !isExtensionColumnCell(fromLink)
      ) {
        return fromLink;
      }
    }

    if (!tableHeaderRow) {
      return null;
    }

    const nativeHeaders = getNativeRowCells(tableHeaderRow);
    const nativePermissionsIndex = nativeHeaders.findIndex(
      (cell) =>
        cell.dataset.columnKey === PERMISSIONS_COLUMN_KEY ||
        cell.dataset.columnName === PERMISSIONS_COLUMN_KEY
    );
    if (nativePermissionsIndex < 0) {
      return null;
    }

    const nativeCells = getNativeRowCells(row);
    return nativeCells[nativePermissionsIndex] || null;
  }

  function findEndpointCell(row) {
    return row.querySelector(
      `:scope > [${COLUMN_ATTR}="${ENDPOINT_COLUMN_KEY}"]`
    );
  }

  function rowExtensionOrderCorrect(row, permissionsCell) {
    if (!row || !permissionsCell) {
      return true;
    }

    const endpointCell = findEndpointCell(row);
    if (!endpointCell) {
      return true;
    }

    return endpointCell.nextElementSibling === permissionsCell;
  }

  function ensureExtensionColumnOrderForRow(row, permissionsCell) {
    if (!permissionsCell || rowExtensionOrderCorrect(row, permissionsCell)) {
      return false;
    }

    const endpointCell = findEndpointCell(row);
    if (!endpointCell) {
      return false;
    }

    row.insertBefore(endpointCell, permissionsCell);
    return true;
  }

  function ensureAffiliateExtensionColumnOrder(table) {
    if (!table) {
      return { repositioned: false };
    }

    const headerRow = table.querySelector("thead tr");
    const permissionsHeader = findNativePermissionsHeader(headerRow);
    if (!permissionsHeader) {
      return { repositioned: false };
    }

    let repositioned = false;

    if (ensureExtensionColumnOrderForRow(headerRow, permissionsHeader)) {
      repositioned = true;
    }

    table.querySelectorAll("tbody tr").forEach((row) => {
      const permissionsCell = findNativePermissionsCell(row, headerRow);
      if (!permissionsCell) {
        return;
      }
      if (ensureExtensionColumnOrderForRow(row, permissionsCell)) {
        repositioned = true;
      }
    });

    return { repositioned };
  }

  window.FareHarborAffiliateTableColumnOrder = {
    COLUMN_ATTR,
    PERMISSIONS_COLUMN_KEY,
    ENDPOINT_COLUMN_KEY,
    isExtensionColumnCell,
    getRowCells,
    getNativeRowCells,
    findNativePermissionsHeader,
    findNativePermissionsCell,
    findEndpointCell,
    rowExtensionOrderCorrect,
    ensureAffiliateExtensionColumnOrder
  };
})();
