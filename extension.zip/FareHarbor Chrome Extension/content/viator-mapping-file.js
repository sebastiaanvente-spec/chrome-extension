console.log("[viator-mapping-file] viator-mapping-file.js loaded");

// Wait for utilities to be available and initialize module
(function initializeViatorMappingFile() {
  // Wait for FareHarborUtils to be available
  if (!window.FareHarborUtils) {
    setTimeout(initializeViatorMappingFile, 10);
    return;
  }
  
  // Now utilities are available, set up the module
  const utils = window.FareHarborUtils;

  // Function to extract channel name from h1 element
  function extractChannelName() {
    // Look for the h1 element with the channel name - try multiple selectors
    // First try: specific class that contains 'test-header-reseller-item'
    let h1Element = document.querySelector('h1[class*="test-header-reseller-item"]');
    if (h1Element) {
      return h1Element.textContent.trim();
    }
    
    // Second try: any h1 in the settings window header tabs
    h1Element = document.querySelector('.settings-window-header-tabs h1');
    if (h1Element) {
      return h1Element.textContent.trim();
    }
    
    // Third try: more generic - any h1 in the settings header area
    h1Element = document.querySelector('.settings-window-header h1');
    if (h1Element) {
      return h1Element.textContent.trim();
    }
    
    return null;
  }
  
  // Function to extract ID from item name
  function extractIdFromItemName(itemName) {
    // Try format with "ID:" prefix first (e.g., "Name (ID: 76748)")
    let match = itemName.match(/\(ID:\s*(\d+)\)/);
    if (match) {
      return `(ID: ${match[1]})`;
    }
    
    // Try format without "ID:" prefix (e.g., "Name (76748)")
    match = itemName.match(/\((\d+)\)/);
    if (match) {
      return `(ID: ${match[1]})`;
    }
    
    return '';
  }
  
  // Function to extract channel name from complete mapping table row
  function extractChannelNameFromTableRow(tbody) {
    const firstCell = tbody.querySelector('td:first-child');
    if (firstCell) {
      return firstCell.textContent.trim();
    }
    return null;
  }
  
  const RESELLER_CHANNEL_ITEM_PATH_RE = /\/integrations\/channels\/(\d+)\/items\/(\d+)/;

  function parseCompanyShortnameFromPathname(pathname) {
    const parts = String(pathname || "").split("/").filter(Boolean);
    return parts[0] || null;
  }

  function resolveAbsoluteUrl(href) {
    if (!href) return null;
    const trimmed = String(href).trim();
    if (!trimmed || trimmed.startsWith("{{")) return null;
    if (/^https?:\/\//i.test(trimmed)) return trimmed;
    if (trimmed.startsWith("/")) return `${window.location.origin}${trimmed}`;
    return `${window.location.origin}/${trimmed}`;
  }

  function extractResellerItemContextFromTbody(tbody) {
    const links = tbody.querySelectorAll("a[href], a[ng-href]");
    for (const link of links) {
      const rawHref = link.getAttribute("href") || link.getAttribute("ng-href") || "";
      const match = String(rawHref).match(RESELLER_CHANNEL_ITEM_PATH_RE);
      if (!match) continue;

      const absoluteUrl = resolveAbsoluteUrl(rawHref);
      let company = null;
      const pathnameSource = absoluteUrl || rawHref;
      try {
        company = parseCompanyShortnameFromPathname(
          absoluteUrl ? new URL(absoluteUrl).pathname : pathnameSource.split("?")[0].split("#")[0]
        );
      } catch {
        company = parseCompanyShortnameFromPathname(pathnameSource);
      }

      return {
        company,
        resellerCompanyId: match[1],
        resellerItemId: match[2],
        resellerItemUrl: absoluteUrl || rawHref,
        enrichmentPageUrl: absoluteUrl || rawHref
      };
    }
    return null;
  }

  function extractMappedCustomerTypesFromSpans(spans) {
    return Array.from(spans)
      .filter((span) => {
        const textContent = span.textContent.trim();
        return textContent.startsWith("rct");
      })
      .map((span) => ({
        externalId: span.textContent.trim(),
        displayName: (span.getAttribute("ng-tip") || "").trim()
      }))
      .filter((entry) => entry.displayName || entry.externalId);
  }

  function reorderMappedCustomerTypes(mappedCustomerTypes) {
    if (!mappedCustomerTypes || mappedCustomerTypes.length === 0) {
      return mappedCustomerTypes;
    }
    const names = mappedCustomerTypes.map((entry) => entry.displayName).filter(Boolean);
    const reorderedNames = reorderCustomerTypes(names);
    const byName = new Map();
    mappedCustomerTypes.forEach((entry) => {
      if (entry.displayName && !byName.has(entry.displayName)) {
        byName.set(entry.displayName, entry);
      }
    });
    return reorderedNames.map((name) => byName.get(name)).filter(Boolean);
  }

  // Function to reorder customer types according to GetYourGuide priority (reusing for now)
  function reorderCustomerTypes(customerTypes) {
    if (!customerTypes || customerTypes.length === 0) {
      return customerTypes;
    }

    const priorityOrder = [
      'Adult',
      'Child', 
      'Youth',
      'Infant',
      'Senior',
      'Student',
      'EU Citizen',
      'EU Citizen Student',
      'Military',
      'Group'
    ];
    
    // Convert priority order to lowercase for case-insensitive comparison
    const priorityOrderLower = priorityOrder.map(type => type.toLowerCase());
    
    // Separate known and unknown customer types
    const knownTypes = [];
    const unknownTypes = [];
    
    customerTypes.forEach(customerType => {
      const lowerCaseType = customerType.toLowerCase();
      const priorityIndex = priorityOrderLower.indexOf(lowerCaseType);
      
      if (priorityIndex !== -1) {
        // Known type - store with its priority index and original case
        knownTypes.push({
          original: customerType,
          priority: priorityIndex
        });
      } else {
        // Unknown type - will be sorted alphabetically
        unknownTypes.push(customerType);
      }
    });
    
    // Sort known types by priority order
    knownTypes.sort((a, b) => a.priority - b.priority);
    
    // Sort unknown types alphabetically (case-insensitive)
    unknownTypes.sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));
    
    // Combine known types (in priority order) + unknown types (alphabetically)
    const reorderedTypes = [
      ...knownTypes.map(item => item.original),
      ...unknownTypes
    ];
    
    console.log(`[viator-mapping-file] Reordered customer types: [${customerTypes.join(', ')}] -> [${reorderedTypes.join(', ')}]`);
    
    return reorderedTypes;
  }
  
  let exportInProgress = false;

  // Function to scrape reseller items from the page (copying GetYourGuide logic for now)
  function scrapeViatorMappingFile() {
    console.log("[viator-mapping-file] Scraping Viator mapping file...");
    
    // Find the reseller items table - same structure as GetYourGuide for now
    const resellerTable = document.querySelector('table[ng-controller*="ResellerItemsController"]') ||
                          document.querySelector('table.reseller-items-table') ||
                          document.querySelector('table');
    
    if (!resellerTable) {
      console.warn("[viator-mapping-file] No reseller items table found");
      return null;
    }
    
    console.log("[viator-mapping-file] Found reseller items table");
    
    // Find all tbody elements with ng-repeat for reseller items
    let tbodyElements = resellerTable.querySelectorAll('tbody[ng-repeat*="resellerItem"]');
    
    // If no tbody elements found with the specific ng-repeat, try more generic selectors
    if (tbodyElements.length === 0) {
      console.log("[viator-mapping-file] No tbody with ng-repeat found, trying alternative selectors...");
      
      // Try other possible tbody selectors
      const tbodySelectors = [
        'tbody[ng-repeat*="resellerItem"]', // Any ng-repeat containing resellerItem
        'tbody[ng-repeat]', // Any tbody with ng-repeat
        'tbody' // Any tbody
      ];
      
      for (const selector of tbodySelectors) {
        tbodyElements = resellerTable.querySelectorAll(selector);
        if (tbodyElements.length > 0) {
          console.log(`[viator-mapping-file] Found ${tbodyElements.length} tbody elements using selector: "${selector}"`);
          break;
        }
      }
    }
    
    if (tbodyElements.length === 0) {
      console.warn("[viator-mapping-file] No tbody elements found in the table");
      return null;
    }
    
    console.log(`[viator-mapping-file] Found ${tbodyElements.length} reseller items`);
    
    const result = [];
    
    // Process each reseller item
    tbodyElements.forEach((tbody, index) => {
      console.log(`[viator-mapping-file] Processing reseller item ${index + 1}...`);
      
      try {
        // Extract Element 1: Item label with number and clickable link
        let itemLink = tbody.querySelector('td:nth-child(4) a[aria-label]');
        if (!itemLink) {
          itemLink = tbody.querySelector('td.prose.prose--compact a[ng-tip]');
        }
        if (!itemLink) {
          itemLink = tbody.querySelector('td a[ng-tip]');
        }
        if (!itemLink) {
          itemLink = tbody.querySelector('td a[aria-label]');
        }
        if (!itemLink) {
          itemLink = tbody.querySelector('a[ng-tip]');
        }
        if (!itemLink) {
          itemLink = tbody.querySelector('a[aria-label]');
        }
        
        let itemLabel = '';
        let itemLinkHTML = '';
        
        if (itemLink) {
          console.log(`[viator-mapping-file] Item ${index + 1} - Found item link`);
          const ariaLabel = itemLink.getAttribute('aria-label');
          if (ariaLabel) {
            itemLabel = ariaLabel;
          } else {
            const ngTip = itemLink.getAttribute('ng-tip') || '';
            const textContent = itemLink.textContent.trim();
            itemLabel = textContent ? `${ngTip} (${textContent})` : ngTip;
          }
          
          const href = itemLink.getAttribute('href') || itemLink.getAttribute('ng-href');
          if (href && href.startsWith('/')) {
            const baseUrl = window.location.origin;
            const absoluteUrl = baseUrl + href;
            
            const clonedLink = itemLink.cloneNode(true);
            clonedLink.setAttribute('href', absoluteUrl);
            clonedLink.textContent = itemLabel;
            itemLinkHTML = clonedLink.outerHTML;
          } else {
            const clonedLink = itemLink.cloneNode(true);
            clonedLink.textContent = itemLabel;
            itemLinkHTML = clonedLink.outerHTML;
          }
        }
        console.log(`[viator-mapping-file] Item ${index + 1} - Item Label: "${itemLabel}"`);
        
        // Extract Element 2: Supplier product code (ri code) from 3rd column
        let supplierProductCode = '';
        const thirdColumn = tbody.querySelector('td:nth-child(3)');
        if (thirdColumn) {
          supplierProductCode = thirdColumn.textContent.trim();
          // Filter to only get 'ri' codes
          if (supplierProductCode && supplierProductCode.startsWith('ri')) {
            console.log(`[viator-mapping-file] Item ${index + 1} - Found supplier product code: "${supplierProductCode}"`);
          } else {
            console.warn(`[viator-mapping-file] Item ${index + 1} - Third column content "${supplierProductCode}" does not start with 'ri'`);
            supplierProductCode = '';
          }
        } else {
          console.warn(`[viator-mapping-file] Item ${index + 1} - Third column not found`);
        }
        
        // Extract Element 3: Customer type ng-tip from <span> (customer type names)
        let customerTypeSpans = tbody.querySelectorAll('td:nth-child(5) span.text-link[ng-tip]');
        if (customerTypeSpans.length === 0) {
          customerTypeSpans = tbody.querySelectorAll('td:nth-child(5) span.text-link.ng-binding[ng-tip]');
        }
        if (customerTypeSpans.length === 0) {
          customerTypeSpans = tbody.querySelectorAll('td span[ng-tip]');
        }
        if (customerTypeSpans.length === 0) {
          customerTypeSpans = tbody.querySelectorAll('span[ng-tip]');
        }
        
        const rawCustomerTypes = Array.from(customerTypeSpans)
          .filter(span => {
            const textContent = span.textContent.trim();
            return textContent.startsWith('rct');
          })
          .map(span => span.getAttribute('ng-tip'))
          .filter(tip => tip);
        
        const mappedCustomerTypeSpans = tbody.querySelectorAll('td:nth-child(5) span.text-link[ng-tip]');
        const mappedCustomerTypes = reorderMappedCustomerTypes(
          extractMappedCustomerTypesFromSpans(
            mappedCustomerTypeSpans.length > 0
              ? mappedCustomerTypeSpans
              : customerTypeSpans
          )
        );

        const customerTypes = reorderCustomerTypes(rawCustomerTypes);
        console.log(`[viator-mapping-file] Item ${index + 1} - Found ${customerTypeSpans.length} customer type spans, filtered to ${rawCustomerTypes.length} customer types, reordered to: [${customerTypes.join(', ')}]`);
        
        const itemId = extractIdNumber(itemLabel);
        const resellerItemContext = extractResellerItemContextFromTbody(tbody);

        // Create row with supplier product code (ri code) instead of channel options
        const combinedCustomerTypes = customerTypes.length > 0 ? customerTypes.join('\n') : '';
        result.push({
          channelOption: supplierProductCode, // Using supplier product code (ri code) instead of channel option (ro code)
          itemLabel: itemLabel,
          itemLabelHTML: itemLinkHTML,
          customerType: combinedCustomerTypes,
          itemId,
          mappedCustomerTypes,
          ...(resellerItemContext || {})
        });
        console.log(`[viator-mapping-file] Added row: "${supplierProductCode}", "${itemLabel}", "${combinedCustomerTypes.replace(/\n/g, ' | ')}"`);
        
      } catch (error) {
        console.error(`[viator-mapping-file] Error processing reseller item ${index + 1}:`, error);
      }
    });
    
    if (result.length === 0) {
      console.warn("[viator-mapping-file] No data extracted.");
      return null;
    }
    
    console.log(`[viator-mapping-file] Successfully extracted ${result.length} rows`);
    return result;
  }

  function formatAsHTML(data) {
    if (!data || data.length === 0) {
      return '';
    }
    
    let html = '<table border="1" cellpadding="5" cellspacing="0">\n';
    html += '<tbody>\n';
    
    data.forEach(item => {
      html += '<tr>\n';
      html += `<td><strong>${escapeHtmlField(item.channelOption)}</strong></td>\n`;
      const itemLabelContent = item.itemLabelHTML || escapeHtmlField(item.itemLabel);
      html += `<td>${itemLabelContent}</td>\n`;
      html += `<td>${escapeHtmlField(item.customerType)}</td>\n`;
      html += '</tr>\n';
    });
    
    html += '</tbody>\n';
    html += '</table>';
    
    return html;
  }
  
  function escapeHtmlField(field) {
    if (!field) return '';
    
    const str = String(field).trim();
    
    const escaped = str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
    
    return escaped.replace(/\n/g, '<br>');
  }

  // Function to extract ID number from item name (returns just the number)
  function extractIdNumber(itemName) {
    if (!itemName) return '';
    
    let match = itemName.match(/\(ID:\s*(\d+)\)/);
    if (match) {
      return match[1];
    }
    
    match = itemName.match(/\((\d+)\)/);
    if (match) {
      return match[1];
    }
    
    return '';
  }

  // Function to extract item name without ID (returns just the name)
  function extractItemName(itemName) {
    if (!itemName) return '';
    
    let cleaned = itemName.replace(/\(ID:\s*\d+\)/g, '').trim();
    
    if (cleaned === itemName) {
      cleaned = itemName.replace(/\(\d+\)/g, '').trim();
    }
    
    return cleaned;
  }

  // Format data as TSV (tab-separated values)
  function formatAsTSV(data) {
    if (!data || data.length === 0) {
      return '';
    }
    
    const tsvLines = [];
    
    data.forEach(item => {
      let itemLabelText = item.itemLabel;
      if (item.itemLabelHTML) {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = item.itemLabelHTML;
        itemLabelText = tempDiv.textContent || tempDiv.innerText || item.itemLabel;
      }
      
      const itemNumber = extractIdNumber(itemLabelText);
      const itemName = extractItemName(itemLabelText);
      
      const customerTypeText = (item.customerType || '').replace(/\n/g, '; ');
      
      const row = [
        escapeTsvField(item.channelOption || ''),
        escapeTsvField(itemNumber),
        escapeTsvField(itemName),
        escapeTsvField(customerTypeText)
      ];
      tsvLines.push(row.join('\t'));
    });
    
    return tsvLines.join('\n');
  }

  function escapeTsvField(field) {
    if (!field) return '';
    
    const str = String(field).trim();
    
    return str.replace(/[\t\n\r]/g, ' ');
  }

  // Message handling for Viator Mapping File actions
  function handleMessage(req, sender, sendResponse) {
    console.log("[viator-mapping-file] Message received:", req);

    if (req.action === "runViatorMappingFileExtract") {
      if (exportInProgress) {
        sendResponse({
          success: false,
          error: "A Viator mapping export is already running. Please wait for it to finish."
        });
        return true;
      }

      (async () => {
        exportInProgress = true;
        try {
          const data = scrapeViatorMappingFile();

          if (!data || data.length === 0) {
            sendResponse({
              success: false,
              error: "No Viator mapping data found on this page. Make sure you're on the Viator reseller items page."
            });
            return;
          }

          const includePriceSheets = req.includePriceSheets === true;
          if (!includePriceSheets) {
            const htmlData = formatAsHTML(data);
            const tsvData = formatAsTSV(data);
            sendResponse({
              success: true,
              data: data,
              htmlData: htmlData,
              tsvData: tsvData,
              count: data.length
            });
            return;
          }

          if (!window.ViatorMappingPricingEnrichment?.enrichViatorMappingOutput) {
            sendResponse({
              success: false,
              error: "Viator pricing enrichment module not loaded. Reload the page and try again."
            });
            return;
          }

          const enrichment = await window.ViatorMappingPricingEnrichment.enrichViatorMappingOutput({
            scrapedRows: data,
            pageUrl: window.location.href,
            onStatus: (statusText) => {
              console.log("[viator-mapping-file]", statusText);
            }
          });

          if (!enrichment.ok) {
            sendResponse({
              success: false,
              error: enrichment.error || "Viator mapping enrichment failed."
            });
            return;
          }

          sendResponse({
            success: true,
            data: data,
            htmlData: enrichment.htmlData,
            tsvData: enrichment.tsvData,
            count: data.length,
            warnings: enrichment.warnings || [],
            summaryMessage: enrichment.summaryMessage || "",
            hasPriceSheetWarning: Boolean(enrichment.hasPriceSheetWarning)
          });
        } catch (error) {
          console.error("[viator-mapping-file] Error during scraping:", error);
          sendResponse({
            success: false,
            error: "An error occurred while scraping Viator mapping data: " + error.message
          });
        } finally {
          exportInProgress = false;
        }
      })();

      return true;
    }

    return false; // Not handled by this module
  }

  // Export the module
  window.ViatorMappingFile = {
    handleMessage,
    scrapeViatorMappingFile,
    formatAsHTML,
    formatAsTSV
  };

  console.log("[viator-mapping-file] Module initialized successfully");

})(); // End of initialization function

