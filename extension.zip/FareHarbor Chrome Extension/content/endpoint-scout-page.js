/**
 * Page-world Endpoint Scout network capture (loaded via script src, not content script).
 * All helpers are local to this file — never call content-script functions.
 */
(function initEndpointScoutPageCapture() {
  if (window.__fhEndpointScoutPageLoaded) return;
  window.__fhEndpointScoutPageLoaded = true;

  var SCHEMA_ENABLED = window.__FH_ENDPOINT_SCOUT_SCHEMA_ENABLED__ !== false;
  var REDACTION_MODE = window.__FH_ENDPOINT_SCOUT_REDACTION_MODE__ || "minimal";
  var REDACTION_DEBUG = false;
  var MSG_TYPE = "FH_ENDPOINT_SCOUT";
  var MSG_SOURCE = "fh-endpoint-scout-v1";
  var SELF_TEST_SOURCE = "fareharbor-automator-endpoint-scout";
  var MAX_JSON_PARSE_BYTES = 15 * 1024 * 1024;
  var MAX_SAMPLE_RESPONSE_SIZE = 250000;
  var MAX_SHAPE_DEPTH_STRICT = 2;
  var MAX_SHAPE_DEPTH_MINIMAL = 4;
  var MAX_SHAPE_KEYS = 50;
  var MAX_SAMPLE_ARRAY_ITEMS = 5;
  var MAX_SAMPLE_OBJECT_DEPTH = 6;
  var MAX_SAMPLE_KEYS = 60;
  var PRIORITY_ENDPOINT_PATH_PATTERNS = [
    /\/bookings\//i,
    /customers-with-seats/i,
    /\/customers\//i,
    /\/contacts\//i,
    /customer-prototypes/i,
    /customer-type-rates/i,
    /availabilities\/[^/]+\/bookings/i,
    /resource.*requirements/i,
    /\/requirements\//i
  ];
  // Keep in sync with endpoint-scout.js
  var ALWAYS_SENSITIVE_KEY_FRAGMENTS = [
    "token", "auth", "password", "secret", "cookie", "csrf",
    "email", "phone", "address", "payment", "card",
    "api_key", "credential"
  ];
  var CONFIG_SAFE_KEY_NAMES = {
    customer_prototypes: true,
    customer_prototype: true,
    customer_types: true,
    customer_type: true,
    customer_type_rates: true,
    customer_type_prices: true,
    customer_type_pricing: true,
    customer_type_assignments: true,
    reseller_customer_types: true,
    reseller_customer_type: true,
    reseller_customer_types_external_identifiers: true,
    unmapped_reseller_customer_type_pks: true,
    reseller_items: true,
    reseller_item: true,
    reseller_options: true,
    reseller_option: true,
    reseller_item_mappings: true,
    reseller_company_mappings: true,
    reseller_options_external_identifiers: true,
    external_identifier: true
  };
  var EXACT_SENSITIVE_KEYS = {
    customer: true,
    customers: true,
    guest: true,
    guests: true,
    contact: true,
    contacts: true,
    email: true,
    phone: true,
    address: true,
    payment: true,
    card: true,
    token: true,
    auth: true,
    cookie: true,
    csrf: true,
    secret: true,
    password: true,
    api_key: true,
    viator_api_key: true,
    bookingcom_api_key: true,
    supplier_secret: true,
    credential: true
  };
  var CONFIG_SAFE_ENDPOINT_TAGS = {
    PRICING: true,
    RESOURCES: true,
    CUSTOMER_TYPES: true,
    ITEMS: true,
    SETTINGS: true
  };
  var CONFIG_SAFE_FIELD_NAMES = {
    name: true,
    title: true,
    label: true,
    display_name: true
  };
  var MINIMAL_SAFE_KEY_NAMES = {
    customer_prototypes: true,
    customer_prototype: true,
    customer_types: true,
    customer_type: true,
    customer_type_rates: true,
    customer_type_prices: true,
    customer_type_pricing: true,
    customer_type_assignments: true,
    reseller_customer_types: true,
    reseller_customer_type: true,
    reseller_customer_types_external_identifiers: true,
    unmapped_reseller_customer_type_pks: true,
    reseller_items: true,
    reseller_item: true,
    reseller_options: true,
    reseller_option: true,
    reseller_item_mappings: true,
    reseller_company_mappings: true,
    reseller_options_external_identifiers: true,
    external_identifier: true,
    booking: true,
    bookings: true,
    availability: true,
    availabilities: true,
    customer: true,
    customers: true,
    contact: true,
    contacts: true,
    guest: true,
    guests: true,
    item: true,
    resource: true,
    resources: true,
    requirements: true,
    customer_breakdown: true,
    customer_breakdown_short: true,
    customer_count: true,
    customers_with_seat_assignments: true,
    customers_with_seats: true,
    pk: true,
    id: true,
    uuid: true,
    uri: true,
    name: true,
    display_name: true,
    customer_prototype_id: true,
    customer_type_id: true
  };
  var MINIMAL_EXACT_SENSITIVE_KEYS = {
    email: true,
    phone: true,
    address: true,
    payment: true,
    card: true,
    token: true,
    auth: true,
    cookie: true,
    csrf: true,
    secret: true,
    password: true,
    api_key: true,
    viator_api_key: true,
    bookingcom_api_key: true,
    supplier_secret: true,
    credential: true,
    card_brand: true,
    last4: true,
    expiry: true,
    exp_month: true,
    exp_year: true
  };
  var MINIMAL_SENSITIVE_KEY_FRAGMENTS = [
    "token", "auth", "password", "secret", "cookie", "csrf",
    "payment", "card", "api_key", "credential"
  ];
  var ALWAYS_REDACT_VALUE_KEYS = {
    password: true,
    secret: true,
    token: true,
    csrf: true,
    cookie: true,
    auth: true,
    api_key: true,
    viator_api_key: true,
    bookingcom_api_key: true,
    supplier_secret: true,
    credential: true
  };
  var EMAIL_VALUE_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var PHONE_VALUE_RE = /^[\d\s()+\-.]{7,}$/;

  function pageLog() {
    try {
      var args = ["[endpoint-scout][page]"].concat(Array.prototype.slice.call(arguments));
      console.log.apply(console, args);
    } catch (e) {}
  }

  function schemaDebugLog() {
    if (!REDACTION_DEBUG) return;
    try {
      var args = ["[endpoint-scout][schema-debug]"].concat(Array.prototype.slice.call(arguments));
      console.log.apply(console, args);
    } catch (e) {}
  }

  function isJsonContentType(contentType) {
    return !!(contentType && String(contentType).toLowerCase().indexOf("json") !== -1);
  }

  function parseErrorToReason(errorKey) {
    if (errorKey === "empty body") return "empty-body";
    if (errorKey === "body too large") return "body-too-large";
    if (errorKey === "parse failed") return "json-parse-failed";
    return "json-parse-failed";
  }

  function getEndpointTagFromUrl(urlString) {
    var path = "";
    try {
      path = new URL(urlString, window.location.href).pathname.toLowerCase();
    } catch (e) {
      return "UNKNOWN";
    }
    if (path.indexOf("customer-prototypes") !== -1) return "CUSTOMER_TYPES";
    if (
      path.indexOf("total-sheets") !== -1 ||
      path.indexOf("total-schedules") !== -1 ||
      path.indexOf("pricing-for-editing") !== -1
    ) {
      return "PRICING";
    }
    if (path.indexOf("/resources/") !== -1) return "RESOURCES";
    if (path.indexOf("availabilities") !== -1) return "AVAILABILITY";
    if (path.indexOf("/bookings/") !== -1) return "BOOKINGS";
    if (path.indexOf("custom-fields") !== -1 || path.indexOf("tax-types") !== -1) {
      return "SETTINGS";
    }
    if (path.indexOf("cost-preview") !== -1 || path.indexOf("cost_preview") !== -1) {
      return "PRICING";
    }
    if (path.indexOf("/cost/") !== -1 || path.indexOf("/preview/") !== -1) {
      return "PRICING";
    }
    if (path.indexOf("/items/") !== -1 || path.indexOf("activities") !== -1) return "ITEMS";
    return "UNKNOWN";
  }

  function redactionLog(keyPath, key) {
    if (!REDACTION_DEBUG) return;
    try {
      console.log("[endpoint-scout][redaction] redacted key", keyPath || key);
    } catch (e) {}
  }

  function childKeyPath(parentPath, key) {
    return parentPath ? parentPath + "." + key : key;
  }

  function isMinimalRedactionMode() {
    return REDACTION_MODE === "minimal";
  }

  function getMaxShapeDepth() {
    return isMinimalRedactionMode() ? MAX_SHAPE_DEPTH_MINIMAL : MAX_SHAPE_DEPTH_STRICT;
  }

  function isMinimalAddressKey(lower) {
    return (
      lower === "street" ||
      lower === "billing_address" ||
      lower === "shipping_address" ||
      lower.indexOf("address_line") === 0
    );
  }

  function isSensitiveKey(key, endpointTag) {
    endpointTag = endpointTag || "UNKNOWN";
    if (!key) return false;
    var lower = String(key).toLowerCase();
    if (isMinimalRedactionMode()) {
      if (MINIMAL_SAFE_KEY_NAMES[lower]) return false;
      if (MINIMAL_EXACT_SENSITIVE_KEYS[lower]) return true;
      if (isMinimalAddressKey(lower)) return true;
      for (var f = 0; f < MINIMAL_SENSITIVE_KEY_FRAGMENTS.length; f++) {
        if (lower.indexOf(MINIMAL_SENSITIVE_KEY_FRAGMENTS[f]) !== -1) return true;
      }
      return false;
    }
    if (CONFIG_SAFE_KEY_NAMES[lower]) return false;
    if (CONFIG_SAFE_ENDPOINT_TAGS[endpointTag] && CONFIG_SAFE_FIELD_NAMES[lower]) {
      return false;
    }
    if (EXACT_SENSITIVE_KEYS[lower]) return true;
    for (var i = 0; i < ALWAYS_SENSITIVE_KEY_FRAGMENTS.length; i++) {
      if (lower.indexOf(ALWAYS_SENSITIVE_KEY_FRAGMENTS[i]) !== -1) return true;
    }
    return false;
  }

  function isSensitiveValue(key, value) {
    if (!isMinimalRedactionMode() || typeof value !== "string") return false;
    var lower = String(key).toLowerCase();
    var trimmed = value.trim();
    if (!trimmed) return false;
    if (lower === "email" || lower.slice(-6) === "_email") return EMAIL_VALUE_RE.test(trimmed);
    if (lower === "phone" || lower.indexOf("phone") !== -1) return PHONE_VALUE_RE.test(trimmed);
    if (lower === "address" || isMinimalAddressKey(lower)) return trimmed.length > 0;
    return false;
  }

  function shouldRedactWholeValue(key) {
    if (!key) return false;
    return !!ALWAYS_REDACT_VALUE_KEYS[String(key).toLowerCase()];
  }

  function shouldRedactField(key, value, endpointTag) {
    endpointTag = endpointTag || "UNKNOWN";
    if (shouldRedactWholeValue(key)) return true;
    if (isSensitiveKey(key, endpointTag)) {
      var t = typeof value;
      if (value === null || t === "string" || t === "number" || t === "boolean") return true;
      if (isMinimalRedactionMode() && (t === "object" || Object.prototype.toString.call(value) === "[object Array]")) {
        return false;
      }
      return true;
    }
    return isSensitiveValue(key, value);
  }

  function firstArrayElement(arr) {
    if (!arr.length) return undefined;
    for (var i = 0; i < arr.length; i++) {
      var item = arr[i];
      if (item !== null && typeof item === "object" && !Array.isArray(item)) {
        return item;
      }
    }
    return arr[0];
  }

  function isPriorityEndpointContext(pathOrUrl) {
    var text = String(pathOrUrl || "").toLowerCase();
    for (var p = 0; p < PRIORITY_ENDPOINT_PATH_PATTERNS.length; p++) {
      if (PRIORITY_ENDPOINT_PATH_PATTERNS[p].test(text)) return true;
    }
    return false;
  }

  function getArraySampleLimit(endpointTag, keyPath, urlHint) {
    if (
      isPriorityEndpointContext(urlHint) ||
      isPriorityEndpointContext(keyPath) ||
      endpointTag === "BOOKINGS" ||
      endpointTag === "AVAILABILITY" ||
      endpointTag === "CUSTOMER_TYPES"
    ) {
      return MAX_SAMPLE_ARRAY_ITEMS;
    }
    return MAX_SAMPLE_ARRAY_ITEMS;
  }

  function arraySampleElements(arr, maxItems) {
    maxItems = maxItems || MAX_SAMPLE_ARRAY_ITEMS;
    var items = [];
    for (var i = 0; i < arr.length && items.length < maxItems; i++) {
      items.push(arr[i]);
    }
    return items;
  }

  function buildArrayShape(value, depth, endpointTag, keyPath, urlHint) {
    var limit = getArraySampleLimit(endpointTag, keyPath, urlHint);
    var samples = arraySampleElements(value, limit);
    var items = [];
    for (var ai = 0; ai < samples.length; ai++) {
      items.push(
        buildShapeValue(
          samples[ai],
          depth + 1,
          endpointTag,
          keyPath ? keyPath + ".items[" + ai + "]" : "items[" + ai + "]",
          urlHint
        )
      );
    }
    var result = { __array__: true, length: value.length, items: items };
    if (value.length > samples.length) {
      result.__truncated__ = true;
      result.__original_length__ = value.length;
    }
    return result;
  }

  function buildArraySample(value, depth, endpointTag, keyPath, urlHint) {
    var limit = getArraySampleLimit(endpointTag, keyPath, urlHint);
    var samples = arraySampleElements(value, limit);
    var items = [];
    for (var j = 0; j < samples.length; j++) {
      items.push(
        buildSample(
          samples[j],
          depth + 1,
          endpointTag,
          keyPath ? keyPath + "[" + j + "]" : "[" + j + "]",
          "",
          urlHint
        )
      );
    }
    if (value.length > samples.length) {
      return {
        __truncated__: true,
        __original_length__: value.length,
        items: items
      };
    }
    return items;
  }

  function primitiveType(value) {
    if (value === null) return "null";
    var t = typeof value;
    if (t === "string" || t === "number" || t === "boolean") return t;
    if (t === "undefined") return "undefined";
    return "unknown";
  }

  function redactedTypeLabel(value) {
    return "[REDACTED:" + primitiveType(value) + "]";
  }

  function redactedSampleValue(value) {
    return "[REDACTED:" + primitiveType(value) + "]";
  }

  function redactSensitiveKeys(key, value, depth, endpointTag, keyPath, urlHint) {
    keyPath = keyPath || key;
    if (shouldRedactField(key, value, endpointTag)) {
      redactionLog(keyPath, key);
      return redactedTypeLabel(value);
    }
    return buildShapeValue(value, depth, endpointTag, keyPath, urlHint);
  }

  function buildShapeValue(value, depth, endpointTag, keyPath, urlHint) {
    depth = depth || 0;
    endpointTag = endpointTag || "UNKNOWN";
    keyPath = keyPath || "";
    urlHint = urlHint || "";
    if (value === null) return "null";
    var t = typeof value;
    if (t === "string" || t === "number" || t === "boolean") return t;
    if (t === "undefined") return "undefined";
    if (Object.prototype.toString.call(value) === "[object Array]") {
      return buildArrayShape(value, depth, endpointTag, keyPath, urlHint);
    }
    if (t === "object") {
      if (depth > getMaxShapeDepth()) return "object";
      var shape = {};
      var keys = Object.keys(value);
      var limit = Math.min(keys.length, MAX_SHAPE_KEYS);
      for (var i = 0; i < limit; i++) {
        var k = keys[i];
        shape[k] = redactSensitiveKeys(
          k,
          value[k],
          depth + 1,
          endpointTag,
          childKeyPath(keyPath, k),
          urlHint
        );
      }
      if (keys.length > limit) {
        shape.__truncated__ = true;
        shape.__original_key_count__ = keys.length;
      }
      return shape;
    }
    return "unknown";
  }

  function buildSample(value, depth, endpointTag, keyPath, key, urlHint) {
    if (!isMinimalRedactionMode()) return null;
    depth = depth || 0;
    endpointTag = endpointTag || "UNKNOWN";
    keyPath = keyPath || "";
    key = key || "";
    urlHint = urlHint || "";
    if (value === null) return null;
    var t = typeof value;
    if (t === "string" || t === "number" || t === "boolean") {
      if (shouldRedactField(key, value, endpointTag)) {
        redactionLog(keyPath, key);
        return redactedSampleValue(value);
      }
      return value;
    }
    if (t === "undefined") return undefined;
    if (Object.prototype.toString.call(value) === "[object Array]") {
      return buildArraySample(value, depth, endpointTag, keyPath, urlHint);
    }
    if (t === "object") {
      if (depth > MAX_SAMPLE_OBJECT_DEPTH) {
        return { __truncated__: true, __depth_limited__: true };
      }
      var sample = {};
      var objKeys = Object.keys(value);
      var objLimit = Math.min(objKeys.length, MAX_SAMPLE_KEYS);
      for (var oi = 0; oi < objLimit; oi++) {
        var childKey = objKeys[oi];
        var childPath = childKeyPath(keyPath, childKey);
        var childValue = value[childKey];
        if (shouldRedactField(childKey, childValue, endpointTag)) {
          redactionLog(childPath, childKey);
          sample[childKey] = redactedSampleValue(childValue);
        } else {
          sample[childKey] = buildSample(
            childValue,
            depth + 1,
            endpointTag,
            childPath,
            childKey,
            urlHint
          );
        }
      }
      if (objKeys.length > objLimit) {
        sample.__truncated__ = true;
        sample.__original_key_count__ = objKeys.length;
      }
      return sample;
    }
    return redactedSampleValue(value);
  }

  function sampleFromParsedJson(parsed, endpointTag, urlHint) {
    if (!isMinimalRedactionMode() || parsed == null) return null;
    var sample = buildSample(parsed, 0, endpointTag || "UNKNOWN", "", "", urlHint || "");
    if (sample == null) return null;
    if (typeof sample === "object" && !Array.isArray(sample) && Object.keys(sample).length === 0) {
      return null;
    }
    return sample;
  }

  function extractShape(value, endpointTag, urlHint) {
    try {
      return buildShapeValue(value, 0, endpointTag || "UNKNOWN", "", urlHint || "");
    } catch (e) {
      return null;
    }
  }

  function safeParseJson(text) {
    if (!text || typeof text !== "string") return { error: "empty body" };
    if (text.length > MAX_JSON_PARSE_BYTES) {
      return { error: "body too large", size: text.length };
    }
    try {
      var trimmed = text.trim();
      if (!trimmed) return { error: "empty body" };
      var value;
      if (trimmed.charAt(0) === "{" || trimmed.charAt(0) === "[") {
        value = JSON.parse(trimmed);
      } else {
        var xssiMatch = trimmed.match(/^\)\]\}',?\s*([\s\S]*)$/);
        if (xssiMatch) {
          trimmed = xssiMatch[1].trim();
        }
        value = JSON.parse(trimmed);
      }
      return {
        value: value,
        truncatedLargeResponse: text.length > MAX_SAMPLE_RESPONSE_SIZE,
        responseBytes: text.length
      };
    } catch (e) {
      return { error: "parse failed", message: e && e.message };
    }
  }

  function extractShapeFromText(text, url) {
    var endpointTag = getEndpointTagFromUrl(url || window.location.href);
    var urlHint = url || window.location.href;
    var parsed = safeParseJson(text);
    if (parsed.error) {
      return {
        shape: null,
        sample: null,
        reason: parseErrorToReason(parsed.error),
        truncatedLargeResponse: false,
        responseBytes: parsed.size || 0
      };
    }
    var shape = extractShape(parsed.value, endpointTag, urlHint);
    if (!shape) {
      return {
        shape: null,
        sample: null,
        reason: "schema-extraction-failed",
        truncatedLargeResponse: false,
        responseBytes: parsed.responseBytes || 0
      };
    }
    return {
      shape: shape,
      sample: sampleFromParsedJson(parsed.value, endpointTag, urlHint),
      reason: null,
      truncatedLargeResponse: Boolean(parsed.truncatedLargeResponse),
      responseBytes: parsed.responseBytes || 0
    };
  }

  function extractShapeFromXHR(xhr, url) {
    var endpointTag = getEndpointTagFromUrl(url || window.location.href);
    var urlHint = url || window.location.href;
    var rt = xhr.responseType || "";
    if (rt === "json" || rt === "document") {
      if (xhr.response != null && typeof xhr.response === "object") {
        var fromResponse = extractShape(xhr.response, endpointTag, urlHint);
        if (fromResponse) {
          var responseBytes =
            xhr.responseText && xhr.responseText.length
              ? xhr.responseText.length
              : JSON.stringify(xhr.response).length;
          return {
            shape: fromResponse,
            sample: sampleFromParsedJson(xhr.response, endpointTag, urlHint),
            reason: null,
            truncatedLargeResponse: responseBytes > MAX_SAMPLE_RESPONSE_SIZE,
            responseBytes: responseBytes
          };
        }
      }
      if (rt === "json" && xhr.response != null) {
        var fromJsonRt = extractShape(xhr.response, endpointTag, urlHint);
        if (fromJsonRt) {
          var jsonRtBytes =
            xhr.responseText && xhr.responseText.length
              ? xhr.responseText.length
              : JSON.stringify(xhr.response).length;
          return {
            shape: fromJsonRt,
            sample: sampleFromParsedJson(xhr.response, endpointTag, urlHint),
            reason: null,
            truncatedLargeResponse: jsonRtBytes > MAX_SAMPLE_RESPONSE_SIZE,
            responseBytes: jsonRtBytes
          };
        }
      }
    }
    if (xhr.responseText) {
      return extractShapeFromText(xhr.responseText, url);
    }
    return {
      shape: null,
      sample: null,
      reason: "xhr-response-unavailable",
      truncatedLargeResponse: false,
      responseBytes: 0
    };
  }

  function shouldCaptureBody(body) {
    if (body == null) return false;
    if (typeof body === "string") return body.length > 0;
    if (typeof FormData !== "undefined" && body instanceof FormData) return true;
    if (typeof URLSearchParams !== "undefined" && body instanceof URLSearchParams) return true;
    if (typeof body === "object") return true;
    return false;
  }

  function shapeFromRequestBody(body, requestContentType, requestUrl) {
    if (!shouldCaptureBody(body)) return null;
    var endpointTag = getEndpointTagFromUrl(requestUrl || window.location.href);
    try {
      if (typeof body === "string") {
        var textResult = extractShapeFromText(body, requestUrl || window.location.href);
        return textResult.shape;
      }
      if (typeof URLSearchParams !== "undefined" && body instanceof URLSearchParams) {
        var paramsShape = {};
        body.forEach(function (_v, key) {
          if (!key) return;
          paramsShape[key] = isSensitiveKey(key, endpointTag) ? "[REDACTED:string]" : "string";
        });
        return Object.keys(paramsShape).length ? paramsShape : null;
      }
      if (typeof FormData !== "undefined" && body instanceof FormData) {
        var formShape = {};
        body.forEach(function (_v, key) {
          if (!key) return;
          formShape[key] = isSensitiveKey(key, endpointTag)
            ? "[REDACTED:form-data-field]"
            : "form-data-field";
        });
        return Object.keys(formShape).length ? formShape : null;
      }
      if (typeof body === "object" && body !== null && !(body instanceof Blob)) {
        var proto = Object.getPrototypeOf(body);
        if (proto === Object.prototype || proto === null) {
          return extractShape(body, endpointTag);
        }
      }
    } catch (e) {
      schemaDebugLog("request body shape failed", e && e.message);
    }
    return null;
  }

  function resolveAbsoluteUrl(url) {
    if (!url) return "";
    try {
      return new URL(url, window.location.href).href;
    } catch (e) {
      return String(url);
    }
  }

  function getContentTypeFromHeaders(headers) {
    if (!headers) return null;
    try {
      if (headers.get) {
        return headers.get("content-type") || headers.get("Content-Type");
      }
      return headers["content-type"] || headers["Content-Type"] || null;
    } catch (e) {
      return null;
    }
  }

  function postScoutMessage(meta, eventKind) {
    try {
      var payload = {
        source: MSG_SOURCE,
        type: MSG_TYPE,
        eventKind: eventKind || "observation",
        method: meta.method || "GET",
        url: meta.url || "",
        status: meta.status != null ? meta.status : null,
        contentType: meta.contentType || null,
        timestamp: meta.timestamp || new Date().toISOString(),
        requestContentType: meta.requestContentType || null,
        requestShape: meta.requestShape || null,
        responseShape: meta.responseShape || null,
        responseSample: meta.responseSample || null,
        truncatedLargeResponse: meta.truncatedLargeResponse === true,
        responseBytes: meta.responseBytes != null ? meta.responseBytes : null,
        captureSource: meta.captureSource || null,
        schemaMissingReason: meta.schemaMissingReason || null
      };
      schemaDebugLog(
        "post observation",
        meta.captureSource,
        meta.url,
        meta.schemaMissingReason || (meta.responseShape ? "has-schema" : "no-schema")
      );
      window.postMessage(payload, window.location.origin);
    } catch (e) {
      schemaDebugLog("postScoutMessage failed", e && e.message);
    }
  }

  function postPatchHealth() {
    try {
      window.postMessage(
        {
          source: MSG_SOURCE,
          type: MSG_TYPE,
          eventKind: "patch-health",
          fetchPatchActive: true,
          xhrPatchActive: true,
          schemaModeActive: SCHEMA_ENABLED,
          timestamp: new Date().toISOString()
        },
        window.location.origin
      );
      schemaDebugLog("patch-health posted", "schema=" + SCHEMA_ENABLED);
    } catch (e) {
      schemaDebugLog("patch-health failed", e && e.message);
    }
  }

  function postSchemaSelfTest() {
    try {
      window.postMessage(
        {
          type: MSG_TYPE,
          source: SELF_TEST_SOURCE,
          eventKind: "schema-self-test",
          method: "GET",
          url: window.location.href,
          status: 200,
          contentType: "application/json",
          timestamp: new Date().toISOString(),
          responseShape: {
            id: "number",
            label: "string",
            nested: { active: "boolean" }
          }
        },
        window.location.origin
      );
      schemaDebugLog("schema self-test posted");
    } catch (e) {
      schemaDebugLog("schema self-test failed", e && e.message);
    }
  }

  function resolveUrl(url) {
    if (typeof url === "string") return url;
    if (url && url.url) return url.url;
    return "";
  }

  function resolveMethod(url, options) {
    if (options && options.method) return String(options.method).toUpperCase();
    if (url && typeof url === "object" && url.method) return String(url.method).toUpperCase();
    return "GET";
  }

  function resolveRequestContentType(url, options) {
    var fromOptions = getContentTypeFromHeaders(options && options.headers);
    if (fromOptions) return fromOptions;
    if (url && typeof url === "object" && url.headers) {
      return getContentTypeFromHeaders(url.headers);
    }
    return null;
  }

  function hasStoredShape(meta) {
    return !!(meta.requestShape || meta.responseShape);
  }

  function finalizeLiveObservation(meta) {
    if (hasStoredShape(meta)) {
      meta.schemaMissingReason = null;
      schemaDebugLog("schema extracted", meta.captureSource, meta.url);
    } else if (!meta.schemaMissingReason) {
      schemaDebugLog("schema skipped", meta.captureSource, meta.url, "unknown");
    } else {
      schemaDebugLog("schema skipped", meta.captureSource, meta.url, meta.schemaMissingReason);
    }
    postScoutMessage(meta, "observation");
  }

  pageLog("injected", "schema=" + SCHEMA_ENABLED);

  var origFetch = window.fetch;
  window.fetch = function (url, options) {
    options = options || {};
    var urlStr = resolveAbsoluteUrl(resolveUrl(url));
    var method = resolveMethod(url, options);
    var requestContentType = resolveRequestContentType(url, options);
    var requestBody = options.body != null ? options.body : null;
    var requestShape = SCHEMA_ENABLED
      ? shapeFromRequestBody(requestBody, requestContentType, urlStr)
      : null;

    return origFetch.apply(this, arguments).then(function (res) {
      var contentType = null;
      try {
        contentType = res.headers && res.headers.get ? res.headers.get("content-type") : null;
      } catch (e) {}

      var meta = {
        captureSource: "fetch",
        method: method,
        url: urlStr,
        status: res.status,
        contentType: contentType,
        timestamp: new Date().toISOString(),
        requestContentType: requestContentType,
        requestShape: requestShape,
        responseShape: null,
        responseSample: null,
        schemaMissingReason: null
      };

      if (!SCHEMA_ENABLED) {
        meta.schemaMissingReason = "captured-before-schema-mode";
        finalizeLiveObservation(meta);
        return res;
      }

      if (!contentType || !isJsonContentType(contentType)) {
        meta.schemaMissingReason = "non-json-content-type";
        finalizeLiveObservation(meta);
        return res;
      }

      schemaDebugLog("JSON fetch detected", urlStr, contentType);

      try {
        return res
          .clone()
          .text()
          .then(function (text) {
            var result = extractShapeFromText(text, urlStr);
            meta.responseShape = result.shape;
            meta.responseSample = result.sample;
            meta.truncatedLargeResponse = Boolean(result.truncatedLargeResponse);
            meta.responseBytes = result.responseBytes || text.length;
            if (!meta.responseShape) {
              meta.schemaMissingReason = result.reason;
            }
            finalizeLiveObservation(meta);
            return res;
          })
          .catch(function (err) {
            meta.schemaMissingReason = "fetch-clone-failed";
            schemaDebugLog("fetch clone.text failed", urlStr, err && err.message);
            finalizeLiveObservation(meta);
            return res;
          });
      } catch (e) {
        meta.schemaMissingReason = "fetch-clone-failed";
        schemaDebugLog("fetch clone failed", urlStr, e && e.message);
        finalizeLiveObservation(meta);
        return res;
      }
    }).catch(function (err) {
      postScoutMessage(
        {
          captureSource: "fetch",
          method: method,
          url: urlStr,
          status: null,
          contentType: null,
          timestamp: new Date().toISOString(),
          requestContentType: requestContentType,
          requestShape: requestShape,
          responseShape: null,
          schemaMissingReason: null
        },
        "observation"
      );
      throw err;
    });
  };
  schemaDebugLog("fetch patch installed");

  var OrigXHR = window.XMLHttpRequest;
  var origXhrOpen = OrigXHR.prototype.open;
  var origXhrSetRequestHeader = OrigXHR.prototype.setRequestHeader;
  var origXhrSend = OrigXHR.prototype.send;

  OrigXHR.prototype.open = function (method, url) {
    this.__fhScoutMethod = String(method || "GET").toUpperCase();
    this.__fhScoutUrl = url || "";
    return origXhrOpen.apply(this, arguments);
  };

  OrigXHR.prototype.setRequestHeader = function (name, value) {
    if (name && String(name).toLowerCase() === "content-type") {
      this.__fhScoutReqCt = value;
    }
    return origXhrSetRequestHeader.apply(this, arguments);
  };

  OrigXHR.prototype.send = function (body) {
    var xhr = this;
    var requestShape = SCHEMA_ENABLED
      ? shapeFromRequestBody(body, xhr.__fhScoutReqCt || null, xhr.__fhScoutUrl || window.location.href)
      : null;
    var fired = false;

    function onLoadEnd() {
      if (fired) return;
      fired = true;

      var urlStr = resolveAbsoluteUrl(xhr.__fhScoutUrl || "");
      var contentType = null;
      try {
        contentType = xhr.getResponseHeader && xhr.getResponseHeader("content-type");
      } catch (e) {}

      var meta = {
        captureSource: "xhr",
        method: xhr.__fhScoutMethod || "GET",
        url: urlStr,
        status: xhr.status,
        contentType: contentType,
        timestamp: new Date().toISOString(),
        requestContentType: xhr.__fhScoutReqCt || null,
        requestShape: requestShape,
        responseShape: null,
        responseSample: null,
        schemaMissingReason: null
      };

      if (!SCHEMA_ENABLED) {
        meta.schemaMissingReason = "captured-before-schema-mode";
        finalizeLiveObservation(meta);
        return;
      }

      if (!contentType || !isJsonContentType(contentType)) {
        meta.schemaMissingReason = "non-json-content-type";
        finalizeLiveObservation(meta);
        return;
      }

      schemaDebugLog("JSON XHR detected", urlStr, contentType);
      var xhrResult = extractShapeFromXHR(xhr, urlStr);
      meta.responseShape = xhrResult.shape;
      meta.responseSample = xhrResult.sample;
      meta.truncatedLargeResponse = Boolean(xhrResult.truncatedLargeResponse);
      meta.responseBytes = xhrResult.responseBytes || 0;
      if (!meta.responseShape) {
        meta.schemaMissingReason = xhrResult.reason;
      }
      finalizeLiveObservation(meta);
    }

    xhr.addEventListener("loadend", onLoadEnd);
    xhr.addEventListener("error", onLoadEnd);
    xhr.addEventListener("abort", onLoadEnd);

    return origXhrSend.apply(this, arguments);
  };
  schemaDebugLog("XHR patch installed");

  postPatchHealth();

  if (SCHEMA_ENABLED) {
    postSchemaSelfTest();
  }
})();
