(function initializeMappingCopyButton() {
  "use strict";

  if (!window.FareHarborUtils) {
    setTimeout(initializeMappingCopyButton, 10);
    return;
  }

  const DEBUG = false;
  const LOG_PREFIX = "[mapping-copy-button]";
  const INJECTED_ATTR = "data-fhx-mapping-copy-btn";
  const ITEM_INJECTED_ATTR = "data-fhx-copy-item-mapping-btn";
  const ITEM_BUTTON_MARKER_ATTR = "data-fh-ext-copy-item-button";
  const ITEM_DATA_ATTR = "data-fh-copy-item-mapping-data";
  const ACTIONS_BAR_ATTR = "data-fh-ext-item-mapping-actions";
  const LINK_ACTION_CLASS = "fh-ext-link-action";
  const COPY_ITEM_BUTTON_ID = "fh-ext-copy-item-mapping-button";
  const COPY_MAPPING_BUTTON_ID = "fh-ext-copy-mapping-button";
  const PLACEMENT_ATTR = "data-fhx-mapping-copy-placement";
  const DEV_MODE_STORAGE_KEY = FareHarborDeveloperAuth.DEV_MODE_STORAGE_KEY;
  const SCAN_DEBOUNCE_MS = 300;
  const SCAN_THROTTLE_MS = 1000;
  const ROUTE_REEVAL_DELAY_MS = 150;
  const ROUTE_POLL_MS = 500;
  const RESELLER_ITEMS_CTRL_SELECTOR =
    'div[ng-controller="dashboard.settings.reseller.ResellerItemsCtrl"]';
  const RESELLER_ITEM_MAPPINGS_CTRL_SELECTOR =
    'div[ng-controller="dashboard.settings.reseller.ResellerItemMappingsCtrl"]';
  const TOOLBAR_GROUP_SELECTOR = ".toolbar.tb--no-gutters .tb-end .tb-group";
  const FLYOUT_WRAP_SELECTOR = ".tb-flyout-wrap";
  const STYLE_ID = "fhx-mapping-copy-btn-styles";
  const SETTING_KEY = "showCopyMappingDataButtons";
  const CHANNEL_COMPANY_LIST_RE =
    /^\/[^/]+\/dashboard\/settings\/integrations\/channels\/(\d+)\/?$/;
  const CHANNEL_ITEM_PAGE_RE =
    /\/dashboard\/settings\/integrations\/channels\/(\d+)\/items\/(\d+)\/?$/;
  const CHANNEL_ITEMS_HEADING_RE = /\bChannel Items\b/i;
  const ITEM_MAPPINGS_HEADING_RE = /^Item Mappings$/i;
  const ADD_CHANNEL_ITEM_RE = /add channel item/i;
  const ADD_COMPANY_RE = /add company/i;
  const PRIMARY_ACTION_RE = /^\+\s*add\b/i;
  const SHORT_NAME_ALIASES = {
    gyg: "getyourguide",
    getyourguide: "getyourguide",
    google: "google",
    viator: "viator",
    airbnb: "airbnb",
    bookingcom: "bookingcom",
    booking: "bookingcom",
    expedia: "expedia"
  };

  const MAPPING_COPY_STRATEGIES = {
    viator: {
      displayName: "Viator",
      copyHandler: "viator-complete",
      includeActivity: true,
      includeResellerOptions: true,
      includeCustomerTypes: true
    },
    google: {
      displayName: "Google",
      copyHandler: "google-complete",
      includeActivity: true,
      includeResellerOptions: true,
      includeCustomerTypes: true
    },
    getyourguide: {
      displayName: "GetYourGuide",
      copyHandler: "gyg-complete",
      includeActivity: true,
      includeResellerOptions: false,
      includeCustomerTypes: true
    },
    airbnb: {
      displayName: "Airbnb",
      copyHandler: "airbnb-complete",
      includeActivity: true,
      includeResellerOptions: false,
      includeCustomerTypes: false
    },
    bookingcom: {
      displayName: "Booking.com",
      copyHandler: "expedia-complete",
      includeActivity: true,
      includeResellerOptions: true,
      includeCustomerTypes: true
    },
    expedia: {
      displayName: "Expedia",
      copyHandler: "expedia-complete",
      includeActivity: true,
      includeResellerOptions: true,
      includeCustomerTypes: true
    }
  };

  const SINGLE_ITEM_AFFILIATES = new Set(["expedia", "getyourguide"]);

  if (DEBUG) {
    console.log("[mapping-copy-button] mapping-copy-button.js loaded");
  }

  let observer = null;
  let debounceTimer = null;
  let throttleTimer = null;
  let hrefPollTimer = null;
  let lastTrackedHref = "";
  let lastScanAt = 0;
  let scanInProgress = false;
  let devModeEnabled = false;
  let affiliateCache = new Map();
  let statusClearTimer = null;
  let copyInProgress = false;
  let itemCopyInProgress = false;
  let lifecycleEvalTimer = null;
  let watchersActive = false;
  let routeWatchersStarted = false;
  let lastScanCache = null;
  let featureEnabled = true;
  const loggedInsertions = new Set();

  function log(...args) {
    if (DEBUG) {
      console.log(LOG_PREFIX, ...args);
    }
  }

  function devLog(...args) {
    if (DEBUG || devModeEnabled) {
      console.log(LOG_PREFIX, ...args);
    }
  }

  function warn(...args) {
    console.warn(LOG_PREFIX, ...args);
  }

  function loadDevMode() {
    if (typeof chrome === "undefined" || !chrome.storage?.local) {
      return;
    }
    FareHarborDeveloperAuth.syncDevModeState().then((active) => {
      devModeEnabled = active;
    });
    chrome.storage.onChanged?.addListener((changes, area) => {
      if (area === "local" && changes[DEV_MODE_STORAGE_KEY]) {
        FareHarborDeveloperAuth.syncDevModeState().then((active) => {
          devModeEnabled = active;
        });
      }
    });
  }

  function isExtensionNode(node) {
    if (!node) {
      return false;
    }
    if (node.nodeType === Node.TEXT_NODE) {
      return isExtensionNode(node.parentElement);
    }
    if (!(node instanceof Element)) {
      return false;
    }
    if (node.id === STYLE_ID || node.id === COPY_ITEM_BUTTON_ID || node.id === COPY_MAPPING_BUTTON_ID) {
      return true;
    }
    if (
      node.hasAttribute(INJECTED_ATTR) ||
      node.hasAttribute(ITEM_INJECTED_ATTR) ||
      node.hasAttribute(ITEM_DATA_ATTR) ||
      node.getAttribute(ACTIONS_BAR_ATTR) === "true" ||
      node.getAttribute(ITEM_BUTTON_MARKER_ATTR) === "true" ||
      node.getAttribute("data-fh-copy-item-mapping-links") === "true"
    ) {
      return true;
    }
    if (
      node.classList?.contains("fhx-mapping-copy-toolbar-control") ||
      node.classList?.contains("fh-ext-item-mapping-actions") ||
      node.classList?.contains(LINK_ACTION_CLASS) ||
      node.classList?.contains("fh-ext-action-separator") ||
      node.classList?.contains("fhx-mapping-copy-status") ||
      node.classList?.contains("fh-ext-link-action-label")
    ) {
      return true;
    }
    return !!node.closest?.(
      `[${INJECTED_ATTR}], [${ITEM_INJECTED_ATTR}], [${ITEM_DATA_ATTR}], [${ACTIONS_BAR_ATTR}], [data-fh-copy-item-mapping-links="true"], .fh-ext-item-mapping-actions, #${STYLE_ID}`
    );
  }

  function isExtensionMutation(mutation) {
    if (isExtensionNode(mutation.target)) {
      return true;
    }
    for (const node of mutation.addedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    for (const node of mutation.removedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    return false;
  }

  function getScanSnapshot() {
    const itemContext = parseChannelItemPageContext();
    if (itemContext) {
      const section = findItemMappingsSection();
      const bar = section?.querySelector(`[${ACTIONS_BAR_ATTR}="true"]`);
      const button = bar?.querySelector(`[${ITEM_DATA_ATTR}="true"]`);
      return {
        href: location.href,
        pageType: "item",
        sectionCount: section ? 1 : 0,
        buttonsPresent: !!button
      };
    }

    const pageContext = parseChannelCompanyListContext();
    if (!pageContext) {
      return {
        href: location.href,
        pageType: "none",
        sectionCount: 0,
        buttonsPresent: false
      };
    }

    const sectionInfo = findChannelItemsSection();
    const placement = sectionInfo ? resolvePlacement(sectionInfo) : null;
    const wrap =
      sectionInfo?.section && placement?.ready
        ? findExistingMappingCopyWrap(sectionInfo.section, placement)
        : null;

    return {
      href: location.href,
      pageType: "list",
      sectionCount: sectionInfo?.section ? 1 : 0,
      buttonsPresent: !!wrap
    };
  }

  function scanSnapshotUnchanged(snapshot) {
    if (!lastScanCache || !snapshot.buttonsPresent) {
      return false;
    }
    return (
      lastScanCache.href === snapshot.href &&
      lastScanCache.pageType === snapshot.pageType &&
      lastScanCache.sectionCount === snapshot.sectionCount &&
      lastScanCache.buttonsPresent === snapshot.buttonsPresent
    );
  }

  function resetScanState() {
    lastScanCache = null;
    loggedInsertions.clear();
  }

  function logInsertionOnce(key, message, data) {
    if (loggedInsertions.has(key)) {
      return;
    }
    loggedInsertions.add(key);
    console.log(LOG_PREFIX, message, data ?? "");
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function isElementVisible(el) {
    if (!el || !(el instanceof Element)) {
      return false;
    }
    if (el.closest("[hidden]")) {
      return false;
    }
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") {
      return false;
    }
    return el.getClientRects().length > 0;
  }

  function normalizeVisibleText(text) {
    return String(text || "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function getArrayField(data, ...keys) {
    if (!data || typeof data !== "object") {
      return null;
    }
    for (const key of keys) {
      if (Array.isArray(data[key])) {
        return data[key];
      }
    }
    return null;
  }

  async function fareHarborApiFetch(path, apiOrigin) {
    if (window.CustomerTypeMappingFinder?.fareHarborApiFetch) {
      return window.CustomerTypeMappingFinder.fareHarborApiFetch(path, apiOrigin);
    }

    const origin = apiOrigin || window.location.origin;
    const url = path.startsWith("/api/v1")
      ? `${origin}${path}`
      : `${origin}/api/v1${path}`;

    try {
      const response = await fetch(url, {
        method: "GET",
        credentials: "include",
        headers: { Accept: "application/json" }
      });

      if (!response.ok) {
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `API request failed with status ${response.status}`,
          url
        };
      }

      const data = await response.json();
      return { ok: true, status: response.status, data, error: null, url };
    } catch (err) {
      return {
        ok: false,
        status: null,
        data: null,
        error: `Fetch failed: ${err.message}`,
        url
      };
    }
  }

  function parseChannelCompanyListContext() {
    if (!isFareHarborHost()) {
      return null;
    }

    const pathname = (location.pathname || "").replace(/\/+$/, "");
    if (!pathname || /\/items\/\d+/.test(pathname)) {
      return null;
    }

    const numericMatch = pathname.match(CHANNEL_COMPANY_LIST_RE);
    if (numericMatch) {
      const parts = pathname.split("/").filter(Boolean);
      return {
        shortname: parts[0],
        companyPk: numericMatch[1],
        apiOrigin: window.location.origin
      };
    }

    const parts = pathname.split("/").filter(Boolean);
    const dashIdx = parts.indexOf("dashboard");
    if (
      dashIdx >= 1 &&
      parts[dashIdx + 1] === "settings" &&
      parts[dashIdx + 2] === "integrations" &&
      parts[dashIdx + 3] === "channels"
    ) {
      const slug = parts[dashIdx + 4];
      const nextSegment = parts[dashIdx + 5];
      if (slug && !/^\d+$/.test(slug) && !nextSegment) {
        return {
          shortname: parts[0],
          channelSlug: slug.toLowerCase(),
          apiOrigin: window.location.origin
        };
      }
    }

    return null;
  }

  function parseChannelItemPageContext() {
    if (!isFareHarborHost()) {
      return null;
    }

    const pathname = (location.pathname || "").replace(/\/+$/, "");
    const match = pathname.match(CHANNEL_ITEM_PAGE_RE);
    if (!match) {
      return null;
    }

    const parts = pathname.split("/").filter(Boolean);
    return {
      shortname: parts[0],
      companyPk: match[1],
      resellerItemId: match[2],
      apiOrigin: window.location.origin
    };
  }

  function normalizeAffiliateKey(company) {
    if (!company) {
      return null;
    }

    const otaType = String(company.ota_type || company.otaType || "")
      .trim()
      .toLowerCase();
    if (otaType && MAPPING_COPY_STRATEGIES[otaType]) {
      return otaType;
    }

    if (!otaType) {
      const shortName = String(company.short_name || company.shortName || "")
        .trim()
        .toLowerCase();
      const aliasKey = SHORT_NAME_ALIASES[shortName] || shortName;
      if (MAPPING_COPY_STRATEGIES[aliasKey]) {
        return aliasKey;
      }
    }

    return null;
  }

  function companyMatchesSlug(company, slug) {
    if (!company || !slug) {
      return false;
    }
    const normalizedSlug = String(slug).toLowerCase();
    const candidates = [
      company.short_name,
      company.shortName,
      company.ota_type,
      company.otaType,
      company.name
    ]
      .filter(Boolean)
      .map((value) => String(value).toLowerCase());

    if (candidates.includes(normalizedSlug)) {
      return true;
    }

    const aliasKey = SHORT_NAME_ALIASES[normalizedSlug];
    if (aliasKey) {
      return candidates.includes(aliasKey) || normalizeAffiliateKey(company) === aliasKey;
    }

    return false;
  }

  async function fetchResellerCompany(pageContext) {
    const cacheKey = [
      pageContext.shortname,
      pageContext.companyPk || pageContext.channelSlug || ""
    ].join(":");
    if (affiliateCache.has(cacheKey)) {
      return affiliateCache.get(cacheKey);
    }

    const companiesUrl = `/companies/${encodeURIComponent(pageContext.shortname)}/reseller-companies/`;
    const companiesResult = await fareHarborApiFetch(companiesUrl, pageContext.apiOrigin);
    if (!companiesResult.ok) {
      const failure = { ok: false, error: companiesResult.error };
      affiliateCache.set(cacheKey, failure);
      return failure;
    }

    const companies =
      getArrayField(companiesResult.data, "reseller_companies", "resellerCompanies") || [];

    let company = null;
    if (pageContext.companyPk) {
      company = companies.find(
        (entry) => String(entry?.pk) === String(pageContext.companyPk)
      );
    } else if (pageContext.channelSlug) {
      company = companies.find((entry) => companyMatchesSlug(entry, pageContext.channelSlug));
      if (company?.pk != null) {
        pageContext.companyPk = String(company.pk);
      }
    }

    if (!company) {
      const failure = { ok: false, error: "Reseller company not found for this page." };
      affiliateCache.set(cacheKey, failure);
      return failure;
    }

    const affiliateKey = normalizeAffiliateKey(company);
    if (!affiliateKey) {
      const failure = { ok: false, error: "Affiliate type could not be determined." };
      affiliateCache.set(cacheKey, failure);
      return failure;
    }

    const strategy = {
      ...MAPPING_COPY_STRATEGIES[affiliateKey],
      affiliateKey,
      company
    };
    const success = { ok: true, strategy };
    affiliateCache.set(cacheKey, success);
    return success;
  }

  function findChannelItemsTable(root) {
    const scope = root || document;
    const selectors = [
      'table[ng-if="resellerItems.length"]',
      'table[ng-table="resellerItems"]',
      'table[ng-controller*="ResellerItemsController"]',
      "table.reseller-items-table",
      'table.spreadsheet[ng-if="resellerItems.length"]',
      'table[ng-table*="resellerItems"]'
    ];

    for (const selector of selectors) {
      const table = scope.querySelector(selector);
      if (table) {
        return table;
      }
    }

    const tables = scope.querySelectorAll("table");
    for (const table of tables) {
      if (table.querySelector('tbody[ng-repeat*="resellerItem"]')) {
        return table;
      }

      const headerText = table.querySelector("thead")?.innerText || "";
      if (/item mappings/i.test(headerText) && /name/i.test(headerText)) {
        return table;
      }
    }

    return null;
  }

  function isChannelItemsHeading(el) {
    if (!el || !(el instanceof Element) || !isElementVisible(el)) {
      return false;
    }

    const text = normalizeVisibleText(el.textContent);
    if (!CHANNEL_ITEMS_HEADING_RE.test(text) || text.length > 80) {
      return false;
    }

    return true;
  }

  function findChannelItemsRoot() {
    return document.querySelector(RESELLER_ITEMS_CTRL_SELECTOR);
  }

  function findChannelItemsSection() {
    const root = findChannelItemsRoot();
    if (root) {
      const table = findChannelItemsTable(root);
      if (!table) {
        return null;
      }

      let heading = null;
      for (const el of root.querySelectorAll("h1, h2, h3, h4, h5, h6, strong, span, p")) {
        if (isChannelItemsHeading(el)) {
          heading = el;
          break;
        }
      }

      return { section: root, heading, table, root };
    }

    const headingSelectors =
      "h1, h2, h3, h4, h5, h6, legend, label, strong, span, p, div";

    for (const heading of document.querySelectorAll(headingSelectors)) {
      if (!isChannelItemsHeading(heading)) {
        continue;
      }

      let walk = heading.parentElement;
      while (walk && walk !== document.body) {
        const table = findChannelItemsTable(walk);
        if (table) {
          return { section: walk, heading, table, root: null };
        }
        walk = walk.parentElement;
      }
    }

    const table = findChannelItemsTable(document);
    if (!table) {
      return null;
    }

    let walk = table.parentElement;
    while (walk && walk !== document.body) {
      for (const heading of walk.querySelectorAll(headingSelectors)) {
        if (isChannelItemsHeading(heading)) {
          return { section: walk, heading, table, root: null };
        }
      }
      walk = walk.parentElement;
    }

    const section =
      table.closest("section, article, main, form, fieldset") ||
      table.parentElement?.parentElement ||
      table.parentElement;

    return section ? { section, heading: null, table, root: null } : null;
  }

  function formatButtonLabel(displayName) {
    return `Copy ${displayName} Mapping Data`;
  }

  function formatSingleItemButtonLabel(displayName) {
    return `Copy ${displayName} Item Data`;
  }

  function createClipboardIcon() {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    svg.setAttribute("aria-hidden", "true");
    svg.setAttribute("focusable", "false");
    svg.setAttribute("width", "14");
    svg.setAttribute("height", "14");
    svg.setAttribute("viewBox", "0 0 14 14");
    svg.classList.add("fhx-mapping-copy-btn-icon");

    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("fill", "currentColor");
    path.setAttribute(
      "d",
      "M4.88 1.13a.63.63 0 0 1 .62-.63h2.75a.63.63 0 0 1 .62.63V2.5h1.38A1.38 1.38 0 0 1 11.63 3.88v7.25A1.38 1.38 0 0 1 10.25 12.5H3.75A1.38 1.38 0 0 1 2.38 11.13V3.88A1.38 1.38 0 0 1 3.75 2.5H5.13V1.13ZM5.5 2.5V1.75h2.75V2.5H5.5ZM3.75 3.25c-.42 0-.75.33-.75.75v7.25c0 .42.33.75.75.75h6.5c.42 0 .75-.33.75-.75V4c0-.42-.33-.75-.75-.75H9.25v.63a.63.63 0 0 1-.62.62H5.38a.63.63 0 0 1-.62-.62V3.25H3.75Z"
    );
    svg.appendChild(path);
    return svg;
  }

  function getMappingCopyButtonLabel(button) {
    const labelEl = button?.querySelector(".fhx-mapping-copy-btn-label");
    if (labelEl) {
      return normalizeVisibleText(labelEl.textContent);
    }
    return normalizeVisibleText(button?.textContent || "");
  }

  function setMappingCopyButtonLabel(button, label) {
    const labelEl = button?.querySelector(".fhx-mapping-copy-btn-label");
    if (labelEl) {
      labelEl.textContent = label;
    }
  }

  function ensureMappingCopyButtonStructure(button, label) {
    if (!button) {
      return;
    }

    if (!button.querySelector(".fhx-mapping-copy-btn-icon")) {
      button.prepend(createClipboardIcon());
    }

    let labelEl = button.querySelector(".fhx-mapping-copy-btn-label");
    if (!labelEl) {
      labelEl = document.createElement("span");
      labelEl.className = "fhx-mapping-copy-btn-label";
      button.appendChild(labelEl);
    }

    labelEl.textContent = label;
  }

  function buildMappingCopyButton({ label, id, markerAttr, markerValue, onClick }) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "fhx-mapping-copy-btn";
    ensureMappingCopyButtonStructure(button, label);

    if (id) {
      button.id = id;
    }
    if (markerAttr) {
      button.setAttribute(markerAttr, markerValue);
    }
    if (onClick) {
      button.addEventListener("click", onClick);
    }

    return button;
  }

  function isMappingPageContext() {
    return !!(parseChannelCompanyListContext() || parseChannelItemPageContext());
  }

  function isIntegrationsChannelsPath() {
    if (!isFareHarborHost()) {
      return false;
    }
    return /\/dashboard\/settings\/integrations\/channels\//.test(
      (location.pathname || "").replace(/\/+$/, "")
    );
  }

  function hasMappingDomMarkers() {
    if (findChannelItemsRoot()) {
      return true;
    }
    if (document.querySelector(RESELLER_ITEM_MAPPINGS_CTRL_SELECTOR)) {
      return true;
    }
    if (findItemMappingsSection()) {
      return true;
    }
    for (const heading of document.querySelectorAll("h2")) {
      if (ITEM_MAPPINGS_HEADING_RE.test(normalizeVisibleText(heading.textContent))) {
        return true;
      }
    }
    return false;
  }

  function isPageEligibleForMappingCopy() {
    if (!isFareHarborHost()) {
      return false;
    }
    if (isMappingPageContext()) {
      return true;
    }
    if (isIntegrationsChannelsPath()) {
      return true;
    }
    return hasMappingDomMarkers();
  }

  function isPrimaryCreateAction(el) {
    if (!el || !(el instanceof Element)) {
      return false;
    }
    const text = normalizeVisibleText(el.textContent);
    return (
      ADD_CHANNEL_ITEM_RE.test(text) ||
      ADD_COMPANY_RE.test(text) ||
      PRIMARY_ACTION_RE.test(text)
    );
  }

  function findHeaderFallbackContainer(section, heading, table) {
    const candidates = [];

    if (heading) {
      let node = heading.parentElement;
      while (node && node !== section) {
        const containsTable = table && node.contains(table);
        const containsAdd = Array.from(node.querySelectorAll("button, a.btn, .btn")).some(
          isPrimaryCreateAction
        );
        if (!containsTable) {
          candidates.push({ node, containsAdd });
        }
        node = node.parentElement;
      }
    }

    const withoutAdd = candidates.find((candidate) => !candidate.containsAdd);
    if (withoutAdd) {
      return withoutAdd.node;
    }
    if (candidates.length) {
      return candidates[0].node;
    }

    return null;
  }

  function findChannelItemsToolbarPlacement(root) {
    const tbGroup = root.querySelector(TOOLBAR_GROUP_SELECTOR);
    if (!tbGroup) {
      return { ready: false, pending: true };
    }

    const flyoutWrap = tbGroup.querySelector(FLYOUT_WRAP_SELECTOR);
    if (flyoutWrap) {
      return {
        ready: true,
        mode: "toolbar-before-flyout",
        container: tbGroup,
        insertBefore: flyoutWrap,
        logMessage: "Inserted into Channel Items toolbar before display options"
      };
    }

    return {
      ready: true,
      mode: "toolbar-append-group",
      container: tbGroup,
      insertBefore: null,
      logMessage: "Inserted into Channel Items toolbar group fallback"
    };
  }

  function resolvePlacement(sectionInfo) {
    const root = sectionInfo.root || findChannelItemsRoot();

    if (root) {
      return findChannelItemsToolbarPlacement(root);
    }

    const headerContainer = findHeaderFallbackContainer(
      sectionInfo.section,
      sectionInfo.heading,
      sectionInfo.table
    );
    if (headerContainer) {
      return {
        ready: true,
        mode: "header-fallback",
        container: headerContainer,
        insertBefore: null,
        logMessage: "Inserted in Channel Items header fallback"
      };
    }

    return { ready: false, pending: true };
  }

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) {
      return;
    }

    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .fhx-mapping-copy-toolbar-control {
        display: inline-flex;
        align-items: center;
        margin-right: 6px;
        position: relative;
        vertical-align: middle;
      }
      .fhx-mapping-copy-btn {
        appearance: none;
        -webkit-appearance: none;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin: 0;
        padding: 0;
        background: none;
        border: none;
        border-radius: 0;
        font-size: 13px;
        font-weight: 400;
        color: #6b8ca3;
        cursor: pointer;
        line-height: 1.4;
        white-space: nowrap;
        font-family: inherit;
        box-shadow: none;
      }
      .fhx-mapping-copy-btn:hover:not(:disabled) {
        color: #4d6272;
        text-decoration: underline;
      }
      .fhx-mapping-copy-btn:disabled {
        opacity: 0.6;
        cursor: default;
      }
      .fhx-mapping-copy-btn-icon {
        width: 14px;
        height: 14px;
        flex-shrink: 0;
      }
      .fhx-mapping-copy-status {
        position: absolute;
        top: calc(100% + 2px);
        right: 0;
        font-size: 11px;
        color: #4d6272;
        max-width: 280px;
        line-height: 1.3;
        white-space: nowrap;
        pointer-events: none;
        z-index: 2;
      }
      .fhx-mapping-copy-status--error {
        color: #8a4b12;
      }
      .fhx-mapping-copy-status--success {
        color: #24553a;
      }
    `;
    document.documentElement.appendChild(style);
  }

  function setInlineStatus(wrap, message, type) {
    if (!wrap) {
      return;
    }
    const statusEl = wrap.querySelector(".fhx-mapping-copy-status");
    if (!statusEl) {
      return;
    }

    statusEl.textContent = message || "";
    statusEl.classList.remove(
      "fhx-mapping-copy-status--error",
      "fhx-mapping-copy-status--success"
    );
    if (type === "error") {
      statusEl.classList.add("fhx-mapping-copy-status--error");
    } else if (type === "success") {
      statusEl.classList.add("fhx-mapping-copy-status--success");
    }

    if (statusClearTimer) {
      clearTimeout(statusClearTimer);
      statusClearTimer = null;
    }
    if (message) {
      statusClearTimer = setTimeout(() => {
        statusEl.textContent = "";
        statusEl.classList.remove(
          "fhx-mapping-copy-status--error",
          "fhx-mapping-copy-status--success"
        );
        statusClearTimer = null;
      }, 4000);
    }
  }

  function removeAllInjectedCopyControls() {
    document
      .querySelectorAll(
        `[${INJECTED_ATTR}="1"], .fhx-mapping-copy-wrap, .fhx-mapping-copy-toolbar, [${ITEM_INJECTED_ATTR}="1"], [${ITEM_DATA_ATTR}="true"], [${ACTIONS_BAR_ATTR}="true"]`
      )
      .forEach((el) => {
        el.remove();
      });
  }

  function applyFeatureSetting(enabled, reason) {
    featureEnabled = enabled !== false;
    if (!featureEnabled) {
      stopObserver();
      removeAllInjectedCopyControls();
      watchersActive = false;
      if (debounceTimer) {
        clearTimeout(debounceTimer);
        debounceTimer = null;
      }
      if (throttleTimer) {
        clearTimeout(throttleTimer);
        throttleTimer = null;
      }
      return;
    }
    evaluateLifecycle(reason || "setting-enabled");
  }

  function initSettingsBinding() {
    const settings = window.FHSettings;
    if (!settings) {
      return;
    }
    settings.get(SETTING_KEY, (value) => {
      applyFeatureSetting(value, "settings-init");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SETTING_KEY]) {
        applyFeatureSetting(changes[SETTING_KEY].newValue, "setting-change");
      }
    });
  }

  function removeMisplacedCopyControls(section) {
    document
      .querySelectorAll(
        `[${INJECTED_ATTR}="1"], .fhx-mapping-copy-wrap[${INJECTED_ATTR}="1"], .fhx-mapping-copy-toolbar`
      )
      .forEach((el) => {
        const placement = el.getAttribute(PLACEMENT_ATTR);
        const isLegacyPlacement = placement === "append-right" || placement === "toolbar";
        const outsideSection = section && !section.contains(el);
        if (!section || outsideSection || isLegacyPlacement) {
          el.remove();
        }
      });
  }

  function cleanupStaleInjections(pageContext) {
    const sectionInfo = findChannelItemsSection();
    const section = sectionInfo?.section;

    if (!pageContext || !section) {
      document
        .querySelectorAll(`[${INJECTED_ATTR}="1"], .fhx-mapping-copy-wrap, .fhx-mapping-copy-toolbar`)
        .forEach((el) => el.remove());
      return;
    }

    removeMisplacedCopyControls(section);

    document.querySelectorAll(`[${INJECTED_ATTR}="1"]`).forEach((el) => {
      if (!section.contains(el)) {
        el.remove();
      }
    });
  }

  function createCopyButtonWrap(strategy) {
    const label = formatButtonLabel(strategy.displayName);
    const wrap = document.createElement("div");
    wrap.className = "fhx-mapping-copy-toolbar-control";
    wrap.setAttribute(INJECTED_ATTR, "1");

    const button = buildMappingCopyButton({
      label,
      onClick: () => {
        handleCopyClick(wrap, strategy);
      }
    });
    wrap.appendChild(button);

    const statusEl = document.createElement("span");
    statusEl.className = "fhx-mapping-copy-status";
    statusEl.setAttribute("aria-live", "polite");
    wrap.appendChild(statusEl);

    return wrap;
  }

  function updateCopyButtonWrap(wrap, strategy, placement) {
    const button = wrap.querySelector(".fhx-mapping-copy-btn");
    if (button) {
      ensureMappingCopyButtonStructure(button, formatButtonLabel(strategy.displayName));
    }
    wrap.setAttribute(PLACEMENT_ATTR, placement.mode);
    return wrap;
  }

  function isWrapCorrectlyPlaced(wrap, placement) {
    if (!wrap || !placement?.ready) {
      return false;
    }

    if (placement.mode === "toolbar-before-flyout") {
      return (
        wrap.parentElement === placement.container &&
        wrap.nextElementSibling === placement.insertBefore
      );
    }

    if (placement.mode === "toolbar-append-group") {
      return wrap.parentElement === placement.container;
    }

    if (placement.mode === "header-fallback") {
      return placement.container?.contains(wrap);
    }

    return false;
  }

  function findExistingMappingCopyWrap(section, placement) {
    if (!section) {
      return null;
    }

    const wrap = section.querySelector(`[${INJECTED_ATTR}="1"]`);
    if (wrap && isWrapCorrectlyPlaced(wrap, placement)) {
      return wrap;
    }

    return null;
  }

  function findItemMappingsSection() {
    const sections = window.ItemMappingLinkCopy?.findItemMappingsSections?.();
    if (sections?.length) {
      return sections[0];
    }

    const ctrl = document.querySelector(RESELLER_ITEM_MAPPINGS_CTRL_SELECTOR);
    if (!ctrl) {
      return null;
    }

    const inner =
      ctrl.querySelector('div[ng-can-list="ResellerItemMapping on company"]') || ctrl;
    const header = inner.querySelector(".reseller-header");
    const heading = header?.querySelector("h2");
    if (
      !heading ||
      !ITEM_MAPPINGS_HEADING_RE.test(normalizeVisibleText(heading.textContent))
    ) {
      return null;
    }

    return inner;
  }

  function ensureItemMappingActionsBar(section) {
    if (window.ItemMappingLinkCopy?.ensureActionsBar) {
      window.ItemMappingLinkCopy.injectActionStyles?.();
      return window.ItemMappingLinkCopy.ensureActionsBar(section);
    }

    const blockList = section.querySelector("ul.block-list");
    let bar = section.querySelector(`[${ACTIONS_BAR_ATTR}="true"]`);
    if (!bar) {
      bar = document.createElement("div");
      bar.className = "fh-ext-item-mapping-actions";
      bar.setAttribute(ACTIONS_BAR_ATTR, "true");
    }
    if (blockList) {
      if (blockList.nextElementSibling !== bar) {
        blockList.insertAdjacentElement("afterend", bar);
      }
    } else if (!section.contains(bar)) {
      section.appendChild(bar);
    }
    return bar;
  }

  function syncItemMappingActionsBar(section) {
    if (window.ItemMappingLinkCopy?.syncActionsBarLayout) {
      return window.ItemMappingLinkCopy.syncActionsBarLayout(section);
    }
    return section.querySelector(`[${ACTIONS_BAR_ATTR}="true"]`);
  }

  function removeLegacySingleItemHeaderButtons(section) {
    if (!section) {
      return;
    }

    section.querySelectorAll(".fhx-mapping-copy-item-header-action").forEach((wrap) => {
      wrap.remove();
    });
  }

  function getItemMappingActionLabel(button) {
    if (window.ItemMappingLinkCopy?.getLinkActionLabel) {
      return normalizeVisibleText(window.ItemMappingLinkCopy.getLinkActionLabel(button));
    }
    return normalizeVisibleText(button?.textContent || "");
  }

  function setItemMappingActionLabel(button, label) {
    if (window.ItemMappingLinkCopy?.ensureLinkActionButtonStructure) {
      window.ItemMappingLinkCopy.ensureLinkActionButtonStructure(
        button,
        label,
        window.ItemMappingLinkCopy.createClipboardIcon
      );
      return;
    }
    if (button) {
      button.textContent = label;
    }
  }

  function buildItemMappingDataButton({ label, onClick }) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = LINK_ACTION_CLASS;
    button.id = COPY_ITEM_BUTTON_ID;
    button.setAttribute(ITEM_DATA_ATTR, "true");
    button.setAttribute(ITEM_BUTTON_MARKER_ATTR, "true");
    setItemMappingActionLabel(button, label);
    if (onClick) {
      button.addEventListener("click", onClick);
    }
    return button;
  }

  function isItemMappingActionsBarPlaced(section, bar) {
    if (!section || !bar || !section.contains(bar)) {
      return false;
    }

    const blockList = section.querySelector("ul.block-list");
    if (blockList) {
      return blockList.nextElementSibling === bar;
    }

    return bar.parentElement === section;
  }

  function isSingleItemButtonCorrectlyPlaced(section, strategy) {
    if (!section || !strategy) {
      return null;
    }

    const bar = section.querySelector(`[${ACTIONS_BAR_ATTR}="true"]`);
    if (!bar || !isItemMappingActionsBarPlaced(section, bar)) {
      return null;
    }

    const button =
      bar.querySelector(`[${ITEM_DATA_ATTR}="true"]`) ||
      document.getElementById(COPY_ITEM_BUTTON_ID);
    if (!button || !bar.contains(button)) {
      return null;
    }

    const expectedLabel = formatSingleItemButtonLabel(strategy.displayName);
    if (getItemMappingActionLabel(button) !== expectedLabel) {
      return null;
    }

    if (!button.id) {
      button.id = COPY_ITEM_BUTTON_ID;
    }
    if (button.getAttribute(ITEM_BUTTON_MARKER_ATTR) !== "true") {
      button.setAttribute(ITEM_BUTTON_MARKER_ATTR, "true");
    }

    return bar;
  }

  function ensureCopyButton(placement, strategy) {
    const sectionInfo = findChannelItemsSection();
    const section = sectionInfo?.section;

    const existingWrap = findExistingMappingCopyWrap(section, placement);
    if (existingWrap) {
      return { wrap: updateCopyButtonWrap(existingWrap, strategy, placement), inserted: false };
    }

    removeMisplacedCopyControls(section);

    document.querySelectorAll(`[${INJECTED_ATTR}="1"]`).forEach((wrap) => {
      if (!section?.contains(wrap) || !isWrapCorrectlyPlaced(wrap, placement)) {
        wrap.remove();
      }
    });

    let wrap = section?.querySelector(`[${INJECTED_ATTR}="1"]`) || null;
    if (wrap && isWrapCorrectlyPlaced(wrap, placement)) {
      return { wrap: updateCopyButtonWrap(wrap, strategy, placement), inserted: false };
    }

    if (wrap) {
      wrap.remove();
      wrap = null;
    }

    wrap = createCopyButtonWrap(strategy);
    wrap.setAttribute(PLACEMENT_ATTR, placement.mode);

    const button = wrap.querySelector(".fhx-mapping-copy-btn");
    if (button) {
      button.id = COPY_MAPPING_BUTTON_ID;
    }

    if (placement.mode === "toolbar-before-flyout") {
      placement.container.insertBefore(wrap, placement.insertBefore);
    } else if (placement.mode === "toolbar-append-group") {
      placement.container.appendChild(wrap);
    } else if (placement.mode === "header-fallback") {
      placement.container.appendChild(wrap);
    }

    return { wrap, inserted: true };
  }

  async function copyExpediaComplete() {
    if (!window.ExpediaMapping?.scrapeCompleteResellerItems || !window.ExpediaMapping?.formatCompleteDataAsHTML) {
      return {
        success: false,
        error: "Mapping copy module not ready. Reload the page."
      };
    }

    const extractResult = window.ExpediaMapping.scrapeCompleteResellerItems();
    if (!extractResult?.success) {
      return {
        success: false,
        error: extractResult?.error || "Could not find channel item table on this page."
      };
    }
    if (!extractResult.data?.length) {
      return {
        success: false,
        error: "No channel item mappings found."
      };
    }

    const htmlData = window.ExpediaMapping.formatCompleteDataAsHTML(
      extractResult.data,
      extractResult.channelInfo
    );
    return {
      success: true,
      htmlData,
      count: extractResult.data.length
    };
  }

  async function copyGygComplete() {
    log("GetYourGuide copy requested with includeHeader=true");
    if (!window.FareHarborResellerItems?.runCompleteMappingCopyHtml) {
      return {
        success: false,
        error: "Mapping copy module not ready. Reload the page."
      };
    }

    const result = await window.FareHarborResellerItems.runCompleteMappingCopyHtml({
      useChannelName: false,
      includeHeaderRow: true,
      includeApiEnrichment: false
    });
    if (!result?.success) {
      return {
        success: false,
        error: result.error || "No channel item mappings found."
      };
    }

    return {
      success: true,
      htmlData: result.htmlData,
      count: result.count
    };
  }

  async function copyViatorComplete() {
    if (!window.ViatorMappingFile?.scrapeViatorMappingFile || !window.ViatorMappingFile?.formatAsHTML) {
      return {
        success: false,
        error: "Mapping copy module not ready. Reload the page."
      };
    }

    const data = window.ViatorMappingFile.scrapeViatorMappingFile();
    if (!data?.length) {
      return {
        success: false,
        error: "No channel item mappings found."
      };
    }

    const htmlData = window.ViatorMappingFile.formatAsHTML(data);
    return {
      success: true,
      htmlData,
      count: data.length
    };
  }

  async function copyAirbnbComplete() {
    if (!window.AirbnbMappingFile?.scrapeAirbnbMappingFile || !window.AirbnbMappingFile?.formatAsHTML) {
      return {
        success: false,
        error: "Mapping copy module not ready. Reload the page."
      };
    }

    const data = window.AirbnbMappingFile.scrapeAirbnbMappingFile();
    if (!data?.length) {
      return {
        success: false,
        error: "No channel item mappings found."
      };
    }

    const htmlData = window.AirbnbMappingFile.formatAsHTML(data);
    return {
      success: true,
      htmlData,
      count: data.length
    };
  }

  async function copyGoogleComplete() {
    log("Google detected; using existing popup Google copy flow");

    if (!window.GoogleMappingData?.runGoogleMappingCopy) {
      return {
        success: false,
        error: "Mapping copy module not ready. Reload the page."
      };
    }

    const result = await window.GoogleMappingData.runGoogleMappingCopy("zendesk");
    if (!result?.success) {
      return {
        success: false,
        error: result?.error || "No channel item mappings found."
      };
    }

    return {
      success: true,
      htmlData: result.outputText,
      count: result.count
    };
  }

  async function runCopyAllMappingData(strategy, pageContext) {
    switch (strategy.copyHandler) {
      case "expedia-complete":
        return copyExpediaComplete();
      case "gyg-complete":
        return copyGygComplete();
      case "viator-complete":
        return copyViatorComplete();
      case "airbnb-complete":
        return copyAirbnbComplete();
      case "google-complete":
        return copyGoogleComplete();
      default:
        return {
          success: false,
          error: "Unsupported affiliate copy handler."
        };
    }
  }

  async function runSingleItemMappingCopy(strategy) {
    log("Copying single item mapping using existing overlay HTML formatter");

    if (strategy.affiliateKey === "expedia") {
      if (!window.ExpediaMapping?.runSingleItemMappingCopy) {
        return {
          success: false,
          error: "Mapping copy module not ready. Reload the page."
        };
      }
      const result = window.ExpediaMapping.runSingleItemMappingCopy();
      if (!result?.success) {
        return result;
      }
      return {
        success: true,
        outputText: result.outputText,
        count: result.count
      };
    }

    if (strategy.affiliateKey === "getyourguide") {
      log("Copying GetYourGuide single item using HTML + channel name mode");
      if (!window.FareHarborResellerItems?.runSingleItemMappingCopyHtml) {
        return {
          success: false,
          error: "Mapping copy module not ready. Reload the page."
        };
      }
      return window.FareHarborResellerItems.runSingleItemMappingCopyHtml({
        useChannelName: true,
        includeHeaderRow: false,
        includeApiEnrichment: false
      });
    }

    return {
      success: false,
      error: "Unsupported affiliate for single item copy."
    };
  }

  function findItemMappingsHeader() {
    return findItemMappingsSection()?.querySelector(".reseller-header") || null;
  }

  function cleanupStaleSingleItemInjections(pageContext) {
    removeLegacySingleItemHeaderButtons(findItemMappingsSection());

    document.querySelectorAll(`[${ITEM_DATA_ATTR}="true"]`).forEach((button) => {
      const section = findItemMappingsSection();
      if (!pageContext || !section?.contains(button)) {
        button.remove();
      }
    });

    document.querySelectorAll(`[${ITEM_INJECTED_ATTR}="1"]`).forEach((wrap) => {
      wrap.remove();
    });

    const section = findItemMappingsSection();
    if (section) {
      syncItemMappingActionsBar(section);
    }
  }

  function ensureSingleItemCopyButton(section, strategy) {
    const label = formatSingleItemButtonLabel(strategy.displayName);
    const existingBar = isSingleItemButtonCorrectlyPlaced(section, strategy);
    if (existingBar) {
      return { wrap: existingBar, inserted: false };
    }

    removeLegacySingleItemHeaderButtons(section);

    window.ItemMappingLinkCopy?.injectActionStyles?.();

    const bar = ensureItemMappingActionsBar(section);
    let button = bar.querySelector(`[${ITEM_DATA_ATTR}="true"]`);

    if (button && section.contains(button)) {
      button.id = COPY_ITEM_BUTTON_ID;
      button.setAttribute(ITEM_BUTTON_MARKER_ATTR, "true");
      setItemMappingActionLabel(button, label);
      syncItemMappingActionsBar(section);
      return { wrap: bar, inserted: false };
    }

    document.querySelectorAll(`[${ITEM_DATA_ATTR}="true"]`).forEach((el) => el.remove());

    button = buildItemMappingDataButton({
      label,
      onClick: () => {
        handleSingleItemCopyClick(bar, strategy);
      }
    });
    bar.appendChild(button);

    let statusEl = bar.querySelector(".fhx-mapping-copy-status");
    if (!statusEl) {
      statusEl = document.createElement("span");
      statusEl.className = "fhx-mapping-copy-status";
      statusEl.setAttribute("aria-live", "polite");
      bar.appendChild(statusEl);
    }

    syncItemMappingActionsBar(section);
    return { wrap: bar, inserted: true };
  }

  async function handleSingleItemCopyClick(wrap, strategy) {
    if (itemCopyInProgress) {
      return;
    }

    const button = wrap.querySelector(`[${ITEM_DATA_ATTR}="true"]`);
    itemCopyInProgress = true;
    if (button) {
      button.disabled = true;
    }
    setInlineStatus(wrap, "Copying…");

    try {
      const result = await runSingleItemMappingCopy(strategy);
      if (!result?.success || !result.outputText) {
        setInlineStatus(wrap, result?.error || "No item mapping data found.", "error");
        return;
      }

      await navigator.clipboard.writeText(result.outputText);
      setInlineStatus(wrap, "Copied item data.", "success");
    } catch (err) {
      setInlineStatus(wrap, "Could not copy item data.", "error");
      warn("Single item clipboard copy failed:", err);
    } finally {
      itemCopyInProgress = false;
      if (button) {
        button.disabled = false;
      }
    }
  }

  async function scanAndInjectSingleItem(pageContext) {
    devLog("Individual item page detected");

    const section = findItemMappingsSection();
    if (!section) {
      devLog("Item Mappings section not found; waiting for DOM");
      return;
    }

    const companyResult = await fetchResellerCompany(pageContext);
    if (!companyResult.ok) {
      devLog("Affiliate not resolved for item page:", companyResult.error);
      cleanupStaleSingleItemInjections(pageContext);
      return;
    }

    const strategy = companyResult.strategy;
    if (!SINGLE_ITEM_AFFILIATES.has(strategy.affiliateKey)) {
      cleanupStaleSingleItemInjections(pageContext);
      return;
    }

    devLog("Expedia/GetYourGuide item copy button eligible");

    if (isSingleItemButtonCorrectlyPlaced(section, strategy)) {
      syncItemMappingActionsBar(section);
      log("button already exists", { pageType: "item", href: location.href });
      return;
    }

    const { inserted } = ensureSingleItemCopyButton(section, strategy);
    if (inserted) {
      logInsertionOnce(
        `${location.href}:item-copy`,
        "Inserted copy item data action in Item Mappings footer",
        { affiliate: strategy.affiliateKey }
      );
    }
  }

  async function handleCopyClick(wrap, strategy) {
    if (copyInProgress) {
      return;
    }

    const pageContext = parseChannelCompanyListContext();
    if (!pageContext) {
      setInlineStatus(wrap, "Could not find channel item table on this page.", "error");
      return;
    }

    const button = wrap.querySelector(".fhx-mapping-copy-btn");
    copyInProgress = true;
    if (button) {
      button.disabled = true;
    }
    setInlineStatus(wrap, "Copying…");

    try {
      log("Copy requested:", {
        affiliate: strategy.affiliateKey,
        copyHandler: strategy.copyHandler
      });

      const result = await runCopyAllMappingData(strategy, pageContext);
      if (!result.success) {
        setInlineStatus(wrap, result.error || "Copy failed.", "error");
        warn("Copy failed:", result.error);
        return;
      }

      await navigator.clipboard.writeText(result.htmlData);
      setInlineStatus(wrap, `Copied ${result.count} rows.`, "success");
      log("Copied rows:", result.count);
    } catch (err) {
      setInlineStatus(wrap, "Failed to copy mapping data to clipboard.", "error");
      warn("Clipboard copy failed:", err);
    } finally {
      copyInProgress = false;
      if (button) {
        button.disabled = false;
      }
    }
  }

  async function scanAndInject() {
    if (!featureEnabled || scanInProgress) {
      return;
    }

    const snapshot = getScanSnapshot();
    if (scanSnapshotUnchanged(snapshot)) {
      log("insertion pass skipped, state unchanged", snapshot);
      return;
    }

    scanInProgress = true;

    try {
      injectStyles();

      const itemContext = parseChannelItemPageContext();
      if (itemContext) {
        cleanupStaleInjections(null);
        await scanAndInjectSingleItem(itemContext);
        lastScanCache = getScanSnapshot();
        log("insertion pass ran", { href: location.href, pageType: "item" });
        return;
      }

      cleanupStaleSingleItemInjections(null);

      const pageContext = parseChannelCompanyListContext();
      if (!pageContext) {
        cleanupStaleInjections(null);
        lastScanCache = getScanSnapshot();
        return;
      }

      cleanupStaleInjections(pageContext);

      const companyResult = await fetchResellerCompany(pageContext);
      if (!companyResult.ok) {
        devLog("Affiliate not resolved:", companyResult.error);
        cleanupStaleInjections(pageContext);
        lastScanCache = getScanSnapshot();
        return;
      }

      const strategy = companyResult.strategy;
      const sectionInfo = findChannelItemsSection();
      if (!sectionInfo?.section || !sectionInfo?.table) {
        devLog("Channel Items section not found");
        return;
      }

      const placement = resolvePlacement(sectionInfo);
      if (!placement.ready) {
        if (placement.pending) {
          devLog("Channel Items toolbar not ready; waiting for DOM");
        }
        return;
      }

      if (findExistingMappingCopyWrap(sectionInfo.section, placement)) {
        log("button already exists", { pageType: "list", href: location.href });
        lastScanCache = getScanSnapshot();
        return;
      }

      const { inserted } = ensureCopyButton(placement, strategy);
      if (inserted) {
        logInsertionOnce(
          `${location.href}:mapping-copy`,
          placement.logMessage,
          {
            affiliate: strategy.affiliateKey,
            copyHandler: strategy.copyHandler,
            placement: placement.mode
          }
        );
      }

      lastScanCache = getScanSnapshot();
      log("insertion pass ran", { href: location.href, pageType: "list" });
    } finally {
      scanInProgress = false;
    }
  }

  function scheduleScan(force = false) {
    if (!featureEnabled) {
      return;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }

    const runScan = () => {
      debounceTimer = null;
      if (throttleTimer) {
        clearTimeout(throttleTimer);
        throttleTimer = null;
      }

      const now = Date.now();
      const elapsed = now - lastScanAt;
      if (!force && elapsed < SCAN_THROTTLE_MS) {
        throttleTimer = setTimeout(runScan, SCAN_THROTTLE_MS - elapsed);
        return;
      }

      lastScanAt = Date.now();
      scanAndInject().catch((err) => {
        warn("Scan failed:", err);
      });
    };

    debounceTimer = setTimeout(runScan, SCAN_DEBOUNCE_MS);
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  function evaluateLifecycle(reason) {
    if (!featureEnabled) {
      stopObserver();
      removeAllInjectedCopyControls();
      watchersActive = false;
      return;
    }

    if (!isFareHarborHost()) {
      if (watchersActive) {
        log("observer stopped because page became ineligible (not FareHarbor)", { reason });
      }
      stopObserver();
      watchersActive = false;
      return;
    }

    const eligible = isPageEligibleForMappingCopy();
    if (eligible) {
      if (!watchersActive) {
        log("eligible page detected", { reason, href: location.href });
        startObserver();
        log("observer started", { reason });
        watchersActive = true;
      }
      scheduleScan(true);
      log("insertion pass scheduled", { reason });
      return;
    }

    if (watchersActive) {
      log("observer stopped because page became ineligible", { reason, href: location.href });
    }
    stopObserver();
    watchersActive = false;
  }

  function onRouteChange(reason) {
    affiliateCache.clear();
    if (throttleTimer) {
      clearTimeout(throttleTimer);
      throttleTimer = null;
    }
    lastScanAt = 0;
    lastTrackedHref = location.href;
    resetScanState();
    scheduleLifecycleEval(reason || "route-change");
  }

  function startRouteWatchers() {
    if (routeWatchersStarted) {
      return;
    }
    routeWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", () => onRouteChange("popstate"));
    window.addEventListener("hashchange", () => onRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        onRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        onRouteChange("replaceState");
        return result;
      };
    } catch (err) {
      warn("history hook unavailable:", err);
    }

    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        onRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  function startObserver() {
    if (observer) {
      return;
    }
    observer = new MutationObserver((mutations) => {
      if (!isPageEligibleForMappingCopy()) {
        return;
      }
      if (mutations.length > 0 && mutations.every(isExtensionMutation)) {
        return;
      }
      scheduleScan();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function init() {
    loadDevMode();
    initSettingsBinding();

    const boot = () => {
      if (isFareHarborHost()) {
        startRouteWatchers();
      }
      evaluateLifecycle("dom-content-loaded");
      scheduleLifecycleEval("body-ready");
    };

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", boot, { once: true });
    } else {
      boot();
    }
  }

  window.MappingCopyButton = {
    MAPPING_COPY_STRATEGIES,
    parseChannelCompanyListContext,
    parseChannelItemPageContext,
    normalizeAffiliateKey,
    fetchResellerCompany,
    findChannelItemsRoot,
    findChannelItemsSection,
    findChannelItemsToolbarPlacement,
    findItemMappingsSection,
    findItemMappingsHeader,
    resolvePlacement,
    isSingleItemButtonCorrectlyPlaced,
    findExistingMappingCopyWrap,
    runCopyAllMappingData,
    runSingleItemMappingCopy
  };

  init();
  log("Module initialized successfully");
})();
