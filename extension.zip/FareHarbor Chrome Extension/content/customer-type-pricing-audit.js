console.log("[customer-type-pricing-audit] customer-type-pricing-audit.js loaded");

(function initializeCustomerTypePricingAudit() {
  if (!window.FareHarborUtils) {
    setTimeout(initializeCustomerTypePricingAudit, 10);
    return;
  }

  const LOG_PREFIX = "[customer-type-pricing-audit]";
  const CONCURRENCY_LIMIT = 4;
  const ITEMS_PAGE_SIZE = 100;

  const TSV_HEADERS = [
    "company",
    "item_id",
    "item_name",
    "item_hidden",
    "item_archived",
    "item_private",
    "total_sheet_id",
    "total_sheet_name",
    "total_sheet_hidden",
    "total_sheet_archived",
    "customer_prototype_id",
    "customer_type_id",
    "customer_type_name",
    "display_name",
    "prototype_hidden",
    "prototype_archived",
    "prototype_inactive",
    "price_visible",
    "hidden_when_booking",
    "hidden_on_receipts",
    "required",
    "price_rate",
    "price_offset",
    "modifier_type",
    "modifier_kind"
  ];

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function warn(...args) {
    console.warn(LOG_PREFIX, ...args);
  }

  function parseCompanyShortname() {
    const parts = (window.location.pathname || "").split("/").filter(Boolean);
    return parts[0] || null;
  }

  async function apiGetJson(url) {
    try {
      const response = await fetch(url, {
        method: "GET",
        credentials: "include",
        headers: { Accept: "application/json" }
      });

      if (!response.ok) {
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `API request failed with status ${response.status}`
        };
      }

      try {
        const data = await response.json();
        return { ok: true, status: response.status, data, error: null };
      } catch (err) {
        return {
          ok: false,
          status: response.status,
          data: null,
          error: `Response is not valid JSON: ${err.message}`
        };
      }
    } catch (err) {
      return { ok: false, status: null, data: null, error: `Fetch failed: ${err.message}` };
    }
  }

  function escapeTsvField(value) {
    if (value === null || value === undefined) {
      return "";
    }
    if (typeof value === "boolean") {
      return value ? "true" : "false";
    }
    const str = String(value).trim();
    return str.replace(/[\t\n\r]/g, " ");
  }

  function getSheetDisplayName(sheet) {
    if (!sheet || typeof sheet !== "object") {
      return "";
    }
    const name = sheet.display_name ?? sheet.displayName ?? sheet.name ?? "";
    return typeof name === "string" ? name.trim() : "";
  }

  function reportProgress(message) {
    try {
      chrome.runtime.sendMessage({
        action: "customerTypePricingAuditProgress",
        message
      });
    } catch (err) {
      log("Could not send progress update:", err.message);
    }
  }

  async function fetchAllItems(shortname) {
    const allItems = [];
    let page = 0;

    while (true) {
      const url =
        `/api/v1/companies/${encodeURIComponent(shortname)}/items/` +
        `?sort=sortable_index&page=${page}&page-size=${ITEMS_PAGE_SIZE}`;
      log("Fetching items page", page, url);

      const result = await apiGetJson(url);
      if (!result.ok) {
        return { ok: false, items: null, error: result.error };
      }

      const items = result.data?.items;
      if (!Array.isArray(items)) {
        return { ok: false, items: null, error: "Response missing items array" };
      }

      allItems.push(...items);
      log("Fetched", items.length, "items on page", page);

      if (items.length < ITEMS_PAGE_SIZE) {
        break;
      }
      page += 1;
    }

    return { ok: true, items: allItems, error: null };
  }

  async function fetchTotalSheets(shortname) {
    const url = `/api/v1/companies/${encodeURIComponent(shortname)}/total-sheets/`;
    log("Fetching total sheets:", url);

    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, sheets: null, error: result.error };
    }

    const sheets = result.data?.total_sheets;
    if (!Array.isArray(sheets)) {
      return { ok: false, sheets: null, error: "Response missing total_sheets array" };
    }

    log("Fetched", sheets.length, "total sheets");
    return { ok: true, sheets, error: null };
  }

  async function fetchCustomerPrototypes(shortname, itemId) {
    const url =
      `/api/v1/companies/${encodeURIComponent(shortname)}/items/${encodeURIComponent(itemId)}` +
      `/customer-prototypes/?include-is-inactive=yes`;
    log("Fetching customer prototypes for item", itemId);

    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, prototypes: null, error: result.error };
    }

    const prototypes = result.data?.customer_prototypes;
    if (!Array.isArray(prototypes)) {
      return { ok: false, prototypes: null, error: "Response missing customer_prototypes array" };
    }

    return { ok: true, prototypes, error: null };
  }

  async function fetchPricingForEditing(shortname, sheetId, itemId) {
    const url =
      `/api/v1/companies/${encodeURIComponent(shortname)}/total-sheets/${encodeURIComponent(sheetId)}` +
      `/pricing-for-editing/Item/${encodeURIComponent(itemId)}/`;
    log("Fetching pricing for item", itemId, "sheet", sheetId);

    const result = await apiGetJson(url);
    if (!result.ok) {
      return { ok: false, pricing: null, error: result.error };
    }

    return { ok: true, pricing: result.data, error: null };
  }

  async function runWithConcurrencyLimit(tasks, limit, worker) {
    const results = new Array(tasks.length);
    let nextIndex = 0;

    async function runWorker() {
      while (nextIndex < tasks.length) {
        const currentIndex = nextIndex;
        nextIndex += 1;
        results[currentIndex] = await worker(tasks[currentIndex], currentIndex);
      }
    }

    const workerCount = Math.min(limit, tasks.length);
    await Promise.all(Array.from({ length: workerCount }, () => runWorker()));
    return results;
  }

  function buildCustomerPrototypePricingMap(pricingData) {
    const effectivePricings = pricingData?.effective_pricings;
    if (!Array.isArray(effectivePricings)) {
      return new Map();
    }

    const map = new Map();
    for (const row of effectivePricings) {
      if (row?.for_object?.cls !== "CustomerPrototype") {
        continue;
      }
      const pk = row.for_object.pk;
      if (pk !== null && pk !== undefined) {
        map.set(pk, row);
      }
    }
    return map;
  }

  function getItemStatus(item) {
    if (item?.is_archived) return "archived";
    if (item?.is_hidden) return "hidden";
    if (item?.is_private) return "private";
    return "active";
  }

  function getCustomerStatus(prototype) {
    if (prototype?.is_archived) return "archived";
    if (prototype?.is_inactive) return "inactive";
    if (prototype?.is_hidden) return "hidden";
    return "active";
  }

  function getSheetVisibilityCell({ pricingRow, pricingFetchFailed }) {
    if (pricingFetchFailed) return "error";
    if (!pricingRow) return "missing";
    if (pricingRow.visibility?.is_visible === true) return "visible";
    if (pricingRow.visibility?.is_visible === false) return "hidden";
    return "missing";
  }

  function buildSheetColumnHeaders(totalSheets) {
    const nameCounts = new Map();
    for (const sheet of totalSheets) {
      const baseName = getSheetDisplayName(sheet) || `Sheet ${sheet?.pk ?? ""}`;
      nameCounts.set(baseName, (nameCounts.get(baseName) || 0) + 1);
    }

    return totalSheets.map((sheet) => {
      const baseName = getSheetDisplayName(sheet) || `Sheet ${sheet?.pk ?? ""}`;
      if (nameCounts.get(baseName) > 1) {
        return `${baseName} (${sheet?.pk ?? ""})`;
      }
      return baseName;
    });
  }

  function buildTsvRow(shortname, item, sheet, prototype, pricingRow) {
    const visibility = pricingRow?.visibility ?? null;

    return [
      shortname,
      item?.pk ?? "",
      item?.name ?? "",
      item?.is_hidden,
      item?.is_archived,
      item?.is_private,
      sheet?.pk ?? "",
      getSheetDisplayName(sheet),
      sheet?.is_hidden,
      sheet?.is_archived,
      prototype?.pk ?? "",
      prototype?.customer_type?.pk ?? "",
      prototype?.customer_type?.name ?? "",
      prototype?.display_name ?? "",
      prototype?.is_hidden,
      prototype?.is_archived,
      prototype?.is_inactive,
      visibility?.is_visible,
      visibility?.is_hidden_when_booking,
      visibility?.is_hidden_on_receipts,
      visibility?.is_required,
      pricingRow?.price_rate ?? "",
      pricingRow?.price_offset ?? "",
      pricingRow?.modifier_type ?? "",
      pricingRow?.modifier_kind ?? ""
    ].map(escapeTsvField);
  }

  function buildRawTsv(rawRows) {
    const lines = [TSV_HEADERS.join("\t")];
    for (const rawRow of rawRows) {
      const row = buildTsvRow(
        rawRow.company,
        rawRow.item,
        rawRow.sheet,
        rawRow.prototype,
        rawRow.pricingRow
      );
      lines.push(row.join("\t"));
    }
    return lines.join("\n");
  }

  function buildReadableTsv(rawRows, totalSheets) {
    const READABLE_FIXED_HEADERS = [
      "company",
      "item_id",
      "item_name",
      "item_status",
      "customer_prototype_id",
      "customer_type_id",
      "customer_type_name",
      "display_name",
      "customer_status"
    ];

    const sheetHeaders = buildSheetColumnHeaders(totalSheets || []);
    const headers = [...READABLE_FIXED_HEADERS, ...sheetHeaders];
    const groups = new Map();

    for (const rawRow of rawRows) {
      const itemId = rawRow.item?.pk;
      const prototypeId = rawRow.prototype?.pk;
      if (itemId === null || itemId === undefined || prototypeId === null || prototypeId === undefined) {
        continue;
      }

      const key = `${itemId}:${prototypeId}`;
      if (!groups.has(key)) {
        groups.set(key, {
          company: rawRow.company,
          item: rawRow.item,
          prototype: rawRow.prototype,
          sheetCells: new Map()
        });
      }

      const group = groups.get(key);
      const sheetId = rawRow.sheet?.pk;
      if (sheetId !== null && sheetId !== undefined) {
        group.sheetCells.set(sheetId, getSheetVisibilityCell(rawRow));
      }
    }

    const sortedGroups = Array.from(groups.values()).sort((a, b) => {
      const aSortIndex = a.item?.sortable_index ?? Number.MAX_SAFE_INTEGER;
      const bSortIndex = b.item?.sortable_index ?? Number.MAX_SAFE_INTEGER;
      if (aSortIndex !== bSortIndex) {
        return aSortIndex - bSortIndex;
      }
      const aItemId = a.item?.pk ?? 0;
      const bItemId = b.item?.pk ?? 0;
      if (aItemId !== bItemId) {
        return aItemId - bItemId;
      }
      return (a.prototype?.pk ?? 0) - (b.prototype?.pk ?? 0);
    });

    let hiddenCellCount = 0;
    let missingCellCount = 0;
    const dataLines = [];

    for (const group of sortedGroups) {
      const sheetCellValues = (totalSheets || []).map((sheet) => {
        const sheetId = sheet?.pk;
        const cell =
          sheetId !== null && sheetId !== undefined && group.sheetCells.has(sheetId)
            ? group.sheetCells.get(sheetId)
            : "missing";
        if (cell === "hidden") hiddenCellCount += 1;
        if (cell === "missing") missingCellCount += 1;
        return cell;
      });

      const fixedFields = [
        group.company,
        group.item?.pk ?? "",
        group.item?.name ?? "",
        getItemStatus(group.item),
        group.prototype?.pk ?? "",
        group.prototype?.customer_type?.pk ?? "",
        group.prototype?.customer_type?.name ?? "",
        group.prototype?.display_name ?? "",
        getCustomerStatus(group.prototype)
      ].map(escapeTsvField);

      dataLines.push([...fixedFields, ...sheetCellValues.map(escapeTsvField)].join("\t"));
    }

    return {
      tsv: [headers.join("\t"), ...dataLines].join("\n"),
      prototypeRowCount: sortedGroups.length,
      hiddenCellCount,
      missingCellCount
    };
  }

  function buildEmptySummary(items, sheets, warnings) {
    return {
      itemCount: items.length,
      sheetCount: sheets.length,
      rowCount: 0,
      prototypeRowCount: 0,
      hiddenCellCount: 0,
      missingCellCount: 0,
      warnings
    };
  }

  async function runCustomerTypePricingAudit() {
    const shortname = parseCompanyShortname();
    if (!shortname) {
      const error = `Could not parse company shortname from URL: ${window.location.pathname}`;
      warn(error);
      return { success: false, error };
    }

    log("Starting audit for company:", shortname);
    reportProgress(`Starting audit for ${shortname}…`);

    const warnings = [];
    const rawRows = [];

    reportProgress("Fetching items and total sheets…");
    const [itemsResult, sheetsResult] = await Promise.all([
      fetchAllItems(shortname),
      fetchTotalSheets(shortname)
    ]);

    if (!itemsResult.ok) {
      const error = `Failed to fetch items: ${itemsResult.error}`;
      warn(error);
      return { success: false, error };
    }

    if (!sheetsResult.ok) {
      const error = `Failed to fetch total sheets: ${sheetsResult.error}`;
      warn(error);
      return { success: false, error };
    }

    const items = itemsResult.items;
    const sheets = sheetsResult.sheets;

    log("Fetched", items.length, "items and", sheets.length, "total sheets");
    reportProgress(`Fetched ${items.length} items and ${sheets.length} total sheets.`);

    if (items.length === 0 || sheets.length === 0) {
      const tsv = buildRawTsv([]);
      const readable = buildReadableTsv([], sheets);
      return {
        success: true,
        company: shortname,
        tsv,
        readableTsv: readable.tsv,
        summary: buildEmptySummary(items, sheets, warnings)
      };
    }

    reportProgress("Fetching customer prototypes for each item…");
    const itemPrototypes = new Map();

    await runWithConcurrencyLimit(items, CONCURRENCY_LIMIT, async (item, index) => {
      const itemId = item?.pk;
      if (itemId === null || itemId === undefined) {
        warn("Skipping item without pk at index", index);
        warnings.push({ itemId: null, sheetId: null, message: "Item missing pk" });
        return;
      }

      reportProgress(`Fetching customer prototypes (${index + 1}/${items.length})…`);
      const protoResult = await fetchCustomerPrototypes(shortname, itemId);

      if (!protoResult.ok) {
        const message = `Failed to fetch customer prototypes for item ${itemId}: ${protoResult.error}`;
        warn(message);
        warnings.push({ itemId, sheetId: null, message });
        itemPrototypes.set(itemId, []);
        return;
      }

      itemPrototypes.set(itemId, protoResult.prototypes);
      log("Item", itemId, "has", protoResult.prototypes.length, "customer prototypes");
    });

    const workQueue = [];
    for (const item of items) {
      const itemId = item?.pk;
      if (itemId === null || itemId === undefined) {
        continue;
      }
      const prototypes = itemPrototypes.get(itemId) ?? [];
      for (const sheet of sheets) {
        workQueue.push({ item, sheet, prototypes });
      }
    }

    log("Processing", workQueue.length, "item/sheet combinations");
    reportProgress(`Processing ${workQueue.length} item/sheet combinations…`);

    let completed = 0;

    await runWithConcurrencyLimit(workQueue, CONCURRENCY_LIMIT, async (task) => {
      const { item, sheet, prototypes } = task;
      const itemId = item?.pk;
      const sheetId = sheet?.pk;

      completed += 1;
      reportProgress(
        `Processing item ${itemId} / sheet ${sheetId} (${completed}/${workQueue.length})…`
      );

      if (sheetId === null || sheetId === undefined) {
        warn("Skipping sheet without pk for item", itemId);
        warnings.push({ itemId, sheetId: null, message: "Total sheet missing pk" });
        return;
      }

      if (prototypes.length === 0) {
        log("No customer prototypes for item", itemId, "on sheet", sheetId);
        return;
      }

      const pricingResult = await fetchPricingForEditing(shortname, sheetId, itemId);
      const pricingFetchFailed = !pricingResult.ok;
      let pricingMap = new Map();

      if (pricingFetchFailed) {
        const message =
          `Failed to fetch pricing for item ${itemId} / sheet ${sheetId}: ${pricingResult.error}`;
        warn(message);
        warnings.push({ itemId, sheetId, message });
      } else {
        pricingMap = buildCustomerPrototypePricingMap(pricingResult.pricing);
      }

      for (const prototype of prototypes) {
        const pricingRow = pricingMap.get(prototype?.pk) ?? null;
        rawRows.push({
          company: shortname,
          item,
          sheet,
          prototype,
          pricingRow,
          pricingFetchFailed
        });
      }
    });

    const tsv = buildRawTsv(rawRows);
    const readable = buildReadableTsv(rawRows, sheets);
    const summary = {
      itemCount: items.length,
      sheetCount: sheets.length,
      rowCount: rawRows.length,
      prototypeRowCount: readable.prototypeRowCount,
      hiddenCellCount: readable.hiddenCellCount,
      missingCellCount: readable.missingCellCount,
      warnings
    };

    log("Audit complete:", summary);
    reportProgress(
      `Complete: ${summary.rowCount} raw rows, ${summary.prototypeRowCount} prototype rows (${summary.warnings.length} warning${summary.warnings.length === 1 ? "" : "s"}).`
    );

    return {
      success: true,
      company: shortname,
      tsv,
      readableTsv: readable.tsv,
      summary
    };
  }

  function handleMessage(req, sender, sendResponse) {
    log("Message received:", req);

    if (req.action === "runCustomerTypePricingAudit") {
      runCustomerTypePricingAudit()
        .then((result) => {
          log("Sending result, rowCount:", result.summary?.rowCount ?? 0);
          sendResponse(result);
        })
        .catch((err) => {
          warn("runCustomerTypePricingAudit failed:", err);
          sendResponse({ success: false, error: err.message });
        });
      return true;
    }

    return false;
  }

  window.CustomerTypePricingAudit = {
    handleMessage,
    runCustomerTypePricingAudit,
    buildReadableTsv,
    getItemStatus,
    getCustomerStatus,
    getSheetVisibilityCell
  };

  log("Module initialized");
})();
