console.log("[google-mapping-data] google-mapping-data.js loaded");

(function initializeGoogleMappingData() {
  "use strict";

  function parseCompanyShortname() {
    const parts = (window.location.pathname || "").split("/").filter(Boolean);
    return parts[0] || null;
  }

  function isFareHarborDashboardHost() {
    return window.location.hostname.includes("fareharbor");
  }

  async function runGoogleMappingCopy(outputFormat) {
    console.log("[mapping-copy] Google formatter reused by popup and inserted button");

    if (!window.QCChecks?.collectGoogleMappingCopyEntries) {
      return {
        success: false,
        error: "Google mapping module is not ready. Reload the FareHarbor page and try again."
      };
    }

    if (!isFareHarborDashboardHost()) {
      return {
        success: false,
        error: "Open a FareHarbor dashboard page first."
      };
    }

    const shortname = parseCompanyShortname();
    if (!shortname) {
      return {
        success: false,
        error: "Could not determine company shortname from the current URL."
      };
    }

    const collection = await window.QCChecks.collectGoogleMappingCopyEntries(shortname);
    if (!collection.ok || !Array.isArray(collection.entries) || collection.entries.length === 0) {
      return {
        success: false,
        error: collection.error || "No Google mappings found."
      };
    }

    const origin = window.location.origin;
    const format = outputFormat === "sheets" ? "sheets" : "zendesk";
    const outputText =
      format === "sheets"
        ? window.QCChecks.formatGoogleMappingSheetsTsv(collection.entries)
        : window.QCChecks.formatGoogleMappingZendeskHtml(collection.entries, origin, shortname);

    console.log("[google-mapping-data] Output format copied:", format);

    return {
      success: true,
      count: collection.entries.length,
      outputText,
      format
    };
  }

  function handleMessage(req, sender, sendResponse) {
    if (req.action === "runGoogleMappingCopy") {
      const outputFormat = req.outputFormat === "sheets" ? "sheets" : "zendesk";
      runGoogleMappingCopy(outputFormat)
        .then((result) => {
          sendResponse(result);
        })
        .catch((err) => {
          console.error("[google-mapping-data] runGoogleMappingCopy failed:", err);
          sendResponse({
            success: false,
            error: err?.message || "Google mapping copy failed."
          });
        });
      return true;
    }

    return false;
  }

  window.GoogleMappingData = {
    handleMessage,
    runGoogleMappingCopy
  };

  console.log("[google-mapping-data] Module initialized");
})();
