console.log("[affiliate-api-credentials] script loaded");

const PAGE_UI_AUTORUN_ENABLED = false;

(function affiliateApiCredentialsModule() {
  "use strict";

  const affiliateApi = window.FareHarborAffiliateApi;
  if (!affiliateApi) {
    console.warn(
      "[affiliate-api-credentials] FareHarborAffiliateApi unavailable; aborting init"
    );
    return;
  }

  const {
    fetchAffiliateDetail,
    fetchAffiliateApiKey,
    fetchResellerApps,
    extractAffiliateCompanyFields,
    resolveChannelAppKey
  } = affiliateApi;

  const LOG_PREFIX = "[affiliate-api-credentials]";
  const DEV_MODE_STORAGE_KEY = FareHarborDeveloperAuth.DEV_MODE_STORAGE_KEY;
  const SETTING_KEY = "showAffiliateApiCredentials";
  const INJECTED_ATTR = "data-fh-ext";
  const INJECTED_VALUE = "affiliate-api-credentials";
  const INJECTED_SELECTOR = `[${INJECTED_ATTR}="${INJECTED_VALUE}"]`;
  const STYLE_ID = "fh-affiliate-api-credentials-styles";
  const ANCHOR_SELECTOR = ".settings-wrap-narrow";
  const AFFILIATE_EDIT_PATH_RE =
    /^\/([^/]+)\/dashboard\/settings\/network\/affiliates\/edit\/(\d+)\/?/;
  const SCAN_DEBOUNCE_MS = 150;
  const ROUTE_REEVAL_DELAY_MS = 150;
  const ROUTE_POLL_MS = 500;
  const RETRY_INTERVAL_MS = 500;
  const RETRY_MAX_MS = 10000;
  const LOADING_TEXT = "Loading…";
  const MASKED_TEXT = "••••••••••••••••••••••••••••••••••••";
  const COPY_SUCCESS_MS = 2000;

  let observer = null;
  let debounceTimer = null;
  let hrefPollTimer = null;
  let lifecycleEvalTimer = null;
  let retryTimer = null;
  let retryStartedAt = 0;
  let lastTrackedHref = location.href;
  let watchersActive = false;
  let routeWatchersStarted = false;
  let scanInProgress = false;
  let fetchGeneration = 0;
  let featureEnabled = true;
  let devModeEnabled = false;
  let activePageKey = null;
  let loadInProgress = false;

  /** @type {{ affiliateApiKey: string | null, channelKey: string | null } | null} */
  let sessionCredentials = null;

  function logDiagnostic(message, detail) {
    if (detail !== undefined) {
      console.warn(LOG_PREFIX, message, detail);
      return;
    }
    console.warn(LOG_PREFIX, message);
  }

  function isDevModeEnabledAsync() {
    return FareHarborDeveloperAuth.isDevModeActiveAsync();
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function parsePageContext() {
    const match = (location.pathname || "").match(AFFILIATE_EDIT_PATH_RE);
    if (!match) {
      return null;
    }
    const companyShortname = match[1];
    const affiliationPk = match[2];
    return {
      companyShortname,
      affiliationPk,
      pageKey: `${companyShortname}|${affiliationPk}`
    };
  }

  function isUrlEligible() {
    return isFareHarborHost() && !!parsePageContext();
  }

  function clearSessionCredentials() {
    sessionCredentials = null;
  }

  function isExtensionNode(node) {
    if (!(node instanceof Element)) {
      const parent = node?.parentElement;
      return parent ? isExtensionNode(parent) : false;
    }
    if (node.getAttribute(INJECTED_ATTR) === INJECTED_VALUE) {
      return true;
    }
    return !!node.closest?.(INJECTED_SELECTOR);
  }

  function isExtensionMutation(mutation) {
    if (isExtensionNode(mutation.target)) {
      return true;
    }
    for (const node of mutation.addedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    for (const node of mutation.removedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    return false;
  }

  function removeInjectedUi() {
    document.querySelectorAll(INJECTED_SELECTOR).forEach((el) => el.remove());
    clearSessionCredentials();
    activePageKey = null;
    loadInProgress = false;
  }

  function findInjectionAnchor() {
    const wrap = document.querySelector(ANCHOR_SELECTOR);
    if (!wrap) {
      return null;
    }

    const identityCandidates = [
      wrap.querySelector('[data-test-id*="affiliate"]'),
      wrap.querySelector(".fh-settings-section"),
      wrap.querySelector(".settings-section"),
      wrap.querySelector("form > div:first-child"),
      wrap.querySelector("form")
    ];

    for (const candidate of identityCandidates) {
      if (candidate && candidate !== wrap && wrap.contains(candidate)) {
        return { wrap, insertAfter: candidate };
      }
    }

    return { wrap, insertAfter: null };
  }

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .fh-ext-api-credentials {
        margin: 16px 0;
        padding: 12px 14px;
        border: 1px solid #d7dee6;
        border-radius: 4px;
        background: #fafbfc;
        font-size: 13px;
        line-height: 1.4;
        color: #2c3e50;
      }
      .fh-ext-api-credentials__title {
        margin: 0 0 10px;
        font-size: 13px;
        font-weight: 600;
        color: #2c3e50;
      }
      .fh-ext-api-credentials__row {
        margin-bottom: 12px;
      }
      .fh-ext-api-credentials__row:last-child {
        margin-bottom: 0;
      }
      .fh-ext-api-credentials__label {
        margin: 0 0 4px;
        font-size: 12px;
        font-weight: 600;
        color: #5c6b78;
      }
      .fh-ext-api-credentials__value {
        margin: 0 0 6px;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 12px;
        word-break: break-all;
        color: #2c3e50;
      }
      .fh-ext-api-credentials__value--muted {
        font-family: inherit;
        color: #5c6b78;
      }
      .fh-ext-api-credentials__actions {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 8px 12px;
      }
      .fh-ext-api-credentials__btn {
        appearance: none;
        border: none;
        background: none;
        padding: 0;
        color: #6b8ca3;
        font-size: 12px;
        cursor: pointer;
        text-decoration: none;
      }
      .fh-ext-api-credentials__btn:hover:not(:disabled) {
        text-decoration: underline;
      }
      .fh-ext-api-credentials__btn:disabled {
        opacity: 0.5;
        cursor: default;
      }
      .fh-ext-api-credentials__status {
        font-size: 11px;
        color: #5c6b78;
      }
      .fh-ext-api-credentials__status--success {
        color: #24553a;
      }
      .fh-ext-api-credentials__status--error {
        color: #8a4b12;
      }
      .fh-ext-api-credentials__subrow {
        margin-top: 10px;
        padding-top: 10px;
        border-top: 1px solid #e6ebf0;
      }
    `;
    document.documentElement.appendChild(style);
  }

  function createActionButton(label) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "fh-ext-api-credentials__btn";
    button.textContent = label;
    return button;
  }

  function setRowStatus(rowEl, message, type) {
    if (!rowEl) {
      return;
    }
    let statusEl = rowEl.querySelector(".fh-ext-api-credentials__status");
    if (!statusEl) {
      statusEl = document.createElement("span");
      statusEl.className = "fh-ext-api-credentials__status";
      rowEl.querySelector(".fh-ext-api-credentials__actions")?.appendChild(statusEl);
    }
    statusEl.textContent = message || "";
    statusEl.classList.remove(
      "fh-ext-api-credentials__status--success",
      "fh-ext-api-credentials__status--error"
    );
    if (type === "success") {
      statusEl.classList.add("fh-ext-api-credentials__status--success");
    } else if (type === "error") {
      statusEl.classList.add("fh-ext-api-credentials__status--error");
    }
  }

  function buildCredentialRow({
    label,
    getValue,
    initialState = "loading",
    initialMessage = LOADING_TEXT,
    allowReveal = true
  }) {
    const row = document.createElement("div");
    row.className = "fh-ext-api-credentials__row";

    const labelEl = document.createElement("div");
    labelEl.className = "fh-ext-api-credentials__label";
    labelEl.textContent = label;

    const valueEl = document.createElement("div");
    valueEl.className = "fh-ext-api-credentials__value";

    const actions = document.createElement("div");
    actions.className = "fh-ext-api-credentials__actions";

    const revealBtn = createActionButton("Reveal");
    const copyBtn = createActionButton("Copy");
    let revealed = false;

    function refreshValueDisplay() {
      const value = getValue();
      if (initialState === "loading") {
        valueEl.textContent = LOADING_TEXT;
        valueEl.classList.add("fh-ext-api-credentials__value--muted");
        revealBtn.disabled = true;
        copyBtn.disabled = true;
        return;
      }

      if (initialState === "error" || initialState === "empty" || initialState === "unresolved" || initialState === "ambiguous") {
        valueEl.textContent = initialMessage;
        valueEl.classList.add("fh-ext-api-credentials__value--muted");
        revealBtn.disabled = true;
        copyBtn.disabled = true;
        return;
      }

      valueEl.classList.remove("fh-ext-api-credentials__value--muted");
      if (!value) {
        valueEl.textContent = initialMessage || "Unavailable";
        revealBtn.disabled = true;
        copyBtn.disabled = true;
        return;
      }

      valueEl.textContent = revealed ? value : MASKED_TEXT;
      revealBtn.disabled = !allowReveal;
      copyBtn.disabled = false;
    }

    revealBtn.addEventListener("click", () => {
      revealed = !revealed;
      revealBtn.textContent = revealed ? "Hide" : "Reveal";
      refreshValueDisplay();
    });

    copyBtn.addEventListener("click", async () => {
      const value = getValue();
      if (!value) {
        setRowStatus(row, "Nothing to copy.", "error");
        return;
      }
      try {
        await navigator.clipboard.writeText(value);
        setRowStatus(row, "Copied.", "success");
        setTimeout(() => setRowStatus(row, ""), COPY_SUCCESS_MS);
      } catch (err) {
        setRowStatus(row, "Copy failed.", "error");
        logDiagnostic("clipboard copy failed", err?.message || "unknown error");
      }
    });

    actions.appendChild(revealBtn);
    actions.appendChild(copyBtn);

    row.appendChild(labelEl);
    row.appendChild(valueEl);
    row.appendChild(actions);
    refreshValueDisplay();

    return {
      row,
      setState(state, message) {
        initialState = state;
        initialMessage = message ?? initialMessage;
        revealed = false;
        revealBtn.textContent = "Reveal";
        refreshValueDisplay();
      },
      setLabel(text) {
        labelEl.textContent = text;
      }
    };
  }

  function ensureInjectedSection() {
    const existing = document.querySelector(INJECTED_SELECTOR);
    if (existing) {
      return existing;
    }

    const anchor = findInjectionAnchor();
    if (!anchor) {
      return null;
    }

    injectStyles();

    const section = document.createElement("section");
    section.className = "fh-ext-api-credentials";
    section.setAttribute(INJECTED_ATTR, INJECTED_VALUE);

    const title = document.createElement("h3");
    title.className = "fh-ext-api-credentials__title";
    title.textContent = "API credentials";
    section.appendChild(title);

    const affiliateContainer = document.createElement("div");
    affiliateContainer.className = "fh-ext-api-credentials__affiliate-keys";
    section.appendChild(affiliateContainer);

    const channelRow = buildCredentialRow({
      label: "Channel app key",
      getValue: () => sessionCredentials?.channelKey ?? null
    });
    section.appendChild(channelRow.row);
    section._channelRow = channelRow;

    if (anchor.insertAfter) {
      anchor.insertAfter.insertAdjacentElement("afterend", section);
    } else {
      anchor.wrap.insertAdjacentElement("afterbegin", section);
    }

    return section;
  }

  function renderAffiliateApiKeyRow(section, apiKey, state, message) {
    const container = section.querySelector(".fh-ext-api-credentials__affiliate-keys");
    if (!container) {
      return;
    }
    container.textContent = "";

    if (state === "loading") {
      const row = buildCredentialRow({
        label: "Affiliate API key",
        getValue: () => null,
        initialState: "loading"
      });
      container.appendChild(row.row);
      return;
    }

    if (state === "ready" && apiKey) {
      const row = buildCredentialRow({
        label: "Affiliate API key",
        getValue: () => apiKey,
        initialState: "ready"
      });
      container.appendChild(row.row);
      return;
    }

    const row = buildCredentialRow({
      label: "Affiliate API key",
      getValue: () => null,
      initialState: state === "empty" ? "empty" : "error",
      initialMessage: message || "Affiliate API key not found",
      allowReveal: false
    });
    container.appendChild(row.row);
  }

  function renderChannelRow(section, result) {
    const channelRow = section._channelRow;
    if (!channelRow) {
      return;
    }

    if (result.status === "resolved") {
      channelRow.setState("ready");
      return;
    }

    if (result.status === "error") {
      channelRow.setState("error", result.message || "Unable to load channel app keys");
      return;
    }

    if (result.status === "ambiguous") {
      channelRow.setState(
        "ambiguous",
        `Multiple channel apps matched (${result.matches.length})`
      );
      logDiagnostic("ambiguous channel app match", {
        matches: result.matches.map((match) => ({
          name: match.name,
          pk: match.pk
        }))
      });
      return;
    }

    channelRow.setState("unresolved", "Channel app key not resolved");
  }

  function isStale(generation, pageKey) {
    return generation !== fetchGeneration || pageKey !== activePageKey;
  }

  async function loadCredentials(ctx, generation) {
    if (loadInProgress && activePageKey === ctx.pageKey) {
      return;
    }

    loadInProgress = true;
    activePageKey = ctx.pageKey;
    clearSessionCredentials();

    const section = ensureInjectedSection();
    if (!section) {
      loadInProgress = false;
      return;
    }

    renderAffiliateApiKeyRow(section, null, "loading");
    section._channelRow?.setState("loading");

    const detailResult = await fetchAffiliateDetail(
      ctx.companyShortname,
      ctx.affiliationPk
    );

    if (isStale(generation, ctx.pageKey)) {
      loadInProgress = false;
      return;
    }

    if (!detailResult.ok || !detailResult.detail) {
      logDiagnostic("affiliation detail unavailable", detailResult.error);
      const affiliateContainer = section.querySelector(".fh-ext-api-credentials__affiliate-keys");
      affiliateContainer.textContent = "";
      const row = buildCredentialRow({
        label: "Affiliate API key",
        getValue: () => null,
        initialState: "error",
        initialMessage: "Unable to load affiliation data",
        allowReveal: false
      });
      affiliateContainer.appendChild(row.row);
      renderChannelRow(section, { status: "unresolved" });
      loadInProgress = false;
      return;
    }

    const companyFields = extractAffiliateCompanyFields(detailResult.detail);
    sessionCredentials = { affiliateApiKey: null, channelKey: null };

    if (!companyFields.shortname) {
      logDiagnostic("missing affiliate shortname");
      renderAffiliateApiKeyRow(
        section,
        null,
        "error",
        "Affiliate shortname unavailable"
      );
    } else {
      const apiKeyResult = await fetchAffiliateApiKey(
        companyFields.shortname,
        companyFields.name
      );

      if (isStale(generation, ctx.pageKey)) {
        loadInProgress = false;
        return;
      }

      if (!apiKeyResult.ok) {
        logDiagnostic("affiliate users fetch failed", apiKeyResult.error);
        let message = "Unable to load affiliate API key";
        if (apiKeyResult.status === 404) {
          message = "API user not found";
        } else if (apiKeyResult.status === 401 || apiKeyResult.status === 403) {
          message = "Affiliate API key unavailable — insufficient permissions";
        }
        renderAffiliateApiKeyRow(section, null, "error", message);
      } else if (apiKeyResult.resolutionStatus === "resolved" && apiKeyResult.key) {
        sessionCredentials.affiliateApiKey = apiKeyResult.key;
        renderAffiliateApiKeyRow(section, apiKeyResult.key, "ready");
      } else if (apiKeyResult.resolutionStatus === "ambiguous") {
        renderAffiliateApiKeyRow(
          section,
          null,
          "error",
          apiKeyResult.errorMessage ||
          "Could not reliably identify the affiliate API user"
        );
      } else if (apiKeyResult.resolutionStatus === "not_found") {
        renderAffiliateApiKeyRow(
          section,
          null,
          "error",
          apiKeyResult.errorMessage || "API user not found"
        );
      } else {
        renderAffiliateApiKeyRow(
          section,
          null,
          "empty",
          apiKeyResult.errorMessage || "Affiliate API key not found"
        );
      }
    }

    let channelResult = { status: "unresolved" };
    if (!companyFields.name) {
      logDiagnostic("missing affiliate company name");
    } else {
      const appsResult = await fetchResellerApps();

      if (isStale(generation, ctx.pageKey)) {
        loadInProgress = false;
        return;
      }

      if (!appsResult.ok) {
        logDiagnostic("reseller-apps fetch failed", appsResult.error);
        channelResult = {
          status: "error",
          message: "Unable to load channel app keys"
        };
      } else {
        channelResult = resolveChannelAppKey(companyFields.name, appsResult.apps);
        if (channelResult.status === "resolved") {
          sessionCredentials.channelKey = channelResult.key;
        }
      }
    }

    if (isStale(generation, ctx.pageKey)) {
      loadInProgress = false;
      return;
    }

    renderChannelRow(section, channelResult);
    loadInProgress = false;
  }

  async function scanAndInject(reason) {
    if (!featureEnabled || !isUrlEligible() || scanInProgress) {
      return false;
    }

    const ctx = parsePageContext();
    if (!ctx) {
      return false;
    }

    if (document.querySelector(INJECTED_SELECTOR) && activePageKey === ctx.pageKey && loadInProgress) {
      return true;
    }

    scanInProgress = true;
    try {
      const anchor = findInjectionAnchor();
      if (!anchor) {
        return false;
      }

      const existing = document.querySelector(INJECTED_SELECTOR);
      if (existing && activePageKey === ctx.pageKey && sessionCredentials) {
        return true;
      }

      if (existing && activePageKey !== ctx.pageKey) {
        removeInjectedUi();
      }

      const generation = fetchGeneration;
      await loadCredentials(ctx, generation);
      return !!document.querySelector(INJECTED_SELECTOR);
    } finally {
      scanInProgress = false;
    }
  }

  function scheduleScan(reason) {
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }
    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      scanAndInject(reason || "debounced-scan");
    }, SCAN_DEBOUNCE_MS);
  }

  function stopRetryLoop() {
    if (retryTimer) {
      clearInterval(retryTimer);
      retryTimer = null;
    }
    retryStartedAt = 0;
  }

  function startRetryLoop(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      stopRetryLoop();
      return;
    }

    if (!retryTimer) {
      retryStartedAt = Date.now();
      retryTimer = setInterval(async () => {
        const elapsed = Date.now() - retryStartedAt;
        const found = await scanAndInject("retry-loop");
        if (found) {
          stopRetryLoop();
          return;
        }
        if (elapsed >= RETRY_MAX_MS) {
          stopRetryLoop();
        }
      }, RETRY_INTERVAL_MS);
    }

    scheduleScan(reason || "retry-schedule");
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    stopRetryLoop();
    fetchGeneration += 1;
    scanInProgress = false;
    removeInjectedUi();
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  function evaluateLifecycle(reason) {
    if (!featureEnabled || !devModeEnabled) {
      console.log("[affiliate-api-credentials] lifecycle: feature disabled", {
        reason,
        featureEnabled,
        devModeEnabled
      });
      stopObserver();
      watchersActive = false;
      return;
    }

    if (!isUrlEligible()) {
      console.log("[affiliate-api-credentials] lifecycle: url not eligible", {
        reason,
        pathname: location.pathname
      });
      stopObserver();
      watchersActive = false;
      return;
    }

    console.log("[affiliate-api-credentials] lifecycle: eligible edit page", {
      reason,
      href: location.href
    });

    if (!watchersActive) {
      startObserver();
      watchersActive = true;
    }

    startRetryLoop(reason || "lifecycle");
  }

  function onRouteChange(reason) {
    const nextHref = location.href;
    if (nextHref !== lastTrackedHref) {
      fetchGeneration += 1;
      clearSessionCredentials();
      activePageKey = null;
      loadInProgress = false;
      removeInjectedUi();
    }
    lastTrackedHref = nextHref;
    scheduleLifecycleEval(reason || "route-change");
  }

  function startRouteWatchers() {
    if (routeWatchersStarted) {
      return;
    }
    routeWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", () => onRouteChange("popstate"));
    window.addEventListener("hashchange", () => onRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        onRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        onRouteChange("replaceState");
        return result;
      };
    } catch (err) {
      logDiagnostic("history hook unavailable", err?.message);
    }

    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        onRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  function startObserver() {
    if (observer) {
      return;
    }

    observer = new MutationObserver((mutations) => {
      if (!isUrlEligible()) {
        return;
      }
      if (mutations.length > 0 && mutations.every(isExtensionMutation)) {
        return;
      }
      scheduleScan("mutation-observer");
    });

    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function applyFeatureSetting(enabled, reason) {
    featureEnabled = enabled !== false;
    if (!featureEnabled) {
      stopObserver();
      watchersActive = false;
      return;
    }
    evaluateLifecycle(reason || "setting-enabled");
  }

  function initSettingsBinding() {
    const settings = window.FHSettings;
    if (!settings) {
      return;
    }
    settings.get(SETTING_KEY, (value) => {
      applyFeatureSetting(value, "settings-init");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SETTING_KEY]) {
        applyFeatureSetting(changes[SETTING_KEY].newValue, "setting-change");
      }
    });
  }

  function init() {
    if (!PAGE_UI_AUTORUN_ENABLED) {
      console.log("[affiliate-api-credentials] page UI autorun disabled");
      return;
    }

    console.log("[affiliate-api-credentials] init", {
      href: location.href,
      host: location.hostname
    });

    if (!isFareHarborHost()) {
      console.log("[affiliate-api-credentials] skipped: not a FareHarbor host");
      return;
    }

    void (async () => {
      devModeEnabled = await isDevModeEnabledAsync();
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes[DEV_MODE_STORAGE_KEY]) {
          void isDevModeEnabledAsync().then((active) => {
            devModeEnabled = active;
            evaluateLifecycle("dev-mode-change");
          });
        }
      });

      initSettingsBinding();
      startRouteWatchers();
      evaluateLifecycle("init");

      if (document.readyState === "loading") {
        document.addEventListener(
          "DOMContentLoaded",
          () => evaluateLifecycle("dom-content-loaded"),
          { once: true }
        );
      }
    })();
  }

  init();
})();
