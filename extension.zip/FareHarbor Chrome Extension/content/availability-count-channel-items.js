console.log("[availability-count-channel-items] script loaded");

(function availabilityCountChannelItemsModule() {
  "use strict";

  const shared = window.FareHarborAvailabilityCount;
  if (!shared) {
    console.error(
      "[availability-count-channel-items] FareHarborAvailabilityCount not loaded"
    );
    return;
  }

  const {
    formatCount,
    parseNumericChannelCompanyPageContext,
    parseResellerItemIdFromExternalId,
    fetchResellerItemAvailabilityCount
  } = shared;

  const LOG_PREFIX = "[availability-count-channel-items]";
  const COLUMN_ATTR = "data-fh-channel-future-avail-column";
  const RESELLER_ITEM_ID_ATTR = "data-fh-reseller-item-id";
  const HEADER_TEXT = "Future availabilities";
  const SETTING_KEY = "showFutureAvailabilitiesColumn";
  const SCAN_DEBOUNCE_MS = 150;
  const ROUTE_REEVAL_DELAY_MS = 150;
  const ROUTE_POLL_MS = 500;
  const RETRY_INTERVAL_MS = 500;
  const RETRY_MAX_MS = 10000;
  const MISSING_COUNT_TEXT = "—";
  const LOADING_TEXT = "Loading...";
  const ERROR_TEXT = "Error";

  const REQUIRED_HEADERS = [
    "Name",
    "SKU",
    "External Identifier",
    "Item Mappings",
    "Channel Customer Types",
    "Channel Options",
    "Last changed"
  ];

  let observer = null;
  let debounceTimer = null;
  let hrefPollTimer = null;
  let lifecycleEvalTimer = null;
  let retryTimer = null;
  let retryStartedAt = 0;
  let lastTrackedHref = location.href;
  let watchersActive = false;
  let routeWatchersStarted = false;
  let scanInProgress = false;
  let fetchGeneration = 0;
  let featureEnabled = true;

  /** @type {Map<string, { itemIdSetKey: string, byItemId: Map<string, { status: string, count: number | null }> }>} */
  const pageCountsCache = new Map();
  let lastAppliedState = {
    pageKey: null,
    itemIdSetKey: null,
    populated: false
  };

  function log(...args) {
    console.log(LOG_PREFIX, ...args);
  }

  function isFareHarborHost() {
    return location.hostname.includes("fareharbor");
  }

  function parsePageContext() {
    return parseNumericChannelCompanyPageContext(location.pathname || "");
  }

  function isUrlEligible() {
    return isFareHarborHost() && !!parsePageContext();
  }

  function buildPageKey(ctx) {
    if (!ctx) {
      return null;
    }
    return `${ctx.companyShortname}|${ctx.channelId}`;
  }

  function buildItemIdSetKey(itemIds) {
    return [...itemIds].sort().join("|");
  }

  function clearPageCaches() {
    pageCountsCache.clear();
    lastAppliedState = {
      pageKey: null,
      itemIdSetKey: null,
      populated: false
    };
  }

  function getRowCells(row) {
    return [...row.children].filter(
      (el) => el.tagName === "TD" || el.tagName === "TH"
    );
  }

  function normalizeCellText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function cellHasFinalValue(cell) {
    const text = (cell.textContent || "").trim();
    return text !== LOADING_TEXT && text !== "";
  }

  function isChannelItemsTable(table) {
    const headerText = table.querySelector("thead")?.innerText || "";
    return REQUIRED_HEADERS.every((header) => headerText.includes(header));
  }

  function findChannelItemsTable(root) {
    const scope = root || document;
    const selectors = [
      'table[ng-if="resellerItems.length"]',
      'table[ng-table="resellerItems"]',
      'table[ng-controller*="ResellerItemsController"]',
      "table.reseller-items-table",
      'table.spreadsheet[ng-if="resellerItems.length"]',
      'table[ng-table*="resellerItems"]'
    ];

    for (const selector of selectors) {
      const table = scope.querySelector(selector);
      if (table && isChannelItemsTable(table)) {
        return table;
      }
    }

    const tables = scope.querySelectorAll("table");
    for (const table of tables) {
      if (!isChannelItemsTable(table)) {
        continue;
      }
      if (table.querySelector('tbody[ng-repeat*="resellerItem"]')) {
        return table;
      }
    }

    return null;
  }

  function getNativeRowCells(row) {
    return getRowCells(row).filter(
      (cell) => cell.getAttribute(COLUMN_ATTR) !== "true"
    );
  }

  function findLastChangedIndex(cells) {
    return cells.findIndex((cell) =>
      /last\s*changed/i.test(normalizeCellText(cell.textContent))
    );
  }

  function extractResellerItemIdFromRow(row) {
    for (const cell of getNativeRowCells(row)) {
      const id = parseResellerItemIdFromExternalId(cell.textContent || "");
      if (id) {
        return id;
      }
    }
    return null;
  }

  function isExtensionNode(node) {
    if (!(node instanceof Element)) {
      const parent = node?.parentElement;
      return parent ? isExtensionNode(parent) : false;
    }
    if (node.getAttribute(COLUMN_ATTR) === "true") {
      return true;
    }
    return !!node.closest?.(`[${COLUMN_ATTR}="true"]`);
  }

  function isExtensionMutation(mutation) {
    if (isExtensionNode(mutation.target)) {
      return true;
    }
    for (const node of mutation.addedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    for (const node of mutation.removedNodes) {
      if (isExtensionNode(node)) {
        return true;
      }
    }
    return false;
  }

  function removeInjectedColumns() {
    document.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
      cell.remove();
    });
  }

  function applyFeatureSetting(enabled, reason) {
    featureEnabled = enabled !== false;
    if (!featureEnabled) {
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }
    evaluateLifecycle(reason || "setting-enabled");
  }

  function initSettingsBinding() {
    const settings = window.FHSettings;
    if (!settings) {
      return;
    }
    settings.get(SETTING_KEY, (value) => {
      applyFeatureSetting(value, "settings-init");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SETTING_KEY]) {
        applyFeatureSetting(changes[SETTING_KEY].newValue, "setting-change");
      }
    });
  }

  function createHeaderCell(referenceCell) {
    const tagName =
      referenceCell?.tagName === "TD" || referenceCell?.tagName === "td"
        ? "td"
        : "th";
    const cell = document.createElement(tagName);
    cell.setAttribute(COLUMN_ATTR, "true");
    cell.textContent = HEADER_TEXT;
    return cell;
  }

  function createBodyCell() {
    const cell = document.createElement("td");
    cell.setAttribute(COLUMN_ATTR, "true");
    cell.style.textAlign = "right";
    cell.textContent = LOADING_TEXT;
    return cell;
  }

  function applyCachedValueToCell(cell, resellerItemId, byItemId) {
    const entry = byItemId?.get(resellerItemId);
    if (!entry) {
      cell.textContent = LOADING_TEXT;
      return;
    }

    if (entry.status === "ok" && typeof entry.count === "number") {
      cell.textContent = formatCount(entry.count);
      return;
    }

    if (entry.status === "missing") {
      cell.textContent = MISSING_COUNT_TEXT;
      return;
    }

    if (entry.status === "error") {
      cell.textContent = ERROR_TEXT;
    }
  }

  function normalizeColumn(table, ctx) {
    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return {
        descriptors: [],
        headerInserted: 0,
        cellsInserted: 0,
        cellsRepositioned: 0
      };
    }

    const pageKey = ctx ? buildPageKey(ctx) : null;
    const byItemId = pageKey ? pageCountsCache.get(pageKey)?.byItemId : null;

    let headerInserted = 0;
    let cellsInserted = 0;
    let cellsRepositioned = 0;
    const descriptors = [];

    headerRow.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
      cell.remove();
      cellsRepositioned += 1;
    });

    const nativeHeaderCells = getNativeRowCells(headerRow);
    const lastChangedHeaderIdx = findLastChangedIndex(nativeHeaderCells);
    if (lastChangedHeaderIdx < 0) {
      return { descriptors, headerInserted, cellsInserted, cellsRepositioned };
    }

    const insertBeforeHeader = nativeHeaderCells[lastChangedHeaderIdx];
    const headerCell = createHeaderCell(insertBeforeHeader);
    headerRow.insertBefore(headerCell, insertBeforeHeader);
    headerInserted = 1;

    const rows = table.querySelectorAll("tbody tr");
    rows.forEach((row) => {
      row.querySelectorAll(`[${COLUMN_ATTR}="true"]`).forEach((cell) => {
        cell.remove();
        cellsRepositioned += 1;
      });

      const nativeRowCells = getNativeRowCells(row);
      const lastChangedCell = nativeRowCells[lastChangedHeaderIdx];
      if (!lastChangedCell) {
        return;
      }

      const resellerItemId = extractResellerItemIdFromRow(row);
      const cell = createBodyCell();
      row.insertBefore(cell, lastChangedCell);
      cellsInserted += 1;

      if (!resellerItemId) {
        cell.textContent = MISSING_COUNT_TEXT;
        return;
      }

      cell.setAttribute(RESELLER_ITEM_ID_ATTR, resellerItemId);
      applyCachedValueToCell(cell, resellerItemId, byItemId);
      descriptors.push({ resellerItemId, cell });
    });

    return { descriptors, headerInserted, cellsInserted, cellsRepositioned };
  }

  function rowColumnCorrectlyPlaced(row, lastChangedHeaderIdx) {
    const nativeRowCells = getNativeRowCells(row);
    const lastChangedCell = nativeRowCells[lastChangedHeaderIdx];
    if (!lastChangedCell) {
      return false;
    }

    const extensionCell = row.querySelector(`[${COLUMN_ATTR}="true"]`);
    if (!extensionCell) {
      return false;
    }

    return extensionCell.nextElementSibling === lastChangedCell;
  }

  function tableNeedsRepair(table) {
    if (!table) {
      return false;
    }

    const headerRow = table.querySelector("thead tr");
    if (!headerRow) {
      return true;
    }

    const nativeHeaderCells = getNativeRowCells(headerRow);
    const lastChangedHeaderIdx = findLastChangedIndex(nativeHeaderCells);
    if (lastChangedHeaderIdx < 0) {
      return true;
    }

    const extensionHeaders = headerRow.querySelectorAll(`[${COLUMN_ATTR}="true"]`);
    if (extensionHeaders.length !== 1) {
      return true;
    }

    const lastChangedHeader = nativeHeaderCells[lastChangedHeaderIdx];
    if (extensionHeaders[0].nextElementSibling !== lastChangedHeader) {
      return true;
    }

    for (const row of table.querySelectorAll("tbody tr")) {
      const extensionCells = row.querySelectorAll(`[${COLUMN_ATTR}="true"]`);
      if (extensionCells.length !== 1) {
        return true;
      }
      if (!rowColumnCorrectlyPlaced(row, lastChangedHeaderIdx)) {
        return true;
      }
    }

    return false;
  }

  function allCountCellsFinal(table) {
    const cells = [
      ...table.querySelectorAll(
        `tbody [${COLUMN_ATTR}="true"][${RESELLER_ITEM_ID_ATTR}]`
      )
    ];
    if (!cells.length) {
      return false;
    }
    return cells.every(cellHasFinalValue);
  }

  function populateCells(table, byItemId) {
    table
      .querySelectorAll(`tbody [${COLUMN_ATTR}="true"][${RESELLER_ITEM_ID_ATTR}]`)
      .forEach((cell) => {
        if (cellHasFinalValue(cell)) {
          return;
        }

        const resellerItemId = cell.getAttribute(RESELLER_ITEM_ID_ATTR);
        const entry = byItemId.get(resellerItemId);
        if (!entry) {
          return;
        }

        if (entry.status === "ok" && typeof entry.count === "number") {
          cell.textContent = formatCount(entry.count);
          return;
        }

        if (entry.status === "missing") {
          cell.textContent = MISSING_COUNT_TEXT;
          return;
        }

        if (entry.status === "error") {
          cell.textContent = ERROR_TEXT;
        }
      });
  }

  async function resolveCounts(ctx, itemIds) {
    const pageKey = buildPageKey(ctx);
    const itemIdSetKey = buildItemIdSetKey(itemIds);
    const cached = pageCountsCache.get(pageKey);

    if (cached && cached.itemIdSetKey === itemIdSetKey) {
      return cached.byItemId;
    }

    let byItemId = cached?.byItemId || new Map();
    const idsToFetch = itemIds.filter((id) => !byItemId.has(id));

    if (idsToFetch.length) {
      log("fetching availability counts", {
        company: ctx.companyShortname,
        channelId: ctx.channelId,
        rowCount: idsToFetch.length
      });

      await Promise.all(
        idsToFetch.map(async (resellerItemId) => {
          const result = await fetchResellerItemAvailabilityCount(
            ctx,
            resellerItemId
          );
          if (result.ok && typeof result.count === "number") {
            byItemId.set(resellerItemId, { status: "ok", count: result.count });
            return;
          }
          if (result.ok) {
            byItemId.set(resellerItemId, { status: "missing", count: null });
            return;
          }
          byItemId.set(resellerItemId, { status: "error", count: null });
        })
      );
    }

    byItemId = new Map(byItemId);
    pageCountsCache.set(pageKey, { itemIdSetKey, byItemId });
    return byItemId;
  }

  function shouldFullySkipScan(ctx, descriptors, table) {
    if (!ctx || !descriptors.length || !table) {
      return false;
    }

    if (tableNeedsRepair(table)) {
      return false;
    }

    if (!allCountCellsFinal(table)) {
      return false;
    }

    const pageKey = buildPageKey(ctx);
    const itemIdSetKey = buildItemIdSetKey(
      descriptors.map((d) => d.resellerItemId)
    );

    if (
      lastAppliedState.pageKey === pageKey &&
      lastAppliedState.itemIdSetKey === itemIdSetKey &&
      lastAppliedState.populated
    ) {
      return true;
    }

    const cached = pageCountsCache.get(pageKey);
    return !!(cached && cached.itemIdSetKey === itemIdSetKey);
  }

  function descriptorsNeedFetch(ctx, descriptors) {
    if (!ctx || !descriptors.length) {
      return false;
    }

    const pageKey = buildPageKey(ctx);
    const itemIdSetKey = buildItemIdSetKey(
      descriptors.map((d) => d.resellerItemId)
    );
    const cached = pageCountsCache.get(pageKey);

    if (cached && cached.itemIdSetKey === itemIdSetKey) {
      return false;
    }

    if (cached) {
      return descriptors.some((d) => !cached.byItemId.has(d.resellerItemId));
    }

    return true;
  }

  async function scanTable(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return false;
    }

    const table = findChannelItemsTable(document);
    if (!table) {
      return false;
    }

    if (scanInProgress) {
      return false;
    }

    scanInProgress = true;
    const generation = ++fetchGeneration;
    let didWork = false;

    try {
      const ctx = parsePageContext();
      const normalizeResult = normalizeColumn(table, ctx);
      const { descriptors, headerInserted, cellsInserted, cellsRepositioned } =
        normalizeResult;

      log("Channel items column normalized", {
        rowCount: descriptors.length,
        headerInserted,
        cellsInserted,
        cellsRepositioned
      });

      didWork =
        headerInserted > 0 || cellsInserted > 0 || cellsRepositioned > 0;

      if (!ctx || !descriptors.length) {
        return didWork;
      }

      const itemIds = descriptors.map((d) => d.resellerItemId);

      if (shouldFullySkipScan(ctx, descriptors, table)) {
        const cached = pageCountsCache.get(buildPageKey(ctx));
        if (cached) {
          populateCells(table, cached.byItemId);
        }
        return didWork;
      }

      const cached = pageCountsCache.get(buildPageKey(ctx));
      if (cached) {
        populateCells(table, cached.byItemId);
      }

      if (!descriptorsNeedFetch(ctx, descriptors)) {
        lastAppliedState = {
          pageKey: buildPageKey(ctx),
          itemIdSetKey: buildItemIdSetKey(itemIds),
          populated: allCountCellsFinal(table)
        };
        if (lastAppliedState.populated) {
          stopRetryLoop();
        }
        return didWork;
      }

      const byItemId = await resolveCounts(ctx, itemIds);
      if (generation !== fetchGeneration) {
        return didWork;
      }

      populateCells(table, byItemId);
      lastAppliedState = {
        pageKey: buildPageKey(ctx),
        itemIdSetKey: buildItemIdSetKey(itemIds),
        populated: allCountCellsFinal(table)
      };

      if (lastAppliedState.populated) {
        stopRetryLoop();
      }

      return didWork;
    } finally {
      scanInProgress = false;
    }
  }

  function scheduleScan(reason) {
    if (!featureEnabled || !isUrlEligible()) {
      return;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }
    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      scanTable(reason || "debounced-scan");
    }, SCAN_DEBOUNCE_MS);
  }

  function stopRetryLoop() {
    if (retryTimer) {
      clearInterval(retryTimer);
      retryTimer = null;
    }
    retryStartedAt = 0;
  }

  function startRetryLoop(reason) {
    if (!isUrlEligible()) {
      stopRetryLoop();
      return;
    }

    if (!retryTimer) {
      retryStartedAt = Date.now();
      retryTimer = setInterval(async () => {
        const elapsed = Date.now() - retryStartedAt;
        const found = await scanTable("retry-loop");
        if (found) {
          stopRetryLoop();
          return;
        }
        if (elapsed >= RETRY_MAX_MS) {
          stopRetryLoop();
        }
      }, RETRY_INTERVAL_MS);
    }

    scheduleScan(reason || "retry-schedule");
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    stopRetryLoop();
    clearPageCaches();
    fetchGeneration += 1;
    scanInProgress = false;
  }

  function scheduleLifecycleEval(reason) {
    if (lifecycleEvalTimer) {
      clearTimeout(lifecycleEvalTimer);
    }
    lifecycleEvalTimer = setTimeout(() => {
      lifecycleEvalTimer = null;
      evaluateLifecycle(reason);
    }, ROUTE_REEVAL_DELAY_MS);
  }

  function evaluateLifecycle(reason) {
    if (!featureEnabled) {
      stopObserver();
      removeInjectedColumns();
      watchersActive = false;
      return;
    }

    if (!isUrlEligible()) {
      stopObserver();
      watchersActive = false;
      return;
    }

    if (!watchersActive) {
      log("eligible page detected", { reason, href: location.href });
      startObserver();
      watchersActive = true;
    }

    startRetryLoop(reason || "lifecycle");
  }

  function onRouteChange(reason) {
    const nextHref = location.href;
    if (nextHref !== lastTrackedHref) {
      clearPageCaches();
      fetchGeneration += 1;
    }
    lastTrackedHref = nextHref;
    scheduleLifecycleEval(reason || "route-change");
  }

  function startRouteWatchers() {
    if (routeWatchersStarted) {
      return;
    }
    routeWatchersStarted = true;
    lastTrackedHref = location.href;

    window.addEventListener("popstate", () => onRouteChange("popstate"));
    window.addEventListener("hashchange", () => onRouteChange("hashchange"));

    try {
      const origPushState = history.pushState;
      const origReplaceState = history.replaceState;
      history.pushState = function (...args) {
        const result = origPushState.apply(this, args);
        onRouteChange("pushState");
        return result;
      };
      history.replaceState = function (...args) {
        const result = origReplaceState.apply(this, args);
        onRouteChange("replaceState");
        return result;
      };
    } catch (err) {
      log("history hook unavailable:", err);
    }

    hrefPollTimer = setInterval(() => {
      if (location.href !== lastTrackedHref) {
        onRouteChange("href-poll");
      }
    }, ROUTE_POLL_MS);
  }

  function startObserver() {
    if (observer) {
      return;
    }

    observer = new MutationObserver((mutations) => {
      if (!isUrlEligible()) {
        return;
      }
      if (mutations.length > 0 && mutations.every(isExtensionMutation)) {
        return;
      }
      scheduleScan("mutation-observer");
    });

    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function init() {
    if (!isFareHarborHost()) {
      return;
    }

    initSettingsBinding();
    startRouteWatchers();
    evaluateLifecycle("init");

    if (document.readyState === "loading") {
      document.addEventListener(
        "DOMContentLoaded",
        () => evaluateLifecycle("dom-content-loaded"),
        { once: true }
      );
    }
  }

  init();
})();
