# Changelog

All notable changes to the FareHarbor Automator extension will be documented in this file.

**Note:** When updating this file, also update the `CHANGELOG` array in `popup.js` and the `manifest.json` to keep the in-extension changelog in sync.

---
## 3.8.3
- Copy Complete Mapping File for Expedia/Booking.com now expands "+ N more" Channel Options so all options are included
- Mapping Tools: renamed Copy link to Copy Item Link and moved it above the Item mappings section
- Mapping Tools: removed the “Copy 1 Item is not available” notice for Viator and Airbnb
- Mapping Tools: warn under Item mappings when Future availabilities differ across customer types
- Mapping Tools: Future availabilities mismatch warning still runs when the Future availabilities column is hidden
- Mapping Tools (Expedia): Find Start Times uses the native FareHarbor green button style
- Fixed flaky Future availabilities column on item mapping pages (race with Angular re-renders and in-flight count fetches)

## 3.8.2
- Fixed Copy Complete Mapping File reading the wrong columns when the Item Status column is shown (GetYourGuide, Viator, Expedia/Booking.com)
- Auto-enable native Future availabilities is now off by default (opt-in; preference still remembered)
- Find Customer Type duplicates is now off by default (opt-in; preference still remembered)
- Company Endpoint Call column is now off by default (opt-in; preference still remembered)

## 3.8.1
- Added Mapping Tools panel on channel item mapping pages (native side panel, OTA-aware, settings toggle)
- Integrated Copy 1 Item into the Mapping Tools panel for GetYourGuide and Expedia (same extraction/formatting as the popup; Viator unchanged — complete mapping only)
- Integrated Find All Start Times into the Expedia Mapping Tools panel (uses connected FareHarbor items from Item Mappings; same scanner as the popup)
- Moved Copy link and Copy Item Data from the Item Mappings footer into the Mapping Tools panel (icons preserved)
- Redesigned GetYourGuide Copy options in the Mapping Tools panel (checkboxes + segmented controls) and persisted all five preferences shared with the popup

## 3.8.0
- Added Find All Start Times: scan an item calendar for unique start times (today through Dec 31 next year), with overlay progress, cancel, partial-failure retry, and copy

## 3.7.14
- Added Item Status column to Channel Items listing table (On / Off / Archived), with a settings toggle
- GetYourGuide QC affiliate check no longer requires a non-empty affiliate note
- Automatically enable FareHarbor's native Show future availabilities setting on Channel Items listing pages (settings toggle)

## 3.7.13
- Removed Future availabilities column from channel company overview pages (now built into FareHarbor); kept on item-level mapping pages

## 3.7.12
- Split GetYourGuide mapping enrichment into separate Include prices and Include capacity settings checkboxes

## 3.7.11
- Fixed GetYourGuide copy mapping data after supplier portal GraphQL schema changes
- Added find duplicates and mappings to settings level Customer Type list. Integrated in UI

## 3.7.10
- Duplicate Customer Types now adopts the selected type as 01-01 by default, with a Keep original unchanged opt-out
- 01-01 now sets maximum party size only; 02 and up set both minimum and maximum party size

## 3.7.9
- Fixed bug for Duplicate Customer Type
- Fixed bug for can_generate_booking_links in QC check

## 3.7.7
- Updated QC check to allow cancellation policy with 24 hours

## 3.7.6
- Added reservation hold logic to Capacity Check

## 3.7.5
- Fixed copy mapping Data from GetYourGuide account
- Fixed bug with Capacity check batch totals
- Fixed DEV mode bug
- Fixed visual bug introduced by Chrome update

## 3.7.4
- Added inserted Created at column in resource uses page
- Added inserted copy Company Endpoint Call column in affiliate list

## 3.7.3
- GYG API copy mapping data now only shows unique prices found
- Fixed bug where opening bookings on the dashboard resulted in a URL not found error

## 3.7.2
- Added integrated Cancellation Policy column to affiliates list

## 3.7.1
- Added settings to show/hide the UI integrated features

## 3.7.0
- Added 'Future availabilities' column to mapping files
- Added sorting by 'Future availabilities' column
- Added 'Future availabilities' column to Channel Items on channel company overview pages

## 3.6.1
- Added API endpoint scraping for GYG mapping files. When enabled, pulls price data and min/max data from the items and availabilities
- Fixed log dump for inserted copy mapping data buttons
- Added inserted 'Copy item mapping link'  button to mapping files
- Updated look of inserted Copy mapping data buttons
- Updated look of inserted Find exact mappings button
- Cleaned up console output and other performance improvements

## 3.6.0
- Added a feature to show to which mappings customer types are mapped. (Has current limitation that it can not find External Company mappings. But it does indicate they exist as a warning message)
- Added Transportation Mapping QC check for advanced settings (runs for all integrations; skipped when transportation is not in use)
- Added locations check for Valid Place ID for Google affiliate QC Checks
- Added Copy Mapping Data for Google Things To Do
- Added integrated copy mapping data buttons
- Airbnb copy mapping data updated from DOM to API
- Jump to... FareHarbor Items/Bookings/Channel Companies/Channel items?Channel options updated from DOM to API

## 3.5.18
- Airbnb price sheets now marked as approved for QC check

## 3.5.17
- Tweaks to QC check

## 3.5.16
- Updated Capacity Check export to clipboard

## 3.5.15
- Switched Capacity checker to API endpoint checks (Faster, more accurate and includes resources). Small tweaks to the QC check

## 3.5.14
- Slight tweaks to the UI

## 3.5.13
- Added 'New update available' nudge to the header

## 3.5.12
- Added header option to GetYourGuide copy mapping data and fixed a bug with GetYourGuide and Expedia copy mapping data

## 3.5.1
- Updated Duplicate Customer Types to use API Endpoints instead of simulating clicks in DOM

## 3.5.0
- Added Customer Type Visibility Audit to export customer type pricing visibility per item and total sheet as TSV

## 3.4.2
- Updated QC checks, better affiliate price sheet detection for Viator and GetYourGuide

## 3.4.1
- Updated look and feel of the overlay.
- Added Copy Mapping Data to the overlay

## 3.4.0
- Added QC Checks to verify API defaults, billing, Affiliate - API permissions, and OTA affiliate setup (select integrations to include affiliate checks)
- QC Checks must be run from Settings > Advanced; popup includes a shortcut to open Advanced Settings
- Added in-page overlay on FareHarbor with Capacity Check, Duplicate Customer Types, and QC Checks; show or hide from the home menu
- Overlay can be dragged and repositioned; position is remembered between sessions
- Fixed capacity batch deduplication when availability URLs use an overlay query parameter
- Improved capacity check so a results display error does not block adding to batch or re-running the check

## 3.3.0
- Added in-page overlay on FareHarbor for Capacity Check, Duplicate Customer Types, and QC Checks without opening the extension popup

## 3.2.0
- Added CSV ready ro codes copy mapping data options to Expedia mapping file

## 3.1.0
- Added builders profile

## 3.0.1
- Updated UI, added update needed messaging, updated wording on update instructions

## 2.20.0
- Added feature to batch capacity check multiple availabilities

## 2.19.1
- Cleaned up UI and added update instructions

## 2.19.0
- Added a version check and download update option

## 2.18.2
- Added 'open all products tab' to Viator copy mapping data

## 2.18.1
- Tabs opened for capacity check now auto close again

## 2.18.0
- Completely revamped copy mapping data for GetYourGuide Products, now scrapes over API being faster and more reliable. Deprecated old version

## 2.17.3
- Copy complete mapping file for GetYourGuide now expands to show all channel options when necessary

## 2.17.2
- Added clearer error messaging when extension has not injected in the webpage

## 2.17.1
- Hid copy all products from GetYourGuide and Viator copy mapping data; Not working correctly

## 2.17.0
- Added TripAdvisor Listing to Jump to...

## 2.16.0
- Added Google Sheets clipboard export to Capacity Check

## 2.15.1
- Updated Jump to for Support to only show relevant options

## 2.15.0
- Added use case selector
- Added copy FareHarbor reports

## 2.14.0
- Added Supplier ID to Jump to.. for GetYourGuide

## 2.13.0
- Added copy mapping file for Viator
- Added TSV transfer option to GetYourGuide copy mapping

## 2.12.0
- Added copy all Viator and GetYourGuide product feature
- Restructured Copy Mapping Data

## 2.11.0
- Added a GetYourGuide and Viator data copy feature

## 2.01.0
- Added Copy FareHarbor items list

## 2.0.31
- Added changelog to extension

## 2.0.3
- Bug fix where not all customer types would correctly be duplicated

## 2.0.0
- New version, UI changes
