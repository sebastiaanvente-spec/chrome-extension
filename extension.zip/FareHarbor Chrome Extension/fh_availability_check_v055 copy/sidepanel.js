const $ = (id) => document.getElementById(id);
let lastData = null;
let busy = false;

function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function status(text, kind='muted') { $('status').textContent = text; $('status').className = kind; }
function groupRows(rows, type) { return rows.filter(r => r.type === type); }
function rowKey(r) { return `${r.type}|${r.id}|${r.channelId}|${r.itemId}`; }
function deletableStartRows(rows) { return rows.filter(r => r.type === 'Start time' && r.kind === 'options' && r.ok); }
function zeroStartRows(rows) { return rows.filter(r => r.type === 'Start time' && r.kind === 'options' && r.ok && r.count === 0); }

function renderGroup(title, rows, isStartTimes=false) {
  if (!rows.length) return '';
  const deletableRows = deletableStartRows(rows);
  const zeroRows = zeroStartRows(rows);
  const selectHeader = isStartTimes ? '<th class="select-col"></th>' : '';
  const actionHeader = isStartTimes ? '<th class="action-col">Action</th>' : '';
  const meta = isStartTimes ? `${rows.length} row${rows.length === 1 ? '' : 's'}${zeroRows.length ? ` · ${zeroRows.length} zero` : ''}` : `${rows.length} row${rows.length === 1 ? '' : 's'}`;
  const bulk = isStartTimes && deletableRows.length
    ? `<button id="delete-selected" class="bulk-delete" disabled>🗑 Delete selected</button>`
    : '';

  return `<div class="section-card">
    <div class="section-head">
      <div><div class="section-title">${esc(title)}</div><div class="section-meta">${esc(meta)}</div></div>
      ${bulk}
    </div>
    <table><thead><tr>${selectHeader}<th>Name</th><th class="count-col">Future availabilities</th>${actionHeader}</tr></thead><tbody>` +
    rows.map(r => {
      const key = esc(rowKey(r));
      const isZero = r.ok && r.count === 0;
      const countHtml = r.ok ? `<span class="count ${isZero ? 'zero' : ''}">${r.count.toLocaleString()}</span>` : `<span class="fail" title="${esc(r.error || 'No count found')}">Error</span>`;
      const canDelete = isStartTimes && r.kind === 'options' && r.ok;
      const selectHtml = isStartTimes ? `<td class="select-col">${canDelete ? `<input type="checkbox" class="bulk-check" data-key="${key}" aria-label="Select ${esc(r.name)} for deletion">` : ''}</td>` : '';
      const actionHtml = isStartTimes ? `<td class="action-col">${canDelete ? `<button class="delete ${isZero ? 'zero-delete' : ''}" data-key="${key}">🗑 Delete</button>` : ''}</td>` : '';
      return `<tr class="${isStartTimes && isZero ? 'zero-row' : ''}">${selectHtml}<td>${esc(r.name)}</td><td class="count-col">${countHtml}</td>${actionHtml}</tr>`;
    }).join('') +
    `</tbody></table></div>`;
}

function updateBulkButton() {
  const selected = [...document.querySelectorAll('.bulk-check:checked')].length;
  const btn = $('delete-selected');
  if (btn) {
    btn.disabled = busy || selected === 0;
    btn.textContent = selected ? `🗑 Delete selected (${selected})` : '🗑 Delete selected';
  }
}

function render(data) {
  lastData = data;
  const rows = data.results || [];
  if (!rows.length) {
    $('results').innerHTML = '<p class="muted">No channel customer types or channel options found on this page.</p>';
    return;
  }
  $('results').innerHTML =
    renderGroup('Customer types', groupRows(rows, 'Customer type'), false) +
    renderGroup('Start times', groupRows(rows, 'Start time'), true);

  for (const btn of document.querySelectorAll('button.delete')) {
    btn.addEventListener('click', () => deleteRowsByKeys([btn.dataset.key]));
  }
  for (const cb of document.querySelectorAll('.bulk-check')) {
    cb.addEventListener('change', updateBulkButton);
  }
  const bulkBtn = $('delete-selected');
  if (bulkBtn) {
    bulkBtn.addEventListener('click', () => {
      const keys = [...document.querySelectorAll('.bulk-check:checked')].map(cb => cb.dataset.key);
      deleteRowsByKeys(keys);
    });
  }
  updateBulkButton();
}

async function loadCounts(message='Loading counts...') {
  if (busy) return;
  busy = true;
  $('load').disabled = true; $('refresh').disabled = true;
  updateBulkButton();
  status(message);
  if (!lastData) $('results').innerHTML = '';
  const resp = await chrome.runtime.sendMessage({ action: 'getCounts' });
  busy = false;
  $('load').disabled = false; $('refresh').disabled = false;
  if (!resp.ok) { status(resp.error, 'err'); updateBulkButton(); return; }
  render(resp.result);
  const ok = (resp.result.results || []).filter(r => r.ok).length;
  const total = (resp.result.results || []).length;
  status(`Loaded ${ok}/${total} counts.` + (ok < total ? ' Hover Error for details.' : ''));
}

function findRowsByKeys(keys) {
  const keySet = new Set(keys);
  return (lastData?.results || []).filter(r => keySet.has(rowKey(r)));
}

async function deleteRowsByKeys(keys) {
  if (busy || !lastData || !keys.length) return;
  const rows = findRowsByKeys(keys);
  if (!rows.length) { status('Could not find the selected start time(s) in the latest results.', 'err'); return; }

  const invalid = rows.find(r => r.type !== 'Start time' || r.kind !== 'options' || !r.ok);
  if (invalid) {
    status('Delete is only available for start times with a loaded availability count.', 'err');
    return;
  }

  const names = rows.map(r => `${r.name} (${r.count} future availabilities)`).join('\n');
  const hasFutureAvailabilities = rows.some(r => r.count > 0);
  const warning = hasFutureAvailabilities
    ? '\n\nWarning: one or more selected start times have future availabilities. Only continue if this is intentional.'
    : '';
  const ok = confirm(rows.length === 1
    ? `Delete channel option ${rows[0].name}?\nFuture availabilities: ${rows[0].count}${warning}\n\nThis action cannot be undone.`
    : `Delete ${rows.length} channel options?\n\n${names}${warning}\n\nThis action cannot be undone.`);
  if (!ok) return;

  busy = true;
  for (const b of document.querySelectorAll('button')) b.disabled = true;
  for (const c of document.querySelectorAll('input[type="checkbox"]')) c.disabled = true;
  status(rows.length === 1 ? `Deleting ${rows[0].name}...` : `Deleting ${rows.length} start times...`);

  const deleted = [];
  const errors = [];
  for (const row of rows) {
    const resp = await chrome.runtime.sendMessage({ action: 'deleteStartTime', row });
    if (resp.ok) deleted.push(row);
    else errors.push(`${row.name}: ${resp.error || 'Unknown error'}`);
  }

  busy = false;
  for (const b of document.querySelectorAll('button')) b.disabled = false;
  for (const c of document.querySelectorAll('input[type="checkbox"]')) c.disabled = false;

  if (deleted.length && lastData?.results) {
    const deletedKeys = new Set(deleted.map(rowKey));
    lastData.results = lastData.results.filter(r => !deletedKeys.has(rowKey(r)));
    render(lastData);
  } else {
    updateBulkButton();
  }

  if (deleted.length) {
    try { await chrome.runtime.sendMessage({ action: 'reloadActiveTab' }); } catch (e) {}
  }

  if (errors.length) {
    status(`Deleted ${deleted.length}/${rows.length}.\n${errors.join('\n')}`, 'err');
  } else if (deleted.length === 1) {
    status(`Deleted ${deleted[0].name}. FareHarbor page refreshed.`, 'ok');
  } else {
    status(`Deleted ${deleted.length} start times. FareHarbor page refreshed.`, 'ok');
  }
}

$('load').addEventListener('click', () => loadCounts());
$('refresh').addEventListener('click', () => loadCounts('Refreshing counts...'));
