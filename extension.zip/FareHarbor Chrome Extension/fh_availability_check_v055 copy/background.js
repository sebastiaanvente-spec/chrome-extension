chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});
chrome.action.onClicked.addListener(async (tab) => {
  if (tab?.id) await chrome.sidePanel.open({ tabId: tab.id });
});

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function getFareHarborOrigin() {
  const tab = await getActiveTab();
  if (!tab?.url) throw new Error('No active FareHarbor tab found.');
  try {
    const { origin, hostname } = new URL(tab.url);
    if (hostname === 'fareharbor.com' || hostname === 'demo.fareharbor.com') return origin;
  } catch {}
  throw new Error('No active FareHarbor tab found.');
}

async function runScript(tabId, func, args = [], world = 'ISOLATED') {
  const [res] = await chrome.scripting.executeScript({ target: { tabId }, func, args, world });
  return res?.result;
}

async function getCsrfToken() {
  const tab = await getActiveTab();
  if (!tab?.id) throw new Error('No active FareHarbor tab found.');
  return await runScript(tab.id, () => {
    const cookieMatch = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/i);
    if (cookieMatch) return decodeURIComponent(cookieMatch[1]);
    const input = document.querySelector('input[name="csrfmiddlewaretoken"]');
    if (input?.value) return input.value;
    const meta = document.querySelector('meta[name="csrf-token"], meta[name="csrfmiddlewaretoken"]');
    if (meta?.content) return meta.content;
    return null;
  });
}

async function scanCurrentPage() {
  const tab = await getActiveTab();
  if (!tab?.id) throw new Error('No active FareHarbor tab found.');
  return await runScript(tab.id, () => {
    const abs = (href) => { try { return new URL(href, location.href).href; } catch { return href; } };
    const clean = (raw, type) => {
      let s = String(raw || '').replace(/\s+/g, ' ').replace(/Edit\s*»?\s*$/i, '').trim();
      s = s.replace(/\s+auto-generated\b.*$/i, '').trim();
      s = s.replace(/\s+r(ct|o)\d+.*$/i, '').trim();
      if (type === 'Start time') {
        const m = s.match(/\b\d{1,2}:\d{2}\b/);
        if (m) return m[0];
      }
      return s || '(unknown)';
    };
    const rows = [];
    const seen = new Set();
    for (const a of document.querySelectorAll('a[href*="/customer-types/"], a[href*="/options/"]')) {
      const url = abs(a.getAttribute('href'));
      const match = url.match(/\/settings\/integrations\/channels\/(\d+)\/items\/(\d+)\/(customer-types|options)\/(\d+)\/?/);
      if (!match) continue;
      const tr = a.closest('tr');
      const cells = tr ? [...tr.children].map(td => (td.innerText || '').replace(/\s+/g, ' ').trim()).filter(Boolean) : [];
      const type = match[3] === 'customer-types' ? 'Customer type' : 'Start time';
      const raw = cells[0] || tr?.innerText || a.parentElement?.innerText || a.innerText || '';
      const name = clean(raw, type);
      const key = type + '|' + match[4];
      if (!seen.has(key)) {
        seen.add(key);
        rows.push({ name, type, url, companyShortname: location.pathname.split('/')[1], channelId: match[1], itemId: match[2], kind: match[3], id: match[4] });
      }
    }
    return { pageUrl: location.href, title: document.title, rows };
  });
}

function findAvailabilityCount(data) {
  if (!data || typeof data !== 'object') return null;
  if (typeof data.availability_count === 'number') return data.availability_count;
  if (typeof data.availabilityCount === 'number') return data.availabilityCount;
  const stack = [data];
  const seen = new Set();
  while (stack.length) {
    const obj = stack.pop();
    if (!obj || typeof obj !== 'object' || seen.has(obj)) continue;
    seen.add(obj);
    for (const [k, v] of Object.entries(obj)) {
      if ((k === 'availability_count' || k === 'availabilityCount' || k === 'futureAvailabilitiesCount') && typeof v === 'number') return v;
      if (v && typeof v === 'object') stack.push(v);
    }
  }
  return null;
}

function basePath(row) {
  return `/api/v1/companies/${row.companyShortname}/reseller-companies/${row.channelId}/reseller-items/${row.itemId}`;
}

function candidateApiUrls(row) {
  const base = basePath(row);
  if (row.kind === 'customer-types') return [`${base}/reseller-customer-types/${row.id}/?availability_count=yes`];
  return [`${base}/reseller-options/${row.id}/?availability_count=yes`];
}

async function fetchCount(row, origin) {
  const errors = [];
  for (const path of candidateApiUrls(row)) {
    const url = new URL(path, origin).href;
    try {
      const resp = await fetch(url, { credentials: 'include' });
      const text = await resp.text();
      if (!resp.ok) { errors.push(`${resp.status} ${path}`); continue; }
      let json;
      try { json = JSON.parse(text); } catch { errors.push(`Non-JSON ${path}`); continue; }
      const count = findAvailabilityCount(json);
      if (typeof count === 'number') return { ...row, count, apiUrl: url, ok: true };
      errors.push(`No count ${path}`);
    } catch (e) {
      errors.push(`${e.message || e} ${path}`);
    }
  }
  return { ...row, count: null, ok: false, error: errors.join(' | ') };
}

async function getCounts() {
  const scan = await scanCurrentPage();
  const origin = await getFareHarborOrigin();
  const results = [];
  for (const row of scan.rows) results.push(await fetchCount(row, origin));
  return { ...scan, results };
}

async function reloadActiveTab() {
  const tab = await getActiveTab();
  if (!tab?.id) throw new Error('No active FareHarbor tab found.');
  await chrome.tabs.reload(tab.id);
  return { ok: true };
}

async function deleteStartTime(row) {
  if (!row || row.kind !== 'options' || row.type !== 'Start time') throw new Error('Only channel options/start times can be deleted.');
  const origin = await getFareHarborOrigin();
  const latest = await fetchCount(row, origin);
  if (!latest.ok) throw new Error(`Could not verify current count for ${row.name}. Delete cancelled.`);

  // Important: perform the DELETE from the active FareHarbor page, not from the
  // extension service worker. FareHarbor rejects unsafe requests from a
  // chrome-extension:// origin even when cookies are included, which shows up as
  // HTTP 403. Running this in the page context gives the request the normal
  // FareHarbor origin/referrer, matching the Dashboard's own delete action.
  const path = `${basePath(row)}/reseller-options/${row.id}/`;
  const tab = await getActiveTab();
  if (!tab?.id) throw new Error('No active FareHarbor tab found.');

  const result = await runScript(tab.id, async (path) => {
    function readCsrfToken() {
      const cookieMatch = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/i);
      if (cookieMatch) return decodeURIComponent(cookieMatch[1]);
      const input = document.querySelector('input[name="csrfmiddlewaretoken"]');
      if (input?.value) return input.value;
      const meta = document.querySelector('meta[name="csrf-token"], meta[name="csrfmiddlewaretoken"]');
      if (meta?.content) return meta.content;
      return null;
    }

    const csrf = readCsrfToken();
    if (!csrf) return { ok: false, error: 'Could not find CSRF token on the active FareHarbor page.' };

    try {
      const resp = await fetch(path, {
        method: 'DELETE',
        credentials: 'include',
        headers: {
          'Accept': 'application/json, text/plain, */*',
          'Content-Type': 'text/plain;charset=UTF-8',
          'X-CSRFToken': csrf,
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: '{}'
      });
      const text = await resp.text().catch(() => '');
      return { ok: resp.status === 204 || resp.ok, status: resp.status, text: text.slice(0, 500) };
    } catch (e) {
      return { ok: false, error: String(e?.message || e) };
    }
  }, [path], 'MAIN');

  if (!result?.ok) {
    const detail = result?.error || `HTTP ${result?.status || 'unknown'}${result?.text ? ` - ${result.text}` : ''}`;
    throw new Error(`Delete failed: ${detail}`);
  }
  return { ok: true, deleted: row, status: result.status };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg?.action === 'scan') return await scanCurrentPage();
    if (msg?.action === 'getCounts') return await getCounts();
    if (msg?.action === 'deleteStartTime') return await deleteStartTime(msg.row);
    if (msg?.action === 'reloadActiveTab') return await reloadActiveTab();
    throw new Error('Unknown action.');
  })().then(result => sendResponse({ ok: true, result })).catch(e => sendResponse({ ok: false, error: String(e?.message || e) }));
  return true;
});
