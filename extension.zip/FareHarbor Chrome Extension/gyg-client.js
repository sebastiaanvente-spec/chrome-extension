/**
 * GYG GraphQL client for service worker: paginated fetch of activity options using stored token.
 * Attaches runFetchAllOptions to self for use by background.js.
 */
(function () {
  "use strict";

  const TOKEN_KEY = "gygAuthToken";
  const SUPPLIER_KEY = "gygSupplierId";
  const ENDPOINT = "https://supplier.getyourguide.com/graphql";

  const GYG_ACTIVITY_OPTION_SEARCH_QUERY = (
    "fragment OptionSetupCompletenessFields on OptionCompletenessValue {\n  option_title\n  option_code\n  time_unit\n  option_description\n  skip_the_line_type\n  wheelchair_accessible_flag\n  time_type\n  time_value\n  private_flag\n  group_size_max\n  languages_live_guide\n  languages_audio_guide\n  languages_booklet\n  time_valid_from\n  __typename\n}\n\n" +
    "fragment MeetingPointCompletenessFields on OptionCompletenessValue {\n  activity_starting_place\n  pick_up_type\n  pick_up_confirmation_time\n  pick_up_locations\n  pick_up_areas\n  pick_up_description\n  pick_up_minutes_before\n  pick_up_transportation_types\n  drop_off_type\n  drop_off_location\n  drop_off_transportation_types\n  meeting_point_location\n  meeting_point_description\n  meeting_point_transportation_types\n  meeting_point_minutes_before\n  __typename\n}\n\n" +
    "fragment OptionsDetailsSearchInfo on ActivityOption {\n  id\n  status\n  blockingReason\n  supplierOptionCode\n  private\n  nextAvailableDate\n  maxAvailabilityDate\n  bookingEngine\n  inventoryConfiguration {\n    cutOffTimeInSeconds\n    newTicketSource\n    availabilityType\n    usesPricingOverApi\n    __typename\n  }\n  connectivitySettings {\n    externalProductId\n    __typename\n  }\n  sourceText {\n    title\n    description\n    __typename\n  }\n  timezone\n  cutOffConfiguration {\n    cutOffTimeInSeconds\n    optionHasCutOffOverrideInTimeSlot\n    __typename\n  }\n  duration {\n    unit\n    value\n    __typename\n  }\n  __typename\n}\n\n" +
    "fragment CutOffCompletenessFields on OptionCompletenessValue {\n  cut_off_time\n  __typename\n}\n\n" +
    "query CatalogActivityOption_ActivityOptionDetailsSearch($input: SearchInput) {\n  activityOptionSearch(input: $input) {\n    items {\n      ...OptionsDetailsSearchInfo\n      completeness {\n        ...OptionSetupCompletenessFields\n        ...MeetingPointCompletenessFields\n        ...CutOffCompletenessFields\n        __typename\n      }\n      __typename\n    }\n    pagination {\n      limit\n      offset\n      totalItems\n      __typename\n    }\n    __typename\n  }\n}"
  );

  function getStoredAuth() {
    return new Promise(function (resolve) {
      chrome.storage.local.get([TOKEN_KEY, SUPPLIER_KEY], resolve);
    });
  }

  function waitForNewToken(timeoutMs) {
    return new Promise(function (resolve) {
      var timer = setTimeout(function () {
        chrome.storage.onChanged.removeListener(onChange);
        resolve(null);
      }, timeoutMs);

      function onChange(changes, area) {
        if (area !== "local") return;
        if (changes[TOKEN_KEY]) {
          clearTimeout(timer);
          chrome.storage.onChanged.removeListener(onChange);
          chrome.storage.local.get([TOKEN_KEY, SUPPLIER_KEY], resolve);
        }
      }
      chrome.storage.onChanged.addListener(onChange);
    });
  }

  function sleep(ms) {
    return new Promise(function (r) { setTimeout(r, ms); });
  }

  function jitter(base, jitterRange) {
    return base + Math.floor(Math.random() * jitterRange);
  }

  function makeBody(limit, offset, filters) {
    var input = { limit: limit, offset: offset };
    if (filters && filters.length) {
      input.filters = filters;
    }
    return JSON.stringify({
      operationName: "CatalogActivityOption_ActivityOptionDetailsSearch",
      query: GYG_ACTIVITY_OPTION_SEARCH_QUERY,
      variables: { input: input }
    });
  }

  function toStr(v) { return v == null ? "" : String(v); }
  function toArr(v) { return Array.isArray(v) ? v : []; }
  function toObj(v) { return v && typeof v === "object" ? v : {}; }

  function mapItemToRow(item, productIdFallback) {
    var o = toObj(item);
    var productId = toStr(o.activityId) || toStr(productIdFallback);
    var sourceText = toObj(o.sourceText);
    var connectivitySettings = toObj(o.connectivitySettings);
    var title = toStr(sourceText.title) || toStr(o.title) || toStr(o.name);
    var externalId = toStr(connectivitySettings.externalProductId) || toStr(o.externalId) || toStr(o.externalProductId);
    if (String(externalId).trim().toUpperCase() === "GYG_MANAGED") externalId = "";
    return {
      productId: productId,
      optionId: toStr(o.id),
      optionName: title,
      externalProductId: externalId,
      status: toStr(o.status)
    };
  }

  /**
   * Fetch all activity options with pagination (status-agnostic). Uses token/supplierId from chrome.storage.local.
   * @param {object} cfg - limit, startOffset, maxRetries, filters (status filter is stripped), ...
   * @returns {Promise<{items: Array<object>, mappedById: object, errorsById: object}>}
   */
  async function runFetchAllOptions(cfg) {
    cfg = cfg || {};
    var limit = Math.min(50, cfg.limit == null ? 50 : cfg.limit);
    var startOffset = cfg.startOffset || 0;
    var maxRetries = cfg.maxRetries == null ? 3 : cfg.maxRetries;
    var filters = cfg.filters;
    var requestTimeoutMs = cfg.requestTimeoutMs == null ? 15000 : cfg.requestTimeoutMs;
    var interRequestDelayMinMs = cfg.interRequestDelayMinMs == null ? 600 : cfg.interRequestDelayMinMs;
    var interRequestDelayJitterMs = cfg.interRequestDelayJitterMs == null ? 400 : cfg.interRequestDelayJitterMs;
    var tokenRefreshWaitMs = cfg.tokenRefreshWaitMs == null ? 8000 : cfg.tokenRefreshWaitMs;
    var productIdFallback = cfg.productIdFallback != null ? String(cfg.productIdFallback) : "";

    var mapById = new Map();
    var offset = startOffset;
    var totalItems = null;
    var attempt = 0;

    while (true) {
      attempt = 0;
      var lastErr = null;

      var auth = await getStoredAuth();
      var token = auth[TOKEN_KEY];
      var supplierId = auth[SUPPLIER_KEY];

      if (!token) {
        var maybe = await waitForNewToken(tokenRefreshWaitMs);
        if (maybe && maybe[TOKEN_KEY]) {
          token = maybe[TOKEN_KEY];
          supplierId = maybe[SUPPLIER_KEY];
        }
      }

      if (!token) {
        throw new Error("No auth token found. Open a product page in a tab so the extension can capture the header.");
      }

      var pageData = null;
      var success = false;

      while (attempt <= maxRetries && !success) {
        attempt++;
        var controller = new AbortController();
        var to = setTimeout(function () { controller.abort(); }, requestTimeoutMs);

        try {
          var headers = {
            "Content-Type": "application/json",
            "Accept": "multipart/mixed;subscriptionSpec=1.0, application/json",
            "Authorization": token,
            "apollographql-client-name": "supplier-portal",
            "apollographql-client-version": "v47840"
          };
          if (supplierId) headers["x-gyg-supplier-id"] = String(supplierId);

          var resp = await fetch(ENDPOINT, {
            method: "POST",
            headers: headers,
            credentials: "include",
            body: makeBody(limit, offset, filters),
            signal: controller.signal
          });
          clearTimeout(to);

          if (resp.status === 401) {
            var fresh = await waitForNewToken(tokenRefreshWaitMs);
            if (fresh && fresh[TOKEN_KEY]) {
              token = fresh[TOKEN_KEY];
              supplierId = fresh[SUPPLIER_KEY];
              continue;
            }
            throw new Error("401 received and no fresh token captured within wait window.");
          }

          if (resp.status >= 500 || resp.status === 429) {
            lastErr = new Error("Server error " + resp.status);
            await sleep(Math.pow(2, attempt) * 500);
            continue;
          }

          var json = await resp.json();
          if (json.errors && Array.isArray(json.errors) && json.errors.length > 0) {
            throw new Error("GraphQL errors: " + JSON.stringify(json.errors));
          }
          pageData = json;
          success = true;
        } catch (err) {
          clearTimeout(to);
          lastErr = err;
          if (err.name === "AbortError") {
            await sleep(Math.pow(2, attempt) * 500);
          } else {
            await sleep(Math.pow(2, attempt) * 300);
          }
        }
      }

      if (!pageData) {
        throw new Error("Failed to fetch page after retries: " + (lastErr ? lastErr.toString() : ""));
      }

      var search = pageData.data && pageData.data.activityOptionSearch;
      var items = Array.isArray(search && search.items) ? search.items : [];
      var pagination = search && search.pagination ? search.pagination : null;

      items.forEach(function (item) {
        var id = item != null && item.id != null ? String(item.id) : null;
        if (id != null) mapById.set(id, item);
      });

      if (pagination) {
        var respOffset = pagination.offset;
        var respLimit = pagination.limit;
        totalItems = pagination.totalItems;
        var nextOffset = (respOffset != null ? respOffset : offset) + (respLimit != null ? respLimit : limit);
        if (nextOffset === offset) throw new Error("Pagination not advancing");
        if (totalItems != null && nextOffset >= totalItems) break;
        offset = nextOffset;
      } else {
        break;
      }

      await sleep(jitter(interRequestDelayMinMs, interRequestDelayJitterMs));
    }

    var itemsList = Array.from(mapById.values());
    var mappedById = {};
    var errorsById = {};
    itemsList.forEach(function (item) {
      var id = item != null && item.id != null ? String(item.id) : "";
      try {
        mappedById[id] = mapItemToRow(item, productIdFallback);
      } catch (err) {
        mappedById[id] = null;
        errorsById[id] = (err && err.message) ? err.message : String(err);
      }
    });

    return { items: itemsList, mappedById: mappedById, errorsById: errorsById };
  }

  self.runFetchAllOptions = runFetchAllOptions;
})();
