/**
 * Remote-first Channel app company mapping with chrome.storage.local cache
 * and bundled JSON fallback. Intended for MV3 service worker via importScripts.
 */
(function (root, factory) {
  const service = factory();
  if (typeof module !== "undefined" && module.exports) {
    module.exports = service;
  } else {
    root.ResellerAppCompanyMapService = service;
  }
})(typeof self !== "undefined" ? self : globalThis, function () {
  "use strict";

  const LOG_PREFIX = "[reseller-app-map]";
  const REMOTE_MAPPING_URL =
    "https://raw.githubusercontent.com/sebastiaanvente-spec/chrome-extension/refs/heads/main/reseller-app-company-map.json";
  const REMOTE_MAPPING_MAX_AGE_MS = 24 * 60 * 60 * 1000;
  const FETCH_TIMEOUT_MS = 8000;
  const CACHE_STORAGE_KEY = "resellerAppCompanyMapCache";
  const BUNDLED_MAP_PATH = "data/reseller-app-company-map.json";
  const SHORTNAME_PATTERN = /^[a-z0-9_-]+$/;
  const MAX_SHORTNAME_LENGTH = 200;
  const DANGEROUS_KEYS = new Set(["__proto__", "prototype", "constructor"]);

  let resolvedMemoryCache = null;
  let inFlightRequest = null;

  function defaultDeps() {
    return {
      fetch: globalThis.fetch.bind(globalThis),
      storageGet(keys) {
        return new Promise((resolve) => {
          chrome.storage.local.get(keys, resolve);
        });
      },
      storageSet(items) {
        return new Promise((resolve) => {
          chrome.storage.local.set(items, resolve);
        });
      },
      getBundledUrl(path) {
        return chrome.runtime.getURL(path);
      },
      now() {
        return Date.now();
      }
    };
  }

  function isDangerousKey(key) {
    return DANGEROUS_KEYS.has(key);
  }

  function isPositiveSafeInteger(value) {
    return (
      typeof value === "number" &&
      Number.isInteger(value) &&
      value > 0 &&
      value <= Number.MAX_SAFE_INTEGER
    );
  }

  function validateShortname(shortname) {
    if (typeof shortname !== "string") {
      return false;
    }
    if (!shortname || shortname.length > MAX_SHORTNAME_LENGTH) {
      return false;
    }
    if (shortname !== shortname.toLowerCase()) {
      return false;
    }
    return SHORTNAME_PATTERN.test(shortname);
  }

  function validateResellerAppCompanyMapDocument(document) {
    if (!document || typeof document !== "object" || Array.isArray(document)) {
      return null;
    }
    if (document.schemaVersion !== 1) {
      return null;
    }
    if (
      !document.mapping ||
      typeof document.mapping !== "object" ||
      Array.isArray(document.mapping)
    ) {
      return null;
    }

    const mapping = Object.create(null);
    for (const shortname of Object.keys(document.mapping)) {
      if (isDangerousKey(shortname)) {
        return null;
      }
      if (!validateShortname(shortname)) {
        return null;
      }
      const appPk = document.mapping[shortname];
      if (!isPositiveSafeInteger(appPk)) {
        return null;
      }
      mapping[shortname] = appPk;
    }

    return {
      schemaVersion: 1,
      generatedAt:
        typeof document.generatedAt === "string" ? document.generatedAt : null,
      mapping
    };
  }

  function normalizeBundledDocument(raw) {
    const validated = validateResellerAppCompanyMapDocument(raw);
    if (!validated) {
      return null;
    }

    return {
      schemaVersion: validated.schemaVersion,
      generatedAt: validated.generatedAt,
      mapping: validated.mapping,
      duplicates:
        raw.duplicates && typeof raw.duplicates === "object" && !Array.isArray(raw.duplicates)
          ? raw.duplicates
          : {},
      inactiveOnly:
        raw.inactiveOnly &&
        typeof raw.inactiveOnly === "object" &&
        !Array.isArray(raw.inactiveOnly)
          ? raw.inactiveOnly
          : {},
      failedApps: Array.isArray(raw.failedApps) ? raw.failedApps : [],
      stats: raw.stats && typeof raw.stats === "object" ? raw.stats : {}
    };
  }

  function buildMappingDatabase(document, includeBundledExtras) {
    const validated = validateResellerAppCompanyMapDocument(document);
    if (!validated) {
      return null;
    }

    if (!includeBundledExtras) {
      return {
        schemaVersion: validated.schemaVersion,
        generatedAt: validated.generatedAt,
        mapping: validated.mapping,
        duplicates: {},
        inactiveOnly: {},
        failedApps: [],
        stats: {}
      };
    }

    return normalizeBundledDocument(document);
  }

  function safeMetadata({
    source,
    document,
    fetchedAt,
    ageMs = null,
    status = "ok"
  }) {
    const mappingCount = document?.mapping
      ? Object.keys(document.mapping).length
      : 0;
    return {
      source,
      schemaVersion: document?.schemaVersion ?? null,
      generatedAt: document?.generatedAt ?? null,
      mappingCount,
      fetchedAt: fetchedAt ?? null,
      ageMs,
      status
    };
  }

  function logEvent(message, metadata) {
    console.log(LOG_PREFIX, message, metadata || {});
  }

  function createSuccessResponse(document, metadata) {
    return {
      success: true,
      mapping: document.mapping,
      document,
      metadata
    };
  }

  async function readCacheEntry(deps) {
    const stored = await deps.storageGet(CACHE_STORAGE_KEY);
    const entry = stored?.[CACHE_STORAGE_KEY];
    if (!entry || typeof entry !== "object") {
      return null;
    }
    if (!entry.document || typeof entry.fetchedAt !== "number") {
      return null;
    }
    return entry;
  }

  async function writeCacheEntry(deps, document) {
    await deps.storageSet({
      [CACHE_STORAGE_KEY]: {
        fetchedAt: deps.now(),
        sourceUrl: REMOTE_MAPPING_URL,
        document
      }
    });
  }

  async function fetchRemoteDocument(deps) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

    try {
      const response = await deps.fetch(REMOTE_MAPPING_URL, {
        cache: "no-store",
        credentials: "omit",
        signal: controller.signal
      });

      if (!response.ok) {
        return {
          ok: false,
          error: `Remote mapping request failed with status ${response.status}`
        };
      }

      const contentType = response.headers.get("content-type") || "";
      if (contentType.includes("text/html")) {
        return {
          ok: false,
          error: "Remote mapping response is HTML instead of JSON"
        };
      }

      const raw = await response.json();
      const document = validateResellerAppCompanyMapDocument(raw);
      if (!document) {
        return {
          ok: false,
          error: "Remote mapping document failed validation"
        };
      }

      return { ok: true, document };
    } catch (error) {
      const message =
        error?.name === "AbortError"
          ? "Remote mapping request timed out"
          : error?.message || String(error);
      return { ok: false, error: message };
    } finally {
      clearTimeout(timeoutId);
    }
  }

  async function loadBundledDocument(deps) {
    try {
      const url = deps.getBundledUrl(BUNDLED_MAP_PATH);
      const response = await deps.fetch(url);
      if (!response.ok) {
        return {
          ok: false,
          error: `Bundled mapping request failed with status ${response.status}`
        };
      }

      const contentType = response.headers.get("content-type") || "";
      if (contentType.includes("text/html")) {
        return {
          ok: false,
          error: "Bundled mapping response is HTML instead of JSON"
        };
      }

      const raw = await response.json();
      const document = normalizeBundledDocument(raw);
      if (!document) {
        return {
          ok: false,
          error: "Bundled mapping document failed validation"
        };
      }

      return { ok: true, document };
    } catch (error) {
      return {
        ok: false,
        error: error?.message || String(error)
      };
    }
  }

  function createService(deps = defaultDeps()) {
    async function getResellerAppCompanyMap(options = {}) {
      const forceRefresh = options.forceRefresh === true;
      const now = deps.now();

      if (
        !forceRefresh &&
        resolvedMemoryCache &&
        now - resolvedMemoryCache.fetchedAt < REMOTE_MAPPING_MAX_AGE_MS
      ) {
        logEvent("using fresh cache", safeMetadata(resolvedMemoryCache.metadata));
        return createSuccessResponse(
          resolvedMemoryCache.document,
          resolvedMemoryCache.metadata
        );
      }

      if (!forceRefresh && inFlightRequest) {
        return inFlightRequest;
      }

      const run = async () => {
        const cacheEntry = await readCacheEntry(deps);
        const cacheAgeMs =
          cacheEntry && typeof cacheEntry.fetchedAt === "number"
            ? now - cacheEntry.fetchedAt
            : null;
        const cachedDocument = cacheEntry
          ? validateResellerAppCompanyMapDocument(cacheEntry.document)
          : null;
        const cacheHasValidDocument = !!cachedDocument;
        const cacheIsFresh =
          cacheEntry &&
          cacheAgeMs !== null &&
          cacheAgeMs >= 0 &&
          cacheAgeMs < REMOTE_MAPPING_MAX_AGE_MS &&
          cacheHasValidDocument;

        if (!forceRefresh && cacheIsFresh && cachedDocument) {
          const metadata = safeMetadata({
            source: "cache",
            document: cachedDocument,
            fetchedAt: cacheEntry.fetchedAt,
            ageMs: cacheAgeMs
          });
          logEvent("using fresh cache", metadata);
          const database = buildMappingDatabase(cachedDocument, false);
          resolvedMemoryCache = {
            document: database,
            fetchedAt: cacheEntry.fetchedAt,
            metadata
          };
          return createSuccessResponse(database, metadata);
        }

        if (forceRefresh || !cacheIsFresh) {
          logEvent("downloading remote mapping", {
            forceRefresh,
            cacheIsFresh: !!cacheIsFresh
          });
          const remoteResult = await fetchRemoteDocument(deps);
          if (remoteResult.ok) {
            await writeCacheEntry(deps, remoteResult.document);
            const fetchedAt = deps.now();
            const metadata = safeMetadata({
              source: "remote",
              document: remoteResult.document,
              fetchedAt,
              ageMs: 0
            });
            logEvent("remote mapping updated", metadata);
            const database = buildMappingDatabase(remoteResult.document, false);
            resolvedMemoryCache = {
              document: database,
              fetchedAt,
              metadata
            };
            return createSuccessResponse(database, metadata);
          }
        }

        if (cachedDocument) {
          const metadata = safeMetadata({
            source: "expired_cache",
            document: cachedDocument,
            fetchedAt: cacheEntry.fetchedAt,
            ageMs: cacheAgeMs,
            status: "fallback"
          });
          logEvent("remote mapping failed; using expired cache", metadata);
          const database = buildMappingDatabase(cachedDocument, false);
          resolvedMemoryCache = {
            document: database,
            fetchedAt: cacheEntry.fetchedAt,
            metadata
          };
          return createSuccessResponse(database, metadata);
        }

        const bundledResult = await loadBundledDocument(deps);
        if (bundledResult.ok) {
          const metadata = safeMetadata({
            source: "bundled",
            document: bundledResult.document,
            fetchedAt: null,
            status: "fallback"
          });
          logEvent("using bundled fallback", metadata);
          resolvedMemoryCache = {
            document: bundledResult.document,
            fetchedAt: deps.now(),
            metadata
          };
          return createSuccessResponse(bundledResult.document, metadata);
        }

        return {
          success: false,
          error: bundledResult.error || "Unable to load Channel app mapping"
        };
      };

      const promise = run();
      if (!forceRefresh) {
        inFlightRequest = promise;
      }

      try {
        return await promise;
      } finally {
        if (!forceRefresh) {
          inFlightRequest = null;
        }
      }
    }

    function clearMemoryCache() {
      resolvedMemoryCache = null;
      inFlightRequest = null;
    }

    return {
      CACHE_STORAGE_KEY,
      REMOTE_MAPPING_URL,
      REMOTE_MAPPING_MAX_AGE_MS,
      FETCH_TIMEOUT_MS,
      BUNDLED_MAP_PATH,
      SHORTNAME_PATTERN,
      MAX_SHORTNAME_LENGTH,
      validateResellerAppCompanyMapDocument,
      normalizeBundledDocument,
      buildMappingDatabase,
      safeMetadata,
      getResellerAppCompanyMap,
      clearMemoryCache
    };
  }

  const defaultService = createService();

  return Object.assign(
    {
      createService,
      defaultService
    },
    defaultService
  );
});
