# Changelog

All notable changes to the FareHarbor Automator extension will be documented in this file.

**Note:** When updating this file, also update the `CHANGELOG` array in `popup.js` to keep the in-extension changelog in sync.

---

## 2.19.1
- Cleaned up UI and added update instructions

## 2.19.0
- Added a version check and download update option

## 2.18.2
- Added 'open all products tab' to Viator copy mapping data

## 2.18.1
- Tabs opened for capacity check now auto close again

## 2.18.0
- Completely revamped copy mapping data for GetYourGuide Products, now scrapes over API being faster and more reliable. Deprecated old version

## 2.17.3
- Copy complete mapping file for GetYourGuide now expands to show all channel options when necessary

## 2.17.2
- Added clearer error messaging when extension has not injected in the webpage

## 2.17.1
- Hid copy all products from GetYourGuide and Viator copy mapping data; Not working correctly

## 2.17.0
- Added TripAdvisor Listing to Jump to...

## 2.16.0
- Added Google Sheets clipboard export to Capacity Check

## 2.15.1
- Updated Jump to for Support to only show relevant options

## 2.15.0
- Added use case selector
- Added copy FareHarbor reports

## 2.14.0
- Added Supplier ID to Jump to.. for GetYourGuide

## 2.13.0
- Added copy mapping file for Viator
- Added TSV transfer option to GetYourGuide copy mapping

## 2.12.0
- Added copy all Viator and GetYourGuide product feature
- Restructured Copy Mapping Data

## 2.11.0
- Added a GetYourGuide and Viator data copy feature

## 2.01.0
- Added Copy FareHarbor items list

## 2.0.31
- Added changelog to extension

## 2.0.3
- Bug fix where not all customer types would correctly be duplicated

## 2.0.0
- New version, UI changes
