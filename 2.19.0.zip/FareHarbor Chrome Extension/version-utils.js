/**
 * Numeric semver-style comparison for extension versions (e.g. 2.18.2).
 * @returns {-1|0|1|null} -1 if a < b, 0 if equal, 1 if a > b, null if invalid
 */
(function (global) {
  'use strict';

  function parseVersionParts(str) {
    if (typeof str !== 'string' || !str.trim()) return null;
    const parts = str.trim().split('.');
    const nums = [];
    for (let i = 0; i < parts.length; i++) {
      const p = parts[i];
      if (p === '' || !/^\d+$/.test(p)) return null;
      nums.push(parseInt(p, 10));
    }
    return nums.length ? nums : null;
  }

  function compareVersions(a, b) {
    const pa = parseVersionParts(String(a));
    const pb = parseVersionParts(String(b));
    if (!pa || !pb) return null;
    const len = Math.max(pa.length, pb.length);
    for (let i = 0; i < len; i++) {
      const x = pa[i] !== undefined ? pa[i] : 0;
      const y = pb[i] !== undefined ? pb[i] : 0;
      if (x < y) return -1;
      if (x > y) return 1;
    }
    return 0;
  }

  if (typeof globalThis !== 'undefined') {
    globalThis.compareExtensionVersions = compareVersions;
    globalThis.compareVersions = compareVersions;
  }
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { compareVersions, parseVersionParts };
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
