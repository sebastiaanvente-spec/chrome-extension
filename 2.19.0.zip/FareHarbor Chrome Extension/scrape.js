// scrape.js - Injected script for background tab resource extraction
// This script runs in background tabs to extract resource information from booking detail pages

(function() {
  'use strict';

  console.log('[scrape.js] === SCRAPE SCRIPT LOADED ===');
  console.log('[scrape.js] Starting resource extraction on:', window.location.href);
  
  // Function to wait for an element to disappear
  async function waitForElementToDisappear(selector, maxWait = 3000) {
    const startTime = Date.now();
    const checkInterval = 100; // Check every 100ms
    
    while (Date.now() - startTime < maxWait) {
      const element = document.querySelector(selector);
      if (!element) {
        console.log(`[scrape.js] Element ${selector} has disappeared`);
        return true;
      }
      await new Promise(resolve => setTimeout(resolve, checkInterval));
    }
    
    console.log(`[scrape.js] Element ${selector} still present after ${maxWait}ms`);
    return false;
  }

  // Function to close the overlay by clicking the close button
  async function closeOverlay() {
    console.log('[scrape.js] Attempting to close overlay...');
    
    // Find the overlay close button
    const closeButton = document.querySelector('button.overlay-close');
    if (closeButton) {
      console.log('[scrape.js] Found overlay close button, clicking it...');
      try {
        closeButton.click();
        console.log('[scrape.js] Overlay close button clicked, waiting for overlay to close...');
        // Wait for overlay to actually close (check if button disappears or overlay element is gone)
        await waitForElementToDisappear('button.overlay-close', 2000);
        console.log('[scrape.js] Overlay closed');
        return true;
      } catch (error) {
        console.error('[scrape.js] Error clicking overlay close button:', error);
        return false;
      }
    } else {
      console.log('[scrape.js] Overlay close button not found - overlay may already be closed or not present');
      return false;
    }
  }

  // Function to check if a button is actually visible and clickable
  function isButtonVisibleAndEnabled(button) {
    if (!button) return false;
    
    // Check if button is disabled
    if (button.disabled) return false;
    
    // Check if button has ng-disabled attribute set to true
    const ngDisabled = button.getAttribute('ng-disabled');
    if (ngDisabled === 'true' || button.getAttribute('disabled') !== null) {
      return false;
    }
    
    // Check if button is actually visible (not hidden by CSS)
    const style = window.getComputedStyle(button);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
      return false;
    }
    
    // Check if button is in the viewport (rough check)
    const rect = button.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) {
      return false;
    }
    
    // Check if button is actually in the document (not a detached element)
    if (!document.body.contains(button)) {
      return false;
    }
    
    return true;
  }

  // Function to wait for activities to load after clicking "Load more"
  async function waitForActivitiesToLoad(previousCount = 0, maxWait = 1500) {
    const startTime = Date.now();
    const checkInterval = 100; // Reduced from 200ms to 100ms for faster checks
    
    console.log('[scrape.js] Waiting for activities to load...');
    
    while (Date.now() - startTime < maxWait) {
      const currentIndicators = document.querySelectorAll('[data-test-id="activity-booked-booking-indicator"]');
      if (currentIndicators.length > previousCount) {
        console.log(`[scrape.js] Activities loaded: ${currentIndicators.length} indicators found (was ${previousCount})`);
        return true;
      }
      await new Promise(resolve => setTimeout(resolve, checkInterval));
    }
    
    console.log('[scrape.js] Activities may still be loading, but proceeding...');
    return false;
  }

  // Function to click "Load more" button if it exists to load all activities
  async function loadMoreActivities() {
    console.log('[scrape.js] Checking for "Load more" activities button...');
    
    // Check immediately first (no wait if already available)
    let hasNextPageContainer = document.querySelector('div.activities-next-page');
    let hasContent = document.querySelector('[data-test-id="activity-booked-booking-indicator"]') || hasNextPageContainer;
    
    // Only wait if content not immediately available, but with shorter timeout and more frequent checks
    if (!hasContent) {
      const maxWait = 500; // Reduced from 2000ms to 500ms
      const startTime = Date.now();
      while (Date.now() - startTime < maxWait) {
        // Check for the parent div first (more reliable indicator that button will appear)
        hasNextPageContainer = document.querySelector('div.activities-next-page');
        hasContent = document.querySelector('[data-test-id="activity-booked-booking-indicator"]') || hasNextPageContainer;
        if (hasContent) {
          console.log('[scrape.js] Content is ready');
          break;
        }
        await new Promise(resolve => setTimeout(resolve, 50)); // Check every 50ms instead of 100ms
      }
    } else {
      console.log('[scrape.js] Content is ready (immediate)');
    }
    
    let clickCount = 0;
    const maxClicks = 10; // Prevent infinite loop
    const clickedButtons = new Set(); // Track which buttons we've already clicked
    
    while (clickCount < maxClicks) {
      // Use more specific selector: target button within the parent div with both classes
      // This matches the exact structure: div.activities-next-page > button.activities-load-more.test-load-more-activities-action
      // Try the most specific selector first (most common case)
      let loadMoreButtons = document.querySelectorAll('div.activities-next-page button.activities-load-more.test-load-more-activities-action');
      
      // If no results, try fallback selectors
      if (loadMoreButtons.length === 0) {
        loadMoreButtons = document.querySelectorAll('div.activities-next-page button.activities-load-more, div.activities-next-page button.test-load-more-activities-action');
      }
      
      // Final fallback to original selector (in case structure changes)
      if (loadMoreButtons.length === 0) {
        loadMoreButtons = document.querySelectorAll('button.activities-load-more.test-load-more-activities-action, button.activities-load-more, button.test-load-more-activities-action');
      }
      
      console.log(`[scrape.js] Found ${loadMoreButtons.length} potential "Load more" button(s)`);
      
      // Filter to only visible and enabled buttons we haven't clicked yet
      let buttonToClick = null;
      for (const button of loadMoreButtons) {
        // Check if we've already clicked this exact button element
        if (clickedButtons.has(button)) {
          console.log('[scrape.js] Skipping button - already clicked this element');
          continue;
        }
        
        // Check if button is visible and enabled
        if (isButtonVisibleAndEnabled(button)) {
          buttonToClick = button;
          break;
        }
      }
      
      if (!buttonToClick) {
        console.log('[scrape.js] No more clickable "Load more" buttons found');
        break;
      }
      
      try {
        console.log(`[scrape.js] Clicking "Load more" button (attempt ${clickCount + 1}/${maxClicks})...`);
        // Mark this button as clicked before clicking
        clickedButtons.add(buttonToClick);
        
        // Get current indicator count before clicking
        const indicatorsBeforeClick = document.querySelectorAll('[data-test-id="activity-booked-booking-indicator"]').length;
        
        buttonToClick.click();
        console.log('[scrape.js] "Load more" button clicked, waiting for activities to load...');
        
        // Wait for new activities to appear (check if indicator count increases)
        await waitForActivitiesToLoad(indicatorsBeforeClick, 1500);
        
        clickCount++;
        
        // Small delay before checking for next button to allow DOM to update
        await new Promise(resolve => setTimeout(resolve, 100));
      } catch (error) {
        console.error('[scrape.js] Error clicking "Load more" button:', error);
        break;
      }
    }
    
    if (clickCount > 0) {
      console.log(`[scrape.js] Finished loading activities (clicked ${clickCount} time(s))`);
      return true;
    } else {
      console.log('[scrape.js] No "Load more" activities button found or all activities already loaded');
      return false;
    }
  }
  
  // Check if we have a target date/time for resource reapplication detection
  const targetDateTime = window.FAREHARBOR_TARGET_DATETIME;
  console.log('[scrape.js] Target date/time for reapplication:', targetDateTime);
  
  // Check if we should extract resources (default to true for backward compatibility)
  // Read this inside the extraction function to ensure it's set by the time we need it
  function shouldExtractResources() {
    // Check if the flag was explicitly set (could be true, false, or undefined)
    const flagValue = window.FAREHARBOR_EXTRACT_RESOURCES;
    const extractResources = flagValue !== false; // Only false if explicitly set to false
    console.log('[scrape.js] Extract resources flag:', extractResources, '(window.FAREHARBOR_EXTRACT_RESOURCES:', flagValue, ')');
    return extractResources;
  }

  // No longer searching for a specific resource - find ALL resources

  // Function to detect and handle resource reapplication elements
  async function detectAndHandleResourceReapplication(targetDateTime) {
    console.log('[scrape.js] Checking for resource reapplication elements...');
    
    if (!targetDateTime) {
      console.log('[scrape.js] No target date/time provided, skipping reapplication detection');
      return { detected: false, resources: null };
    }

    // Find all reapplied resource elements
    const reapplicationElements = document.querySelectorAll('[data-test-id="activity-reapplied-resources-indicator"]');
    console.log(`[scrape.js] Found ${reapplicationElements.length} resource reapplication elements`);
    
    if (reapplicationElements.length === 0) {
      console.log('[scrape.js] No resource reapplication elements found');
      return { detected: false, resources: null };
    }

    // Parse target date/time for comparison
    const targetDate = new Date(targetDateTime);
    console.log('[scrape.js] Parsed target date:', targetDate);
    
    if (isNaN(targetDate.getTime())) {
      console.log('[scrape.js] Invalid target date/time, skipping reapplication detection');
      return { detected: false, resources: null };
    }

    // Analyze each reapplication element to find timestamps
    const reapplicationData = [];
    
    for (let i = 0; i < reapplicationElements.length; i++) {
      const element = reapplicationElements[i];
      console.log(`[scrape.js] Analyzing reapplication element ${i + 1}`);
      
      // Check if it contains "Reapplied resource uses" text
      const reappliedText = Array.from(element.querySelectorAll('div')).find(div => 
                             div.textContent.trim() === 'Reapplied resource uses');
      
      if (!reappliedText) {
        console.log(`[scrape.js] Element ${i + 1} does not contain "Reapplied resource uses" text`);
        continue;
      }
      
      console.log(`[scrape.js] Element ${i + 1} contains "Reapplied resource uses" text`);
      
      // Find the timestamp button (e.g., "3 minutes ago")
      const timestampButton = element.querySelector('button.activity-meta-date');
      if (!timestampButton) {
        console.log(`[scrape.js] Element ${i + 1} has no timestamp button`);
        continue;
      }
      
      const timestampText = timestampButton.textContent.trim();
      const titleTimestamp = timestampButton.getAttribute('title');
      console.log(`[scrape.js] Element ${i + 1} timestamp text: "${timestampText}", title: "${titleTimestamp}"`);
      
      // Parse the timestamp - try title first, then relative text
      let reapplicationDate = null;
      
      if (titleTimestamp) {
        // Try to parse title format (e.g., "9/23/25 at 3:28 PM")
        reapplicationDate = parseTimestamp(titleTimestamp);
      }
      
      if (!reapplicationDate && timestampText) {
        // Try to parse relative format (e.g., "3 minutes ago")
        reapplicationDate = parseRelativeTimestamp(timestampText);
      }
      
      if (!reapplicationDate) {
        console.log(`[scrape.js] Could not parse timestamp for element ${i + 1}`);
        continue;
      }
      
      console.log(`[scrape.js] Element ${i + 1} parsed timestamp:`, reapplicationDate);
      
      // Find the "Show changes" button
      const showChangesButton = element.querySelector('button.form-link');
      if (!showChangesButton) {
        console.log(`[scrape.js] Element ${i + 1} has no "Show changes" button`);
        continue;
      }
      
      reapplicationData.push({
        element,
        timestamp: reapplicationDate,
        showChangesButton,
        index: i + 1
      });
    }
    
    if (reapplicationData.length === 0) {
      console.log('[scrape.js] No valid reapplication elements found');
      return { detected: false, resources: null };
    }
    
    console.log(`[scrape.js] Found ${reapplicationData.length} valid reapplication elements`);
    
    // Filter to only reapplications that occurred after the target time
    const reapplicationsAfterTarget = reapplicationData.filter(reapplication => {
      const isAfterTarget = reapplication.timestamp > targetDate;
      console.log(`[scrape.js] Reapplication element ${reapplication.index} at ${reapplication.timestamp.toISOString()} ${isAfterTarget ? 'is after' : 'is before/at'} target ${targetDate.toISOString()}`);
      return isAfterTarget;
    });
    
    console.log(`[scrape.js] Found ${reapplicationsAfterTarget.length} reapplications after target time`);
    
    // Sort the filtered ones by timestamp (oldest first) to get the earliest one after target time
    reapplicationsAfterTarget.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
    
    // Select the earliest reapplication that occurred after the target time
    const selectedReapplication = reapplicationsAfterTarget.length > 0 ? reapplicationsAfterTarget[0] : null;
    
    if (selectedReapplication) {
      console.log(`[scrape.js] Selected reapplication element ${selectedReapplication.index} at ${selectedReapplication.timestamp.toISOString()} (earliest after target time)`);
    }
    
    if (!selectedReapplication) {
      console.log('[scrape.js] No reapplication found after target time, using current resources');
      return { detected: true, resources: null, usedReapplication: false };
    }
    
    // Click "Show changes" to reveal the resource table
    console.log(`[scrape.js] Clicking "Show changes" for element ${selectedReapplication.index}`);
    selectedReapplication.showChangesButton.click();
    
    // Wait for the resource table to appear (check for table element)
    console.log('[scrape.js] Waiting for resource reapplication table to load...');
    const maxWait = 2000;
    const startTime = Date.now();
    const checkInterval = 100;
    while (Date.now() - startTime < maxWait) {
      const resourceTable = selectedReapplication.element.querySelector('table.spreadsheet');
      if (resourceTable) {
        console.log('[scrape.js] Resource table found');
        break;
      }
      await new Promise(resolve => setTimeout(resolve, checkInterval));
    }
    
    // Extract resources from the reapplication table
    const historicalResources = extractResourcesFromReapplicationTable(selectedReapplication.element);
    
    if (historicalResources && historicalResources.length > 0) {
      console.log(`[scrape.js] Extracted ${historicalResources.length} historical resources from reapplication table`);
      return { 
        detected: true, 
        resources: historicalResources, 
        usedReapplication: true, 
        selectedTimestamp: selectedReapplication.timestamp.toISOString() 
      };
    } else {
      console.log('[scrape.js] Could not extract resources from reapplication table');
      return { detected: true, resources: null, usedReapplication: false };
    }
  }

  // Helper function to parse timestamp formats like "9/23/25 at 3:28 PM"
  function parseTimestamp(timestampStr) {
    try {
      // Try various date formats
      const formats = [
        timestampStr, // Original format
        timestampStr.replace(' at ', ' '), // Remove " at "
        timestampStr.replace(/(\d{1,2}\/\d{1,2}\/\d{2})/, '20$1') // Convert 2-digit year to 4-digit
      ];
      
      for (const format of formats) {
        const date = new Date(format);
        if (!isNaN(date.getTime())) {
          return date;
        }
      }
      
      return null;
    } catch (error) {
      console.log('[scrape.js] Error parsing timestamp:', error);
      return null;
    }
  }

  // Helper function to parse relative timestamps like "3 minutes ago"
  function parseRelativeTimestamp(relativeStr) {
    try {
      const now = new Date();
      const lowerStr = relativeStr.toLowerCase();
      
      if (lowerStr.includes('minute')) {
        const match = lowerStr.match(/(\d+)\s*minute/);
        if (match) {
          const minutes = parseInt(match[1], 10);
          return new Date(now.getTime() - (minutes * 60 * 1000));
        }
      } else if (lowerStr.includes('hour')) {
        const match = lowerStr.match(/(\d+)\s*hour/);
        if (match) {
          const hours = parseInt(match[1], 10);
          return new Date(now.getTime() - (hours * 60 * 60 * 1000));
        }
      } else if (lowerStr.includes('day')) {
        const match = lowerStr.match(/(\d+)\s*day/);
        if (match) {
          const days = parseInt(match[1], 10);
          return new Date(now.getTime() - (days * 24 * 60 * 60 * 1000));
        }
      } else if (lowerStr.includes('second')) {
        const match = lowerStr.match(/(\d+)\s*second/);
        if (match) {
          const seconds = parseInt(match[1], 10);
          return new Date(now.getTime() - (seconds * 1000));
        }
      }
      
      return null;
    } catch (error) {
      console.log('[scrape.js] Error parsing relative timestamp:', error);
      return null;
    }
  }

  // Function to extract resources from the reapplication table (From column only)
  function extractResourcesFromReapplicationTable(reapplicationElement) {
    console.log('[scrape.js] Extracting resources from reapplication table...');
    
    try {
      // Look for the expanded resource table
      const resourceTable = reapplicationElement.querySelector('table.spreadsheet');
      if (!resourceTable) {
        console.log('[scrape.js] No resource table found in reapplication element');
        return null;
      }
      
      const resources = [];
      const rows = resourceTable.querySelectorAll('tbody tr');
      console.log(`[scrape.js] Found ${rows.length} rows in resource table`);
      
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const cells = row.querySelectorAll('td');
        
        if (cells.length >= 3) { // Should have From #, To #, Resource columns
          const fromCell = cells[0]; // "From #" column (original-use-count)
          const resourceCell = cells[2]; // "Resource" column (skip "To #" column at index 1)
          
          const fromQuantityText = fromCell.textContent.trim();
          const resourceNameElement = resourceCell.querySelector('a') || resourceCell;
          const resourceName = resourceNameElement.textContent.trim();
          
          const fromQuantity = parseInt(fromQuantityText, 10);
          
          // Only extract resources that had a quantity > 0 in the original state (From column)
          if (!isNaN(fromQuantity) && fromQuantity > 0 && resourceName) {
            resources.push({
              name: resourceName,
              quantity: fromQuantity,
              source: 'reapplication-table-from-column'
            });
            console.log(`[scrape.js] Extracted historical resource: "${resourceName}" original quantity: ${fromQuantity} (ignoring new quantity)`);
          } else if (!isNaN(fromQuantity) && fromQuantity === 0 && resourceName) {
            console.log(`[scrape.js] Skipping resource "${resourceName}" - had 0 original quantity (was added later)`);
          } else {
            console.log(`[scrape.js] Could not parse row ${i + 1}: fromQuantity="${fromQuantityText}", resourceName="${resourceName}"`);
          }
        }
      }
      
      console.log(`[scrape.js] Extracted ${resources.length} historical resources from "From #" column only`);
      return resources.length > 0 ? resources : null;
    } catch (error) {
      console.log('[scrape.js] Error extracting from reapplication table:', error);
      return null;
    }
  }

  // Function to find ALL resources using the EXACT DOM structure where resources appear
  function findAllResources() {
    const resourceTotals = {};
    
    console.log(`[scrape.js] Searching for resources in specific DOM structure`);
    
    // Strategy: Look for the EXACT structure where resources appear
    // Resources appear in: tbody[ng-controller="dashboard.resources.ResourceUseEditableCtrl"] tr.invoice-table--row .fh-grey-new
    
    // First approach: Find tbody elements with the resource controller
    const resourceTableBodies = document.querySelectorAll('tbody[ng-controller*="ResourceUseEditableCtrl"], tbody[ng-controller*="ResourceUse"]');
    console.log(`[scrape.js] Found ${resourceTableBodies.length} resource table bodies`);
    
    resourceTableBodies.forEach((tbody, tbodyIndex) => {
      console.log(`[scrape.js] Processing resource table body ${tbodyIndex + 1}`);
      
      // Look for invoice table rows within this tbody
      const resourceRows = tbody.querySelectorAll('tr.invoice-table--row');
      console.log(`[scrape.js] Found ${resourceRows.length} resource rows in tbody ${tbodyIndex + 1}`);
      
      resourceRows.forEach((row, rowIndex) => {
        // Look for .fh-grey-new elements within this specific row structure
        const resourceSpans = row.querySelectorAll('.fh-grey-new');
        
        resourceSpans.forEach((span, spanIndex) => {
          const text = span.textContent.trim();
          console.log(`[scrape.js] Tbody ${tbodyIndex + 1}, Row ${rowIndex + 1}, Span ${spanIndex + 1}: "${text}"`);
          
          // Look for pattern: "ResourceName:" 
          const resourceMatch = text.match(/^(.+?):\s*$/);
          if (resourceMatch) {
            const resourceName = resourceMatch[1].trim();
            console.log(`[scrape.js] Found resource in correct structure: "${resourceName}"`);
            
            // Find the quantity in the same table cell
            const parentCell = span.closest('td');
            let quantity = 1;
            
            if (parentCell) {
              const cellText = parentCell.textContent.trim();
              // Remove the resource name part and look for quantity
              const withoutResourceName = cellText.replace(text, '').trim();
              const quantityMatch = withoutResourceName.match(/(\d+(?:\.\d+)?)/);
              if (quantityMatch) {
                quantity = parseFloat(quantityMatch[1]);
                console.log(`[scrape.js] Found quantity ${quantity} for "${resourceName}"`);
              }
            }
            
            // Add to totals - no filtering needed since we're in the exact right DOM structure
            resourceTotals[resourceName] = (resourceTotals[resourceName] || 0) + quantity;
            console.log(`[scrape.js] "${resourceName}": adding ${quantity}, total now: ${resourceTotals[resourceName]}`);
          }
        });
      });
    });
    
    // Fallback: If no resources found with the controller approach, try the test-id approach
    if (Object.keys(resourceTotals).length === 0) {
      console.log(`[scrape.js] No resources found with controller approach, trying test-id approach`);
      
      const resourceUsageSections = document.querySelectorAll('[data-test-id="active-ct-level-resource-usage-indicator"]');
      console.log(`[scrape.js] Found ${resourceUsageSections.length} resource usage sections`);
      
      resourceUsageSections.forEach((section, sectionIndex) => {
        // Look specifically for the table structure: table.invoice-table tbody tr.invoice-table--row .fh-grey-new
        const resourceSpans = section.querySelectorAll('table.invoice-table tbody tr.invoice-table--row .fh-grey-new');
        console.log(`[scrape.js] Found ${resourceSpans.length} resource spans in structured table within section ${sectionIndex + 1}`);
        
        resourceSpans.forEach((span, spanIndex) => {
          const text = span.textContent.trim();
          console.log(`[scrape.js] Section ${sectionIndex + 1}, Structured span ${spanIndex + 1}: "${text}"`);
          
          // Look for pattern: "ResourceName:" 
          const resourceMatch = text.match(/^(.+?):\s*$/);
          if (resourceMatch) {
            const resourceName = resourceMatch[1].trim();
            console.log(`[scrape.js] Found resource in structured table: "${resourceName}"`);
            
            // Find the quantity in the same table cell
            const parentCell = span.closest('td');
            let quantity = 1;
            
            if (parentCell) {
              const cellText = parentCell.textContent.trim();
              const withoutResourceName = cellText.replace(text, '').trim();
              const quantityMatch = withoutResourceName.match(/(\d+(?:\.\d+)?)/);
              if (quantityMatch) {
                quantity = parseFloat(quantityMatch[1]);
                console.log(`[scrape.js] Found quantity ${quantity} for "${resourceName}"`);
              }
            }
            
            resourceTotals[resourceName] = (resourceTotals[resourceName] || 0) + quantity;
            console.log(`[scrape.js] "${resourceName}": adding ${quantity}, total now: ${resourceTotals[resourceName]}`);
          }
        });
      });
    }
    
    console.log(`[scrape.js] Final resource totals:`, resourceTotals);
    return resourceTotals;
  }

  // Function to extract resources from invoice tables
  function extractResourcesFromInvoiceTables() {
    const resources = {
      included: [],
      excluded: [],
      detailed: []
    };

    // Use the new approach to find ALL resources
    const allResourceTotals = findAllResources();
    
    if (Object.keys(allResourceTotals).length > 0) {
      console.log(`[scrape.js] Found ${Object.keys(allResourceTotals).length} different resources`);
      
      // Convert the resource totals into the expected format
      for (const [resourceName, totalQuantity] of Object.entries(allResourceTotals)) {
        resources.detailed.push({
          name: resourceName,
          quantity: totalQuantity,
          source: 'fh-grey-new-pattern'
        });
        console.log(`[scrape.js] Added resource: "${resourceName}" with total quantity: ${totalQuantity}`);
      }
      
      return resources;
    }

    console.log(`[scrape.js] No resources found with new approach, falling back to old method`);

    // Look for any invoice tables on the page for fallback
    const invoiceTables = document.querySelectorAll('.invoice-table, table[class*="invoice"], table.spreadsheet');
    console.log(`[scrape.js] Found ${invoiceTables.length} invoice tables for fallback extraction`);

    invoiceTables.forEach((table, tableIndex) => {
      console.log(`[scrape.js] Processing invoice table ${tableIndex + 1}`);
      
      // Look for resource-related spans or cells
      const resourceElements = table.querySelectorAll('.fh-grey-new, .resource-name, [class*="resource"]');
      
      resourceElements.forEach(element => {
        const text = element.textContent.trim();
        
        // Check if this looks like a resource name
        if (text && text.length > 2 && text.length < 100 && /^[A-Za-z\s-]+$/.test(text)) {
          console.log(`[scrape.js] Found potential resource: "${text}"`);
          
          // Try to find quantity information using multiple strategies
          let quantity = null;
          
          // Strategy 1: Check next sibling for quantity
          let nextElement = element.nextElementSibling;
          if (nextElement && !quantity) {
            const quantityMatch = nextElement.textContent.match(/(\d+(?:\.\d+)?)/);
            if (quantityMatch) {
              quantity = parseFloat(quantityMatch[1]);
              console.log(`[scrape.js] Found quantity ${quantity} in next sibling for "${text}"`);
            }
          }
          
          // Strategy 2: Check parent cell for quantity
          if (!quantity) {
            const parentCell = element.closest('td, th');
            if (parentCell) {
              const cellText = parentCell.textContent;
              const quantityMatch = cellText.match(/(\d+(?:\.\d+)?)/);
              if (quantityMatch) {
                quantity = parseFloat(quantityMatch[1]);
                console.log(`[scrape.js] Found quantity ${quantity} in parent cell for "${text}"`);
              }
            }
          }
          
          // Strategy 3: Check parent row for quantity patterns
          if (!quantity) {
            const parentRow = element.closest('tr');
            if (parentRow) {
              const rowText = parentRow.textContent;
              // Look for patterns like "2 x Loper" or "Loper: 2" or "Qty: 2"
              const patterns = [
                /(\d+(?:\.\d+)?)\s*x\s*$/i,           // "2 x" or "2.5 x" pattern
                /:\s*(\d+(?:\.\d+)?)/,               // ": 2" or ": 2.5" pattern
                /qty:?\s*(\d+(?:\.\d+)?)/i,          // "Qty: 2" or "Qty: 2.5" pattern
                /quantity:?\s*(\d+(?:\.\d+)?)/i,     // "Quantity: 2" or "Quantity: 2.5" pattern
                /(\d+(?:\.\d+)?)\s*units?/i          // "2 units" or "2.5 units" pattern
              ];
              
              for (const pattern of patterns) {
                const match = rowText.match(pattern);
                if (match) {
                  quantity = parseFloat(match[1]);
                  console.log(`[scrape.js] Found quantity ${quantity} using pattern for "${text}"`);
                  break;
                }
              }
            }
          }
          
          // Strategy 4: Look for guest count in the page as fallback
          if (!quantity) {
            const pageText = document.body.textContent.toLowerCase();
            // Look for guest/adult count patterns that might indicate resource usage
            const guestPatterns = [
              /(\d+(?:\.\d+)?)\s*adult/i,
              /(\d+(?:\.\d+)?)\s*guest/i,
              /(\d+(?:\.\d+)?)\s*people/i,
              /(\d+(?:\.\d+)?)\s*person/i
            ];
            
            for (const pattern of guestPatterns) {
              const match = pageText.match(pattern);
              if (match) {
                quantity = parseFloat(match[1]);
                console.log(`[scrape.js] Using guest count ${quantity} as fallback quantity for "${text}"`);
                break;
              }
            }
          }
          
          // Final fallback if no quantity found
          if (quantity === null) {
            quantity = 1;
            console.log(`[scrape.js] No quantity found for "${text}", defaulting to 1`);
          }
          
          console.log(`[scrape.js] Adding resource: "${text}" with quantity: ${quantity} (type: ${typeof quantity})`);
          
          resources.detailed.push({
            name: text,
            quantity: quantity,
            source: 'invoice-table'
          });
          
          // Log the resource found
          console.log(`[scrape.js] ✅ Found resource "${text}" with quantity ${quantity} (type: ${typeof quantity})`);
        }
      });
    });

    return resources;
  }

  // Function to extract resources from page text content (now redundant with findAllResources)
  function extractResourcesFromPageContent() {
    const resources = {
      included: [],
      excluded: [],
      detailed: []
    };

    // This function is now handled by findAllResources() in extractResourcesFromInvoiceTables()
    console.log(`[scrape.js] Page content extraction is now handled by findAllResources()`);
    
    return resources;
  }

  // Function to extract resources from Angular data (disabled to avoid noise)
  function extractResourcesFromAngularData() {
    const resources = {
      included: [],
      excluded: [],
      detailed: []
    };

    console.log('[scrape.js] Angular data extraction disabled to avoid noise - using DOM structure approach only');
    return resources;
  }

  // Function to extract booking creation date from activity timeline
  function extractBookingCreationDate() {
    console.log('[scrape.js] Extracting booking creation date from activity timeline...');
    
    try {
      // Find all activity-booked-booking-indicator elements
      const activityIndicators = document.querySelectorAll('[data-test-id="activity-booked-booking-indicator"]');
      console.log(`[scrape.js] Found ${activityIndicators.length} activity-booked-booking-indicator elements`);
      
      if (activityIndicators.length === 0) {
        console.log('[scrape.js] No activity indicators found');
        return null;
      }
      
      // Get the bottommost (last) instance
      const bottommostIndicator = activityIndicators[activityIndicators.length - 1];
      console.log('[scrape.js] Using bottommost activity indicator');
      
      // Find the activity-meta-date button within this indicator's parent activity element
      // The structure is: activity-booked-booking-indicator is inside an activity element
      // We need to go up to find the activity element, then find the date button
      const activityElement = bottommostIndicator.closest('.activity');
      if (!activityElement) {
        console.log('[scrape.js] Could not find parent activity element');
        return null;
      }
      
      // Find the date button with class activity-meta-date
      const dateButton = activityElement.querySelector('button.activity-meta-date');
      if (!dateButton) {
        console.log('[scrape.js] Could not find date button in activity element');
        return null;
      }
      
      // Get the title attribute which contains the full date/time
      const dateTitle = dateButton.getAttribute('title');
      if (!dateTitle) {
        console.log('[scrape.js] Date button has no title attribute');
        return null;
      }
      
      console.log(`[scrape.js] Found booking creation date: ${dateTitle}`);
      
      // Parse the date from title format like "12/5/25 at 9:33 PM"
      const parsedDate = parseTimestamp(dateTitle);
      if (!parsedDate) {
        console.log('[scrape.js] Could not parse date from title');
        return null;
      }
      
      console.log(`[scrape.js] Parsed booking creation date: ${parsedDate.toISOString()}`);
      return parsedDate;
      
    } catch (error) {
      console.error('[scrape.js] Error extracting booking creation date:', error);
      return null;
    }
  }

  // Function to determine page type
  function getPageType() {
    const url = window.location.href;
    const title = document.title || '';
    const bodyContent = document.body.textContent || '';

    // Check if this is a booking detail page
    if (url.includes('/bookings/') || bodyContent.includes('Booking Details') || bodyContent.includes('Invoice')) {
      return 'booking-detail';
    }

    // Check if this is a dashboard page
    if (url.includes('/dashboard') || title.includes('Dashboard')) {
      return 'dashboard';
    }

    // Check if this is an error/login page
    if (bodyContent.includes('Sign in') || bodyContent.includes('Login') || bodyContent.includes('Access Denied')) {
      return 'error-login';
    }

    return 'unknown';
  }

  // Main extraction function
  async function extractBookingResources() {
    const pageType = getPageType();
    console.log(`[scrape.js] Page type detected: ${pageType}`);
    console.log(`[scrape.js] Document body length: ${document.body ? document.body.innerHTML.length : 'no body'}`);
    console.log(`[scrape.js] Page contains "invoice": ${document.body ? document.body.innerHTML.toLowerCase().includes('invoice') : false}`);
    console.log(`[scrape.js] Looking for ALL resources using class "fh-grey-new"`);
    
    const result = {
      success: false,
      pageType: pageType,
      url: window.location.href,
      searchStrategy: 'all-resources',
      foundAnyResources: false,
      resources: {
        included: [],
        excluded: [],
        detailed: []
      },
      resourceReapplication: {
        detected: false,
        used: false,
        selectedTimestamp: null
      },
      bookedAt: null, // Booking creation date from activity timeline
      error: null
    };

    try {
      if (pageType === 'error-login') {
        throw new Error('Cannot access page - authentication required');
      }

      // Only extract resources if extractResources flag is true
      const extractResources = shouldExtractResources();
      if (extractResources) {
        console.log('[scrape.js] Resource extraction enabled - extracting resources...');
        
        // Check for resource reapplication first if we have a target date/time
        if (targetDateTime) {
          console.log('[scrape.js] Checking for resource reapplication...');
          try {
            const reapplicationResult = await detectAndHandleResourceReapplication(targetDateTime);
            
            result.resourceReapplication = {
              detected: reapplicationResult.detected,
              used: reapplicationResult.usedReapplication || false,
              selectedTimestamp: reapplicationResult.selectedTimestamp || null
            };
            
            if (reapplicationResult.detected && reapplicationResult.resources) {
              // Use historical resources from reapplication
              console.log('[scrape.js] Using historical resources from reapplication table');
              result.resources.detailed = reapplicationResult.resources;
              result.foundAnyResources = true;
              result.success = true;
              result.searchStrategy = 'resource-reapplication';
              
              console.log(`[scrape.js] Resource reapplication completed. Found ${result.resources.detailed.length} historical resources.`);
              // Still extract bookedAt even if we got resources from reapplication
              console.log(`[scrape.js] Extracting booking creation date...`);
              result.bookedAt = extractBookingCreationDate();
              if (result.bookedAt) {
                console.log(`[scrape.js] Found booking creation date: ${result.bookedAt.toISOString()}`);
              } else {
                console.log(`[scrape.js] No booking creation date found`);
              }
              return result;
            } else if (reapplicationResult.detected) {
              console.log('[scrape.js] Resource reapplication detected but no historical data extracted, continuing with normal extraction');
            }
          } catch (reapplicationError) {
            console.error('[scrape.js] Error during resource reapplication detection:', reapplicationError);
            console.log('[scrape.js] Continuing with normal resource extraction...');
            // Continue with normal extraction
          }
        }

        // Extract from multiple sources
        console.log(`[scrape.js] Extracting from invoice tables...`);
        const invoiceResources = extractResourcesFromInvoiceTables();
        console.log(`[scrape.js] Invoice resources found: ${invoiceResources.detailed.length}`);
        
        console.log(`[scrape.js] Extracting from page content...`);
        const contentResources = extractResourcesFromPageContent();
        console.log(`[scrape.js] Content resources found: ${contentResources.detailed.length}`);
        
        console.log(`[scrape.js] Extracting from Angular data...`);
        const angularResources = extractResourcesFromAngularData();
        console.log(`[scrape.js] Angular resources found: ${angularResources.detailed.length}`);

        // Combine all results
        result.resources.detailed = [
          ...invoiceResources.detailed,
          ...contentResources.detailed,
          ...angularResources.detailed
        ];

        console.log(`[scrape.js] Total resources before deduplication: ${result.resources.detailed.length}`);

        // Remove duplicates
        const seen = new Set();
        result.resources.detailed = result.resources.detailed.filter(resource => {
          const key = `${resource.name}-${resource.quantity}`;
          if (seen.has(key)) {
            return false;
          }
          seen.add(key);
          return true;
        });

        console.log(`[scrape.js] Total resources after deduplication: ${result.resources.detailed.length}`);
        if (result.resources.detailed.length > 0) {
          console.log(`[scrape.js] Resource details:`, result.resources.detailed);
        }

        // Check if we found any resources
        result.foundAnyResources = result.resources.detailed.length > 0;
      } else {
        console.log('[scrape.js] Resource extraction disabled - skipping resource extraction');
        result.foundAnyResources = false;
      }

      // Extract booking creation date from activity timeline
      console.log(`[scrape.js] Extracting booking creation date...`);
      result.bookedAt = extractBookingCreationDate();
      if (result.bookedAt) {
        console.log(`[scrape.js] Found booking creation date: ${result.bookedAt.toISOString()}`);
      } else {
        console.log(`[scrape.js] No booking creation date found`);
      }

      result.success = true;
      
      console.log(`[scrape.js] Extraction completed. Found ${result.resources.detailed.length} resources.`);
      console.log(`[scrape.js] Any resources found: ${result.foundAnyResources}`);

    } catch (error) {
      console.error('[scrape.js] Extraction failed:', error);
      result.error = error.message;
    }

    return result;
  }

  // Wait for page to be fully loaded before extracting
  function waitForPageLoad() {
    return new Promise((resolve) => {
      if (document.readyState === 'complete') {
        resolve();
      } else {
        window.addEventListener('load', resolve);
        // Fallback timeout
        setTimeout(resolve, 5000);
      }
    });
  }

  // Wait for overlay to be fully loaded (if present)
  async function waitForOverlay() {
    const maxWait = 5000; // 5 seconds max (reduced from 10)
    const startTime = Date.now();
    const checkInterval = 100; // Check every 100ms (faster polling)
    
    console.log('[scrape.js] Waiting for overlay to load...');
    
    while (Date.now() - startTime < maxWait) {
      const closeButton = document.querySelector('button.overlay-close');
      if (closeButton) {
        // Check if button is visible and clickable
        const style = window.getComputedStyle(closeButton);
        if (style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0') {
          console.log('[scrape.js] Overlay detected and ready');
          return true;
        }
      }
      await new Promise(resolve => setTimeout(resolve, checkInterval));
    }
    
    console.log('[scrape.js] No overlay detected or timeout reached');
    return false;
  }

  // Main execution
  waitForPageLoad().then(async () => {
    console.log('[scrape.js] Page loaded, starting extraction...');
    console.log('[scrape.js] Current URL:', window.location.href);
    console.log('[scrape.js] Document title:', document.title);
    console.log('[scrape.js] Document ready state:', document.readyState);
    console.log('[scrape.js] Target date/time available:', !!targetDateTime, targetDateTime);
    
    // Check if this is an overlay page
    const isOverlayPage = window.location.search.includes('overlay=');
    console.log('[scrape.js] Is overlay page:', isOverlayPage);
    
    if (isOverlayPage) {
      // Wait for overlay to load, then close it
      console.log('[scrape.js] Waiting for overlay to load...');
      const overlayFound = await waitForOverlay();
      
      if (overlayFound) {
        console.log('[scrape.js] Closing overlay...');
        await closeOverlay();
        console.log('[scrape.js] Overlay closed, checking for content...');
        // Check immediately first, then wait if needed (with shorter timeout and faster checks)
        let hasNextPageContainer = document.querySelector('div.activities-next-page');
        let hasContent = document.querySelector('[data-test-id="activity-booked-booking-indicator"]') || 
                         hasNextPageContainer ||
                         document.querySelector('div.activities-next-page button.activities-load-more');
        
        if (!hasContent) {
          const maxWait = 500; // Reduced from 2000ms to 500ms
          const startTime = Date.now();
          while (Date.now() - startTime < maxWait) {
            // Check for parent div first (more reliable indicator)
            hasNextPageContainer = document.querySelector('div.activities-next-page');
            hasContent = document.querySelector('[data-test-id="activity-booked-booking-indicator"]') || 
                         hasNextPageContainer ||
                         document.querySelector('div.activities-next-page button.activities-load-more');
            if (hasContent) {
              console.log('[scrape.js] Content is visible');
              break;
            }
            await new Promise(resolve => setTimeout(resolve, 50)); // Check every 50ms instead of 100ms
          }
        } else {
          console.log('[scrape.js] Content is visible (immediate)');
        }
      } else {
        console.log('[scrape.js] No overlay found, proceeding with extraction');
      }
      
      // After overlay is closed, check for and click "Load more" button to load all activities
      console.log('[scrape.js] Checking for "Load more" activities button...');
      await loadMoreActivities();
      console.log('[scrape.js] Activities loading complete, proceeding with extraction');
    }
    
    // Check if we need to wait for content, otherwise proceed immediately
    const extractResources = shouldExtractResources();
    if (!extractResources) {
      // Only extracting bookedAt - check if activity indicators are present
      const maxWait = 2000;
      const startTime = Date.now();
      while (Date.now() - startTime < maxWait) {
        const hasIndicators = document.querySelector('[data-test-id="activity-booked-booking-indicator"]');
        if (hasIndicators) {
          console.log('[scrape.js] Activity indicators found, proceeding with extraction...');
          break;
        }
        await new Promise(resolve => setTimeout(resolve, 100));
      }
    }
    
    // Start extraction immediately (no fixed delay)
    (async () => {
      console.log('[scrape.js] Starting extraction...');
      
      try {
        const extractionResult = await extractBookingResources();
        
        console.log('[scrape.js] Extraction completed, result:', extractionResult);
        console.log('[scrape.js] Sending results to background script');
        
        // Send results back to background script
        await chrome.runtime.sendMessage({
          action: 'backgroundScrapeResult',
          data: extractionResult
        });
        
        console.log('[scrape.js] Message sent successfully to background');
      } catch (error) {
        console.error('[scrape.js] Error during extraction:', error);
        
        // Send error result
        await chrome.runtime.sendMessage({
          action: 'backgroundScrapeResult',
          data: {
            success: false,
            error: error.message,
            pageType: 'error',
            url: window.location.href,
            searchStrategy: 'all-resources',
            foundAnyResources: false,
            resources: { included: [], excluded: [], detailed: [] },
            resourceReapplication: {
              detected: false,
              used: false,
              selectedTimestamp: null
            },
            bookedAt: null
          }
        });
      }
      
    })(); // Start immediately, no delay
  }).catch(error => {
    console.error('[scrape.js] Error during page load wait:', error);
    
    // Send error result
    chrome.runtime.sendMessage({
      action: 'backgroundScrapeResult',
      data: {
        success: false,
        error: error.message,
        pageType: 'error',
        url: window.location.href,
        searchStrategy: 'all-resources',
        foundAnyResources: false,
        resources: { included: [], excluded: [], detailed: [] },
        resourceReapplication: {
          detected: false,
          used: false,
          selectedTimestamp: null
        },
        bookedAt: null
      }
    }).catch(e => console.error('[scrape.js] Failed to send error message:', e));
  });

})();
