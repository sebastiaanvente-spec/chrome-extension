 ###############################################
 
    Test:

Multiple re-bookings on 1 avail capacity check

###############################################

    New features:

Capacity Check, remaining capacity:
    1. Check if there are capacity updates
        1.1 if there are, check when those were made.
        1.2 if there are not, check what the capacity is.

     2. Subtract total customer types booked from total capacity and show remaining capacity.

Use the Option ro code thing from the extension

Copy to clipboard GYG
    1. For complete mapping file:
        NEEDS:
        Item name and ID
        rocode
        CTs mapped
        Price sheet selection
        prices
        Check min/max

        HOW:
 
        Price sheet selection:
            ?
        Prices:
            ?
        Check min/max:
            ?
            


###############################################

