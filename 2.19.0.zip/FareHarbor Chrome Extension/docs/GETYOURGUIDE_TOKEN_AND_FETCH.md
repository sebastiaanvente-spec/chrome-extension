# GetYourGuide Token Capture and Paginated Fetch

This document describes the **getyourguide_capture_and_fetch** feature: how the extension captures the GYG GraphQL auth token, stores it, and uses it to fetch all activity options with pagination.

## How token capture works

- The **background service worker** registers a `chrome.webRequest.onBeforeSendHeaders` listener for `*://supplier.getyourguide.com/graphql` with `extraInfoSpec: ["requestHeaders", "extraHeaders"]`.
- When any tab (or the page itself) sends a request to that GraphQL endpoint, the listener reads the `Authorization` and `x-gyg-supplier-id` headers and saves them to `chrome.storage.local` under the keys `gygAuthToken`, `gygSupplierId`, and `gygTokenCapturedAt` (timestamp).
- **You must open a GetYourGuide supplier product page in a browser tab while logged in** so that the site sends at least one GraphQL request. After that, the extension will have captured the token and can use it for subsequent fetches.

## Message API (for popup / content scripts)

From any extension context (popup or content script), you can send messages to the background:

| Message | Payload | Response |
|--------|---------|----------|
| `getToken` | none | `{ gygAuthToken?, gygSupplierId?, gygTokenCapturedAt? }` |
| `clearToken` | none | `{ ok: true }` |
| `startFetchAllOptions` | `{ limit?, startOffset?, maxRetries?, filters?, productIdFallback?, ... }` | `{ ok: true, results: { items, mappedById, errorsById } }` or `{ ok: false, error, partial: { count, ids } }` |

Collection is **status-agnostic**: any `status` filter in `filters` is stripped so that all options (ACTIVE, DEACTIVATED, TEMPORARY, etc.) are returned. Pagination uses only `response.data.activityOptionSearch.pagination.{ offset, limit, totalItems }`; results are deduplicated by `item.id`.

Example:

```javascript
chrome.runtime.sendMessage({ type: "getToken" }, (res) => console.log(res));

chrome.runtime.sendMessage({
  type: "startFetchAllOptions",
  payload: {
    limit: 50,
    filters: [{ field: "activity.id", values: ["840568"] }],
    productIdFallback: "840568"
  }
}, (res) => console.log(res.ok ? res.results.items.length : res.error));
```

## GetYourGuide Products V2 (Copy Mapping Data > OTA)

- **Copy 1 Product's Data (API)** and **Copy all product data (API)** first try the background path: they send `startFetchAllOptions` with filters (activity id only; no status filter). Results are `{ items, mappedById, errorsById }`; the UI builds TSV from the raw list (all statuses) and includes a Status column. Failed mappings are kept in the export with a Mapping error column when present.
- If the background has no token or the request fails, the extension **falls back** to the existing page-context fetch (injected script using the page’s token). So the flow works even when the webRequest capture has not run yet.

## Dev UI (GetYourGuide Products V2 page)

- **Copy current GYG token** — Reads token from storage and copies it to the clipboard (useful for debugging or external tools).
- **Clear token** — Removes the stored token and supplier id so the next product-page load can capture a fresh one.

## Troubleshooting

| Issue | What to do |
|-------|------------|
| No token / “No auth token found” | Open https://supplier.getyourguide.com (e.g. a product details page) in a tab while logged in. Use the site normally so it sends a GraphQL request; the extension will then capture the header. |
| 401 from GraphQL | The stored token may have expired. Refresh the supplier page (or open a product page again), then try the button again. You can also use **Clear token** and then reload a product page to force a new capture. |
| webRequest not capturing | Some environments may not expose `Authorization` via `extraHeaders`. In that case the extension still works via the **fallback**: the content script’s page-context inject captures the token when the page makes requests, and “Copy 1 Product’s Data (API)” uses that path when the background path fails. |

## Security and storage

- Tokens are stored only in `chrome.storage.local` and are not sent to any server except the GetYourGuide GraphQL endpoint when you trigger a fetch.
- Use this tool only with accounts you are authorized to access.
