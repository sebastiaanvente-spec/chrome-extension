Ideas to automate:
    1.  Check how resources/capacity was distributed at a specific date and time.
    2.  Grab values from price sheet and copy to clipboard




🔹 Safe Workflow
✅ Commit before AI edits
    git add .
    git commit -m "Checkpoint before AI edit"

🤖 Ask Cursor AI to make changes
🧪 Test your code
❌ Rollback if needed

Undo changes in one file:
    git restore <filename>

Undo all changes since last commit:
    git reset --hard HEAD


🔹 Pro Tips
Commit often → Small checkpoints are easier to roll back to.
Use descriptive messages → e.g., git commit -m "Added login button"
Check what’s staged before commit:
    git status


# 🌿 Branching Workflow

**List branches**
```bash
    git branch

Create new branch
    git branch ai-experiments

Switch to branch
    git checkout ai-experiments
    git switch ai-experiments

Back to main
    git checkout main

Merge experiments into main
    git merge ai-experiments

Delete branch after merge
    git branch -d ai-experiments