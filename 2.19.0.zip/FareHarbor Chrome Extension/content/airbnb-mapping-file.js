console.log("[airbnb-mapping-file] airbnb-mapping-file.js loaded");

// Wait for utilities to be available and initialize module
(function initializeAirbnbMappingFile() {
  // Wait for FareHarborUtils to be available
  if (!window.FareHarborUtils) {
    setTimeout(initializeAirbnbMappingFile, 10);
    return;
  }
  
  // Now utilities are available, set up the module
  const utils = window.FareHarborUtils;

  // Function to extract edit links from the page
  function extractEditLinks() {
    console.log("[airbnb-mapping-file] Extracting edit links from page...");
    
    // Find all edit links (a tags with ng-href containing "/items/" and class "test-edit-link-exposed-item")
    const editLinks = document.querySelectorAll('a.test-edit-link-exposed-item[ng-href*="/items/"], a.test-edit-link-exposed-item[href*="/items/"]');
    
    console.log(`[airbnb-mapping-file] Found ${editLinks.length} edit links`);
    
    const links = [];
    editLinks.forEach((link, index) => {
      const href = link.getAttribute('ng-href') || link.getAttribute('href') || link.href;
      if (href) {
        // Convert relative URLs to absolute
        const absoluteUrl = href.startsWith('http') ? href : `${window.location.origin}${href}`;
        links.push({
          url: absoluteUrl,
          index: index
        });
        console.log(`[airbnb-mapping-file] Edit link ${index + 1}: ${absoluteUrl}`);
      }
    });
    
    return links;
  }

  // Function to extract airbnbActivityId from Settings page
  function extractAirbnbActivityId() {
    console.log("[airbnb-mapping-file] Extracting airbnbActivityId from Settings page...");
    
    // Find the input field with name="airbnbActivityId"
    const input = document.querySelector('input[name="airbnbActivityId"]');
    
    if (input) {
      const value = input.value ? input.value.trim() : '';
      console.log(`[airbnb-mapping-file] Found airbnbActivityId: "${value}"`);
      return value;
    } else {
      console.warn("[airbnb-mapping-file] airbnbActivityId input field not found");
      return '';
    }
  }

  // Function to scrape reseller items from the page
  function scrapeAirbnbMappingFile() {
    console.log("[airbnb-mapping-file] Scraping Airbnb mapping file...");
    
    // Find the reseller items table
    const resellerTable = document.querySelector('table[ng-controller*="ResellerItemsController"]') ||
                          document.querySelector('table.reseller-items-table') ||
                          document.querySelector('table');
    
    if (!resellerTable) {
      console.warn("[airbnb-mapping-file] No reseller items table found");
      return null;
    }
    
    console.log("[airbnb-mapping-file] Found reseller items table");
    
    // Find all tbody elements with ng-repeat for reseller items
    let tbodyElements = resellerTable.querySelectorAll('tbody[ng-repeat*="resellerItem"]');
    
    // If no tbody elements found with the specific ng-repeat, try more generic selectors
    if (tbodyElements.length === 0) {
      console.log("[airbnb-mapping-file] No tbody with ng-repeat found, trying alternative selectors...");
      
      // Try other possible tbody selectors
      const tbodySelectors = [
        'tbody[ng-repeat*="resellerItem"]',
        'tbody[ng-repeat]',
        'tbody'
      ];
      
      for (const selector of tbodySelectors) {
        tbodyElements = resellerTable.querySelectorAll(selector);
        if (tbodyElements.length > 0) {
          console.log(`[airbnb-mapping-file] Found ${tbodyElements.length} tbody elements using selector: "${selector}"`);
          break;
        }
      }
    }
    
    if (tbodyElements.length === 0) {
      console.warn("[airbnb-mapping-file] No tbody elements found in the table");
      return null;
    }
    
    console.log(`[airbnb-mapping-file] Found ${tbodyElements.length} reseller items`);
    
    const result = [];
    
    // Process each reseller item
    tbodyElements.forEach((tbody, index) => {
      console.log(`[airbnb-mapping-file] Processing reseller item ${index + 1}...`);
      
      try {
        // Extract the leading number from the first column (td:first-child)
        const firstColumn = tbody.querySelector('td:first-child');
        let leadingNumber = '';
        
        if (firstColumn) {
          const firstColumnText = firstColumn.textContent.trim();
          // Extract the number at the start (e.g., "6771471" from "6771471 Barcelona Gothic Quarter...")
          const match = firstColumnText.match(/^(\d+)\s+/);
          if (match) {
            leadingNumber = match[1];
            console.log(`[airbnb-mapping-file] Item ${index + 1} - Found leading number: "${leadingNumber}"`);
          } else {
            console.warn(`[airbnb-mapping-file] Item ${index + 1} - Could not extract leading number from: "${firstColumnText}"`);
          }
        } else {
          console.warn(`[airbnb-mapping-file] Item ${index + 1} - First column not found`);
        }
        
        // Extract all item links from the 4th column (td:nth-child(4) or td.prose.prose--compact)
        let itemLinksContainer = tbody.querySelector('td:nth-child(4)');
        if (!itemLinksContainer) {
          itemLinksContainer = tbody.querySelector('td.prose.prose--compact');
        }
        if (!itemLinksContainer) {
          // Try to find any td with links
          itemLinksContainer = tbody.querySelector('td');
        }
        
        if (!itemLinksContainer) {
          console.warn(`[airbnb-mapping-file] Item ${index + 1} - Item links container not found`);
          return;
        }
        
        // Find all item links (a tags with ng-href or href)
        const itemLinks = itemLinksContainer.querySelectorAll('a[ng-href], a[href]');
        
        if (itemLinks.length === 0) {
          console.warn(`[airbnb-mapping-file] Item ${index + 1} - No item links found`);
          return;
        }
        
        console.log(`[airbnb-mapping-file] Item ${index + 1} - Found ${itemLinks.length} item links`);
        
        // Find the edit link for this row
        // The edit link is in a <td class="show-links"> inside a <tr> inside the <tbody>
        // The class starts with "test-edit-link-exposed-item" (may have additional classes)
        // Try multiple selectors to find it
        let editLink = null;
        
        // First, try finding it within the tbody (should work since tbody contains the tr)
        editLink = tbody.querySelector('a[class*="test-edit-link-exposed-item"][ng-href*="/items/"], a[class*="test-edit-link-exposed-item"][href*="/items/"]');
        
        // If not found, try looking in td.show-links
        if (!editLink) {
          const showLinksTd = tbody.querySelector('td.show-links');
          if (showLinksTd) {
            editLink = showLinksTd.querySelector('a[class*="test-edit-link-exposed-item"][ng-href*="/items/"], a[class*="test-edit-link-exposed-item"][href*="/items/"]');
          }
        }
        
        // If still not found, try finding any link with the class pattern in the tbody
        if (!editLink) {
          const allLinks = tbody.querySelectorAll('a[class*="test-edit-link-exposed-item"]');
          for (const link of allLinks) {
            const href = link.getAttribute('ng-href') || link.getAttribute('href') || link.href;
            if (href && href.includes('/items/')) {
              editLink = link;
              break;
            }
          }
        }
        
        let editLinkUrl = null;
        if (editLink) {
          const href = editLink.getAttribute('ng-href') || editLink.getAttribute('href') || editLink.href;
          // Handle relative URLs - ensure they start with / or are absolute
          if (href) {
            if (href.startsWith('http://') || href.startsWith('https://')) {
              editLinkUrl = href;
            } else if (href.startsWith('/')) {
              editLinkUrl = `${window.location.origin}${href}`;
            } else {
              // Relative path without leading slash
              editLinkUrl = `${window.location.origin}/${href}`;
            }
            console.log(`[airbnb-mapping-file] Item ${index + 1} - Found edit link: ${editLinkUrl}`);
          }
        } else {
          console.warn(`[airbnb-mapping-file] Item ${index + 1} - Edit link not found`);
          // Debug: log what we can find
          const allLinksInTbody = tbody.querySelectorAll('a');
          console.log(`[airbnb-mapping-file] Item ${index + 1} - Found ${allLinksInTbody.length} total links in tbody`);
          allLinksInTbody.forEach((link, i) => {
            const linkHref = link.getAttribute('ng-href') || link.getAttribute('href') || link.href;
            const linkClass = link.getAttribute('class') || '';
            console.log(`[airbnb-mapping-file] Item ${index + 1} - Link ${i + 1}: class="${linkClass}", href="${linkHref}"`);
          });
        }
        
        // Create a row for each item link
        itemLinks.forEach((itemLink, linkIndex) => {
          // Extract Item ID (from text content of the link)
          const itemId = itemLink.textContent.trim();
          
          // Extract Item Name (from aria-label or ng-tip)
          let itemName = '';
          const ariaLabel = itemLink.getAttribute('aria-label');
          if (ariaLabel) {
            // Remove the ID part from aria-label (e.g., "Name (123)" -> "Name")
            itemName = ariaLabel.replace(/\s*\(\d+\)$/, '').trim();
          } else {
            const ngTip = itemLink.getAttribute('ng-tip');
            if (ngTip) {
              itemName = ngTip.trim();
            } else {
              // Fallback to text content if no aria-label or ng-tip
              itemName = itemId;
            }
          }
          
          console.log(`[airbnb-mapping-file] Item ${index + 1}, Link ${linkIndex + 1} - Item ID: "${itemId}", Item Name: "${itemName}"`);
          
          // Create a row for this item
          result.push({
            itemId: itemId,
            itemName: itemName,
            leadingNumber: leadingNumber,
            editLinkUrl: editLinkUrl // Store edit link URL for Detailed mode
          });
        });
        
      } catch (error) {
        console.error(`[airbnb-mapping-file] Error processing reseller item ${index + 1}:`, error);
      }
    });
    
    if (result.length === 0) {
      console.warn("[airbnb-mapping-file] No data extracted.");
      return null;
    }
    
    console.log(`[airbnb-mapping-file] Successfully extracted ${result.length} rows`);
    return result;
  }

  function formatAsHTML(data) {
    if (!data || data.length === 0) {
      return '';
    }
    
    let html = '<table border="1" cellpadding="5" cellspacing="0">\n';
    html += '<tbody>\n';
    
    data.forEach(item => {
      html += '<tr>\n';
      html += `<td><strong>${escapeHtmlField(item.itemId)}</strong></td>\n`;
      html += `<td>${escapeHtmlField(item.itemName)}</td>\n`;
      html += `<td>${escapeHtmlField(item.leadingNumber)}</td>\n`;
      html += '</tr>\n';
    });
    
    html += '</tbody>\n';
    html += '</table>';
    
    return html;
  }
  
  function escapeHtmlField(field) {
    if (!field) return '';
    
    const str = String(field).trim();
    
    const escaped = str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
    
    return escaped.replace(/\n/g, '<br>');
  }

  // Format data as TSV (tab-separated values)
  function formatAsTSV(data) {
    if (!data || data.length === 0) {
      return '';
    }
    
    const tsvLines = [];
    
    data.forEach(item => {
      const row = [
        escapeTsvField(item.itemId || ''),
        escapeTsvField(item.itemName || ''),
        escapeTsvField(item.leadingNumber || '')
      ];
      tsvLines.push(row.join('\t'));
    });
    
    return tsvLines.join('\n');
  }

  function escapeTsvField(field) {
    if (!field) return '';
    
    const str = String(field).trim();
    
    return str.replace(/[\t\n\r]/g, ' ');
  }

  // Function to extract airbnbActivityId from a Settings page URL
  async function extractAirbnbActivityIdFromUrl(editUrl) {
    return new Promise((resolve) => {
      console.log(`[airbnb-mapping-file] Extracting airbnbActivityId from edit URL: ${editUrl}`);
      
      // Send message to background script to open tab, click Settings, and extract data
      chrome.runtime.sendMessage({
        action: 'extractAirbnbActivityId',
        url: editUrl
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.error(`[airbnb-mapping-file] Error extracting airbnbActivityId:`, chrome.runtime.lastError);
          resolve(''); // Return empty string on error
        } else if (response && response.success) {
          console.log(`[airbnb-mapping-file] Successfully extracted airbnbActivityId: "${response.airbnbActivityId}"`);
          resolve(response.airbnbActivityId || '');
        } else {
          console.warn(`[airbnb-mapping-file] Failed to extract airbnbActivityId:`, response?.error);
          resolve(''); // Return empty string on failure
        }
      });
    });
  }

  // Message handling for Airbnb Mapping File actions
  function handleMessage(req, sender, sendResponse) {
    console.log("[airbnb-mapping-file] Message received:", req);

    if (req.action === "runAirbnbMappingFileExtract") {
      // Handle asynchronously for Detailed mode
      (async () => {
        try {
          // Get the useDetailed flag (defaults to false for Simple mode)
          const useDetailed = req.useDetailed || false;
          console.log("[airbnb-mapping-file] Extraction mode:", useDetailed ? "Detailed" : "Simple");
          
          // Scrape the initial data
          const data = scrapeAirbnbMappingFile();
          
          if (!data || data.length === 0) {
            sendResponse({ 
              success: false, 
              error: "No Airbnb mapping data found on this page. Make sure you're on the Airbnb reseller items page." 
            });
            return;
          }
          
          // If Detailed mode, extract airbnbActivityId for each row
          if (useDetailed) {
            console.log(`[airbnb-mapping-file] Detailed mode: Extracting airbnbActivityId for ${data.length} items...`);
            
            // Process items sequentially to avoid overwhelming the browser
            for (let i = 0; i < data.length; i++) {
              const item = data[i];
              if (item.editLinkUrl) {
                console.log(`[airbnb-mapping-file] Processing item ${i + 1}/${data.length}...`);
                const airbnbActivityId = await extractAirbnbActivityIdFromUrl(item.editLinkUrl);
                // Replace leadingNumber with airbnbActivityId in Detailed mode
                item.leadingNumber = airbnbActivityId;
                // Small delay between requests to avoid overwhelming the server
                await new Promise(resolve => setTimeout(resolve, 500));
              } else {
                console.warn(`[airbnb-mapping-file] Item ${i + 1} has no edit link URL`);
                item.leadingNumber = ''; // Set empty if no edit link
              }
            }
            
            console.log(`[airbnb-mapping-file] Detailed mode extraction complete`);
          }
          
          const htmlData = formatAsHTML(data);
          const tsvData = formatAsTSV(data);
          
          sendResponse({ 
            success: true, 
            data: data,
            htmlData: htmlData,
            tsvData: tsvData,
            count: data.length
          });
          
        } catch (error) {
          console.error("[airbnb-mapping-file] Error during scraping:", error);
          sendResponse({ 
            success: false, 
            error: "An error occurred while scraping Airbnb mapping data: " + error.message 
          });
        }
      })();
      
      return true; // Keep channel open for async response
    }

    // Handle extraction of airbnbActivityId from Settings page
    if (req.action === "extractAirbnbActivityIdFromPage") {
      const airbnbActivityId = extractAirbnbActivityId();
      sendResponse({
        success: true,
        airbnbActivityId: airbnbActivityId
      });
      return true;
    }

    return false; // Not handled by this module
  }

  // Export the module
  window.AirbnbMappingFile = {
    handleMessage,
    scrapeAirbnbMappingFile,
    formatAsHTML,
    formatAsTSV,
    extractAirbnbActivityId,
    extractEditLinks
  };

  console.log("[airbnb-mapping-file] Module initialized successfully");

})(); // End of initialization function



