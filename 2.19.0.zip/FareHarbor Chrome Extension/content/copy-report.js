console.log("[copy-report] copy-report.js loaded");

// Initialize module immediately
(function initializeCopyReport() {

  // Function to extract text from a cell, preserving links
  function extractCellContent(cell) {
    if (!cell) return { text: '', html: '', hyperlink: null };
    
    // Clone the cell to avoid modifying the original
    const clonedCell = cell.cloneNode(true);
    
    // Extract plain text
    const text = clonedCell.textContent.trim() || clonedCell.innerText.trim();
    
    // Check for links
    const links = clonedCell.querySelectorAll('a');
    let hyperlink = null;
    
    if (links.length > 0) {
      // Get the first link (most cells will have at most one link)
      const link = links[0];
      const linkText = link.textContent.trim() || link.innerText.trim();
      let href = link.getAttribute('href') || link.getAttribute('ng-href') || '';
      
      // Make href absolute if it's relative
      if (href && href.startsWith('/')) {
        href = window.location.origin + href;
      }
      
      if (href && linkText) {
        hyperlink = { url: href, text: linkText };
      }
    }
    
    // Extract HTML with links preserved
    let html = '';
    if (links.length > 0) {
      // Has links - preserve them
      links.forEach(link => {
        const linkText = link.textContent.trim() || link.innerText.trim();
        const href = link.getAttribute('href') || link.getAttribute('ng-href') || '';
        
        // Make href absolute if it's relative
        let absoluteHref = href;
        if (href && href.startsWith('/')) {
          absoluteHref = window.location.origin + href;
        }
        
        // Replace the link in the cloned cell with a properly formatted link
        const newLink = document.createElement('a');
        newLink.href = absoluteHref || '#';
        newLink.textContent = linkText;
        link.replaceWith(newLink);
      });
      
      html = clonedCell.innerHTML;
    } else {
      // No links - just escape the text
      html = escapeHtmlField(text);
    }
    
    return { text, html, hyperlink };
  }

  // Function to extract table data
  function scrapeReportTable() {
    console.log("[copy-report] Scraping report table...");
    
    // Find the report table - try multiple selectors
    let table = document.querySelector('table.spreadsheet.width-auto.highlight-rows.spreadsheet--nowrap.no-margin.sticky-headers--reports.ng-scope');
    
    // Fallback to less specific selector
    if (!table) {
      table = document.querySelector('table.sticky-headers--reports');
    }
    
    // Fallback to any table with spreadsheet class
    if (!table) {
      table = document.querySelector('table.spreadsheet');
    }
    
    if (!table) {
      console.warn("[copy-report] No report table found");
      return null;
    }
    
    console.log("[copy-report] Found report table");
    
    const result = {
      headers: [],
      rows: [],
      footer: []
    };
    
    // Extract headers from thead
    const thead = table.querySelector('thead');
    if (thead) {
      // Get header rows
      const headerRows = thead.querySelectorAll('tr');
      headerRows.forEach(headerRow => {
        const headerCells = [];
        // Get all cells including grouping columns and booking columns
        const cells = headerRow.querySelectorAll('th, td');
        
        cells.forEach(cell => {
          // Skip cells with ng-auto-export-skip
          if (cell.hasAttribute('ng-auto-export-skip')) {
            return;
          }
          
          const colspan = parseInt(cell.getAttribute('colspan') || '1', 10);
          const cellContent = extractCellContent(cell);
          
          // Handle colspan - store the colspan value
          headerCells.push({
            content: cellContent,
            colspan: colspan
          });
        });
        
        if (headerCells.length > 0) {
          result.headers.push(headerCells);
        }
      });
    }
    
    // Extract data rows from tbody
    // Look for actual data rows - they have ng-repeat="object in objectTable.collection"
    const dataRows = table.querySelectorAll('tbody tr[ng-repeat="object in objectTable.collection"]');
    
    if (dataRows.length > 0) {
      // Process the actual data rows
      dataRows.forEach(row => {
        const rowCells = [];
        
        // First, get grouping columns (ng-repeat="grouping in report.data.groupings")
        const groupingCells = row.querySelectorAll('td[ng-repeat="grouping in report.data.groupings"]');
        groupingCells.forEach(cell => {
          const cellContent = extractCellContent(cell);
          rowCells.push(cellContent);
        });
        
        // Then, get all cells with ng-advanced-show-column attribute, in order
        const bookingCells = row.querySelectorAll('td[ng-advanced-show-column]');
        bookingCells.forEach(cell => {
          // Skip cells with ng-auto-export-skip
          if (cell.hasAttribute('ng-auto-export-skip')) {
            return;
          }
          const cellContent = extractCellContent(cell);
          rowCells.push(cellContent);
        });
        
        // Only add rows that have actual content
        if (rowCells.length > 0) {
          result.rows.push(rowCells);
        }
      });
    } else {
      // Fallback: try to find any tbody rows that aren't skipped
      const tbodyElements = table.querySelectorAll('tbody');
      tbodyElements.forEach(tbody => {
        // Skip tbody elements that are part of ng-repeat-end (empty separators)
        if (tbody.querySelector('tr[ng-auto-export-skip]')) {
          return;
        }
        
        // Get rows that are not skipped and have actual data cells
        const rows = tbody.querySelectorAll('tr:not([ng-auto-export-skip]):not([ng-repeat-start]):not([ng-repeat-end])');
        rows.forEach(row => {
          // Skip rows that are just separators (only have one cell with colspan="100")
          const cells = row.querySelectorAll('td');
          if (cells.length === 1 && cells[0].getAttribute('colspan') === '100') {
            return;
          }
          
          const rowCells = [];
          cells.forEach(cell => {
            // Skip cells with ng-auto-export-skip
            if (cell.hasAttribute('ng-auto-export-skip')) {
              return;
            }
            const cellContent = extractCellContent(cell);
            rowCells.push(cellContent);
          });
          
          // Only add rows that have actual content
          if (rowCells.length > 0 && rowCells.some(cell => cell.text.trim() !== '')) {
            result.rows.push(rowCells);
          }
        });
      });
    }
    
    // Extract footer from tfoot
    const tfoot = table.querySelector('tfoot');
    if (tfoot) {
      const footerRows = tfoot.querySelectorAll('tr:not([ng-auto-export-skip])');
      footerRows.forEach(footerRow => {
        // Skip rows that are just timezone disclaimers
        if (footerRow.querySelector('td[colspan="100"]')) {
          return;
        }
        
        const footerCells = [];
        
        // First, get grouping columns (ng-repeat="grouping in report.data.groupings")
        const groupingCells = footerRow.querySelectorAll('td[ng-repeat="grouping in report.data.groupings"]');
        groupingCells.forEach(cell => {
          const cellContent = extractCellContent(cell);
          footerCells.push(cellContent);
        });
        
        // Then, get cells with ng-advanced-show-column attribute
        const bookingCells = footerRow.querySelectorAll('td[ng-advanced-show-column]');
        bookingCells.forEach(cell => {
          const cellContent = extractCellContent(cell);
          footerCells.push(cellContent);
        });
        
        if (footerCells.length > 0) {
          result.footer.push(footerCells);
        }
      });
    }
    
    if (result.rows.length === 0 && result.headers.length === 0) {
      console.warn("[copy-report] No data extracted from table");
      return null;
    }
    
    console.log(`[copy-report] Successfully extracted ${result.headers.length} header row(s), ${result.rows.length} data row(s), ${result.footer.length} footer row(s)`);
    return result;
  }

  function escapeHtmlField(field) {
    if (!field) return '';
    
    const str = String(field).trim();
    
    const escaped = str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
    
    return escaped;
  }

  // Format data as HTML (for Zendesk)
  function formatAsHTML(data) {
    if (!data || (!data.headers.length && !data.rows.length)) {
      return '';
    }
    
    let html = '<table border="1" cellpadding="5" cellspacing="0">\n';
    
    // Add headers
    if (data.headers.length > 0) {
      html += '<thead>\n';
      data.headers.forEach(headerRow => {
        html += '<tr>\n';
        headerRow.forEach(headerCell => {
          const colspan = headerCell.colspan > 1 ? ` colspan="${headerCell.colspan}"` : '';
          const cellHtml = headerCell.content.html || escapeHtmlField(headerCell.content.text);
          html += `<th${colspan}>${cellHtml}</th>\n`;
        });
        html += '</tr>\n';
      });
      html += '</thead>\n';
    }
    
    // Add body rows
    if (data.rows.length > 0) {
      html += '<tbody>\n';
      data.rows.forEach(row => {
        html += '<tr>\n';
        row.forEach(cell => {
          const cellHtml = cell.html || escapeHtmlField(cell.text);
          html += `<td>${cellHtml}</td>\n`;
        });
        html += '</tr>\n';
      });
      html += '</tbody>\n';
    }
    
    // Add footer
    if (data.footer.length > 0) {
      html += '<tfoot>\n';
      data.footer.forEach(footerRow => {
        html += '<tr>\n';
        footerRow.forEach(cell => {
          const cellHtml = cell.html || escapeHtmlField(cell.text);
          html += `<td>${cellHtml}</td>\n`;
        });
        html += '</tr>\n';
      });
      html += '</tfoot>\n';
    }
    
    html += '</table>';
    
    return html;
  }

  // Format data as TSV (for Sheets)
  function formatAsTSV(data) {
    if (!data || (!data.headers.length && !data.rows.length)) {
      return '';
    }
    
    const tsvLines = [];
    
    // First, determine the maximum number of columns by looking at all rows
    let maxColumns = 0;
    
    // Check header rows for max columns - count colspan properly
    data.headers.forEach(headerRow => {
      let colCount = 0;
      headerRow.forEach(headerCell => {
        colCount += headerCell.colspan || 1;
      });
      maxColumns = Math.max(maxColumns, colCount);
    });
    
    // Check data rows for max columns
    data.rows.forEach(row => {
      maxColumns = Math.max(maxColumns, row.length);
    });
    
    // Check footer rows for max columns
    data.footer.forEach(footerRow => {
      maxColumns = Math.max(maxColumns, footerRow.length);
    });
    
    // Add headers - handle colspan correctly
    if (data.headers.length > 0) {
      data.headers.forEach(headerRow => {
        const headerCells = [];
        headerRow.forEach(headerCell => {
          const text = escapeTsvField(headerCell.content.text);
          const colspan = headerCell.colspan || 1;
          
          // For TSV, put the text in the first column, then empty cells for the rest
          headerCells.push(text);
          for (let i = 1; i < colspan; i++) {
            headerCells.push('');
          }
        });
        // Pad to maxColumns if needed
        while (headerCells.length < maxColumns) {
          headerCells.push('');
        }
        // Trim to maxColumns in case we went over
        headerCells.splice(maxColumns);
        if (headerCells.length > 0) {
          tsvLines.push(headerCells.join('\t'));
        }
      });
    }
    
    // Add data rows
    data.rows.forEach(row => {
      const rowCells = row.map(cell => {
        // If cell has a hyperlink, format it as HYPERLINK formula
        if (cell.hyperlink && cell.hyperlink.url && cell.hyperlink.text) {
          // Escape quotes in URL and text for the formula
          const escapedUrl = cell.hyperlink.url.replace(/"/g, '""');
          const escapedText = cell.hyperlink.text.replace(/"/g, '""');
          return `=HYPERLINK("${escapedUrl}", "${escapedText}")`;
        }
        
        // Get the text value
        const cellText = escapeTsvField(cell.text);
        
        // If it's a pure number, prefix with apostrophe to prevent auto-formatting
        if (isPureNumber(cellText)) {
          return `'${cellText}`;
        }
        
        // Otherwise, just use the text
        return cellText;
      });
      // Pad to maxColumns if needed
      while (rowCells.length < maxColumns) {
        rowCells.push('');
      }
      // Trim to maxColumns in case we went over
      rowCells.splice(maxColumns);
      tsvLines.push(rowCells.join('\t'));
    });
    
    // Add footer
    data.footer.forEach(footerRow => {
      const footerCells = footerRow.map(cell => {
        // If cell has a hyperlink, format it as HYPERLINK formula
        if (cell.hyperlink && cell.hyperlink.url && cell.hyperlink.text) {
          // Escape quotes in URL and text for the formula
          const escapedUrl = cell.hyperlink.url.replace(/"/g, '""');
          const escapedText = cell.hyperlink.text.replace(/"/g, '""');
          return `=HYPERLINK("${escapedUrl}", "${escapedText}")`;
        }
        
        // Get the text value
        const cellText = escapeTsvField(cell.text);
        
        // If it's a pure number, prefix with apostrophe to prevent auto-formatting
        if (isPureNumber(cellText)) {
          return `'${cellText}`;
        }
        
        // Otherwise, just use the text
        return cellText;
      });
      // Pad to maxColumns if needed
      while (footerCells.length < maxColumns) {
        footerCells.push('');
      }
      // Trim to maxColumns in case we went over
      footerCells.splice(maxColumns);
      tsvLines.push(footerCells.join('\t'));
    });
    
    return tsvLines.join('\n');
  }

  function escapeTsvField(field) {
    if (!field) return '';
    
    const str = String(field).trim();
    
    // Replace tabs, newlines, and carriage returns with spaces
    return str.replace(/[\t\n\r]/g, ' ');
  }

  // Function to check if a string is a pure number (no currency, dates, etc.)
  function isPureNumber(str) {
    if (!str || typeof str !== 'string') return false;
    
    const trimmed = str.trim();
    if (trimmed === '') return false;
    
    // Check for currency symbols
    if (/[€$£¥₹]/.test(trimmed)) return false;
    
    // Check for date-like patterns (slashes, dashes, colons in date context)
    if (/^\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}/.test(trimmed)) return false; // Dates like 12/18/25
    if (/^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}/.test(trimmed)) return false; // Dates like 2025-12-18
    
    // Check for time patterns
    if (/^\d{1,2}:\d{2}(\s*(AM|PM|am|pm))?$/.test(trimmed)) return false;
    
    // Check if it's a pure number (digits, optional decimal point, optional negative sign)
    // Allow for numbers like: 123, 123.45, -123, -123.45
    const pureNumberRegex = /^-?\d+(\.\d+)?$/;
    
    return pureNumberRegex.test(trimmed);
  }

  // Message handling for Copy Report actions
  function handleMessage(req, sender, sendResponse) {
    console.log("[copy-report] Message received:", req);

    if (req.action === "runCopyReportExtract") {
      try {
        const data = scrapeReportTable();
        
        if (!data || (!data.headers.length && !data.rows.length)) {
          sendResponse({ 
            success: false, 
            error: "No report table found on this page. Make sure you're on a FareHarbor report page." 
          });
          return true;
        }
        
        const htmlData = formatAsHTML(data);
        const tsvData = formatAsTSV(data);
        
        sendResponse({ 
          success: true, 
          data: data,
          htmlData: htmlData,
          tsvData: tsvData,
          rowCount: data.rows.length
        });
        
      } catch (error) {
        console.error("[copy-report] Error during scraping:", error);
        sendResponse({ 
          success: false, 
          error: "An error occurred while scraping report data: " + error.message 
        });
      }
      
      return true;
    }

    return false; // Not handled by this module
  }

  // Export the module
  window.CopyReport = {
    handleMessage,
    scrapeReportTable,
    formatAsHTML,
    formatAsTSV
  };

  console.log("[copy-report] Module initialized successfully");

})(); // End of initialization function

