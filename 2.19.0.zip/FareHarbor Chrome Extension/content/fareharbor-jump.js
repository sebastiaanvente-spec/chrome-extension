console.log("[fareharbor-jump] fareharbor-jump.js loaded on URL:", window.location.href);

// Initialize module immediately (no dependencies needed)
(function initializeFareHarborJump() {
  console.log("[fareharbor-jump] Initializing FareHarbor Jump...");

  // Jump type mappings to match the original admin jump functionality
  const JUMP_TYPE_MAPPINGS = {
    'company': 'string:Company',
    'item': 'string:Item', 
    'booking': 'string:Booking',
    'channel-company': 'string:ResellerCompany',
    'channel-item': 'string:ResellerItem',
    'channel-option': 'string:ResellerOption'
  };


  // Helper function to process search text for channel options
  function processSearchText(jumpType, searchText) {
    // For channel options, strip any letter prefix and keep only numbers
    const channelTypes = ['channel-company', 'channel-item', 'channel-option'];
    
    if (channelTypes.includes(jumpType)) {
      // Remove any letters from the beginning and keep only numbers
      const numbersOnly = searchText.replace(/^[a-zA-Z]+/, '');
      if (numbersOnly !== searchText) {
        console.log(`[fareharbor-jump] Processed channel text: "${searchText}" → "${numbersOnly}"`);
      }
      return numbersOnly;
    }
    
    return searchText; // Return unchanged for non-channel types
  }

  // Alternative approach: Try to use the existing admin jump functionality if available (expects already processed searchText)
  function performJumpViaExistingSystem(jumpType, searchText) {
    console.log(`[fareharbor-jump] Attempting to use existing admin jump system for ${jumpType}: ${searchText}`);
    
    return new Promise((resolve) => {
      // Function to check for elements and attempt jump
      function attemptJump(retryCount = 0) {
        try {
          console.log(`[fareharbor-jump] Attempt ${retryCount}: Checking for jump elements...`);
          
          // First, check for jump elements immediately
          const hasJumpElements = document.querySelector('.admin-jump-menu') || 
                                 document.querySelector('nav[aria-label="Jump to..."]') ||
                                 document.querySelector('select[ng-model="jump.objectType"]');
          
          if (hasJumpElements) {
            console.log(`[fareharbor-jump] Jump elements found! Angular available: ${!!window.angular}`);
            
            // If elements are present, try non-Angular approach immediately
            console.log(`[fareharbor-jump] Elements detected, using non-Angular approach immediately...`);
            attemptNonAngularJump(jumpType, searchText).then(resolve);
            return;
          }
          
          // If no elements found yet, check document state and retry
          console.log(`[fareharbor-jump] No jump elements found yet. Document ready state: ${document.readyState}`);
          console.log(`[fareharbor-jump] Current URL: ${window.location.href}`);
          console.log(`[fareharbor-jump] Page title: ${document.title}`);
          
          if (retryCount < 20) { // Reduced max retries since we're checking more frequently
            setTimeout(() => attemptJump(retryCount + 1), 250); // Check every 250ms for faster response
            return;
          } else {
            console.error(`[fareharbor-jump] No jump elements found after ${retryCount} attempts`);
            console.log(`[fareharbor-jump] Final page analysis:`);
            console.log(`  - All .admin-jump-menu elements:`, document.querySelectorAll('.admin-jump-menu'));
            console.log(`  - All nav elements:`, document.querySelectorAll('nav'));
            console.log(`  - All select elements:`, document.querySelectorAll('select'));
            console.log(`  - Page content includes "jump":`, document.documentElement.innerHTML.toLowerCase().includes('jump'));
            resolve(false);
            return;
          }
        } catch (error) {
          console.error(`[fareharbor-jump] Error in attemptJump:`, error);
          resolve(false);
        }
      }
      
      // Start the attempt immediately
      attemptJump();
    });
  }

  // Fallback function to attempt jump without Angular (expects already processed searchText)
  function attemptNonAngularJump(jumpType, searchText) {
    console.log(`[fareharbor-jump] Attempting non-Angular jump for ${jumpType}: ${searchText}`);
    
    return new Promise((resolve) => {
      try {
        const mappedType = JUMP_TYPE_MAPPINGS[jumpType];
        
        // Try to find and manipulate jump elements directly
        const jumpSelect = document.querySelector('select[ng-model="jump.objectType"]') ||
                          document.querySelector('.admin-jump-menu select') ||
                          document.querySelector('nav.admin-jump-menu select');
        
        if (jumpSelect) {
          console.log(`[fareharbor-jump] Found jump select element, setting value to: ${mappedType}`);
          
          // Set the value directly
          jumpSelect.value = mappedType;
          
          // Trigger change events
          jumpSelect.dispatchEvent(new Event('change', { bubbles: true }));
          jumpSelect.dispatchEvent(new Event('input', { bubbles: true }));
          
          // Check for input field immediately and with polling
          function checkForInputField(attempt = 0) {
            let objectIdInput = document.querySelector('input[ng-model="jump.objectId"]') ||
                               document.querySelector('.admin-jump-menu input[type="text"]') ||
                               document.querySelector('.admin-jump-menu input:not([type])');
            
            if (objectIdInput) {
              console.log(`[fareharbor-jump] Found input field on attempt ${attempt + 1}, setting value to: ${searchText}`);
              
              objectIdInput.value = searchText;
              objectIdInput.dispatchEvent(new Event('input', { bubbles: true }));
              objectIdInput.dispatchEvent(new Event('change', { bubbles: true }));
              
              // Try to submit immediately
              const submitBtn = document.querySelector('.admin-jump-menu button[type="submit"]') ||
                               document.querySelector('.admin-jump-menu button');
              
              if (submitBtn) {
                console.log(`[fareharbor-jump] Clicking submit button`);
                submitBtn.click();
                resolve(true);
              } else {
                // Try pressing Enter on the input
                console.log(`[fareharbor-jump] Simulating Enter key`);
                objectIdInput.dispatchEvent(new KeyboardEvent('keydown', {
                  key: 'Enter',
                  keyCode: 13,
                  which: 13,
                  bubbles: true
                }));
                resolve(true);
              }
            } else if (attempt < 10) { // Check up to 10 times
              setTimeout(() => checkForInputField(attempt + 1), 100); // Check every 100ms
            } else {
              console.error(`[fareharbor-jump] Could not find input field for object ID after ${attempt + 1} attempts`);
              resolve(false);
            }
          }
          
          // Start checking immediately
          checkForInputField();
        } else {
          console.error(`[fareharbor-jump] Could not find jump select element`);
          resolve(false);
        }
      } catch (error) {
        console.error(`[fareharbor-jump] Error in non-Angular jump:`, error);
        resolve(false);
      }
    });
  }

  // Message handling for FareHarbor Jump actions
  function handleMessage(req, sender, sendResponse) {
    console.log("[fareharbor-jump] Message received:", req);
    console.log("[fareharbor-jump] Current URL:", window.location.href);
    console.log("[fareharbor-jump] Angular available:", !!window.angular);

    if (req.action === "performFareHarborJump") {
      const { jumpType, searchText } = req;
      
      if (!jumpType || !searchText) {
        console.error("[fareharbor-jump] Missing jumpType or searchText");
        sendResponse({ success: false, error: "Missing jumpType or searchText" });
        return true;
      }

      // Process search text for channel options
      const processedSearchText = processSearchText(jumpType, searchText);
      console.log(`[fareharbor-jump] Processing jump: ${jumpType} for "${processedSearchText}"`);

      try {
        // performJumpViaExistingSystem now returns a Promise
        performJumpViaExistingSystem(jumpType, processedSearchText).then((success) => {
          console.log(`[fareharbor-jump] Jump completed with success: ${success}`);
          sendResponse({ success: success });
        }).catch((error) => {
          console.error("[fareharbor-jump] Error during jump:", error);
          sendResponse({ success: false, error: error.message });
        });
      } catch (error) {
        console.error("[fareharbor-jump] Error during jump:", error);
        sendResponse({ success: false, error: error.message });
      }
      
      return true;
    }

    return false; // Not handled by this module
  }

  // Export the module
  window.FareHarborJump = {
    handleMessage,
    performJumpViaExistingSystem
  };

  console.log("[fareharbor-jump] Module initialized successfully");

})(); // End of initialization function
