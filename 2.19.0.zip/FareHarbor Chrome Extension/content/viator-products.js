console.log("[viator-products] viator-products.js loaded");

// Wait for utilities to be available and initialize module
(function initializeViatorProducts() {
  // Viator Products data extraction function
  function scrapeViatorProducts() {
    const result = [];
    
    console.log("[viator-products] Scraping Viator products...");
    
    // Find the Product Code
    // Look for span containing "Product code:"
    const productCodeElement = Array.from(document.querySelectorAll('span')).find(
      span => span.textContent.includes('Product code:')
    );
    
    let productCode = '';
    if (productCodeElement) {
      const text = productCodeElement.textContent.trim();
      // Extract the code after "Product code:"
      const match = text.match(/Product code:\s*([^\s]+)/);
      if (match) {
        productCode = match[1];
        console.log(`[viator-products] Found Product Code: ${productCode}`);
      }
    }
    
    if (!productCode) {
      console.warn("[viator-products] Product Code not found");
      return null;
    }
    
    // Find all TabSection elements (each represents a product option)
    const tabSections = document.querySelectorAll('div[data-automation^="product-connection-edit-"]');
    console.log(`[viator-products] Found ${tabSections.length} TabSection elements`);
    
    if (tabSections.length === 0) {
      console.warn("[viator-products] No TabSection elements found");
      return null;
    }
    
    // Track seen TabSection automation IDs to prevent duplicates (each TabSection has unique data-automation)
    const seenTabSections = new Set();
    
    // Extract data from each TabSection element
    tabSections.forEach((tabSection, index) => {
      // Get unique identifier for this TabSection
      const automationId = tabSection.getAttribute('data-automation');
      if (!automationId) {
        console.warn(`[viator-products] TabSection ${index + 1} has no data-automation attribute, skipping`);
        return;
      }
      
      // Skip if we've already processed this TabSection
      if (seenTabSections.has(automationId)) {
        console.warn(`[viator-products] Skipped duplicate TabSection ${index + 1} with automation ID=${automationId}`);
        return;
      }
      seenTabSections.add(automationId);
      
      let productName = '';
      let supplierProductCode = '';
      let supplierOptionCode = '';
      let status = '';
      
      // Extract Product name from TabSection__tabSectionTitle
      // Use attribute selector to handle CSS module class names with dynamic suffixes
      const titleElement = tabSection.querySelector('[class*="TabSection__tabSectionTitle"]');
      if (titleElement) {
        // Get all text content including the tour grade code
        productName = titleElement.textContent.trim();
        console.log(`[viator-products] Found Product Name: ${productName}`);
      }
      
      // Extract Supplier product code, Supplier option code, and Status from LabelAndValue elements
      // Use attribute selectors to handle CSS module class names with dynamic suffixes
      const labelValueContainers = tabSection.querySelectorAll('[class*="LabelAndValue__labelAndValueContainer"]');
      
      labelValueContainers.forEach(container => {
        const labelElement = container.querySelector('[class*="LabelAndValue__label"]');
        
        if (labelElement) {
          // Check if this label contains "Supplier product code", "Supplier option code", or "Status"
          const labelText = labelElement.textContent.trim();
          
          // Find the value element - it should be inside the label element
          const valueElement = labelElement.querySelector('[class*="LabelAndValue__value"]');
          
          if (valueElement) {
            const valueText = valueElement.textContent.trim();
            
            // Check if the label text contains the key phrase (before the colon)
            if (labelText.includes('Supplier product code')) {
              supplierProductCode = valueText;
              console.log(`[viator-products] Found Supplier product code: ${supplierProductCode}`);
            } else if (labelText.includes('Supplier option code')) {
              supplierOptionCode = valueText;
              console.log(`[viator-products] Found Supplier option code: ${supplierOptionCode}`);
            } else if (labelText.includes('Status')) {
              status = valueText;
              console.log(`[viator-products] Found Status: ${status}`);
            }
          } else {
            // Fallback: try to find value element in the container
            const containerValueElement = container.querySelector('[class*="LabelAndValue__value"]');
            if (containerValueElement) {
              const valueText = containerValueElement.textContent.trim();
              
              if (labelText.includes('Supplier product code')) {
                supplierProductCode = valueText;
                console.log(`[viator-products] Found Supplier product code (fallback): ${supplierProductCode}`);
              } else if (labelText.includes('Supplier option code')) {
                supplierOptionCode = valueText;
                console.log(`[viator-products] Found Supplier option code (fallback): ${supplierOptionCode}`);
              } else if (labelText.includes('Status')) {
                status = valueText;
                console.log(`[viator-products] Found Status (fallback): ${status}`);
              }
            }
          }
        }
      });
      
      // Debug logging if we didn't find the supplier product code
      if (!supplierProductCode) {
        console.log(`[viator-products] Debug - TabSection ${index + 1} (${automationId}):`);
        console.log(`  - Product Name found: ${productName ? 'Yes' : 'No'}`);
        console.log(`  - LabelValue containers found: ${labelValueContainers.length}`);
        labelValueContainers.forEach((container, idx) => {
          const labelEl = container.querySelector('[class*="LabelAndValue__label"]');
          const valueEl = container.querySelector('[class*="LabelAndValue__value"]');
          console.log(`  - Container ${idx + 1}: label=${labelEl ? labelEl.textContent.trim().substring(0, 50) : 'NOT FOUND'}, value=${valueEl ? valueEl.textContent.trim() : 'NOT FOUND'}`);
        });
      }
      
      // Add the item even if supplier product code is missing (for "Not connected" items)
      // Only require product name to be present
      if (productName) {
        result.push({
          productCode: productCode,
          productName: productName || '',
          supplierProductCode: supplierProductCode || '',
          supplierOptionCode: supplierOptionCode || '',
          status: status || ''
        });
        console.log(`[viator-products] Extracted option ${index + 1}: Product Code=${productCode}, Product Name=${productName}, Supplier product code=${supplierProductCode || '(none)'}, Supplier option code=${supplierOptionCode || '(none)'}, Status=${status || '(none)'}`);
      } else {
        console.warn(`[viator-products] Skipped option ${index + 1} - missing Product Name`);
      }
    });
    
    console.log(`[viator-products] Successfully extracted ${result.length} options`);
    return result;
  }
  
  // Format data as TSV for Google Sheets (tab-separated values)
  function formatAsTSV(data, includeHeaderRow = false) {
    if (!data || data.length === 0) {
      return '';
    }
    
    const tsvLines = [];
    
    // Add headers if requested
    if (includeHeaderRow) {
      const headers = ['Product Code', 'Product name', 'Supplier product code', 'Status', 'Supplier option code'];
      tsvLines.push(headers.join('\t'));
    }
    
    // Add data rows (using tabs for Google Sheets)
    data.forEach(item => {
      const row = [
        escapeTsvField(item.productCode),
        escapeTsvField(item.productName),
        escapeTsvField(item.supplierProductCode),
        escapeTsvField(item.status),
        escapeTsvField(item.supplierOptionCode)
      ];
      tsvLines.push(row.join('\t'));
    });
    
    return tsvLines.join('\n');
  }
  
  function escapeTsvField(field) {
    if (!field) return '';
    
    // Convert to string and trim
    const str = String(field).trim();
    
    // For TSV, replace tabs, newlines, and carriage returns with spaces
    return str.replace(/[\t\n\r]/g, ' ');
  }

  // Find all product codes on the products list page
  function findAllProductCodes() {
    const productCodeElements = document.querySelectorAll('[data-automation^="product-list-product-code-"]');
    const productCodes = [];
    
    productCodeElements.forEach(element => {
      // Extract product code from data-automation attribute to avoid nested text content
      // Format: "product-list-product-code-{PRODUCT_CODE}"
      const automationAttr = element.getAttribute('data-automation');
      if (automationAttr) {
        const match = automationAttr.match(/^product-list-product-code-(.+)$/);
        if (match && match[1]) {
          const productCode = match[1];
          productCodes.push(productCode);
          console.log(`[viator-products] Extracted product code "${productCode}" from data-automation="${automationAttr}"`);
        } else {
          // Fallback to textContent if data-automation format is unexpected
          const productCode = element.textContent.trim();
          if (productCode) {
            productCodes.push(productCode);
            console.warn(`[viator-products] Fallback: Using textContent "${productCode}" for element with data-automation="${automationAttr}"`);
          }
        }
      } else {
        // Fallback if no data-automation attribute
        const productCode = element.textContent.trim();
        if (productCode) {
          productCodes.push(productCode);
          console.warn(`[viator-products] Fallback: Using textContent "${productCode}" for element without data-automation attribute`);
        }
      }
    });
    
    console.log(`[viator-products] Found ${productCodes.length} product codes: ${productCodes.join(', ')}`);
    return productCodes;
  }

  // Scrape all products from the products list page
  async function scrapeAllViatorProducts(includeHeaderRow = false) {
    const allResults = [];
    const seenTabSections = new Set();
    
    console.log("[viator-products] Starting to scrape all products...");
    
    // Find all product codes
    const productCodes = findAllProductCodes();
    
    if (productCodes.length === 0) {
      return { success: false, error: "No products found on this page. Make sure you're on a products list page." };
    }
    
    // Send message to background script to handle tab creation and scraping
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({
        action: "scrapeAllViatorProducts",
        productCodes: productCodes,
        includeHeaderRow: includeHeaderRow
      }, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        
        if (response && response.success) {
          resolve(response);
        } else {
          reject(new Error(response?.error || "Failed to scrape all products"));
        }
      });
    });
  }

  // Message handling for Viator Products actions
  function handleMessage(req, sender, sendResponse) {
    console.log("[viator-products] Message received:", req);

    if (req.action === "runViatorProductsExtract") {
      const data = scrapeViatorProducts();
      
      if (!data || data.length === 0) {
        sendResponse({ 
          success: false, 
          error: "No Viator products found on this page. Make sure you're on a product page with options." 
        });
        return true;
      }
      
      const includeHeaderRow = req.includeHeaderRow || false;
      const tsvData = formatAsTSV(data, includeHeaderRow);
      
      sendResponse({ 
        success: true, 
        data: data,
        tsvData: tsvData,
        count: data.length
      });
      
      return true; // Indicates we handled the message
    }

    if (req.action === "runViatorProductsExtractAll") {
      // Handle async scraping of all products
      scrapeAllViatorProducts(req.includeHeaderRow || false)
        .then(result => {
          sendResponse(result);
        })
        .catch(error => {
          console.error("[viator-products] Error during all products scraping:", error);
          sendResponse({ 
            success: false, 
            error: "An error occurred while scraping all Viator products: " + error.message 
          });
        });
      
      return true; // Indicates we will send response asynchronously
    }

    if (req.action === "getViatorProductCodes") {
      const productCodes = findAllProductCodes();
      if (!productCodes || productCodes.length === 0) {
        sendResponse({
          success: false,
          error: "No products found on this page. Make sure you're on a products list page."
        });
      } else {
        sendResponse({ success: true, productCodes });
      }
      return true;
    }

    return false; // Not handled by this module
  }

  // Export the module
  window.ViatorProducts = {
    handleMessage,
    scrapeViatorProducts,
    formatAsTSV
  };

  console.log("[viator-products] Module initialized successfully");

})(); // End of initialization function

