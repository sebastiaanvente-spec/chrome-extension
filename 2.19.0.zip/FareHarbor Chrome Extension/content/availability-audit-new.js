// Availability Audit functionality for FareHarbor Chrome Extension
(function() {
  'use strict';

  // Wait for FareHarborUtils to be available
  function waitForUtils() {
    if (typeof window.FareHarborUtils !== 'undefined') {
      initializeAvailabilityAudit();
    } else {
      setTimeout(waitForUtils, 100);
    }
  }

  function initializeAvailabilityAudit() {
    console.log('[availability-audit] Initializing availability audit module');

    const AUDIT_SELECTORS = {
      BOOKING_ELEMENT: 'a[data-test-id="active-booking"], a[data-test-id="cancelled-booking"]',
      ACTIVE_BOOKING: 'a[data-test-id="active-booking"]',
      CANCELLED_BOOKING: 'a[data-test-id="cancelled-booking"]',
      BOOKING_NUMBER: '.fh-grey-new',
      PARTY_SIZE_CONTAINER: '.text-medium',
      BOOKING_DATE_CONTAINER: '.booked-at',
      CANCELLED_DATE_CONTAINER: '.booked-at',
      EXPAND_ACTIVE: 'td[ng-toggle="showActive"]',
      EXPAND_CANCELLED: 'td[ng-toggle="showCancelled"]'
    };

    // Updated patterns for better parsing
    const PARTY_SIZE_PATTERN = /(\d+)(?:\s|&nbsp;)+\w+/gi;
    const DATE_PATTERN = /(?:(\d{1,2}\/\d{1,2}\/\d{2,4})|(Today)|(Yesterday))\s*at\s*(\d{1,2}:\d{2}(?:\s*[APap][Mm])?)/i;
    const CANCELLED_DATE_PATTERN = /Last modified:\s*(?:(\d{1,2}\/\d{1,2}\/\d{2,4})|(Today)|(Yesterday))\s*at\s*(\d{1,2}:\d{2}(?:\s*[APap][Mm])?)/i;
    const RESOURCES_INCLUDING_PATTERN = /(?:including|with)\s+([^•]+?)(?:\s*•|$)/gi;
    const RESOURCES_EXCLUDING_PATTERN = /(?:excluding|without)\s+([^•]+?)(?:\s*•|$)/gi;

    // Helper function to extract numbers from text
    function extractNumber(text) {
      if (!text) return 0;
      const match = text.match(/\d+/);
      return match ? parseInt(match[0], 10) : 0;
    }

    // Enhanced date parsing function
    function parseDateTime(dateStr, timeStr) {
      try {
        console.log(`[parseDateTime] Input: dateStr="${dateStr}", timeStr="${timeStr}"`);
        
        if (!dateStr || !timeStr) {
          console.warn(`[parseDateTime] Missing date or time: dateStr="${dateStr}", timeStr="${timeStr}"`);
          return null;
        }

        let finalDateStr = dateStr;

        // Handle "Today" and "Yesterday"
        const today = new Date();
        if (dateStr === 'Today') {
          const month = (today.getMonth() + 1).toString().padStart(2, '0');
          const day = today.getDate().toString().padStart(2, '0');
          const year = today.getFullYear().toString().slice(-2);
          finalDateStr = `${month}/${day}/${year}`;
        } else if (dateStr === 'Yesterday') {
          const yesterday = new Date(today);
          yesterday.setDate(yesterday.getDate() - 1);
          const month = (yesterday.getMonth() + 1).toString().padStart(2, '0');
          const day = yesterday.getDate().toString().padStart(2, '0');
          const year = yesterday.getFullYear().toString().slice(-2);
          finalDateStr = `${month}/${day}/${year}`;
        }

        let finalTimeStr = timeStr;

        // Handle 24-hour time format (no AM/PM)
        if (!/[APap][Mm]/.test(timeStr)) {
          console.log(`[parseDateTime] Detected 24-hour format: ${timeStr}`);
          const [hours, minutes] = timeStr.split(':').map(Number);
          if (hours === 0) {
            finalTimeStr = `12:${minutes.toString().padStart(2, '0')} AM`;
          } else if (hours < 12) {
            finalTimeStr = `${hours}:${minutes.toString().padStart(2, '0')} AM`;
          } else if (hours === 12) {
            finalTimeStr = `12:${minutes.toString().padStart(2, '0')} PM`;
          } else {
            finalTimeStr = `${hours - 12}:${minutes.toString().padStart(2, '0')} PM`;
          }
          console.log(`[parseDateTime] Converted to 12-hour format: ${finalTimeStr}`);
        }

        // Ensure 4-digit year
        if (finalDateStr.includes('/')) {
          const parts = finalDateStr.split('/');
          if (parts.length === 3 && parts[2].length === 2) {
            parts[2] = `20${parts[2]}`;
            finalDateStr = parts.join('/');
          }
        }

        const dateTimeStr = `${finalDateStr} ${finalTimeStr}`;
        console.log(`[parseDateTime] Final dateTimeStr: "${dateTimeStr}"`);
        
        const date = new Date(dateTimeStr);
        console.log(`[parseDateTime] Result: ${date.toISOString()}, isValid: ${!isNaN(date.getTime())}`);
        
        return isNaN(date.getTime()) ? null : date;
      } catch (error) {
        console.warn(`[parseDateTime] Failed to parse date/time: dateStr="${dateStr}", timeStr="${timeStr}", error:`, error);
        return null;
      }
    }

    // Function to detect if the current page is compatible for auditing
    function detectPageType() {
      const url = window.location.href;
      const bookingElements = document.querySelectorAll(AUDIT_SELECTORS.BOOKING_ELEMENT);
      
      console.log(`[availability-audit] Detected ${bookingElements.length} booking elements on page`);
      
      if (bookingElements.length > 0) {
        return 'booking-grid';
      }
      
      return 'unknown';
    }

    // Function to ensure booking sections are expanded
    async function ensureBookingSectionsExpanded() {
      console.log('[availability-audit] Checking if booking sections need to be expanded...');
      
      const activeExpandButton = document.querySelector(AUDIT_SELECTORS.EXPAND_ACTIVE);
      const cancelledExpandButton = document.querySelector(AUDIT_SELECTORS.EXPAND_CANCELLED);
      
      let expansionsNeeded = 0;
      
      // Check and expand active bookings section
      if (activeExpandButton && activeExpandButton.getAttribute('aria-expanded') === 'false') {
        console.log('[availability-audit] Expanding active bookings section...');
        activeExpandButton.click();
        expansionsNeeded++;
      }
      
      // Check and expand cancelled bookings section
      if (cancelledExpandButton && cancelledExpandButton.getAttribute('aria-expanded') === 'false') {
        console.log('[availability-audit] Expanding cancelled bookings section...');
        cancelledExpandButton.click();
        expansionsNeeded++;
      }
      
      if (expansionsNeeded > 0) {
        console.log(`[availability-audit] Expanded ${expansionsNeeded} sections, waiting for DOM update...`);
        // Wait for DOM to update after expansions
        await new Promise(resolve => setTimeout(resolve, 1000));
      } else {
        console.log('[availability-audit] All sections already expanded');
      }
    }

    // Function to scrape availability data from the page
    async function scrapeAvailabilityData() {
      console.log('[availability-audit] Starting to scrape availability data...');
      
      // First ensure all sections are expanded
      await ensureBookingSectionsExpanded();
      
      const bookingElements = document.querySelectorAll(AUDIT_SELECTORS.BOOKING_ELEMENT);
      console.log(`[availability-audit] Found ${bookingElements.length} total booking elements`);
      
      const bookings = [];

      bookingElements.forEach((element, index) => {
        try {
          const booking = extractBookingData(element, index);
          if (booking) {
            bookings.push(booking);
          }
        } catch (error) {
          console.warn(`[availability-audit] Failed to extract booking ${index}:`, error);
        }
      });
      
      console.log(`[availability-audit] Successfully scraped ${bookings.length} bookings`);
      
      return {
        bookings,
        totalBookings: bookings.length,
        scrapedAt: new Date().toISOString()
      };
    }

    // Function to extract booking data from a single booking element
    function extractBookingData(element, index) {
      console.log(`[availability-audit] Extracting booking ${index + 1}...`);
      
      const isCancelled = element.getAttribute('data-test-id') === 'cancelled-booking';
      
      // Extract booking number
      const bookingNumberElement = element.querySelector(AUDIT_SELECTORS.BOOKING_NUMBER);
      const bookingNumber = bookingNumberElement ? bookingNumberElement.textContent.trim().replace('#', '') : null;
      
      // Extract party size by looking for all numeric patterns
      const partySizeElement = element.querySelector(AUDIT_SELECTORS.PARTY_SIZE_CONTAINER);
      let partySize = 0;
      
      if (partySizeElement) {
        const partySizeText = partySizeElement.textContent;
        console.log(`[availability-audit] Party size text: "${partySizeText}"`);
        
        // Use matchAll to find all party size components
        const matches = [...partySizeText.matchAll(PARTY_SIZE_PATTERN)];
        console.log(`[availability-audit] Found ${matches.length} party size matches:`, matches.map(m => m[1]));
        
        // Sum all the numbers found
        partySize = matches.reduce((sum, match) => sum + parseInt(match[1], 10), 0);
        console.log(`[availability-audit] Calculated total party size: ${partySize}`);
      }
      
      // Extract booking href for detailed information
      const bookingHref = element.getAttribute('href');
      console.log(`[availability-audit] Booking href: ${bookingHref}`);
      
      // Extract resources from the main listing
      const resources = {
        included: [],
        excluded: []
      };
      
      const elementText = element.textContent;
      
      // Look for "including" or "with" resources
      const includingMatches = [...elementText.matchAll(RESOURCES_INCLUDING_PATTERN)];
      includingMatches.forEach(match => {
        const resourceText = match[1].trim();
        if (resourceText) {
          resources.included.push(resourceText);
        }
      });
      
      // Look for "excluding" or "without" resources  
      const excludingMatches = [...elementText.matchAll(RESOURCES_EXCLUDING_PATTERN)];
      excludingMatches.forEach(match => {
        const resourceText = match[1].trim();
        if (resourceText) {
          resources.excluded.push(resourceText);
        }
      });
      
      // Extract date and time information
      const dateElement = element.querySelector(isCancelled ? AUDIT_SELECTORS.CANCELLED_DATE_CONTAINER : AUDIT_SELECTORS.BOOKING_DATE_CONTAINER);
      let bookingDate = null;
      let bookingTime = null;
      let cancelledDate = null;
      let cancelledTime = null;
      let datetime = null;
      
      if (dateElement) {
        const dateText = dateElement.textContent;
        console.log(`[availability-audit] Date text: "${dateText}"`);
        
        if (isCancelled) {
          const cancelledMatch = dateText.match(CANCELLED_DATE_PATTERN);
          if (cancelledMatch) {
            cancelledDate = cancelledMatch[1] || cancelledMatch[2] || cancelledMatch[3];
            cancelledTime = cancelledMatch[4];
            
            // Convert relative dates to absolute dates
            if (cancelledDate === 'Today') {
              const today = new Date();
              cancelledDate = `${today.getMonth() + 1}/${today.getDate()}/${today.getFullYear().toString().slice(-2)}`;
            } else if (cancelledDate === 'Yesterday') {
              const yesterday = new Date();
              yesterday.setDate(yesterday.getDate() - 1);
              cancelledDate = `${yesterday.getMonth() + 1}/${yesterday.getDate()}/${yesterday.getFullYear().toString().slice(-2)}`;
            }
            
            datetime = parseDateTime(cancelledDate, cancelledTime);
            console.log(`[availability-audit] Parsed cancelled datetime: ${datetime ? datetime.toISOString() : 'null'}`);
          }
        } else {
          const bookingMatch = dateText.match(DATE_PATTERN);
          if (bookingMatch) {
            bookingDate = bookingMatch[1] || bookingMatch[2] || bookingMatch[3];
            bookingTime = bookingMatch[4];
            
            // Convert relative dates to absolute dates
            if (bookingDate === 'Today') {
              const today = new Date();
              bookingDate = `${today.getMonth() + 1}/${today.getDate()}/${today.getFullYear().toString().slice(-2)}`;
            } else if (bookingDate === 'Yesterday') {
              const yesterday = new Date();
              yesterday.setDate(yesterday.getDate() - 1);
              bookingDate = `${yesterday.getMonth() + 1}/${yesterday.getDate()}/${yesterday.getFullYear().toString().slice(-2)}`;
            }
            
            datetime = parseDateTime(bookingDate, bookingTime);
            console.log(`[availability-audit] Parsed booking datetime: ${datetime ? datetime.toISOString() : 'null'}`);
          }
        }
      }
      
      const booking = {
        index: index + 1,
        bookingNumber,
        partySize,
        isCancelled,
        bookingDate,
        bookingTime,
        cancelledDate,
        cancelledTime,
        datetime,
        resources,
        bookingHref,
        element: element.outerHTML.substring(0, 500) // First 500 chars for debugging
      };
      
      console.log(`[availability-audit] Extracted booking ${index + 1}:`, {
        bookingNumber: booking.bookingNumber,
        partySize: booking.partySize,
        isCancelled: booking.isCancelled,
        datetime: booking.datetime ? booking.datetime.toISOString() : null,
        hasHref: !!booking.bookingHref
      });

      if (booking.bookingHref) {
        console.log(`[availability-audit] Booking ${index} has href: ${booking.bookingHref}`);
      } else {
        console.log(`[availability-audit] Booking ${index} missing href! Element:`, element);
      }
      
      return booking;
    }

    // Function to filter bookings based on target date and time
    function filterBookingsUpToDateTime(bookings, targetDate, targetTime) {
      console.log(`[availability-audit] Filtering bookings up to ${targetDate} ${targetTime}`);
      
      // Parse the target date/time directly (user input format)
      const targetDateTime = new Date(`${targetDate} ${targetTime}`);
      
      if (isNaN(targetDateTime.getTime())) {
        console.error(`[availability-audit] Invalid target date/time: ${targetDate} ${targetTime}`);
        return {
          filteredBookings: [],
          skippedBookings: [],
          targetDateTime: null
        };
      }
      
      console.log(`[availability-audit] Target datetime: ${targetDateTime.toISOString()}`);
      
      const filteredBookings = [];
      const skippedBookings = [];
      
      if (!bookings || !Array.isArray(bookings)) {
        console.error('[availability-audit] No valid bookings array provided');
        return {
          filteredBookings: [],
          skippedBookings: [],
          targetDateTime
        };
      }
      
      bookings.forEach((booking, index) => {
        if (!booking.datetime) {
          console.log(`[availability-audit] Booking ${index + 1} has no datetime, excluding from filter`);
          skippedBookings.push(booking);
          return;
        }
        
        console.log(`[availability-audit] Checking booking ${index + 1}: ${booking.datetime.toISOString()} vs target ${targetDateTime.toISOString()}`);
        
        if (booking.isCancelled) {
          // For cancelled bookings, include them if they were cancelled AFTER the target time
          // (meaning they were active at the target time)
          if (booking.datetime > targetDateTime) {
            console.log(`[availability-audit] Including cancelled booking ${index + 1} - cancelled after target time`);
            filteredBookings.push({...booking, reason: 'cancelled_after_target'});
          } else {
            console.log(`[availability-audit] Excluding cancelled booking ${index + 1} - cancelled before target time`);
            skippedBookings.push(booking);
          }
        } else {
          // For active bookings, include them if they were created BEFORE or AT the target time
          if (booking.datetime <= targetDateTime) {
            console.log(`[availability-audit] Including active booking ${index + 1} - created before/at target time`);
            filteredBookings.push({...booking, reason: 'active_before_target'});
          } else {
            console.log(`[availability-audit] Excluding active booking ${index + 1} - created after target time`);
            skippedBookings.push(booking);
          }
        }
      });
      
      return {
        filteredBookings,
        skippedBookings,
        targetDateTime
      };
    }

    // Function to calculate total capacity used
    function calculateCapacityUsed(filteredBookings) {
      if (!filteredBookings || !Array.isArray(filteredBookings)) {
        return 0;
      }
      
      return filteredBookings.reduce((total, booking) => total + (booking.partySize || 0), 0);
    }

    // Function to prepare audit summary
    function prepareAuditSummary(bookings, filteredBookings, skippedBookings, targetDateTime) {
      const capacityUsed = calculateCapacityUsed(filteredBookings);
      
      return {
        filteredBookings,
        totalCapacityUsed: capacityUsed,
        targetDateTime: targetDateTime.toISOString(),
        originalBookingsCount: bookings.length,
        filteredBookingsCount: filteredBookings.length,
        skippedBookingsCount: skippedBookings.length
      };
    }

    // Function to fetch detailed booking information using iframe for proper authentication
    async function fetchBookingDetails(bookingHref) {
      try {
        console.log(`[availability-audit] Loading booking details from: ${bookingHref}`);
        
        // Use iframe approach to load the page with user's session
        return new Promise((resolve) => {
          console.log(`[availability-audit] Creating hidden iframe for: ${bookingHref}`);
          
          const iframe = document.createElement('iframe');
          iframe.style.display = 'none';
          iframe.style.position = 'absolute';
          iframe.style.left = '-9999px';
          iframe.style.width = '1px';
          iframe.style.height = '1px';
          
          let timeoutId;
          let resolved = false;
          
          const cleanup = () => {
            if (timeoutId) clearTimeout(timeoutId);
            if (iframe.parentNode) {
              iframe.parentNode.removeChild(iframe);
            }
          };
          
          const resolveOnce = (result) => {
            if (!resolved) {
              resolved = true;
              cleanup();
              resolve(result);
            }
          };
          
          // Set timeout to prevent hanging
          timeoutId = setTimeout(() => {
            console.warn(`[availability-audit] Iframe loading timeout for ${bookingHref}`);
            resolveOnce(null);
          }, 15000); // 15 second timeout
          
          iframe.onload = async () => {
            try {
              console.log(`[availability-audit] Iframe loaded successfully`);
              
              // Wait for any JavaScript to execute and overlay to load
              await new Promise(resolve => setTimeout(resolve, 2000));
              
              const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
              
              if (!iframeDoc) {
                console.error(`[availability-audit] Cannot access iframe document`);
                resolveOnce(null);
                return;
              }
              
              const html = iframeDoc.documentElement.outerHTML;
              console.log(`[availability-audit] Iframe HTML length: ${html.length} characters`);
              
              // Check if we got a login page
              if (html.toLowerCase().includes('login') || html.toLowerCase().includes('log in') || 
                  html.toLowerCase().includes('sign in') || html.toLowerCase().includes('authentication')) {
                console.warn(`[availability-audit] Iframe received login page - authentication issue`);
                resolveOnce(null);
                return;
              }
              
              // Check for Eveline to verify we have the right content
              if (html.toLowerCase().includes('eveline')) {
                console.log(`[availability-audit] Found "Eveline" in iframe HTML!`);
              } else {
                console.log(`[availability-audit] "Eveline" NOT found in iframe HTML`);
              }
              
              const result = await extractBookingDetailsFromDoc(iframeDoc, html);
              console.log(`[availability-audit] Iframe processing complete, result:`, result);
              resolveOnce(result);
              
            } catch (error) {
              console.error(`[availability-audit] Error processing iframe content:`, error);
              resolveOnce(null);
            }
          };
          
          iframe.onerror = () => {
            console.error(`[availability-audit] Iframe loading error for ${bookingHref}`);
            resolveOnce(null);
          };
          
          // Add iframe to page and start loading
          document.body.appendChild(iframe);
          iframe.src = bookingHref;
          
          console.log(`[availability-audit] Iframe created and loading started`);
        });
        
      } catch (error) {
        console.warn(`[availability-audit] Failed to fetch booking details: ${error.message}`);
        return null;
      }
    }

    // Helper function to extract booking details from document
    async function extractBookingDetailsFromDoc(doc, html) {
      // Extract additional details from the booking page
      const details = {
        actualCapacity: null,
        bookingDetails: null,
        customerInfo: null,
        resources: {
          included: [],
          excluded: [],
          detailed: []
        }
      };

      // Extract resource information from booking detail page
      console.log(`[availability-audit] Searching for resources in booking details`);
      console.log(`[availability-audit] HTML content length: ${html.length} characters`);
      
      // Log a sample of the HTML to see what we're working with
      const htmlSample = html.substring(0, 2000); // First 2000 chars
      console.log(`[availability-audit] HTML sample:`, htmlSample);
      
      // Check if "Eveline" appears anywhere in the HTML
      if (html.toLowerCase().includes('eveline')) {
        console.log(`[availability-audit] Found "Eveline" in HTML!`);
        // Find all occurrences with context
        const evelineContext = [];
        const lines = html.split('\n');
        lines.forEach((line, lineNum) => {
          if (line.toLowerCase().includes('eveline')) {
            evelineContext.push(`Line ${lineNum}: ${line.trim()}`);
          }
        });
        console.log(`[availability-audit] Eveline contexts:`, evelineContext);
      } else {
        console.log(`[availability-audit] "Eveline" NOT found in HTML`);
      }
      
      // Look for FareHarbor resource structure specifically
      console.log(`[availability-audit] Looking for FareHarbor resource usage indicators...`);
      
      // Target the specific resource usage indicators
      const resourceUsageIndicators = doc.querySelectorAll('[data-test-id*="resource-usage-indicator"]');
      console.log(`[availability-audit] Found ${resourceUsageIndicators.length} resource usage indicators`);
      
      resourceUsageIndicators.forEach((indicator, indicatorIndex) => {
        console.log(`[availability-audit] Processing resource usage indicator ${indicatorIndex + 1}`);
        console.log(`[availability-audit] Indicator data-test-id: ${indicator.getAttribute('data-test-id')}`);
        
        // Look for invoice tables within this indicator
        const invoiceTables = indicator.querySelectorAll('.invoice-table');
        console.log(`[availability-audit] Found ${invoiceTables.length} invoice tables in indicator ${indicatorIndex + 1}`);
        
        invoiceTables.forEach((table, tableIndex) => {
          console.log(`[availability-audit] Processing table ${tableIndex + 1} in indicator ${indicatorIndex + 1}`);
          
          // Look for fh-grey-new spans that contain resource names
          const greySpans = table.querySelectorAll('.fh-grey-new');
          console.log(`[availability-audit] Found ${greySpans.length} fh-grey-new spans in table`);
          
          greySpans.forEach((span, spanIndex) => {
            const spanText = span.textContent.trim();
            console.log(`[availability-audit] fh-grey-new span ${spanIndex + 1}: "${spanText}"`);
            
            // Check if this span contains a resource name (ends with colon)
            if (spanText.endsWith(':')) {
              const resourceName = spanText.replace(':', '').trim();
              console.log(`[availability-audit] Found resource name: "${resourceName}"`);
              
              // Look for the quantity in the next sibling or parent element
              let quantity = null;
              
              // Try to find quantity in next text node
              let nextNode = span.nextSibling;
              while (nextNode) {
                if (nextNode.nodeType === Node.TEXT_NODE) {
                  const text = nextNode.textContent.trim();
                  const num = parseInt(text, 10);
                  if (!isNaN(num) && num > 0) {
                    quantity = num;
                    console.log(`[availability-audit] Found quantity in next text node: ${quantity}`);
                    break;
                  }
                } else if (nextNode.nodeType === Node.ELEMENT_NODE) {
                  const text = nextNode.textContent.trim();
                  const num = parseInt(text, 10);
                  if (!isNaN(num) && num > 0) {
                    quantity = num;
                    console.log(`[availability-audit] Found quantity in next element: ${quantity}`);
                    break;
                  }
                }
                nextNode = nextNode.nextSibling;
              }
              
              // If not found in siblings, check parent's text content
              if (quantity === null) {
                const parentText = span.parentElement?.textContent || '';
                console.log(`[availability-audit] Parent text content: "${parentText}"`);
                const match = parentText.match(new RegExp(resourceName + ':\\s*(\\d+)', 'i'));
                if (match) {
                  quantity = parseInt(match[1], 10);
                  console.log(`[availability-audit] Found quantity in parent text: ${quantity}`);
                }
              }
              
              // Also try looking in the table cell content
              if (quantity === null) {
                const cell = span.closest('td');
                if (cell) {
                  const cellText = cell.textContent.trim();
                  console.log(`[availability-audit] Cell text content: "${cellText}"`);
                  // Look for number after the resource name
                  const cellMatch = cellText.match(new RegExp(resourceName + ':\\s*(\\d+)', 'i'));
                  if (cellMatch) {
                    quantity = parseInt(cellMatch[1], 10);
                    console.log(`[availability-audit] Found quantity in cell text: ${quantity}`);
                  } else {
                    // Try to find standalone number in cell
                    const numbers = cellText.match(/\b\d+\b/g);
                    if (numbers && numbers.length > 0) {
                      quantity = parseInt(numbers[numbers.length - 1], 10); // Take last number
                      console.log(`[availability-audit] Found standalone quantity in cell: ${quantity}`);
                    }
                  }
                }
              }
              
              if (quantity !== null) {
                details.resources.detailed.push({
                  name: resourceName,
                  quantity: quantity
                });
                console.log(`[availability-audit] Added resource: ${resourceName} (${quantity})`);
              } else {
                console.log(`[availability-audit] Could not find quantity for resource: ${resourceName}`);
              }
            }
          });
        });
      });
      
      // Also try broader selectors for debugging
      const debugSelectors = [
        '.resource', 
        '.resources', 
        '[class*="resource"]',
        '.booking-item',
        '.booking-items',
        '.item-details',
        '.add-ons',
        '.extras',
        '.line-item',
        '.booking-line-item'
      ];
      
      debugSelectors.forEach(selector => {
        const elements = doc.querySelectorAll(selector);
        console.log(`[availability-audit] Selector "${selector}" found ${elements.length} elements`);
      });
      
      return details;
    }

    // Main audit function
    async function runAvailabilityAudit(targetDate, targetTime, fetchDetailedInfo = false) {
      try {
        console.log(`[availability-audit] AUDIT STARTED - fetchDetailedInfo: ${fetchDetailedInfo}`);
        console.log(`[availability-audit] Running audit for ${targetDate} ${targetTime} (detailed: ${fetchDetailedInfo})`);
        
        // Step 1: Scrape basic availability data
        const availabilityData = await scrapeAvailabilityData();
        
        if (!availabilityData || !availabilityData.bookings || !Array.isArray(availabilityData.bookings)) {
          throw new Error('Failed to scrape availability data or no bookings found');
        }
        
        // Step 2: Optionally fetch detailed information for each booking
        if (fetchDetailedInfo) {
          console.log(`[availability-audit] DETAILED INFO ENABLED - Processing ${availabilityData.bookings.length} bookings`);
          
          for (let i = 0; i < availabilityData.bookings.length; i++) {
            const booking = availabilityData.bookings[i];
            
            if (booking.bookingHref) {
              console.log(`[availability-audit] Processing booking ${i + 1}: bookingHref = ${booking.bookingHref}`);
              console.log(`[availability-audit] Fetching details for booking ${i + 1}/${availabilityData.bookings.length} - URL: ${booking.bookingHref}`);
              
              const details = await fetchBookingDetails(booking.bookingHref);
              console.log(`[availability-audit] Received details for booking ${i + 1}:`, details);
              
              if (details) {
                booking.detailedInfo = details;
                
                // Update party size if we got more accurate data
                if (details.actualCapacity) {
                  booking.partySize = details.actualCapacity;
                }
                
                // Add detailed resource information
                if (details.resources && details.resources.detailed) {
                  booking.resources.detailed = details.resources.detailed;
                }
              }
            }
          }
        } else {
          console.log(`[availability-audit] DETAILED INFO DISABLED - Using basic data only`);
        }
        
        // Step 3: Filter bookings based on target date/time
        const filterResult = filterBookingsUpToDateTime(availabilityData.bookings, targetDate, targetTime);
        
        // Step 4: Prepare summary
        const result = prepareAuditSummary(
          availabilityData.bookings,
          filterResult.filteredBookings,
          filterResult.skippedBookings,
          filterResult.targetDateTime
        );
        
        result.success = true;
        result.detailedInfoFetched = fetchDetailedInfo;
        
        console.log("[availability-audit] Audit completed successfully:", result);
        return result;
        
      } catch (error) {
        console.error("[availability-audit] Audit failed:", error);
        return { 
          success: false, 
          error: error.message,
          details: error.stack 
        };
      }
    }

    // Message handler for communication with popup
    function handleMessage(req, sender, sendResponse) {
      console.log("[availability-audit] Received message:", req);
      
      if (req.action === 'runAvailabilityAudit') {
        console.log(`[availability-audit] Processing ${req.action} with fetchDetailedInfo: ${req.fetchDetailedInfo}`);
        
        runAvailabilityAudit(
          req.targetDate, 
          req.targetTime, 
          req.fetchDetailedInfo || false
        ).then(result => {
          console.log("[availability-audit] Sending audit result:", result);
          sendResponse(result);
        }).catch(error => {
          console.error("[availability-audit] Error handling audit request:", error);
          sendResponse({ 
            success: false, 
            error: error.message 
          });
        });
        return true; // Keep the message channel open for async response
        
      } else if (req.action === 'getAvailabilityPageInfo') {
        try {
          const pageType = detectPageType();
          const sampleData = {
            pageType,
            bookings: document.querySelectorAll(AUDIT_SELECTORS.BOOKING_ELEMENT)
          };
          
          sendResponse({
            success: true,
            pageType,
            canAudit: sampleData.bookings.length > 0  // If we find bookings, we can audit
          });
        } catch (error) {
          sendResponse({ 
            success: false, 
            error: error.message 
          });
        }
      }
    }

    // Register the module
    window.AvailabilityAudit = {
      detectPageType,
      scrapeAvailabilityData,
      runAvailabilityAudit,
      handleMessage,
      fetchBookingDetails,
      filterBookingsUpToDateTime,
      calculateCapacityUsed
    };

    console.log('[availability-audit] Module initialized and registered');
  }

  // Start waiting for utils
  waitForUtils();
})();


