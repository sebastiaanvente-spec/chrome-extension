console.log("[activity-listings] activity-listings.js loaded");

// Wait for utilities to be available and initialize module
(function initializeActivityListings() {
  // Wait for FareHarborUtils to be available
  if (!window.FareHarborUtils) {
    setTimeout(initializeActivityListings, 10);
    return;
  }
  
  // Now utilities are available, set up the module
  const utils = window.FareHarborUtils;

  // Activity listings data extraction functions
  function scrapeCurrentPage() {
    const result = [];
    
    console.log("[activity-listings] Scraping current page...");
    
    // Find the table container
    const tableContainer = document.querySelector('[role="table"][aria-label="Activity listings"]');
    if (!tableContainer) {
      console.warn("[activity-listings] Activity listings table not found");
      return null;
    }
    
    // Find all data rows (skip header row)
    const rows = tableContainer.querySelectorAll('[role="row"]');
    console.log(`[activity-listings] Found ${rows.length} total rows on current page`);
    
    // Process each row (skip first row which is the header)
    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const cells = row.querySelectorAll('[role="cell"]');
      
      if (cells.length >= 7) { // Make sure we have enough cells
        // Extract data from specific columns
        // Column mapping: 0=ID, 1=Name, 2=Owner ID (skip), 3=Status, 4=API Sync Status, 5=Vetting queue status, 6=Country, 7=Product type (skip), 8=Last updated (skip)
        
        const id = extractCellText(cells[0]);
        const name = extractCellText(cells[1]);
        const status = extractCellText(cells[3]);
        const apiSyncStatus = extractCellText(cells[4]);
        const vettingQueueStatus = extractCellText(cells[5]);
        const country = extractCellText(cells[6]);
        
        if (id && name) {
          result.push({
            id,
            name,
            status,
            apiSyncStatus,
            vettingQueueStatus,
            country
          });
          
          console.log(`[activity-listings] Extracted row ${i}: ID=${id}, Name=${name}`);
        } else {
          console.warn(`[activity-listings] Skipped row ${i} - missing required data`);
        }
      } else {
        console.warn(`[activity-listings] Skipped row ${i} - insufficient cells (${cells.length})`);
      }
    }
    
    console.log(`[activity-listings] Successfully extracted ${result.length} activity listings from current page`);
    return result;
  }

  function hasPreviousPage() {
    const prevButton = document.querySelector('button[data-testid="previous_page"]');
    if (!prevButton) {
      console.log("[activity-listings] No previous page button found");
      return false;
    }
    
    // Check if button is disabled
    const isDisabled = prevButton.disabled || prevButton.hasAttribute('disabled') || 
                      prevButton.getAttribute('aria-disabled') === 'true';
    
    console.log(`[activity-listings] Previous page button found, disabled: ${isDisabled}`);
    return !isDisabled;
  }

  function clickPreviousPage() {
    const prevButton = document.querySelector('button[data-testid="previous_page"]');
    if (!prevButton) {
      console.warn("[activity-listings] Previous page button not found");
      return false;
    }
    
    console.log("[activity-listings] Clicking previous page button...");
    prevButton.click();
    return true;
  }

  function hasNextPage() {
    const nextButton = document.querySelector('button[data-testid="next_page"]');
    if (!nextButton) {
      console.log("[activity-listings] No next page button found");
      return false;
    }
    
    // Check if button is disabled
    const isDisabled = nextButton.disabled || nextButton.hasAttribute('disabled') || 
                      nextButton.getAttribute('aria-disabled') === 'true';
    
    console.log(`[activity-listings] Next page button found, disabled: ${isDisabled}`);
    return !isDisabled;
  }

  function clickNextPage() {
    const nextButton = document.querySelector('button[data-testid="next_page"]');
    if (!nextButton) {
      console.warn("[activity-listings] Next page button not found");
      return false;
    }
    
    console.log("[activity-listings] Clicking next page button...");
    nextButton.click();
    return true;
  }

  function waitForPageLoad() {
    return new Promise((resolve) => {
      // Wait for the page to finish loading/updating
      setTimeout(() => {
        console.log("[activity-listings] Page load wait completed");
        resolve();
      }, 2000); // Wait 2 seconds for page transition
    });
  }

  async function navigateToFirstPage() {
    console.log("[activity-listings] Checking if we need to navigate to first page...");
    
    let attempts = 0;
    const maxAttempts = 50; // Safety limit to prevent infinite loops
    
    while (hasPreviousPage() && attempts < maxAttempts) {
      console.log(`[activity-listings] Found previous page button, going back (attempt ${attempts + 1})...`);
      
      if (!clickPreviousPage()) {
        console.error("[activity-listings] Failed to click previous page button");
        break;
      }
      
      // Wait for page to load
      await waitForPageLoad();
      attempts++;
    }
    
    if (attempts === 0) {
      console.log("[activity-listings] Already on first page");
    } else if (attempts >= maxAttempts) {
      console.warn(`[activity-listings] Reached maximum attempts (${maxAttempts}) while navigating to first page`);
    } else {
      console.log(`[activity-listings] Successfully navigated to first page after ${attempts} steps`);
    }
    
    return true;
  }

  async function scrapeActivityListings() {
    const allResults = [];
    let currentPage = 1;
    const maxPages = 50; // Safety limit to prevent infinite loops
    
    console.log("[activity-listings] Starting to scrape activity listings with pagination...");
    
    try {
      // First, navigate to the first page to ensure we capture all data
      await navigateToFirstPage();
      
      do {
        console.log(`[activity-listings] Scraping page ${currentPage}...`);
        
        // Scrape current page
        const pageResults = scrapeCurrentPage();
        if (!pageResults) {
          console.error("[activity-listings] Failed to scrape current page");
          break;
        }
        
        if (pageResults.length === 0) {
          console.log("[activity-listings] No data found on current page, stopping");
          break;
        }
        
        // Add results from this page
        allResults.push(...pageResults);
        console.log(`[activity-listings] Page ${currentPage}: Added ${pageResults.length} items (total: ${allResults.length})`);
        
        // Check if there's a next page
        if (!hasNextPage()) {
          console.log("[activity-listings] No more pages available");
          break;
        }
        
        // Safety check
        if (currentPage >= maxPages) {
          console.warn(`[activity-listings] Reached maximum page limit (${maxPages}), stopping`);
          break;
        }
        
        // Go to next page
        if (!clickNextPage()) {
          console.error("[activity-listings] Failed to click next page");
          break;
        }
        
        // Wait for page to load
        await waitForPageLoad();
        currentPage++;
        
      } while (true);
      
    } catch (error) {
      console.error("[activity-listings] Error during pagination:", error);
    }
    
    console.log(`[activity-listings] Pagination complete. Scraped ${currentPage} pages with ${allResults.length} total items`);
    return allResults;
  }
  
  function extractCellText(cell) {
    if (!cell) return '';
    
    // Try to get text from links first
    const link = cell.querySelector('a');
    if (link) {
      return link.textContent.trim();
    }
    
    // Try to get text from spans with status indicators
    const statusSpan = cell.querySelector('span[class*="b16ycy69"] span:last-child');
    if (statusSpan) {
      return statusSpan.textContent.trim();
    }
    
    // Try to get text from div containers (for country codes)
    const divText = cell.querySelector('div');
    if (divText) {
      return divText.textContent.trim();
    }
    
    // Fall back to cell text content
    return cell.textContent.trim();
  }
  
  function formatAsCSV(data) {
    if (!data || data.length === 0) {
      return '';
    }
    
    // TSV headers for Google Sheets compatibility
    const headers = ['ID', 'Name', 'Status', 'API Sync Status', 'Vetting queue status', 'Country'];
    
    // Start with headers (using tabs for Google Sheets)
    const csvLines = [headers.join('\t')];
    
    // Add data rows (using tabs for Google Sheets)
    data.forEach(item => {
      const row = [
        escapeTsvField(item.id),
        escapeTsvField(item.name),
        escapeTsvField(item.status),
        escapeTsvField(item.apiSyncStatus),
        escapeTsvField(item.vettingQueueStatus),
        escapeTsvField(item.country)
      ];
      csvLines.push(row.join('\t'));
    });
    
    return csvLines.join('\n');
  }
  
  function escapeTsvField(field) {
    if (!field) return '';
    
    // Convert to string and trim
    const str = String(field).trim();
    
    // For TSV, replace tabs, newlines, and carriage returns with spaces
    return str.replace(/[\t\n\r]/g, ' ');
  }
  
  // Note: Clipboard copying moved to popup due to focus requirements

  // Message handling for Activity Listings actions
  function handleMessage(req, sender, sendResponse) {
    console.log("[activity-listings] Message received:", req);

    if (req.action === "runActivityListingsExtract") {
      // Handle async scraping with pagination
      scrapeActivityListings()
        .then(data => {
          if (!data || data.length === 0) {
            sendResponse({ 
              success: false, 
              error: "No activity listings found on this page. Make sure you're on the Activity Listings page." 
            });
            return;
          }
          
          const csvData = formatAsCSV(data);
          
          sendResponse({ 
            success: true, 
            data: data,
            csvData: csvData,
            count: data.length
          });
        })
        .catch(error => {
          console.error("[activity-listings] Error during scraping:", error);
          sendResponse({ 
            success: false, 
            error: "An error occurred while scraping activity listings: " + error.message 
          });
        });
      
      return true; // Indicates we will send response asynchronously
    }

    return false; // Not handled by this module
  }

  // Export the module
  window.ActivityListings = {
    handleMessage,
    scrapeActivityListings,
    scrapeCurrentPage,
    formatAsCSV,
    hasPreviousPage,
    clickPreviousPage,
    hasNextPage,
    clickNextPage,
    navigateToFirstPage
  };

  console.log("[activity-listings] Module initialized successfully");

})(); // End of initialization function
