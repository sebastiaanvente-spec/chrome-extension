console.log("[availability-audit] availability-audit.js loaded");

// Wait for utilities to be available and initialize module
(function initializeAvailabilityAudit() {
  // Wait for FareHarborUtils to be available
  if (!window.FareHarborUtils) {
    setTimeout(initializeAvailabilityAudit, 10);
    return;
  }
  
  // Now utilities are available, set up the module
  const utils = window.FareHarborUtils;

  // Availability audit specific selectors (based on actual FareHarbor HTML structure)
  const AUDIT_SELECTORS = {
    // Main booking elements (both active and cancelled)
    BOOKING_ELEMENTS: 'a[data-test-id="active-booking"], a[data-test-id="cancelled-booking"]',
    
    // Within each booking element
    BOOKING_CONTACT: '.availability-booking-contact',
    BOOKING_DETAILS: '.text-medium',
    BOOKING_DATE_INFO: '.booked-at',
    STATUS_BADGE: '.status-badge',
    
    // Patterns for extracting data - generic pattern to match any customer type
    PARTY_SIZE_PATTERN: /(\d+)(?:\s|&nbsp;)+\w+/gi,
    BOOKING_NUMBER_PATTERN: /#(\d+)/,
    
    // Resource patterns for FareHarbor add-ons/resources
    RESOURCES_INCLUDING_PATTERN: /(?:including|with)\s+([^•]+?)(?:\s*•|$)/gi,
    RESOURCES_EXCLUDING_PATTERN: /(?:excluding|without)\s+([^•]+?)(?:\s*•|$)/gi,
    DATE_PATTERN: /(?:(\d{1,2}\/\d{1,2}\/\d{2,4})|(Today)|(Yesterday))\s*at\s*(\d{1,2}:\d{2}(?:\s*[APap][Mm])?)/i,
    CANCELLED_DATE_PATTERN: /Last modified:\s*(?:(\d{1,2}\/\d{1,2}\/\d{2,4})|(Today)|(Yesterday))\s*at\s*(\d{1,2}:\d{2}(?:\s*[APap][Mm])?)/i,
    
    // Fallback selectors for different page types
    AVAILABILITY_CALENDAR: '.availability-calendar',
    AVAILABILITY_GRID: '.availability-grid',
    TIME_SLOTS: '.time-slot',
    
    // Expandable sections
    ACTIVE_BOOKINGS_TOGGLE: 'td[ng-toggle="showActive"]',
    CANCELLED_BOOKINGS_TOGGLE: 'td[ng-toggle="showCancelled"]'
  };

  // Helper function to parse date/time strings from FareHarbor format
  function parseDateTime(dateStr, timeStr) {
    try {
      if (!dateStr || !timeStr) {
        console.warn(`[parseDateTime] Missing data: dateStr="${dateStr}", timeStr="${timeStr}"`);
        return null;
      }
      
      console.log(`[parseDateTime] Input: dateStr="${dateStr}", timeStr="${timeStr}"`);
      
      // Handle FareHarbor date format like "7/10/25" -> convert to full year
      let processedDate = dateStr;
      const dateParts = dateStr.split('/');
      if (dateParts.length === 3 && dateParts[2].length === 2) {
        // Convert 2-digit year to 4-digit (assuming 20xx)
        processedDate = `${dateParts[0]}/${dateParts[1]}/20${dateParts[2]}`;
      }
      
      // Handle both 12-hour (with AM/PM) and 24-hour (without AM/PM) time formats
      let processedTime = timeStr.trim();
      
      // Check if time has AM/PM - if not, it's 24-hour format
      if (!/[APap][Mm]/.test(processedTime)) {
        console.log(`[parseDateTime] 24-hour format detected: "${processedTime}"`);
        const [hours, minutes] = processedTime.split(':');
        const hour24 = parseInt(hours, 10);
        
        // Convert 24-hour to 12-hour format for consistent parsing
        if (hour24 === 0) {
          processedTime = `12:${minutes} AM`;
        } else if (hour24 < 12) {
          processedTime = `${hour24}:${minutes} AM`;
        } else if (hour24 === 12) {
          processedTime = `12:${minutes} PM`;
        } else {
          processedTime = `${hour24 - 12}:${minutes} PM`;
        }
        console.log(`[parseDateTime] Converted to 12-hour format: "${processedTime}"`);
      } else {
        // Normalize time format (ensure space before AM/PM)
        processedTime = processedTime.replace(/([ap]m)/i, ' $1').replace(/\s+/g, ' ').trim();
      }
      
      // Combine date and time
      const fullDateTime = `${processedDate} ${processedTime}`;
      console.log(`[parseDateTime] Attempting to parse: "${fullDateTime}"`);
      
      const date = new Date(fullDateTime);
      console.log(`[parseDateTime] Result: ${date.toISOString()}, isValid: ${!isNaN(date.getTime())}`);
      
      return isNaN(date.getTime()) ? null : date;
    } catch (error) {
      console.warn(`[parseDateTime] Failed to parse date/time: dateStr="${dateStr}", timeStr="${timeStr}", error:`, error);
      return null;
    }
  }

  // Helper function to extract numeric value from text (e.g., "5 guests" -> 5)
  function extractNumber(text) {
    if (!text) return 0;
    const match = text.toString().match(/\d+/);
    return match ? parseInt(match[0], 10) : 0;
  }

  // Main function to detect what type of availability page we're on
  function detectPageType() {
    const url = window.location.href;
    
    // Check for different FareHarbor availability page patterns
    if (url.includes('/availability') || url.includes('/calendar') || url.includes('/bookings/grid')) {
      if (utils.$(AUDIT_SELECTORS.AVAILABILITY_CALENDAR)) {
        return 'calendar';
      } else if (utils.$(AUDIT_SELECTORS.AVAILABILITY_GRID)) {
        return 'grid';
      } else {
        return 'list';
      }
    }
    
    // If we find booking elements, consider it a valid availability page regardless of URL
    const bookingElements = utils.$$(AUDIT_SELECTORS.BOOKING_ELEMENTS);
    if (bookingElements.length > 0) {
      return 'booking-grid';
    }
    
    return 'unknown';
  }

  // Function to ensure booking sections are expanded
  async function ensureBookingSectionsExpanded() {
    console.log("[availability-audit] Checking if booking sections are expanded...");
    
    const expandPromises = [];
    
    // Check and expand active bookings section
    const activeToggle = utils.$(AUDIT_SELECTORS.ACTIVE_BOOKINGS_TOGGLE);
    if (activeToggle) {
      const isExpanded = activeToggle.getAttribute('aria-expanded') === 'true';
      console.log(`[availability-audit] Active bookings section expanded: ${isExpanded}`);
      
      if (!isExpanded) {
        console.log("[availability-audit] Expanding active bookings section...");
        activeToggle.click();
        expandPromises.push(utils.wait(500)); // Wait for expansion animation
      }
    } else {
      console.log("[availability-audit] Active bookings toggle not found");
    }
    
    // Check and expand cancelled bookings section
    const cancelledToggle = utils.$(AUDIT_SELECTORS.CANCELLED_BOOKINGS_TOGGLE);
    if (cancelledToggle) {
      const isExpanded = cancelledToggle.getAttribute('aria-expanded') === 'true';
      console.log(`[availability-audit] Cancelled bookings section expanded: ${isExpanded}`);
      
      if (!isExpanded) {
        console.log("[availability-audit] Expanding cancelled bookings section...");
        cancelledToggle.click();
        expandPromises.push(utils.wait(500)); // Wait for expansion animation
      }
    } else {
      console.log("[availability-audit] Cancelled bookings toggle not found");
    }
    
    // Wait for all expansions to complete
    if (expandPromises.length > 0) {
      await Promise.all(expandPromises);
      console.log("[availability-audit] Finished expanding sections, waiting for DOM to update...");
      await utils.wait(1000); // Extra time for DOM updates
    } else {
      console.log("[availability-audit] All sections already expanded");
    }
  }

  // Function to scrape all bookings from the current availability view
  async function scrapeAvailabilityData() {
    console.log("[availability-audit] Starting to scrape availability data");
    
    const pageType = detectPageType();
    console.log("[availability-audit] Detected page type:", pageType);
    
    // First, ensure all booking sections are expanded
    await ensureBookingSectionsExpanded();
    
    const bookings = [];
    
    // Use the correct selector for FareHarbor booking elements
    const bookingElements = utils.$$(AUDIT_SELECTORS.BOOKING_ELEMENTS);
    
    if (bookingElements.length === 0) {
      console.warn("[availability-audit] No booking elements found with selector:", AUDIT_SELECTORS.BOOKING_ELEMENTS);
      return { bookings: [], totalCapacityUsed: 0, pageType, error: "No bookings found" };
    }
    
    console.log(`[availability-audit] Found ${bookingElements.length} booking elements`);
    
    // Extract data from each booking element
    bookingElements.forEach((element, index) => {
      try {
        const booking = extractBookingData(element, index);
        if (booking) {
          bookings.push(booking);
        }
      } catch (error) {
        console.warn(`[availability-audit] Failed to extract booking ${index}:`, error);
      }
    });
    
    console.log(`[availability-audit] Successfully scraped ${bookings.length} bookings`);
    
    return {
      bookings,
      totalCapacityUsed: bookings.reduce((sum, booking) => sum + booking.partySize, 0),
      pageType,
      scrapedAt: new Date().toISOString(),
      url: window.location.href
    };
  }

  // Function to extract booking data from a single booking element
  function extractBookingData(element, index) {
    const booking = {
      index,
      bookingHref: element.href || '',
      bookingNumber: null,
      customerName: 'Unknown',
      partySize: 0,
      bookingDate: null,
      bookingTime: null,
      datetime: null,
      status: null,
      isCancelled: false,
      cancelledDate: null,
      cancelledTime: null,
      cancelledDatetime: null,
      rawElement: element.outerHTML.substring(0, 300) + '...' // For debugging
    };
    
    // Determine if this is a cancelled booking
    booking.isCancelled = element.getAttribute('data-test-id') === 'cancelled-booking';
    
    // Extract customer name
    const contactElement = utils.$(AUDIT_SELECTORS.BOOKING_CONTACT, element);
    if (contactElement) {
      booking.customerName = contactElement.textContent.trim();
    }
    
    // Extract party size and booking number from the details section
    const detailsElement = utils.$(AUDIT_SELECTORS.BOOKING_DETAILS, element);
    if (detailsElement) {
      const detailsText = detailsElement.textContent;
      
      // Extract booking number (e.g., "#722930")
      const bookingNumberMatch = detailsText.match(AUDIT_SELECTORS.BOOKING_NUMBER_PATTERN);
      if (bookingNumberMatch) {
        booking.bookingNumber = bookingNumberMatch[1];
      }
      
      // Extract party size using generic pattern that works with any customer type names
      const partySizeMatches = detailsText.matchAll(AUDIT_SELECTORS.PARTY_SIZE_PATTERN);
      let totalPartySize = 0;
      
      for (const match of partySizeMatches) {
        const count = parseInt(match[1], 10);
        if (!isNaN(count)) {
          totalPartySize += count;
          console.log(`[availability-audit] Found party size component: ${match[0]} (${count})`);
        }
      }
      
      if (totalPartySize > 0) {
        booking.partySize = totalPartySize;
        console.log(`[availability-audit] Total party size: ${totalPartySize}`);
      }
      
      // Extract resources information
      booking.resources = {
        included: [],
        excluded: []
      };
      
      // Find included resources (e.g., "including Wine Tasting & Lunch")
      const includingMatches = detailsText.matchAll(AUDIT_SELECTORS.RESOURCES_INCLUDING_PATTERN);
      for (const match of includingMatches) {
        const resourcesText = match[1].trim();
        const resources = resourcesText.split(/\s*&\s*|\s*,\s*|\s*\+\s*/).map(r => r.trim()).filter(r => r);
        booking.resources.included.push(...resources);
        console.log(`[availability-audit] Found included resources: ${resources.join(', ')}`);
      }
      
      // Find excluded resources (e.g., "excluding Cheese & Unlimited Drinks")
      const excludingMatches = detailsText.matchAll(AUDIT_SELECTORS.RESOURCES_EXCLUDING_PATTERN);
      for (const match of excludingMatches) {
        const resourcesText = match[1].trim();
        const resources = resourcesText.split(/\s*&\s*|\s*,\s*|\s*\+\s*/).map(r => r.trim()).filter(r => r);
        booking.resources.excluded.push(...resources);
        console.log(`[availability-audit] Found excluded resources: ${resources.join(', ')}`);
      }
    }
    
    // Extract booking date and time
    const dateInfoElement = utils.$(AUDIT_SELECTORS.BOOKING_DATE_INFO, element);
    if (dateInfoElement) {
      const dateText = dateInfoElement.textContent;
      console.log(`[availability-audit] Raw date text for booking ${index}:`, JSON.stringify(dateText));
      
      if (booking.isCancelled) {
        // For cancelled bookings, look for "Last modified:" date
        const cancelledMatch = dateText.match(AUDIT_SELECTORS.CANCELLED_DATE_PATTERN);
        if (cancelledMatch) {
          let dateStr = cancelledMatch[1]; // Regular date like "7/10/25"
          const todayStr = cancelledMatch[2]; // "Today"
          const yesterdayStr = cancelledMatch[3]; // "Yesterday"
          const timeStr = cancelledMatch[4]; // "10:33 AM"
          
          // Handle relative dates
          if (todayStr) {
            const today = new Date();
            dateStr = `${today.getMonth() + 1}/${today.getDate()}/${today.getFullYear().toString().slice(-2)}`;
          } else if (yesterdayStr) {
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            dateStr = `${yesterday.getMonth() + 1}/${yesterday.getDate()}/${yesterday.getFullYear().toString().slice(-2)}`;
          }
          
          booking.cancelledDate = dateStr;
          booking.cancelledTime = timeStr;
          booking.cancelledDatetime = parseDateTime(dateStr, timeStr);
          
          // For cancelled bookings, we use the cancellation date as the primary datetime
          booking.datetime = booking.cancelledDatetime;
        }
      } else {
        // For active bookings, extract the original booking date
        const dateMatch = dateText.match(AUDIT_SELECTORS.DATE_PATTERN);
        console.log(`[availability-audit] Date regex match for booking ${index}:`, dateMatch);
        
        if (dateMatch) {
          let dateStr = dateMatch[1]; // Regular date like "7/10/25"
          const todayStr = dateMatch[2]; // "Today"
          const yesterdayStr = dateMatch[3]; // "Yesterday"
          const timeStr = dateMatch[4]; // "10:33 AM"
          
          console.log(`[availability-audit] Extracted components: date="${dateStr}", today="${todayStr}", yesterday="${yesterdayStr}", time="${timeStr}"`);
          
          // Handle relative dates
          if (todayStr) {
            const today = new Date();
            dateStr = `${today.getMonth() + 1}/${today.getDate()}/${today.getFullYear().toString().slice(-2)}`;
          } else if (yesterdayStr) {
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            dateStr = `${yesterday.getMonth() + 1}/${yesterday.getDate()}/${yesterday.getFullYear().toString().slice(-2)}`;
          }
          
          booking.bookingDate = dateStr;
          booking.bookingTime = timeStr;
          booking.datetime = parseDateTime(dateStr, timeStr);
          
          console.log(`[availability-audit] Final datetime for booking ${index}:`, booking.datetime ? booking.datetime.toISOString() : 'null');
        } else {
          console.warn(`[availability-audit] No date match found for booking ${index}. Raw text: "${dateText}"`);
        }
      }
    }
    
    // Extract status (Paid, Cancelled, etc.)
    const statusElement = utils.$(AUDIT_SELECTORS.STATUS_BADGE, element);
    if (statusElement) {
      const statusText = statusElement.textContent.trim();
      booking.status = statusText;
    }
    
    // If no party size found, default to 1
    if (booking.partySize === 0) {
      booking.partySize = 1;
    }
    
    console.log(`[availability-audit] Extracted booking ${index}:`, {
      customer: booking.customerName,
      partySize: booking.partySize,
      bookingNumber: booking.bookingNumber,
      resources: booking.resources,
      isCancelled: booking.isCancelled,
      originalDate: booking.bookingDate,
      originalTime: booking.bookingTime,
      cancelledDate: booking.cancelledDate,
      cancelledTime: booking.cancelledTime,
      primaryDateTime: booking.datetime ? booking.datetime.toISOString() : null,
      href: booking.bookingHref
    });
    
    // Debug href extraction
    if (booking.bookingHref) {
      console.log(`[availability-audit] ✅ Booking ${index} has href: ${booking.bookingHref}`);
    } else {
      console.log(`[availability-audit] ❌ Booking ${index} missing href! Element:`, element);
    }
    
    return booking;
  }

  // Function to filter bookings up to a specific date/time
  function filterBookingsUpToDateTime(bookings, targetDate, targetTime) {
    console.log(`[availability-audit] Filtering bookings up to ${targetDate} ${targetTime}`);
    
    // Defensive check for bookings array
    if (!bookings || !Array.isArray(bookings)) {
      console.error("[availability-audit] Invalid bookings array provided:", bookings);
      return { filteredBookings: [], error: "Invalid bookings data" };
    }
    
    // Parse target date/time (user input format: YYYY-MM-DD and HH:MM)
    const targetDateTime = new Date(`${targetDate} ${targetTime}`);
    if (isNaN(targetDateTime.getTime())) {
      console.error("[availability-audit] Invalid target date/time provided:", targetDate, targetTime);
      return { filteredBookings: [], error: "Invalid date/time format" };
    }
    
    console.log(`[availability-audit] Target datetime: ${targetDateTime.toISOString()}`);
    console.log(`[availability-audit] Processing ${bookings.length} bookings for filtering`);
    
    const filteredBookings = [];
    const skippedBookings = [];
    
    bookings.forEach((booking, index) => {
      console.log(`[availability-audit] Checking booking ${index}:`, {
        customer: booking.customerName,
        isCancelled: booking.isCancelled,
        bookingDate: booking.bookingDate,
        bookingTime: booking.bookingTime,
        cancelledDate: booking.cancelledDate,
        cancelledTime: booking.cancelledTime,
        datetime: booking.datetime ? booking.datetime.toISOString() : 'null'
      });
      
      if (!booking.datetime) {
        console.warn(`[availability-audit] Booking ${index} has no datetime, excluding from filter`);
        skippedBookings.push(booking);
        return;
      }
      
      let shouldInclude = false;
      let reason = '';
      
      if (booking.isCancelled) {
        // For cancelled bookings: include if cancellation happened AFTER target time
        // (meaning the booking was still active at the target time)
        if (booking.datetime > targetDateTime) {
          shouldInclude = true;
          reason = `cancelled after target time (${booking.datetime.toISOString()} > ${targetDateTime.toISOString()})`;
        } else {
          shouldInclude = false;
          reason = `cancelled before target time (${booking.datetime.toISOString()} <= ${targetDateTime.toISOString()})`;
        }
      } else {
        // For active bookings: include if booking was created BEFORE or AT target time
        if (booking.datetime <= targetDateTime) {
          shouldInclude = true;
          reason = `booked before target time (${booking.datetime.toISOString()} <= ${targetDateTime.toISOString()})`;
        } else {
          shouldInclude = false;
          reason = `booked after target time (${booking.datetime.toISOString()} > ${targetDateTime.toISOString()})`;
        }
      }
      
      if (shouldInclude) {
        console.log(`[availability-audit] Including booking ${index}: ${reason}`);
        filteredBookings.push(booking);
      } else {
        console.log(`[availability-audit] Excluding booking ${index}: ${reason}`);
        skippedBookings.push(booking);
      }
    });
    
    const capacityUsed = filteredBookings.reduce((sum, booking) => sum + booking.partySize, 0);
    
    console.log(`[availability-audit] Filtering complete:`, {
      totalBookings: bookings.length,
      includedBookings: filteredBookings.length,
      skippedBookings: skippedBookings.length,
      totalCapacityUsed: capacityUsed
    });
    
    return {
      filteredBookings,
      totalCapacityUsed: capacityUsed,
      targetDateTime: targetDateTime.toISOString(),
      originalBookingsCount: bookings.length,
      filteredBookingsCount: filteredBookings.length,
      skippedBookingsCount: skippedBookings.length
    };
  }

  // Function to fetch detailed booking information from href URL (optional enhancement)
  async function fetchBookingDetails(bookingHref) {
    try {
      console.log(`[availability-audit] Loading booking details from: ${bookingHref}`);
      
      // Use iframe approach to load the page with user's session
      return new Promise((resolve) => {
        console.log(`[availability-audit] Creating hidden iframe for: ${bookingHref}`);
        
        const iframe = document.createElement('iframe');
        iframe.style.display = 'none';
        iframe.style.position = 'absolute';
        iframe.style.left = '-9999px';
        iframe.style.width = '1px';
        iframe.style.height = '1px';
        
        let timeoutId;
        let resolved = false;
        
        const cleanup = () => {
          if (timeoutId) clearTimeout(timeoutId);
          if (iframe.parentNode) {
            iframe.parentNode.removeChild(iframe);
          }
        };
        
        const resolveOnce = (result) => {
          if (!resolved) {
            resolved = true;
            cleanup();
            resolve(result);
          }
        };
        
        // Set timeout to prevent hanging
        timeoutId = setTimeout(() => {
          console.warn(`[availability-audit] Iframe loading timeout for ${bookingHref}`);
          resolveOnce(null);
        }, 15000); // 15 second timeout
        
        iframe.onload = async () => {
          try {
            console.log(`[availability-audit] Iframe loaded successfully`);
            
            // Wait for any JavaScript to execute and overlay to load
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
            
            if (!iframeDoc) {
              console.error(`[availability-audit] Cannot access iframe document`);
              resolveOnce(null);
              return;
            }
            
            const html = iframeDoc.documentElement.outerHTML;
            console.log(`[availability-audit] Iframe HTML length: ${html.length} characters`);
            
            // Check if we got a login page
            if (html.toLowerCase().includes('login') || html.toLowerCase().includes('log in') || 
                html.toLowerCase().includes('sign in') || html.toLowerCase().includes('authentication')) {
              console.warn(`[availability-audit] ⚠️ Iframe received login page - authentication issue`);
              resolveOnce(null);
              return;
            }
            
            // Check for Eveline to verify we have the right content
            if (html.toLowerCase().includes('eveline')) {
              console.log(`[availability-audit] ✅ Found "Eveline" in iframe HTML!`);
            } else {
              console.log(`[availability-audit] ❌ "Eveline" NOT found in iframe HTML`);
            }
            
            const result = await extractBookingDetailsFromDoc(iframeDoc, html);
            console.log(`[availability-audit] Iframe processing complete, result:`, result);
            resolveOnce(result);
            
          } catch (error) {
            console.error(`[availability-audit] Error processing iframe content:`, error);
            resolveOnce(null);
          }
        };
        
        iframe.onerror = () => {
          console.error(`[availability-audit] Iframe loading error for ${bookingHref}`);
          resolveOnce(null);
        };
        
        // Add iframe to page and start loading
        document.body.appendChild(iframe);
        iframe.src = bookingHref;
        
        console.log(`[availability-audit] Iframe created and loading started`);
      });
      
    } catch (error) {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
          }
        });
        
        if (!fallbackResponse.ok) {
          throw new Error(`HTTP ${fallbackResponse.status}: ${fallbackResponse.statusText}`);
        }
        const html = await fallbackResponse.text();
        console.log(`[availability-audit] Fallback response HTML length: ${html.length} characters`);
        
        // Check if we got a login page instead of booking details
        if (html.toLowerCase().includes('login') || html.toLowerCase().includes('log in') || 
            html.toLowerCase().includes('sign in') || html.toLowerCase().includes('authentication')) {
          console.warn(`[availability-audit] ⚠️ Received login page instead of booking details - authentication issue`);
          return null;
        }
        
        const doc = new DOMParser().parseFromString(html, 'text/html');
        return await extractBookingDetailsFromDoc(doc, html);
      }
      
      const html = await response.text();
      console.log(`[availability-audit] Direct response HTML length: ${html.length} characters`);
      
      // Check if we got a login page instead of booking details
      if (html.toLowerCase().includes('login') || html.toLowerCase().includes('log in') || 
          html.toLowerCase().includes('sign in') || html.toLowerCase().includes('authentication')) {
        console.warn(`[availability-audit] ⚠️ Received login page instead of booking details - authentication issue`);
        return null;
      }
      
      const doc = new DOMParser().parseFromString(html, 'text/html');
      
      return await extractBookingDetailsFromDoc(doc, html);
      
      // Extract resource information from booking detail page
      console.log(`[availability-audit] Searching for resources in booking details`);
      console.log(`[availability-audit] HTML content length: ${html.length} characters`);
      
      // Log a sample of the HTML to see what we're working with
      const htmlSample = html.substring(0, 2000); // First 2000 chars
      console.log(`[availability-audit] HTML sample:`, htmlSample);
      
      // Check if "Eveline" appears anywhere in the HTML
      if (html.toLowerCase().includes('eveline')) {
        console.log(`[availability-audit] ✅ Found "Eveline" in HTML!`);
        // Find all occurrences with context
        const evelineContext = [];
        const lines = html.split('\n');
        lines.forEach((line, lineNum) => {
          if (line.toLowerCase().includes('eveline')) {
            evelineContext.push(`Line ${lineNum}: ${line.trim()}`);
          }
        });
        console.log(`[availability-audit] Eveline contexts:`, evelineContext);
      } else {
        console.log(`[availability-audit] ❌ "Eveline" NOT found in HTML`);
      }
      
      // Look for FareHarbor resource structure specifically
      console.log(`[availability-audit] Looking for FareHarbor resource usage indicators...`);
      
      // Target the specific resource usage indicators
      const resourceUsageIndicators = doc.querySelectorAll('[data-test-id*="resource-usage-indicator"]');
      console.log(`[availability-audit] Found ${resourceUsageIndicators.length} resource usage indicators`);
      
      resourceUsageIndicators.forEach((indicator, indicatorIndex) => {
        console.log(`[availability-audit] Processing resource usage indicator ${indicatorIndex + 1}`);
        console.log(`[availability-audit] Indicator data-test-id: ${indicator.getAttribute('data-test-id')}`);
        
        // Look for invoice tables within this indicator
        const invoiceTables = indicator.querySelectorAll('.invoice-table');
        console.log(`[availability-audit] Found ${invoiceTables.length} invoice tables in indicator ${indicatorIndex + 1}`);
        
        invoiceTables.forEach((table, tableIndex) => {
          console.log(`[availability-audit] Processing table ${tableIndex + 1} in indicator ${indicatorIndex + 1}`);
          
          // Look for fh-grey-new spans that contain resource names
          const greySpans = table.querySelectorAll('.fh-grey-new');
          console.log(`[availability-audit] Found ${greySpans.length} fh-grey-new spans in table`);
          
          greySpans.forEach((span, spanIndex) => {
            const spanText = span.textContent.trim();
            console.log(`[availability-audit] fh-grey-new span ${spanIndex + 1}: "${spanText}"`);
            
            // Check if this span contains a resource name (ends with colon)
            if (spanText.endsWith(':')) {
              const resourceName = spanText.replace(':', '').trim();
              console.log(`[availability-audit] 🎯 Found resource name: "${resourceName}"`);
              
              // Look for the quantity in the next sibling or parent element
              let quantity = null;
              
              // Try to find quantity in next text node
              let nextNode = span.nextSibling;
              while (nextNode) {
                if (nextNode.nodeType === Node.TEXT_NODE) {
                  const text = nextNode.textContent.trim();
                  const num = parseInt(text, 10);
                  if (!isNaN(num) && num > 0) {
                    quantity = num;
                    console.log(`[availability-audit] Found quantity in next text node: ${quantity}`);
                    break;
                  }
                } else if (nextNode.nodeType === Node.ELEMENT_NODE) {
                  const text = nextNode.textContent.trim();
                  const num = parseInt(text, 10);
                  if (!isNaN(num) && num > 0) {
                    quantity = num;
                    console.log(`[availability-audit] Found quantity in next element: ${quantity}`);
                    break;
                  }
                }
                nextNode = nextNode.nextSibling;
              }
              
              // If not found in siblings, check parent's text content
              if (quantity === null) {
                const parentText = span.parentElement?.textContent || '';
                console.log(`[availability-audit] Parent text content: "${parentText}"`);
                const match = parentText.match(new RegExp(resourceName + ':\\s*(\\d+)', 'i'));
                if (match) {
                  quantity = parseInt(match[1], 10);
                  console.log(`[availability-audit] Found quantity in parent text: ${quantity}`);
                }
              }
              
              // Also try looking in the table cell content
              if (quantity === null) {
                const cell = span.closest('td');
                if (cell) {
                  const cellText = cell.textContent.trim();
                  console.log(`[availability-audit] Cell text content: "${cellText}"`);
                  // Look for number after the resource name
                  const cellMatch = cellText.match(new RegExp(resourceName + ':\\s*(\\d+)', 'i'));
                  if (cellMatch) {
                    quantity = parseInt(cellMatch[1], 10);
                    console.log(`[availability-audit] Found quantity in cell text: ${quantity}`);
                  } else {
                    // Try to find standalone number in cell
                    const numbers = cellText.match(/\b\d+\b/g);
                    if (numbers && numbers.length === 1) {
                      quantity = parseInt(numbers[0], 10);
                      console.log(`[availability-audit] Found standalone number in cell: ${quantity}`);
                    }
                  }
                }
              }
              
              if (quantity !== null) {
                const resource = {
                  name: resourceName,
                  quantity: quantity,
                  source: `resource-indicator[${indicatorIndex}] table[${tableIndex}] .fh-grey-new[${spanIndex}]`,
                  text: `${resourceName}: ${quantity}`
                };
                details.resources.detailed.push(resource);
                console.log(`[availability-audit] ✅ Added resource: ${resourceName} (${quantity})`);
              } else {
                console.log(`[availability-audit] ❌ Could not find quantity for resource: ${resourceName}`);
              }
            }
          });
        });
      });
      
      // Legacy resource search (keep as fallback)
      const resourceSelectors = [
        '.resource',
        '.resources',
        '[class*="resource"]',
        '.booking-item',
        '.booking-items',
        '.item-details',
        '.add-ons',
        '.extras',
        '.line-item',
        '.booking-line-item'
      ];
      
      for (const selector of resourceSelectors) {
        const elements = doc.querySelectorAll(selector);
        console.log(`[availability-audit] Selector "${selector}" found ${elements.length} elements`);
        
        elements.forEach((element, index) => {
          const text = element.textContent.trim();
          if (text && text.length > 0 && text.length < 200) { // Reasonable text length
            if (text.toLowerCase().includes('eveline')) {
              console.log(`[availability-audit] 🎯 Found "Eveline" in element ${selector}[${index}]: "${text}"`);
            }
            // Look for resource patterns like "Eveline" with quantity
            // Common patterns: "Eveline: 4", "4x Eveline", "Eveline (4)", "Resource: Eveline - 4"
            const resourcePatterns = [
              /([A-Za-z][A-Za-z\s]+):\s*(\d+)/g,           // "Eveline: 4"
              /(\d+)x?\s+([A-Za-z][A-Za-z\s]+)/g,          // "4x Eveline" or "4 Eveline"
              /([A-Za-z][A-Za-z\s]+)\s*\((\d+)\)/g,        // "Eveline (4)"
              /([A-Za-z][A-Za-z\s]+)\s*[-–]\s*(\d+)/g,     // "Eveline - 4"
              /Resource:\s*([A-Za-z][A-Za-z\s]+).*?(\d+)/g // "Resource: Eveline ... 4"
            ];
            
            for (const pattern of resourcePatterns) {
              const matches = text.matchAll(pattern);
              for (const match of matches) {
                let resourceName, quantity;
                if (pattern.source.startsWith('(\\d+)')) {
                  // Pattern starts with number
                  quantity = parseInt(match[1], 10);
                  resourceName = match[2].trim();
                } else {
                  // Pattern starts with name
                  resourceName = match[1].trim();
                  quantity = parseInt(match[2], 10);
                }
                
                if (resourceName && !isNaN(quantity) && quantity > 0) {
                  const resource = {
                    name: resourceName,
                    quantity: quantity,
                    source: `${selector}[${index}]`,
                    text: text.substring(0, 100) // First 100 chars for context
                  };
                  details.resources.detailed.push(resource);
                  console.log(`[availability-audit] Found resource: ${resourceName} (${quantity})`);
                }
              }
            }
          }
        });
      }
      
      // Also look for any text that might contain "Eveline" or other resource names
      const bodyText = doc.body ? doc.body.textContent : '';
      if (bodyText.toLowerCase().includes('eveline')) {
        console.log(`[availability-audit] Found "Eveline" mentioned in booking details`);
        // Try to extract quantity context around "Eveline"
        const evelineMatches = bodyText.match(/[^.!?]*[Ee]veline[^.!?]*/g);
        if (evelineMatches) {
          evelineMatches.forEach(match => {
            console.log(`[availability-audit] Eveline context: "${match.trim()}"`);
          });
        }
      }
      
      return await extractBookingDetailsFromDoc(doc, html);
      
    } catch (error) {
      console.warn(`[availability-audit] Failed to fetch booking details: ${error.message}`);
      return null;
    }
  }

  // Helper function to extract booking details from document
  async function extractBookingDetailsFromDoc(doc, html) {
    // Extract additional details from the booking page
    const details = {
      actualCapacity: null,
      bookingDetails: null,
      customerInfo: null,
      resources: {
        included: [],
        excluded: [],
        detailed: []
      }
    };
    
    // Look for capacity information in the booking details page
    const capacitySelectors = [
      '[data-test-id*="capacity"]',
      '.capacity',
      '.guest-count',
      '.party-size'
    ];
    
    for (const selector of capacitySelectors) {
      const element = doc.querySelector(selector);
      if (element) {
        details.actualCapacity = extractNumber(element.textContent);
        break;
      }
    }
    
    // Extract resource information from booking detail page
    console.log(`[availability-audit] Searching for resources in booking details`);
    console.log(`[availability-audit] HTML content length: ${html.length} characters`);
    
    // Log a sample of the HTML to see what we're working with
    const htmlSample = html.substring(0, 2000); // First 2000 chars
    console.log(`[availability-audit] HTML sample:`, htmlSample);
    
    // Check if "Eveline" appears anywhere in the HTML
    if (html.toLowerCase().includes('eveline')) {
      console.log(`[availability-audit] ✅ Found "Eveline" in HTML!`);
      // Find all occurrences with context
      const evelineContext = [];
      const lines = html.split('\n');
      lines.forEach((line, lineNum) => {
        if (line.toLowerCase().includes('eveline')) {
          evelineContext.push(`Line ${lineNum}: ${line.trim()}`);
        }
      });
      console.log(`[availability-audit] Eveline contexts:`, evelineContext);
    } else {
      console.log(`[availability-audit] ❌ "Eveline" NOT found in HTML`);
    }
    
    // Look for FareHarbor resource usage indicators
    console.log(`[availability-audit] Looking for FareHarbor resource usage indicators...`);
    
    // Target the specific resource usage indicators
    const resourceUsageIndicators = doc.querySelectorAll('[data-test-id*="resource-usage-indicator"]');
    console.log(`[availability-audit] Found ${resourceUsageIndicators.length} resource usage indicators`);
    
    resourceUsageIndicators.forEach((indicator, indicatorIndex) => {
      console.log(`[availability-audit] Processing resource usage indicator ${indicatorIndex + 1}`);
      console.log(`[availability-audit] Indicator data-test-id: ${indicator.getAttribute('data-test-id')}`);
      
      // Look for invoice tables within this indicator
      const invoiceTables = indicator.querySelectorAll('.invoice-table');
      console.log(`[availability-audit] Found ${invoiceTables.length} invoice tables in indicator ${indicatorIndex + 1}`);
      
      invoiceTables.forEach((table, tableIndex) => {
        console.log(`[availability-audit] Processing table ${tableIndex + 1} in indicator ${indicatorIndex + 1}`);
        
        // Look for fh-grey-new spans that contain resource names
        const greySpans = table.querySelectorAll('.fh-grey-new');
        console.log(`[availability-audit] Found ${greySpans.length} fh-grey-new spans in table`);
        
        greySpans.forEach((span, spanIndex) => {
          const spanText = span.textContent.trim();
          console.log(`[availability-audit] fh-grey-new span ${spanIndex + 1}: "${spanText}"`);
          
          // Check if this span contains a resource name (ends with colon)
          if (spanText.endsWith(':')) {
            const resourceName = spanText.replace(':', '').trim();
            console.log(`[availability-audit] 🎯 Found resource name: "${resourceName}"`);
            
            // Look for the quantity in the next sibling or parent element
            let quantity = null;
            
            // Try to find quantity in next text node
            let nextNode = span.nextSibling;
            while (nextNode) {
              if (nextNode.nodeType === Node.TEXT_NODE) {
                const text = nextNode.textContent.trim();
                const num = parseInt(text, 10);
                if (!isNaN(num) && num > 0) {
                  quantity = num;
                  console.log(`[availability-audit] Found quantity in next text node: ${quantity}`);
                  break;
                }
              } else if (nextNode.nodeType === Node.ELEMENT_NODE) {
                const text = nextNode.textContent.trim();
                const num = parseInt(text, 10);
                if (!isNaN(num) && num > 0) {
                  quantity = num;
                  console.log(`[availability-audit] Found quantity in next element: ${quantity}`);
                  break;
                }
              }
              nextNode = nextNode.nextSibling;
            }
            
            // If not found in siblings, check parent's text content
            if (quantity === null) {
              const parentText = span.parentElement?.textContent || '';
              console.log(`[availability-audit] Parent text content: "${parentText}"`);
              const match = parentText.match(new RegExp(resourceName + ':\\s*(\\d+)', 'i'));
              if (match) {
                quantity = parseInt(match[1], 10);
                console.log(`[availability-audit] Found quantity in parent text: ${quantity}`);
              }
            }
            
            // Also try looking in the table cell content
            if (quantity === null) {
              const cell = span.closest('td');
              if (cell) {
                const cellText = cell.textContent.trim();
                console.log(`[availability-audit] Cell text content: "${cellText}"`);
                // Look for number after the resource name
                const cellMatch = cellText.match(new RegExp(resourceName + ':\\s*(\\d+)', 'i'));
                if (cellMatch) {
                  quantity = parseInt(cellMatch[1], 10);
                  console.log(`[availability-audit] Found quantity in cell text: ${quantity}`);
                } else {
                  // Try to find standalone number in cell
                  const numbers = cellText.match(/\b\d+\b/g);
                  if (numbers && numbers.length === 1) {
                    quantity = parseInt(numbers[0], 10);
                    console.log(`[availability-audit] Found standalone number in cell: ${quantity}`);
                  }
                }
              }
            }
            
            if (quantity !== null) {
              const resource = {
                name: resourceName,
                quantity: quantity,
                source: `resource-indicator[${indicatorIndex}] table[${tableIndex}] .fh-grey-new[${spanIndex}]`,
                text: `${resourceName}: ${quantity}`
              };
              details.resources.detailed.push(resource);
              console.log(`[availability-audit] ✅ Added resource: ${resourceName} (${quantity})`);
            } else {
              console.log(`[availability-audit] ❌ Could not find quantity for resource: ${resourceName}`);
            }
          }
        });
      });
    });
    
    return details;
  }

  // Main audit function called from popup
  async function runAvailabilityAudit(targetDate, targetTime, fetchDetailedInfo = false) {
    console.log(`[availability-audit] AUDIT STARTED - fetchDetailedInfo: ${fetchDetailedInfo}`);
    console.log(`[availability-audit] Running audit for ${targetDate} ${targetTime} (detailed: ${fetchDetailedInfo})`);
    
    try {
      // First, scrape all available booking data
      const availabilityData = await scrapeAvailabilityData();
      
      if (availabilityData.error) {
        return { success: false, error: availabilityData.error };
      }
      
      // Defensive check for bookings data
      if (!availabilityData.bookings || !Array.isArray(availabilityData.bookings)) {
        console.error("[availability-audit] Invalid bookings data structure:", availabilityData);
        return { success: false, error: "Invalid bookings data received from scraper" };
      }
      
      // Optionally fetch detailed information for each booking
      if (fetchDetailedInfo && availabilityData.bookings.length > 0) {
        console.log(`[availability-audit] DETAILED INFO ENABLED - Processing ${availabilityData.bookings.length} bookings`);
        
        for (let i = 0; i < availabilityData.bookings.length; i++) {
          const booking = availabilityData.bookings[i];
          console.log(`[availability-audit] Processing booking ${i + 1}: bookingHref = ${booking.bookingHref}`);
          
          if (booking.bookingHref) {
            console.log(`[availability-audit] Fetching details for booking ${i + 1}/${availabilityData.bookings.length} - URL: ${booking.bookingHref}`);
            const details = await fetchBookingDetails(booking.bookingHref);
            
            console.log(`[availability-audit] Received details for booking ${i + 1}:`, details);
            
            if (details) {
              booking.detailedInfo = details;
              
              // Use detailed capacity if available, otherwise keep the scraped value
              if (details.actualCapacity && details.actualCapacity > 0) {
                booking.partySize = details.actualCapacity;
              }
            }
          }
        }
      }
      
      // Then filter to the target date/time
      const filteredData = filterBookingsUpToDateTime(
        availabilityData.bookings, 
        targetDate, 
        targetTime
      );
      
      if (filteredData.error) {
        return { success: false, error: filteredData.error };
      }
      
      // Combine the results
      const result = {
        success: true,
        audit: {
          ...availabilityData,
          ...filteredData,
          summary: {
            totalBookingsFound: availabilityData.bookings.length,
            bookingsUpToTarget: filteredData.filteredBookingsCount,
            totalCapacityUsed: filteredData.totalCapacityUsed,
            targetDate,
            targetTime,
            auditedAt: new Date().toISOString(),
            detailedInfoFetched: fetchDetailedInfo
          }
        }
      };
      
      console.log("[availability-audit] Audit completed successfully:", result);
      return result;
      
    } catch (error) {
      console.error("[availability-audit] Audit failed:", error);
      return { 
        success: false, 
        error: error.message,
        details: error.stack 
      };
    }
  }

  // Message handling for availability audit actions
  function handleMessage(req, sender, sendResponse) {
    console.log("[availability-audit] Message received:", req);
    console.log(`[availability-audit] Processing ${req.action} with fetchDetailedInfo: ${req.fetchDetailedInfo}`);

    if (req.action === "runAvailabilityAudit") {
      (async () => {
        try {
          const result = await runAvailabilityAudit(
            req.targetDate, 
            req.targetTime, 
            req.fetchDetailedInfo || false
          );
          sendResponse(result);
        } catch (error) {
          console.error("[availability-audit] Error handling audit request:", error);
          sendResponse({ 
            success: false, 
            error: error.message 
          });
        }
      })();
      return true;
    }

    if (req.action === "getAvailabilityPageInfo") {
      (async () => {
        try {
          const pageType = detectPageType();
          const sampleData = await scrapeAvailabilityData();
          
          sendResponse({ 
            success: true,
            pageInfo: {
              pageType,
              url: window.location.href,
              bookingsFound: sampleData.bookings.length,
              canAudit: sampleData.bookings.length > 0  // If we find bookings, we can audit
            }
          });
        } catch (error) {
          sendResponse({ 
            success: false, 
            error: error.message 
          });
        }
      })();
      return true;
    }

    return false; // Not handled by this module
  }

  // Export the module
  window.AvailabilityAudit = {
    handleMessage,
    runAvailabilityAudit,
    scrapeAvailabilityData,
    detectPageType,
    fetchBookingDetails,
    ensureBookingSectionsExpanded
  };

  console.log("[availability-audit] Module initialized successfully");

})(); // End of initialization function
