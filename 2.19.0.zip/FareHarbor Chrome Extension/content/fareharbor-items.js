console.log("[fareharbor-items] fareharbor-items.js loaded");

// Wait for utilities to be available and initialize module
(function initializeFareHarborItems() {
  // Wait for FareHarborUtils to be available
  if (!window.FareHarborUtils) {
    setTimeout(initializeFareHarborItems, 10);
    return;
  }
  
  // Now utilities are available, set up the module
  const utils = window.FareHarborUtils;

  // FareHarbor Items data extraction function
  function scrapeFareHarborItems() {
    const result = [];
    
    console.log("[fareharbor-items] Scraping FareHarbor items...");
    
    // Find the item table with data-test-id="item-table-list"
    const itemTable = document.querySelector('table[data-test-id="item-table-list"]');
    if (!itemTable) {
      console.warn("[fareharbor-items] Item table not found (looking for data-test-id='item-table-list')");
      return null;
    }
    
    console.log("[fareharbor-items] Found item table");
    
    // Find all tbody elements (each item is in a separate tbody)
    const tbodies = itemTable.querySelectorAll('tbody');
    console.log(`[fareharbor-items] Found ${tbodies.length} tbody elements`);
    
    tbodies.forEach((tbody, index) => {
      // Find the ID cell (td.ss-pk with ng-if="itemFilters.showIds")
      const idCell = tbody.querySelector('td.ss-pk[ng-if="itemFilters.showIds"]');
      
      // Find the name cell (td containing an anchor with data-test-id starting with "item-list-")
      // The name is in a <b> tag inside the anchor
      const nameAnchor = tbody.querySelector('a[data-test-id^="item-list-"]');
      
      if (idCell && nameAnchor) {
        // Extract the ID from the link text inside the ID cell
        const idLink = idCell.querySelector('a');
        const itemId = idLink ? idLink.textContent.trim() : '';
        
        // Extract the name from the <b> tag inside the name anchor
        const nameElement = nameAnchor.querySelector('b');
        const itemName = nameElement ? nameElement.textContent.trim() : nameAnchor.textContent.trim();
        
        if (itemId && itemName) {
          result.push({
            id: itemId,
            name: itemName
          });
          console.log(`[fareharbor-items] Extracted item ${index + 1}: ID=${itemId}, Name=${itemName}`);
        } else {
          console.warn(`[fareharbor-items] Skipped tbody ${index + 1} - missing ID or name (ID: "${itemId}", Name: "${itemName}")`);
        }
      } else {
        // This could be header row or item without ID column shown
        console.log(`[fareharbor-items] Skipped tbody ${index + 1} - ID cell or name anchor not found`);
      }
    });
    
    console.log(`[fareharbor-items] Successfully extracted ${result.length} items`);
    return result;
  }
  
  // Format data as TSV for Google Sheets (tab-separated values)
  function formatAsTSV(data) {
    if (!data || data.length === 0) {
      return '';
    }
    
    // TSV headers for Google Sheets compatibility
    const headers = ['Item ID', 'Item Name'];
    
    // Start with headers (using tabs for Google Sheets)
    const tsvLines = [headers.join('\t')];
    
    // Add data rows (using tabs for Google Sheets)
    data.forEach(item => {
      const row = [
        escapeTsvField(item.id),
        escapeTsvField(item.name)
      ];
      tsvLines.push(row.join('\t'));
    });
    
    return tsvLines.join('\n');
  }
  
  function escapeTsvField(field) {
    if (!field) return '';
    
    // Convert to string and trim
    const str = String(field).trim();
    
    // For TSV, replace tabs, newlines, and carriage returns with spaces
    return str.replace(/[\t\n\r]/g, ' ');
  }

  // Message handling for FareHarbor Items actions
  function handleMessage(req, sender, sendResponse) {
    console.log("[fareharbor-items] Message received:", req);

    if (req.action === "runFareHarborItemsExtract") {
      const data = scrapeFareHarborItems();
      
      if (!data || data.length === 0) {
        sendResponse({ 
          success: false, 
          error: "No FareHarbor items found on this page. Make sure you're on the Items list page and the ID column is visible." 
        });
        return true;
      }
      
      const tsvData = formatAsTSV(data);
      
      sendResponse({ 
        success: true, 
        data: data,
        tsvData: tsvData,
        count: data.length
      });
      
      return true; // Indicates we handled the message
    }

    return false; // Not handled by this module
  }

  // Export the module
  window.FareHarborItems = {
    handleMessage,
    scrapeFareHarborItems,
    formatAsTSV
  };

  console.log("[fareharbor-items] Module initialized successfully");

})(); // End of initialization function


