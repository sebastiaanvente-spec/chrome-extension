(function () {
  const originalConfirm = window.confirm;
  window.confirm = function (message) {
    if (message.includes("Are you sure you want to duplicate this customer type?")) {
      return true;
    }
    return originalConfirm(message);
  };
})();
