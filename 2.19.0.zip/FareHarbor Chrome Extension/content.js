console.log("[content] content.js loaded");

// Constants
const SELECTORS = {
  EDIT_CUSTOMER_TYPE_BTN: 'button[data-test-id="edit-customer-type-button"]',
  DUPLICATE_CUSTOMER_TYPE_BTN: 'button[data-test-id="duplicate-customer-type-button"]',
  CONFIRM_DUPLICATE_BTN: 'button[data-test-id="submit-duplicate-customer-type-button"]',
  SAVE_EDIT_BTN: 'button[data-test-id="save-customer-type-update-button"]',
  NAME_INPUT: 'input[name="name"]',
  MIN_PARTY_SIZE_INPUT: 'input[name="minimumPartySize"]',
  MAX_PARTY_SIZE_INPUT: 'input[name="maximumPartySize"]',
  CUSTOMER_TYPE_BLOCKS: 'div[ng-controller="dashboard.items.item.CustomerPrototypeEditableCtrl"]',
  CUSTOMER_TYPE_NAME: '[data-test-id="customer-type-name"] span',
  PROTOTYPE_INDICATOR: '[data-test-id$="-prototype-indicator"]',
  SPREADSHEET_TABLE: 'table.spreadsheet',
  TABS_LINK: 'ul.tabs a[href*="/items/"]'
};

const TIMEOUTS = {
  DEFAULT_WAIT: 500,
  CONFIRM_BUTTON: 5000,
  EDIT_FORM: 5000,
  RENAMED_CUSTOMER_TYPE: 10000,
  SAVE_COMPLETION: 8000,
  CLEAN_STATE: 3000,
  BUTTON_INTERACTIVE: 4000,
  POLLING_INTERVAL: 150
};

// Inject confirm override script into page context
(function injectScriptFile() {
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('inject.js');
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);
})();

// Utility functions
function $(selector, context = document) {
  return context.querySelector(selector);
}

function $$(selector, context = document) {
  return Array.from(context.querySelectorAll(selector));
}

function setInputValue(input, value) {
  if (!input) return false;
  
  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  nativeSetter.call(input, value);
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  return true;
}

function createPollingPromise(checkFn, timeout, interval = TIMEOUTS.POLLING_INTERVAL) {
  console.log(`Starting polling with timeout: ${timeout}ms, interval: ${interval}ms`);
  
  return new Promise((resolve, reject) => {
    const start = Date.now();
    let intervalId;
    
    const check = () => {
      const result = checkFn();
      if (result) {
        clearInterval(intervalId);
        const elapsed = Date.now() - start;
        console.log(`Polling succeeded after ${elapsed}ms`);
        resolve(result);
        return;
      }
      
      if (Date.now() - start > timeout) {
        clearInterval(intervalId);
        const elapsed = Date.now() - start;
        console.error(`Polling timed out after ${elapsed}ms (timeout was ${timeout}ms)`);
        reject(new Error(`Polling timed out after ${timeout}ms`));
      }
    };
    
    intervalId = setInterval(check, interval);
    check(); // Check immediately
  });
}

// Optimized click helpers
function clickButton(selector, context = document, logMessage = '') {
  const btn = $(selector, context);
  if (btn) {
    btn.click();
    if (logMessage) console.log(logMessage);
    return true;
  }
  console.warn(`Button not found: ${selector}`);
  return false;
}

function clickEditCustomerTypeButton() {
  return clickButton(SELECTORS.EDIT_CUSTOMER_TYPE_BTN);
}

function clickDuplicateCustomerTypeButton() {
  return clickButton(SELECTORS.DUPLICATE_CUSTOMER_TYPE_BTN);
}

function clickConfirmDuplicateButton() {
  return clickButton(SELECTORS.CONFIRM_DUPLICATE_BTN);
}

function clickSaveEditForm() {
  return clickButton(SELECTORS.SAVE_EDIT_BTN, document, 'Clicked Save');
}


// Renaming logic
function renameEditInput(newName) {
  const input = $(SELECTORS.NAME_INPUT);
  if (!input) {
    console.warn("Rename input not found.");
    return false;
  }
  
  return setInputValue(input, newName);
}



// Timing helpers
function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function waitForConfirmButton(timeout = TIMEOUTS.CONFIRM_BUTTON) {
  return createPollingPromise(() => $(SELECTORS.CONFIRM_DUPLICATE_BTN), timeout);
}

function waitForEditForm(timeout = TIMEOUTS.EDIT_FORM) {
  return createPollingPromise(() => $(SELECTORS.NAME_INPUT), timeout);
}

// Intelligent waiting functions for UI state changes
function waitForDuplicateButton(timeout = TIMEOUTS.CONFIRM_BUTTON) {
  return createPollingPromise(() => $(SELECTORS.DUPLICATE_CUSTOMER_TYPE_BTN), timeout);
}

function waitForEditButtonInteractive(block, timeout = TIMEOUTS.BUTTON_INTERACTIVE) {
  return createPollingPromise(() => {
    const btn = $(SELECTORS.EDIT_CUSTOMER_TYPE_BTN, block);
    // Check if button exists and is not disabled
    if (btn && !btn.disabled && !btn.classList.contains('disabled')) {
      console.log("Edit button is interactive and ready");
      return true;
    }
    return false;
  }, timeout);
}

function waitForFormClosure(timeout = TIMEOUTS.CLEAN_STATE) {
  return createPollingPromise(() => {
    // Form is closed when name input is no longer present
    const formOpen = $(SELECTORS.NAME_INPUT);
    if (!formOpen) {
      console.log("Form successfully closed");
      return true;
    }
    return false;
  }, timeout);
}

function waitForDuplicateCompletion(previousBlockCount, timeout = TIMEOUTS.RENAMED_CUSTOMER_TYPE) {
  return createPollingPromise(() => {
    const currentBlocks = getCustomerTypeBlocks();
    // Duplicate is complete when we have more blocks than before
    return currentBlocks.length > previousBlockCount ? currentBlocks : null;
  }, timeout, 200);
}

function waitForSaveCompletion(expectedName, timeout = TIMEOUTS.SAVE_COMPLETION) {
  console.log(`Waiting for save completion of: "${expectedName}"`);
  let formWasOpen = true; // Track if form was initially open
  
  return createPollingPromise(() => {
    // Primary method: Look for a block with the expected name
    const blocks = getCustomerTypeBlocks();
    console.log(`Checking ${blocks.length} blocks for name: "${expectedName}"`);
    
    const foundBlock = blocks.find(block => {
      const nameSpan = $(SELECTORS.CUSTOMER_TYPE_NAME, block);
      if (nameSpan) {
        const currentName = nameSpan.textContent.trim();
        console.log(`Found block with name: "${currentName}"`);
        return currentName === expectedName;
      }
      return false;
    });
    
    if (foundBlock) {
      console.log(`Save completion detected for: "${expectedName}"`);
      return foundBlock;
    }
    
    // Fallback method: If form was open and now closed, consider save complete
    const formStillOpen = $(SELECTORS.NAME_INPUT);
    if (formWasOpen && !formStillOpen) {
      console.log("Save likely completed - form was closed");
      // Double-check after a brief moment
      return true; // Consider this a successful save
    }
    
    // Update our tracking of form state
    if (formStillOpen) {
      formWasOpen = true;
    }
    
    return null;
  }, timeout, TIMEOUTS.POLLING_INTERVAL);
}

// Alternative save completion method with more generous timeout
async function waitForSaveCompletionRobust(expectedName) {
  console.log(`Using robust save completion detection for: "${expectedName}" with ${TIMEOUTS.SAVE_COMPLETION}ms timeout`);
  
  try {
    // First try the normal method with explicit timeout
    console.log(`Calling waitForSaveCompletion with timeout: ${TIMEOUTS.SAVE_COMPLETION}ms`);
    return await waitForSaveCompletion(expectedName, TIMEOUTS.SAVE_COMPLETION);
  } catch (error) {
    console.log(`Primary save detection failed: ${error.message}, trying fallback method...`);
    
    // Fallback: Just wait for form to close, then give extra time for UI update
    try {
      console.log(`Calling waitForFormClosure with timeout: ${TIMEOUTS.CLEAN_STATE}ms`);
      await waitForFormClosure(TIMEOUTS.CLEAN_STATE);
      console.log("Form closed, giving extra time for UI to update...");
      await wait(1000); // Extra time for UI to update
      
      // Final check for the expected name
      const blocks = getCustomerTypeBlocks();
      const finalBlock = blocks.find(block => {
        const nameSpan = $(SELECTORS.CUSTOMER_TYPE_NAME, block);
        return nameSpan && nameSpan.textContent.trim() === expectedName;
      });
      
      if (finalBlock) {
        console.log(`Found expected name after fallback: "${expectedName}"`);
        return finalBlock;
      } else {
        console.log("Fallback completed but name not found - considering save successful anyway");
        return true; // Consider it successful even if we can't find the exact name
      }
    } catch (fallbackError) {
      console.warn(`Both primary and fallback save detection failed: ${fallbackError.message}, but continuing...`);
      return true; // Continue anyway
    }
  }
}

function waitForCleanState(timeout = TIMEOUTS.CLEAN_STATE) {
  console.log("Waiting for clean UI state...");
  
  return createPollingPromise(() => {
    // Clean state: no forms open, no duplicate buttons visible, no loading states
    const hasForm = $(SELECTORS.NAME_INPUT);
    const hasDuplicateBtn = $(SELECTORS.DUPLICATE_CUSTOMER_TYPE_BTN);
    const hasConfirmBtn = $(SELECTORS.CONFIRM_DUPLICATE_BTN);
    
    // Clean state is when there's no form, no duplicate button, and no confirm button visible
    const isClean = !hasForm && !hasDuplicateBtn && !hasConfirmBtn;
    
    if (isClean) {
      console.log("Clean state achieved");
      return true;
    } else {
      console.log(`UI not clean yet - Form: ${!!hasForm}, DuplicateBtn: ${!!hasDuplicateBtn}, ConfirmBtn: ${!!hasConfirmBtn}`);
    }
    
    return false;
  }, timeout);
}

// DOM parsing helpers
function getCustomerTypeBlocks() {
  return $$(SELECTORS.CUSTOMER_TYPE_BLOCKS);
}

function clickEditLink(blockElement) {
  return clickButton(SELECTORS.EDIT_CUSTOMER_TYPE_BTN, blockElement, 'Clicked edit button inside block');
}

function waitForRenamedCustomerType(previousNames, timeout = TIMEOUTS.RENAMED_CUSTOMER_TYPE) {
  return createPollingPromise(() => {
    const blocks = getCustomerTypeBlocks();
    
    for (const block of blocks) {
      console.log("Checking for new names...");
      const nameSpan = $(SELECTORS.PROTOTYPE_INDICATOR, block);
      if (!nameSpan) continue;

      const name = nameSpan.textContent.trim();
      if (!previousNames.has(name)) {
        console.log("Found new name:", name);
        return block;
      }
    }
    return null;
  }, timeout, 200);
}


function setPartySizeFields(value) {
  const minInput = $(SELECTORS.MIN_PARTY_SIZE_INPUT);
  const maxInput = $(SELECTORS.MAX_PARTY_SIZE_INPUT);

  let success = true;
  
  if (setInputValue(minInput, value)) {
    console.log("Set minimumPartySize to", value);
  } else {
    console.warn("minimumPartySize input not found");
    success = false;
  }

  if (setInputValue(maxInput, value)) {
    console.log("Set maximumPartySize to", value);
  } else {
    console.warn("maximumPartySize input not found");
    success = false;
  }
  
  return success;
}



// Main loop
async function runMultipleDuplicates(count, basename, baseIndex = 0) {

  const pad = num => String(num).padStart(2, '0');

  const blocks = getCustomerTypeBlocks();
  blocks.forEach((block, i) => {
    const name = block.querySelector('[data-test-id="customer-type-name"] span')?.textContent.trim();
    console.log(`[${i}] Block:`, name);
  });

  const baseBlock = getCustomerTypeBlocks()[baseIndex];
  console.log("Using baseIndex:", baseIndex);
  if (!baseBlock) {
    console.error("Selected base block not found");
    return;
  }

  const baseName = baseBlock.querySelector('[data-test-id="customer-type-name"] span')?.textContent.trim();
  console.log("→ BaseBlock name is:", baseName);
  
  const editBtn = baseBlock.querySelector('button[data-test-id="edit-customer-type-button"]');
  if (!editBtn) {
    console.error("Edit button not found in selected block");
    return;
  }

  for (let i = 0; i < count; i++) {
    console.log(`[${i + 1}/${count}] Starting duplicate`);
    
    try {
      // Ensure we start from a clean state
      console.log("Waiting for clean state before starting iteration...");
      await waitForCleanState();
      console.log("Clean state confirmed, proceeding with duplication");
      // Re-find the base block for each iteration to ensure we have a fresh reference
      const currentBlocks = getCustomerTypeBlocks();
      const currentBaseBlock = currentBlocks[baseIndex];
      
      if (!currentBaseBlock) {
        console.error("Base block not found at index", baseIndex);
        throw new Error(`Base block not found at index ${baseIndex}`);
      }

      // Find the edit button for the current base block
      const currentEditBtn = $(SELECTORS.EDIT_CUSTOMER_TYPE_BTN, currentBaseBlock);
      if (!currentEditBtn) {
        console.error("Edit button not found in base block");
        throw new Error("Edit button not found in base block");
      }

      // Get current state before starting duplication
      const existingNames = new Set();
      const initialBlockCount = currentBlocks.length;
      currentBlocks.forEach(block => {
        const nameSpan = $(SELECTORS.CUSTOMER_TYPE_NAME, block);
        if (nameSpan) existingNames.add(nameSpan.textContent.trim());
      });

      console.log(`Current block count: ${initialBlockCount}, existing names: ${existingNames.size}`);

      // Click the base block's edit button
      currentEditBtn.click();
      console.log("Clicked edit button, waiting for duplicate button...");
      
      // Wait for duplicate button to appear (indicates edit mode is ready)
      await waitForDuplicateButton();
      console.log("Duplicate button is available");

      if (!clickDuplicateCustomerTypeButton()) {
        throw new Error("Failed to click duplicate button");
      }
      
      await waitForConfirmButton();
      
      if (!clickConfirmDuplicateButton()) {
        throw new Error("Failed to click confirm button");
      }
      console.log("Clicked confirm, waiting for duplication to complete...");

      // Wait for the duplicate operation to actually complete by checking block count
      await waitForDuplicateCompletion(initialBlockCount);
      console.log("Duplication completed, new block detected");

      const newBlock = await waitForRenamedCustomerType(existingNames);
      console.log("New customer type block found");

      // Wait for edit button to become interactive before clicking
      await waitForEditButtonInteractive(newBlock);
      console.log("Edit button is interactive");
      
      if (!clickEditLink(newBlock)) {
        throw new Error("Failed to click edit link on new block");
      }
      console.log("Clicked edit on new block");

      await waitForEditForm();
      console.log("Edit form opened");

      const newName = `${basename} ${pad(i + 1)}-${pad(i + 1)}`;
      if (!renameEditInput(newName)) {
        throw new Error("Failed to rename input");
      }
      console.log("Renamed to:", newName);

      const shortVal = pad(i + 1);
      setPartySizeFields(shortVal);

      if (!clickSaveEditForm()) {
        throw new Error("Failed to click save button");
      }
      console.log("Clicked save, waiting for save completion...");
      
      // Wait for save to complete using robust detection
      await waitForSaveCompletionRobust(newName);
      console.log("Save completed successfully");

      // Wait for form to close before starting next iteration
      await waitForFormClosure();
      console.log("Form closed, ready for next iteration");
      
    } catch (error) {
      console.error(`Error in duplicate ${i + 1}:`, error);
      
      // Try to recover by ensuring we're in a clean state
      try {
        console.log("Attempting to recover from error...");
        
        // First try to close any open forms by pressing escape key
        if ($(SELECTORS.NAME_INPUT)) {
          console.log("Form is open, attempting to close with escape key");
          document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
          await wait(500);
        }
        
        // Wait for clean state
        await waitForCleanState().catch(() => {
          console.log("Could not achieve clean state, forcing recovery wait");
        });
        
        // Additional recovery wait to let UI settle
        await wait(1000);
        
        console.log("Recovery attempt completed, continuing with next iteration");
      } catch (recoveryError) {
        console.warn("Could not fully recover from error:", recoveryError);
        // Continue anyway but with a longer wait and forced clean state attempt
        console.log("Forcing longer recovery wait...");
        await wait(3000);
      }
    }
  }
}



// Handle extension messages
chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  console.log("[content] Message received:", req);

  if (req.action === "getCustomerTypes") {
  const blocks = getCustomerTypeBlocks();
  const list = [];

  blocks.forEach((block, i) => {
    const nameSpan = block.querySelector('[data-test-id="customer-type-name"] span');
    if (!nameSpan) return;

    const name = nameSpan.textContent.trim();
    if (name) list.push({ domIndex: i, name });
  });

  sendResponse({ customerTypes: list });
  return true;
}



  if (req.action === "runDuplicate") {
    (async () => {
      try {
        console.log("[content] Running simple duplicate");

        // Store existing customer type names
        const existingNames = new Set();
        getCustomerTypeBlocks().forEach(block => {
          const nameSpan = block.querySelector('[data-test-id$="-prototype-indicator"]');
          if (nameSpan) existingNames.add(nameSpan.textContent.trim());
        });

        console.log("Existing customer type names:");
        existingNames.forEach(name => console.log(" -", name));


        const initialBlockCount = getCustomerTypeBlocks().length;
        
        clickEditCustomerTypeButton();
        console.log("Clicked edit button, waiting for duplicate button...");
        
        // Wait for duplicate button to appear
        await waitForDuplicateButton();
        console.log("Duplicate button is available");

        clickDuplicateCustomerTypeButton();
        await waitForConfirmButton();
        clickConfirmDuplicateButton();
        console.log("Clicked confirm, waiting for duplication to complete...");

        // Wait for duplication to actually complete
        await waitForDuplicateCompletion(initialBlockCount);
        console.log("Duplication completed");

        // 🔁 Wait for block with a *new* customer type name
        const newBlock = await waitForRenamedCustomerType(existingNames, 8000);
        console.log("New customer type block found");

        // Wait for edit button to become interactive
        await waitForEditButtonInteractive(newBlock);
        console.log("Edit button is interactive");
        
        clickEditLink(newBlock);
        console.log("Clicked edit on new block");

        await waitForEditForm();
        console.log("Edit form opened");

        const baseNameSpan = $(SELECTORS.CUSTOMER_TYPE_NAME);
        const baseName = baseNameSpan ? baseNameSpan.textContent.trim() : "Untitled";
        console.log("Original base name:", baseName);

        const newName = `${baseName} 01-01`;
        renameEditInput(newName);
        console.log("Renamed to:", newName);

        clickSaveEditForm();
        console.log("Clicked save, waiting for save completion...");
        
        // Wait for save to complete using robust detection
        await waitForSaveCompletionRobust(newName);
        console.log("Save completed successfully");

        sendResponse({ status: "done" });
      } catch (err) {
        console.error("[runDuplicate] Error occurred:", err);
        sendResponse({ status: "error", error: err.message });
      }
    })();

    return true;
  }

  if (req.action === "runMultipleDuplicates") {
    (async () => {
      try {
        console.log("[content] Running multiple duplicates");
        await runMultipleDuplicates(req.count, req.basename, req.baseIndex);
        sendResponse({ status: "done" });
      } catch (err) {
        console.error("[runMultipleDuplicates] Error occurred:", err);
        sendResponse({ status: "error", error: err.message });
      }
    })();

    return true;
  }
});





// Extract Expedia Data

function scrapeResellerOptions() {
  const result = [];

  // Each <tbody> represents one row
  const bodies = document.querySelectorAll('table.spreadsheet > tbody');

  bodies.forEach(tbody => {
    const tds = tbody.querySelectorAll('td');
    const time = tds[0]?.innerText.trim() || '';
    const code = tds[2]?.innerText.trim() || '';

    if (time && code) {
      result.push([time, code]);
    }
  });

  return result;
}

function scrapeCustomerTypes() {
  const result = [];

  const bodies = document.querySelectorAll('table.spreadsheet > tbody');

  bodies.forEach(tbody => {
    const tds = tbody.querySelectorAll('td');
    const name = tds[0]?.innerText.trim() || '';
    const externalId = tds[2]?.innerText.trim() || '';

    if (name && externalId) {
      result.push([name, externalId]);
    }
  });

  return result;
}

function getItemCode() {
  const link = $(SELECTORS.TABS_LINK);
  const match = link?.href.match(/\/items\/(\d+)\//);
  return match ? `ri${match[1]}` : null;
}

function scrapeCombinedData() {
  const result = [];
  const itemCode = getItemCode();

  if (!itemCode) {
    console.warn("[content] Item code not found");
    return null;
  }

  // Add the "Activity" row
  result.push(['Activity', '', itemCode]);

  const tables = $$(SELECTORS.SPREADSHEET_TABLE);

  // 🔹 Reseller Options Table
  const resellerTable = tables.find(t => {
    const header = t.querySelector('thead')?.innerText || '';
    return header.includes('External Identifier') && !header.includes('Customer Types Used');
  });

  const resellerBodies = resellerTable?.querySelectorAll('tbody') || [];
  resellerBodies.forEach(tbody => {
    const tds = tbody.querySelectorAll('td');
    const time = tds[0]?.innerText.trim();
    const optionCode = tds[2]?.innerText.trim();
    if (time && optionCode) {
      result.push(['Offer', time, optionCode]);
    }
  });

  // 🔹 Customer Types Table
  const customerTypesTable = tables.find(t => {
    const header = t.querySelector('thead')?.innerText || '';
    return header.includes('Customer Types Used');
  });

  const customerBodies = customerTypesTable?.querySelectorAll('tbody') || [];
  customerBodies.forEach(tbody => {
    const tds = tbody.querySelectorAll('td');
    const name = tds[0]?.innerText.trim();
    const externalId = tds[2]?.innerText.trim();
    if (name && externalId) {
      result.push(['TicketType', name, externalId]);
    }
  });

  return result;
}

function copyToClipboard(data) {
  const text = data.map(row => row.join('\t')).join('\n');
  navigator.clipboard.writeText(text)
    .then(() => console.log("Data copied to clipboard"))
    .catch(err => console.error("Clipboard copy failed", err));
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "runExtract") {
    const data = scrapeCombinedData();
    sendResponse({ data }); // Send it back to the popup
  }
  return true; // keep message channel alive for async sendResponse
});


