/**
 * MV3 service worker: fetch remote version.json, compare versions, persist to chrome.storage.local.
 * Listeners are registered synchronously at load (MV3-safe). Alarm + onInstalled/onStartup call the same runUpdateCheck.
 *
 * Other extension code can read chrome.storage.local:
 * - belowMinimumSupportedVersion (boolean): true if installed version is below minimumSupportedVersion from the last successful fetch — use to gate risky features.
 * - updateAvailable, latestVersion, downloadUrl, releaseNotes, updateCheckStatus ('ok'|'error'), etc.
 */
importScripts('version-utils.js');

var VERSION_JSON_URL =
  'https://raw.githubusercontent.com/sebastiaanvente-spec/chrome-extension/refs/heads/main/version.json';
/** Optional second URL if the primary fails (must be allowed in manifest host_permissions). */
var VERSION_JSON_FALLBACK_URL = '';
var UPDATE_CHECK_ALARM = 'fh-version-check';
var ALARM_PERIOD_MINUTES = 240;
var STORAGE_ALARM_PERIOD_KEY = 'fhUpdateCheckAlarmPeriodV1';
var FETCH_TIMEOUT_MS = 15000;

function storageLocalSet(obj) {
  return new Promise(function (resolve, reject) {
    chrome.storage.local.set(obj, function () {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

function storageLocalGet(keys) {
  return new Promise(function (resolve) {
    chrome.storage.local.get(keys, resolve);
  });
}

function getCompareFn() {
  return typeof globalThis.compareVersions === 'function'
    ? globalThis.compareVersions
    : globalThis.compareExtensionVersions;
}

/** Recompute belowMinimum from manifest version and stored minimum string. */
function computeBelowMinimum(currentVersion, minimumSupportedVersion, cmpFn) {
  if (!minimumSupportedVersion || !String(minimumSupportedVersion).trim()) {
    return false;
  }
  var cmp = cmpFn ? cmpFn(currentVersion, String(minimumSupportedVersion).trim()) : null;
  return cmp !== null && cmp < 0;
}

function writeDebugSnapshot(payload) {
  return storageLocalSet({ updateCheckDebug: payload }).catch(function () {});
}

function getVersionJsonUrlList() {
  var list = [VERSION_JSON_URL];
  var fb = VERSION_JSON_FALLBACK_URL && String(VERSION_JSON_FALLBACK_URL).trim();
  if (fb) {
    list.push(fb);
  }
  var seen = {};
  return list.filter(function (u) {
    if (seen[u]) return false;
    seen[u] = true;
    return true;
  });
}

/**
 * Try each URL until we get JSON-shaped body. Non-JSON (e.g. HTML error page) tries next URL.
 */
function fetchVersionJsonText(signal) {
  var urls = getVersionJsonUrlList();
  var attempt = 0;
  function tryNext() {
    if (attempt >= urls.length) {
      return Promise.reject(
        new Error(
          'Failed to fetch version.json (tried ' +
            urls.length +
            ' URL(s)). Reload the extension or set VERSION_JSON_FALLBACK_URL.'
        )
      );
    }
    var url = urls[attempt++];
    return fetch(url, { cache: 'no-store', signal: signal, credentials: 'omit' })
      .then(function (res) {
        if (!res.ok) {
          throw new Error('HTTP ' + res.status);
        }
        return res.text();
      })
      .then(function (text) {
        var t = text.trim();
        if (t.length === 0) {
          throw new Error('Empty body');
        }
        if (t.charAt(0) === '<') {
          console.warn(
            '[update-check] Non-JSON (likely HTML) from',
            url.slice(0, 72),
            '— trying next URL'
          );
          return tryNext();
        }
        return text;
      })
      .catch(function (err) {
        if (err && err.name === 'AbortError') {
          return Promise.reject(err);
        }
        console.warn(
          '[update-check] Fetch failed:',
          url.slice(0, 64),
          err && err.message ? err.message : err
        );
        return tryNext();
      });
  }
  return tryNext();
}

function runUpdateCheck() {
  var currentVersion = chrome.runtime.getManifest().version;
  var lastCheckedAt = Date.now();
  var cmpFn = getCompareFn();

  var abortController = new AbortController();
  var timeoutId = setTimeout(function () {
    abortController.abort();
  }, FETCH_TIMEOUT_MS);

  return fetchVersionJsonText(abortController.signal)
    .then(function (text) {
      clearTimeout(timeoutId);
      return text;
    })
    .catch(function (e) {
      clearTimeout(timeoutId);
      throw e;
    })
    .then(function (text) {
      var data;
      try {
        data = JSON.parse(text);
      } catch (e) {
        throw new Error('Invalid JSON from version endpoint');
      }
      var latestVersion =
        data.latestVersion != null ? String(data.latestVersion).trim() : '';
      if (!latestVersion) {
        throw new Error('Missing latestVersion');
      }
      var downloadUrl =
        data.downloadUrl != null ? String(data.downloadUrl).trim() : '';
      var releaseNotes =
        data.releaseNotes != null ? String(data.releaseNotes) : '';
      var minimumSupportedVersion =
        data.minimumSupportedVersion != null
          ? String(data.minimumSupportedVersion).trim()
          : '';

      var cmp = cmpFn ? cmpFn(currentVersion, latestVersion) : null;
      var updateAvailable = cmp !== null && cmp < 0;
      var belowMinimumSupportedVersion = computeBelowMinimum(
        currentVersion,
        minimumSupportedVersion,
        cmpFn
      );

      var cmpLabel =
        cmp === null ? 'unknown' : cmp < 0 ? 'older' : cmp > 0 ? 'newer' : 'same';

      console.log(
        '[update-check] OK | installed=' +
          currentVersion +
          ' remote=' +
          latestVersion +
          ' compare=' +
          cmpLabel +
          ' belowMin=' +
          belowMinimumSupportedVersion +
          ' | lastCheckedAt=' +
          new Date(lastCheckedAt).toISOString()
      );

      var debugPayload = {
        installedVersion: currentVersion,
        remoteLatestVersion: latestVersion,
        compareResult: cmpLabel,
        minimumSupportedVersion: minimumSupportedVersion || '(none)',
        belowMinimumSupportedVersion: belowMinimumSupportedVersion,
        lastCheckedAt: lastCheckedAt,
        lastSuccessfulCheckAt: lastCheckedAt,
        status: 'ok',
        errorMessage: null
      };

      return storageLocalSet({
        currentVersion: currentVersion,
        latestVersion: latestVersion,
        updateAvailable: updateAvailable,
        downloadUrl: downloadUrl,
        releaseNotes: releaseNotes,
        minimumSupportedVersion: minimumSupportedVersion,
        lastCheckedAt: lastCheckedAt,
        lastSuccessfulCheckAt: lastCheckedAt,
        belowMinimumSupportedVersion: belowMinimumSupportedVersion,
        updateCheckStatus: 'ok'
      })
        .then(function () {
          return writeDebugSnapshot(debugPayload);
        })
        .then(function () {
          return { ok: true, success: true };
        });
    })
    .catch(function (err) {
      var msg = err && err.name === 'AbortError' ? 'Request timed out' : err && err.message ? err.message : String(err);
      console.warn('[update-check] fetch failed:', msg);

      return storageLocalGet([
        'latestVersion',
        'downloadUrl',
        'releaseNotes',
        'minimumSupportedVersion',
        'updateAvailable',
        'lastSuccessfulCheckAt',
        'belowMinimumSupportedVersion'
      ]).then(function (prev) {
        var minStr =
          prev.minimumSupportedVersion !== undefined &&
          prev.minimumSupportedVersion !== ''
            ? String(prev.minimumSupportedVersion).trim()
            : '';
        var belowMin = computeBelowMinimum(currentVersion, minStr, cmpFn);

        return storageLocalSet({
          currentVersion: currentVersion,
          lastCheckedAt: lastCheckedAt,
          latestVersion:
            prev.latestVersion !== undefined && prev.latestVersion !== ''
              ? prev.latestVersion
              : '',
          downloadUrl:
            prev.downloadUrl !== undefined ? prev.downloadUrl : '',
          releaseNotes:
            prev.releaseNotes !== undefined ? prev.releaseNotes : '',
          minimumSupportedVersion:
            prev.minimumSupportedVersion !== undefined
              ? prev.minimumSupportedVersion
              : '',
          updateAvailable:
            prev.updateAvailable !== undefined ? prev.updateAvailable : false,
          lastSuccessfulCheckAt:
            prev.lastSuccessfulCheckAt !== undefined
              ? prev.lastSuccessfulCheckAt
              : null,
          belowMinimumSupportedVersion: belowMin,
          updateCheckStatus: 'error'
        }).then(function () {
          return writeDebugSnapshot({
            installedVersion: currentVersion,
            remoteLatestVersion: prev.latestVersion || null,
            compareResult: 'unknown',
            minimumSupportedVersion: minStr || '(none)',
            belowMinimumSupportedVersion: belowMin,
            lastCheckedAt: lastCheckedAt,
            lastSuccessfulCheckAt: prev.lastSuccessfulCheckAt || null,
            status: 'error',
            errorMessage: msg
          });
        });
      }).then(function () {
        return { ok: true, success: false, error: msg };
      });
    });
}

function ensureVersionAlarm() {
  chrome.storage.local.get(STORAGE_ALARM_PERIOD_KEY, function (r) {
    if (r[STORAGE_ALARM_PERIOD_KEY] !== ALARM_PERIOD_MINUTES) {
      chrome.alarms.create(UPDATE_CHECK_ALARM, {
        periodInMinutes: ALARM_PERIOD_MINUTES
      });
      var o = {};
      o[STORAGE_ALARM_PERIOD_KEY] = ALARM_PERIOD_MINUTES;
      chrome.storage.local.set(o);
    } else {
      chrome.alarms.get(UPDATE_CHECK_ALARM, function (a) {
        if (!a) {
          chrome.alarms.create(UPDATE_CHECK_ALARM, {
            periodInMinutes: ALARM_PERIOD_MINUTES
          });
        }
      });
    }
  });
}

chrome.runtime.onInstalled.addListener(function () {
  chrome.alarms.create(UPDATE_CHECK_ALARM, {
    periodInMinutes: ALARM_PERIOD_MINUTES
  });
  var o = {};
  o[STORAGE_ALARM_PERIOD_KEY] = ALARM_PERIOD_MINUTES;
  chrome.storage.local.set(o);
  runUpdateCheck();
});

chrome.runtime.onStartup.addListener(function () {
  runUpdateCheck();
});

chrome.alarms.onAlarm.addListener(function (alarm) {
  if (alarm.name === UPDATE_CHECK_ALARM) {
    runUpdateCheck();
  }
});

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message && message.type === 'checkExtensionUpdate') {
    runUpdateCheck().then(function (result) {
      sendResponse(result || { ok: true });
    });
    return true;
  }
});

globalThis.runExtensionUpdateCheck = runUpdateCheck;

ensureVersionAlarm();
