#!/usr/bin/env node
'use strict';

const assert = require('assert');
const { compareVersions } = require('../version-utils.js');

assert.strictEqual(compareVersions('2.10.0', '2.9.0'), 1);
assert.strictEqual(compareVersions('2.9.0', '2.10.0'), -1);
assert.strictEqual(compareVersions('1.0', '1.0.0'), 0);
assert.strictEqual(compareVersions('2.18.2', '2.18.2'), 0);
assert.strictEqual(compareVersions('2.18.1', '2.18.2'), -1);
assert.strictEqual(compareVersions('2.18.3', '2.18.2'), 1);
assert.strictEqual(compareVersions('1.0.0', '2.0.0'), -1);
assert.strictEqual(compareVersions(null, '1.0.0'), null);
assert.strictEqual(compareVersions('1.0.0', ''), null);
assert.strictEqual(compareVersions('1.a.0', '1.0.0'), null);
assert.strictEqual(compareVersions('v1.0.0', '1.0.0'), null);

console.log('version-utils compareVersions: all assertions passed');
