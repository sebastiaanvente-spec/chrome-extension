#!/usr/bin/env node
'use strict';

/**
 * Mirrors dedupe + join in content/expedia-mapping.js runExtractAllRoCodes.
 */
function joinUniqueRoCodes(sortedPairs) {
  const seen = new Set();
  const codes = [];
  for (const [, code] of sortedPairs) {
    if (!seen.has(code)) {
      seen.add(code);
      codes.push(code);
    }
  }
  return codes.join('_');
}

const assert = require('assert');

assert.strictEqual(
  joinUniqueRoCodes([
    ['7:00 AM', 'ro876217'],
    ['8:00 AM', 'ro876250'],
    ['9:00 AM', 'ro876265']
  ]),
  'ro876217_ro876250_ro876265'
);
assert.strictEqual(
  joinUniqueRoCodes([
    ['7:00 AM', 'ro1'],
    ['8:00 AM', 'ro2'],
    ['9:00 AM', 'ro1']
  ]),
  'ro1_ro2'
);
assert.strictEqual(joinUniqueRoCodes([]), '');

console.log('expedia Ro codes string: all assertions passed');
