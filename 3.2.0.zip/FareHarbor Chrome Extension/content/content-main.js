console.log("[content-main] content-main.js loaded");

// Constants
const SELECTORS = {
  EDIT_CUSTOMER_TYPE_BTN: 'button[data-test-id="edit-customer-type-button"]',
  DUPLICATE_CUSTOMER_TYPE_BTN: 'button[data-test-id="duplicate-customer-type-button"]',
  CONFIRM_DUPLICATE_BTN: 'button[data-test-id="submit-duplicate-customer-type-button"]',
  SAVE_EDIT_BTN: 'button[data-test-id="save-customer-type-update-button"]',
  NAME_INPUT: 'input[name="name"]',
  MIN_PARTY_SIZE_INPUT: 'input[name="minimumPartySize"]',
  MAX_PARTY_SIZE_INPUT: 'input[name="maximumPartySize"]',
  CUSTOMER_TYPE_BLOCKS: 'div[ng-controller="dashboard.items.item.CustomerPrototypeEditableCtrl"]',
  CUSTOMER_TYPE_NAME: '[data-test-id="customer-type-name"] span',
  PROTOTYPE_INDICATOR: '[data-test-id$="-prototype-indicator"]',
  SPREADSHEET_TABLE: 'table.spreadsheet',
  TABS_LINK: 'ul.tabs a[href*="/items/"]',
  // Price-related selectors
  PRICE_SPAN: 'span.the-price.closed.ng-scope, span[ng-effective-price], .price-cell .the-price, [data-test-id*="price"], [title*="Price"]',
  PRICE_DROPDOWN_SELECT: 'select[ng-model*="priceType"], select[ng-model*="editableLine.priceType"]',
  PRICE_CHANGE_OPTION: 'option[value="string:change"], option[label="Change"]',
  PRICE_OFFSET_INPUT: 'input[name="offset"], input[id="id_offset"], input[ng-model*="offset"]',
  PRICE_SAVE_BTN: 'button.btn-tiny.btn-green[data-test-id="save-visibility-option-button"], button[type="submit"].btn-tiny.btn-green',
  // Additional price-related selectors for discovery
  PRICE_AREAS: '.price-form, .pricing-editor, [ng-pricing-editor], .option-sheet, .td.price, .price-col-inner',
  CUSTOMER_TYPE_PRICE_AREA: '[data-test-id*="pricing"], [data-test-id*="price"]'
};

const TIMEOUTS = {
  DEFAULT_WAIT: 500,
  CONFIRM_BUTTON: 5000,
  EDIT_FORM: 5000,
  RENAMED_CUSTOMER_TYPE: 10000,
  SAVE_COMPLETION: 8000,
  CLEAN_STATE: 3000,
  BUTTON_INTERACTIVE: 4000,
  POLLING_INTERVAL: 150
};

// Inject confirm override script into page context
(function injectScriptFile() {
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('inject.js');
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);
})();

// Utility functions
function $(selector, context = document) {
  return context.querySelector(selector);
}

function $$(selector, context = document) {
  return Array.from(context.querySelectorAll(selector));
}

function setInputValue(input, value) {
  if (!input) return false;
  
  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  nativeSetter.call(input, value);
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  return true;
}

function createPollingPromise(checkFn, timeout, interval = TIMEOUTS.POLLING_INTERVAL) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    let intervalId;
    
    const check = () => {
      const result = checkFn();
      if (result) {
        clearInterval(intervalId);
        resolve(result);
        return;
      }
      
      if (Date.now() - start > timeout) {
        clearInterval(intervalId);
        reject(new Error(`Polling timed out after ${timeout}ms`));
      }
    };
    
    intervalId = setInterval(check, interval);
    check(); // Check immediately
  });
}

// Timing helpers
function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Optimized click helpers
function clickButton(selector, context = document) {
  const btn = $(selector, context);
  if (btn) {
    btn.click();
    return true;
  }
  return false;
}

// Make utilities globally available for other modules
window.FareHarborUtils = {
  SELECTORS,
  TIMEOUTS,
  $,
  $$,
  setInputValue,
  createPollingPromise,
  wait,
  clickButton
};

// Handle extension messages and route to appropriate modules
chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  console.log("[content-main] Message received, action:", req.action);
  
  // Route duplicate-related messages to the duplicate module
  if (req.action === "getCustomerTypes" || 
      req.action === "runDuplicate" || 
      req.action === "runMultipleDuplicates") {
    
    if (window.DuplicateCustomerTypes) {
      return window.DuplicateCustomerTypes.handleMessage(req, sender, sendResponse);
    } else {
      console.error("DuplicateCustomerTypes module not loaded");
      sendResponse({ status: "error", error: "DuplicateCustomerTypes module not loaded" });
      return true;
    }
  }

  // Route Expedia-related messages to the Expedia module
  if (req.action === "runExtract" || req.action === "runCompleteExtract" || req.action === "runExtractAllRoCodes") {
    if (window.ExpediaMapping) {
      return window.ExpediaMapping.handleMessage(req, sender, sendResponse);
    } else {
      console.error("ExpediaMapping module not loaded");
      sendResponse({ status: "error", error: "ExpediaMapping module not loaded" });
      return true;
    }
  }

  // Route availability audit messages to the AvailabilityAudit module
  if (req.action === "runAvailabilityAudit" || req.action === "getAvailabilityPageInfo") {
    if (window.AvailabilityAudit) {
      return window.AvailabilityAudit.handleMessage(req, sender, sendResponse);
    } else {
      console.error("AvailabilityAudit module not loaded");
      sendResponse({ status: "error", error: "AvailabilityAudit module not loaded" });
      return true;
    }
  }

  // Route Activity Listings messages to the ActivityListings module
  if (req.action === "runActivityListingsExtract") {
    if (window.ActivityListings) {
      return window.ActivityListings.handleMessage(req, sender, sendResponse);
    } else {
      console.error("ActivityListings module not loaded");
      sendResponse({ status: "error", error: "ActivityListings module not loaded" });
      return true;
    }
  }

  // Route FareHarbor Reseller Items messages to the FareHarborResellerItems module
  if (req.action === "runFareHarborResellerItemsExtract" || req.action === "runFareHarborResellerItemsSingleExtract") {
    if (window.FareHarborResellerItems) {
      return window.FareHarborResellerItems.handleMessage(req, sender, sendResponse);
    } else {
      console.error("FareHarborResellerItems module not loaded");
      sendResponse({ status: "error", error: "FareHarborResellerItems module not loaded" });
      return true;
    }
  }

  // Route Viator Mapping File messages to the ViatorMappingFile module
  if (req.action === "runViatorMappingFileExtract") {
    if (window.ViatorMappingFile) {
      return window.ViatorMappingFile.handleMessage(req, sender, sendResponse);
    } else {
      console.error("ViatorMappingFile module not loaded");
      sendResponse({ status: "error", error: "ViatorMappingFile module not loaded" });
      return true;
    }
  }

  // Route Airbnb Mapping File messages to the AirbnbMappingFile module
  if (req.action === "runAirbnbMappingFileExtract") {
    if (window.AirbnbMappingFile) {
      return window.AirbnbMappingFile.handleMessage(req, sender, sendResponse);
    } else {
      console.error("AirbnbMappingFile module not loaded");
      sendResponse({ status: "error", error: "AirbnbMappingFile module not loaded" });
      return true;
    }
  }

  // Route FareHarbor Jump messages to the FareHarborJump module
  if (req.action === "performFareHarborJump") {
    if (window.FareHarborJump) {
      return window.FareHarborJump.handleMessage(req, sender, sendResponse);
    } else {
      console.error("FareHarborJump module not loaded");
      sendResponse({ status: "error", error: "FareHarborJump module not loaded" });
      return true;
    }
  }

  // Route FareHarbor Items messages to the FareHarborItems module
  if (req.action === "runFareHarborItemsExtract") {
    if (window.FareHarborItems) {
      return window.FareHarborItems.handleMessage(req, sender, sendResponse);
    } else {
      console.error("FareHarborItems module not loaded");
      sendResponse({ status: "error", error: "FareHarborItems module not loaded" });
      return true;
    }
  }

  // Route GetYourGuide Products messages to the GetYourGuideProducts module
  if (req.action === "runGetYourGuideProductsExtract" || req.action === "runGetYourGuideProductsExtractAll" ||
      req.action === "runGetYourGuideProductsExtractV2" || req.action === "runGetYourGuideProductsExtractAllV2") {
    if (window.GetYourGuideProducts) {
      return window.GetYourGuideProducts.handleMessage(req, sender, sendResponse);
    } else {
      console.error("GetYourGuideProducts module not loaded");
      sendResponse({ status: "error", error: "GetYourGuideProducts module not loaded" });
      return true;
    }
  }

  // Route Viator Products messages to the ViatorProducts module
  if (req.action === "runViatorProductsExtract" || req.action === "runViatorProductsExtractAll" || req.action === "getViatorProductCodes") {
    if (window.ViatorProducts) {
      return window.ViatorProducts.handleMessage(req, sender, sendResponse);
    } else {
      console.error("ViatorProducts module not loaded");
      sendResponse({ status: "error", error: "ViatorProducts module not loaded" });
      return true;
    }
  }

  // Route Copy Report messages to the CopyReport module
  if (req.action === "runCopyReportExtract") {
    console.log("[content-main] Routing Copy Report message, window.CopyReport:", window.CopyReport);
    if (window.CopyReport && window.CopyReport.handleMessage) {
      const result = window.CopyReport.handleMessage(req, sender, sendResponse);
      console.log("[content-main] CopyReport.handleMessage returned:", result);
      return result;
    } else {
      console.error("[content-main] CopyReport module not loaded or handleMessage missing");
      sendResponse({ status: "error", error: "CopyReport module not loaded" });
      return true;
    }
  }

  // Unknown action
  console.warn("Unknown action:", req.action);
  sendResponse({ status: "error", error: `Unknown action: ${req.action}` });
  return true;
});
