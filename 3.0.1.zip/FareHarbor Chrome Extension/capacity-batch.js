/**
 * Single active capacity-check batch in chrome.storage.local.
 * Popup loads this before popup.js; exposes window.CapacityBatch.
 */
(function (global) {
  'use strict';

  const STORAGE_KEY = 'fh_capacity_batch_v1';

  const STATUS_PRIORITY = {
    active_at_snapshot: 0,
    created_after_snapshot: 1,
    cancelled_before_snapshot: 2
  };

  function newBatchId() {
    if (global.crypto && typeof global.crypto.randomUUID === 'function') {
      return global.crypto.randomUUID();
    }
    return `${Date.now()}-${Math.random().toString(36).slice(2, 11)}`;
  }

  function toISOStringSafe(value) {
    if (value == null || value === '') return null;
    const d = value instanceof Date ? value : new Date(value);
    return isNaN(d.getTime()) ? null : d.toISOString();
  }

  function normalizeBookingStatus(booking, isFiltered) {
    if (isFiltered) return 'active_at_snapshot';
    if (booking.isCancelled) {
      if (booking.reason === 'cancelled_created_after_target') {
        return 'created_after_snapshot';
      }
      return 'cancelled_before_snapshot';
    }
    return 'created_after_snapshot';
  }

  function serializeBookingForTsvSource(b) {
    if (!b) return null;
    let dt = null;
    if (b.datetime != null) {
      const d =
        b.datetime instanceof Date ? b.datetime : new Date(b.datetime);
      dt = isNaN(d.getTime()) ? null : d.toISOString();
    }
    let ba;
    if (b.bookedAt != null) {
      const d =
        b.bookedAt instanceof Date ? b.bookedAt : new Date(b.bookedAt);
      ba = isNaN(d.getTime()) ? undefined : d.toISOString();
    }
    return {
      bookingNumber: b.bookingNumber,
      partySize: b.partySize,
      customerTypes: Array.isArray(b.customerTypes) ? b.customerTypes : [],
      isCancelled: !!b.isCancelled,
      datetime: dt,
      bookedAt: ba,
      reason: b.reason,
      bookingHref: b.bookingHref,
      hasHref: b.hasHref,
      index: b.index
    };
  }

  /**
   * Same TSV as single “Copy All Bookings to Clipboard (TSV)”.
   * @param {object} auditData - filteredBookings, skippedBookings, targetDateTime, originalBookingsCount
   * @param {{ normalizeCustomerTypeName: function, formatDateTime: function }} deps
   * @param {{ availabilityName?: string }} [options]
   * @returns {string|null}
   */
  function buildCapacityCheckTsvFromAudit(auditData, deps, options) {
    const { normalizeCustomerTypeName, formatDateTime } = deps;
    if (
      !auditData ||
      !auditData.filteredBookings ||
      !auditData.filteredBookings.length
    ) {
      return null;
    }

    const getBookedAtDate = (booking) => {
      if (booking.isCancelled) {
        if (booking.bookedAt) {
          return booking.bookedAt instanceof Date
            ? booking.bookedAt
            : new Date(booking.bookedAt);
        }
        return new Date('9999-12-31');
      }
      return booking.datetime
        ? booking.datetime instanceof Date
          ? booking.datetime
          : new Date(booking.datetime)
        : new Date('9999-12-31');
    };

    const escapeTSV = (str) => {
      if (!str) return '';
      return str
        .toString()
        .replace(/\t/g, ' ')
        .replace(/\n/g, ' ')
        .replace(/\r/g, '');
    };

    const sortedBookings = [...auditData.filteredBookings].sort((a, b) => {
      const dateA = getBookedAtDate(a);
      const dateB = getBookedAtDate(b);
      if (isNaN(dateA.getTime()) && isNaN(dateB.getTime())) return 0;
      if (isNaN(dateA.getTime())) return 1;
      if (isNaN(dateB.getTime())) return -1;
      return dateA.getTime() - dateB.getTime();
    });

    const skippedBookings = auditData.skippedBookings || [];
    const sortedSkippedBookings = [...skippedBookings].sort((a, b) => {
      const dateA = getBookedAtDate(a);
      const dateB = getBookedAtDate(b);
      if (isNaN(dateA.getTime()) && isNaN(dateB.getTime())) return 0;
      if (isNaN(dateA.getTime())) return 1;
      if (isNaN(dateB.getTime())) return -1;
      return dateA.getTime() - dateB.getTime();
    });

    const allBookings = [...sortedBookings, ...sortedSkippedBookings];
    const sortedAllBookings = [...allBookings].sort((a, b) => {
      const dateA = getBookedAtDate(a);
      const dateB = getBookedAtDate(b);
      if (isNaN(dateA.getTime()) && isNaN(dateB.getTime())) return 0;
      if (isNaN(dateA.getTime())) return 1;
      if (isNaN(dateB.getTime())) return -1;
      return dateA.getTime() - dateB.getTime();
    });

    const filteredBookingsSet = new Set(
      auditData.filteredBookings.map((b) => b.bookingHref || b.bookingNumber)
    );

    const customerTypeSet = new Set();
    sortedAllBookings.forEach((booking) => {
      if (booking.customerTypes && Array.isArray(booking.customerTypes)) {
        booking.customerTypes.forEach((ct) => {
          const normalizedName = normalizeCustomerTypeName(ct.name);
          customerTypeSet.add(normalizedName);
        });
      }
    });

    const customerTypes = Array.from(customerTypeSet).sort();
    const colCount = 4 + customerTypes.length;

    const prefixLines = [];
    if (options && options.availabilityName) {
      const availRow = [
        'Availability name',
        escapeTSV(options.availabilityName)
      ];
      while (availRow.length < colCount) availRow.push('');
      prefixLines.push(availRow.join('\t'));
    }

    const header = [
      'Booking Number',
      'Booked at',
      'Status',
      'Cancelled at',
      ...customerTypes
    ].join('\t');

    const totals = {};
    customerTypes.forEach((ct) => {
      totals[ct] = 0;
    });

    const filteredRows = [];
    const skippedRows = [];

    sortedAllBookings.forEach((booking) => {
      const bookingNumber = booking.bookingNumber || '';
      const dateTime = booking.datetime
        ? formatDateTime(
            booking.datetime instanceof Date
              ? booking.datetime
              : new Date(booking.datetime)
          )
        : '';
      const isFiltered = filteredBookingsSet.has(
        booking.bookingHref || booking.bookingNumber
      );

      let status = 'Active';
      if (booking.isCancelled) {
        if (booking.reason === 'cancelled_created_after_target') {
          status = 'Cancelled (created after timestamp)';
        } else if (isFiltered) {
          status = 'Cancelled (was active at timestamp)';
        } else {
          status = 'Cancelled before timestamp';
        }
      } else if (!isFiltered) {
        status = 'Active (created after timestamp)';
      }

      let bookedAt = '';
      let cancelledAt = '';
      if (booking.isCancelled) {
        cancelledAt = dateTime;
        if (booking.bookedAt) {
          bookedAt = formatDateTime(
            booking.bookedAt instanceof Date
              ? booking.bookedAt
              : new Date(booking.bookedAt)
          );
        }
      } else {
        bookedAt = dateTime;
      }

      const bookingCustomerTypes = {};
      if (booking.customerTypes && Array.isArray(booking.customerTypes)) {
        booking.customerTypes.forEach((ct) => {
          const normalizedName = normalizeCustomerTypeName(ct.name);
          const quantity = ct.quantity || 0;
          bookingCustomerTypes[normalizedName] =
            (bookingCustomerTypes[normalizedName] || 0) + quantity;
          if (isFiltered) {
            totals[normalizedName] = (totals[normalizedName] || 0) + quantity;
          }
        });
      }

      const rowValues = [
        escapeTSV(bookingNumber),
        escapeTSV(bookedAt),
        escapeTSV(status),
        escapeTSV(cancelledAt),
        ...customerTypes.map((ct) => bookingCustomerTypes[ct] || '')
      ];

      const row = rowValues.join('\t');
      if (isFiltered) filteredRows.push(row);
      else skippedRows.push(row);
    });

    const totalRow = [
      'TOTAL',
      '',
      '',
      '',
      ...customerTypes.map((ct) => totals[ct] || 0)
    ].join('\t');

    const emptyRow = Array(colCount).fill('').join('\t');

    const targetDateTime =
      auditData.targetDateTime instanceof Date
        ? auditData.targetDateTime
        : new Date(auditData.targetDateTime);
    const timestampStr = formatDateTime(targetDateTime);

    const timestampRow = [
      'Timestamp:',
      escapeTSV(timestampStr),
      ...Array(customerTypes.length + 2).fill('')
    ].join('\t');

    const totalScanned =
      auditData.originalBookingsCount != null
        ? auditData.originalBookingsCount
        : sortedAllBookings.length;

    const summaryStats = [`Total bookings scanned: ${totalScanned}`];

    return [
      ...prefixLines,
      header,
      ...filteredRows,
      totalRow,
      emptyRow,
      timestampRow,
      emptyRow,
      ...skippedRows,
      ...summaryStats
    ].join('\n');
  }

  function countBatchTsvBookings(batch) {
    let n = 0;
    for (const snap of batch.snapshots || []) {
      const src = snap.tsvSource;
      if (!src) continue;
      n += (src.filteredBookings || []).length + (src.skippedBookings || []).length;
    }
    return n;
  }

  /**
   * One accumulated TSV matching single “Copy All Bookings” layout:
   * header → filtered rows (all snapshots, sorted by booked-at) → TOTAL → blank → Timestamp → blank → skipped → summary.
   */
  function exportBatchToCapacityCheckTsv(batch, deps) {
    const { normalizeCustomerTypeName, formatDateTime } = deps;

    const getBookedAtDate = (booking) => {
      if (booking.isCancelled) {
        if (booking.bookedAt) {
          return booking.bookedAt instanceof Date
            ? booking.bookedAt
            : new Date(booking.bookedAt);
        }
        return new Date('9999-12-31');
      }
      return booking.datetime
        ? booking.datetime instanceof Date
          ? booking.datetime
          : new Date(booking.datetime)
        : new Date('9999-12-31');
    };

    const escapeTSV = (str) => {
      if (!str) return '';
      return str
        .toString()
        .replace(/\t/g, ' ')
        .replace(/\n/g, ' ')
        .replace(/\r/g, '');
    };

    const snaps = [...(batch.snapshots || [])].filter((s) => s.tsvSource);
    if (!snaps.length) return null;

    const enriched = [];
    let totalScannedSum = 0;
    const targetIsoSet = new Set();

    for (const snap of snaps) {
      const src = snap.tsvSource;
      const filteredSet = new Set(
        (src.filteredBookings || []).map((b) => b.bookingHref || b.bookingNumber)
      );
      const allInSnap = [
        ...(src.filteredBookings || []),
        ...(src.skippedBookings || [])
      ];
      const seen = new Set();
      const targetForFormat =
        src.targetDateTime instanceof Date
          ? src.targetDateTime
          : new Date(src.targetDateTime);
      const targetIso = isNaN(targetForFormat.getTime())
        ? ''
        : targetForFormat.toISOString();
      if (targetIso) targetIsoSet.add(targetIso);

      for (const booking of allInSnap) {
        const key = booking.bookingHref || booking.bookingNumber || String(booking.index);
        if (seen.has(key)) continue;
        seen.add(key);

        const isFiltered = filteredSet.has(
          booking.bookingHref || booking.bookingNumber
        );
        enriched.push({
          booking,
          availabilityName: snap.availabilityName || '',
          targetDateTime: targetForFormat,
          isFiltered
        });
      }

      if (src.originalBookingsCount != null) {
        totalScannedSum += src.originalBookingsCount;
      } else {
        totalScannedSum +=
          (src.filteredBookings || []).length + (src.skippedBookings || []).length;
      }
    }

    if (!enriched.length) return null;

    const customerTypeSet = new Set();
    enriched.forEach(({ booking }) => {
      if (booking.customerTypes && Array.isArray(booking.customerTypes)) {
        booking.customerTypes.forEach((ct) => {
          customerTypeSet.add(normalizeCustomerTypeName(ct.name));
        });
      }
    });
    const customerTypes = Array.from(customerTypeSet).sort();

    const sortByBookedAt = (a, b) => {
      const dateA = getBookedAtDate(a.booking);
      const dateB = getBookedAtDate(b.booking);
      if (isNaN(dateA.getTime()) && isNaN(dateB.getTime())) return 0;
      if (isNaN(dateA.getTime())) return 1;
      if (isNaN(dateB.getTime())) return -1;
      return dateA.getTime() - dateB.getTime();
    };

    const filteredList = enriched.filter((e) => e.isFiltered).sort(sortByBookedAt);
    const skippedList = enriched.filter((e) => !e.isFiltered).sort(sortByBookedAt);

    const colCount = 4 + customerTypes.length;

    const totals = {};
    customerTypes.forEach((ct) => {
      totals[ct] = 0;
    });

    filteredList.forEach((entry) => {
      const { booking } = entry;
      if (booking.customerTypes && Array.isArray(booking.customerTypes)) {
        booking.customerTypes.forEach((ct) => {
          const normalizedName = normalizeCustomerTypeName(ct.name);
          const quantity = ct.quantity || 0;
          totals[normalizedName] = (totals[normalizedName] || 0) + quantity;
        });
      }
    });

    function buildRow(entry) {
      const { booking, isFiltered } = entry;
      const dateTime = booking.datetime
        ? formatDateTime(
            booking.datetime instanceof Date
              ? booking.datetime
              : new Date(booking.datetime)
          )
        : '';

      let status = 'Active';
      if (booking.isCancelled) {
        if (booking.reason === 'cancelled_created_after_target') {
          status = 'Cancelled (created after timestamp)';
        } else if (isFiltered) {
          status = 'Cancelled (was active at timestamp)';
        } else {
          status = 'Cancelled before timestamp';
        }
      } else if (!isFiltered) {
        status = 'Active (created after timestamp)';
      }

      let bookedAt = '';
      let cancelledAt = '';
      if (booking.isCancelled) {
        cancelledAt = dateTime;
        if (booking.bookedAt) {
          bookedAt = formatDateTime(
            booking.bookedAt instanceof Date
              ? booking.bookedAt
              : new Date(booking.bookedAt)
          );
        }
      } else {
        bookedAt = dateTime;
      }

      const bookingCustomerTypes = {};
      if (booking.customerTypes && Array.isArray(booking.customerTypes)) {
        booking.customerTypes.forEach((ct) => {
          const normalizedName = normalizeCustomerTypeName(ct.name);
          const quantity = ct.quantity || 0;
          bookingCustomerTypes[normalizedName] =
            (bookingCustomerTypes[normalizedName] || 0) + quantity;
        });
      }

      return [
        escapeTSV(booking.bookingNumber || ''),
        escapeTSV(bookedAt),
        escapeTSV(status),
        escapeTSV(cancelledAt),
        ...customerTypes.map((ct) => bookingCustomerTypes[ct] || '')
      ].join('\t');
    }

    const filteredRows = filteredList.map(buildRow);
    const skippedRows = skippedList.map(buildRow);

    const header = [
      'Booking Number',
      'Booked at',
      'Status',
      'Cancelled at',
      ...customerTypes
    ].join('\t');

    const totalRow = [
      'TOTAL',
      '',
      '',
      '',
      ...customerTypes.map((ct) => totals[ct] || 0)
    ].join('\t');

    const emptyRow = Array(colCount).fill('').join('\t');

    let timestampDisplay = '';
    if (targetIsoSet.size === 1) {
      const d = new Date([...targetIsoSet][0]);
      timestampDisplay = formatDateTime(d);
    } else if (targetIsoSet.size > 1) {
      const sortedTs = [...targetIsoSet].sort();
      timestampDisplay = sortedTs
        .map((iso) => formatDateTime(new Date(iso)))
        .join('; ');
    }

    const timestampRow = [
      'Timestamp:',
      escapeTSV(timestampDisplay),
      ...Array(customerTypes.length + 2).fill('')
    ].join('\t');

    const summaryStats = [`Total bookings scanned: ${totalScannedSum}`];

    return [
      header,
      ...filteredRows,
      totalRow,
      emptyRow,
      timestampRow,
      emptyRow,
      ...skippedRows,
      ...summaryStats
    ].join('\n');
  }

  /**
   * Maps audit API response + pageContext to a persisted snapshot (normalized rows only).
   */
  function auditResponseToSnapshot(auditData, pageContext) {
    const availabilityId =
      (pageContext && pageContext.availabilityId) || 'unknown';
    const availabilityName =
      (pageContext && pageContext.availabilityName) || 'Unknown';

    const snapshotTimestamp =
      toISOStringSafe(auditData.targetDateTime) || new Date().toISOString();

    const filtered = auditData.filteredBookings || [];
    const skipped = auditData.skippedBookings || [];
    const filteredSet = new Set(
      filtered.map((b) => b.bookingHref || b.bookingNumber)
    );

    const tsvTargetIso =
      toISOStringSafe(auditData.targetDateTime) || snapshotTimestamp;
    const tsvSource = {
      filteredBookings: filtered.map(serializeBookingForTsvSource).filter(Boolean),
      skippedBookings: skipped.map(serializeBookingForTsvSource).filter(Boolean),
      targetDateTime: tsvTargetIso,
      originalBookingsCount:
        auditData.originalBookingsCount != null
          ? auditData.originalBookingsCount
          : filtered.length + skipped.length
    };

    const rows = [];
    const seen = new Set();

    for (const booking of [...filtered, ...skipped]) {
      const dedupeKey = booking.bookingHref || booking.bookingNumber || JSON.stringify(booking.index);
      if (seen.has(dedupeKey)) continue;
      seen.add(dedupeKey);

      const isFiltered = filteredSet.has(booking.bookingHref || booking.bookingNumber);
      const status = normalizeBookingStatus(booking, isFiltered);

      const datetime =
        booking.datetime != null
          ? booking.datetime instanceof Date
            ? booking.datetime
            : new Date(booking.datetime)
          : null;

      let bookedAtIso = null;
      let cancelledAtIso = null;
      if (booking.isCancelled) {
        cancelledAtIso = toISOStringSafe(datetime);
        bookedAtIso = toISOStringSafe(booking.bookedAt);
      } else {
        bookedAtIso = toISOStringSafe(datetime);
      }

      rows.push({
        bookingNumber: booking.bookingNumber != null ? String(booking.bookingNumber) : '',
        bookedAt: bookedAtIso,
        status,
        cancelledAt: cancelledAtIso,
        adults:
          booking.partySize != null && !isNaN(Number(booking.partySize))
            ? Number(booking.partySize)
            : 0
      });
    }

    return {
      availabilityId,
      availabilityName,
      snapshotTimestamp,
      rows,
      tsvSource
    };
  }

  function flattenBatchToRows(batch) {
    const flat = [];
    for (const snap of batch.snapshots || []) {
      for (const row of snap.rows || []) {
        flat.push({
          availabilityName: snap.availabilityName || '',
          availabilityId: snap.availabilityId || '',
          snapshotTimestamp: snap.snapshotTimestamp || '',
          bookingNumber: row.bookingNumber,
          bookedAt: row.bookedAt,
          status: row.status,
          cancelledAt: row.cancelledAt,
          adults: row.adults
        });
      }
    }
    return flat;
  }

  function sortBatchRows(rows) {
    return [...rows].sort((a, b) => {
      const nameCmp = (a.availabilityName || '').localeCompare(
        b.availabilityName || '',
        undefined,
        { sensitivity: 'base' }
      );
      if (nameCmp !== 0) return nameCmp;

      const tsCmp = (a.snapshotTimestamp || '').localeCompare(
        b.snapshotTimestamp || ''
      );
      if (tsCmp !== 0) return tsCmp;

      const pa = STATUS_PRIORITY[a.status] ?? 99;
      const pb = STATUS_PRIORITY[b.status] ?? 99;
      if (pa !== pb) return pa - pb;

      const ba = a.bookedAt || '';
      const bb = b.bookedAt || '';
      if (!ba && bb) return 1;
      if (ba && !bb) return -1;
      const bookedCmp = ba.localeCompare(bb);
      if (bookedCmp !== 0) return bookedCmp;

      return (a.bookingNumber || '').localeCompare(b.bookingNumber || '', undefined, {
        numeric: true
      });
    });
  }

  function escapeCsvField(val) {
    if (val == null || val === '') return '';
    const s = String(val);
    if (/[",\n\r]/.test(s)) {
      return '"' + s.replace(/"/g, '""') + '"';
    }
    return s;
  }

  const EXPORT_HEADERS = [
    'availabilityName',
    'availabilityId',
    'snapshotTimestamp',
    'bookingNumber',
    'bookedAt',
    'status',
    'cancelledAt',
    'adults'
  ];

  function exportBatchToCsv(batch) {
    const flat = sortBatchRows(flattenBatchToRows(batch));
    const lines = [EXPORT_HEADERS.join(',')];
    for (const r of flat) {
      lines.push(
        EXPORT_HEADERS.map((h) => escapeCsvField(r[h])).join(',')
      );
    }
    return lines.join('\n');
  }

  function exportBatchToTableText(batch) {
    const flat = sortBatchRows(flattenBatchToRows(batch));
    const escapeCell = (v) =>
      String(v ?? '')
        .replace(/\t/g, ' ')
        .replace(/\n/g, ' ')
        .replace(/\r/g, '');
    const lines = [EXPORT_HEADERS.join('\t')];
    for (const r of flat) {
      lines.push(EXPORT_HEADERS.map((h) => escapeCell(r[h])).join('\t'));
    }
    return lines.join('\n');
  }

  function createNewBatch() {
    return new Promise((resolve, reject) => {
      const batch = {
        id: newBatchId(),
        createdAt: new Date().toISOString(),
        label: 'Batch',
        snapshots: []
      };
      chrome.storage.local.remove(STORAGE_KEY, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }
        chrome.storage.local.set({ [STORAGE_KEY]: batch }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
            return;
          }
          resolve(batch);
        });
      });
    });
  }

  function getActiveBatch() {
    return new Promise((resolve) => {
      chrome.storage.local.get([STORAGE_KEY], (r) => {
        if (chrome.runtime.lastError) {
          resolve(null);
          return;
        }
        const batch = r[STORAGE_KEY];
        if (
          !batch ||
          typeof batch !== 'object' ||
          !Array.isArray(batch.snapshots)
        ) {
          resolve(null);
          return;
        }
        resolve(batch);
      });
    });
  }

  function saveSnapshotToBatch(snapshot) {
    return new Promise((resolve, reject) => {
      getActiveBatch()
        .then((batch) => {
          if (!batch) {
            reject(new Error('No active batch'));
            return;
          }
          const idx = batch.snapshots.findIndex(
            (s) =>
              s.availabilityId === snapshot.availabilityId &&
              s.snapshotTimestamp === snapshot.snapshotTimestamp
          );
          if (idx >= 0) {
            batch.snapshots[idx] = snapshot;
          } else {
            batch.snapshots.push(snapshot);
          }
          chrome.storage.local.set({ [STORAGE_KEY]: batch }, () => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
              return;
            }
            resolve(batch);
          });
        })
        .catch(reject);
    });
  }

  function formatBatchStatusLine(batch) {
    if (!batch) {
      return 'No active batch. Click “New batch” to start.';
    }
    const started = new Date(batch.createdAt).toLocaleString();
    const n = batch.snapshots.length;
    return `Active batch: started ${started}, ${n} snapshot${n === 1 ? '' : 's'}`;
  }

  /** Fallback when pageContext is missing (e.g. older content script). */
  function inferPageContextFromUrl(url) {
    try {
      const u = new URL(url);
      const pathname = u.pathname || '';
      let availabilityId = '';
      const itemMatch = pathname.match(/\/items\/(\d+)/);
      const itemId = itemMatch ? itemMatch[1] : null;
      const calMatch = pathname.match(
        /\/calendar\/(\d{4})\/(\d{1,2})(?:\/(\d{1,2}))?/
      );
      if (itemId && calMatch) {
        const y = calMatch[1];
        const m = String(calMatch[2]).padStart(2, '0');
        const d = calMatch[3] ? String(calMatch[3]).padStart(2, '0') : '';
        availabilityId = d ? `${itemId}-${y}-${m}-${d}` : `${itemId}-${y}-${m}`;
      } else if (itemId) {
        availabilityId = itemId;
      } else {
        const trimmed = pathname.replace(/^\/+|\/+$/g, '').replace(/\//g, '_');
        availabilityId = trimmed || 'unknown';
      }
      let availabilityName = 'Unknown';
      if (itemId) {
        if (calMatch) {
          const y = calMatch[1];
          const mo = String(calMatch[2]).padStart(2, '0');
          const day = calMatch[3]
            ? `-${String(calMatch[3]).padStart(2, '0')}`
            : '';
          availabilityName = `Item ${itemId} (${y}-${mo}${day})`;
        } else {
          availabilityName = `Item ${itemId}`;
        }
      } else {
        availabilityName = pathname || u.hostname || 'Unknown';
      }
      return { availabilityId, availabilityName };
    } catch (e) {
      return { availabilityId: 'unknown', availabilityName: 'Unknown' };
    }
  }

  global.CapacityBatch = {
    STORAGE_KEY,
    STATUS_PRIORITY,
    createNewBatch,
    getActiveBatch,
    saveSnapshotToBatch,
    auditResponseToSnapshot,
    sortBatchRows,
    exportBatchToCsv,
    exportBatchToTableText,
    formatBatchStatusLine,
    flattenBatchToRows,
    inferPageContextFromUrl,
    buildCapacityCheckTsvFromAudit,
    exportBatchToCapacityCheckTsv,
    countBatchTsvBookings
  };
})(typeof window !== 'undefined' ? window : self);
