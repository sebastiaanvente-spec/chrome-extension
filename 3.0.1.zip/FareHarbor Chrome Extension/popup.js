// Page Navigation Functions
function showPage(pageId) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(page => {
    page.classList.remove('active');
  });
  
  // Show the target page
  document.getElementById(pageId).classList.add('active');
  
  // If showing main menu page, re-apply usecase filter and update home card statuses
  if (pageId === 'mainMenuPage') {
    // Reload the preference to ensure indicator is up to date
    // Don't show modal when returning to main menu (only on first load)
    loadUsecasePreference(false);
    updateMainMenuCapacityStatus();
    updateMainMenuDuplicateStatus();
    refreshMainMenuUpdateRequiredOverlay();
  }
  if (pageId === 'updatesPage') {
    loadUpdatesUI();
  }
  if (pageId === 'availabilityAuditPage') {
    refreshCapacityBatchUI();
  }
}

/** Last successful audit payload (slim) for “Add current results to batch”. */
let capacityCheckLastAuditForBatch = null;

function stripBookingForBatch(b) {
  if (!b) return null;
  return {
    bookingNumber: b.bookingNumber,
    partySize: b.partySize,
    customerTypes: b.customerTypes,
    isCancelled: b.isCancelled,
    datetime: b.datetime,
    bookedAt: b.bookedAt,
    reason: b.reason,
    bookingHref: b.bookingHref,
    hasHref: b.hasHref,
    index: b.index
  };
}

function sanitizeAuditResponseForBatch(response) {
  if (!response || !response.success) return null;
  return {
    success: true,
    filteredBookings: (response.filteredBookings || [])
      .map(stripBookingForBatch)
      .filter(Boolean),
    skippedBookings: (response.skippedBookings || [])
      .map(stripBookingForBatch)
      .filter(Boolean),
    targetDateTime: response.targetDateTime,
    originalBookingsCount: response.originalBookingsCount,
    pageContext: response.pageContext
  };
}

async function refreshCapacityBatchUI() {
  const statusEl = document.getElementById('capacityBatchStatus');
  const addBtn = document.getElementById('capacityBatchAddBtn');
  if (!statusEl || !addBtn || typeof CapacityBatch === 'undefined') return;
  const batch = await CapacityBatch.getActiveBatch();
  statusEl.textContent = CapacityBatch.formatBatchStatusLine(batch);
  addBtn.disabled = !(batch && capacityCheckLastAuditForBatch);
}

function setupCapacityBatchControls() {
  if (typeof CapacityBatch === 'undefined') return;
  const newBtn = document.getElementById('capacityBatchNewBtn');
  const addBtn = document.getElementById('capacityBatchAddBtn');
  const batchTsvBtn = document.getElementById('capacityBatchCopyTsvBtn');
  if (!newBtn || !addBtn || !batchTsvBtn) return;

  newBtn.addEventListener('click', async () => {
    try {
      await CapacityBatch.createNewBatch();
      showStatus(
        'Started a new batch. Run Capacity check on each availability, then add results here.'
      );
      await refreshCapacityBatchUI();
    } catch (e) {
      console.error(e);
      showStatus('Could not start a new batch. Try again.', true);
    }
  });

  addBtn.addEventListener('click', async () => {
    if (!capacityCheckLastAuditForBatch) {
      showStatus('Run a Capacity check first, then add results.', true);
      return;
    }
    const batch = await CapacityBatch.getActiveBatch();
    if (!batch) {
      showStatus('No active batch. Click “New batch” first.', true);
      return;
    }
    addBtn.disabled = true;
    try {
      let ctx = capacityCheckLastAuditForBatch.pageContext;
      if (
        !ctx ||
        !ctx.availabilityId ||
        ctx.availabilityId === 'unknown'
      ) {
        const tabs = await chrome.tabs.query({
          active: true,
          currentWindow: true
        });
        const url = tabs[0] && tabs[0].url ? tabs[0].url : '';
        ctx = CapacityBatch.inferPageContextFromUrl(url);
      }
      const snapshot = CapacityBatch.auditResponseToSnapshot(
        capacityCheckLastAuditForBatch,
        ctx
      );
      await CapacityBatch.saveSnapshotToBatch(snapshot);
      showStatus(
        `Saved this availability to the batch (${snapshot.rows.length} booking rows).`
      );
    } catch (err) {
      console.error(err);
      showStatus(
        'Could not save to batch. Try “New batch” and run the check again.',
        true
      );
    } finally {
      await refreshCapacityBatchUI();
    }
  });

  const copyBatchTsv = async () => {
    const batch = await CapacityBatch.getActiveBatch();
    if (!batch || !batch.snapshots.length) {
      showStatus('Nothing to export. Add results to a batch first.', true);
      return;
    }
    const tsv = CapacityBatch.exportBatchToCapacityCheckTsv(batch, {
      normalizeCustomerTypeName,
      formatDateTime
    });
    if (!tsv) {
      showStatus(
        'No batch data to copy. Add results from at least one Capacity check.',
        true
      );
      return;
    }
    const totalBookings = CapacityBatch.countBatchTsvBookings(batch);
    try {
      await navigator.clipboard.writeText(tsv);
      showStatus(
        `Successfully copied ${totalBookings} booking${totalBookings === 1 ? '' : 's'} to clipboard!`
      );
    } catch (err) {
      console.error(err);
      showStatus('Failed to copy batch to clipboard', true);
    }
  };

  batchTsvBtn.addEventListener('click', copyBatchTsv);
}

const UPDATES_STORAGE_KEYS = [
  'currentVersion',
  'latestVersion',
  'updateAvailable',
  'releaseNotes',
  'lastCheckedAt',
  'lastSuccessfulCheckAt',
  'updateCheckStatus',
  'belowMinimumSupportedVersion',
  'minimumSupportedVersion',
  'downloadUrl'
];

/** Same rules as version-utils: -1 / 0 / 1 / null */
function compareExtensionVersionsForUi(a, b) {
  const parse = (str) => {
    if (typeof str !== 'string' || !str.trim()) return null;
    const parts = str.trim().split('.');
    const nums = [];
    for (let i = 0; i < parts.length; i++) {
      if (parts[i] === '' || !/^\d+$/.test(parts[i])) return null;
      nums.push(parseInt(parts[i], 10));
    }
    return nums.length ? nums : null;
  };
  const pa = parse(String(a));
  const pb = parse(String(b));
  if (!pa || !pb) return null;
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const x = pa[i] !== undefined ? pa[i] : 0;
    const y = pb[i] !== undefined ? pb[i] : 0;
    if (x < y) return -1;
    if (x > y) return 1;
  }
  return 0;
}

function hideMainMenuUpdateRequiredOverlay() {
  const overlay = document.getElementById('mainMenuUpdateRequiredOverlay');
  if (!overlay) return;
  overlay.style.display = 'none';
  overlay.setAttribute('aria-hidden', 'true');
}

/**
 * Full-screen warning on the home screen when installed version is below minimum supported.
 * Shown each time the main menu becomes active until storage reports the user is no longer below minimum.
 */
function refreshMainMenuUpdateRequiredOverlay() {
  const mainPage = document.getElementById('mainMenuPage');
  const overlay = document.getElementById('mainMenuUpdateRequiredOverlay');
  if (!mainPage || !overlay) return;
  if (!mainPage.classList.contains('active')) {
    hideMainMenuUpdateRequiredOverlay();
    return;
  }
  chrome.storage.local.get(UPDATES_STORAGE_KEYS, (r) => {
    if (chrome.runtime.lastError) {
      return;
    }
    if (!mainPage.classList.contains('active')) {
      hideMainMenuUpdateRequiredOverlay();
      return;
    }
    if (!r.belowMinimumSupportedVersion) {
      hideMainMenuUpdateRequiredOverlay();
      return;
    }
    const manifest = chrome.runtime.getManifest();
    const current = r.currentVersion || manifest.version || '—';
    const min = r.minimumSupportedVersion && String(r.minimumSupportedVersion).trim()
      ? String(r.minimumSupportedVersion).trim()
      : null;
    const versionsEl = document.getElementById('mainMenuUpdateVersions');
    if (versionsEl) {
      versionsEl.textContent = min
        ? `Installed: ${current} · Minimum supported: ${min}`
        : `Installed: ${current}`;
    }
    overlay.style.display = 'flex';
    overlay.setAttribute('aria-hidden', 'false');
    const dialog = overlay.querySelector('.main-menu-update-dialog');
    if (dialog && typeof dialog.focus === 'function') {
      try {
        dialog.focus();
      } catch (_e) {
        /* ignore */
      }
    }
  });
}

function loadUpdatesUI() {
  chrome.storage.local.get(UPDATES_STORAGE_KEYS, (r) => {
    if (chrome.runtime.lastError) {
      return;
    }
    const manifest = chrome.runtime.getManifest();
    const current = r.currentVersion || manifest.version || '—';
    const latest = r.latestVersion && String(r.latestVersion).trim() ? r.latestVersion : '—';

    document.getElementById('updatesCurrentVersion').textContent = current;
    document.getElementById('updatesLatestVersion').textContent = latest;

    let statusText = 'Up to date';
    if (r.belowMinimumSupportedVersion) {
      statusText = 'Update required (below minimum)';
    } else if (r.updateAvailable) {
      statusText = 'Update available';
    } else if (r.updateCheckStatus === 'error' && (!r.latestVersion || !String(r.latestVersion).trim())) {
      statusText = 'Waiting for first successful check';
    } else if (r.updateCheckStatus === 'error') {
      statusText = 'Offline or error — showing last saved info';
    }
    document.getElementById('updatesStatus').textContent = statusText;

    document.getElementById('updatesLastChecked').textContent = r.lastCheckedAt
      ? new Date(r.lastCheckedAt).toLocaleString()
      : '—';

    const lastOk = document.getElementById('updatesLastSuccessLine');
    if (lastOk) {
      if (r.updateCheckStatus === 'error' && r.lastSuccessfulCheckAt) {
        lastOk.style.display = 'block';
        lastOk.textContent =
          'Last successful check: ' + new Date(r.lastSuccessfulCheckAt).toLocaleString();
      } else {
        lastOk.style.display = 'none';
      }
    }

    const notes = r.releaseNotes && String(r.releaseNotes).trim() ? r.releaseNotes : '—';
    document.getElementById('updatesReleaseNotes').textContent = notes;

    document.getElementById('updatesRequiredBanner').style.display = r.belowMinimumSupportedVersion
      ? 'block'
      : 'none';

    const installedVer = manifest.version;
    const latestStr = r.latestVersion && String(r.latestVersion).trim() ? String(r.latestVersion).trim() : '';
    const cmp = latestStr ? compareExtensionVersionsForUi(installedVer, latestStr) : null;
    const onLatestOrNewer =
      cmp !== null && cmp >= 0;
    const mustShowUpdateFlow =
      r.belowMinimumSupportedVersion ||
      r.updateAvailable ||
      (cmp !== null && cmp < 0);
    const simplifyUpdateUi = onLatestOrNewer && !mustShowUpdateFlow;

    const dl = (r.downloadUrl || '').trim();
    const dlOk = /^https?:\/\//i.test(dl);
    const downloadBtn = document.getElementById('updatesDownloadBtn');
    const openExtBtn = document.getElementById('updatesOpenExtensionsBtn');
    const stepsEl = document.querySelector('.updates-user-steps');

    if (simplifyUpdateUi) {
      downloadBtn.disabled = true;
      downloadBtn.classList.add('updates-download-muted');
      openExtBtn.style.display = 'none';
      if (stepsEl) stepsEl.style.display = 'none';
    } else {
      downloadBtn.disabled = !dlOk;
      downloadBtn.classList.remove('updates-download-muted');
      openExtBtn.style.display = '';
      if (stepsEl) stepsEl.style.display = '';
    }

  });
}

// Price validation function
function validatePriceFormat(priceText) {
  // Remove any leading/trailing whitespace
  const cleanPrice = priceText.trim();
  
  // Check if empty
  if (!cleanPrice) {
    return { valid: false, error: "Price cannot be empty" };
  }
  
  // Check for valid number format with optional decimal (max 2 digits after decimal)
  const priceRegex = /^\d+(\.\d{1,2})?$/;
  if (!priceRegex.test(cleanPrice)) {
    return { valid: false, error: "Price must be a positive number with max 2 decimal places (e.g., 76.45)" };
  }
  
  // Parse the number
  const price = parseFloat(cleanPrice);
  
  // Check if it's a valid positive number
  if (isNaN(price) || price <= 0) {
    return { valid: false, error: "Price must be a positive number greater than 0" };
  }
  
  // Check for reasonable maximum (to prevent accidental huge numbers)
  if (price > 999999.99) {
    return { valid: false, error: "Price seems too large (max 999,999.99)" };
  }
  
  return { valid: true, price: price };
}

// Changelog data - update this when releasing new versions
const CHANGELOG = [
  {
    version: "3.0.1",
    changes: [
      "Updated UI, added update needed messaging, updated wording on update instructions"
    ]
  },
  {
    version: "2.20.0",
    changes: [
      "Added feature to batch capacity check multiple availabilities"
    ]
  },
  {
    version: "2.19.1",
    changes: [
      "Cleaned up UI and added update instructions"
    ]
  },
  {
    version: "2.19.0",
    changes: [
      "Added a version check and download update option"
    ]
  },
  {
    version: "2.18.2",
    changes: [
      "Added 'open all products tab' to Viator copy mapping data"
    ]
  },
  {
    version: "2.18.1",
    changes: [
      "Tabs opened for capacity check now auto close again"
    ]
  },
  {
    version: "2.18.0",
    changes: [
      "Completely revamped copy mapping data for GetYourGuide Products, now scrapes over API being faster and more reliable. Deprecated old version"
    ]
  },
  {
    version: "2.17.3",
    changes: [
      "Copy complete mapping file for GetYourGuide now expands to show all channel options when necessary"
    ]
  },
  {
    version: "2.17.2",
    changes: [
      "Added clearer error messaging when extension has not injected in the webpage"
    ]
  },
  {
    version: "2.17.1",
    changes: [
      "Hid copy all products from GetYourGuide and Viator copy mapping data; Not working correctly"
    ]
  },
  {
    version: "2.17.0",
    changes: [
      "Added TripAdvisor Listing to Jump to..."
    ]
  },
  {
    version: "2.16.0",
    changes: [
      "Added Google Sheets clipboard export to Capacity Check"
    ]
  },
  {
    version: "2.15.1",
    changes: [
      "Updated Jump to for Support to only show relevant options"
    ]
  },
  {
    version: "2.15.0",
    changes: [
      "Added use case selector",
      "Added copy FareHarbor reports"
    ]
  },
  {
    version: "2.14.0",
    changes: [
      "Added Supplier ID to Jump to.. for GetYourGuide"
    ]
  },
  {
    version: "2.13.0",
    changes: [
      "Added copy mapping file for Viator",
      "Added TSV transfer option to GetYourGuide copy mapping"
    ]
  },
  {
    version: "2.12.0",
    changes: [
      "Added copy all Viator and GetYourGuide product feature",
      "Restructured Copy Mapping Data"
    ]
  },
  {
    version: "2.11.0",
    changes: [
      "Added a GetYourGuide and Viator data copy feature"
    ]
  },
  {
    version: "2.01.0",
    changes: [
      "Added Copy FareHarbor items list"
    ]
  },
  {
    version: "2.0.31",
    changes: [
      "Added changelog to extension"
    ]
  },
  {
    version: "2.0.3",
    changes: [
      "Bug fix where not all customer types would correctly be duplicated"
    ]
  },
  {
    version: "2.0.0",
    changes: [
      "New version, UI changes "
    ]
  }
];

// Format changelog for display
function formatChangelog() {
  let html = '';
  CHANGELOG.forEach(entry => {
    html += `<div class="changelog-version">${entry.version}</div>`;
    entry.changes.forEach(change => {
      html += `<div class="changelog-item">${change}</div>`;
    });
  });
  return html;
}

// Show changelog modal
function showChangelog() {
  const modal = document.getElementById('changelogModal');
  const content = document.getElementById('changelogContent');
  content.innerHTML = formatChangelog();
  modal.style.display = 'flex';
}

// Hide changelog modal
function hideChangelog() {
  const modal = document.getElementById('changelogModal');
  modal.style.display = 'none';
}

// Show usecase selection modal
function showUsecaseModal() {
  const modal = document.getElementById('usecaseModal');
  if (modal) {
    modal.style.display = 'flex';
    
    // Highlight the currently selected option
    const currentUsecase = document.getElementById('usecaseIndicatorText')?.textContent?.toLowerCase() || 'all';
    document.querySelectorAll('.usecase-option').forEach(option => {
      const optionUsecase = option.getAttribute('data-usecase');
      if (optionUsecase === currentUsecase) {
        option.style.backgroundColor = '#e6f7f4';
        option.style.borderColor = '#1BA88C';
      } else {
        option.style.backgroundColor = '#ffffff';
        option.style.borderColor = '#e1e4e8';
      }
    });
  }
}

// Hide usecase selection modal
function hideUsecaseModal() {
  const modal = document.getElementById('usecaseModal');
  if (modal) {
    modal.style.display = 'none';
  }
}

// Function to format usecase name for display
function formatUsecaseName(usecase) {
  if (!usecase) return 'All';
  return usecase.charAt(0).toUpperCase() + usecase.slice(1);
}

// Function to update usecase indicator text
function updateUsecaseIndicator(usecase) {
  const indicator = document.getElementById('usecaseIndicatorText');
  if (indicator) {
    indicator.textContent = formatUsecaseName(usecase);
  }
}

// Function to filter menu options based on selected usecase
function filterMenuOptionsByUsecase(usecase) {
  const menuOptions = document.querySelectorAll('#mainMenuPage .menu-option');
  
  menuOptions.forEach(option => {
    // Check if the option has the matching usecase class
    const shouldShow = 
      usecase === 'all' || 
      option.classList.contains(`usecase-${usecase}`);
    
    option.style.display = shouldShow ? 'flex' : 'none';
  });
  
  // Update the indicator text
  updateUsecaseIndicator(usecase);
}

// Function to load and apply saved usecase preference
function loadUsecasePreference(showModalIfMissing = false) {
  console.log('[Usecase] Loading usecase preference...');
  try {
    // Try sync storage first
    chrome.storage.sync.get(['selectedUsecase'], (result) => {
      console.log('[Usecase] Sync storage result:', result);
      if (chrome.runtime.lastError) {
        console.error('[Usecase] Error loading usecase preference from sync:', chrome.runtime.lastError);
        // Try local storage as fallback
        console.log('[Usecase] Attempting to load from local storage as fallback');
        chrome.storage.local.get(['selectedUsecase'], (localResult) => {
          console.log('[Usecase] Local storage result:', localResult);
          const usecase = localResult.selectedUsecase;
          
          if (!usecase && showModalIfMissing) {
            // No preference found, show modal
            console.log('[Usecase] No preference found, showing modal');
            showUsecaseModal();
          } else {
            const finalUsecase = usecase || 'all';
            console.log('[Usecase] Using usecase from local storage:', finalUsecase);
            filterMenuOptionsByUsecase(finalUsecase);
            console.log('[Usecase] Applied usecase:', finalUsecase);
          }
        });
        return;
      }
      
      const usecase = result.selectedUsecase;
      
      if (!usecase && showModalIfMissing) {
        // No preference found, show modal
        console.log('[Usecase] No preference found, showing modal');
        showUsecaseModal();
      } else {
        const finalUsecase = usecase || 'all'; // Default to 'all' if not set
        console.log('[Usecase] Using usecase from sync storage:', finalUsecase);
        filterMenuOptionsByUsecase(finalUsecase);
        console.log('[Usecase] Applied usecase:', finalUsecase);
      }
    });
  } catch (error) {
    console.error('[Usecase] Error accessing storage:', error);
    if (showModalIfMissing) {
      // On error, show modal to let user select
      console.log('[Usecase] Error occurred, showing modal');
      showUsecaseModal();
    } else {
      // Fallback to default
      filterMenuOptionsByUsecase('all');
      console.log('[Usecase] Using default usecase: all (error fallback)');
    }
  }
}

// Function to save usecase preference
function saveUsecasePreference(usecase) {
  console.log('[Usecase] Attempting to save usecase preference:', usecase);
  try {
    chrome.storage.sync.set({ selectedUsecase: usecase }, () => {
      if (chrome.runtime.lastError) {
        console.error('[Usecase] Error saving usecase preference to sync:', chrome.runtime.lastError);
        // Try using local storage as fallback
        console.log('[Usecase] Attempting to save to local storage as fallback');
        chrome.storage.local.set({ selectedUsecase: usecase }, () => {
          if (chrome.runtime.lastError) {
            console.error('[Usecase] Error saving to local storage:', chrome.runtime.lastError);
          } else {
            console.log('[Usecase] Successfully saved to local storage:', usecase);
          }
        });
      } else {
        console.log('[Usecase] Successfully saved to sync storage:', usecase);
      }
    });
  } catch (error) {
    console.error('[Usecase] Error accessing storage for save:', error);
    // Try using local storage as fallback
    try {
      console.log('[Usecase] Attempting to save to local storage as fallback (catch block)');
      chrome.storage.local.set({ selectedUsecase: usecase }, () => {
        if (chrome.runtime.lastError) {
          console.error('[Usecase] Error saving to local storage (catch block):', chrome.runtime.lastError);
        } else {
          console.log('[Usecase] Successfully saved to local storage (catch block):', usecase);
        }
      });
    } catch (localError) {
      console.error('[Usecase] Error saving to local storage:', localError);
    }
  }
}

// Navigation Event Listeners
document.addEventListener("DOMContentLoaded", () => {
  // Load and display extension version from manifest
  try {
    const manifest = chrome.runtime.getManifest();
    const versionText = manifest.version ? `Version: ${manifest.version}` : 'Version: Unknown';
    const versionElement = document.getElementById('extensionVersion');
    if (versionElement) {
      versionElement.textContent = versionText;
      versionElement.addEventListener('click', showChangelog);
    }
    const mainMenuFooterVersion = document.getElementById('mainMenuFooterVersion');
    if (mainMenuFooterVersion) {
      mainMenuFooterVersion.textContent = versionText;
      mainMenuFooterVersion.addEventListener('click', showChangelog);
    }
    const headerVersionEl = document.getElementById('headerVersion');
    if (headerVersionEl && manifest.version) {
      headerVersionEl.textContent = `v${manifest.version}`;
    }
  } catch (error) {
    console.error('Failed to load extension version:', error);
    const versionElement = document.getElementById('extensionVersion');
    if (versionElement) {
      versionElement.textContent = 'Version: Unknown';
    }
    const mainMenuFooterVersion = document.getElementById('mainMenuFooterVersion');
    if (mainMenuFooterVersion) {
      mainMenuFooterVersion.textContent = 'Version: Unknown';
    }
  }

  // Load and apply saved usecase preference (do this first)
  // Show modal if no preference exists (first time opening)
  loadUsecasePreference(true);
  updateMainMenuCapacityStatus();
  updateMainMenuDuplicateStatus();
  refreshMainMenuUpdateRequiredOverlay();

  // Handle usecase indicator click
  const usecaseIndicator = document.getElementById('usecaseIndicator');
  if (usecaseIndicator) {
    usecaseIndicator.addEventListener('click', showUsecaseModal);
  }
  
  // Handle usecase modal option clicks
  document.querySelectorAll('.usecase-option').forEach(option => {
    option.addEventListener('click', (e) => {
      const selectedUsecase = e.currentTarget.getAttribute('data-usecase');
      console.log('[Usecase] Selected usecase from modal:', selectedUsecase);
      saveUsecasePreference(selectedUsecase);
      filterMenuOptionsByUsecase(selectedUsecase);
      hideUsecaseModal();
    });
  });
  
  // Usecase modal close handlers
  document.getElementById('closeUsecaseModal').addEventListener('click', hideUsecaseModal);
  document.getElementById('usecaseModal').addEventListener('click', (e) => {
    if (e.target.id === 'usecaseModal') {
      hideUsecaseModal();
    }
  });
  
  // Changelog modal close handlers
  document.getElementById('closeChangelog').addEventListener('click', hideChangelog);
  document.getElementById('changelogModal').addEventListener('click', (e) => {
    if (e.target.id === 'changelogModal') {
      hideChangelog();
    }
  });

  // Navigation to pages
  document.getElementById("goToDuplicatePage").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('duplicatePage');
    loadCustomerTypes(); // Load data when entering duplicate page
  });
  
  document.getElementById("goToMappingDataPage").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('mappingDataPage');
  });
  
  // Folder toggle handlers
  document.getElementById("fareHarborDashboardFolder").addEventListener("click", () => {
    const header = document.getElementById("fareHarborDashboardFolder");
    const content = document.getElementById("fareHarborDashboardContent");
    header.classList.toggle("expanded");
    content.classList.toggle("expanded");
  });
  
  document.getElementById("otaFolder").addEventListener("click", () => {
    const header = document.getElementById("otaFolder");
    const content = document.getElementById("otaContent");
    header.classList.toggle("expanded");
    content.classList.toggle("expanded");
  });
  
  document.getElementById("goToExpediaPage").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('expediaPage');
  });
  
  document.getElementById("goToFareHarborResellerItemsPage").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('fareHarborResellerItemsPage');
  });
  
  document.getElementById("goToAvailabilityAuditPage").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('availabilityAuditPage');
    checkAvailabilityPageCompatibility(); // Check if current page supports auditing
  });

  setupCapacityBatchControls();
  
  document.getElementById("goToActivityListingsPage").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('activityListingsPage');
  });
  
  document.getElementById("goToFareHarborItemsPage").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('fareHarborItemsPage');
  });
  
  document.getElementById("goToViatorMappingFilePage").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('viatorMappingFilePage');
  });
  
  document.getElementById("goToAirbnbMappingFilePage").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('airbnbMappingFilePage');
  });
  
  document.getElementById("goToGetYourGuideProductsPage").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('getYourGuideProductsPage');
  });

  document.getElementById("goToGetYourGuideProductsV2Page").addEventListener("click", () => {
    clearStatus();
    showPage('getYourGuideProductsV2Page');
  });
  
  document.getElementById("goToViatorProductsPage").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('viatorProductsPage');
  });
  
  document.getElementById("goToCopyReportPage").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('copyReportPage');
  });

  document.getElementById("goToUpdatesPage").addEventListener("click", () => {
    clearStatus();
    showPage('updatesPage');
  });

  document.getElementById("backFromUpdates").addEventListener("click", () => {
    clearStatus();
    document.getElementById("updatesCheckHint").style.display = "none";
    showPage('mainMenuPage');
  });

  document.getElementById("updatesCheckAgainBtn").addEventListener("click", () => {
    const btn = document.getElementById("updatesCheckAgainBtn");
    const hint = document.getElementById("updatesCheckHint");
    btn.disabled = true;
    hint.style.display = "block";
    hint.textContent = "Checking…";
    chrome.runtime.sendMessage({ type: "checkExtensionUpdate" }, () => {
      btn.disabled = false;
      if (chrome.runtime.lastError) {
        hint.textContent = "Could not run check. Try reloading the extension.";
        loadUpdatesUI();
        return;
      }
      hint.textContent = "Done. Values below are refreshed.";
      loadUpdatesUI();
      setTimeout(() => {
        hint.style.display = "none";
      }, 4000);
    });
  });

  document.getElementById("updatesDownloadBtn").addEventListener("click", () => {
    chrome.storage.local.get(["downloadUrl"], (r) => {
      const url = (r.downloadUrl || "").trim();
      if (!/^https?:\/\//i.test(url)) {
        return;
      }
      chrome.tabs.create({ url });
    });
  });

  document.getElementById("updatesOpenExtensionsBtn").addEventListener("click", () => {
    chrome.tabs.create({ url: "chrome://extensions/" }, () => {
      if (chrome.runtime.lastError) {
        alert(
          "Could not open the page automatically. Open a new tab and type chrome://extensions in the address bar (or Menu → Extensions → Manage extensions)."
        );
      }
    });
  });

  const mainMenuUpdateOverlay = document.getElementById("mainMenuUpdateRequiredOverlay");
  if (mainMenuUpdateOverlay) {
    mainMenuUpdateOverlay.addEventListener("click", (e) => {
      if (e.target === mainMenuUpdateOverlay) {
        hideMainMenuUpdateRequiredOverlay();
      }
    });
    const goUpdates = document.getElementById("mainMenuUpdateGoToUpdatesBtn");
    const dismiss = document.getElementById("mainMenuUpdateDismissBtn");
    if (goUpdates) {
      goUpdates.addEventListener("click", () => {
        hideMainMenuUpdateRequiredOverlay();
        clearStatus();
        showPage("updatesPage");
      });
    }
    if (dismiss) {
      dismiss.addEventListener("click", () => {
        hideMainMenuUpdateRequiredOverlay();
      });
    }
    const dialog = mainMenuUpdateOverlay.querySelector(".main-menu-update-dialog");
    if (dialog) {
      dialog.addEventListener("click", (e) => {
        e.stopPropagation();
      });
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    const keys = Object.keys(changes);
    if (!keys.some((k) => UPDATES_STORAGE_KEYS.includes(k))) return;
    const updatesPage = document.getElementById("updatesPage");
    if (updatesPage && updatesPage.classList.contains("active")) {
      loadUpdatesUI();
    }
    refreshMainMenuUpdateRequiredOverlay();
  });
  
  // Back to main menu
  document.getElementById("backFromDuplicate").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('mainMenuPage');
  });
  
  document.getElementById("backFromMappingData").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('mainMenuPage');
  });
  
  document.getElementById("backFromExpedia").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('mappingDataPage');
  });
  
  document.getElementById("backFromFareHarborResellerItems").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('mappingDataPage');
  });
  
  document.getElementById("backFromViatorMappingFile").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('mappingDataPage');
  });
  
  document.getElementById("backFromAirbnbMappingFile").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('mappingDataPage');
  });
  
  document.getElementById("backFromAvailabilityAudit").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('mainMenuPage');
  });
  
  document.getElementById("backFromActivityListings").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('mappingDataPage');
  });
  
  document.getElementById("backFromFareHarborItems").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('mappingDataPage');
  });
  
  document.getElementById("backFromGetYourGuideProducts").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('mappingDataPage');
  });

  document.getElementById("backFromGetYourGuideProductsV2").addEventListener("click", () => {
    clearStatus();
    showPage('mappingDataPage');
  });
  
  document.getElementById("backFromViatorProducts").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('mappingDataPage');
  });
  
  document.getElementById("backFromCopyReport").addEventListener("click", () => {
    clearStatus(); // Clear any existing status messages
    showPage('mainMenuPage');
  });
  
  // Handle timestamp format selection
  document.getElementById("timestampMode").addEventListener("change", (e) => {
    const selectedMode = e.target.value;
    const getYourGuideGroup = document.getElementById("getYourGuideGroup");
    const viatorGroup = document.getElementById("viatorGroup");
    const manualDateGroup = document.getElementById("manualDateGroup");
    const manualTimeGroup = document.getElementById("manualTimeGroup");
    
    // Hide all groups first
    getYourGuideGroup.style.display = 'none';
    viatorGroup.style.display = 'none';
    manualDateGroup.style.display = 'none';
    manualTimeGroup.style.display = 'none';
    
    // Show the selected group
    if (selectedMode === 'getyourguide') {
      getYourGuideGroup.style.display = 'block';
    } else if (selectedMode === 'viator') {
      viatorGroup.style.display = 'block';
    } else if (selectedMode === 'manual') {
      manualDateGroup.style.display = 'block';
      manualTimeGroup.style.display = 'block';
    }
  });
  
  // Handle GetYourGuide timestamp input with real-time conversion
  document.getElementById("getYourGuideDateTime").addEventListener("input", (e) => {
    const berlinTimestamp = e.target.value.trim();
    if (berlinTimestamp) {
      convertGetYourGuideTimestamp(berlinTimestamp);
    } else {
      hideGetYourGuideConversion();
    }
  });

  // Handle Viator timestamp input with real-time conversion
  document.getElementById("viatorDateTime").addEventListener("input", (e) => {
    const utcTimestamp = e.target.value.trim();
    if (utcTimestamp) {
      convertViatorTimestamp(utcTimestamp);
    } else {
      hideViatorConversion();
    }
  });
  
  // Handle customer type selection change to update base name
  document.getElementById("customerTypeSelect").addEventListener("change", () => {
    updateBaseNameFromSelection();
  });
});

// Update base name field based on selected customer type
function updateBaseNameFromSelection() {
  const select = document.getElementById("customerTypeSelect");
  const baseNameInput = document.getElementById("basename");
  
  if (select.selectedIndex >= 0) {
    const selectedOption = select.options[select.selectedIndex];
    const customerTypeName = selectedOption.getAttribute('data-name') || selectedOption.textContent;
    
    console.log(`[updateBaseNameFromSelection] Selected option data-name: "${selectedOption.getAttribute('data-name')}"`);
    console.log(`[updateBaseNameFromSelection] Selected option textContent: "${selectedOption.textContent}"`);
    console.log(`[updateBaseNameFromSelection] Final customerTypeName: "${customerTypeName}" (length: ${customerTypeName.length})`);
    
    // Only update if the base name field hasn't been manually modified
    // We'll consider it unmodified if it's the default "Adult" or matches a previous customer type name
    const currentBaseName = baseNameInput.value.trim();
    
    // Check if current value is likely a default (matches any existing customer type name)
    const allOptions = Array.from(select.options);
    const isLikelyDefault = currentBaseName === "Adult" || 
                           allOptions.some(option => option.getAttribute('data-name') === currentBaseName);
    
    if (isLikelyDefault || currentBaseName === "") {
      baseNameInput.value = customerTypeName;
      console.log(`[updateBaseNameFromSelection] Updated base name to: "${customerTypeName}"`);
      console.log(`[updateBaseNameFromSelection] Input field value after update: "${baseNameInput.value}" (length: ${baseNameInput.value.length})`);
    } else {
      console.log(`[updateBaseNameFromSelection] Skipping update - current value "${currentBaseName}" appears to be manually set`);
    }
  }
}

// Load customer types for the duplicate page
function loadCustomerTypes() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];

    if (!tab || !tab.id) {
      showStatus("No active tab found", true);
      return;
    }

    chrome.tabs.sendMessage(tab.id, { action: "getCustomerTypes" }, (res) => {
      if (chrome.runtime.lastError) {
        showStatus("Error loading Customer Types: Options & Prices page not found", true, true);
        setDuplicateButtonState(false); // Disable button on error
        return;
      }
      
      if (!res || !res.customerTypes) {
        showStatus("No customer types found on this page", true, true);
        setDuplicateButtonState(false); // Disable button when no customer types
        return;
      }
      
      const select = document.getElementById("customerTypeSelect");
      select.innerHTML = ''; // Clear existing options
      
      res.customerTypes.forEach(type => {
        console.log(`[loadCustomerTypes] Processing customer type: "${type.name}" (length: ${type.name.length})`);
        
        const option = document.createElement("option");
        option.value = type.domIndex;
        option.textContent = type.name;
        option.setAttribute('data-name', type.name); // Store the name for easy access
        select.appendChild(option);
        
        console.log(`[loadCustomerTypes] Added option - textContent: "${option.textContent}", data-name: "${option.getAttribute('data-name')}"`);
      });
      
      if (res.customerTypes.length === 0) {
        showStatus("No customer types found on this page", true, true);
        setDuplicateButtonState(false); // Disable button when no customer types
      } else {
        // Set initial base name to the first customer type
        updateBaseNameFromSelection();
        // Clear any existing error messages since we found customer types
        clearStatus();
        setDuplicateButtonState(true); // Enable button when customer types are found
      }
    });
  });
}

// Duplicate Customer Types Handler
document.addEventListener("DOMContentLoaded", () => {
  // Initialize button as disabled until customer types are loaded
  setDuplicateButtonState(false);
  
  document.getElementById("multipleDuplicateBtn").addEventListener("click", async () => {
    const countInput = document.getElementById("duplicateCount");
    const baseInput = document.getElementById("basename");
    const typeSelect = document.getElementById("customerTypeSelect");
    const priceInput = document.getElementById("priceInput");

    const count = parseInt(countInput.value, 10);
    const basename = baseInput.value.trim();
    const baseIndex = parseInt(typeSelect.value, 10);
    const priceText = priceInput.value.trim();

    console.log(`[multipleDuplicateBtn] Retrieved basename from input: "${basename}" (length: ${basename.length}, bytes: ${new Blob([basename]).size})`);

    // Validation
    if (isNaN(count) || count <= 0) {
      showStatus("Please enter a valid number greater than 0.", true);
      return;
    }

    if (!basename) {
      showStatus("Please enter a base name.", true);
      return;
    }
    
    if (typeSelect.options.length === 0) {
      showStatus("No customer types available. Please make sure you're on the correct page.", true, true);
      return;
    }

    // Validate price if provided
    let price = null;
    if (priceText) {
      const priceValidation = validatePriceFormat(priceText);
      if (!priceValidation.valid) {
        showStatus(`Invalid price: ${priceValidation.error}`, true);
        priceInput.focus();
        return;
      }
      price = priceValidation.price;
    }

    console.log("Starting multiple duplicates:", { count, basename, baseIndex });
    
    // Show processing status
    showStatus(`Starting duplication of ${count} customer types...`);
    
    // Disable button during processing
    const btn = document.getElementById("multipleDuplicateBtn");
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = "Processing...";

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab || !tab.id) {
        showStatus("No active tab found", true);
        btn.disabled = false;
        btn.textContent = originalText;
        return;
      }

      const messageData = {
        action: "runMultipleDuplicates",
        count,
        basename,
        baseIndex,
        price
      };
      
      console.log(`[multipleDuplicateBtn] Sending message with basename: "${messageData.basename}" (length: ${messageData.basename.length})`);
      
      chrome.tabs.sendMessage(tab.id, messageData, (response) => {
        btn.disabled = false;
        btn.textContent = originalText;
        
        if (chrome.runtime.lastError) {
          showStatus("Error: " + chrome.runtime.lastError.message, true);
          return;
        }
        
        if (response && response.status === "done") {
          showStatus(`Successfully created ${count} duplicate customer types!`);
        } else if (response && response.status === "error") {
          showStatus("Error: " + (response.error || "Unknown error occurred"), true);
        } else {
          showStatus("Duplication completed");
        }
      });
    });
  });
});




// Expedia Mapping Handler
document.addEventListener("DOMContentLoaded", () => {
  // Handler for single item extraction
  document.getElementById("extractBtnExpedia").addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab || !tab.id) {
      showStatus("No active tab found", true);
      return;
    }
    
    // Show processing status
    showStatus("Extracting mapping data...");
    
    // Disable button during processing
    const btn = document.getElementById("extractBtnExpedia");
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = "Processing...";

    chrome.tabs.sendMessage(tab.id, { action: "runExtract" }, (response) => {
      btn.disabled = false;
      btn.textContent = originalText;
      
      if (chrome.runtime.lastError) {
        showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
        return;
      }

      const data = response?.data;
      if (!data || data.length === 0) {
        showStatus("No single item data found on this page. Make sure you're on a Expedia single item configuration page.", true, true);
      } else {
        copyFormattedToClipboard(data);
        showStatus(`Successfully copied item to clipboard!`);
      }
    });
  });

  // Handler for complete mapping file extraction
  document.getElementById("extractBtnExpediaComplete").addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab || !tab.id) {
      showStatus("No active tab found", true);
      return;
    }
    
    // Show processing status
    showStatus("Extracting complete mapping file...");
    
    // Disable button during processing
    const btn = document.getElementById("extractBtnExpediaComplete");
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = "Processing...";

    chrome.tabs.sendMessage(tab.id, { action: "runCompleteExtract" }, (response) => {
      btn.disabled = false;
      btn.textContent = originalText;
      
      if (chrome.runtime.lastError) {
        showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
        return;
      }

      if (response && response.success) {
        // Copy HTML table to clipboard
        navigator.clipboard.writeText(response.htmlData)
          .then(() => {
            showStatus(`Successfully copied mapping file to clipboard!`);
          })
          .catch(err => {
            console.error("Clipboard copy failed:", err);
            showStatus(`Extracted ${response.count} reseller items, but clipboard copy failed. Data: ${response.htmlData.substring(0, 100)}...`, true);
          });
      } else {
        showStatus(response?.error || "No reseller items found on this page. Make sure you're on the Expedia reseller items page.", true, true);
      }
    });
  });
});

// FareHarbor Reseller Items Handler
document.addEventListener("DOMContentLoaded", () => {
  // Toggle switch state management
  let useChannelName = false; // false = Item name, true = Channel name
  let useTSVFormat = false; // false = HTML format (default), true = TSV format
  
  // Toggle switch functionality for name selection
  const nameToggle = document.getElementById("nameToggle");
  const itemNameLabel = document.getElementById("itemNameLabel");
  const channelNameLabel = document.getElementById("channelNameLabel");
  
  if (nameToggle) {
  nameToggle.addEventListener("click", () => {
    useChannelName = !useChannelName;
    
    // Update visual state
    nameToggle.classList.toggle("active", useChannelName);
    itemNameLabel.classList.toggle("active", !useChannelName);
    channelNameLabel.classList.toggle("active", useChannelName);
    
    console.log("Toggle state changed to:", useChannelName ? "Channel name" : "Item name");
  });
  }
  
  // Toggle switch functionality for format selection
  const formatToggle = document.getElementById("formatToggle");
  const htmlFormatLabel = document.getElementById("htmlFormatLabel");
  const tsvFormatLabel = document.getElementById("tsvFormatLabel");
  
  if (formatToggle) {
    formatToggle.addEventListener("click", () => {
      useTSVFormat = !useTSVFormat;
      
      // Update visual state
      formatToggle.classList.toggle("active", useTSVFormat);
      htmlFormatLabel.classList.toggle("active", !useTSVFormat);
      tsvFormatLabel.classList.toggle("active", useTSVFormat);
      
      console.log("Format toggle state changed to:", useTSVFormat ? "For sheets" : "For Zendesk");
    });
  }
  
  // Function to get current toggle state
  function getToggleState() {
    return useChannelName;
  }
  
  // Function to get current format toggle state
  function getFormatToggleState() {
    return useTSVFormat;
  }
  // Handler for single item extraction
  document.getElementById("extractBtnFareHarborResellerItemsSingle").addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab || !tab.id) {
      showStatus("No active tab found", true);
      return;
    }
    
    // Show processing status
    showStatus("Extracting single item data...");
    
    // Disable button during processing
    const btn = document.getElementById("extractBtnFareHarborResellerItemsSingle");
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = "Processing...";

    chrome.tabs.sendMessage(tab.id, { 
      action: "runFareHarborResellerItemsSingleExtract",
      useChannelName: getToggleState(),
      useTSVFormat: getFormatToggleState()
    }, (response) => {
      btn.disabled = false;
      btn.textContent = originalText;
      
      if (chrome.runtime.lastError) {
        showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
        return;
      }

      if (response && response.success) {
        // Copy data to clipboard based on format toggle
        const dataToCopy = getFormatToggleState() ? response.tsvData : response.htmlData;
        const formatName = getFormatToggleState() ? "TSV" : "HTML";
        
        navigator.clipboard.writeText(dataToCopy)
          .then(() => {
            showStatus(`Successfully copied item to clipboard (${formatName} format)!`);
          })
          .catch(err => {
            console.error("Clipboard copy failed:", err);
            showStatus(`Extracted single item data, but clipboard copy failed. Data: ${dataToCopy.substring(0, 100)}...`, true);
          });
      } else {
        showStatus(response?.error || "No single item data found on this page. Make sure you're on a GetYourGuide single item page.", true, true);
      }
    });
  });

  // Handler for complete mapping file extraction
  document.getElementById("extractBtnFareHarborResellerItems").addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab || !tab.id) {
      showStatus("No active tab found", true);
      return;
    }
    
    // Show processing status
    showStatus("Extracting reseller items data...");
    
    // Disable button during processing
    const btn = document.getElementById("extractBtnFareHarborResellerItems");
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = "Processing...";

    chrome.tabs.sendMessage(tab.id, { 
      action: "runFareHarborResellerItemsExtract",
      useChannelName: getToggleState(),
      useTSVFormat: getFormatToggleState()
    }, (response) => {
      btn.disabled = false;
      btn.textContent = originalText;
      
      if (chrome.runtime.lastError) {
        showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
        return;
      }

      if (response && response.success) {
        // Copy data to clipboard based on format toggle
        const dataToCopy = getFormatToggleState() ? response.tsvData : response.htmlData;
        const formatName = getFormatToggleState() ? "TSV" : "HTML";
        
        navigator.clipboard.writeText(dataToCopy)
          .then(() => {
            showStatus(`Successfully copied mapping file to clipboard (${formatName} format)!`);
          })
          .catch(err => {
            console.error("Clipboard copy failed:", err);
            showStatus(`Extracted ${response.count} reseller items, but clipboard copy failed. Data: ${dataToCopy.substring(0, 100)}...`, true);
          });
      } else {
        showStatus(response?.error || "No reseller items found on this page. Make sure you're on the FareHarbor reseller items page.", true, true);
      }
    });
  });
});

// Viator Mapping File Handler
document.addEventListener("DOMContentLoaded", () => {
  // Toggle switch state management
  let viatorUseTSVFormat = true; // Default to TSV format (For sheets)
  
  // Toggle switch functionality for format selection
  const viatorFormatToggle = document.getElementById("viatorFormatToggle");
  const viatorHtmlFormatLabel = document.getElementById("viatorHtmlFormatLabel");
  const viatorTsvFormatLabel = document.getElementById("viatorTsvFormatLabel");
  
  if (viatorFormatToggle) {
    viatorFormatToggle.addEventListener("click", () => {
      viatorUseTSVFormat = !viatorUseTSVFormat;
      
      // Update visual state
      viatorFormatToggle.classList.toggle("active", viatorUseTSVFormat);
      viatorHtmlFormatLabel.classList.toggle("active", !viatorUseTSVFormat);
      viatorTsvFormatLabel.classList.toggle("active", viatorUseTSVFormat);
      
      console.log("Viator Format toggle state changed to:", viatorUseTSVFormat ? "For sheets" : "For Zendesk");
    });
  }
  
  // Function to get current format toggle state
  function getViatorFormatToggleState() {
    return viatorUseTSVFormat;
  }
  
  // Handler for complete mapping file extraction
  const extractBtnViatorMappingFile = document.getElementById("extractBtnViatorMappingFile");
  if (extractBtnViatorMappingFile) {
    extractBtnViatorMappingFile.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab || !tab.id) {
        showStatus("No active tab found", true);
        return;
      }
      
      // Show processing status
      showStatus("Extracting Viator mapping file data...");
      
      // Disable button during processing
      const btn = document.getElementById("extractBtnViatorMappingFile");
      const originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Processing...";

      chrome.tabs.sendMessage(tab.id, { 
        action: "runViatorMappingFileExtract",
        useTSVFormat: getViatorFormatToggleState()
      }, (response) => {
        btn.disabled = false;
        btn.textContent = originalText;
        
        if (chrome.runtime.lastError) {
          showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
          return;
        }

        if (response && response.success) {
          // Copy data to clipboard based on format toggle
          const dataToCopy = getViatorFormatToggleState() ? response.tsvData : response.htmlData;
          const formatName = getViatorFormatToggleState() ? "For sheets" : "For Zendesk";
          
          navigator.clipboard.writeText(dataToCopy)
            .then(() => {
              showStatus(`Successfully copied mapping file to clipboard (${formatName} format)!`);
            })
            .catch(err => {
              console.error("Clipboard copy failed:", err);
              showStatus(`Extracted ${response.count} items, but clipboard copy failed. Data: ${dataToCopy.substring(0, 100)}...`, true);
            });
        } else {
          showStatus(response?.error || "No Viator mapping data found on this page. Make sure you're on the Viator reseller items page.", true, true);
        }
      });
    });
  }
});

// Airbnb Mapping File Handler
document.addEventListener("DOMContentLoaded", () => {
  // Toggle switch state management
  let airbnbUseTSVFormat = true; // Default to TSV format (For sheets)
  let airbnbUseDetailed = false; // Default to Simple mode
  
  // Toggle switch functionality for Simple/Detailed selection
  const airbnbSimpleDetailedToggle = document.getElementById("airbnbSimpleDetailedToggle");
  const airbnbSimpleLabel = document.getElementById("airbnbSimpleLabel");
  const airbnbDetailedLabel = document.getElementById("airbnbDetailedLabel");
  
  if (airbnbSimpleDetailedToggle) {
    airbnbSimpleDetailedToggle.addEventListener("click", () => {
      airbnbUseDetailed = !airbnbUseDetailed;
      
      // Update visual state
      airbnbSimpleDetailedToggle.classList.toggle("active", airbnbUseDetailed);
      airbnbSimpleLabel.classList.toggle("active", !airbnbUseDetailed);
      airbnbDetailedLabel.classList.toggle("active", airbnbUseDetailed);
      
      console.log("Airbnb Simple/Detailed toggle state changed to:", airbnbUseDetailed ? "Detailed" : "Simple");
    });
  }
  
  // Toggle switch functionality for format selection
  const airbnbFormatToggle = document.getElementById("airbnbFormatToggle");
  const airbnbHtmlFormatLabel = document.getElementById("airbnbHtmlFormatLabel");
  const airbnbTsvFormatLabel = document.getElementById("airbnbTsvFormatLabel");
  
  if (airbnbFormatToggle) {
    airbnbFormatToggle.addEventListener("click", () => {
      airbnbUseTSVFormat = !airbnbUseTSVFormat;
      
      // Update visual state
      airbnbFormatToggle.classList.toggle("active", airbnbUseTSVFormat);
      airbnbHtmlFormatLabel.classList.toggle("active", !airbnbUseTSVFormat);
      airbnbTsvFormatLabel.classList.toggle("active", airbnbUseTSVFormat);
      
      console.log("Airbnb Format toggle state changed to:", airbnbUseTSVFormat ? "For sheets" : "For Zendesk");
    });
  }
  
  // Function to get current format toggle state
  function getAirbnbFormatToggleState() {
    return airbnbUseTSVFormat;
  }
  
  // Function to get current Simple/Detailed toggle state
  function getAirbnbSimpleDetailedToggleState() {
    return airbnbUseDetailed;
  }
  
  // Handler for complete mapping file extraction
  const extractBtnAirbnbMappingFile = document.getElementById("extractBtnAirbnbMappingFile");
  if (extractBtnAirbnbMappingFile) {
    extractBtnAirbnbMappingFile.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab || !tab.id) {
        showStatus("No active tab found", true);
        return;
      }
      
      // Show processing status
      showStatus("Extracting Airbnb mapping file data...");
      
      // Disable button during processing
      const btn = document.getElementById("extractBtnAirbnbMappingFile");
      const originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Processing...";

      chrome.tabs.sendMessage(tab.id, { 
        action: "runAirbnbMappingFileExtract",
        useTSVFormat: getAirbnbFormatToggleState(),
        useDetailed: getAirbnbSimpleDetailedToggleState()
      }, (response) => {
        btn.disabled = false;
        btn.textContent = originalText;
        
        if (chrome.runtime.lastError) {
          showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
          return;
        }

        if (response && response.success) {
          // Copy data to clipboard based on format toggle
          const dataToCopy = getAirbnbFormatToggleState() ? response.tsvData : response.htmlData;
          const formatName = getAirbnbFormatToggleState() ? "For sheets" : "For Zendesk";
          
          navigator.clipboard.writeText(dataToCopy)
            .then(() => {
              showStatus(`Successfully copied mapping file to clipboard (${formatName} format)!`);
            })
            .catch(err => {
              console.error("Clipboard copy failed:", err);
              showStatus(`Extracted ${response.count} items, but clipboard copy failed. Data: ${dataToCopy.substring(0, 100)}...`, true);
            });
        } else {
          showStatus(response?.error || "No Airbnb mapping data found on this page. Make sure you're on the Airbnb reseller items page.", true, true);
        }
      });
    });
  }
});

// Copy Report Handler
document.addEventListener("DOMContentLoaded", () => {
  // Toggle switch state management
  let copyReportUseTSVFormat = true;
  
  const copyReportFormatToggle = document.getElementById('copyReportFormatToggle');
  const copyReportHtmlFormatLabel = document.getElementById('copyReportHtmlFormatLabel');
  const copyReportTsvFormatLabel = document.getElementById('copyReportTsvFormatLabel');
  
  function getCopyReportFormatToggleState() {
    return copyReportUseTSVFormat;
  }
  
  if (copyReportFormatToggle) {
    copyReportFormatToggle.addEventListener('click', () => {
      copyReportUseTSVFormat = !copyReportUseTSVFormat;
      copyReportFormatToggle.classList.toggle('active', copyReportUseTSVFormat);
      copyReportHtmlFormatLabel.classList.toggle('active', !copyReportUseTSVFormat);
      copyReportTsvFormatLabel.classList.toggle('active', copyReportUseTSVFormat);
    });
  }
  
  // Handler for copy report extraction
  const extractBtnCopyReport = document.getElementById("extractBtnCopyReport");
  if (extractBtnCopyReport) {
    extractBtnCopyReport.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab || !tab.id) {
        showStatus("No active tab found", true);
        return;
      }
      
      // Show processing status
      showStatus("Extracting report data...");
      
      // Disable button during processing
      const btn = document.getElementById("extractBtnCopyReport");
      const originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Processing...";

      chrome.tabs.sendMessage(tab.id, { 
        action: "runCopyReportExtract",
        useTSVFormat: getCopyReportFormatToggleState()
      }, (response) => {
        btn.disabled = false;
        btn.textContent = originalText;
        
        if (chrome.runtime.lastError) {
          showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
          return;
        }

        if (response && response.success) {
          // Copy data to clipboard based on format toggle
          const dataToCopy = getCopyReportFormatToggleState() ? response.tsvData : response.htmlData;
          const formatName = getCopyReportFormatToggleState() ? "For sheets" : "For Zendesk";
          
          navigator.clipboard.writeText(dataToCopy)
            .then(() => {
              showStatus(`Successfully copied report to clipboard (${formatName} format)!`);
            })
            .catch(err => {
              console.error("Clipboard copy failed:", err);
              showStatus(`Extracted ${response.rowCount} rows, but clipboard copy failed. Data: ${dataToCopy.substring(0, 100)}...`, true);
            });
        } else {
          showStatus(response?.error || "No report table found on this page. Make sure you're on a FareHarbor report page.", true, true);
        }
      });
    });
  }
});

// Activity Listings Handler
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("extractBtnActivityListings").addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab || !tab.id) {
      showStatus("No active tab found", true);
      return;
    }
    
    // Show processing status
    showStatus("Extracting activity listings data...");
    
    // Disable button during processing
    const btn = document.getElementById("extractBtnActivityListings");
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = "Processing...";
    
    // Show initial status
    showStatus("Starting extraction... Navigating to first page and checking all pages...", false);

    chrome.tabs.sendMessage(tab.id, { action: "runActivityListingsExtract" }, (response) => {
      btn.disabled = false;
      btn.textContent = originalText;
      
      if (chrome.runtime.lastError) {
        showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
        return;
      }

      if (response && response.success) {
        // Copy TSV data to clipboard (tab-separated for Google Sheets)
        navigator.clipboard.writeText(response.csvData)
          .then(() => {
            showStatus(`Successfully copied ${response.count} activity listings to clipboard! Ready to paste into Google Sheets.`);
          })
          .catch(err => {
            console.error("Clipboard copy failed:", err);
            showStatus(`Extracted ${response.count} activity listings, but clipboard copy failed. Data: ${response.csvData.substring(0, 100)}...`, true);
          });
      } else {
        showStatus(response?.error || "No activity listings found on this page. Make sure you're on the Activity Listings page.", true, true);
      }
    });
  });
});

// FareHarbor Items Handler
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("extractBtnFareHarborItems").addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab || !tab.id) {
      showStatus("No active tab found", true);
      return;
    }
    
    // Show processing status
    showStatus("Extracting FareHarbor items data...");
    
    // Disable button during processing
    const btn = document.getElementById("extractBtnFareHarborItems");
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = "Processing...";

    chrome.tabs.sendMessage(tab.id, { action: "runFareHarborItemsExtract" }, (response) => {
      btn.disabled = false;
      btn.textContent = originalText;
      
      if (chrome.runtime.lastError) {
        showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
        return;
      }

      if (response && response.success) {
        // Copy TSV data to clipboard (tab-separated for Google Sheets)
        navigator.clipboard.writeText(response.tsvData)
          .then(() => {
            showStatus(`Successfully copied ${response.count} items to clipboard! Ready to paste into Google Sheets.`);
          })
          .catch(err => {
            console.error("Clipboard copy failed:", err);
            showStatus(`Extracted ${response.count} items, but clipboard copy failed. Data: ${response.tsvData.substring(0, 100)}...`, true);
          });
      } else {
        showStatus(response?.error || "No FareHarbor items found on this page. Make sure you're on the Items list page and the ID column is visible.", true, true);
      }
    });
  });
});

// GetYourGuide Products Handler
document.addEventListener("DOMContentLoaded", () => {
  // Toggle switch state management
  let includeHeaderRow = false; // Default is off (no headers)
  
  // Toggle switch functionality
  const headerToggle = document.getElementById("headerToggle");
  const noHeaderLabel = document.getElementById("noHeaderLabel");
  const includeHeaderLabel = document.getElementById("includeHeaderLabel");
  
  if (headerToggle) {
    headerToggle.addEventListener("click", () => {
      includeHeaderRow = !includeHeaderRow;
      
      // Update visual state
      headerToggle.classList.toggle("active", includeHeaderRow);
      noHeaderLabel.classList.toggle("active", !includeHeaderRow);
      includeHeaderLabel.classList.toggle("active", includeHeaderRow);
      
      console.log("Header toggle state changed to:", includeHeaderRow ? "Include header row" : "No header row");
    });
  }
  
  // Function to get current toggle state
  function getHeaderToggleState() {
    return includeHeaderRow;
  }
  
  const extractBtn = document.getElementById("extractBtnGetYourGuideProducts");
  if (extractBtn) {
    extractBtn.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab || !tab.id) {
        showStatus("No active tab found", true);
        return;
      }
      
      // Show processing status
      showStatus("Extracting GetYourGuide products data...");
      
      // Disable button during processing
      const btn = document.getElementById("extractBtnGetYourGuideProducts");
      const originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Processing...";

      chrome.tabs.sendMessage(tab.id, { 
        action: "runGetYourGuideProductsExtract",
        includeHeaderRow: getHeaderToggleState()
      }, (response) => {
        btn.disabled = false;
        btn.textContent = originalText;
        
        if (chrome.runtime.lastError) {
          showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
          return;
        }

        if (response && response.success) {
          // Copy TSV data to clipboard (tab-separated for Google Sheets)
          navigator.clipboard.writeText(response.tsvData)
            .then(() => {
              showStatus(`Successfully copied ${response.count} products to clipboard! Ready to paste into Google Sheets.`);
            })
            .catch(err => {
              console.error("Clipboard copy failed:", err);
              showStatus(`Extracted ${response.count} products, but clipboard copy failed. Data: ${response.tsvData.substring(0, 100)}...`, true);
            });
        } else {
          showStatus(response?.error || "No GetYourGuide products found on this page. Make sure you're on a product page with options.", true, true);
        }
      });
    });
  }
  
  const extractAllBtn = document.getElementById("extractBtnGetYourGuideProductsAll");
  if (extractAllBtn) {
    extractAllBtn.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab || !tab.id) {
        showStatus("No active tab found", true);
        return;
      }
      
      // Show processing status
      showStatus("Finding all products and extracting data... This may take a while.");
      
      // Disable button during processing
      const btn = document.getElementById("extractBtnGetYourGuideProductsAll");
      const originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Processing...";

      chrome.tabs.sendMessage(tab.id, { 
        action: "runGetYourGuideProductsExtractAll",
        includeHeaderRow: getHeaderToggleState()
      }, (response) => {
        btn.disabled = false;
        btn.textContent = originalText;
        
        if (chrome.runtime.lastError) {
          showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
          return;
        }

        if (response && response.success) {
          // Copy TSV data to clipboard (tab-separated for Google Sheets)
          navigator.clipboard.writeText(response.tsvData)
            .then(() => {
              const pageText = response.pageCount > 1 ? ` from ${response.pageCount} pages` : '';
              showStatus(`Successfully copied ${response.count} products${pageText} to clipboard! Ready to paste into Google Sheets.`);
            })
            .catch(err => {
              console.error("Clipboard copy failed:", err);
              showStatus(`Extracted ${response.count} products, but clipboard copy failed. Data: ${response.tsvData.substring(0, 100)}...`, true);
            });
        } else {
          showStatus(response?.error || "No GetYourGuide products found on this page. Make sure you're on a products list page.", true, true);
        }
      });
    });
  }
});

// GetYourGuide Products V2 Handler
document.addEventListener("DOMContentLoaded", () => {
  let includeHeaderRowV2 = false;
  const headerToggleV2 = document.getElementById("headerToggleV2");
  const noHeaderLabelV2 = document.getElementById("noHeaderLabelV2");
  const includeHeaderLabelV2 = document.getElementById("includeHeaderLabelV2");

  if (headerToggleV2) {
    headerToggleV2.addEventListener("click", () => {
      includeHeaderRowV2 = !includeHeaderRowV2;
      headerToggleV2.classList.toggle("active", includeHeaderRowV2);
      noHeaderLabelV2.classList.toggle("active", !includeHeaderRowV2);
      includeHeaderLabelV2.classList.toggle("active", includeHeaderRowV2);
    });
  }

  const extractBtnV2 = document.getElementById("extractBtnGetYourGuideProductsV2");
  if (extractBtnV2) {
    extractBtnV2.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.id) {
        showStatus("No active tab found", true);
        return;
      }
      showStatus("Fetching GetYourGuide options via API...");
      const btn = document.getElementById("extractBtnGetYourGuideProductsV2");
      const originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Processing...";

      chrome.tabs.sendMessage(tab.id, {
        action: "runGetYourGuideProductsExtractV2",
        includeHeaderRow: includeHeaderRowV2
      }, (response) => {
        btn.disabled = false;
        btn.textContent = originalText;
        if (chrome.runtime.lastError) {
          showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
          return;
        }
        if (response && response.success) {
          navigator.clipboard.writeText(response.tsvData)
            .then(() => {
              showStatus(`Successfully copied ${response.count} options to clipboard!`);
            })
            .catch(() => {
              showStatus(`Extracted ${response.count} options, but clipboard copy failed.`, true);
            });
        } else {
          showStatus(response?.error || "No options returned. Ensure you're on a product details page.", true, true);
        }
      });
    });
  }

  const extractAllBtnV2 = document.getElementById("extractBtnGetYourGuideProductsAllV2");
  if (extractAllBtnV2) {
    extractAllBtnV2.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.id) {
        showStatus("No active tab found", true);
        return;
      }
      showStatus("Fetching all products via API... This may take a while.");
      const btn = document.getElementById("extractBtnGetYourGuideProductsAllV2");
      const originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Processing...";

      chrome.tabs.sendMessage(tab.id, {
        action: "runGetYourGuideProductsExtractAllV2",
        includeHeaderRow: includeHeaderRowV2
      }, (response) => {
        btn.disabled = false;
        btn.textContent = originalText;
        if (chrome.runtime.lastError) {
          showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
          return;
        }
        if (response && response.success) {
          navigator.clipboard.writeText(response.tsvData)
            .then(() => {
              const productText = response.productCount > 1 ? ` from ${response.productCount} products` : "";
              showStatus(`Successfully copied ${response.count} options${productText} to clipboard!`);
            })
            .catch(() => {
              showStatus(`Extracted ${response.count} options, but clipboard copy failed.`, true);
            });
        } else {
          showStatus(response?.error || "No options returned. Ensure you're on a products list page.", true, true);
        }
      });
    });
  }

  const gygCopyTokenBtn = document.getElementById("gygCopyTokenBtn");
  if (gygCopyTokenBtn) {
    gygCopyTokenBtn.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "getToken" }, (res) => {
        if (chrome.runtime.lastError) {
          showStatus("Extension error: " + chrome.runtime.lastError.message, true);
          return;
        }
        const token = res && res.gygAuthToken;
        if (token) {
          navigator.clipboard.writeText(token).then(() => {
            showStatus("GYG token copied to clipboard.");
          }).catch(() => showStatus("Clipboard copy failed.", true));
        } else {
          showStatus("No GYG token in storage. Open a product page so the extension can capture it.", true);
        }
      });
    });
  }

  const gygClearTokenBtn = document.getElementById("gygClearTokenBtn");
  if (gygClearTokenBtn) {
    gygClearTokenBtn.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "clearToken" }, (res) => {
        if (chrome.runtime.lastError) {
          showStatus("Extension error: " + chrome.runtime.lastError.message, true);
          return;
        }
        showStatus(res && res.ok ? "GYG token cleared." : "Clear failed.");
      });
    });
  }
});

// Viator Products Handler
document.addEventListener("DOMContentLoaded", () => {
  // Toggle switch state management
  let includeHeaderRow = false; // Default is off (no headers)
  
  // Toggle switch functionality
  const viatorHeaderToggle = document.getElementById("viatorHeaderToggle");
  const viatorNoHeaderLabel = document.getElementById("viatorNoHeaderLabel");
  const viatorIncludeHeaderLabel = document.getElementById("viatorIncludeHeaderLabel");
  
  if (viatorHeaderToggle) {
    viatorHeaderToggle.addEventListener("click", () => {
      includeHeaderRow = !includeHeaderRow;
      
      // Update visual state
      viatorHeaderToggle.classList.toggle("active", includeHeaderRow);
      viatorNoHeaderLabel.classList.toggle("active", !includeHeaderRow);
      viatorIncludeHeaderLabel.classList.toggle("active", includeHeaderRow);
      
      console.log("Viator header toggle state changed to:", includeHeaderRow ? "Include header row" : "No header row");
    });
  }
  
  // Function to get current toggle state
  function getHeaderToggleState() {
    return includeHeaderRow;
  }
  
  const extractBtn = document.getElementById("extractBtnViatorProducts");
  if (extractBtn) {
    extractBtn.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab || !tab.id) {
        showStatus("No active tab found", true);
        return;
      }
      
      // Show processing status
      showStatus("Extracting Viator products data...");
      
      // Disable button during processing
      const btn = document.getElementById("extractBtnViatorProducts");
      const originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Processing...";

      chrome.tabs.sendMessage(tab.id, { 
        action: "runViatorProductsExtract",
        includeHeaderRow: getHeaderToggleState()
      }, (response) => {
        btn.disabled = false;
        btn.textContent = originalText;
        
        if (chrome.runtime.lastError) {
          showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
          return;
        }

        if (response && response.success) {
          // Copy TSV data to clipboard (tab-separated for Google Sheets)
          navigator.clipboard.writeText(response.tsvData)
            .then(() => {
              showStatus(`Successfully copied ${response.count} products to clipboard! Ready to paste into Google Sheets.`);
            })
            .catch(err => {
              console.error("Clipboard copy failed:", err);
              showStatus(`Extracted ${response.count} products, but clipboard copy failed. Data: ${response.tsvData.substring(0, 100)}...`, true);
            });
        } else {
          showStatus(response?.error || "No Viator products found on this page. Make sure you're on a product page with options.", true, true);
        }
      });
    });
  }
  
  const extractAllBtn = document.getElementById("extractBtnViatorProductsAll");
  if (extractAllBtn) {
    extractAllBtn.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab || !tab.id) {
        showStatus("No active tab found", true);
        return;
      }
      
      // Show processing status
      showStatus("Finding all products and extracting data... This may take a while.");
      
      // Disable button during processing
      const btn = document.getElementById("extractBtnViatorProductsAll");
      const originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Processing...";

      chrome.tabs.sendMessage(tab.id, { 
        action: "runViatorProductsExtractAll",
        includeHeaderRow: getHeaderToggleState()
      }, (response) => {
        btn.disabled = false;
        btn.textContent = originalText;
        
        if (chrome.runtime.lastError) {
          showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
          return;
        }

        if (response && response.success) {
          // Copy TSV data to clipboard (tab-separated for Google Sheets)
          navigator.clipboard.writeText(response.tsvData)
            .then(() => {
              const pageText = response.pageCount > 1 ? ` from ${response.pageCount} pages` : '';
              showStatus(`Successfully copied ${response.count} products${pageText} to clipboard! Ready to paste into Google Sheets.`);
            })
            .catch(err => {
              console.error("Clipboard copy failed:", err);
              showStatus(`Extracted ${response.count} products, but clipboard copy failed. Data: ${response.tsvData.substring(0, 100)}...`, true);
            });
        } else {
          showStatus(response?.error || "No Viator products found on this page. Make sure you're on a products list page.", true, true);
        }
      });
    });
  }

  const openViatorProductTabsBtn = document.getElementById("openViatorProductTabsBtn");
  if (openViatorProductTabsBtn) {
    openViatorProductTabsBtn.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      if (!tab || !tab.id) {
        showStatus("No active tab found", true);
        return;
      }

      showStatus("Finding products...");
      const btn = openViatorProductTabsBtn;
      const originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Opening...";

      chrome.tabs.sendMessage(tab.id, { action: "getViatorProductCodes" }, (response) => {
        btn.disabled = false;
        btn.textContent = originalText;

        if (chrome.runtime.lastError) {
          showStatus("Extension error: " + chrome.runtime.lastError.message + " Reload the page and try again.", true);
          return;
        }

        if (!response || !response.success || !response.productCodes || response.productCodes.length === 0) {
          showStatus(response?.error || "No products found on this page. Make sure you're on a products list page.", true, true);
          return;
        }

        chrome.runtime.sendMessage({
          action: "openViatorProductTabs",
          productCodes: response.productCodes
        }, (bgResponse) => {
          if (chrome.runtime.lastError) {
            showStatus("Error opening tabs: " + chrome.runtime.lastError.message, true);
            return;
          }
          if (bgResponse && bgResponse.success) {
            const n = bgResponse.tabsOpened;
            showStatus("Opened " + n + " tab" + (n === 1 ? "" : "s") + ".");
          } else {
            showStatus(bgResponse?.error || "Failed to open tabs.", true);
          }
        });
      });
    });
  }
});


function copyToClipboard(data) {
  const text = data.map(row => row.join('\t')).join('\n');
  navigator.clipboard.writeText(text)
    .then(() => showStatus("Copied to clipboard"))
    .catch(err => showStatus("Failed to copy", true));
}

function copyFormattedToClipboard(data) {
  // Format the data in a more readable way for client communication
  let formattedText = '';
  
  data.forEach(row => {
    const [type, detail, code] = row;
    
    if (type === 'Activity') {
      formattedText += `Activity: ${detail}\n`;
      formattedText += `Code: ${code}\n\n`;
    } else if (type === 'Offer') {
      if (formattedText && !formattedText.includes('Available Times:')) {
        formattedText += 'Available Times:\n';
      }
      formattedText += `- ${detail} (${code})\n`;
    } else if (type === 'TicketType') {
      if (formattedText && !formattedText.includes('Ticket Types:')) {
        formattedText += '\nTicket Types:\n';
      }
      formattedText += `- ${detail} (${code})\n`;
    }
  });
  
  navigator.clipboard.writeText(formattedText)
    .then(() => console.log("Formatted data copied to clipboard"))
    .catch(err => {
      console.error("Clipboard copy failed", err);
      showStatus("Failed to copy to clipboard", true);
    });
}

// Global variable to track status timeout
let statusTimeout = null;

function showStatus(message, isError = false, persistent = false) {
  // Find the status message element in the currently active page
  const activePage = document.querySelector('.page.active');
  const el = activePage ? activePage.querySelector('#statusMessage') : document.getElementById("statusMessage");
  
  if (!el) {
    console.error("Status message element not found");
    return;
  }
  
  el.textContent = message;
  el.classList.remove('success', 'error');
  el.classList.add(isError ? 'error' : 'success');
  el.style.display = 'block';

  // Clear any existing timeout
  if (statusTimeout) {
    clearTimeout(statusTimeout);
    statusTimeout = null;
  }

  // Only auto-hide success messages or non-persistent errors
  if (!isError || !persistent) {
    const hideTimeout = isError ? 8000 : 5000;
    statusTimeout = setTimeout(() => {
      el.style.display = 'none';
      el.classList.remove('success', 'error');
      statusTimeout = null;
    }, hideTimeout);
  }
  // Persistent errors stay visible until manually cleared
}

function clearStatus() {
  // Find the status message element in the currently active page
  const activePage = document.querySelector('.page.active');
  const el = activePage ? activePage.querySelector('#statusMessage') : document.getElementById("statusMessage");
  
  if (!el) {
    console.error("Status message element not found");
    return;
  }
  
  el.style.display = 'none';
  el.classList.remove('success', 'error');
  el.textContent = '';
  
  // Clear any pending timeout
  if (statusTimeout) {
    clearTimeout(statusTimeout);
    statusTimeout = null;
  }
}

// Manage button state for duplicate functionality
function setDuplicateButtonState(enabled) {
  const btn = document.getElementById("multipleDuplicateBtn");
  if (btn) {
    btn.disabled = !enabled;
  }
}

// Timezone conversion functions for Viator timestamps
function convertViatorTimestamp(utcTimestamp) {
  try {
    // Parse the UTC timestamp
    let utcDate;
    
    // Handle different UTC timestamp formats
    if (utcTimestamp.includes('Z') || utcTimestamp.includes('+') || utcTimestamp.includes('T')) {
      // Full ISO format with timezone (e.g., "2025-08-24T04:09:46.713Z")
      utcDate = new Date(utcTimestamp);
    } else {
      // Simple datetime format, assume UTC (e.g., "2025-08-24T04:09:46")
      utcDate = new Date(utcTimestamp + 'Z');
    }
    
    if (isNaN(utcDate.getTime())) {
      throw new Error('Invalid timestamp format');
    }
    
    // Get user's timezone
    const userTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const userTimezoneOffset = utcDate.getTimezoneOffset();
    
    // Convert to user's local time
    const localDate = new Date(utcDate.getTime());
    
    // Format the converted time for display
    const localDateStr = localDate.toLocaleDateString();
    const localTimeStr = localDate.toLocaleTimeString();
    
    // Show conversion information
    showViatorConversion(utcTimestamp, localDate, userTimezone);
    
    return {
      localDate,
      userTimezone,
      valid: true
    };
    
  } catch (error) {
    console.error('Error converting Viator timestamp:', error);
    hideViatorConversion();
    return {
      valid: false,
      error: error.message
    };
  }
}

function showViatorConversion(utcTimestamp, localDate, userTimezone) {
  const conversionText = document.getElementById("viatorConversionText");
  const conversionDetails = document.getElementById("conversionDetails");
  
  const localDateStr = localDate.toLocaleDateString();
  const localTimeStr = localDate.toLocaleTimeString();
  
  // Check if the time zone is UTC
  const isUTC = userTimezone === 'UTC' || localDate.getTimezoneOffset() === 0;
  
  if (isUTC) {
    conversionDetails.textContent = `Your timezone is UTC - no conversion needed`;
    conversionDetails.style.color = "#6c757d";
  } else {
    conversionDetails.innerHTML = `Converted from UTC to <strong>${userTimezone}</strong>: ${localDateStr} at ${localTimeStr}`;
    conversionDetails.style.color = "#0066cc";
  }
  
  conversionText.style.display = 'block';
}

function hideViatorConversion() {
  const conversionText = document.getElementById("viatorConversionText");
  conversionText.style.display = 'none';
}

// GetYourGuide timezone conversion functions (Berlin time to local)
function convertGetYourGuideTimestamp(berlinTimestamp) {
  try {
    // Handle different timestamp formats
    if (!berlinTimestamp.includes('T')) {
      throw new Error('Invalid timestamp format');
    }
    
    // Get the user's timezone
    const userTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    
    // Simple approach: we want to convert from Berlin time to user's local time
    // The input represents a specific time in Berlin timezone
    
    // Step 1: Create a Date object from the timestamp (will be interpreted as local time)
    const inputDate = new Date(berlinTimestamp);
    
    // Step 2: Get Berlin's timezone offset vs UTC for this date (handles DST)
    const berlinFormatter = new Intl.DateTimeFormat('en', {
      timeZone: 'Europe/Berlin',
      timeZoneName: 'longOffset'
    });
    const berlinOffset = berlinFormatter.formatToParts(inputDate)
      .find(part => part.type === 'timeZoneName').value;
    
    // Step 3: Get user's timezone offset vs UTC for this date
    const userFormatter = new Intl.DateTimeFormat('en', {
      timeZone: userTimezone,
      timeZoneName: 'longOffset'
    });
    const userOffset = userFormatter.formatToParts(inputDate)
      .find(part => part.type === 'timeZoneName').value;
    
    console.log(`Berlin offset: ${berlinOffset}, User offset: ${userOffset}`);
    
    // Step 4: If offsets are the same, no conversion needed
    if (berlinOffset === userOffset) {
      showGetYourGuideConversion(berlinTimestamp, inputDate, userTimezone);
      return {
        localDate: inputDate,
        userTimezone,
        berlinTimezone: 'Europe/Berlin',
        valid: true
      };
    }
    
    // Step 5: Calculate the time difference and apply conversion
    const berlinOffsetMinutes = parseOffset(berlinOffset);
    const userOffsetMinutes = parseOffset(userOffset);
    const offsetDiffMs = (berlinOffsetMinutes - userOffsetMinutes) * 60 * 1000;
    
    const convertedDate = new Date(inputDate.getTime() - offsetDiffMs);
    
    // Show conversion information
    showGetYourGuideConversion(berlinTimestamp, convertedDate, userTimezone);
    
    return {
      localDate: convertedDate,
      userTimezone,
      berlinTimezone: 'Europe/Berlin',
      valid: true
    };
    
  } catch (error) {
    console.error('Error converting GetYourGuide timestamp:', error);
    hideGetYourGuideConversion();
    return {
      valid: false,
      error: error.message
    };
  }
}

// Helper function to parse timezone offset strings like "+02:00" or "-05:00"
function parseOffset(offsetStr) {
  const match = offsetStr.match(/([+-])(\d{2}):(\d{2})/);
  if (!match) return 0;
  
  const [, sign, hours, minutes] = match;
  const totalMinutes = parseInt(hours) * 60 + parseInt(minutes);
  return sign === '+' ? totalMinutes : -totalMinutes;
}

function showGetYourGuideConversion(berlinTimestamp, localDate, userTimezone) {
  const conversionText = document.getElementById("getYourGuideConversionText");
  const conversionDetails = document.getElementById("getYourGuideConversionDetails");
  
  const localDateStr = localDate.toLocaleDateString();
  const localTimeStr = localDate.toLocaleTimeString();
  
  // Check if the user's timezone is Berlin
  const isBerlinTime = userTimezone === 'Europe/Berlin' || userTimezone.includes('Berlin');
  
  if (isBerlinTime) {
    conversionDetails.textContent = `Your timezone is Berlin time - no conversion needed`;
    conversionDetails.style.color = "#6c757d";
  } else {
    conversionDetails.innerHTML = `Converted from Berlin time to <strong>${userTimezone}</strong>: ${localDateStr} at ${localTimeStr}`;
    conversionDetails.style.color = "#0066cc";
  }
  
  conversionText.style.display = 'block';
}

function hideGetYourGuideConversion() {
  const conversionText = document.getElementById("getYourGuideConversionText");
  conversionText.style.display = 'none';
}

// Availability Audit Functions
function checkAvailabilityPageCompatibility() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.id) {
      updatePageStatus("No active tab found", false);
      return;
    }

    chrome.tabs.sendMessage(tab.id, { action: "getAvailabilityPageInfo" }, (response) => {
      console.log("[popup] Received response from content script:", response);
      
      if (chrome.runtime.lastError) {
        console.error("[popup] Chrome runtime error:", chrome.runtime.lastError);
        updatePageStatus("Unable to connect to page", false);
        return;
      }
      
      if (response && response.success) {
        const { pageType, canAudit } = response;
        
        if (canAudit) {
          updatePageStatus(`Compatible page - Ready for check`, true);
          
          // Set default date and time for all input modes
          const now = new Date();
          
          // Set GetYourGuide datetime input - user's current time in Berlin timezone
          const berlinTime = new Intl.DateTimeFormat('sv-SE', {
            timeZone: 'Europe/Berlin',
            year: 'numeric', month: '2-digit', day: '2-digit',
            hour: '2-digit', minute: '2-digit', second: '2-digit'
          }).format(now);
          document.getElementById("getYourGuideDateTime").value = berlinTime.replace(' ', 'T');
          
          // Set Viator datetime input - user's current time in UTC
          document.getElementById("viatorDateTime").value = now.toISOString();
          
          // Set manual date/time inputs (user's local time)
          document.getElementById("auditDate").value = now.toISOString().split('T')[0];
          
          // Format time as 12-hour format with AM/PM
          const hours = now.getHours();
          const minutes = now.getMinutes();
          const ampm = hours >= 12 ? 'PM' : 'AM';
          const displayHours = hours % 12 || 12;
          const displayMinutes = minutes.toString().padStart(2, '0');
          document.getElementById("auditTime").value = `${displayHours}:${displayMinutes} ${ampm}`;
        } else {
          updatePageStatus(`Page not compatible for auditing (${pageType}) - ${bookingsFound} bookings found`, false);
        }
      } else {
        updatePageStatus("Unable to analyze page for auditing", false);
      }
    });
  });
}

function updatePageStatus(message, isCompatible) {
  const pageStatus = document.getElementById("pageStatus");
  const runButton = document.getElementById("runAuditBtn");
  
  pageStatus.textContent = message;
  pageStatus.classList.remove("page-status-compatible", "page-status-incompatible");
  pageStatus.classList.add(isCompatible ? "page-status-compatible" : "page-status-incompatible");
  
  runButton.disabled = !isCompatible;
}

/** Update the Capacity Check status line on the main menu (green when compatible, muted otherwise). */
function updateMainMenuCapacityStatus(retryCount) {
  const el = document.getElementById("capacityCheckStatus");
  if (!el) return;

  const maxRetries = typeof retryCount === "number" ? retryCount : 1;
  let attempts = 0;

  function setStatus(text, statusClass) {
    if (!el) return;
    el.textContent = text;
    el.className = "menu-option-status " + (statusClass || "unsupported");
  }

  function runCheck() {
    attempts += 1;
    setStatus("Checking…", "checking");

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab || !tab.id) {
        setStatus("Open a FareHarbor availability page", "unsupported");
        return;
      }

      chrome.tabs.sendMessage(tab.id, { action: "getAvailabilityPageInfo" }, (response) => {
        if (chrome.runtime.lastError) {
          if (attempts <= maxRetries && tab.url && tab.url.includes("fareharbor")) {
            setTimeout(runCheck, 350);
            return;
          }
          setStatus("Open a FareHarbor availability page", "unsupported");
          return;
        }
        if (!response) {
          if (attempts <= maxRetries && tab.url && tab.url.includes("fareharbor")) {
            setTimeout(runCheck, 350);
            return;
          }
          setStatus("Open a FareHarbor availability page", "unsupported");
          return;
        }
        if (response.success && response.canAudit === true) {
          setStatus("Available on this page", "supported");
          return;
        }
        if (response.status === "error" && response.error && attempts <= maxRetries && tab.url && tab.url.includes("fareharbor")) {
          setTimeout(runCheck, 400);
          return;
        }
        setStatus("Open a FareHarbor availability page", "unsupported");
      });
    });
  }

  runCheck();
}

/** Update the Duplicate Customer Types status line on the main menu (green when page has customer types, muted otherwise). Reuses getCustomerTypes. */
function updateMainMenuDuplicateStatus(retryCount) {
  const el = document.getElementById("duplicatePageStatus");
  if (!el) return;

  const maxRetries = typeof retryCount === "number" ? retryCount : 1;
  let attempts = 0;

  function setStatus(text, statusClass) {
    if (!el) return;
    el.textContent = text;
    el.className = "menu-option-status " + (statusClass || "unsupported");
  }

  function runCheck() {
    attempts += 1;
    setStatus("Checking…", "checking");

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab || !tab.id) {
        setStatus("Open a FareHarbor item page", "unsupported");
        return;
      }

      chrome.tabs.sendMessage(tab.id, { action: "getCustomerTypes" }, (res) => {
        if (chrome.runtime.lastError) {
          if (attempts <= maxRetries && tab.url && tab.url.includes("fareharbor")) {
            setTimeout(runCheck, 350);
            return;
          }
          setStatus("Open a FareHarbor item page", "unsupported");
          return;
        }
        if (res && res.customerTypes && Array.isArray(res.customerTypes) && res.customerTypes.length > 0) {
          setStatus("Available on this page", "supported");
          return;
        }
        if ((!res || !res.customerTypes) && attempts <= maxRetries && tab.url && tab.url.includes("fareharbor")) {
          setTimeout(runCheck, 400);
          return;
        }
        setStatus("Open a FareHarbor item page", "unsupported");
      });
    });
  }

  runCheck();
}

// Availability Audit Handler
// Validation functions for text inputs
function validateDateFormat(dateStr) {
  // Accept YYYY-MM-DD format
  const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateRegex.test(dateStr)) {
    return { valid: false, error: "Date must be in YYYY-MM-DD format (e.g., 2025-08-22)" };
  }
  
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) {
    return { valid: false, error: "Invalid date" };
  }
  
  return { valid: true, date: dateStr };
}

function validateTimeFormat(timeStr) {
  // Accept HH:MM AM/PM or HH:MM format
  const timeRegex12 = /^(\d{1,2}):(\d{2})\s*(AM|PM)$/i;
  const timeRegex24 = /^(\d{1,2}):(\d{2})$/;
  
  let match = timeStr.match(timeRegex12);
  if (match) {
    const hours = parseInt(match[1]);
    const minutes = parseInt(match[2]);
    const ampm = match[3].toUpperCase();
    
    if (hours < 1 || hours > 12 || minutes < 0 || minutes > 59) {
      return { valid: false, error: "Invalid time format" };
    }
    
    // Convert to 24-hour format
    let hours24 = hours;
    if (ampm === 'PM' && hours !== 12) hours24 += 12;
    if (ampm === 'AM' && hours === 12) hours24 = 0;
    
    return { 
      valid: true, 
      time: `${hours24.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}` 
    };
  }
  
  match = timeStr.match(timeRegex24);
  if (match) {
    const hours = parseInt(match[1]);
    const minutes = parseInt(match[2]);
    
    if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
      return { valid: false, error: "Invalid time format" };
    }
    
    return { 
      valid: true, 
      time: `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}` 
    };
  }
  
  return { valid: false, error: "Time must be in HH:MM AM/PM format (e.g., 5:30 PM)" };
}

function validateISODateTimeFormat(isoStr) {
  // Accept YYYY-MM-DDTHH:MM:SS format (with optional seconds)
  const isoRegex = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/;
  
  const match = isoStr.match(isoRegex);
  if (!match) {
    return { valid: false, error: "DateTime must be in YYYY-MM-DDTHH:MM:SS format (e.g., 2025-08-24T09:51:51)" };
  }
  
  const [, year, month, day, hours, minutes, seconds] = match;
  const date = new Date(`${year}-${month}-${day}T${hours}:${minutes}:${seconds || '00'}`);
  
  if (isNaN(date.getTime())) {
    return { valid: false, error: "Invalid date/time values" };
  }
  
  return { 
    valid: true, 
    date: `${year}-${month}-${day}`,
    time: `${hours}:${minutes}`
  };
}

function validateViatorTimestampFormat(viatorStr) {
  try {
    // Parse the UTC timestamp
    let utcDate;
    
    // Handle different UTC timestamp formats
    if (viatorStr.includes('Z') || viatorStr.includes('+') || viatorStr.includes('-', 19)) {
      // Full ISO format with timezone (e.g., "2025-08-24T04:09:46.713Z")
      utcDate = new Date(viatorStr);
    } else if (viatorStr.includes('T')) {
      // Simple datetime format, assume UTC (e.g., "2025-08-24T04:09:46")
      utcDate = new Date(viatorStr + 'Z');
    } else {
      return { valid: false, error: "Viator timestamp must include 'T' separator (e.g., 2025-08-24T04:09:46.713Z)" };
    }
    
    if (isNaN(utcDate.getTime())) {
      return { valid: false, error: "Invalid Viator timestamp format" };
    }
    
    // Convert to local time for the audit
    const localDate = new Date(utcDate.getTime());
    
    // Format as date and time for the audit system
    const localDateStr = localDate.getFullYear() + '-' + 
                         String(localDate.getMonth() + 1).padStart(2, '0') + '-' + 
                         String(localDate.getDate()).padStart(2, '0');
    const localTimeStr = String(localDate.getHours()).padStart(2, '0') + ':' + 
                         String(localDate.getMinutes()).padStart(2, '0');
    
    return {
      valid: true,
      date: localDateStr,
      time: localTimeStr,
      utcTimestamp: viatorStr,
      localDate
    };
    
  } catch (error) {
    return { valid: false, error: "Invalid Viator timestamp format" };
  }
}

function validateGetYourGuideTimestampFormat(berlinStr) {
  try {
    // Handle different timestamp formats
    if (!berlinStr.includes('T')) {
      return { valid: false, error: "GetYourGuide timestamp must include 'T' separator (e.g., 2025-08-24T09:51:51)" };
    }
    
    // Parse the datetime components
    const parts = berlinStr.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?/);
    if (!parts) {
      return { valid: false, error: "GetYourGuide timestamp must be in YYYY-MM-DDTHH:MM:SS format (e.g., 2025-08-24T09:51:51)" };
    }
    
    const [, year, month, day, hours, minutes, seconds = '00'] = parts;
    
    // Validate the date values by creating a test date
    const testDate = new Date(parseInt(year), parseInt(month) - 1, parseInt(day), 
                             parseInt(hours), parseInt(minutes), parseInt(seconds));
    if (isNaN(testDate.getTime())) {
      return { valid: false, error: "Invalid date/time values in GetYourGuide timestamp" };
    }
    
    // Use the same conversion logic as the main function
    const userTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const inputDate = new Date(berlinStr);
    
    // Get timezone offsets
    const berlinFormatter = new Intl.DateTimeFormat('en', {
      timeZone: 'Europe/Berlin',
      timeZoneName: 'longOffset'
    });
    const berlinOffset = berlinFormatter.formatToParts(inputDate)
      .find(part => part.type === 'timeZoneName').value;
    
    const userFormatter = new Intl.DateTimeFormat('en', {
      timeZone: userTimezone,
      timeZoneName: 'longOffset'
    });
    const userOffset = userFormatter.formatToParts(inputDate)
      .find(part => part.type === 'timeZoneName').value;
    
    let resultDate = inputDate;
    
    // Only convert if offsets are different
    if (berlinOffset !== userOffset) {
      const berlinOffsetMinutes = parseOffset(berlinOffset);
      const userOffsetMinutes = parseOffset(userOffset);
      const offsetDiffMs = (berlinOffsetMinutes - userOffsetMinutes) * 60 * 1000;
      resultDate = new Date(inputDate.getTime() - offsetDiffMs);
    }
    
    // Format as date and time for the audit system
    const localDateStr = resultDate.getFullYear() + '-' + 
                         String(resultDate.getMonth() + 1).padStart(2, '0') + '-' + 
                         String(resultDate.getDate()).padStart(2, '0');
    const localTimeStr = String(resultDate.getHours()).padStart(2, '0') + ':' + 
                         String(resultDate.getMinutes()).padStart(2, '0');
    
    return {
      valid: true,
      date: localDateStr,
      time: localTimeStr,
      berlinTimestamp: berlinStr,
      localDate: resultDate
    };
    
  } catch (error) {
    return { valid: false, error: "Invalid GetYourGuide timestamp format" };
  }
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("runAuditBtn").addEventListener("click", async () => {
    const timestampMode = document.getElementById("timestampMode").value;
    const detailedInfoCheckbox = document.getElementById("fetchDetailedInfo");
    const fetchDetailedInfo = detailedInfoCheckbox.checked;
    
    console.log(`[popup] Audit button clicked - fetchDetailedInfo checkbox: ${fetchDetailedInfo}, timestampMode: ${timestampMode}`);
    
    let validatedDate, validatedTime;
    
    if (timestampMode === 'manual') {
      // Use separate date and time inputs
      const dateInput = document.getElementById("auditDate");
      const timeInput = document.getElementById("auditTime");
      
      const targetDate = dateInput.value.trim();
      const targetTime = timeInput.value.trim();
      
      // Validation
      if (!targetDate) {
        showStatus("Please enter a target date.", true);
        return;
      }
      
      if (!targetTime) {
        showStatus("Please enter a target time.", true);
        return;
      }
      
      // Validate date format
      const dateValidation = validateDateFormat(targetDate);
      if (!dateValidation.valid) {
        showStatus(`Invalid date: ${dateValidation.error}`, true);
        dateInput.focus();
        return;
      }
      
      // Validate time format
      const timeValidation = validateTimeFormat(targetTime);
      if (!timeValidation.valid) {
        showStatus(`Invalid time: ${timeValidation.error}`, true);
        timeInput.focus();
        return;
      }
      
      // Use validated date and converted time
      validatedDate = dateValidation.date;
      validatedTime = timeValidation.time;
      
    } else if (timestampMode === 'getyourguide') {
      // Use GetYourGuide datetime input (Berlin timezone conversion)
      const getYourGuideInput = document.getElementById("getYourGuideDateTime");
      const getYourGuideDateTime = getYourGuideInput.value.trim();
      
      if (!getYourGuideDateTime) {
        showStatus("Please enter a GetYourGuide timestamp.", true);
        return;
      }
      
      // Validate and convert GetYourGuide timestamp (Berlin time)
      const getYourGuideValidation = validateGetYourGuideTimestampFormat(getYourGuideDateTime);
      if (!getYourGuideValidation.valid) {
        showStatus(`Invalid GetYourGuide timestamp: ${getYourGuideValidation.error}`, true);
        getYourGuideInput.focus();
        return;
      }
      
      // Use the converted local date and time
      validatedDate = getYourGuideValidation.date;
      validatedTime = getYourGuideValidation.time;
      
      // Update the conversion display to show the conversion happened
      showGetYourGuideConversion(getYourGuideDateTime, getYourGuideValidation.localDate, Intl.DateTimeFormat().resolvedOptions().timeZone);
      
    } else if (timestampMode === 'viator') {
      // Use Viator datetime input (UTC conversion)
      const viatorInput = document.getElementById("viatorDateTime");
      const viatorDateTime = viatorInput.value.trim();
      
      if (!viatorDateTime) {
        showStatus("Please enter a Viator timestamp.", true);
        return;
      }
      
      // Validate and convert Viator timestamp
      const viatorValidation = validateViatorTimestampFormat(viatorDateTime);
      if (!viatorValidation.valid) {
        showStatus(`Invalid Viator timestamp: ${viatorValidation.error}`, true);
        viatorInput.focus();
        return;
      }
      
      // Use the converted local date and time
      validatedDate = viatorValidation.date;
      validatedTime = viatorValidation.time;
      
      // Update the conversion display to show the conversion happened
      showViatorConversion(viatorDateTime, viatorValidation.localDate, Intl.DateTimeFormat().resolvedOptions().timeZone);
    }
    
    console.log("Starting availability audit:", { validatedDate, validatedTime, fetchDetailedInfo });

    capacityCheckLastAuditForBatch = null;
    refreshCapacityBatchUI();
    
    // Show processing status
    const statusMessage = fetchDetailedInfo ? 
      "Running detailed audit (this may take longer)..." : 
      "Running availability audit...";
    showStatus(statusMessage);
    
    // Disable button during processing
    const btn = document.getElementById("runAuditBtn");
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = fetchDetailedInfo ? "Fetching details..." : "Auditing...";
    
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab || !tab.id) {
        showStatus("No active tab found", true);
        btn.disabled = false;
        btn.textContent = originalText;
        return;
      }
      
      console.log(`[popup] Sending message to content script: fetchDetailedInfo = ${fetchDetailedInfo}`);
      
      chrome.tabs.sendMessage(tab.id, {
        action: "runAvailabilityAudit",
        targetDate: validatedDate,
        targetTime: validatedTime,
        fetchDetailedInfo
      }, (response) => {
        btn.disabled = false;
        btn.textContent = originalText;
        
        if (chrome.runtime.lastError) {
          capacityCheckLastAuditForBatch = null;
          refreshCapacityBatchUI();
          showStatus("Error: " + chrome.runtime.lastError.message, true);
          return;
        }
        
        console.log("[popup] Audit response received:", response);
        
        if (response && response.success) {
          console.log("[popup] Audit successful, displaying results");
          displayAuditResults(response);
          capacityCheckLastAuditForBatch = sanitizeAuditResponseForBatch(response);
          refreshCapacityBatchUI();
          const successMessage = fetchDetailedInfo ? 
            "Detailed audit completed successfully!" : 
            "Audit completed successfully!";
          showStatus(successMessage);
        } else {
          console.error("[popup] Audit failed:", response);
          capacityCheckLastAuditForBatch = null;
          refreshCapacityBatchUI();
          showStatus("Error: " + (response?.error || "Unknown error occurred"), true);
          hideAuditResults();
        }
      });
    });
  });
  
  // Export bookings to TSV button
  const exportBtn = document.getElementById("exportBookingsToTSVBtn");
  if (exportBtn) {
    exportBtn.addEventListener('click', () => {
      const auditDataJson = exportBtn.dataset.auditData;
      if (auditDataJson) {
        try {
          const auditData = JSON.parse(auditDataJson);
          exportBookingsToTSV(auditData);
        } catch (error) {
          console.error("[popup] Failed to parse audit data:", error);
          showStatus("Error: Could not export bookings", true);
        }
      } else {
        showStatus("No booking data available to export", true);
      }
    });
  }
});

function generateResourcesUsedHTML(resourcesUsed) {
  if (!resourcesUsed || Object.keys(resourcesUsed).length === 0) {
    return '';
  }
  
  let resourcesHTML = `
    <div style="margin-top: 12px;">
      <div style="font-weight: bold; font-size: 12px; margin-bottom: 6px;">Resources Used:</div>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 12px;">
  `;
  
  for (const [resourceName, count] of Object.entries(resourcesUsed)) {
    resourcesHTML += `
        <div style="margin-left: 20px;"><strong>${resourceName}:</strong></div>
        <div>${count}</div>
    `;
  }
  
  resourcesHTML += `
      </div>
    </div>
  `;
  
  return resourcesHTML;
}

function generateCustomerTypesUsedHTML(customerTypesUsed) {
  if (!customerTypesUsed || Object.keys(customerTypesUsed).length === 0) {
    return '';
  }
  
  let customerTypesHTML = `
    <div style="margin-top: 12px;">
      <div style="font-weight: bold; font-size: 12px; margin-bottom: 6px;">Customer Types Used:</div>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 12px;">
  `;
  
  for (const [typeName, count] of Object.entries(customerTypesUsed)) {
    customerTypesHTML += `
        <div style="margin-left: 20px;"><strong>${typeName}:</strong></div>
        <div>${count}</div>
    `;
  }
  
  customerTypesHTML += `
      </div>
    </div>
  `;
  
  return customerTypesHTML;
}

function displayAuditResults(auditData) {
  console.log("[popup] Displaying audit results:", auditData);
  
  const resultsDiv = document.getElementById("auditResults");
  const summaryDiv = document.getElementById("auditSummary");
  const exportBtn = document.getElementById("exportBookingsToTSVBtn");
  
  // The response comes directly, not nested under .summary
  const detailedInfoText = auditData.detailedInfoFetched ? 
    '' : 
    'Basic capacity info (from page display)';
  
  // Extract target date and time from ISO string
  const targetDate = new Date(auditData.targetDateTime);
  const targetDateStr = targetDate.toLocaleDateString();
  const targetTimeStr = targetDate.toLocaleTimeString();
  
  const summaryHTML = `
    <div style="background: #f8f9fa; padding: 12px; border-radius: 4px; margin-bottom: 10px;">

      <span style="color: #495057;">At: ${targetDateStr} at ${targetTimeStr}</span><br>
      <span style="color: #6c757d; font-size: 11px;">${detailedInfoText}</span>
    </div>
    
    <details style="margin-bottom: 10px;">
      <summary style="cursor: pointer; font-size: 12px; color: #6c757d; margin-bottom: 8px;">Bookings scanned (all statuses)</summary>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 12px; margin-left: 16px;">
        <div><strong>Total Scanned:</strong></div>
        <div>${auditData.originalBookingsCount}</div>
      </div>
    </details>
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 12px;">
      <div><strong>Active Bookings:</strong></div>
      <div>${auditData.filteredBookingsCount}</div>
      
      <div><strong>Total Customer Types:</strong></div>
      <div style="font-weight: bold; color: #0066cc;">${auditData.totalCapacityUsed}</div>
    </div>
    
    ${generateResourcesUsedHTML(auditData.resourcesUsed)}
    
    ${generateCustomerTypesUsedHTML(auditData.customerTypesUsed)}
    
    <div style="margin-top: 8px; font-size: 11px; color: #6c757d;">
      Note: Includes cancelled bookings that were cancelled after target time
    </div>
    
    <div style="margin-top: 12px; font-size: 11px; color: #6c757d;">
      Audited at: ${new Date().toLocaleString()}
    </div>
  `;
  
  summaryDiv.innerHTML = summaryHTML;
  resultsDiv.style.display = 'block';
  
  // Show export button if we have filtered bookings
  if (auditData.filteredBookings && auditData.filteredBookings.length > 0) {
    exportBtn.style.display = 'block';
    // Store audit data for export
    exportBtn.dataset.auditData = JSON.stringify(auditData);
  } else {
    exportBtn.style.display = 'none';
  }
}

function hideAuditResults() {
  const resultsDiv = document.getElementById("auditResults");
  resultsDiv.style.display = 'none';
}

// Function to format customer types as a readable string
function formatCustomerTypes(customerTypes) {
  if (!customerTypes || !Array.isArray(customerTypes) || customerTypes.length === 0) {
    return '';
  }
  
  return customerTypes
    .map(ct => `${ct.quantity} ${ct.name}`)
    .join(', ');
}

// Function to format datetime for display (military time for TSV export)
function formatDateTime(datetime) {
  if (!datetime) return '';
  
  const date = datetime instanceof Date ? datetime : new Date(datetime);
  if (isNaN(date.getTime())) return '';
  
  // Format as: MM/DD/YYYY HH:MM (24-hour format, military time)
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const day = date.getDate().toString().padStart(2, '0');
  const year = date.getFullYear();
  
  // Use getHours() which returns 0-23 (24-hour format)
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  
  // Return in 24-hour format without AM/PM
  return `${month}/${day}/${year} ${hours}:${minutes}`;
}

// Function to normalize customer type names (same logic as in availability-audit.js)
function normalizeCustomerTypeName(typeName) {
  const name = typeName.trim();
  const lowerName = name.toLowerCase();
  
  // Special cases for irregular plurals
  const irregularPlurals = {
    'child': 'Children',
    'children': 'Children',
    'kid': 'Children',
    'kids': 'Children',
    'baby': 'Babies',
    'babies': 'Babies',
    'infant': 'Infants',
    'infants': 'Infants',
    'youth': 'Youth',
    'youths': 'Youth'
  };
  
  // Check for irregular plurals first
  if (irregularPlurals[lowerName]) {
    return irregularPlurals[lowerName];
  }
  
  // Generic singular/plural handling
  // If it ends with 's', assume it's already plural
  if (lowerName.endsWith('s')) {
    // Capitalize first letter and keep the rest as-is
    return name.charAt(0).toUpperCase() + name.slice(1);
  } else {
    // If it doesn't end with 's', make it plural by adding 's'
    return name.charAt(0).toUpperCase() + name.slice(1) + 's';
  }
}

// Function to export bookings to TSV format (shared logic in capacity-batch.js)
function exportBookingsToTSV(auditData) {
  if (typeof CapacityBatch === 'undefined') {
    showStatus('Export not available.', true);
    return;
  }
  const tsvContent = CapacityBatch.buildCapacityCheckTsvFromAudit(
    auditData,
    { normalizeCustomerTypeName, formatDateTime }
  );
  if (!tsvContent) {
    showStatus('No bookings to export', true);
    return;
  }
  const totalCount =
    (auditData.filteredBookings || []).length +
    (auditData.skippedBookings || []).length;
  navigator.clipboard
    .writeText(tsvContent)
    .then(() => {
      showStatus(`Successfully copied ${totalCount} bookings to clipboard!`);
      console.log('[popup] TSV exported:', tsvContent.substring(0, 200) + '...');
    })
    .catch((err) => {
      console.error('Clipboard copy failed:', err);
      showStatus('Failed to copy bookings to clipboard', true);
    });
}
