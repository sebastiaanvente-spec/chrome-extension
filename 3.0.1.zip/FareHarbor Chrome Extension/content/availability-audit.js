// Availability Audit functionality for FareHarbor Chrome Extension
(function() {
  'use strict';

  // Wait for FareHarborUtils to be available
  function waitForUtils() {
    if (typeof window.FareHarborUtils !== 'undefined') {
      initializeAvailabilityAudit();
    } else {
      setTimeout(waitForUtils, 100);
    }
  }

  function initializeAvailabilityAudit() {
    console.log('[availability-audit] Initializing availability audit module');

    const AUDIT_SELECTORS = {
      BOOKING_ELEMENT: 'a[data-test-id="active-booking"], a[data-test-id="cancelled-booking"]',
      ACTIVE_BOOKING: 'a[data-test-id="active-booking"]',
      CANCELLED_BOOKING: 'a[data-test-id="cancelled-booking"]',
      BOOKING_NUMBER: '.fh-grey-new',
      PARTY_SIZE_CONTAINER: '.text-medium',
      BOOKING_DATE_CONTAINER: '.booked-at',
      CANCELLED_DATE_CONTAINER: '.booked-at',
      EXPAND_ACTIVE: 'td[ng-toggle="showActive"]',
      EXPAND_CANCELLED: 'td[ng-toggle="showCancelled"]'
    };

    // Updated patterns for better parsing - with Unicode support for diacritics
    const PARTY_SIZE_PATTERN = /(\d+)(?:\s|&nbsp;)+[\p{L}\p{M}]+/giu;
    const CUSTOMER_TYPE_PATTERN = /(\d+)(?:\s|&nbsp;)+([\p{L}\p{M}]+(?:\s+[\p{L}\p{M}]+)*)/giu;
    const DATE_PATTERN = /(?:(\d{1,2}\/\d{1,2}\/\d{2,4})|(Today)|(Yesterday))\s*at\s*(\d{1,2}:\d{2}(?:\s*[APap][Mm])?)/im;
    const CANCELLED_DATE_PATTERN = /Last modified:\s*(?:(\d{1,2}\/\d{1,2}\/\d{2,4})|(Today)|(Yesterday))\s*at\s*(\d{1,2}:\d{2}(?:\s*[APap][Mm])?)/i;
    const RESOURCES_INCLUDING_PATTERN = /(?:including|with)\s+([^•]+?)(?:\s*•|$)/gi;
    const RESOURCES_EXCLUDING_PATTERN = /(?:excluding|without)\s+([^•]+?)(?:\s*•|$)/gi;

    // Helper function to extract numbers from text
    function extractNumber(text) {
      if (!text) return 0;
      const match = text.match(/\d+/);
      return match ? parseInt(match[0], 10) : 0;
    }

    // Enhanced date parsing function
    function parseDateTime(dateStr, timeStr) {
      try {
        if (!dateStr || !timeStr) {
          console.warn(`[parseDateTime] Missing date or time: dateStr="${dateStr}", timeStr="${timeStr}"`);
          return null;
        }

        let finalDateStr = dateStr;

        // Handle "Today" and "Yesterday"
        const today = new Date();
        if (dateStr === 'Today') {
          const month = (today.getMonth() + 1).toString().padStart(2, '0');
          const day = today.getDate().toString().padStart(2, '0');
          const year = today.getFullYear().toString().slice(-2);
          finalDateStr = `${month}/${day}/${year}`;
        } else if (dateStr === 'Yesterday') {
          const yesterday = new Date(today);
          yesterday.setDate(yesterday.getDate() - 1);
          const month = (yesterday.getMonth() + 1).toString().padStart(2, '0');
          const day = yesterday.getDate().toString().padStart(2, '0');
          const year = yesterday.getFullYear().toString().slice(-2);
          finalDateStr = `${month}/${day}/${year}`;
        }

        let finalTimeStr = timeStr;

        // Handle 24-hour time format (no AM/PM)
        if (!/[APap][Mm]/.test(timeStr)) {
          const [hours, minutes] = timeStr.split(':').map(Number);
          if (hours === 0) {
            finalTimeStr = `12:${minutes.toString().padStart(2, '0')} AM`;
          } else if (hours < 12) {
            finalTimeStr = `${hours}:${minutes.toString().padStart(2, '0')} AM`;
          } else if (hours === 12) {
            finalTimeStr = `12:${minutes.toString().padStart(2, '0')} PM`;
          } else {
            finalTimeStr = `${hours - 12}:${minutes.toString().padStart(2, '0')} PM`;
          }
        }

        // Ensure 4-digit year
        if (finalDateStr.includes('/')) {
          const parts = finalDateStr.split('/');
          if (parts.length === 3 && parts[2].length === 2) {
            parts[2] = `20${parts[2]}`;
            finalDateStr = parts.join('/');
          }
        }

        // Parse the date components for more reliable date construction
        const dateParts = finalDateStr.split('/');
        if (dateParts.length !== 3) {
          console.warn(`[parseDateTime] Invalid date format: "${finalDateStr}"`);
          return null;
        }
        
        const month = parseInt(dateParts[0], 10);
        const day = parseInt(dateParts[1], 10);
        const year = parseInt(dateParts[2], 10);
        
        // Parse time components
        const timeRegex = /^(\d{1,2}):(\d{2})\s*(AM|PM)$/i;
        const timeMatch = finalTimeStr.match(timeRegex);
        if (!timeMatch) {
          console.warn(`[parseDateTime] Invalid time format: "${finalTimeStr}"`);
          return null;
        }
        
        let hours = parseInt(timeMatch[1], 10);
        const minutes = parseInt(timeMatch[2], 10);
        const ampm = timeMatch[3].toUpperCase();
        
        // Convert to 24-hour format
        if (ampm === 'PM' && hours !== 12) {
          hours += 12;
        } else if (ampm === 'AM' && hours === 12) {
          hours = 0;
        }
        
        // Create date using Date constructor with individual components (month is 0-based)
        const date = new Date(year, month - 1, day, hours, minutes, 0, 0);
        
        return isNaN(date.getTime()) ? null : date;
      } catch (error) {
        console.warn(`[parseDateTime] Failed to parse date/time: dateStr="${dateStr}", timeStr="${timeStr}", error:`, error);
        return null;
      }
    }

    // Function to detect if the current page is compatible for auditing
    function detectPageType() {
      const url = window.location.href;
      const bookingElements = document.querySelectorAll(AUDIT_SELECTORS.BOOKING_ELEMENT);
      
      console.log(`[availability-audit] Detected ${bookingElements.length} booking elements on page`);
      
      if (bookingElements.length > 0) {
        return 'booking-grid';
      }
      
      return 'unknown';
    }

    /**
     * Item id + optional calendar date from pathname for batch dedupe; title for display.
     */
    function getAvailabilityPageContext() {
      const pathname = window.location.pathname || '';
      let availabilityId = '';
      const itemMatch = pathname.match(/\/items\/(\d+)/);
      const itemId = itemMatch ? itemMatch[1] : null;
      const calMatch = pathname.match(/\/calendar\/(\d{4})\/(\d{1,2})(?:\/(\d{1,2}))?/);
      if (itemId && calMatch) {
        const y = calMatch[1];
        const m = String(calMatch[2]).padStart(2, '0');
        const d = calMatch[3] ? String(calMatch[3]).padStart(2, '0') : '';
        availabilityId = d ? `${itemId}-${y}-${m}-${d}` : `${itemId}-${y}-${m}`;
      } else if (itemId) {
        availabilityId = itemId;
      } else {
        const trimmed = pathname.replace(/^\/+|\/+$/g, '').replace(/\//g, '_');
        availabilityId = trimmed || 'unknown';
      }

      let availabilityName = (document.title || '').trim();
      availabilityName = availabilityName.replace(/\s*\|\s*FareHarbor.*$/i, '').trim();
      if (
        !availabilityName ||
        availabilityName.startsWith('/') ||
        availabilityName.length < 2
      ) {
        if (itemId) {
          const cm = pathname.match(
            /\/calendar\/(\d{4})\/(\d{1,2})(?:\/(\d{1,2}))?/
          );
          if (cm) {
            const y = cm[1];
            const mo = String(cm[2]).padStart(2, '0');
            const day = cm[3] ? `-${String(cm[3]).padStart(2, '0')}` : '';
            availabilityName = `Item ${itemId} (${y}-${mo}${day})`;
          } else {
            availabilityName = `Item ${itemId}`;
          }
        } else {
          availabilityName = pathname || 'Availability';
        }
      }

      return { availabilityId, availabilityName };
    }

    // Function to ensure booking sections are expanded
    async function ensureBookingSectionsExpanded() {
      console.log('[availability-audit] Checking if booking sections need to be expanded...');
      
      const activeExpandButton = document.querySelector(AUDIT_SELECTORS.EXPAND_ACTIVE);
      const cancelledExpandButton = document.querySelector(AUDIT_SELECTORS.EXPAND_CANCELLED);
      
      let expansionsNeeded = 0;
      
      // Check and expand active bookings section
      if (activeExpandButton && activeExpandButton.getAttribute('aria-expanded') === 'false') {
        console.log('[availability-audit] Expanding active bookings section...');
        activeExpandButton.click();
        expansionsNeeded++;
      }
      
      // Check and expand cancelled bookings section
      if (cancelledExpandButton && cancelledExpandButton.getAttribute('aria-expanded') === 'false') {
        console.log('[availability-audit] Expanding cancelled bookings section...');
        cancelledExpandButton.click();
        expansionsNeeded++;
      }
      
      if (expansionsNeeded > 0) {
        console.log(`[availability-audit] Expanded ${expansionsNeeded} sections, waiting for DOM update...`);
        // Wait for DOM to update after expansions
        await new Promise(resolve => setTimeout(resolve, 1000));
      } else {
        console.log('[availability-audit] All sections already expanded');
      }
    }

    // Function to scrape availability data from the page
    async function scrapeAvailabilityData() {
      console.log('[availability-audit] Starting to scrape availability data...');
      
      // First ensure all sections are expanded
      await ensureBookingSectionsExpanded();
      
      const bookingElements = document.querySelectorAll(AUDIT_SELECTORS.BOOKING_ELEMENT);
      console.log(`[availability-audit] Found ${bookingElements.length} total booking elements`);
      
      const bookings = [];

      bookingElements.forEach((element, index) => {
        try {
          const booking = extractBookingData(element, index);
          if (booking) {
            bookings.push(booking);
          }
        } catch (error) {
          console.warn(`[availability-audit] Failed to extract booking ${index}:`, error);
        }
      });
      
      console.log(`[availability-audit] Successfully scraped ${bookings.length} bookings`);
      
      return {
        bookings,
        totalBookings: bookings.length,
        scrapedAt: new Date().toISOString()
      };
    }

    // Function to extract booking data from a single booking element
    function extractBookingData(element, index) {
      console.log(`[availability-audit] Extracting booking ${index + 1}...`);
      
      const isCancelled = element.getAttribute('data-test-id') === 'cancelled-booking';
      
      // Extract booking number
      const bookingNumberElement = element.querySelector(AUDIT_SELECTORS.BOOKING_NUMBER);
      const bookingNumber = bookingNumberElement ? bookingNumberElement.textContent.trim().replace('#', '') : null;
      
      // Extract party size and customer types by looking for all numeric patterns
      const partySizeElement = element.querySelector(AUDIT_SELECTORS.PARTY_SIZE_CONTAINER);
      let partySize = 0;
      const customerTypes = [];
      
      if (partySizeElement) {
        const partySizeText = partySizeElement.textContent;
        console.log(`[availability-audit] Party size text: "${partySizeText}"`);
        
        // Use matchAll to find all customer type components (quantity + type name)
        const customerTypeMatches = [...partySizeText.matchAll(CUSTOMER_TYPE_PATTERN)];
        console.log(`[availability-audit] Found ${customerTypeMatches.length} customer type matches:`, customerTypeMatches.map(m => `${m[1]} ${m[2]}`));
        
        // Extract customer types and calculate total party size
        customerTypeMatches.forEach(match => {
          const quantity = parseInt(match[1], 10);
          const typeName = match[2].trim();
          
          customerTypes.push({
            name: typeName,
            quantity: quantity
          });
          
          partySize += quantity;
        });
        
        console.log(`[availability-audit] Extracted customer types:`, customerTypes);
        console.log(`[availability-audit] Calculated total party size: ${partySize}`);
      }
      
      // Extract booking href for detailed information
      const bookingHref = element.getAttribute('href');
      console.log(`[availability-audit] Booking href: ${bookingHref}`);
      
      // Extract resources from the main listing
      const resources = {
        included: [],
        excluded: []
      };
      
      const elementText = element.textContent;
      
             // Look for "including" or "with" resources
       const includingMatches = [...elementText.matchAll(RESOURCES_INCLUDING_PATTERN)];
       includingMatches.forEach(match => {
         const resourceText = match[1].trim();
         if (resourceText) {
           // Split multiple resources if they are separated by & or ,
           const individualResources = resourceText.split(/\s*[&,]\s*/).map(r => r.trim()).filter(r => r);
           resources.included.push(...individualResources);
           console.log(`[availability-audit] Found included resources: ${individualResources.join(', ')}`);
         }
       });
       
       // Look for "excluding" or "without" resources  
       const excludingMatches = [...elementText.matchAll(RESOURCES_EXCLUDING_PATTERN)];
       excludingMatches.forEach(match => {
         const resourceText = match[1].trim();
         if (resourceText) {
           // Split multiple resources if they are separated by & or ,
           const individualResources = resourceText.split(/\s*[&,]\s*/).map(r => r.trim()).filter(r => r);
           resources.excluded.push(...individualResources);
           console.log(`[availability-audit] Found excluded resources: ${individualResources.join(', ')}`);
         }
       });
       
       // Debug: Log the full element text to see what's available
       console.log(`[availability-audit] Booking ${index + 1} full text:`, elementText.substring(0, 500));
       
       // Try to extract more resource information from the main page
       // Look for patterns that might indicate resources in different formats
       const resourcePatterns = [
         /with\s+([^•\n]+)/gi,
         /including\s+([^•\n]+)/gi,
         /excluding\s+([^•\n]+)/gi,
         /without\s+([^•\n]+)/gi,
         /featuring\s+([^•\n]+)/gi,
         /•\s*([A-Z][a-zA-Z\s]+)/g  // Items after bullet points
       ];
       
       resourcePatterns.forEach((pattern, index) => {
         const matches = [...elementText.matchAll(pattern)];
         matches.forEach(match => {
           const resourceText = match[1].trim();
           if (resourceText && resourceText.length > 2 && resourceText.length < 100) {
             console.log(`[availability-audit] Pattern ${index} found potential resource: "${resourceText}"`);
             // Don't add duplicates
             if (!resources.included.includes(resourceText) && !resources.excluded.includes(resourceText)) {
               if (pattern.source.includes('excluding') || pattern.source.includes('without')) {
                 resources.excluded.push(resourceText);
               } else {
                 resources.included.push(resourceText);
               }
             }
           }
         });
       });
      
      // Extract date and time information
      const dateElement = element.querySelector(isCancelled ? AUDIT_SELECTORS.CANCELLED_DATE_CONTAINER : AUDIT_SELECTORS.BOOKING_DATE_CONTAINER);
      let bookingDate = null;
      let bookingTime = null;
      let cancelledDate = null;
      let cancelledTime = null;
      let datetime = null;
      
      if (dateElement) {
        const dateText = dateElement.textContent.trim();
        console.log(`[availability-audit] Date text: "${dateText}"`);
        
        if (isCancelled) {
          const cancelledMatch = dateText.match(CANCELLED_DATE_PATTERN);
          if (cancelledMatch) {
            cancelledDate = cancelledMatch[1] || cancelledMatch[2] || cancelledMatch[3];
            cancelledTime = cancelledMatch[4];
            
            // Convert relative dates to absolute dates
            if (cancelledDate === 'Today') {
              const today = new Date();
              cancelledDate = `${today.getMonth() + 1}/${today.getDate()}/${today.getFullYear().toString().slice(-2)}`;
            } else if (cancelledDate === 'Yesterday') {
              const yesterday = new Date();
              yesterday.setDate(yesterday.getDate() - 1);
              cancelledDate = `${yesterday.getMonth() + 1}/${yesterday.getDate()}/${yesterday.getFullYear().toString().slice(-2)}`;
            }
            
            datetime = parseDateTime(cancelledDate, cancelledTime);
            console.log(`[availability-audit] Parsed cancelled datetime: ${datetime ? datetime.toISOString() : 'null'}`);
          }
        } else {
          const bookingMatch = dateText.match(DATE_PATTERN);
          if (bookingMatch) {
            bookingDate = bookingMatch[1] || bookingMatch[2] || bookingMatch[3];
            bookingTime = bookingMatch[4];
            
            // Convert relative dates to absolute dates
            if (bookingDate === 'Today') {
              const today = new Date();
              bookingDate = `${today.getMonth() + 1}/${today.getDate()}/${today.getFullYear().toString().slice(-2)}`;
            } else if (bookingDate === 'Yesterday') {
              const yesterday = new Date();
              yesterday.setDate(yesterday.getDate() - 1);
              bookingDate = `${yesterday.getMonth() + 1}/${yesterday.getDate()}/${yesterday.getFullYear().toString().slice(-2)}`;
            }
            
            datetime = parseDateTime(bookingDate, bookingTime);
            console.log(`[availability-audit] Parsed booking datetime: ${datetime ? datetime.toISOString() : 'null'}`);
          }
        }
      }
      
      const booking = {
        index: index + 1,
        bookingNumber,
        partySize,
        customerTypes,
        isCancelled,
        bookingDate,
        bookingTime,
        cancelledDate,
        cancelledTime,
        datetime,
        resources,
        bookingHref,
        hasHref: !!bookingHref,
        element: element.outerHTML.substring(0, 500) // First 500 chars for debugging
      };

      // Tag the element with a stable unique id for in-page Angular extraction
      try {
        const uniqueId = `fh-ext-booking-${Date.now()}-${Math.random().toString(36).slice(2)}`;
        element.setAttribute('data-fh-ext-id', uniqueId);
        booking.elementRefId = uniqueId;
      } catch (e) {
        console.warn('[availability-audit] Failed to set elementRefId:', e);
      }
      
      console.log(`[availability-audit] Extracted booking ${index + 1}:`, {
        bookingNumber: booking.bookingNumber,
        partySize: booking.partySize,
        isCancelled: booking.isCancelled,
        datetime: booking.datetime ? booking.datetime.toISOString() : null,
        hasHref: !!booking.bookingHref
      });

      if (booking.bookingHref) {
        console.log(`[availability-audit] Booking ${index} has href: ${booking.bookingHref}`);
      } else {
        console.log(`[availability-audit] Booking ${index} missing href! Element:`, element);
      }
      
      return booking;
    }

    // Attempt to extract resources from Angular scope on the live page for a given booking element
    async function tryExtractResourcesFromAngular(elementRefId) {
      return new Promise((resolve) => {
        try {
          if (!elementRefId) {
            resolve(null);
            return;
          }

          const responseEventName = 'fh-ext-angular-response';

          const onResponse = (evt) => {
            try {
              if (!evt || !evt.detail) return;
              if (evt.detail.id !== elementRefId) return;
              document.removeEventListener(responseEventName, onResponse, true);

              const payload = evt.detail.payload;
              if (!payload) {
                resolve(null);
                return;
              }

              // Attempt to parse and normalize resources from payload
              let resources = { included: [], excluded: [], detailed: [] };
              try {
                // payload is expected to be a JSON string or object
                const data = typeof payload === 'string' ? JSON.parse(payload) : payload;

                // Generic deep scan for resource-like structures
                const stack = [data];
                const seen = new Set();
                while (stack.length) {
                  const node = stack.pop();
                  if (!node || typeof node !== 'object' || seen.has(node)) continue;
                  seen.add(node);
                  // Heuristics for resource entries
                  if (node && (node.resource || node.resourceName || node.name)) {
                    const name = (node.resourceName || node.name || node.resource || '').toString();
                    const qty = extractNumber(node.quantity || node.qty || node.count || node.amount || '');
                    if (name && name.length < 128) {
                      resources.detailed.push({ name, quantity: qty || null });
                    }
                  }
                  // Arrays or nested objects
                  if (Array.isArray(node)) {
                    for (const item of node) stack.push(item);
                  } else {
                    for (const key of Object.keys(node)) {
                      const val = node[key];
                      // Likely resource containers
                      if (key.toLowerCase().includes('resource')) {
                        stack.push(val);
                      } else if (typeof val === 'object') {
                        stack.push(val);
                      }
                    }
                  }
                }

                resolve({ actualCapacity: null, bookingDetails: null, customerInfo: null, resources });
              } catch (e) {
                console.log('[availability-audit] Angular payload parse error:', e.message);
                resolve(null);
              }
            } catch (e) {
              console.log('[availability-audit] Angular response handler error:', e.message);
              resolve(null);
            }
          };

          document.addEventListener(responseEventName, onResponse, true);

          // Ask background service worker to execute in MAIN world (bypasses CSP for inline scripts)
          try {
            chrome.runtime.sendMessage({
              type: 'FH_INJECT_ANGULAR_EXTRACTOR',
              elementRefId
            }, () => {
              // no-op; we listen for the DOM event response
            });
          } catch (e) {
            console.log('[availability-audit] Failed to request MAIN world execution:', e.message);
          }

          // Safety timeout
          setTimeout(() => {
            try { document.removeEventListener(responseEventName, onResponse, true); } catch(_) {}
            resolve(null);
          }, 4000);
        } catch (error) {
          console.log('[availability-audit] Failed Angular extraction setup:', error.message);
          resolve(null);
        }
      });
    }

    // Attempt to open the inline overlay invisibly, scrape resource info, then close it
    async function tryExtractResourcesViaOverlay(elementRefId) {
      try {
        if (!elementRefId) return null;
        const el = document.querySelector(`[data-fh-ext-id="${elementRefId}"]`);
        if (!el) return null;

        // Add CSS to hide overlay UI if it appears
        let hideStyle = document.getElementById('fh-ext-hide-overlay-style');
        if (!hideStyle) {
          hideStyle = document.createElement('style');
          hideStyle.id = 'fh-ext-hide-overlay-style';
          hideStyle.textContent = `
            [class*="overlay"], [id*="overlay"], .modal, .dialog, [role="dialog"], .ngdialog, .ng-modal {
              display: none !important; visibility: hidden !important; opacity: 0 !important;
            }
            body.body-print-overlay { overflow: hidden !important; }
          `;
          document.documentElement.appendChild(hideStyle);
        }

        const prevScroll = { x: window.scrollX, y: window.scrollY };

        // Trigger overlay opening by clicking the booking element
        el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

        // Wait for overlay DOM to load; poll for likely overlay content
        const start = Date.now();
        let overlayLoaded = false;
        while (Date.now() - start < 4000) {
          // Look for resource indicators that appear only in overlay content
          const indicators = document.querySelectorAll('[data-test-id*="resource-usage-indicator"]');
          if (indicators && indicators.length > 0) {
            overlayLoaded = true;
            break;
          }
          await new Promise(r => setTimeout(r, 150));
        }

        // Attempt to scrape from overlay DOM
        let resources = { included: [], excluded: [], detailed: [] };
        if (overlayLoaded) {
          const indicators = document.querySelectorAll('[data-test-id*="resource-usage-indicator"]');
          indicators.forEach((indicator) => {
            const tables = indicator.querySelectorAll('.invoice-table');
            tables.forEach((table) => {
              const greySpans = table.querySelectorAll('.fh-grey-new');
              greySpans.forEach((span) => {
                const t = span.textContent.trim();
                if (t.endsWith(':')) {
                  const name = t.slice(0, -1).trim();
                  // Find a nearby quantity
                  let quantity = null;
                  let n = span.nextSibling;
                  while (n) {
                    const txt = (n.textContent || '').trim();
                    const num = parseInt(txt, 10);
                    if (!isNaN(num) && num > 0) { quantity = num; break; }
                    n = n.nextSibling;
                  }
                  if (quantity === null) {
                    const cell = span.closest('td');
                    if (cell) {
                      const txt = cell.textContent.trim();
                      const m = txt.match(new RegExp(name + ':\\s*(\\d+)', 'i')) || txt.match(/\b(\d+)\b/);
                      if (m) quantity = parseInt(m[m.length - 1], 10);
                    }
                  }
                  resources.detailed.push({ name, quantity: quantity || null });
                }
              });
            });
          });
        }

        // Try to close overlay (ESC key and common close buttons), then cleanup
        try {
          document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
          const closeBtn = document.querySelector('[data-test-id*="close"], .close, .btn-close, [aria-label="Close"]');
          if (closeBtn) closeBtn.dispatchEvent(new MouseEvent('click', { bubbles: true }));
        } catch (_) {}

        window.scrollTo(prevScroll.x, prevScroll.y);
        // Keep hideStyle to avoid flicker until after extraction; then remove
        try { hideStyle && hideStyle.remove(); } catch(_) {}

        if (resources.detailed.length > 0) {
          return { actualCapacity: null, bookingDetails: null, customerInfo: null, resources };
        }
        return null;
      } catch (error) {
        console.log('[availability-audit] Overlay extraction error:', error.message);
        return null;
      }
    }

    // Function to filter bookings based on target date and time
    function filterBookingsUpToDateTime(bookings, targetDate, targetTime) {
      console.log(`[availability-audit] Filtering bookings up to ${targetDate} ${targetTime}`);
      
      // Parse the target date/time properly
      // targetDate format: "YYYY-MM-DD"
      // targetTime format: "HH:MM" (24-hour)
      const targetDateTime = new Date(`${targetDate}T${targetTime}:00`);
      
      if (isNaN(targetDateTime.getTime())) {
        console.error(`[availability-audit] Invalid target date/time: ${targetDate} ${targetTime}`);
        console.error(`[availability-audit] Attempted to parse: ${targetDate}T${targetTime}:00`);
        return {
          filteredBookings: [],
          skippedBookings: [],
          targetDateTime: null
        };
      }
      
      console.log(`[availability-audit] Target datetime: ${targetDateTime.toISOString()}`);
      console.log(`[availability-audit] Target datetime local: ${targetDateTime.toString()}`);
      
      const filteredBookings = [];
      const skippedBookings = [];
      
      if (!bookings || !Array.isArray(bookings)) {
        console.error('[availability-audit] No valid bookings array provided');
        return {
          filteredBookings: [],
          skippedBookings: [],
          targetDateTime
        };
      }
      
      bookings.forEach((booking, index) => {
        if (!booking.datetime) {
          console.log(`[availability-audit] Booking ${index + 1} has no datetime, excluding from filter`);
          skippedBookings.push(booking);
          return;
        }
        
        console.log(`[availability-audit] Checking booking ${index + 1}:`, {
          bookingNumber: booking.bookingNumber,
          isCancelled: booking.isCancelled,
          datetime: booking.datetime.toISOString(),
          targetDateTime: targetDateTime.toISOString(),
          hasHref: booking.hasHref,
          bookingHref: booking.bookingHref
        });
        
        if (booking.isCancelled) {
          // For cancelled bookings, check both cancelled_at and booked_at dates
          if (booking.datetime > targetDateTime) {
            // Cancelled after timestamp - check if booked_at is available
            if (booking.bookedAt) {
              const bookedAtDate = booking.bookedAt instanceof Date ? booking.bookedAt : new Date(booking.bookedAt);
              if (!isNaN(bookedAtDate.getTime())) {
                if (bookedAtDate > targetDateTime) {
                  // Booked after timestamp - this booking was created after the timestamp, exclude from filtered
                  console.log(`[availability-audit] ✗ Excluding cancelled booking ${index + 1} - cancelled after target time, but booked after timestamp`);
                  skippedBookings.push({...booking, reason: 'cancelled_created_after_target'});
                  return;
                } else {
                  // Booked before/at timestamp - this booking was active at the timestamp, include in filtered
                  console.log(`[availability-audit] ✓ Including cancelled booking ${index + 1} - cancelled after target time, was active at timestamp`);
                  filteredBookings.push({...booking, reason: 'cancelled_was_active_at_target'});
                  return;
                }
              }
            }
            // bookedAt not available yet - include temporarily (will be re-evaluated after bookedAt is fetched)
            console.log(`[availability-audit] ✓ Including cancelled booking ${index + 1} - cancelled after target time (bookedAt not yet available, will re-evaluate)`);
            filteredBookings.push({...booking, reason: 'cancelled_after_target'});
          } else {
            console.log(`[availability-audit] ✗ Excluding cancelled booking ${index + 1} - cancelled before target time`);
            skippedBookings.push(booking);
          }
        } else {
          // For active bookings, include them if they were created BEFORE or AT the target time
          if (booking.datetime <= targetDateTime) {
            console.log(`[availability-audit] ✓ Including active booking ${index + 1} - created before/at target time`);
            filteredBookings.push({...booking, reason: 'active_before_target'});
          } else {
            console.log(`[availability-audit] ✗ Excluding active booking ${index + 1} - created after target time`);
            skippedBookings.push(booking);
          }
        }
      });
      
      return {
        filteredBookings,
        skippedBookings,
        targetDateTime
      };
    }

    // Function to calculate total capacity used
    function calculateCapacityUsed(filteredBookings) {
      if (!filteredBookings || !Array.isArray(filteredBookings)) {
        return 0;
      }
      
      return filteredBookings.reduce((total, booking) => total + (booking.partySize || 0), 0);
    }

    // Function to aggregate resource usage across all bookings
    function aggregateResourceUsage(filteredBookings) {
      const resourceCounts = {};
      
      if (!filteredBookings || !Array.isArray(filteredBookings)) {
        return resourceCounts;
      }
      
      filteredBookings.forEach((booking) => {
        if (booking.detailedInfo && booking.detailedInfo.resources && booking.detailedInfo.resources.detailed) {
          booking.detailedInfo.resources.detailed.forEach((resource) => {
            if (resource.name) {
              const resourceName = resource.name.trim();
              if (resourceName) {
                // Use the resource quantity if available, otherwise fall back to party size, then to 1
                let resourceQuantity = 1;
                
                if (resource.quantity && typeof resource.quantity === 'number' && resource.quantity > 0) {
                  resourceQuantity = resource.quantity;
                } else if (booking.partySize && booking.partySize > 0) {
                  // If no specific quantity found, assume each guest uses the resource once
                  resourceQuantity = booking.partySize;
                }
                
                resourceCounts[resourceName] = (resourceCounts[resourceName] || 0) + resourceQuantity;
              }
            }
          });
        }
      });
      
      return resourceCounts;
    }

    // Function to normalize customer type names (combine singular/plural)
    function normalizeCustomerTypeName(typeName) {
      const name = typeName.trim();
      const lowerName = name.toLowerCase();
      
      // Special cases for irregular plurals
      const irregularPlurals = {
        'child': 'Children',
        'children': 'Children',
        'kid': 'Children',
        'kids': 'Children',
        'baby': 'Babies',
        'babies': 'Babies',
        'infant': 'Infants',
        'infants': 'Infants',
        'youth': 'Youth',
        'youths': 'Youth'
      };
      
      // Check for irregular plurals first
      if (irregularPlurals[lowerName]) {
        return irregularPlurals[lowerName];
      }
      
      // Generic singular/plural handling
      // If it ends with 's', assume it's already plural
      if (lowerName.endsWith('s')) {
        // Capitalize first letter and keep the rest as-is
        return name.charAt(0).toUpperCase() + name.slice(1);
      } else {
        // If it doesn't end with 's', make it plural by adding 's'
        return name.charAt(0).toUpperCase() + name.slice(1) + 's';
      }
    }

    // Function to aggregate customer type usage across all bookings
    function aggregateCustomerTypeUsage(bookings) {
      const customerTypeCounts = {};
      
      bookings.forEach(booking => {
        if (booking.customerTypes && Array.isArray(booking.customerTypes)) {
          booking.customerTypes.forEach(customerType => {
            const typeName = customerType.name.trim();
            if (typeName) {
              const normalizedName = normalizeCustomerTypeName(typeName);
              const quantity = customerType.quantity || 1;
              customerTypeCounts[normalizedName] = (customerTypeCounts[normalizedName] || 0) + quantity;
            }
          });
        }
      });
      
      return customerTypeCounts;
    }

    // Function to prepare audit summary
    function prepareAuditSummary(bookings, filteredBookings, skippedBookings, targetDateTime) {
      const capacityUsed = calculateCapacityUsed(filteredBookings);
      const resourcesUsed = aggregateResourceUsage(filteredBookings);
      const customerTypesUsed = aggregateCustomerTypeUsage(filteredBookings);
      
      return {
        filteredBookings,
        skippedBookings,
        totalCapacityUsed: capacityUsed,
        resourcesUsed,
        customerTypesUsed,
        targetDateTime: targetDateTime instanceof Date ? targetDateTime : new Date(targetDateTime),
        originalBookingsCount: bookings.length,
        filteredBookingsCount: filteredBookings.length,
        skippedBookingsCount: skippedBookings.length
      };
    }

    // Function to fetch detailed booking information using background tabs
    async function fetchBookingDetails(bookingHref, targetDateTime = null, extractResources = true) {
      try {
        console.log(`[availability-audit] ===== fetchBookingDetails CALLED =====`);
        console.log(`[availability-audit] Starting background tab scraping for: ${bookingHref}`);
        console.log(`[availability-audit] Target date/time: ${targetDateTime ? new Date(targetDateTime).toISOString() : 'null'}`);
        console.log(`[availability-audit] Extract resources: ${extractResources}`);
        
        if (!bookingHref) {
          console.error(`[availability-audit] ERROR: bookingHref is null or undefined!`);
          return null;
        }
        
        // Prepare the URL for background tab scraping
        // The bookingHref is typically a relative path that needs to be combined with the current calendar URL
        console.log(`[availability-audit] Original booking href: ${bookingHref}`);
        console.log(`[availability-audit] Current window location: ${window.location.href}`);
        
        let targetUrl = null;
        
        // Check if bookingHref already contains ?overlay=
        if (bookingHref.includes('?overlay=')) {
          // If it already has overlay parameter, extract it
          const overlayPath = bookingHref.split('?overlay=')[1];
          console.log(`[availability-audit] Extracted overlay path: ${overlayPath}`);
          
          if (overlayPath && overlayPath.includes('/bookings/')) {
            // Use the same base calendar URL with the booking overlay
            const currentUrl = new URL(window.location.href);
            const basePath = currentUrl.pathname; // e.g., /searocketftlauderdale/dashboard/items/598844/calendar/2025/12/
            
            console.log(`[availability-audit] Base path: ${basePath}`);
            console.log(`[availability-audit] Booking overlay path: ${overlayPath}`);
            
            // Construct the correct overlay URL using the calendar base with the booking overlay
            targetUrl = `${window.location.origin}${basePath}?overlay=${overlayPath}`;
            console.log(`[availability-audit] Constructed overlay booking URL: ${targetUrl}`);
          } else {
            console.log(`[availability-audit] Overlay path does not contain /bookings/`);
          }
        } else if (bookingHref.startsWith('/')) {
          // bookingHref is a relative path - could be an overlay path or a direct path
          // Check if we're on a calendar page - if so, treat it as an overlay path
          const currentUrl = new URL(window.location.href);
          const isCalendarPage = currentUrl.pathname.includes('/calendar/');
          
          if (isCalendarPage) {
            // We're on a calendar page, so bookingHref is likely an overlay path
            // e.g., /contacts/294171740/bookings/ef5a4c12-c5c3-44b0-b913-0c10f263e548/
            // We need to construct: https://fareharbor.com{calendarBasePath}?overlay={bookingHref}
            
            const basePath = currentUrl.pathname; // e.g., /searocketftlauderdale/dashboard/items/598844/calendar/2025/12/
            
            console.log(`[availability-audit] On calendar page - treating bookingHref as overlay path`);
            console.log(`[availability-audit] Current calendar base path: ${basePath}`);
            console.log(`[availability-audit] Booking href (overlay path): ${bookingHref}`);
            
            // Construct the full URL: origin + calendar path + overlay parameter
            targetUrl = `${window.location.origin}${basePath}?overlay=${encodeURIComponent(bookingHref)}`;
            console.log(`[availability-audit] Constructed full overlay URL: ${targetUrl}`);
          } else {
            // Not on calendar page, treat as direct relative path
            targetUrl = `${window.location.origin}${bookingHref}`;
            console.log(`[availability-audit] Not on calendar page - converted relative URL to absolute: ${targetUrl}`);
          }
        } else {
          // Fallback: treat as relative or absolute URL
          if (bookingHref.startsWith('/')) {
            targetUrl = `${window.location.origin}${bookingHref}`;
            console.log(`[availability-audit] Converted relative URL to absolute: ${targetUrl}`);
          } else if (bookingHref.startsWith('http://') || bookingHref.startsWith('https://')) {
            targetUrl = bookingHref;
            console.log(`[availability-audit] Using absolute URL as-is: ${targetUrl}`);
          } else {
            // Relative path without leading slash
            targetUrl = `${window.location.origin}/${bookingHref}`;
            console.log(`[availability-audit] Added leading slash and origin: ${targetUrl}`);
          }
        }
        
        if (!targetUrl) {
          console.error(`[availability-audit] ERROR: Failed to construct target URL from bookingHref: ${bookingHref}`);
          return null;
        }
        
        console.log(`[availability-audit] Final target URL: ${targetUrl}`);
        console.log(`[availability-audit] Sending message to background script to create tab...`);
        
        // Send scraping request to background script with target date/time for resource reapplication
        const response = await chrome.runtime.sendMessage({
          action: 'backgroundScrapeUrls',
          urls: [targetUrl],
          targetDateTime: targetDateTime, // Pass target date/time for resource reapplication detection
          extractResources: extractResources // Pass flag to indicate whether to extract resources
        });
        
        console.log(`[availability-audit] Received response from background script:`, {
          success: response ? response.success : false,
          hasResults: response && response.results ? response.results.length > 0 : false,
          error: response && !response.success ? response.error : null
        });
        
        if (response && response.success && response.results && response.results.length > 0) {
          const result = response.results[0];
          console.log(`[availability-audit] Background scraping result:`, {
            success: result.success,
            hasData: !!result.data,
            error: result.error,
            url: result.url
          });
          
          if (result.success && result.data) {
            console.log(`[availability-audit] Background scraping successful for: ${targetUrl}`);
            console.log(`[availability-audit] Found ${result.data.resources.detailed.length} resources`);
            console.log(`[availability-audit] Any resources found: ${result.data.foundAnyResources}`);
            console.log(`[availability-audit] Booking creation date (bookedAt): ${result.data.bookedAt ? new Date(result.data.bookedAt).toISOString() : 'not found'}`);
            
            const returnValue = {
              actualCapacity: null,
              bookingDetails: result.data,
              customerInfo: null,
              resources: result.data.resources,
              bookedAt: result.data.bookedAt ? new Date(result.data.bookedAt) : null
            };
            
            console.log(`[availability-audit] Returning booking details:`, {
              hasResources: !!returnValue.resources,
              resourcesCount: returnValue.resources ? returnValue.resources.detailed.length : 0,
              hasBookedAt: !!returnValue.bookedAt,
              bookedAt: returnValue.bookedAt ? returnValue.bookedAt.toISOString() : null
            });
            
            return returnValue;
          } else {
            console.warn(`[availability-audit] Background scraping failed: ${result.error || 'Unknown error'}`);
            return null;
          }
        } else {
          const errorMsg = response && response.error ? response.error : 'No response or empty results';
          console.warn(`[availability-audit] Background scraping request failed: ${errorMsg}`);
          return null;
        }
        
      } catch (error) {
        console.error(`[availability-audit] ===== ERROR IN fetchBookingDetails =====`);
        console.error(`[availability-audit] Error message: ${error.message}`);
        console.error(`[availability-audit] Error stack:`, error.stack);
        console.error(`[availability-audit] Booking href that caused error: ${bookingHref}`);
        return null;
      }
    }

    // Main audit function
    async function runAvailabilityAudit(targetDate, targetTime, fetchDetailedInfo = false) {
      try {
        console.log(`[availability-audit] AUDIT STARTED - fetchDetailedInfo: ${fetchDetailedInfo}`);
        console.log(`[availability-audit] Running audit for ${targetDate} ${targetTime} (detailed: ${fetchDetailedInfo})`);
        
        // Step 1: Scrape basic availability data
        const availabilityData = await scrapeAvailabilityData();
        if (!availabilityData || !availabilityData.bookings) {
          console.error('[availability-audit] Failed to scrape availability data');
          return { success: false, error: 'Failed to scrape availability data' };
        }

        // Step 2: Filter bookings based on target date and time
        const filteredResult = filterBookingsUpToDateTime(
          availabilityData.bookings,
          targetDate,
          targetTime
        );

        if (!filteredResult) {
          console.error('[availability-audit] Failed to filter bookings');
          return { success: false, error: 'Failed to filter bookings' };
        }

        // Step 3: Fetch bookedAt date for cancelled bookings (always needed for TSV export)
        // AND fetch detailed information if requested (only for filtered bookings)
        const cancelledBookings = filteredResult.filteredBookings.filter(b => b.isCancelled);
        const activeBookings = filteredResult.filteredBookings.filter(b => !b.isCancelled);
        console.log(`[availability-audit] Filtered bookings breakdown: ${cancelledBookings.length} cancelled, ${activeBookings.length} active`);
        
        // Always fetch bookedAt date for cancelled bookings (they were cancelled after timestamp, so were active at that time)
        const cancelledBookingsToFetch = cancelledBookings.filter(booking => booking.hasHref && booking.bookingHref);
        if (cancelledBookingsToFetch.length > 0) {
          console.log(`[availability-audit] Fetching bookedAt date for ${cancelledBookingsToFetch.length} cancelled bookings via background tabs`);
          
          for (let i = 0; i < cancelledBookingsToFetch.length; i++) {
            const cancelledBooking = cancelledBookingsToFetch[i];
            console.log(`[availability-audit] ===== FETCHING bookedAt FOR CANCELLED BOOKING ${i + 1}/${cancelledBookingsToFetch.length} =====`);
            console.log(`[availability-audit] Cancelled booking details:`, {
              bookingNumber: cancelledBooking.bookingNumber,
              hasHref: cancelledBooking.hasHref,
              bookingHref: cancelledBooking.bookingHref,
              datetime: cancelledBooking.datetime ? cancelledBooking.datetime.toISOString() : null,
              reason: cancelledBooking.reason
            });
            console.log(`[availability-audit] Calling fetchBookingDetails for bookedAt with URL: ${cancelledBooking.bookingHref}`);
            
            // Only extract bookedAt, skip resource extraction for speed
            const bookingDetails = await fetchBookingDetails(cancelledBooking.bookingHref, filteredResult.targetDateTime, false);
            
            if (bookingDetails && bookingDetails.bookedAt) {
              const bookedAtDate = bookingDetails.bookedAt instanceof Date ? bookingDetails.bookedAt : new Date(bookingDetails.bookedAt);
              console.log(`[availability-audit] Received bookedAt date: ${bookedAtDate.toISOString()}`);
              
              // Determine the correct reason based on bookedAt date
              let reason = 'cancelled_after_target'; // Default
              let shouldMoveToSkipped = false;
              if (!isNaN(bookedAtDate.getTime()) && filteredResult.targetDateTime) {
                if (bookedAtDate > filteredResult.targetDateTime) {
                  reason = 'cancelled_created_after_target';
                  shouldMoveToSkipped = true; // Move to skipped since booked after timestamp
                  console.log(`[availability-audit] Booking was created after timestamp - will move to skipped bookings`);
                } else {
                  reason = 'cancelled_was_active_at_target';
                  console.log(`[availability-audit] Booking was active at timestamp - keeping in filtered bookings`);
                }
              }
              
              // Update the original booking in availabilityData.bookings
              const originalBookingIndex = availabilityData.bookings.findIndex(b => 
                b.bookingHref === cancelledBooking.bookingHref
              );
              if (originalBookingIndex !== -1) {
                availabilityData.bookings[originalBookingIndex].bookedAt = bookingDetails.bookedAt;
                availabilityData.bookings[originalBookingIndex].reason = reason;
                console.log(`[availability-audit] Stored bookedAt date and reason for original booking: ${bookedAtDate.toISOString()}, reason: ${reason}`);
              }
              
              // Update the booking and move to skipped if needed
              cancelledBooking.bookedAt = bookingDetails.bookedAt;
              cancelledBooking.reason = reason;
              
              if (shouldMoveToSkipped) {
                // Remove from filteredBookings and add to skippedBookings
                const filteredIndex = filteredResult.filteredBookings.findIndex(b => 
                  b.bookingHref === cancelledBooking.bookingHref
                );
                if (filteredIndex !== -1) {
                  filteredResult.filteredBookings.splice(filteredIndex, 1);
                  console.log(`[availability-audit] Removed booking from filteredBookings`);
                }
                filteredResult.skippedBookings.push(cancelledBooking);
                console.log(`[availability-audit] Moved booking to skippedBookings with reason: ${reason}`);
              } else {
                console.log(`[availability-audit] Stored bookedAt date and reason for filtered cancelled booking: ${bookedAtDate.toISOString()}, reason: ${reason}`);
              }
            } else {
              console.log(`[availability-audit] No bookedAt date received for cancelled booking ${i + 1}`);
            }
          }
        } else {
          console.log(`[availability-audit] No cancelled bookings with hrefs to fetch bookedAt for`);
        }

        // Step 4: Fetch detailed information if requested (only for filtered bookings)
        if (fetchDetailedInfo) {
          console.log(`[availability-audit] DETAILED INFO ENABLED - Processing ${filteredResult.filteredBookings.length} filtered bookings (skipping ${filteredResult.skippedBookings.length} bookings created after target time)`);
          
          // Log cancelled bookings details
          cancelledBookings.forEach((booking, idx) => {
            console.log(`[availability-audit] Cancelled booking ${idx + 1}:`, {
              bookingNumber: booking.bookingNumber,
              hasHref: booking.hasHref,
              bookingHref: booking.bookingHref,
              datetime: booking.datetime ? booking.datetime.toISOString() : null,
              reason: booking.reason
            });
          });
          
          // Only process filtered bookings for detailed info
          const bookingsToFetch = filteredResult.filteredBookings.filter(booking => booking.hasHref && booking.bookingHref);
          
          console.log(`[availability-audit] Debug: Filtered bookings: ${filteredResult.filteredBookings.length}`);
          console.log(`[availability-audit] Debug: Filtered bookings with href: ${bookingsToFetch.length}`);
          
          // Log which bookings will be fetched
          bookingsToFetch.forEach((booking, idx) => {
            console.log(`[availability-audit] Booking ${idx + 1} to fetch:`, {
              bookingNumber: booking.bookingNumber,
              isCancelled: booking.isCancelled,
              bookingHref: booking.bookingHref,
              hasHref: booking.hasHref
            });
          });
          
          // Log which bookings were filtered out (no href)
          const bookingsWithoutHref = filteredResult.filteredBookings.filter(booking => !booking.hasHref || !booking.bookingHref);
          if (bookingsWithoutHref.length > 0) {
            console.log(`[availability-audit] WARNING: ${bookingsWithoutHref.length} filtered bookings have no href and will be skipped:`, 
              bookingsWithoutHref.map(b => ({
                bookingNumber: b.bookingNumber,
                isCancelled: b.isCancelled,
                hasHref: b.hasHref,
                bookingHref: b.bookingHref
              }))
            );
          }

          if (bookingsToFetch.length > 0) {
            console.log(`[availability-audit] Fetching detailed info for ${bookingsToFetch.length} filtered bookings via background tabs`);
            
            // Process only the filtered bookings with background tab scraping
            for (let i = 0; i < bookingsToFetch.length; i++) {
              const filteredBooking = bookingsToFetch[i];
              console.log(`[availability-audit] ===== FETCHING DETAILS FOR BOOKING ${i + 1}/${bookingsToFetch.length} =====`);
              console.log(`[availability-audit] Booking details:`, {
                bookingNumber: filteredBooking.bookingNumber,
                isCancelled: filteredBooking.isCancelled,
                bookingHref: filteredBooking.bookingHref,
                hasHref: filteredBooking.hasHref,
                datetime: filteredBooking.datetime ? filteredBooking.datetime.toISOString() : null,
                reason: filteredBooking.reason
              });
              console.log(`[availability-audit] Calling fetchBookingDetails with URL: ${filteredBooking.bookingHref}`);
              
              const bookingDetails = await fetchBookingDetails(filteredBooking.bookingHref, filteredResult.targetDateTime);
              
              console.log(`[availability-audit] fetchBookingDetails returned:`, {
                success: !!bookingDetails,
                hasResources: !!(bookingDetails && bookingDetails.resources),
                hasBookedAt: !!(bookingDetails && bookingDetails.bookedAt),
                bookedAt: bookingDetails && bookingDetails.bookedAt ? new Date(bookingDetails.bookedAt).toISOString() : null
              });
              if (bookingDetails && bookingDetails.resources) {
                console.log(`[availability-audit] Received details for filtered booking ${i + 1}:`, {
                  actualCapacity: bookingDetails.actualCapacity,
                  bookingDetails: bookingDetails.bookingDetails,
                  customerInfo: bookingDetails.customerInfo,
                  resources: bookingDetails.resources
                });
                
                console.log(`[availability-audit] Filtered booking ${i + 1} resources:`, bookingDetails.resources);
                
                // Update the original booking in availabilityData.bookings with detailed information
                // Find the corresponding booking in the original array
                const originalBookingIndex = availabilityData.bookings.findIndex(b => 
                  b.bookingHref === filteredBooking.bookingHref
                );
                if (originalBookingIndex !== -1) {
                  availabilityData.bookings[originalBookingIndex].detailedInfo = bookingDetails;
                  // Store bookedAt date if available (for cancelled bookings)
                  if (bookingDetails.bookedAt) {
                    const bookedAtDate = bookingDetails.bookedAt instanceof Date ? bookingDetails.bookedAt : new Date(bookingDetails.bookedAt);
                    availabilityData.bookings[originalBookingIndex].bookedAt = bookingDetails.bookedAt;
                    
                    // Update reason for cancelled bookings based on bookedAt date
                    if (filteredBooking.isCancelled && !isNaN(bookedAtDate.getTime()) && filteredResult.targetDateTime) {
                      let reason = 'cancelled_after_target';
                      if (bookedAtDate > filteredResult.targetDateTime) {
                        reason = 'cancelled_created_after_target';
                      } else {
                        reason = 'cancelled_was_active_at_target';
                      }
                      availabilityData.bookings[originalBookingIndex].reason = reason;
                      console.log(`[availability-audit] Stored bookedAt date and reason for original booking: ${bookedAtDate.toISOString()}, reason: ${reason}`);
                    } else {
                      console.log(`[availability-audit] Stored bookedAt date for original booking: ${bookedAtDate.toISOString()}`);
                    }
                  }
                }
                
                // Also update the filtered booking
                filteredBooking.detailedInfo = bookingDetails;
                if (bookingDetails.bookedAt) {
                  const bookedAtDate = bookingDetails.bookedAt instanceof Date ? bookingDetails.bookedAt : new Date(bookingDetails.bookedAt);
                  filteredBooking.bookedAt = bookingDetails.bookedAt;
                  
                  // Update reason for cancelled bookings based on bookedAt date
                  if (filteredBooking.isCancelled && !isNaN(bookedAtDate.getTime()) && filteredResult.targetDateTime) {
                    let reason = 'cancelled_after_target';
                    let shouldMoveToSkipped = false;
                    if (bookedAtDate > filteredResult.targetDateTime) {
                      reason = 'cancelled_created_after_target';
                      shouldMoveToSkipped = true; // Move to skipped since booked after timestamp
                      console.log(`[availability-audit] Booking was created after timestamp - will move to skipped bookings`);
                    } else {
                      reason = 'cancelled_was_active_at_target';
                      console.log(`[availability-audit] Booking was active at timestamp - keeping in filtered bookings`);
                    }
                    filteredBooking.reason = reason;
                    
                    if (shouldMoveToSkipped) {
                      // Remove from filteredBookings and add to skippedBookings
                      const filteredIndex = filteredResult.filteredBookings.findIndex(b => 
                        b.bookingHref === filteredBooking.bookingHref
                      );
                      if (filteredIndex !== -1) {
                        filteredResult.filteredBookings.splice(filteredIndex, 1);
                        console.log(`[availability-audit] Removed booking from filteredBookings`);
                      }
                      filteredResult.skippedBookings.push(filteredBooking);
                      console.log(`[availability-audit] Moved booking to skippedBookings with reason: ${reason}`);
                    } else {
                      console.log(`[availability-audit] Stored bookedAt date and reason for filtered booking: ${bookedAtDate.toISOString()}, reason: ${reason}`);
                    }
                  } else {
                    console.log(`[availability-audit] Stored bookedAt date for filtered booking: ${bookedAtDate.toISOString()}`);
                  }
                }
              } else {
                console.log(`[availability-audit] No detailed info received for filtered booking ${i + 1}`);
              }
            }
          }
        }

        // Step 5: Filter again after detailed fetching (in case the data changed)
        const finalFilteredResult = filterBookingsUpToDateTime(
          availabilityData.bookings,
          targetDate,
          targetTime
        );

        // Step 6: Prepare the final audit summary with all statistics
        const auditSummary = prepareAuditSummary(
          availabilityData.bookings,
          finalFilteredResult.filteredBookings,
          finalFilteredResult.skippedBookings,
          finalFilteredResult.targetDateTime
        );

        console.log(`[availability-audit] Audit completed successfully:`, {
          filteredBookings: auditSummary.filteredBookings.length,
          totalCapacityUsed: auditSummary.totalCapacityUsed,
          targetDateTime: auditSummary.targetDateTime,
          originalBookingsCount: auditSummary.originalBookingsCount,
          filteredBookingsCount: auditSummary.filteredBookingsCount,
          skippedBookingsCount: auditSummary.skippedBookingsCount
        });

        const pageContext = getAvailabilityPageContext();

        return {
          success: true,
          ...auditSummary,
          detailedInfoFetched: fetchDetailedInfo,
          pageContext
        };

      } catch (error) {
        console.error('[availability-audit] Audit failed:', error);
        return { success: false, error: error.message };
      }
    }

    // Message handler for communication with popup
    function handleMessage(req, sender, sendResponse) {
      console.log("[availability-audit] Received message:", req);
      
      if (req.action === 'runAvailabilityAudit') {
        console.log(`[availability-audit] Processing ${req.action} with fetchDetailedInfo: ${req.fetchDetailedInfo}`);
        
        runAvailabilityAudit(
          req.targetDate, 
          req.targetTime, 
          req.fetchDetailedInfo || false
        ).then(result => {
          console.log("[availability-audit] Sending audit result:", result);
          sendResponse(result);
        }).catch(error => {
          console.error("[availability-audit] Audit failed:", error);
          sendResponse({ 
            success: false, 
            error: error.message,
            details: error.stack 
          });
        });
        
        return true; // Keep message channel open for async response
        
      } else if (req.action === 'getAvailabilityPageInfo') {
        console.log(`[availability-audit] Processing getAvailabilityPageInfo request`);
        try {
          console.log(`[availability-audit] About to call detectPageType()`);
          const pageType = detectPageType();
          console.log(`[availability-audit] detectPageType() returned: ${pageType}`);
          
          const bookingElements = document.querySelectorAll(AUDIT_SELECTORS.BOOKING_ELEMENT);
          console.log(`[availability-audit] Found ${bookingElements.length} booking elements`);
          
          const sampleData = {
            pageType,
            bookings: bookingElements
          };
          
          const responseData = {
            success: true,
            pageType,
            canAudit: sampleData.bookings.length > 0  // If we find bookings, we can audit
          };
          
          console.log(`[availability-audit] About to send response:`, responseData);
          sendResponse(responseData);
          console.log(`[availability-audit] Response sent successfully`);
          
        } catch (error) {
          console.error("[availability-audit] Error in getAvailabilityPageInfo:", error);
          sendResponse({ 
            success: false, 
            error: error.message 
          });
        }
        
        return true;
      }
    }

    // Register the module
    window.AvailabilityAudit = {
      detectPageType,
      scrapeAvailabilityData,
      runAvailabilityAudit,
      handleMessage,
      fetchBookingDetails
    };
  }

  // Start waiting for utils
  waitForUtils();
})();
